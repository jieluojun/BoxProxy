.class public final Lb47;
.super Ljava/lang/Object;
.source "r8-map-id-bd0caf1bc4f5f32ccbf6362d02e487e5aa57647e3e4f9baa433c9379167097a7"


# instance fields
.field public final a:D

.field public final b:D

.field public final c:D

.field public final d:D

.field public final e:D

.field public final f:D

.field public final g:D


# direct methods
.method public synthetic constructor <init>(DDDDD)V
    .locals 15

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    move-object v0, p0

    move-wide/from16 v1, p1

    move-wide/from16 v3, p3

    move-wide/from16 v5, p5

    move-wide/from16 v7, p7

    move-wide/from16 v9, p9

    .line 187
    invoke-direct/range {v0 .. v14}, Lb47;-><init>(DDDDDDD)V

    return-void
.end method

.method public constructor <init>(DDDDDDD)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lb47;->a:D

    .line 5
    .line 6
    iput-wide p3, p0, Lb47;->b:D

    .line 7
    .line 8
    iput-wide p5, p0, Lb47;->c:D

    .line 9
    .line 10
    iput-wide p7, p0, Lb47;->d:D

    .line 11
    .line 12
    iput-wide p9, p0, Lb47;->e:D

    .line 13
    .line 14
    iput-wide p11, p0, Lb47;->f:D

    .line 15
    .line 16
    iput-wide p13, p0, Lb47;->g:D

    .line 17
    .line 18
    invoke-static {p3, p4}, Ljava/lang/Double;->isNaN(D)Z

    .line 19
    .line 20
    .line 21
    move-result p0

    .line 22
    const/4 v0, 0x0

    .line 23
    if-nez p0, :cond_a

    .line 24
    .line 25
    invoke-static {p5, p6}, Ljava/lang/Double;->isNaN(D)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-nez p0, :cond_a

    .line 30
    .line 31
    invoke-static {p7, p8}, Ljava/lang/Double;->isNaN(D)Z

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    if-nez p0, :cond_a

    .line 36
    .line 37
    invoke-static {p9, p10}, Ljava/lang/Double;->isNaN(D)Z

    .line 38
    .line 39
    .line 40
    move-result p0

    .line 41
    if-nez p0, :cond_a

    .line 42
    .line 43
    invoke-static {p11, p12}, Ljava/lang/Double;->isNaN(D)Z

    .line 44
    .line 45
    .line 46
    move-result p0

    .line 47
    if-nez p0, :cond_a

    .line 48
    .line 49
    invoke-static {p13, p14}, Ljava/lang/Double;->isNaN(D)Z

    .line 50
    .line 51
    .line 52
    move-result p0

    .line 53
    if-nez p0, :cond_a

    .line 54
    .line 55
    invoke-static {p1, p2}, Ljava/lang/Double;->isNaN(D)Z

    .line 56
    .line 57
    .line 58
    move-result p0

    .line 59
    if-nez p0, :cond_a

    .line 60
    .line 61
    const-wide/high16 p5, -0x4000000000000000L    # -2.0

    .line 62
    .line 63
    cmpg-double p0, p1, p5

    .line 64
    .line 65
    if-eqz p0, :cond_0

    .line 66
    .line 67
    const-wide/high16 p5, -0x3ff8000000000000L    # -3.0

    .line 68
    .line 69
    cmpg-double p0, p1, p5

    .line 70
    .line 71
    if-nez p0, :cond_1

    .line 72
    .line 73
    :cond_0
    return-void

    .line 74
    :cond_1
    const-wide/16 p5, 0x0

    .line 75
    .line 76
    cmpl-double p0, p9, p5

    .line 77
    .line 78
    if-ltz p0, :cond_9

    .line 79
    .line 80
    const-wide/high16 p11, 0x3ff0000000000000L    # 1.0

    .line 81
    .line 82
    cmpg-double p0, p9, p11

    .line 83
    .line 84
    if-gtz p0, :cond_9

    .line 85
    .line 86
    cmpg-double p0, p9, p5

    .line 87
    .line 88
    if-nez p0, :cond_3

    .line 89
    .line 90
    cmpg-double p0, p3, p5

    .line 91
    .line 92
    if-eqz p0, :cond_2

    .line 93
    .line 94
    cmpg-double p0, p1, p5

    .line 95
    .line 96
    if-nez p0, :cond_3

    .line 97
    .line 98
    :cond_2
    const-string p0, "Parameter a or g is zero, the transfer function is constant"

    .line 99
    .line 100
    invoke-static {p0}, Lex1;->h(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw v0

    .line 104
    :cond_3
    cmpl-double p0, p9, p11

    .line 105
    .line 106
    if-ltz p0, :cond_4

    .line 107
    .line 108
    cmpg-double p0, p7, p5

    .line 109
    .line 110
    if-nez p0, :cond_4

    .line 111
    .line 112
    const-string p0, "Parameter c is zero, the transfer function is constant"

    .line 113
    .line 114
    invoke-static {p0}, Lex1;->h(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw v0

    .line 118
    :cond_4
    cmpg-double p0, p3, p5

    .line 119
    .line 120
    if-eqz p0, :cond_5

    .line 121
    .line 122
    cmpg-double p0, p1, p5

    .line 123
    .line 124
    if-nez p0, :cond_6

    .line 125
    .line 126
    :cond_5
    cmpg-double p0, p7, p5

    .line 127
    .line 128
    if-nez p0, :cond_6

    .line 129
    .line 130
    const-string p0, "Parameter a or g is zero, and c is zero, the transfer function is constant"

    .line 131
    .line 132
    invoke-static {p0}, Lex1;->h(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    throw v0

    .line 136
    :cond_6
    cmpg-double p0, p7, p5

    .line 137
    .line 138
    if-ltz p0, :cond_8

    .line 139
    .line 140
    cmpg-double p0, p3, p5

    .line 141
    .line 142
    if-ltz p0, :cond_7

    .line 143
    .line 144
    cmpg-double p0, p1, p5

    .line 145
    .line 146
    if-ltz p0, :cond_7

    .line 147
    .line 148
    return-void

    .line 149
    :cond_7
    const-string p0, "The transfer function must be positive or increasing"

    .line 150
    .line 151
    invoke-static {p0}, Lex1;->h(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    throw v0

    .line 155
    :cond_8
    const-string p0, "The transfer function must be increasing"

    .line 156
    .line 157
    invoke-static {p0}, Lex1;->h(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    throw v0

    .line 161
    :cond_9
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 162
    .line 163
    new-instance p1, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    const-string p2, "Parameter d must be in the range [0..1], was "

    .line 166
    .line 167
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p1, p9, p10}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    throw p0

    .line 181
    :cond_a
    const-string p0, "Parameters cannot be NaN"

    .line 182
    .line 183
    invoke-static {p0}, Lex1;->h(Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    throw v0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lb47;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lb47;

    .line 12
    .line 13
    iget-wide v3, p0, Lb47;->a:D

    .line 14
    .line 15
    iget-wide v5, p1, Lb47;->a:D

    .line 16
    .line 17
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-wide v3, p0, Lb47;->b:D

    .line 25
    .line 26
    iget-wide v5, p1, Lb47;->b:D

    .line 27
    .line 28
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    iget-wide v3, p0, Lb47;->c:D

    .line 36
    .line 37
    iget-wide v5, p1, Lb47;->c:D

    .line 38
    .line 39
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_4

    .line 44
    .line 45
    return v2

    .line 46
    :cond_4
    iget-wide v3, p0, Lb47;->d:D

    .line 47
    .line 48
    iget-wide v5, p1, Lb47;->d:D

    .line 49
    .line 50
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_5

    .line 55
    .line 56
    return v2

    .line 57
    :cond_5
    iget-wide v3, p0, Lb47;->e:D

    .line 58
    .line 59
    iget-wide v5, p1, Lb47;->e:D

    .line 60
    .line 61
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-eqz v1, :cond_6

    .line 66
    .line 67
    return v2

    .line 68
    :cond_6
    iget-wide v3, p0, Lb47;->f:D

    .line 69
    .line 70
    iget-wide v5, p1, Lb47;->f:D

    .line 71
    .line 72
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    if-eqz v1, :cond_7

    .line 77
    .line 78
    return v2

    .line 79
    :cond_7
    iget-wide v3, p0, Lb47;->g:D

    .line 80
    .line 81
    iget-wide p0, p1, Lb47;->g:D

    .line 82
    .line 83
    invoke-static {v3, v4, p0, p1}, Ljava/lang/Double;->compare(DD)I

    .line 84
    .line 85
    .line 86
    move-result p0

    .line 87
    if-eqz p0, :cond_8

    .line 88
    .line 89
    return v2

    .line 90
    :cond_8
    return v0
.end method

.method public final hashCode()I
    .locals 4

    .line 1
    iget-wide v0, p0, Lb47;->a:D

    .line 2
    .line 3
    invoke-static {v0, v1}, Ljava/lang/Double;->hashCode(D)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-wide v2, p0, Lb47;->b:D

    .line 11
    .line 12
    invoke-static {v2, v3, v0, v1}, Llj6;->c(DII)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-wide v2, p0, Lb47;->c:D

    .line 17
    .line 18
    invoke-static {v2, v3, v0, v1}, Llj6;->c(DII)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-wide v2, p0, Lb47;->d:D

    .line 23
    .line 24
    invoke-static {v2, v3, v0, v1}, Llj6;->c(DII)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-wide v2, p0, Lb47;->e:D

    .line 29
    .line 30
    invoke-static {v2, v3, v0, v1}, Llj6;->c(DII)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget-wide v2, p0, Lb47;->f:D

    .line 35
    .line 36
    invoke-static {v2, v3, v0, v1}, Llj6;->c(DII)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    iget-wide v1, p0, Lb47;->g:D

    .line 41
    .line 42
    invoke-static {v1, v2}, Ljava/lang/Double;->hashCode(D)I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    add-int/2addr p0, v0

    .line 47
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "TransferParameters(gamma="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-wide v1, p0, Lb47;->a:D

    .line 9
    .line 10
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", a="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-wide v1, p0, Lb47;->b:D

    .line 19
    .line 20
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", b="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-wide v1, p0, Lb47;->c:D

    .line 29
    .line 30
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v1, ", c="

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    iget-wide v1, p0, Lb47;->d:D

    .line 39
    .line 40
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v1, ", d="

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    iget-wide v1, p0, Lb47;->e:D

    .line 49
    .line 50
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    const-string v1, ", e="

    .line 54
    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    iget-wide v1, p0, Lb47;->f:D

    .line 59
    .line 60
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string v1, ", f="

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    iget-wide v1, p0, Lb47;->g:D

    .line 69
    .line 70
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    const-string p0, ")"

    .line 74
    .line 75
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    return-object p0
.end method
