.class public final Lb32;
.super Lq91;


# instance fields
.field public synthetic i:Ljava/lang/Object;

.field public j:I

.field public final synthetic k:Lbl;

.field public l:Ljava/lang/Object;

.field public m:Le22;


# direct methods
.method public constructor <init>(Lbl;Lp91;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lb32;->k:Lbl;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lq91;-><init>(Lp91;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lb32;->i:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lb32;->j:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lb32;->j:I

    .line 9
    .line 10
    iget-object p1, p0, Lb32;->k:Lbl;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lbl;->d(Ljava/lang/Object;Lp91;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
