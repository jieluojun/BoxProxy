.class public abstract La03;
.super Ljava/lang/Object;
.source "r8-map-id-bd0caf1bc4f5f32ccbf6362d02e487e5aa57647e3e4f9baa433c9379167097a7"

# interfaces
.implements Ltz2;


# static fields
.field public static final synthetic i:J

.field public static final synthetic j:J


# instance fields
.field private volatile synthetic _parentHandle$volatile:Ljava/lang/Object;

.field private volatile synthetic _state$volatile:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 2
    .line 3
    const-class v1, La03;

    .line 4
    .line 5
    const-string v2, "_state$volatile"

    .line 6
    .line 7
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-virtual {v0, v2}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    .line 12
    .line 13
    .line 14
    move-result-wide v2

    .line 15
    sput-wide v2, La03;->j:J

    .line 16
    .line 17
    const-string v2, "_parentHandle$volatile"

    .line 18
    .line 19
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-virtual {v0, v1}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    sput-wide v0, La03;->i:J

    .line 28
    .line 29
    return-void
.end method

.method public constructor <init>(Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    sget-object p1, Lye0;->X:Lav1;

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    sget-object p1, Lye0;->W:Lav1;

    .line 10
    .line 11
    :goto_0
    iput-object p1, p0, La03;->_state$volatile:Ljava/lang/Object;

    .line 12
    .line 13
    return-void
.end method

.method public static Y(Lih3;)Lwo0;
    .locals 1

    .line 1
    :goto_0
    invoke-virtual {p0}, Lih3;->k()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Lih3;->j()Lih3;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p0}, Lih3;->i()Lih3;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p0}, Lih3;->k()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    instance-of v0, p0, Lwo0;

    .line 23
    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    check-cast p0, Lwo0;

    .line 27
    .line 28
    return-object p0

    .line 29
    :cond_1
    instance-of v0, p0, Lse4;

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    const/4 p0, 0x0

    .line 34
    return-object p0
.end method

.method public static f0(Ljava/lang/Object;)Ljava/lang/String;
    .locals 1

    .line 1
    instance-of v0, p0, Lzz2;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    check-cast p0, Lzz2;

    .line 6
    .line 7
    invoke-virtual {p0}, Lzz2;->e()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    const-string p0, "Cancelling"

    .line 14
    .line 15
    return-object p0

    .line 16
    :cond_0
    invoke-virtual {p0}, Lzz2;->f()Z

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    if-eqz p0, :cond_2

    .line 21
    .line 22
    const-string p0, "Completing"

    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_1
    instance-of v0, p0, Lws2;

    .line 26
    .line 27
    if-eqz v0, :cond_4

    .line 28
    .line 29
    check-cast p0, Lws2;

    .line 30
    .line 31
    invoke-interface {p0}, Lws2;->b()Z

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    if-eqz p0, :cond_3

    .line 36
    .line 37
    :cond_2
    const-string p0, "Active"

    .line 38
    .line 39
    return-object p0

    .line 40
    :cond_3
    const-string p0, "New"

    .line 41
    .line 42
    return-object p0

    .line 43
    :cond_4
    instance-of p0, p0, Liy0;

    .line 44
    .line 45
    if-eqz p0, :cond_5

    .line 46
    .line 47
    const-string p0, "Cancelled"

    .line 48
    .line 49
    return-object p0

    .line 50
    :cond_5
    const-string p0, "Completed"

    .line 51
    .line 52
    return-object p0
.end method


# virtual methods
.method public final A(Lec1;)Lfc1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lxl;->Q(Ldc1;Lec1;)Lfc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final C(Ljava/lang/Object;)Z
    .locals 12

    .line 1
    sget-object v0, Lye0;->R:Lhx4;

    .line 2
    .line 3
    invoke-virtual {p0}, La03;->N()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    if-eqz v1, :cond_3

    .line 10
    .line 11
    :cond_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    instance-of v1, v0, Lws2;

    .line 16
    .line 17
    if-eqz v1, :cond_2

    .line 18
    .line 19
    instance-of v1, v0, Lzz2;

    .line 20
    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    move-object v1, v0

    .line 24
    check-cast v1, Lzz2;

    .line 25
    .line 26
    invoke-virtual {v1}, Lzz2;->f()Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-nez v1, :cond_2

    .line 31
    .line 32
    :cond_1
    new-instance v1, Liy0;

    .line 33
    .line 34
    invoke-virtual {p0, p1}, La03;->J(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    invoke-direct {v1, v4, v2}, Liy0;-><init>(Ljava/lang/Throwable;Z)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0, v0, v1}, La03;->g0(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    sget-object v1, Lye0;->T:Lhx4;

    .line 46
    .line 47
    if-eq v0, v1, :cond_0

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    sget-object v0, Lye0;->R:Lhx4;

    .line 51
    .line 52
    :goto_0
    sget-object v1, Lye0;->S:Lhx4;

    .line 53
    .line 54
    if-eq v0, v1, :cond_12

    .line 55
    .line 56
    :cond_3
    sget-object v1, Lye0;->R:Lhx4;

    .line 57
    .line 58
    if-ne v0, v1, :cond_11

    .line 59
    .line 60
    const/4 v0, 0x0

    .line 61
    move-object v1, v0

    .line 62
    :goto_1
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    instance-of v5, v4, Lzz2;

    .line 67
    .line 68
    if-eqz v5, :cond_8

    .line 69
    .line 70
    monitor-enter v4

    .line 71
    :try_start_0
    move-object v5, v4

    .line 72
    check-cast v5, Lzz2;

    .line 73
    .line 74
    sget-object v6, Lhw;->a:Lsun/misc/Unsafe;

    .line 75
    .line 76
    sget-wide v7, Lzz2;->j:J

    .line 77
    .line 78
    invoke-virtual {v6, v5, v7, v8}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v5

    .line 82
    sget-object v6, Lye0;->V:Lhx4;

    .line 83
    .line 84
    if-ne v5, v6, :cond_4

    .line 85
    .line 86
    sget-object p1, Lye0;->U:Lhx4;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 87
    .line 88
    monitor-exit v4

    .line 89
    :goto_2
    move-object v6, p0

    .line 90
    move-object v0, p1

    .line 91
    goto/16 :goto_6

    .line 92
    .line 93
    :cond_4
    :try_start_1
    move-object v5, v4

    .line 94
    check-cast v5, Lzz2;

    .line 95
    .line 96
    invoke-virtual {v5}, Lzz2;->e()Z

    .line 97
    .line 98
    .line 99
    move-result v5

    .line 100
    if-nez v1, :cond_5

    .line 101
    .line 102
    invoke-virtual {p0, p1}, La03;->J(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    :cond_5
    move-object p1, v4

    .line 107
    check-cast p1, Lzz2;

    .line 108
    .line 109
    invoke-virtual {p1, v1}, Lzz2;->a(Ljava/lang/Throwable;)V

    .line 110
    .line 111
    .line 112
    move-object p1, v4

    .line 113
    check-cast p1, Lzz2;

    .line 114
    .line 115
    invoke-virtual {p1}, Lzz2;->c()Ljava/lang/Throwable;

    .line 116
    .line 117
    .line 118
    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 119
    if-nez v5, :cond_6

    .line 120
    .line 121
    move-object v0, p1

    .line 122
    :cond_6
    monitor-exit v4

    .line 123
    if-eqz v0, :cond_7

    .line 124
    .line 125
    check-cast v4, Lzz2;

    .line 126
    .line 127
    iget-object p1, v4, Lzz2;->i:Lse4;

    .line 128
    .line 129
    invoke-virtual {p0, p1, v0}, La03;->Z(Lse4;Ljava/lang/Throwable;)V

    .line 130
    .line 131
    .line 132
    :cond_7
    sget-object p1, Lye0;->R:Lhx4;

    .line 133
    .line 134
    goto :goto_2

    .line 135
    :catchall_0
    move-exception v0

    .line 136
    move-object p0, v0

    .line 137
    monitor-exit v4

    .line 138
    throw p0

    .line 139
    :cond_8
    instance-of v5, v4, Lws2;

    .line 140
    .line 141
    if-eqz v5, :cond_10

    .line 142
    .line 143
    if-nez v1, :cond_9

    .line 144
    .line 145
    invoke-virtual {p0, p1}, La03;->J(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    :cond_9
    move-object v9, v4

    .line 150
    check-cast v9, Lws2;

    .line 151
    .line 152
    invoke-interface {v9}, Lws2;->b()Z

    .line 153
    .line 154
    .line 155
    move-result v5

    .line 156
    if-eqz v5, :cond_d

    .line 157
    .line 158
    invoke-virtual {p0, v9}, La03;->O(Lws2;)Lse4;

    .line 159
    .line 160
    .line 161
    move-result-object v11

    .line 162
    if-nez v11, :cond_a

    .line 163
    .line 164
    move-object v6, p0

    .line 165
    goto :goto_5

    .line 166
    :cond_a
    new-instance v10, Lzz2;

    .line 167
    .line 168
    invoke-direct {v10, v11, v1}, Lzz2;-><init>(Lse4;Ljava/lang/Throwable;)V

    .line 169
    .line 170
    .line 171
    :goto_3
    sget-object v5, Lhw;->a:Lsun/misc/Unsafe;

    .line 172
    .line 173
    sget-wide v7, La03;->j:J

    .line 174
    .line 175
    move-object v6, p0

    .line 176
    invoke-virtual/range {v5 .. v10}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    move-result p0

    .line 180
    if-eqz p0, :cond_c

    .line 181
    .line 182
    invoke-virtual {v6, v11, v1}, La03;->Z(Lse4;Ljava/lang/Throwable;)V

    .line 183
    .line 184
    .line 185
    sget-object p0, Lye0;->R:Lhx4;

    .line 186
    .line 187
    :cond_b
    :goto_4
    move-object v0, p0

    .line 188
    goto :goto_6

    .line 189
    :cond_c
    invoke-virtual {v5, v6, v7, v8}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object p0

    .line 193
    if-ne p0, v9, :cond_e

    .line 194
    .line 195
    move-object p0, v6

    .line 196
    goto :goto_3

    .line 197
    :cond_d
    move-object v6, p0

    .line 198
    new-instance p0, Liy0;

    .line 199
    .line 200
    invoke-direct {p0, v1, v2}, Liy0;-><init>(Ljava/lang/Throwable;Z)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v6, v4, p0}, La03;->g0(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object p0

    .line 207
    sget-object v5, Lye0;->R:Lhx4;

    .line 208
    .line 209
    if-eq p0, v5, :cond_f

    .line 210
    .line 211
    sget-object v4, Lye0;->T:Lhx4;

    .line 212
    .line 213
    if-ne p0, v4, :cond_b

    .line 214
    .line 215
    :cond_e
    :goto_5
    move-object p0, v6

    .line 216
    goto/16 :goto_1

    .line 217
    .line 218
    :cond_f
    const-string p0, "Cannot happen in "

    .line 219
    .line 220
    invoke-static {p0, v4}, Lnf1;->h(Ljava/lang/String;Ljava/lang/Object;)V

    .line 221
    .line 222
    .line 223
    return v2

    .line 224
    :cond_10
    move-object v6, p0

    .line 225
    sget-object p0, Lye0;->U:Lhx4;

    .line 226
    .line 227
    goto :goto_4

    .line 228
    :cond_11
    move-object v6, p0

    .line 229
    :goto_6
    sget-object p0, Lye0;->R:Lhx4;

    .line 230
    .line 231
    if-eq v0, p0, :cond_12

    .line 232
    .line 233
    sget-object p0, Lye0;->S:Lhx4;

    .line 234
    .line 235
    if-ne v0, p0, :cond_13

    .line 236
    .line 237
    :cond_12
    return v3

    .line 238
    :cond_13
    sget-object p0, Lye0;->U:Lhx4;

    .line 239
    .line 240
    if-ne v0, p0, :cond_14

    .line 241
    .line 242
    return v2

    .line 243
    :cond_14
    invoke-virtual {v6, v0}, La03;->v(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    return v3
.end method

.method public D(Ljava/util/concurrent/CancellationException;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, La03;->C(Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final E(Lq91;)Ljava/lang/Object;
    .locals 3

    .line 1
    :cond_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Lws2;

    .line 6
    .line 7
    sget-object v2, Ll97;->a:Ll97;

    .line 8
    .line 9
    if-nez v1, :cond_1

    .line 10
    .line 11
    invoke-interface {p1}, Lp91;->getContext()Lfc1;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-static {p0}, Lqm;->x(Lfc1;)V

    .line 16
    .line 17
    .line 18
    return-object v2

    .line 19
    :cond_1
    invoke-virtual {p0, v0}, La03;->e0(Ljava/lang/Object;)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-ltz v0, :cond_0

    .line 24
    .line 25
    new-instance v0, Lri0;

    .line 26
    .line 27
    invoke-static {p1}, Lul;->I(Lp91;)Lp91;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    const/4 v1, 0x1

    .line 32
    invoke-direct {v0, v1, p1}, Lri0;-><init>(ILp91;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, Lri0;->t()V

    .line 36
    .line 37
    .line 38
    new-instance p1, Lwi5;

    .line 39
    .line 40
    invoke-direct {p1, v0}, Lwi5;-><init>(Lri0;)V

    .line 41
    .line 42
    .line 43
    invoke-static {p0, v1, p1}, Lqm;->I(Ltz2;ZLwz2;)Ltl1;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    new-instance p1, Lmi0;

    .line 48
    .line 49
    invoke-direct {p1, p0, v1}, Lmi0;-><init>(Ljava/lang/Object;B)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0, p1}, Lri0;->w(Lff4;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0}, Lri0;->q()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p0

    .line 59
    sget-object p1, Lpc1;->i:Lpc1;

    .line 60
    .line 61
    if-eq p0, p1, :cond_2

    .line 62
    .line 63
    move-object p0, v2

    .line 64
    :cond_2
    if-ne p0, p1, :cond_3

    .line 65
    .line 66
    return-object p0

    .line 67
    :cond_3
    return-object v2
.end method

.method public final F(Ljava/lang/Throwable;)Z
    .locals 4

    .line 1
    invoke-virtual {p0}, La03;->U()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    .line 8
    .line 9
    sget-object v1, Lhw;->a:Lsun/misc/Unsafe;

    .line 10
    .line 11
    sget-wide v2, La03;->i:J

    .line 12
    .line 13
    invoke-virtual {v1, p0, v2, v3}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    check-cast p0, Lvo0;

    .line 18
    .line 19
    if-eqz p0, :cond_1

    .line 20
    .line 21
    sget-object v1, Lye4;->i:Lye4;

    .line 22
    .line 23
    if-eq p0, v1, :cond_1

    .line 24
    .line 25
    invoke-interface {p0, p1}, Lvo0;->c(Ljava/lang/Throwable;)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-nez p0, :cond_0

    .line 30
    .line 31
    if-nez v0, :cond_0

    .line 32
    .line 33
    const/4 p0, 0x0

    .line 34
    return p0

    .line 35
    :cond_0
    const/4 p0, 0x1

    .line 36
    return p0

    .line 37
    :cond_1
    return v0
.end method

.method public G()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "Job was cancelled"

    .line 2
    .line 3
    return-object p0
.end method

.method public H(Ljava/lang/Throwable;)Z
    .locals 1

    .line 1
    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0, p1}, La03;->C(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_1

    .line 10
    .line 11
    invoke-virtual {p0}, La03;->M()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-eqz p0, :cond_1

    .line 16
    .line 17
    :cond_0
    const/4 p0, 0x1

    .line 18
    return p0

    .line 19
    :cond_1
    const/4 p0, 0x0

    .line 20
    return p0
.end method

.method public final I(Lws2;Ljava/lang/Object;)V
    .locals 6

    .line 1
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 2
    .line 3
    sget-wide v1, La03;->i:J

    .line 4
    .line 5
    invoke-virtual {v0, p0, v1, v2}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    check-cast v3, Lvo0;

    .line 10
    .line 11
    if-eqz v3, :cond_0

    .line 12
    .line 13
    invoke-interface {v3}, Ltl1;->a()V

    .line 14
    .line 15
    .line 16
    sget-object v3, Lye4;->i:Lye4;

    .line 17
    .line 18
    invoke-virtual {v0, p0, v1, v2, v3}, Lsun/misc/Unsafe;->putObjectVolatile(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    instance-of v0, p2, Liy0;

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    check-cast p2, Liy0;

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_1
    move-object p2, v1

    .line 30
    :goto_0
    if-eqz p2, :cond_2

    .line 31
    .line 32
    iget-object p2, p2, Liy0;->a:Ljava/lang/Throwable;

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_2
    move-object p2, v1

    .line 36
    :goto_1
    instance-of v0, p1, Lwz2;

    .line 37
    .line 38
    const-string v2, " for "

    .line 39
    .line 40
    const-string v3, "Exception in completion handler "

    .line 41
    .line 42
    if-eqz v0, :cond_3

    .line 43
    .line 44
    :try_start_0
    move-object v0, p1

    .line 45
    check-cast v0, Lwz2;

    .line 46
    .line 47
    invoke-virtual {v0, p2}, Lwz2;->n(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :catchall_0
    move-exception p2

    .line 52
    new-instance v0, Lky0;

    .line 53
    .line 54
    new-instance v1, Ljava/lang/StringBuilder;

    .line 55
    .line 56
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    invoke-direct {v0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0, v0}, La03;->R(Lky0;)V

    .line 76
    .line 77
    .line 78
    goto :goto_4

    .line 79
    :cond_3
    invoke-interface {p1}, Lws2;->d()Lse4;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    if-eqz p1, :cond_7

    .line 84
    .line 85
    new-instance v0, Lse3;

    .line 86
    .line 87
    const/4 v4, 0x1

    .line 88
    invoke-direct {v0, v4}, Lse3;-><init>(I)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p1, v0, v4}, Lih3;->e(Lih3;I)Z

    .line 92
    .line 93
    .line 94
    invoke-virtual {p1}, Lih3;->h()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 99
    .line 100
    .line 101
    check-cast v0, Lih3;

    .line 102
    .line 103
    :goto_2
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v4

    .line 107
    if-nez v4, :cond_6

    .line 108
    .line 109
    instance-of v4, v0, Lwz2;

    .line 110
    .line 111
    if-eqz v4, :cond_5

    .line 112
    .line 113
    :try_start_1
    move-object v4, v0

    .line 114
    check-cast v4, Lwz2;

    .line 115
    .line 116
    invoke-virtual {v4, p2}, Lwz2;->n(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 117
    .line 118
    .line 119
    goto :goto_3

    .line 120
    :catchall_1
    move-exception v4

    .line 121
    if-eqz v1, :cond_4

    .line 122
    .line 123
    invoke-static {v1, v4}, Lzt;->u(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 124
    .line 125
    .line 126
    goto :goto_3

    .line 127
    :cond_4
    new-instance v1, Lky0;

    .line 128
    .line 129
    new-instance v5, Ljava/lang/StringBuilder;

    .line 130
    .line 131
    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 135
    .line 136
    .line 137
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 138
    .line 139
    .line 140
    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 141
    .line 142
    .line 143
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v5

    .line 147
    invoke-direct {v1, v5, v4}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 148
    .line 149
    .line 150
    :cond_5
    :goto_3
    invoke-virtual {v0}, Lih3;->i()Lih3;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    goto :goto_2

    .line 155
    :cond_6
    if-eqz v1, :cond_7

    .line 156
    .line 157
    invoke-virtual {p0, v1}, La03;->R(Lky0;)V

    .line 158
    .line 159
    .line 160
    :cond_7
    :goto_4
    return-void
.end method

.method public final J(Ljava/lang/Object;)Ljava/lang/Throwable;
    .locals 3

    .line 1
    instance-of p0, p1, Ljava/lang/Throwable;

    .line 2
    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    check-cast p1, Ljava/lang/Throwable;

    .line 6
    .line 7
    return-object p1

    .line 8
    :cond_0
    check-cast p1, La03;

    .line 9
    .line 10
    invoke-virtual {p1}, La03;->P()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    instance-of v0, p0, Lzz2;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    move-object v0, p0

    .line 20
    check-cast v0, Lzz2;

    .line 21
    .line 22
    invoke-virtual {v0}, Lzz2;->c()Ljava/lang/Throwable;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    goto :goto_0

    .line 27
    :cond_1
    instance-of v0, p0, Liy0;

    .line 28
    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    move-object v0, p0

    .line 32
    check-cast v0, Liy0;

    .line 33
    .line 34
    iget-object v0, v0, Liy0;->a:Ljava/lang/Throwable;

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_2
    instance-of v0, p0, Lws2;

    .line 38
    .line 39
    if-nez v0, :cond_5

    .line 40
    .line 41
    move-object v0, v1

    .line 42
    :goto_0
    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    .line 43
    .line 44
    if-eqz v2, :cond_3

    .line 45
    .line 46
    move-object v1, v0

    .line 47
    check-cast v1, Ljava/util/concurrent/CancellationException;

    .line 48
    .line 49
    :cond_3
    if-nez v1, :cond_4

    .line 50
    .line 51
    new-instance v1, Luz2;

    .line 52
    .line 53
    invoke-static {p0}, La03;->f0(Ljava/lang/Object;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    const-string v2, "Parent job is "

    .line 58
    .line 59
    invoke-virtual {v2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    invoke-direct {v1, p0, v0, p1}, Luz2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;La03;)V

    .line 64
    .line 65
    .line 66
    :cond_4
    return-object v1

    .line 67
    :cond_5
    const-string p1, "Cannot be cancelling child in this state: "

    .line 68
    .line 69
    invoke-static {p1, p0}, Lnf1;->h(Ljava/lang/String;Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    return-object v1
.end method

.method public final K(Lzz2;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    instance-of v0, p2, Liy0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move-object v0, p2

    .line 7
    check-cast v0, Liy0;

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object v0, v1

    .line 11
    :goto_0
    if-eqz v0, :cond_1

    .line 12
    .line 13
    iget-object v1, v0, Liy0;->a:Ljava/lang/Throwable;

    .line 14
    .line 15
    :cond_1
    monitor-enter p1

    .line 16
    :try_start_0
    invoke-virtual {p1}, Lzz2;->e()Z

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1, v1}, Lzz2;->g(Ljava/lang/Throwable;)Ljava/util/ArrayList;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {p0, p1, v0}, La03;->L(Lzz2;Ljava/util/ArrayList;)Ljava/lang/Throwable;

    .line 24
    .line 25
    .line 26
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 27
    if-eqz v2, :cond_3

    .line 28
    .line 29
    :try_start_1
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    const/4 v4, 0x1

    .line 34
    if-le v3, v4, :cond_3

    .line 35
    .line 36
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    new-instance v4, Ljava/util/IdentityHashMap;

    .line 41
    .line 42
    invoke-direct {v4, v3}, Ljava/util/IdentityHashMap;-><init>(I)V

    .line 43
    .line 44
    .line 45
    invoke-static {v4}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    :cond_2
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    if-eqz v4, :cond_3

    .line 58
    .line 59
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    check-cast v4, Ljava/lang/Throwable;

    .line 64
    .line 65
    if-eq v4, v2, :cond_2

    .line 66
    .line 67
    if-eq v4, v2, :cond_2

    .line 68
    .line 69
    instance-of v5, v4, Ljava/util/concurrent/CancellationException;

    .line 70
    .line 71
    if-nez v5, :cond_2

    .line 72
    .line 73
    invoke-interface {v3, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v5

    .line 77
    if-eqz v5, :cond_2

    .line 78
    .line 79
    invoke-static {v2, v4}, Lzt;->u(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 80
    .line 81
    .line 82
    goto :goto_1

    .line 83
    :catchall_0
    move-exception v0

    .line 84
    move-object p0, v0

    .line 85
    move-object v6, p1

    .line 86
    goto :goto_3

    .line 87
    :cond_3
    monitor-exit p1

    .line 88
    if-eqz v2, :cond_4

    .line 89
    .line 90
    if-eq v2, v1, :cond_4

    .line 91
    .line 92
    new-instance p2, Liy0;

    .line 93
    .line 94
    const/4 v0, 0x0

    .line 95
    invoke-direct {p2, v2, v0}, Liy0;-><init>(Ljava/lang/Throwable;Z)V

    .line 96
    .line 97
    .line 98
    :cond_4
    if-eqz v2, :cond_6

    .line 99
    .line 100
    invoke-virtual {p0, v2}, La03;->F(Ljava/lang/Throwable;)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-nez v0, :cond_5

    .line 105
    .line 106
    invoke-virtual {p0, v2}, La03;->Q(Ljava/lang/Throwable;)Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    if-eqz v0, :cond_6

    .line 111
    .line 112
    :cond_5
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    .line 114
    .line 115
    move-object v2, p2

    .line 116
    check-cast v2, Liy0;

    .line 117
    .line 118
    sget-object v1, Lhw;->a:Lsun/misc/Unsafe;

    .line 119
    .line 120
    sget-wide v3, Liy0;->b:J

    .line 121
    .line 122
    const/4 v5, 0x0

    .line 123
    const/4 v6, 0x1

    .line 124
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->compareAndSwapInt(Ljava/lang/Object;JII)Z

    .line 125
    .line 126
    .line 127
    :cond_6
    invoke-virtual {p0, p2}, La03;->a0(Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    instance-of v0, p2, Lws2;

    .line 131
    .line 132
    if-eqz v0, :cond_7

    .line 133
    .line 134
    new-instance v0, Lxs2;

    .line 135
    .line 136
    move-object v1, p2

    .line 137
    check-cast v1, Lws2;

    .line 138
    .line 139
    invoke-direct {v0, v1}, Lxs2;-><init>(Lws2;)V

    .line 140
    .line 141
    .line 142
    move-object v7, v0

    .line 143
    goto :goto_2

    .line 144
    :cond_7
    move-object v7, p2

    .line 145
    :goto_2
    sget-object v2, Lhw;->a:Lsun/misc/Unsafe;

    .line 146
    .line 147
    sget-wide v4, La03;->j:J

    .line 148
    .line 149
    move-object v3, p0

    .line 150
    move-object v6, p1

    .line 151
    invoke-virtual/range {v2 .. v7}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result p0

    .line 155
    if-nez p0, :cond_8

    .line 156
    .line 157
    invoke-virtual {v2, v3, v4, v5}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    if-eq p0, v6, :cond_9

    .line 162
    .line 163
    :cond_8
    invoke-virtual {v3, v6, p2}, La03;->I(Lws2;Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    return-object p2

    .line 167
    :cond_9
    move-object p0, v3

    .line 168
    move-object p1, v6

    .line 169
    goto :goto_2

    .line 170
    :catchall_1
    move-exception v0

    .line 171
    move-object v6, p1

    .line 172
    move-object p0, v0

    .line 173
    :goto_3
    monitor-exit v6

    .line 174
    throw p0
.end method

.method public final L(Lzz2;Ljava/util/ArrayList;)Ljava/lang/Throwable;
    .locals 2

    .line 1
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    invoke-virtual {p1}, Lzz2;->e()Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    new-instance p1, Luz2;

    .line 15
    .line 16
    invoke-virtual {p0}, La03;->G()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    invoke-direct {p1, p2, v1, p0}, Luz2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;La03;)V

    .line 21
    .line 22
    .line 23
    return-object p1

    .line 24
    :cond_0
    return-object v1

    .line 25
    :cond_1
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    :cond_2
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_3

    .line 34
    .line 35
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    move-object v0, p1

    .line 40
    check-cast v0, Ljava/lang/Throwable;

    .line 41
    .line 42
    instance-of v0, v0, Ljava/util/concurrent/CancellationException;

    .line 43
    .line 44
    if-nez v0, :cond_2

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_3
    move-object p1, v1

    .line 48
    :goto_0
    check-cast p1, Ljava/lang/Throwable;

    .line 49
    .line 50
    if-eqz p1, :cond_4

    .line 51
    .line 52
    return-object p1

    .line 53
    :cond_4
    const/4 p0, 0x0

    .line 54
    invoke-interface {p2, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    check-cast p0, Ljava/lang/Throwable;

    .line 59
    .line 60
    instance-of p1, p0, Lo07;

    .line 61
    .line 62
    if-eqz p1, :cond_7

    .line 63
    .line 64
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    :cond_5
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 69
    .line 70
    .line 71
    move-result p2

    .line 72
    if-eqz p2, :cond_6

    .line 73
    .line 74
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p2

    .line 78
    move-object v0, p2

    .line 79
    check-cast v0, Ljava/lang/Throwable;

    .line 80
    .line 81
    if-eq v0, p0, :cond_5

    .line 82
    .line 83
    instance-of v0, v0, Lo07;

    .line 84
    .line 85
    if-eqz v0, :cond_5

    .line 86
    .line 87
    move-object v1, p2

    .line 88
    :cond_6
    check-cast v1, Ljava/lang/Throwable;

    .line 89
    .line 90
    if-eqz v1, :cond_7

    .line 91
    .line 92
    return-object v1

    .line 93
    :cond_7
    return-object p0
.end method

.method public M()Z
    .locals 0

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public N()Z
    .locals 0

    .line 1
    instance-of p0, p0, Lfy0;

    .line 2
    .line 3
    return p0
.end method

.method public final O(Lws2;)Lse4;
    .locals 2

    .line 1
    invoke-interface {p1}, Lws2;->d()Lse4;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_2

    .line 6
    .line 7
    instance-of v0, p1, Lav1;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    new-instance p0, Lse4;

    .line 12
    .line 13
    invoke-direct {p0}, Lih3;-><init>()V

    .line 14
    .line 15
    .line 16
    return-object p0

    .line 17
    :cond_0
    instance-of v0, p1, Lwz2;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    check-cast p1, Lwz2;

    .line 23
    .line 24
    invoke-virtual {p0, p1}, La03;->d0(Lwz2;)V

    .line 25
    .line 26
    .line 27
    return-object v1

    .line 28
    :cond_1
    const-string p0, "State should have list: "

    .line 29
    .line 30
    invoke-static {p0, p1}, Lnf1;->h(Ljava/lang/String;Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    return-object v1

    .line 34
    :cond_2
    return-object v0
.end method

.method public final P()Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 2
    .line 3
    sget-wide v1, La03;->j:J

    .line 4
    .line 5
    invoke-virtual {v0, p0, v1, v2}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public Q(Ljava/lang/Throwable;)Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public R(Lky0;)V
    .locals 0

    .line 1
    throw p1
.end method

.method public final S(Ltz2;)V
    .locals 5

    .line 1
    sget-wide v0, La03;->i:J

    .line 2
    .line 3
    sget-object v2, Lye4;->i:Lye4;

    .line 4
    .line 5
    if-nez p1, :cond_0

    .line 6
    .line 7
    sget-object p1, Lhw;->a:Lsun/misc/Unsafe;

    .line 8
    .line 9
    invoke-virtual {p1, p0, v0, v1, v2}, Lsun/misc/Unsafe;->putObjectVolatile(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    invoke-interface {p1}, Ltz2;->start()Z

    .line 14
    .line 15
    .line 16
    invoke-interface {p1, p0}, Ltz2;->j(La03;)Lvo0;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    sget-object v3, Lhw;->a:Lsun/misc/Unsafe;

    .line 21
    .line 22
    invoke-virtual {v3, p0, v0, v1, p1}, Lsun/misc/Unsafe;->putObjectVolatile(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    instance-of v4, v4, Lws2;

    .line 30
    .line 31
    if-nez v4, :cond_1

    .line 32
    .line 33
    invoke-interface {p1}, Ltl1;->a()V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v3, p0, v0, v1, v2}, Lsun/misc/Unsafe;->putObjectVolatile(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    :cond_1
    return-void
.end method

.method public final T(ZLwz2;)Ltl1;
    .locals 6

    .line 1
    iput-object p0, p2, Lwz2;->l:La03;

    .line 2
    .line 3
    :goto_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    instance-of v0, v4, Lav1;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    move-object v0, v4

    .line 12
    check-cast v0, Lav1;

    .line 13
    .line 14
    iget-boolean v1, v0, Lav1;->i:Z

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    :goto_1
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 19
    .line 20
    sget-wide v2, La03;->j:J

    .line 21
    .line 22
    move-object v1, p0

    .line 23
    move-object v5, p2

    .line 24
    invoke-virtual/range {v0 .. v5}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    if-nez p0, :cond_7

    .line 29
    .line 30
    invoke-virtual {v0, v1, v2, v3}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    if-ne p0, v4, :cond_8

    .line 35
    .line 36
    move-object p0, v1

    .line 37
    move-object p2, v5

    .line 38
    goto :goto_1

    .line 39
    :cond_0
    move-object v1, p0

    .line 40
    move-object v5, p2

    .line 41
    invoke-virtual {v1, v0}, La03;->c0(Lav1;)V

    .line 42
    .line 43
    .line 44
    goto :goto_4

    .line 45
    :cond_1
    move-object v1, p0

    .line 46
    move-object v5, p2

    .line 47
    instance-of p0, v4, Lws2;

    .line 48
    .line 49
    sget-object p2, Lye4;->i:Lye4;

    .line 50
    .line 51
    const/4 v0, 0x0

    .line 52
    if-eqz p0, :cond_9

    .line 53
    .line 54
    move-object p0, v4

    .line 55
    check-cast p0, Lws2;

    .line 56
    .line 57
    invoke-interface {p0}, Lws2;->d()Lse4;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    if-nez v2, :cond_2

    .line 62
    .line 63
    check-cast v4, Lwz2;

    .line 64
    .line 65
    invoke-virtual {v1, v4}, La03;->d0(Lwz2;)V

    .line 66
    .line 67
    .line 68
    goto :goto_4

    .line 69
    :cond_2
    invoke-virtual {v5}, Lwz2;->m()Z

    .line 70
    .line 71
    .line 72
    move-result v3

    .line 73
    if-eqz v3, :cond_6

    .line 74
    .line 75
    instance-of v3, p0, Lzz2;

    .line 76
    .line 77
    if-eqz v3, :cond_3

    .line 78
    .line 79
    check-cast p0, Lzz2;

    .line 80
    .line 81
    goto :goto_2

    .line 82
    :cond_3
    move-object p0, v0

    .line 83
    :goto_2
    if-eqz p0, :cond_4

    .line 84
    .line 85
    invoke-virtual {p0}, Lzz2;->c()Ljava/lang/Throwable;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    :cond_4
    if-nez v0, :cond_5

    .line 90
    .line 91
    const/4 p0, 0x5

    .line 92
    invoke-virtual {v2, v5, p0}, Lih3;->e(Lih3;I)Z

    .line 93
    .line 94
    .line 95
    move-result p0

    .line 96
    goto :goto_3

    .line 97
    :cond_5
    if-eqz p1, :cond_c

    .line 98
    .line 99
    invoke-virtual {v5, v0}, Lwz2;->n(Ljava/lang/Throwable;)V

    .line 100
    .line 101
    .line 102
    return-object p2

    .line 103
    :cond_6
    const/4 p0, 0x1

    .line 104
    invoke-virtual {v2, v5, p0}, Lih3;->e(Lih3;I)Z

    .line 105
    .line 106
    .line 107
    move-result p0

    .line 108
    :goto_3
    if-eqz p0, :cond_8

    .line 109
    .line 110
    :cond_7
    return-object v5

    .line 111
    :cond_8
    :goto_4
    move-object p0, v1

    .line 112
    move-object p2, v5

    .line 113
    goto :goto_0

    .line 114
    :cond_9
    if-eqz p1, :cond_c

    .line 115
    .line 116
    invoke-virtual {v1}, La03;->P()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object p0

    .line 120
    instance-of p1, p0, Liy0;

    .line 121
    .line 122
    if-eqz p1, :cond_a

    .line 123
    .line 124
    check-cast p0, Liy0;

    .line 125
    .line 126
    goto :goto_5

    .line 127
    :cond_a
    move-object p0, v0

    .line 128
    :goto_5
    if-eqz p0, :cond_b

    .line 129
    .line 130
    iget-object v0, p0, Liy0;->a:Ljava/lang/Throwable;

    .line 131
    .line 132
    :cond_b
    invoke-virtual {v5, v0}, Lwz2;->n(Ljava/lang/Throwable;)V

    .line 133
    .line 134
    .line 135
    :cond_c
    return-object p2
.end method

.method public U()Z
    .locals 0

    .line 1
    instance-of p0, p0, Lc30;

    .line 2
    .line 3
    return p0
.end method

.method public final V(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    :cond_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, v0, p1}, La03;->g0(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget-object v1, Lye0;->R:Lhx4;

    .line 10
    .line 11
    if-ne v0, v1, :cond_1

    .line 12
    .line 13
    const/4 p0, 0x0

    .line 14
    return p0

    .line 15
    :cond_1
    sget-object v1, Lye0;->S:Lhx4;

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    if-ne v0, v1, :cond_2

    .line 19
    .line 20
    return v2

    .line 21
    :cond_2
    sget-object v1, Lye0;->T:Lhx4;

    .line 22
    .line 23
    if-eq v0, v1, :cond_0

    .line 24
    .line 25
    invoke-virtual {p0, v0}, La03;->v(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    return v2
.end method

.method public final W(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    :cond_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, v0, p1}, La03;->g0(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget-object v1, Lye0;->R:Lhx4;

    .line 10
    .line 11
    if-ne v0, v1, :cond_3

    .line 12
    .line 13
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    new-instance v1, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v2, "Job "

    .line 18
    .line 19
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string p0, " is already complete or completing, but is being completed with "

    .line 26
    .line 27
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    instance-of v1, p1, Liy0;

    .line 38
    .line 39
    const/4 v2, 0x0

    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    check-cast p1, Liy0;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    move-object p1, v2

    .line 46
    :goto_0
    if-eqz p1, :cond_2

    .line 47
    .line 48
    iget-object v2, p1, Liy0;->a:Ljava/lang/Throwable;

    .line 49
    .line 50
    :cond_2
    invoke-direct {v0, p0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 51
    .line 52
    .line 53
    throw v0

    .line 54
    :cond_3
    sget-object v1, Lye0;->T:Lhx4;

    .line 55
    .line 56
    if-eq v0, v1, :cond_0

    .line 57
    .line 58
    return-object v0
.end method

.method public X()Ljava/lang/String;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final Z(Lse4;Ljava/lang/Throwable;)V
    .locals 5

    .line 1
    new-instance v0, Lse3;

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    invoke-direct {v0, v1}, Lse3;-><init>(I)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1, v0, v1}, Lih3;->e(Lih3;I)Z

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1}, Lih3;->h()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    check-cast v0, Lih3;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    :goto_0
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    if-nez v2, :cond_2

    .line 25
    .line 26
    instance-of v2, v0, Lwz2;

    .line 27
    .line 28
    if-eqz v2, :cond_1

    .line 29
    .line 30
    move-object v2, v0

    .line 31
    check-cast v2, Lwz2;

    .line 32
    .line 33
    invoke-virtual {v2}, Lwz2;->m()Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_1

    .line 38
    .line 39
    :try_start_0
    move-object v2, v0

    .line 40
    check-cast v2, Lwz2;

    .line 41
    .line 42
    invoke-virtual {v2, p2}, Lwz2;->n(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    .line 44
    .line 45
    goto :goto_1

    .line 46
    :catchall_0
    move-exception v2

    .line 47
    if-eqz v1, :cond_0

    .line 48
    .line 49
    invoke-static {v1, v2}, Lzt;->u(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 50
    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_0
    new-instance v1, Lky0;

    .line 54
    .line 55
    new-instance v3, Ljava/lang/StringBuilder;

    .line 56
    .line 57
    const-string v4, "Exception in completion handler "

    .line 58
    .line 59
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    const-string v4, " for "

    .line 66
    .line 67
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    invoke-direct {v1, v3, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 78
    .line 79
    .line 80
    :cond_1
    :goto_1
    invoke-virtual {v0}, Lih3;->i()Lih3;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    goto :goto_0

    .line 85
    :cond_2
    if-eqz v1, :cond_3

    .line 86
    .line 87
    invoke-virtual {p0, v1}, La03;->R(Lky0;)V

    .line 88
    .line 89
    .line 90
    :cond_3
    invoke-virtual {p0, p2}, La03;->F(Ljava/lang/Throwable;)Z

    .line 91
    .line 92
    .line 93
    return-void
.end method

.method public a0(Ljava/lang/Object;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final b()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    instance-of v0, p0, Lws2;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast p0, Lws2;

    .line 10
    .line 11
    invoke-interface {p0}, Lws2;->b()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-eqz p0, :cond_0

    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    return p0

    .line 19
    :cond_0
    const/4 p0, 0x0

    .line 20
    return p0
.end method

.method public b0()V
    .locals 0

    .line 1
    return-void
.end method

.method public c(Ljava/util/concurrent/CancellationException;)V
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    new-instance p1, Luz2;

    .line 4
    .line 5
    invoke-virtual {p0}, La03;->G()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-direct {p1, v0, v1, p0}, Luz2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;La03;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    invoke-virtual {p0, p1}, La03;->D(Ljava/util/concurrent/CancellationException;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final c0(Lav1;)V
    .locals 8

    .line 1
    new-instance v0, Lse4;

    .line 2
    .line 3
    invoke-direct {v0}, Lih3;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-boolean v1, p1, Lav1;->i:Z

    .line 7
    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    move-object v7, v0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance v1, Lts2;

    .line 13
    .line 14
    invoke-direct {v1, v0}, Lts2;-><init>(Lse4;)V

    .line 15
    .line 16
    .line 17
    move-object v7, v1

    .line 18
    :goto_0
    sget-object v2, Lhw;->a:Lsun/misc/Unsafe;

    .line 19
    .line 20
    sget-wide v4, La03;->j:J

    .line 21
    .line 22
    move-object v3, p0

    .line 23
    move-object v6, p1

    .line 24
    invoke-virtual/range {v2 .. v7}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    if-nez p0, :cond_1

    .line 29
    .line 30
    invoke-virtual {v2, v3, v4, v5}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    if-eq p0, v6, :cond_2

    .line 35
    .line 36
    :cond_1
    return-void

    .line 37
    :cond_2
    move-object p0, v3

    .line 38
    move-object p1, v6

    .line 39
    goto :goto_0
.end method

.method public final d0(Lwz2;)V
    .locals 14

    .line 1
    new-instance v5, Lse4;

    .line 2
    .line 3
    invoke-direct {v5}, Lih3;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 7
    .line 8
    sget-wide v1, Lih3;->j:J

    .line 9
    .line 10
    invoke-virtual {v0, v5, v1, v2, p1}, Lsun/misc/Unsafe;->putObjectVolatile(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    sget-wide v6, Lih3;->i:J

    .line 14
    .line 15
    invoke-virtual {v0, v5, v6, v7, p1}, Lsun/misc/Unsafe;->putObjectVolatile(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :goto_0
    invoke-virtual {p1}, Lih3;->h()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-eq v0, p1, :cond_0

    .line 23
    .line 24
    move-object v1, p1

    .line 25
    goto :goto_2

    .line 26
    :cond_0
    :goto_1
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 27
    .line 28
    sget-wide v2, Lih3;->i:J

    .line 29
    .line 30
    move-object v4, p1

    .line 31
    move-object v1, p1

    .line 32
    invoke-virtual/range {v0 .. v5}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    if-eqz p1, :cond_3

    .line 37
    .line 38
    invoke-virtual {v5, v1}, Lih3;->g(Lih3;)V

    .line 39
    .line 40
    .line 41
    :goto_2
    invoke-virtual {v1}, Lih3;->i()Lih3;

    .line 42
    .line 43
    .line 44
    move-result-object v13

    .line 45
    :goto_3
    sget-object v8, Lhw;->a:Lsun/misc/Unsafe;

    .line 46
    .line 47
    sget-wide v10, La03;->j:J

    .line 48
    .line 49
    move-object v9, p0

    .line 50
    move-object v12, v1

    .line 51
    invoke-virtual/range {v8 .. v13}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result p0

    .line 55
    if-nez p0, :cond_1

    .line 56
    .line 57
    invoke-virtual {v8, v9, v10, v11}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    if-eq p0, v1, :cond_2

    .line 62
    .line 63
    :cond_1
    return-void

    .line 64
    :cond_2
    move-object p0, v9

    .line 65
    goto :goto_3

    .line 66
    :cond_3
    move-object v9, p0

    .line 67
    invoke-virtual {v0, v1, v6, v7}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    move-object p1, v1

    .line 72
    if-eq p0, v1, :cond_4

    .line 73
    .line 74
    move-object p0, v9

    .line 75
    goto :goto_0

    .line 76
    :cond_4
    move-object p0, v9

    .line 77
    goto :goto_1
.end method

.method public final e0(Ljava/lang/Object;)I
    .locals 9

    .line 1
    instance-of v0, p1, Lav1;

    .line 2
    .line 3
    sget-wide v6, La03;->j:J

    .line 4
    .line 5
    const/4 v8, 0x1

    .line 6
    if-eqz v0, :cond_2

    .line 7
    .line 8
    move-object v0, p1

    .line 9
    check-cast v0, Lav1;

    .line 10
    .line 11
    iget-boolean v0, v0, Lav1;->i:Z

    .line 12
    .line 13
    if-nez v0, :cond_5

    .line 14
    .line 15
    sget-object v5, Lye0;->X:Lav1;

    .line 16
    .line 17
    :cond_0
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 18
    .line 19
    sget-wide v2, La03;->j:J

    .line 20
    .line 21
    move-object v1, p0

    .line 22
    move-object v4, p1

    .line 23
    invoke-virtual/range {v0 .. v5}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-eqz v2, :cond_1

    .line 28
    .line 29
    invoke-virtual {p0}, La03;->b0()V

    .line 30
    .line 31
    .line 32
    return v8

    .line 33
    :cond_1
    invoke-virtual {v0, p0, v6, v7}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-eq v0, p1, :cond_0

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_2
    instance-of v0, p1, Lts2;

    .line 41
    .line 42
    if-eqz v0, :cond_5

    .line 43
    .line 44
    move-object v0, p1

    .line 45
    check-cast v0, Lts2;

    .line 46
    .line 47
    iget-object v5, v0, Lts2;->i:Lse4;

    .line 48
    .line 49
    :cond_3
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 50
    .line 51
    sget-wide v2, La03;->j:J

    .line 52
    .line 53
    move-object v1, p0

    .line 54
    move-object v4, p1

    .line 55
    invoke-virtual/range {v0 .. v5}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    if-eqz v2, :cond_4

    .line 60
    .line 61
    invoke-virtual {p0}, La03;->b0()V

    .line 62
    .line 63
    .line 64
    return v8

    .line 65
    :cond_4
    invoke-virtual {v0, p0, v6, v7}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    if-eq v0, p1, :cond_3

    .line 70
    .line 71
    :goto_0
    const/4 v0, -0x1

    .line 72
    return v0

    .line 73
    :cond_5
    const/4 v0, 0x0

    .line 74
    return v0
.end method

.method public final g0(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    instance-of v0, p1, Lws2;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    sget-object p0, Lye0;->R:Lhx4;

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_0
    instance-of v0, p1, Lav1;

    .line 9
    .line 10
    if-nez v0, :cond_1

    .line 11
    .line 12
    instance-of v0, p1, Lwz2;

    .line 13
    .line 14
    if-eqz v0, :cond_5

    .line 15
    .line 16
    :cond_1
    instance-of v0, p1, Lwo0;

    .line 17
    .line 18
    if-nez v0, :cond_5

    .line 19
    .line 20
    instance-of v0, p2, Liy0;

    .line 21
    .line 22
    if-nez v0, :cond_5

    .line 23
    .line 24
    move-object v5, p1

    .line 25
    check-cast v5, Lws2;

    .line 26
    .line 27
    instance-of p1, p2, Lws2;

    .line 28
    .line 29
    if-eqz p1, :cond_2

    .line 30
    .line 31
    new-instance p1, Lxs2;

    .line 32
    .line 33
    move-object v0, p2

    .line 34
    check-cast v0, Lws2;

    .line 35
    .line 36
    invoke-direct {p1, v0}, Lxs2;-><init>(Lws2;)V

    .line 37
    .line 38
    .line 39
    move-object v6, p1

    .line 40
    goto :goto_0

    .line 41
    :cond_2
    move-object v6, p2

    .line 42
    :goto_0
    sget-object v1, Lhw;->a:Lsun/misc/Unsafe;

    .line 43
    .line 44
    sget-wide v3, La03;->j:J

    .line 45
    .line 46
    move-object v2, p0

    .line 47
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    if-eqz p0, :cond_3

    .line 52
    .line 53
    invoke-virtual {v2, p2}, La03;->a0(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v2, v5, p2}, La03;->I(Lws2;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    return-object p2

    .line 60
    :cond_3
    invoke-virtual {v1, v2, v3, v4}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    if-eq p0, v5, :cond_4

    .line 65
    .line 66
    sget-object p0, Lye0;->T:Lhx4;

    .line 67
    .line 68
    return-object p0

    .line 69
    :cond_4
    move-object p0, v2

    .line 70
    goto :goto_0

    .line 71
    :cond_5
    move-object v2, p0

    .line 72
    move-object v11, p1

    .line 73
    check-cast v11, Lws2;

    .line 74
    .line 75
    invoke-virtual {v2, v11}, La03;->O(Lws2;)Lse4;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    if-nez p0, :cond_6

    .line 80
    .line 81
    sget-object p0, Lye0;->T:Lhx4;

    .line 82
    .line 83
    return-object p0

    .line 84
    :cond_6
    instance-of p1, v11, Lzz2;

    .line 85
    .line 86
    const/4 v0, 0x0

    .line 87
    if-eqz p1, :cond_7

    .line 88
    .line 89
    move-object p1, v11

    .line 90
    check-cast p1, Lzz2;

    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_7
    move-object p1, v0

    .line 94
    :goto_1
    if-nez p1, :cond_8

    .line 95
    .line 96
    new-instance p1, Lzz2;

    .line 97
    .line 98
    invoke-direct {p1, p0, v0}, Lzz2;-><init>(Lse4;Ljava/lang/Throwable;)V

    .line 99
    .line 100
    .line 101
    :cond_8
    move-object v12, p1

    .line 102
    monitor-enter v12

    .line 103
    :try_start_0
    invoke-virtual {v12}, Lzz2;->f()Z

    .line 104
    .line 105
    .line 106
    move-result p1

    .line 107
    if-eqz p1, :cond_9

    .line 108
    .line 109
    sget-object p0, Lye0;->R:Lhx4;

    .line 110
    .line 111
    goto :goto_2

    .line 112
    :cond_9
    sget-object p1, Lhw;->a:Lsun/misc/Unsafe;

    .line 113
    .line 114
    sget-wide v3, Lzz2;->k:J

    .line 115
    .line 116
    const/4 v1, 0x1

    .line 117
    invoke-virtual {p1, v12, v3, v4, v1}, Lsun/misc/Unsafe;->putIntVolatile(Ljava/lang/Object;JI)V

    .line 118
    .line 119
    .line 120
    if-eq v12, v11, :cond_b

    .line 121
    .line 122
    :cond_a
    sget-object v7, Lhw;->a:Lsun/misc/Unsafe;

    .line 123
    .line 124
    sget-wide v9, La03;->j:J

    .line 125
    .line 126
    move-object v8, v2

    .line 127
    invoke-virtual/range {v7 .. v12}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result p1

    .line 131
    move-object v2, v8

    .line 132
    if-nez p1, :cond_b

    .line 133
    .line 134
    invoke-virtual {v7, v2, v9, v10}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    if-eq p1, v11, :cond_a

    .line 139
    .line 140
    sget-object p0, Lye0;->T:Lhx4;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 141
    .line 142
    :goto_2
    monitor-exit v12

    .line 143
    return-object p0

    .line 144
    :cond_b
    :try_start_1
    invoke-virtual {v12}, Lzz2;->e()Z

    .line 145
    .line 146
    .line 147
    move-result p1

    .line 148
    instance-of v1, p2, Liy0;

    .line 149
    .line 150
    if-eqz v1, :cond_c

    .line 151
    .line 152
    move-object v1, p2

    .line 153
    check-cast v1, Liy0;

    .line 154
    .line 155
    goto :goto_3

    .line 156
    :cond_c
    move-object v1, v0

    .line 157
    :goto_3
    if-eqz v1, :cond_d

    .line 158
    .line 159
    iget-object v1, v1, Liy0;->a:Ljava/lang/Throwable;

    .line 160
    .line 161
    invoke-virtual {v12, v1}, Lzz2;->a(Ljava/lang/Throwable;)V

    .line 162
    .line 163
    .line 164
    :cond_d
    invoke-virtual {v12}, Lzz2;->c()Ljava/lang/Throwable;

    .line 165
    .line 166
    .line 167
    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 168
    if-nez p1, :cond_e

    .line 169
    .line 170
    move-object v0, v1

    .line 171
    :cond_e
    monitor-exit v12

    .line 172
    if-eqz v0, :cond_f

    .line 173
    .line 174
    invoke-virtual {v2, p0, v0}, La03;->Z(Lse4;Ljava/lang/Throwable;)V

    .line 175
    .line 176
    .line 177
    :cond_f
    invoke-static {p0}, La03;->Y(Lih3;)Lwo0;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    if-eqz p1, :cond_10

    .line 182
    .line 183
    invoke-virtual {v2, v12, p1, p2}, La03;->h0(Lzz2;Lwo0;Ljava/lang/Object;)Z

    .line 184
    .line 185
    .line 186
    move-result p1

    .line 187
    if-eqz p1, :cond_10

    .line 188
    .line 189
    sget-object p0, Lye0;->S:Lhx4;

    .line 190
    .line 191
    return-object p0

    .line 192
    :cond_10
    new-instance p1, Lse3;

    .line 193
    .line 194
    const/4 v0, 0x2

    .line 195
    invoke-direct {p1, v0}, Lse3;-><init>(I)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {p0, p1, v0}, Lih3;->e(Lih3;I)Z

    .line 199
    .line 200
    .line 201
    invoke-static {p0}, La03;->Y(Lih3;)Lwo0;

    .line 202
    .line 203
    .line 204
    move-result-object p0

    .line 205
    if-eqz p0, :cond_11

    .line 206
    .line 207
    invoke-virtual {v2, v12, p0, p2}, La03;->h0(Lzz2;Lwo0;Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move-result p0

    .line 211
    if-eqz p0, :cond_11

    .line 212
    .line 213
    sget-object p0, Lye0;->S:Lhx4;

    .line 214
    .line 215
    return-object p0

    .line 216
    :cond_11
    invoke-virtual {v2, v12, p2}, La03;->K(Lzz2;Ljava/lang/Object;)Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object p0

    .line 220
    return-object p0

    .line 221
    :catchall_0
    move-exception v0

    .line 222
    move-object p0, v0

    .line 223
    monitor-exit v12

    .line 224
    throw p0
.end method

.method public final getKey()Lec1;
    .locals 0

    .line 1
    sget-object p0, Ld42;->o:Ld42;

    .line 2
    .line 3
    return-object p0
.end method

.method public final h0(Lzz2;Lwo0;Ljava/lang/Object;)Z
    .locals 3

    .line 1
    :cond_0
    iget-object v0, p2, Lwo0;->m:La03;

    .line 2
    .line 3
    new-instance v1, Lyz2;

    .line 4
    .line 5
    invoke-direct {v1, p0, p1, p2, p3}, Lyz2;-><init>(La03;Lzz2;Lwo0;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-static {v0, v2, v1}, Lqm;->I(Ltz2;ZLwz2;)Ltl1;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sget-object v1, Lye4;->i:Lye4;

    .line 14
    .line 15
    if-eq v0, v1, :cond_1

    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    return p0

    .line 19
    :cond_1
    invoke-static {p2}, La03;->Y(Lih3;)Lwo0;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    if-nez p2, :cond_0

    .line 24
    .line 25
    return v2
.end method

.method public final j(La03;)Lvo0;
    .locals 6

    .line 1
    new-instance v5, Lwo0;

    .line 2
    .line 3
    invoke-direct {v5, p1}, Lwo0;-><init>(La03;)V

    .line 4
    .line 5
    .line 6
    iput-object p0, v5, Lwz2;->l:La03;

    .line 7
    .line 8
    :goto_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    instance-of p1, v4, Lav1;

    .line 13
    .line 14
    if-eqz p1, :cond_1

    .line 15
    .line 16
    move-object p1, v4

    .line 17
    check-cast p1, Lav1;

    .line 18
    .line 19
    iget-boolean v0, p1, Lav1;->i:Z

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    :goto_1
    sget-object v0, Lhw;->a:Lsun/misc/Unsafe;

    .line 24
    .line 25
    sget-wide v2, La03;->j:J

    .line 26
    .line 27
    move-object v1, p0

    .line 28
    invoke-virtual/range {v0 .. v5}, Lsun/misc/Unsafe;->compareAndSwapObject(Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p0

    .line 32
    if-nez p0, :cond_7

    .line 33
    .line 34
    invoke-virtual {v0, v1, v2, v3}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    if-ne p0, v4, :cond_2

    .line 39
    .line 40
    move-object p0, v1

    .line 41
    goto :goto_1

    .line 42
    :cond_0
    move-object v1, p0

    .line 43
    invoke-virtual {v1, p1}, La03;->c0(Lav1;)V

    .line 44
    .line 45
    .line 46
    goto :goto_2

    .line 47
    :cond_1
    move-object v1, p0

    .line 48
    instance-of p0, v4, Lws2;

    .line 49
    .line 50
    sget-object p1, Lye4;->i:Lye4;

    .line 51
    .line 52
    const/4 v0, 0x0

    .line 53
    if-eqz p0, :cond_9

    .line 54
    .line 55
    move-object p0, v4

    .line 56
    check-cast p0, Lws2;

    .line 57
    .line 58
    invoke-interface {p0}, Lws2;->d()Lse4;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    if-nez p0, :cond_3

    .line 63
    .line 64
    check-cast v4, Lwz2;

    .line 65
    .line 66
    invoke-virtual {v1, v4}, La03;->d0(Lwz2;)V

    .line 67
    .line 68
    .line 69
    :cond_2
    :goto_2
    move-object p0, v1

    .line 70
    goto :goto_0

    .line 71
    :cond_3
    const/4 v2, 0x7

    .line 72
    invoke-virtual {p0, v5, v2}, Lih3;->e(Lih3;I)Z

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    if-nez v2, :cond_7

    .line 77
    .line 78
    const/4 v2, 0x3

    .line 79
    invoke-virtual {p0, v5, v2}, Lih3;->e(Lih3;I)Z

    .line 80
    .line 81
    .line 82
    move-result p0

    .line 83
    invoke-virtual {v1}, La03;->P()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    instance-of v2, v1, Lzz2;

    .line 88
    .line 89
    if-eqz v2, :cond_4

    .line 90
    .line 91
    check-cast v1, Lzz2;

    .line 92
    .line 93
    invoke-virtual {v1}, Lzz2;->c()Ljava/lang/Throwable;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    goto :goto_4

    .line 98
    :cond_4
    instance-of v2, v1, Liy0;

    .line 99
    .line 100
    if-eqz v2, :cond_5

    .line 101
    .line 102
    check-cast v1, Liy0;

    .line 103
    .line 104
    goto :goto_3

    .line 105
    :cond_5
    move-object v1, v0

    .line 106
    :goto_3
    if-eqz v1, :cond_6

    .line 107
    .line 108
    iget-object v0, v1, Liy0;->a:Ljava/lang/Throwable;

    .line 109
    .line 110
    :cond_6
    :goto_4
    invoke-virtual {v5, v0}, Lwo0;->n(Ljava/lang/Throwable;)V

    .line 111
    .line 112
    .line 113
    if-eqz p0, :cond_8

    .line 114
    .line 115
    :cond_7
    return-object v5

    .line 116
    :cond_8
    return-object p1

    .line 117
    :cond_9
    invoke-virtual {v1}, La03;->P()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    instance-of v1, p0, Liy0;

    .line 122
    .line 123
    if-eqz v1, :cond_a

    .line 124
    .line 125
    check-cast p0, Liy0;

    .line 126
    .line 127
    goto :goto_5

    .line 128
    :cond_a
    move-object p0, v0

    .line 129
    :goto_5
    if-eqz p0, :cond_b

    .line 130
    .line 131
    iget-object v0, p0, Liy0;->a:Ljava/lang/Throwable;

    .line 132
    .line 133
    :cond_b
    invoke-virtual {v5, v0}, Lwo0;->n(Ljava/lang/Throwable;)V

    .line 134
    .line 135
    .line 136
    return-object p1
.end method

.method public final k(Lfc1;)Lfc1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lxl;->S(Ldc1;Lfc1;)Lfc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final p(Lec1;)Ldc1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lxl;->G(Ldc1;Lec1;)Ldc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final start()Z
    .locals 2

    .line 1
    :cond_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, v0}, La03;->e0(Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    if-ne v0, v1, :cond_0

    .line 13
    .line 14
    return v1

    .line 15
    :cond_1
    const/4 p0, 0x0

    .line 16
    return p0
.end method

.method public final t(ZZLs61;)Ltl1;
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    new-instance p1, Lvy2;

    .line 4
    .line 5
    invoke-direct {p1, p3}, Lvy2;-><init>(Ls61;)V

    .line 6
    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    new-instance p1, Lwy2;

    .line 10
    .line 11
    invoke-direct {p1, p3}, Lwy2;-><init>(Lp72;)V

    .line 12
    .line 13
    .line 14
    :goto_0
    invoke-virtual {p0, p2, p1}, La03;->T(ZLwz2;)Ltl1;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    invoke-virtual {p0}, La03;->X()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const/16 v2, 0x7b

    .line 13
    .line 14
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-static {v2}, La03;->f0(Ljava/lang/Object;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    const/16 v2, 0x7d

    .line 29
    .line 30
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    const/16 v1, 0x40

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-static {p0}, Ljf1;->D(Ljava/lang/Object;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    return-object p0
.end method

.method public final u()Ljava/util/concurrent/CancellationException;
    .locals 4

    .line 1
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Lzz2;

    .line 6
    .line 7
    const-string v2, "Job is still new or active: "

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    if-eqz v1, :cond_3

    .line 11
    .line 12
    check-cast v0, Lzz2;

    .line 13
    .line 14
    invoke-virtual {v0}, Lzz2;->c()Ljava/lang/Throwable;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-eqz v0, :cond_2

    .line 19
    .line 20
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    const-string v2, " is cancelling"

    .line 29
    .line 30
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    .line 35
    .line 36
    if-eqz v2, :cond_0

    .line 37
    .line 38
    move-object v3, v0

    .line 39
    check-cast v3, Ljava/util/concurrent/CancellationException;

    .line 40
    .line 41
    :cond_0
    if-nez v3, :cond_1

    .line 42
    .line 43
    new-instance v2, Luz2;

    .line 44
    .line 45
    invoke-direct {v2, v1, v0, p0}, Luz2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;La03;)V

    .line 46
    .line 47
    .line 48
    return-object v2

    .line 49
    :cond_1
    return-object v3

    .line 50
    :cond_2
    invoke-static {v2, p0}, Lnf1;->h(Ljava/lang/String;Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-object v3

    .line 54
    :cond_3
    instance-of v1, v0, Lws2;

    .line 55
    .line 56
    if-nez v1, :cond_7

    .line 57
    .line 58
    instance-of v1, v0, Liy0;

    .line 59
    .line 60
    if-eqz v1, :cond_6

    .line 61
    .line 62
    check-cast v0, Liy0;

    .line 63
    .line 64
    iget-object v0, v0, Liy0;->a:Ljava/lang/Throwable;

    .line 65
    .line 66
    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    .line 67
    .line 68
    if-eqz v1, :cond_4

    .line 69
    .line 70
    move-object v3, v0

    .line 71
    check-cast v3, Ljava/util/concurrent/CancellationException;

    .line 72
    .line 73
    :cond_4
    if-nez v3, :cond_5

    .line 74
    .line 75
    new-instance v1, Luz2;

    .line 76
    .line 77
    invoke-virtual {p0}, La03;->G()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    invoke-direct {v1, v2, v0, p0}, Luz2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;La03;)V

    .line 82
    .line 83
    .line 84
    return-object v1

    .line 85
    :cond_5
    return-object v3

    .line 86
    :cond_6
    new-instance v0, Luz2;

    .line 87
    .line 88
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    const-string v2, " has completed normally"

    .line 97
    .line 98
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    invoke-direct {v0, v1, v3, p0}, Luz2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;La03;)V

    .line 103
    .line 104
    .line 105
    return-object v0

    .line 106
    :cond_7
    invoke-static {v2, p0}, Lnf1;->h(Ljava/lang/String;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    return-object v3
.end method

.method public v(Ljava/lang/Object;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final w(Lt72;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, Lt72;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public x(Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, La03;->v(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final y(Lp72;)Ltl1;
    .locals 1

    .line 1
    new-instance v0, Lwy2;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Lwy2;-><init>(Lp72;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    invoke-virtual {p0, p1, v0}, La03;->T(ZLwz2;)Ltl1;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public final z(Lp91;)Ljava/lang/Object;
    .locals 2

    .line 1
    :cond_0
    invoke-virtual {p0}, La03;->P()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Lws2;

    .line 6
    .line 7
    if-nez v1, :cond_2

    .line 8
    .line 9
    instance-of p0, v0, Liy0;

    .line 10
    .line 11
    if-nez p0, :cond_1

    .line 12
    .line 13
    invoke-static {v0}, Lye0;->Y(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0

    .line 18
    :cond_1
    check-cast v0, Liy0;

    .line 19
    .line 20
    iget-object p0, v0, Liy0;->a:Ljava/lang/Throwable;

    .line 21
    .line 22
    throw p0

    .line 23
    :cond_2
    invoke-virtual {p0, v0}, La03;->e0(Ljava/lang/Object;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-ltz v0, :cond_0

    .line 28
    .line 29
    new-instance v0, Lxz2;

    .line 30
    .line 31
    invoke-static {p1}, Lul;->I(Lp91;)Lp91;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-direct {v0, p1, p0}, Lxz2;-><init>(Lp91;La03;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Lri0;->t()V

    .line 39
    .line 40
    .line 41
    new-instance p1, Lvi5;

    .line 42
    .line 43
    invoke-direct {p1, v0}, Lvi5;-><init>(Lxz2;)V

    .line 44
    .line 45
    .line 46
    const/4 v1, 0x1

    .line 47
    invoke-static {p0, v1, p1}, Lqm;->I(Ltz2;ZLwz2;)Ltl1;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    new-instance p1, Lmi0;

    .line 52
    .line 53
    invoke-direct {p1, p0, v1}, Lmi0;-><init>(Ljava/lang/Object;B)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0, p1}, Lri0;->w(Lff4;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0}, Lri0;->q()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    return-object p0
.end method
