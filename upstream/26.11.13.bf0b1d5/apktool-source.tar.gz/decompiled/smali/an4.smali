.class public final synthetic Lan4;
.super Ljava/lang/Object;
.source "r8-map-id-bd0caf1bc4f5f32ccbf6362d02e487e5aa57647e3e4f9baa433c9379167097a7"

# interfaces
.implements Lt72;


# instance fields
.field public final synthetic i:Z

.field public final synthetic j:Ljava/util/List;

.field public final synthetic k:Le72;

.field public final synthetic l:Lyu3;

.field public final synthetic m:Lsw3;

.field public final synthetic n:Le72;

.field public final synthetic o:Lbz4;

.field public final synthetic p:Laz4;

.field public final synthetic q:Z

.field public final synthetic r:F

.field public final synthetic s:Z

.field public final synthetic t:Laq1;

.field public final synthetic u:Z

.field public final synthetic v:I

.field public final synthetic w:I


# direct methods
.method public synthetic constructor <init>(ZLjava/util/List;Le72;Lyu3;Lsw3;Le72;Lbz4;Laz4;ZFZLaq1;ZII)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lan4;->i:Z

    .line 5
    .line 6
    iput-object p2, p0, Lan4;->j:Ljava/util/List;

    .line 7
    .line 8
    iput-object p3, p0, Lan4;->k:Le72;

    .line 9
    .line 10
    iput-object p4, p0, Lan4;->l:Lyu3;

    .line 11
    .line 12
    iput-object p5, p0, Lan4;->m:Lsw3;

    .line 13
    .line 14
    iput-object p6, p0, Lan4;->n:Le72;

    .line 15
    .line 16
    iput-object p7, p0, Lan4;->o:Lbz4;

    .line 17
    .line 18
    iput-object p8, p0, Lan4;->p:Laz4;

    .line 19
    .line 20
    iput-boolean p9, p0, Lan4;->q:Z

    .line 21
    .line 22
    iput p10, p0, Lan4;->r:F

    .line 23
    .line 24
    iput-boolean p11, p0, Lan4;->s:Z

    .line 25
    .line 26
    iput-object p12, p0, Lan4;->t:Laq1;

    .line 27
    .line 28
    iput-boolean p13, p0, Lan4;->u:Z

    .line 29
    .line 30
    iput p14, p0, Lan4;->v:I

    .line 31
    .line 32
    iput p15, p0, Lan4;->w:I

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v13, p1

    .line 4
    .line 5
    check-cast v13, Lt82;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget v1, v0, Lan4;->v:I

    .line 15
    .line 16
    or-int/lit8 v1, v1, 0x1

    .line 17
    .line 18
    invoke-static {v1}, Lp06;->W(I)I

    .line 19
    .line 20
    .line 21
    move-result v14

    .line 22
    iget v1, v0, Lan4;->w:I

    .line 23
    .line 24
    invoke-static {v1}, Lp06;->W(I)I

    .line 25
    .line 26
    .line 27
    move-result v15

    .line 28
    iget-boolean v1, v0, Lan4;->i:Z

    .line 29
    .line 30
    move v2, v1

    .line 31
    iget-object v1, v0, Lan4;->j:Ljava/util/List;

    .line 32
    .line 33
    move v3, v2

    .line 34
    iget-object v2, v0, Lan4;->k:Le72;

    .line 35
    .line 36
    move v4, v3

    .line 37
    iget-object v3, v0, Lan4;->l:Lyu3;

    .line 38
    .line 39
    move v5, v4

    .line 40
    iget-object v4, v0, Lan4;->m:Lsw3;

    .line 41
    .line 42
    move v6, v5

    .line 43
    iget-object v5, v0, Lan4;->n:Le72;

    .line 44
    .line 45
    move v7, v6

    .line 46
    iget-object v6, v0, Lan4;->o:Lbz4;

    .line 47
    .line 48
    move v8, v7

    .line 49
    iget-object v7, v0, Lan4;->p:Laz4;

    .line 50
    .line 51
    move v9, v8

    .line 52
    iget-boolean v8, v0, Lan4;->q:Z

    .line 53
    .line 54
    move v10, v9

    .line 55
    iget v9, v0, Lan4;->r:F

    .line 56
    .line 57
    move v11, v10

    .line 58
    iget-boolean v10, v0, Lan4;->s:Z

    .line 59
    .line 60
    move v12, v11

    .line 61
    iget-object v11, v0, Lan4;->t:Laq1;

    .line 62
    .line 63
    iget-boolean v0, v0, Lan4;->u:Z

    .line 64
    .line 65
    move/from16 v16, v12

    .line 66
    .line 67
    move v12, v0

    .line 68
    move/from16 v0, v16

    .line 69
    .line 70
    invoke-static/range {v0 .. v15}, Lga3;->d(ZLjava/util/List;Le72;Lyu3;Lsw3;Le72;Lbz4;Laz4;ZFZLaq1;ZLt82;II)V

    .line 71
    .line 72
    .line 73
    sget-object v0, Ll97;->a:Ll97;

    .line 74
    .line 75
    return-object v0
.end method
