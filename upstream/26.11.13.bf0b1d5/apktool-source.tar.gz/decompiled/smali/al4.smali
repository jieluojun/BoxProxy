.class public interface abstract Lal4;
.super Ljava/lang/Object;
.source "r8-map-id-bd0caf1bc4f5f32ccbf6362d02e487e5aa57647e3e4f9baa433c9379167097a7"


# virtual methods
.method public abstract d(Ljava/lang/Integer;)Ljava/util/List;
.end method

.method public abstract g()Z
.end method
