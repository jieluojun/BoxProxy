.class public final Lcom/box/app/AppApplication;
.super Landroid/app/Application;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static volatile i:Landroid/content/Context;

.field public static final j:Lzq6;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lfm;

    .line 2
    .line 3
    const/16 v1, 0x14

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lfm;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lzq6;

    .line 9
    .line 10
    invoke-direct {v1, v0}, Lzq6;-><init>(Lw82;)V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lcom/box/app/AppApplication;->j:Lzq6;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static a(Lh27;Ljava/lang/String;Z)V
    .locals 2

    .line 1
    const-string v0, "textmate/"

    .line 2
    .line 3
    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v0, ".json"

    .line 12
    .line 13
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {}, Lk12;->u()Lk12;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v1, v0}, Lk12;->G(Ljava/lang/String;)Ljava/io/InputStream;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    if-eqz v1, :cond_0

    .line 29
    .line 30
    invoke-static {v1, v0}, Lcu2;->a(Ljava/io/InputStream;Ljava/lang/String;)Lht2;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    new-instance v1, Lio/github/rosemoe/sora/langs/textmate/registry/model/ThemeModel;

    .line 35
    .line 36
    invoke-direct {v1, v0, p1}, Lio/github/rosemoe/sora/langs/textmate/registry/model/ThemeModel;-><init>(Lcu2;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1, p2}, Lio/github/rosemoe/sora/langs/textmate/registry/model/ThemeModel;->setDark(Z)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p0, v1}, Lh27;->K(Lio/github/rosemoe/sora/langs/textmate/registry/model/ThemeModel;)V

    .line 43
    .line 44
    .line 45
    sget-object p0, Loc7;->a:Loc7;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :catchall_0
    move-exception p0

    .line 49
    new-instance p2, Lcm5;

    .line 50
    .line 51
    invoke-direct {p2, p0}, Lcm5;-><init>(Ljava/lang/Throwable;)V

    .line 52
    .line 53
    .line 54
    move-object p0, p2

    .line 55
    :goto_0
    invoke-static {p0}, Ldm5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 56
    .line 57
    .line 58
    move-result-object p0

    .line 59
    if-eqz p0, :cond_0

    .line 60
    .line 61
    const-string p2, "Failed to load TextMate theme: "

    .line 62
    .line 63
    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    const-string p2, "BoxAppTextMate"

    .line 68
    .line 69
    invoke-static {p2, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 70
    .line 71
    .line 72
    :cond_0
    return-void
.end method


# virtual methods
.method public final onCreate()V
    .locals 6

    .line 1
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    sput-object v0, Lcom/box/app/AppApplication;->i:Landroid/content/Context;
    invoke-static {}, Lcom/box/app/vpn/VpnPrefs;->processStart()V
    invoke-static {p0}, Lcom/box/app/vpn/FToast;->init(Landroid/app/Application;)V

    .line 12
    .line 13
    new-instance v0, Lkn;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-direct {v0, v1}, Lkn;-><init>(B)V

    .line 17
    .line 18
    .line 19
    sget-object v2, Lre6;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 20
    .line 21
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    instance-of v4, v3, Lpu2;

    .line 26
    .line 27
    if-eqz v4, :cond_0

    .line 28
    .line 29
    check-cast v3, Lpu2;

    .line 30
    .line 31
    sget-object v0, Lse6;->a:Lkn;

    .line 32
    .line 33
    check-cast v3, Lai5;

    .line 34
    .line 35
    iget-object v0, v3, Lai5;->a:Lxh5;

    .line 36
    .line 37
    iget-object v0, v0, Lxh5;->b:Ltu2;

    .line 38
    .line 39
    iget-object v0, v0, Ltu2;->e:Lr02;

    .line 40
    .line 41
    sget-object v2, Lse6;->b:Lq02;

    .line 42
    .line 43
    iget-object v0, v0, Lr02;->a:Ljava/util/Map;

    .line 44
    .line 45
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    if-eqz v0, :cond_1

    .line 50
    .line 51
    const-string p0, "The singleton image loader has already been created. This indicates that \'setSafe\' is being called after the first \'get\' call. Ensure that \'setSafe\' is called before any Coil API usages (e.g. `load`, `AsyncImage`, `rememberAsyncImagePainter`, etc.)."

    .line 52
    .line 53
    invoke-static {p0}, Lzy1;->d(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :cond_0
    invoke-virtual {v2, v3, v0}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v4

    .line 61
    if-nez v4, :cond_1

    .line 62
    .line 63
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v4

    .line 67
    if-eq v4, v3, :cond_0

    .line 68
    .line 69
    :cond_1
    sget-object v0, Lbc6;->r:Ljava/util/concurrent/ExecutorService;

    .line 70
    .line 71
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    :goto_0
    instance-of v2, v0, Landroid/content/ContextWrapper;

    .line 76
    .line 77
    if-eqz v2, :cond_2

    .line 78
    .line 79
    check-cast v0, Landroid/content/ContextWrapper;

    .line 80
    .line 81
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    goto :goto_0

    .line 86
    :cond_2
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    if-eqz v2, :cond_3

    .line 91
    .line 92
    move-object v0, v2

    .line 93
    :cond_3
    :goto_1
    instance-of v2, v0, Landroid/content/ContextWrapper;

    .line 94
    .line 95
    if-eqz v2, :cond_4

    .line 96
    .line 97
    check-cast v0, Landroid/content/ContextWrapper;

    .line 98
    .line 99
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    goto :goto_1

    .line 104
    :cond_4
    const-class v4, Lnn3;

    .line 105
    .line 106
    monitor-enter v4

    .line 107
    :try_start_0
    sget-object v0, Lnn3;->a:[Lbc6;

    .line 108
    .line 109
    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 110
    :try_start_1
    aget-object v2, v0, v1

    .line 111
    .line 112
    const/4 v3, 0x0

    .line 113
    if-eqz v2, :cond_5

    .line 114
    .line 115
    iget v5, v2, Lbc6;->i:I

    .line 116
    .line 117
    if-gez v5, :cond_5

    .line 118
    .line 119
    aput-object v3, v0, v1

    .line 120
    .line 121
    move-object v2, v3

    .line 122
    :cond_5
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 123
    if-nez v2, :cond_7

    .line 124
    .line 125
    monitor-exit v4

    .line 126
    invoke-static {}, Landroid/app/Application;->getProcessName()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    invoke-static {v0, v2}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-nez v0, :cond_6

    .line 139
    .line 140
    return-void

    .line 141
    :cond_6
    sget-object v0, Lqr;->a:Laa1;

    .line 142
    .line 143
    new-instance v2, Lmn;

    .line 144
    .line 145
    invoke-direct {v2, p0, v3, v1}, Lmn;-><init>(Ljava/lang/Object;Lca1;B)V

    .line 146
    .line 147
    .line 148
    const/4 p0, 0x3

    .line 149
    invoke-static {v0, v3, v3, v2, p0}, Llm;->Z(Lhe1;Lb3;Lke1;Ll92;I)Lek6;

    .line 150
    .line 151
    .line 152
    return-void

    .line 153
    :cond_7
    :try_start_2
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 154
    .line 155
    const-string v0, "The main shell was already created"

    .line 156
    .line 157
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 161
    :goto_2
    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 162
    :try_start_4
    throw p0

    .line 163
    :catchall_0
    move-exception p0

    .line 164
    goto :goto_2

    .line 165
    :goto_3
    monitor-exit v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 166
    throw p0

    .line 167
    :catchall_1
    move-exception p0

    .line 168
    goto :goto_3
.end method
