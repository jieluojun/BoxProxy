.class public final Ly92;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lyw5;

.field public final b:Lgx;

.field public final c:Ljava/util/ArrayList;

.field public final d:Lgx;

.field public e:Landroid/graphics/Bitmap;

.field public f:Landroid/graphics/Bitmap;

.field public g:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>(Lyw5;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ly92;->a:Lyw5;

    .line 5
    .line 6
    new-instance p1, Lgx;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p1, v0}, Ltr6;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Ly92;->b:Lgx;

    .line 13
    .line 14
    new-instance p1, Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Ly92;->c:Ljava/util/ArrayList;

    .line 20
    .line 21
    new-instance p1, Lgx;

    .line 22
    .line 23
    invoke-direct {p1, v0}, Ltr6;-><init>(I)V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, Ly92;->d:Lgx;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 3

    .line 1
    iget-object v0, p0, Ly92;->b:Lgx;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ltr6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Landroid/graphics/Bitmap;

    .line 8
    .line 9
    if-nez v1, :cond_4

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const v2, -0x2a4da31a

    .line 16
    .line 17
    .line 18
    if-eq v1, v2, :cond_1

    .line 19
    .line 20
    const v2, 0x34132c7b

    .line 21
    .line 22
    .line 23
    if-eq v1, v2, :cond_0

    .line 24
    .line 25
    const v2, 0x5cb3d9e3

    .line 26
    .line 27
    .line 28
    if-ne v1, v2, :cond_2

    .line 29
    .line 30
    const-string v1, "SourceAlpha"

    .line 31
    .line 32
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    if-eqz p1, :cond_2

    .line 37
    .line 38
    iget-object p1, p0, Ly92;->e:Landroid/graphics/Bitmap;

    .line 39
    .line 40
    if-eqz p1, :cond_2

    .line 41
    .line 42
    iget-object p0, p0, Ly92;->a:Lyw5;

    .line 43
    .line 44
    invoke-static {p0, p1}, Ll40;->b(Lyw5;Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    invoke-virtual {v0, v1, p0}, Ltr6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    return-object p0

    .line 52
    :cond_0
    const-string v0, "FillPaint"

    .line 53
    .line 54
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    if-eqz p1, :cond_2

    .line 59
    .line 60
    iget-object p0, p0, Ly92;->f:Landroid/graphics/Bitmap;

    .line 61
    .line 62
    return-object p0

    .line 63
    :cond_1
    const-string v0, "StrokePaint"

    .line 64
    .line 65
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    if-nez p1, :cond_3

    .line 70
    .line 71
    :cond_2
    const/4 p0, 0x0

    .line 72
    return-object p0

    .line 73
    :cond_3
    iget-object p0, p0, Ly92;->g:Landroid/graphics/Bitmap;

    .line 74
    .line 75
    return-object p0

    .line 76
    :cond_4
    return-object v1
.end method

.method public final b(Landroid/graphics/Bitmap;)V
    .locals 7

    .line 1
    iget-object v0, p0, Ly92;->a:Lyw5;

    .line 2
    .line 3
    iget-object v0, v0, Lyw5;->h:Lfr;

    .line 4
    .line 5
    iget-object v0, v0, Lfr;->l:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Lor;

    .line 8
    .line 9
    iget-object v1, p0, Ly92;->b:Lgx;

    .line 10
    .line 11
    iget v2, v1, Ltr6;->j:I

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    move v4, v3

    .line 15
    :goto_0
    if-ge v4, v2, :cond_1

    .line 16
    .line 17
    invoke-virtual {v1, v4}, Ltr6;->h(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    check-cast v5, Landroid/graphics/Bitmap;

    .line 22
    .line 23
    if-eq v5, p1, :cond_0

    .line 24
    .line 25
    iget-object v6, p0, Ly92;->e:Landroid/graphics/Bitmap;

    .line 26
    .line 27
    if-eq v5, v6, :cond_0

    .line 28
    .line 29
    iget-object v6, p0, Ly92;->f:Landroid/graphics/Bitmap;

    .line 30
    .line 31
    if-eq v5, v6, :cond_0

    .line 32
    .line 33
    iget-object v6, p0, Ly92;->g:Landroid/graphics/Bitmap;

    .line 34
    .line 35
    if-eq v5, v6, :cond_0

    .line 36
    .line 37
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0, v5}, Lor;->E(Landroid/graphics/Bitmap;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    iget v2, v1, Ltr6;->j:I

    .line 47
    .line 48
    move v4, v3

    .line 49
    :goto_1
    if-ge v4, v2, :cond_2

    .line 50
    .line 51
    invoke-virtual {v1, v4}, Ltr6;->e(I)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    check-cast v5, Ljava/lang/String;

    .line 56
    .line 57
    const/4 v6, 0x0

    .line 58
    invoke-virtual {v1, v5, v6}, Ltr6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    add-int/lit8 v4, v4, 0x1

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    iget-object v1, p0, Ly92;->d:Lgx;

    .line 65
    .line 66
    invoke-virtual {v1}, Ltr6;->clear()V

    .line 67
    .line 68
    .line 69
    iget-object p0, p0, Ly92;->c:Ljava/util/ArrayList;

    .line 70
    .line 71
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    :goto_2
    if-ge v3, v1, :cond_4

    .line 76
    .line 77
    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    check-cast v2, Landroid/graphics/Bitmap;

    .line 82
    .line 83
    if-eq v2, p1, :cond_3

    .line 84
    .line 85
    invoke-virtual {v0, v2}, Lor;->E(Landroid/graphics/Bitmap;)V

    .line 86
    .line 87
    .line 88
    :cond_3
    add-int/lit8 v3, v3, 0x1

    .line 89
    .line 90
    goto :goto_2

    .line 91
    :cond_4
    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    .line 92
    .line 93
    .line 94
    return-void
.end method
