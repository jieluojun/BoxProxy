.class public abstract Lqh4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lcx1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ln94;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ln94;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lcx1;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Lqh4;->a:Lcx1;

    .line 15
    .line 16
    return-void
.end method

.method public static final a(Lha4;JZZLhh4;Lq21;Lki2;I)V
    .locals 19

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-wide/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v7, p7

    .line 6
    .line 7
    const v0, 0x445cf7ab

    .line 8
    .line 9
    .line 10
    invoke-virtual {v7, v0}, Lki2;->i0(I)Lki2;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v7, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const/4 v0, 0x4

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v0, 0x2

    .line 22
    :goto_0
    or-int v0, p8, v0

    .line 23
    .line 24
    invoke-virtual {v7, v2, v3}, Lki2;->f(J)Z

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    const/16 v11, 0x20

    .line 29
    .line 30
    if-eqz v4, :cond_1

    .line 31
    .line 32
    move v4, v11

    .line 33
    goto :goto_1

    .line 34
    :cond_1
    const/16 v4, 0x10

    .line 35
    .line 36
    :goto_1
    or-int/2addr v0, v4

    .line 37
    or-int/lit16 v0, v0, 0x6d80

    .line 38
    .line 39
    const v4, 0x12493

    .line 40
    .line 41
    .line 42
    and-int/2addr v4, v0

    .line 43
    const v5, 0x12492

    .line 44
    .line 45
    .line 46
    const/4 v12, 0x0

    .line 47
    const/4 v13, 0x1

    .line 48
    if-eq v4, v5, :cond_2

    .line 49
    .line 50
    move v4, v13

    .line 51
    goto :goto_2

    .line 52
    :cond_2
    move v4, v12

    .line 53
    :goto_2
    and-int/2addr v0, v13

    .line 54
    invoke-virtual {v7, v0, v4}, Lki2;->Y(IZ)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_d

    .line 59
    .line 60
    invoke-virtual {v7}, Lki2;->d0()V

    .line 61
    .line 62
    .line 63
    and-int/lit8 v0, p8, 0x1

    .line 64
    .line 65
    if-eqz v0, :cond_3

    .line 66
    .line 67
    invoke-virtual {v7}, Lki2;->D()Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-nez v0, :cond_3

    .line 72
    .line 73
    invoke-virtual {v7}, Lki2;->b0()V

    .line 74
    .line 75
    .line 76
    move/from16 v0, p3

    .line 77
    .line 78
    move/from16 v14, p4

    .line 79
    .line 80
    move-object/from16 v15, p5

    .line 81
    .line 82
    goto :goto_3

    .line 83
    :cond_3
    sget-object v0, Lhh4;->h:Lhh4;

    .line 84
    .line 85
    move-object v15, v0

    .line 86
    move v0, v13

    .line 87
    move v14, v0

    .line 88
    :goto_3
    invoke-virtual {v7}, Lki2;->s()V

    .line 89
    .line 90
    .line 91
    sget-object v4, La28;->w:Ljava/util/WeakHashMap;

    .line 92
    .line 93
    invoke-static {v7}, Lzi6;->i(Lki2;)La28;

    .line 94
    .line 95
    .line 96
    move-result-object v4

    .line 97
    iget-object v4, v4, La28;->a:Lpg;

    .line 98
    .line 99
    new-instance v5, Lro3;

    .line 100
    .line 101
    invoke-direct {v5, v4, v11}, Lro3;-><init>(Lt08;I)V

    .line 102
    .line 103
    .line 104
    invoke-static {v5, v7}, Lxp7;->m(Lt08;Lki2;)Lq83;

    .line 105
    .line 106
    .line 107
    move-result-object v4

    .line 108
    invoke-virtual {v4}, Lq83;->c()F

    .line 109
    .line 110
    .line 111
    move-result v4

    .line 112
    const/4 v5, 0x0

    .line 113
    invoke-static {v4, v5}, Lws1;->a(FF)I

    .line 114
    .line 115
    .line 116
    move-result v6

    .line 117
    if-gtz v6, :cond_4

    .line 118
    .line 119
    move v4, v5

    .line 120
    :cond_4
    const/16 v6, 0x12c

    .line 121
    .line 122
    const/4 v8, 0x0

    .line 123
    const/4 v9, 0x6

    .line 124
    invoke-static {v6, v12, v8, v9}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 125
    .line 126
    .line 127
    move-result-object v6

    .line 128
    move-object v9, v8

    .line 129
    const/16 v8, 0x30

    .line 130
    .line 131
    move-object/from16 v16, v9

    .line 132
    .line 133
    const/16 v9, 0xc

    .line 134
    .line 135
    move/from16 v17, v5

    .line 136
    .line 137
    move-object v5, v6

    .line 138
    const/4 v6, 0x0

    .line 139
    move-object/from16 v11, v16

    .line 140
    .line 141
    move/from16 v10, v17

    .line 142
    .line 143
    invoke-static/range {v4 .. v9}, Lwg;->a(FLca2;Ljava/lang/String;Lki2;II)Lvg;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    const/high16 v5, 0x3f800000    # 1.0f

    .line 148
    .line 149
    invoke-static {v1, v5}, Lit6;->e(Lha4;F)Lha4;

    .line 150
    .line 151
    .line 152
    move-result-object v6

    .line 153
    sget-object v8, Lnl1;->p0:Lc13;

    .line 154
    .line 155
    invoke-static {v6, v2, v3, v8}, Lf48;->t(Lha4;JLkn6;)Lha4;

    .line 156
    .line 157
    .line 158
    move-result-object v6

    .line 159
    sget-object v8, Lx87;->e:Lsw;

    .line 160
    .line 161
    sget-object v9, Ly6;->v:Ly30;

    .line 162
    .line 163
    invoke-static {v8, v9, v7, v12}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 164
    .line 165
    .line 166
    move-result-object v8

    .line 167
    move/from16 p3, v14

    .line 168
    .line 169
    iget-wide v13, v7, Lki2;->U:J

    .line 170
    .line 171
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 172
    .line 173
    .line 174
    move-result v13

    .line 175
    invoke-virtual {v7}, Lki2;->m()Lr95;

    .line 176
    .line 177
    .line 178
    move-result-object v14

    .line 179
    invoke-static {v7, v6}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 180
    .line 181
    .line 182
    move-result-object v6

    .line 183
    sget-object v17, Lp41;->d:Ly6;

    .line 184
    .line 185
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 186
    .line 187
    .line 188
    invoke-virtual {v7}, Lki2;->k0()V

    .line 189
    .line 190
    .line 191
    iget-boolean v9, v7, Lki2;->T:Z

    .line 192
    .line 193
    sget-object v5, Lwi3;->Z:Lj43;

    .line 194
    .line 195
    if-eqz v9, :cond_5

    .line 196
    .line 197
    invoke-virtual {v7, v5}, Lki2;->l(Lwg2;)V

    .line 198
    .line 199
    .line 200
    goto :goto_4

    .line 201
    :cond_5
    invoke-virtual {v7}, Lki2;->t0()V

    .line 202
    .line 203
    .line 204
    :goto_4
    sget-object v9, Ly6;->T:Lu31;

    .line 205
    .line 206
    invoke-static {v9, v7, v8}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    sget-object v8, Ly6;->S:Lu31;

    .line 210
    .line 211
    invoke-static {v8, v7, v14}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 215
    .line 216
    .line 217
    move-result-object v13

    .line 218
    sget-object v14, Ly6;->U:Lu31;

    .line 219
    .line 220
    invoke-static {v14, v7, v13}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 221
    .line 222
    .line 223
    invoke-static {v7}, Lml6;->p(Lki2;)V

    .line 224
    .line 225
    .line 226
    sget-object v13, Ly6;->R:Lu31;

    .line 227
    .line 228
    invoke-static {v13, v7, v6}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    if-eqz v0, :cond_6

    .line 232
    .line 233
    const v6, -0x532fd9be

    .line 234
    .line 235
    .line 236
    invoke-virtual {v7, v6}, Lki2;->h0(I)V

    .line 237
    .line 238
    .line 239
    const/4 v6, 0x7

    .line 240
    invoke-static {v11, v10, v7, v12, v6}, Ldj;->v(Lha4;FLki2;II)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v7, v12}, Lki2;->r(Z)V

    .line 244
    .line 245
    .line 246
    goto :goto_5

    .line 247
    :cond_6
    const v6, -0x532f3853

    .line 248
    .line 249
    .line 250
    invoke-virtual {v7, v6}, Lki2;->h0(I)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v7, v12}, Lki2;->r(Z)V

    .line 254
    .line 255
    .line 256
    :goto_5
    sget-object v6, Lea4;->h:Lea4;

    .line 257
    .line 258
    const/high16 v10, 0x3f800000    # 1.0f

    .line 259
    .line 260
    invoke-static {v6, v10}, Lit6;->e(Lha4;F)Lha4;

    .line 261
    .line 262
    .line 263
    move-result-object v11

    .line 264
    if-eqz p3, :cond_7

    .line 265
    .line 266
    const v10, -0x532cc7b9

    .line 267
    .line 268
    .line 269
    invoke-virtual {v7, v10}, Lki2;->h0(I)V

    .line 270
    .line 271
    .line 272
    invoke-static {v7}, Lzi6;->i(Lki2;)La28;

    .line 273
    .line 274
    .line 275
    move-result-object v10

    .line 276
    iget-object v10, v10, La28;->b:Lpg;

    .line 277
    .line 278
    invoke-static {v7}, Lzi6;->i(Lki2;)La28;

    .line 279
    .line 280
    .line 281
    move-result-object v12

    .line 282
    iget-object v12, v12, La28;->e:Lpg;

    .line 283
    .line 284
    move/from16 v18, v0

    .line 285
    .line 286
    new-instance v0, Lls7;

    .line 287
    .line 288
    invoke-direct {v0, v10, v12}, Lls7;-><init>(Lt08;Lt08;)V

    .line 289
    .line 290
    .line 291
    new-instance v10, Lro3;

    .line 292
    .line 293
    const/16 v12, 0xf

    .line 294
    .line 295
    invoke-direct {v10, v0, v12}, Lro3;-><init>(Lt08;I)V

    .line 296
    .line 297
    .line 298
    invoke-static {v6, v10}, Lnt7;->d0(Lha4;Lt08;)Lha4;

    .line 299
    .line 300
    .line 301
    move-result-object v0

    .line 302
    const/4 v10, 0x0

    .line 303
    invoke-virtual {v7, v10}, Lki2;->r(Z)V

    .line 304
    .line 305
    .line 306
    goto :goto_6

    .line 307
    :cond_7
    move/from16 v18, v0

    .line 308
    .line 309
    move v10, v12

    .line 310
    const v0, -0x5328d22b

    .line 311
    .line 312
    .line 313
    invoke-virtual {v7, v0}, Lki2;->h0(I)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v7, v10}, Lki2;->r(Z)V

    .line 317
    .line 318
    .line 319
    move-object v0, v6

    .line 320
    :goto_6
    invoke-interface {v11, v0}, Lha4;->b0(Lha4;)Lha4;

    .line 321
    .line 322
    .line 323
    move-result-object v0

    .line 324
    invoke-static {v0}, Ll63;->h0(Lha4;)Lha4;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    sget-object v10, Lx87;->i:Ln28;

    .line 329
    .line 330
    sget-object v11, Ly6;->t:Lz30;

    .line 331
    .line 332
    const/16 v12, 0x36

    .line 333
    .line 334
    invoke-static {v10, v11, v7, v12}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 335
    .line 336
    .line 337
    move-result-object v10

    .line 338
    iget-wide v11, v7, Lki2;->U:J

    .line 339
    .line 340
    invoke-static {v11, v12}, Ljava/lang/Long;->hashCode(J)I

    .line 341
    .line 342
    .line 343
    move-result v11

    .line 344
    invoke-virtual {v7}, Lki2;->m()Lr95;

    .line 345
    .line 346
    .line 347
    move-result-object v12

    .line 348
    invoke-static {v7, v0}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 349
    .line 350
    .line 351
    move-result-object v0

    .line 352
    invoke-virtual {v7}, Lki2;->k0()V

    .line 353
    .line 354
    .line 355
    iget-boolean v1, v7, Lki2;->T:Z

    .line 356
    .line 357
    if-eqz v1, :cond_8

    .line 358
    .line 359
    invoke-virtual {v7, v5}, Lki2;->l(Lwg2;)V

    .line 360
    .line 361
    .line 362
    goto :goto_7

    .line 363
    :cond_8
    invoke-virtual {v7}, Lki2;->t0()V

    .line 364
    .line 365
    .line 366
    :goto_7
    invoke-static {v9, v7, v10}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 367
    .line 368
    .line 369
    invoke-static {v8, v7, v12}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 370
    .line 371
    .line 372
    invoke-static {v11, v7, v14, v7}, Lx82;->w(ILki2;Lu31;Lki2;)V

    .line 373
    .line 374
    .line 375
    invoke-static {v13, v7, v0}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 376
    .line 377
    .line 378
    sget-object v0, Lqh4;->a:Lcx1;

    .line 379
    .line 380
    invoke-virtual {v0, v15}, Lcx1;->a(Ljava/lang/Object;)Lfh5;

    .line 381
    .line 382
    .line 383
    move-result-object v0

    .line 384
    new-instance v1, Lm24;

    .line 385
    .line 386
    const/16 v5, 0xa

    .line 387
    .line 388
    move-object/from16 v8, p6

    .line 389
    .line 390
    invoke-direct {v1, v8, v5}, Lm24;-><init>(Lq21;B)V

    .line 391
    .line 392
    .line 393
    const v5, 0x43321fd1

    .line 394
    .line 395
    .line 396
    invoke-static {v5, v1, v7}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    const/16 v5, 0x38

    .line 401
    .line 402
    invoke-static {v0, v1, v7, v5}, Lkk;->c(Lfh5;Llh2;Lki2;I)V

    .line 403
    .line 404
    .line 405
    const/4 v9, 0x1

    .line 406
    invoke-virtual {v7, v9}, Lki2;->r(Z)V

    .line 407
    .line 408
    .line 409
    if-eqz p3, :cond_c

    .line 410
    .line 411
    const v0, -0x532205b0

    .line 412
    .line 413
    .line 414
    invoke-virtual {v7, v0}, Lki2;->h0(I)V

    .line 415
    .line 416
    .line 417
    const v0, -0x53215658

    .line 418
    .line 419
    .line 420
    invoke-virtual {v7, v0}, Lki2;->h0(I)V

    .line 421
    .line 422
    .line 423
    invoke-static {v7}, Lzi6;->i(Lki2;)La28;

    .line 424
    .line 425
    .line 426
    move-result-object v0

    .line 427
    iget-object v0, v0, La28;->e:Lpg;

    .line 428
    .line 429
    new-instance v1, Lro3;

    .line 430
    .line 431
    const/16 v5, 0x20

    .line 432
    .line 433
    invoke-direct {v1, v0, v5}, Lro3;-><init>(Lt08;I)V

    .line 434
    .line 435
    .line 436
    invoke-static {v1, v7}, Lxp7;->m(Lt08;Lki2;)Lq83;

    .line 437
    .line 438
    .line 439
    move-result-object v0

    .line 440
    invoke-virtual {v0}, Lq83;->c()F

    .line 441
    .line 442
    .line 443
    move-result v0

    .line 444
    const/4 v10, 0x0

    .line 445
    invoke-virtual {v7, v10}, Lki2;->r(Z)V

    .line 446
    .line 447
    .line 448
    const/high16 v10, 0x3f800000    # 1.0f

    .line 449
    .line 450
    invoke-static {v6, v10}, Lit6;->e(Lha4;F)Lha4;

    .line 451
    .line 452
    .line 453
    move-result-object v1

    .line 454
    invoke-virtual {v7, v0}, Lki2;->d(F)Z

    .line 455
    .line 456
    .line 457
    move-result v5

    .line 458
    invoke-virtual {v7, v4}, Lki2;->g(Ljava/lang/Object;)Z

    .line 459
    .line 460
    .line 461
    move-result v6

    .line 462
    or-int/2addr v5, v6

    .line 463
    invoke-virtual {v7}, Lki2;->T()Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    move-result-object v6

    .line 467
    sget-object v10, Lz41;->a:Lql0;

    .line 468
    .line 469
    if-nez v5, :cond_9

    .line 470
    .line 471
    if-ne v6, v10, :cond_a

    .line 472
    .line 473
    :cond_9
    new-instance v6, Lsp0;

    .line 474
    .line 475
    const/4 v5, 0x2

    .line 476
    invoke-direct {v6, v0, v4, v5}, Lsp0;-><init>(FLjava/lang/Object;B)V

    .line 477
    .line 478
    .line 479
    invoke-virtual {v7, v6}, Lki2;->q0(Ljava/lang/Object;)V

    .line 480
    .line 481
    .line 482
    :cond_a
    check-cast v6, Lmh2;

    .line 483
    .line 484
    invoke-static {v1, v6}, Lxp7;->v(Lha4;Lmh2;)Lha4;

    .line 485
    .line 486
    .line 487
    move-result-object v0

    .line 488
    invoke-virtual {v7}, Lki2;->T()Ljava/lang/Object;

    .line 489
    .line 490
    .line 491
    move-result-object v1

    .line 492
    if-ne v1, v10, :cond_b

    .line 493
    .line 494
    sget-object v1, Lwp;->o:Lwp;

    .line 495
    .line 496
    invoke-virtual {v7, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 497
    .line 498
    .line 499
    :cond_b
    check-cast v1, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 500
    .line 501
    sget-object v4, Los7;->a:Los7;

    .line 502
    .line 503
    invoke-static {v0, v4, v1}, Lh57;->b(Lha4;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Lha4;

    .line 504
    .line 505
    .line 506
    move-result-object v0

    .line 507
    invoke-static {v7, v0}, Lck6;->b(Lki2;Lha4;)V

    .line 508
    .line 509
    .line 510
    const/4 v10, 0x0

    .line 511
    invoke-virtual {v7, v10}, Lki2;->r(Z)V

    .line 512
    .line 513
    .line 514
    :goto_8
    const/4 v9, 0x1

    .line 515
    goto :goto_9

    .line 516
    :cond_c
    const/4 v10, 0x0

    .line 517
    const v0, -0x53138513

    .line 518
    .line 519
    .line 520
    invoke-virtual {v7, v0}, Lki2;->h0(I)V

    .line 521
    .line 522
    .line 523
    invoke-virtual {v7, v10}, Lki2;->r(Z)V

    .line 524
    .line 525
    .line 526
    goto :goto_8

    .line 527
    :goto_9
    invoke-virtual {v7, v9}, Lki2;->r(Z)V

    .line 528
    .line 529
    .line 530
    move/from16 v5, p3

    .line 531
    .line 532
    move-object v6, v15

    .line 533
    move/from16 v4, v18

    .line 534
    .line 535
    goto :goto_a

    .line 536
    :cond_d
    move-object/from16 v8, p6

    .line 537
    .line 538
    invoke-virtual {v7}, Lki2;->b0()V

    .line 539
    .line 540
    .line 541
    move/from16 v4, p3

    .line 542
    .line 543
    move/from16 v5, p4

    .line 544
    .line 545
    move-object/from16 v6, p5

    .line 546
    .line 547
    :goto_a
    invoke-virtual {v7}, Lki2;->w()Lhu5;

    .line 548
    .line 549
    .line 550
    move-result-object v9

    .line 551
    if-eqz v9, :cond_e

    .line 552
    .line 553
    new-instance v0, Lrl;

    .line 554
    .line 555
    move-object/from16 v1, p0

    .line 556
    .line 557
    move-object v7, v8

    .line 558
    move/from16 v8, p8

    .line 559
    .line 560
    invoke-direct/range {v0 .. v8}, Lrl;-><init>(Lha4;JZZLhh4;Lq21;I)V

    .line 561
    .line 562
    .line 563
    iput-object v0, v9, Lhu5;->d:Llh2;

    .line 564
    .line 565
    :cond_e
    return-void
.end method

.method public static final b(Lj16;ZLwg2;La53;Ljava/lang/String;Lha4;ZLih4;Lki2;I)V
    .locals 30

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v0, p3

    .line 6
    .line 7
    move-object/from16 v9, p8

    .line 8
    .line 9
    move/from16 v10, p9

    .line 10
    .line 11
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    const v3, 0x1e92df9f

    .line 21
    .line 22
    .line 23
    invoke-virtual {v9, v3}, Lki2;->i0(I)Lki2;

    .line 24
    .line 25
    .line 26
    and-int/lit8 v3, v10, 0x6

    .line 27
    .line 28
    if-nez v3, :cond_1

    .line 29
    .line 30
    invoke-virtual {v9, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    if-eqz v3, :cond_0

    .line 35
    .line 36
    const/4 v3, 0x4

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const/4 v3, 0x2

    .line 39
    :goto_0
    or-int/2addr v3, v10

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    move v3, v10

    .line 42
    :goto_1
    and-int/lit8 v5, v10, 0x30

    .line 43
    .line 44
    if-nez v5, :cond_3

    .line 45
    .line 46
    invoke-virtual {v9, v2}, Lki2;->h(Z)Z

    .line 47
    .line 48
    .line 49
    move-result v5

    .line 50
    if-eqz v5, :cond_2

    .line 51
    .line 52
    const/16 v5, 0x20

    .line 53
    .line 54
    goto :goto_2

    .line 55
    :cond_2
    const/16 v5, 0x10

    .line 56
    .line 57
    :goto_2
    or-int/2addr v3, v5

    .line 58
    :cond_3
    and-int/lit16 v5, v10, 0x180

    .line 59
    .line 60
    if-nez v5, :cond_5

    .line 61
    .line 62
    move-object/from16 v8, p2

    .line 63
    .line 64
    invoke-virtual {v9, v8}, Lki2;->i(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    if-eqz v5, :cond_4

    .line 69
    .line 70
    const/16 v5, 0x100

    .line 71
    .line 72
    goto :goto_3

    .line 73
    :cond_4
    const/16 v5, 0x80

    .line 74
    .line 75
    :goto_3
    or-int/2addr v3, v5

    .line 76
    :cond_5
    and-int/lit16 v5, v10, 0xc00

    .line 77
    .line 78
    if-nez v5, :cond_7

    .line 79
    .line 80
    invoke-virtual {v9, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v5

    .line 84
    if-eqz v5, :cond_6

    .line 85
    .line 86
    const/16 v5, 0x800

    .line 87
    .line 88
    goto :goto_4

    .line 89
    :cond_6
    const/16 v5, 0x400

    .line 90
    .line 91
    :goto_4
    or-int/2addr v3, v5

    .line 92
    :cond_7
    and-int/lit16 v5, v10, 0x6000

    .line 93
    .line 94
    if-nez v5, :cond_9

    .line 95
    .line 96
    move-object/from16 v12, p4

    .line 97
    .line 98
    invoke-virtual {v9, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v5

    .line 102
    if-eqz v5, :cond_8

    .line 103
    .line 104
    const/16 v5, 0x4000

    .line 105
    .line 106
    goto :goto_5

    .line 107
    :cond_8
    const/16 v5, 0x2000

    .line 108
    .line 109
    :goto_5
    or-int/2addr v3, v5

    .line 110
    :cond_9
    const/high16 v5, 0x1b0000

    .line 111
    .line 112
    or-int/2addr v5, v3

    .line 113
    const/high16 v6, 0xc00000

    .line 114
    .line 115
    and-int/2addr v6, v10

    .line 116
    if-nez v6, :cond_a

    .line 117
    .line 118
    const/high16 v5, 0x5b0000

    .line 119
    .line 120
    or-int/2addr v5, v3

    .line 121
    :cond_a
    const/high16 v3, 0x6000000

    .line 122
    .line 123
    or-int/2addr v5, v3

    .line 124
    const v3, 0x2492493

    .line 125
    .line 126
    .line 127
    and-int/2addr v3, v5

    .line 128
    const v6, 0x2492492

    .line 129
    .line 130
    .line 131
    const/4 v14, 0x1

    .line 132
    if-eq v3, v6, :cond_b

    .line 133
    .line 134
    move v3, v14

    .line 135
    goto :goto_6

    .line 136
    :cond_b
    const/4 v3, 0x0

    .line 137
    :goto_6
    and-int/lit8 v6, v5, 0x1

    .line 138
    .line 139
    invoke-virtual {v9, v6, v3}, Lki2;->Y(IZ)Z

    .line 140
    .line 141
    .line 142
    move-result v3

    .line 143
    if-eqz v3, :cond_1e

    .line 144
    .line 145
    invoke-virtual {v9}, Lki2;->d0()V

    .line 146
    .line 147
    .line 148
    and-int/lit8 v3, v10, 0x1

    .line 149
    .line 150
    sget-object v15, Lea4;->h:Lea4;

    .line 151
    .line 152
    sget-object v6, Lz41;->a:Lql0;

    .line 153
    .line 154
    const v7, -0x1c00001

    .line 155
    .line 156
    .line 157
    if-eqz v3, :cond_c

    .line 158
    .line 159
    invoke-virtual {v9}, Lki2;->D()Z

    .line 160
    .line 161
    .line 162
    move-result v3

    .line 163
    if-nez v3, :cond_c

    .line 164
    .line 165
    invoke-virtual {v9}, Lki2;->b0()V

    .line 166
    .line 167
    .line 168
    and-int/2addr v5, v7

    .line 169
    move-object/from16 v11, p5

    .line 170
    .line 171
    move/from16 v3, p6

    .line 172
    .line 173
    move-object/from16 v12, p7

    .line 174
    .line 175
    :goto_7
    move v13, v5

    .line 176
    goto :goto_8

    .line 177
    :cond_c
    sget v3, Lgh4;->b:F

    .line 178
    .line 179
    sget-object v3, Lsz0;->a:Lcx1;

    .line 180
    .line 181
    invoke-virtual {v9, v3}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v16

    .line 185
    check-cast v16, Lrz0;

    .line 186
    .line 187
    move/from16 v17, v7

    .line 188
    .line 189
    invoke-virtual/range {v16 .. v16}, Lrz0;->j()J

    .line 190
    .line 191
    .line 192
    move-result-wide v7

    .line 193
    invoke-virtual {v9, v3}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v3

    .line 197
    check-cast v3, Lrz0;

    .line 198
    .line 199
    invoke-virtual {v3}, Lrz0;->j()J

    .line 200
    .line 201
    .line 202
    move-result-wide v11

    .line 203
    invoke-virtual {v9, v7, v8}, Lki2;->f(J)Z

    .line 204
    .line 205
    .line 206
    move-result v3

    .line 207
    invoke-virtual {v9, v11, v12}, Lki2;->f(J)Z

    .line 208
    .line 209
    .line 210
    move-result v18

    .line 211
    or-int v3, v3, v18

    .line 212
    .line 213
    invoke-virtual {v9}, Lki2;->T()Ljava/lang/Object;

    .line 214
    .line 215
    .line 216
    move-result-object v13

    .line 217
    if-nez v3, :cond_d

    .line 218
    .line 219
    if-ne v13, v6, :cond_e

    .line 220
    .line 221
    :cond_d
    new-instance v13, Lih4;

    .line 222
    .line 223
    invoke-direct {v13, v7, v8, v11, v12}, Lih4;-><init>(JJ)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v9, v13}, Lki2;->q0(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    :cond_e
    move-object v3, v13

    .line 230
    check-cast v3, Lih4;

    .line 231
    .line 232
    and-int v5, v5, v17

    .line 233
    .line 234
    move-object v12, v3

    .line 235
    move v3, v14

    .line 236
    move-object v11, v15

    .line 237
    goto :goto_7

    .line 238
    :goto_8
    invoke-virtual {v9}, Lki2;->s()V

    .line 239
    .line 240
    .line 241
    sget v5, Lgh4;->b:F

    .line 242
    .line 243
    invoke-virtual {v9}, Lki2;->T()Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v5

    .line 247
    if-ne v5, v6, :cond_f

    .line 248
    .line 249
    invoke-static {v9}, Lx82;->i(Lki2;)Lzc4;

    .line 250
    .line 251
    .line 252
    move-result-object v5

    .line 253
    :cond_f
    check-cast v5, Lzc4;

    .line 254
    .line 255
    invoke-static {v5, v9}, Lv43;->I(Lzc4;Lki2;)Lzd4;

    .line 256
    .line 257
    .line 258
    move-result-object v7

    .line 259
    invoke-interface {v7}, Lxy6;->getValue()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v7

    .line 263
    check-cast v7, Ljava/lang/Boolean;

    .line 264
    .line 265
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 266
    .line 267
    .line 268
    move-result v7

    .line 269
    if-eqz v7, :cond_11

    .line 270
    .line 271
    if-eqz v2, :cond_10

    .line 272
    .line 273
    iget-wide v7, v12, Lih4;->b:J

    .line 274
    .line 275
    invoke-static {v7, v8}, Ldy0;->c(J)F

    .line 276
    .line 277
    .line 278
    move-result v17

    .line 279
    sget v18, Lgh4;->d:F

    .line 280
    .line 281
    mul-float v4, v17, v18

    .line 282
    .line 283
    invoke-static {v4, v7, v8}, Ldy0;->b(FJ)J

    .line 284
    .line 285
    .line 286
    move-result-wide v7

    .line 287
    :goto_9
    move-wide/from16 v17, v7

    .line 288
    .line 289
    goto :goto_a

    .line 290
    :cond_10
    iget-wide v7, v12, Lih4;->a:J

    .line 291
    .line 292
    invoke-static {v7, v8}, Ldy0;->c(J)F

    .line 293
    .line 294
    .line 295
    move-result v4

    .line 296
    sget v17, Lgh4;->e:F

    .line 297
    .line 298
    mul-float v4, v4, v17

    .line 299
    .line 300
    invoke-static {v4, v7, v8}, Ldy0;->b(FJ)J

    .line 301
    .line 302
    .line 303
    move-result-wide v7

    .line 304
    goto :goto_9

    .line 305
    :cond_11
    if-eqz v2, :cond_12

    .line 306
    .line 307
    iget-wide v7, v12, Lih4;->b:J

    .line 308
    .line 309
    goto :goto_9

    .line 310
    :cond_12
    iget-wide v7, v12, Lih4;->a:J

    .line 311
    .line 312
    invoke-static {v7, v8}, Ldy0;->c(J)F

    .line 313
    .line 314
    .line 315
    move-result v4

    .line 316
    sget v17, Lgh4;->f:F

    .line 317
    .line 318
    mul-float v4, v4, v17

    .line 319
    .line 320
    invoke-static {v4, v7, v8}, Ldy0;->b(FJ)J

    .line 321
    .line 322
    .line 323
    move-result-wide v7

    .line 324
    goto :goto_9

    .line 325
    :goto_a
    if-eqz v2, :cond_13

    .line 326
    .line 327
    sget-object v4, Lsf2;->m:Lsf2;

    .line 328
    .line 329
    :goto_b
    move-object/from16 v22, v4

    .line 330
    .line 331
    goto :goto_c

    .line 332
    :cond_13
    sget-object v4, Lsf2;->j:Lsf2;

    .line 333
    .line 334
    goto :goto_b

    .line 335
    :goto_c
    sget-object v4, Lqh4;->a:Lcx1;

    .line 336
    .line 337
    invoke-virtual {v9, v4}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 338
    .line 339
    .line 340
    move-result-object v4

    .line 341
    check-cast v4, Lhh4;

    .line 342
    .line 343
    const/high16 v7, 0x42800000    # 64.0f

    .line 344
    .line 345
    invoke-static {v11, v7}, Lit6;->f(Lha4;F)Lha4;

    .line 346
    .line 347
    .line 348
    move-result-object v7

    .line 349
    invoke-interface {v1, v7, v14}, Lj16;->a(Lha4;Z)Lha4;

    .line 350
    .line 351
    .line 352
    move-result-object v7

    .line 353
    move-object v2, v7

    .line 354
    new-instance v7, Lxz5;

    .line 355
    .line 356
    const/4 v8, 0x4

    .line 357
    invoke-direct {v7, v8}, Lxz5;-><init>(I)V

    .line 358
    .line 359
    .line 360
    move-object v8, v4

    .line 361
    move-object v4, v5

    .line 362
    const/4 v5, 0x0

    .line 363
    move-object v0, v6

    .line 364
    move-object v14, v8

    .line 365
    move-object/from16 v8, p2

    .line 366
    .line 367
    move v6, v3

    .line 368
    move/from16 v3, p1

    .line 369
    .line 370
    invoke-static/range {v2 .. v8}, Lx87;->N(Lha4;ZLzc4;Ld63;ZLxz5;Lwg2;)Lha4;

    .line 371
    .line 372
    .line 373
    move-result-object v2

    .line 374
    move/from16 v25, v6

    .line 375
    .line 376
    invoke-interface {v2, v15}, Lha4;->b0(Lha4;)Lha4;

    .line 377
    .line 378
    .line 379
    move-result-object v2

    .line 380
    sget-object v3, Ly6;->w:Ly30;

    .line 381
    .line 382
    sget-object v4, Lhh4;->h:Lhh4;

    .line 383
    .line 384
    if-eq v14, v4, :cond_14

    .line 385
    .line 386
    sget-object v4, Lhh4;->i:Lhh4;

    .line 387
    .line 388
    if-eq v14, v4, :cond_14

    .line 389
    .line 390
    sget-object v4, Lx87;->g:Ln28;

    .line 391
    .line 392
    goto :goto_d

    .line 393
    :cond_14
    sget-object v4, Lx87;->e:Lsw;

    .line 394
    .line 395
    :goto_d
    const/16 v5, 0x30

    .line 396
    .line 397
    invoke-static {v4, v3, v9, v5}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 398
    .line 399
    .line 400
    move-result-object v3

    .line 401
    iget-wide v4, v9, Lki2;->U:J

    .line 402
    .line 403
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 404
    .line 405
    .line 406
    move-result v4

    .line 407
    invoke-virtual {v9}, Lki2;->m()Lr95;

    .line 408
    .line 409
    .line 410
    move-result-object v5

    .line 411
    invoke-static {v9, v2}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 412
    .line 413
    .line 414
    move-result-object v2

    .line 415
    sget-object v6, Lp41;->d:Ly6;

    .line 416
    .line 417
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 418
    .line 419
    .line 420
    invoke-virtual {v9}, Lki2;->k0()V

    .line 421
    .line 422
    .line 423
    iget-boolean v6, v9, Lki2;->T:Z

    .line 424
    .line 425
    if-eqz v6, :cond_15

    .line 426
    .line 427
    sget-object v6, Lwi3;->Z:Lj43;

    .line 428
    .line 429
    invoke-virtual {v9, v6}, Lki2;->l(Lwg2;)V

    .line 430
    .line 431
    .line 432
    goto :goto_e

    .line 433
    :cond_15
    invoke-virtual {v9}, Lki2;->t0()V

    .line 434
    .line 435
    .line 436
    :goto_e
    sget-object v6, Ly6;->T:Lu31;

    .line 437
    .line 438
    invoke-static {v6, v9, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 439
    .line 440
    .line 441
    sget-object v3, Ly6;->S:Lu31;

    .line 442
    .line 443
    invoke-static {v3, v9, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 444
    .line 445
    .line 446
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 447
    .line 448
    .line 449
    move-result-object v3

    .line 450
    sget-object v4, Ly6;->U:Lu31;

    .line 451
    .line 452
    invoke-static {v4, v9, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 453
    .line 454
    .line 455
    invoke-static {v9}, Lml6;->p(Lki2;)V

    .line 456
    .line 457
    .line 458
    sget-object v3, Ly6;->R:Lu31;

    .line 459
    .line 460
    invoke-static {v3, v9, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 461
    .line 462
    .line 463
    invoke-virtual {v14}, Ljava/lang/Enum;->ordinal()I

    .line 464
    .line 465
    .line 466
    move-result v2

    .line 467
    if-eqz v2, :cond_1d

    .line 468
    .line 469
    const/4 v3, 0x2

    .line 470
    if-eq v2, v3, :cond_16

    .line 471
    .line 472
    const v0, 0x4371aae

    .line 473
    .line 474
    .line 475
    invoke-virtual {v9, v0}, Lki2;->h0(I)V

    .line 476
    .line 477
    .line 478
    new-instance v2, Low2;

    .line 479
    .line 480
    const/4 v3, 0x1

    .line 481
    move-object/from16 v6, p3

    .line 482
    .line 483
    move-object/from16 v7, p4

    .line 484
    .line 485
    move-wide/from16 v4, v17

    .line 486
    .line 487
    invoke-direct/range {v2 .. v7}, Low2;-><init>(BJLjava/lang/Object;Ljava/lang/Object;)V

    .line 488
    .line 489
    .line 490
    const v0, -0x4739d892

    .line 491
    .line 492
    .line 493
    invoke-static {v0, v2, v9}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 494
    .line 495
    .line 496
    move-result-object v0

    .line 497
    shr-int/lit8 v13, v13, 0x18

    .line 498
    .line 499
    and-int/lit8 v13, v13, 0xe

    .line 500
    .line 501
    or-int/lit16 v13, v13, 0x1b0

    .line 502
    .line 503
    invoke-static {v15, v0, v9, v13}, Lqh4;->c(Lha4;Lq21;Lki2;I)V

    .line 504
    .line 505
    .line 506
    const/4 v0, 0x0

    .line 507
    invoke-virtual {v9, v0}, Lki2;->r(Z)V

    .line 508
    .line 509
    .line 510
    move-object v5, v9

    .line 511
    move-object/from16 v26, v11

    .line 512
    .line 513
    move-object/from16 p6, v12

    .line 514
    .line 515
    :goto_f
    const/4 v4, 0x1

    .line 516
    goto/16 :goto_12

    .line 517
    .line 518
    :cond_16
    move-object/from16 v14, p3

    .line 519
    .line 520
    move-wide/from16 v4, v17

    .line 521
    .line 522
    const v2, 0x41843da

    .line 523
    .line 524
    .line 525
    invoke-virtual {v9, v2}, Lki2;->h0(I)V

    .line 526
    .line 527
    .line 528
    if-eqz p1, :cond_17

    .line 529
    .line 530
    sget v2, Lgh4;->b:F

    .line 531
    .line 532
    goto :goto_10

    .line 533
    :cond_17
    const/high16 v2, 0x41980000    # 19.0f

    .line 534
    .line 535
    :goto_10
    const/16 v3, 0x12c

    .line 536
    .line 537
    const/4 v6, 0x0

    .line 538
    const/4 v7, 0x6

    .line 539
    move v1, v3

    .line 540
    const/4 v8, 0x0

    .line 541
    invoke-static {v1, v8, v6, v7}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 542
    .line 543
    .line 544
    move-result-object v3

    .line 545
    move-object/from16 v16, v6

    .line 546
    .line 547
    const/16 v6, 0x1b0

    .line 548
    .line 549
    move/from16 v17, v7

    .line 550
    .line 551
    const/16 v7, 0x8

    .line 552
    .line 553
    move-wide/from16 v18, v4

    .line 554
    .line 555
    const-string v4, "iconTopPadding"

    .line 556
    .line 557
    move-object v5, v9

    .line 558
    move-object/from16 v9, v16

    .line 559
    .line 560
    move/from16 v10, v17

    .line 561
    .line 562
    move-wide/from16 v26, v18

    .line 563
    .line 564
    invoke-static/range {v2 .. v7}, Lwg;->a(FLca2;Ljava/lang/String;Lki2;II)Lvg;

    .line 565
    .line 566
    .line 567
    move-result-object v2

    .line 568
    if-eqz p1, :cond_18

    .line 569
    .line 570
    const/high16 v3, 0x3f800000    # 1.0f

    .line 571
    .line 572
    goto :goto_11

    .line 573
    :cond_18
    const/4 v3, 0x0

    .line 574
    :goto_11
    invoke-static {v1, v8, v9, v10}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 575
    .line 576
    .line 577
    move-result-object v1

    .line 578
    const/16 v6, 0xc30

    .line 579
    .line 580
    const/16 v7, 0x14

    .line 581
    .line 582
    const-string v4, "textAlpha"

    .line 583
    .line 584
    move v5, v3

    .line 585
    move-object v3, v1

    .line 586
    move-object v1, v2

    .line 587
    move v2, v5

    .line 588
    move-object/from16 v5, p8

    .line 589
    .line 590
    invoke-static/range {v2 .. v7}, Lwg;->b(FLca2;Ljava/lang/String;Lki2;II)Lvg;

    .line 591
    .line 592
    .line 593
    move-result-object v2

    .line 594
    invoke-virtual {v5, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 595
    .line 596
    .line 597
    move-result v3

    .line 598
    invoke-virtual {v5}, Lki2;->T()Ljava/lang/Object;

    .line 599
    .line 600
    .line 601
    move-result-object v4

    .line 602
    if-nez v3, :cond_19

    .line 603
    .line 604
    if-ne v4, v0, :cond_1a

    .line 605
    .line 606
    :cond_19
    new-instance v4, Lo84;

    .line 607
    .line 608
    const/16 v3, 0x13

    .line 609
    .line 610
    invoke-direct {v4, v1, v3}, Lo84;-><init>(Ljava/lang/Object;B)V

    .line 611
    .line 612
    .line 613
    invoke-virtual {v5, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 614
    .line 615
    .line 616
    :cond_1a
    check-cast v4, Lmh2;

    .line 617
    .line 618
    invoke-static {v15, v4}, Lxp7;->v(Lha4;Lmh2;)Lha4;

    .line 619
    .line 620
    .line 621
    move-result-object v1

    .line 622
    new-instance v3, Lmh4;

    .line 623
    .line 624
    move-wide/from16 v6, v26

    .line 625
    .line 626
    const/4 v4, 0x1

    .line 627
    invoke-direct {v3, v6, v7, v14, v4}, Lmh4;-><init>(JLa53;B)V

    .line 628
    .line 629
    .line 630
    const v9, 0x6f73104e

    .line 631
    .line 632
    .line 633
    invoke-static {v9, v3, v5}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 634
    .line 635
    .line 636
    move-result-object v3

    .line 637
    shr-int/lit8 v9, v13, 0x18

    .line 638
    .line 639
    and-int/lit8 v9, v9, 0xe

    .line 640
    .line 641
    or-int/lit16 v9, v9, 0x180

    .line 642
    .line 643
    invoke-static {v1, v3, v5, v9}, Lqh4;->c(Lha4;Lq21;Lki2;I)V

    .line 644
    .line 645
    .line 646
    sget v19, Lgh4;->c:F

    .line 647
    .line 648
    const/16 v20, 0x7

    .line 649
    .line 650
    const/16 v16, 0x0

    .line 651
    .line 652
    const/16 v17, 0x0

    .line 653
    .line 654
    const/16 v18, 0x0

    .line 655
    .line 656
    invoke-static/range {v15 .. v20}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 657
    .line 658
    .line 659
    move-result-object v1

    .line 660
    invoke-virtual {v5, v2}, Lki2;->g(Ljava/lang/Object;)Z

    .line 661
    .line 662
    .line 663
    move-result v3

    .line 664
    invoke-virtual {v5}, Lki2;->T()Ljava/lang/Object;

    .line 665
    .line 666
    .line 667
    move-result-object v9

    .line 668
    if-nez v3, :cond_1b

    .line 669
    .line 670
    if-ne v9, v0, :cond_1c

    .line 671
    .line 672
    :cond_1b
    new-instance v9, Lup;

    .line 673
    .line 674
    const/16 v0, 0xb

    .line 675
    .line 676
    invoke-direct {v9, v2, v0}, Lup;-><init>(Lvg;B)V

    .line 677
    .line 678
    .line 679
    invoke-virtual {v5, v9}, Lki2;->q0(Ljava/lang/Object;)V

    .line 680
    .line 681
    .line 682
    :cond_1c
    check-cast v9, Lhh2;

    .line 683
    .line 684
    invoke-static {v1, v9}, Lnt7;->Q(Lha4;Lhh2;)Lha4;

    .line 685
    .line 686
    .line 687
    move-result-object v3

    .line 688
    move-wide/from16 v26, v6

    .line 689
    .line 690
    sget-wide v6, Lgh4;->a:J

    .line 691
    .line 692
    move-object v0, v12

    .line 693
    new-instance v12, Ld97;

    .line 694
    .line 695
    const/4 v1, 0x3

    .line 696
    invoke-direct {v12, v1}, Ld97;-><init>(I)V

    .line 697
    .line 698
    .line 699
    shr-int/lit8 v13, v13, 0xc

    .line 700
    .line 701
    and-int/lit8 v13, v13, 0xe

    .line 702
    .line 703
    or-int/lit16 v13, v13, 0x6000

    .line 704
    .line 705
    const/16 v23, 0x0

    .line 706
    .line 707
    const v24, 0x3fba8

    .line 708
    .line 709
    .line 710
    const/4 v9, 0x0

    .line 711
    move-object v15, v11

    .line 712
    const-wide/16 v10, 0x0

    .line 713
    .line 714
    move/from16 v21, v8

    .line 715
    .line 716
    move-object/from16 v8, v22

    .line 717
    .line 718
    move/from16 v22, v13

    .line 719
    .line 720
    const-wide/16 v13, 0x0

    .line 721
    .line 722
    move-object v1, v15

    .line 723
    const/4 v15, 0x0

    .line 724
    const/16 v16, 0x0

    .line 725
    .line 726
    const/16 v17, 0x0

    .line 727
    .line 728
    const/16 v18, 0x0

    .line 729
    .line 730
    const/16 v19, 0x0

    .line 731
    .line 732
    const/16 v20, 0x0

    .line 733
    .line 734
    move-wide/from16 v28, v26

    .line 735
    .line 736
    move-object/from16 v26, v1

    .line 737
    .line 738
    move/from16 v1, v21

    .line 739
    .line 740
    move-object/from16 v21, v5

    .line 741
    .line 742
    move-wide/from16 v4, v28

    .line 743
    .line 744
    move-object/from16 v2, p4

    .line 745
    .line 746
    move-object/from16 p6, v0

    .line 747
    .line 748
    invoke-static/range {v2 .. v24}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 749
    .line 750
    .line 751
    move-object/from16 v5, v21

    .line 752
    .line 753
    invoke-virtual {v5, v1}, Lki2;->r(Z)V

    .line 754
    .line 755
    .line 756
    goto/16 :goto_f

    .line 757
    .line 758
    :cond_1d
    move-object/from16 v0, p3

    .line 759
    .line 760
    move-object v5, v9

    .line 761
    move-object/from16 v26, v11

    .line 762
    .line 763
    move-object/from16 p6, v12

    .line 764
    .line 765
    move-wide/from16 v6, v17

    .line 766
    .line 767
    move-object/from16 v8, v22

    .line 768
    .line 769
    const/4 v1, 0x0

    .line 770
    const v2, 0x407a023

    .line 771
    .line 772
    .line 773
    invoke-virtual {v5, v2}, Lki2;->h0(I)V

    .line 774
    .line 775
    .line 776
    sget v17, Lgh4;->b:F

    .line 777
    .line 778
    const/16 v19, 0x0

    .line 779
    .line 780
    const/16 v20, 0xd

    .line 781
    .line 782
    const/16 v16, 0x0

    .line 783
    .line 784
    const/16 v18, 0x0

    .line 785
    .line 786
    invoke-static/range {v15 .. v20}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 787
    .line 788
    .line 789
    move-result-object v2

    .line 790
    new-instance v3, Lmh4;

    .line 791
    .line 792
    invoke-direct {v3, v6, v7, v0, v1}, Lmh4;-><init>(JLa53;B)V

    .line 793
    .line 794
    .line 795
    const v4, 0x2b52d0a5

    .line 796
    .line 797
    .line 798
    invoke-static {v4, v3, v5}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 799
    .line 800
    .line 801
    move-result-object v3

    .line 802
    shr-int/lit8 v4, v13, 0x18

    .line 803
    .line 804
    and-int/lit8 v4, v4, 0xe

    .line 805
    .line 806
    or-int/lit16 v4, v4, 0x1b0

    .line 807
    .line 808
    invoke-static {v2, v3, v5, v4}, Lqh4;->c(Lha4;Lq21;Lki2;I)V

    .line 809
    .line 810
    .line 811
    sget v19, Lgh4;->c:F

    .line 812
    .line 813
    const/16 v20, 0x7

    .line 814
    .line 815
    const/16 v17, 0x0

    .line 816
    .line 817
    invoke-static/range {v15 .. v20}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 818
    .line 819
    .line 820
    move-result-object v3

    .line 821
    move-wide/from16 v18, v6

    .line 822
    .line 823
    sget-wide v6, Lgh4;->a:J

    .line 824
    .line 825
    new-instance v12, Ld97;

    .line 826
    .line 827
    const/4 v2, 0x3

    .line 828
    invoke-direct {v12, v2}, Ld97;-><init>(I)V

    .line 829
    .line 830
    .line 831
    shr-int/lit8 v13, v13, 0xc

    .line 832
    .line 833
    and-int/lit8 v13, v13, 0xe

    .line 834
    .line 835
    or-int/lit16 v13, v13, 0x6030

    .line 836
    .line 837
    const/16 v23, 0x0

    .line 838
    .line 839
    const v24, 0x3fba8

    .line 840
    .line 841
    .line 842
    const/4 v9, 0x0

    .line 843
    const-wide/16 v10, 0x0

    .line 844
    .line 845
    move/from16 v22, v13

    .line 846
    .line 847
    const-wide/16 v13, 0x0

    .line 848
    .line 849
    const/4 v15, 0x0

    .line 850
    const/16 v16, 0x0

    .line 851
    .line 852
    const/16 v17, 0x0

    .line 853
    .line 854
    move-wide/from16 v4, v18

    .line 855
    .line 856
    const/16 v18, 0x0

    .line 857
    .line 858
    const/16 v19, 0x0

    .line 859
    .line 860
    const/16 v20, 0x0

    .line 861
    .line 862
    move-object/from16 v2, p4

    .line 863
    .line 864
    move-object/from16 v21, p8

    .line 865
    .line 866
    invoke-static/range {v2 .. v24}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 867
    .line 868
    .line 869
    move-object/from16 v5, v21

    .line 870
    .line 871
    invoke-virtual {v5, v1}, Lki2;->r(Z)V

    .line 872
    .line 873
    .line 874
    goto/16 :goto_f

    .line 875
    .line 876
    :goto_12
    invoke-virtual {v5, v4}, Lki2;->r(Z)V

    .line 877
    .line 878
    .line 879
    move-object/from16 v8, p6

    .line 880
    .line 881
    move/from16 v7, v25

    .line 882
    .line 883
    move-object/from16 v6, v26

    .line 884
    .line 885
    goto :goto_13

    .line 886
    :cond_1e
    move-object v5, v9

    .line 887
    invoke-virtual {v5}, Lki2;->b0()V

    .line 888
    .line 889
    .line 890
    move-object/from16 v6, p5

    .line 891
    .line 892
    move/from16 v7, p6

    .line 893
    .line 894
    move-object/from16 v8, p7

    .line 895
    .line 896
    :goto_13
    invoke-virtual {v5}, Lki2;->w()Lhu5;

    .line 897
    .line 898
    .line 899
    move-result-object v10

    .line 900
    if-eqz v10, :cond_1f

    .line 901
    .line 902
    new-instance v0, Loh4;

    .line 903
    .line 904
    move-object/from16 v1, p0

    .line 905
    .line 906
    move/from16 v2, p1

    .line 907
    .line 908
    move-object/from16 v3, p2

    .line 909
    .line 910
    move-object/from16 v4, p3

    .line 911
    .line 912
    move-object/from16 v5, p4

    .line 913
    .line 914
    move/from16 v9, p9

    .line 915
    .line 916
    invoke-direct/range {v0 .. v9}, Loh4;-><init>(Lj16;ZLwg2;La53;Ljava/lang/String;Lha4;ZLih4;I)V

    .line 917
    .line 918
    .line 919
    iput-object v0, v10, Lhu5;->d:Llh2;

    .line 920
    .line 921
    :cond_1f
    return-void
.end method

.method public static final c(Lha4;Lq21;Lki2;I)V
    .locals 10

    .line 1
    const v0, -0x3d6dae32

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, Lki2;->i0(I)Lki2;

    .line 5
    .line 6
    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 8
    .line 9
    const/4 v1, 0x4

    .line 10
    if-nez v0, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p2, v0}, Lki2;->i(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    move v0, v1

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v0, 0x2

    .line 22
    :goto_0
    or-int/2addr v0, p3

    .line 23
    goto :goto_1

    .line 24
    :cond_1
    move v0, p3

    .line 25
    :goto_1
    and-int/lit8 v2, p3, 0x30

    .line 26
    .line 27
    if-nez v2, :cond_3

    .line 28
    .line 29
    invoke-virtual {p2, p0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-eqz v2, :cond_2

    .line 34
    .line 35
    const/16 v2, 0x20

    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_2
    const/16 v2, 0x10

    .line 39
    .line 40
    :goto_2
    or-int/2addr v0, v2

    .line 41
    :cond_3
    and-int/lit16 v2, p3, 0x180

    .line 42
    .line 43
    if-nez v2, :cond_5

    .line 44
    .line 45
    invoke-virtual {p2, p1}, Lki2;->i(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    if-eqz v2, :cond_4

    .line 50
    .line 51
    const/16 v2, 0x100

    .line 52
    .line 53
    goto :goto_3

    .line 54
    :cond_4
    const/16 v2, 0x80

    .line 55
    .line 56
    :goto_3
    or-int/2addr v0, v2

    .line 57
    :cond_5
    and-int/lit16 v2, v0, 0x93

    .line 58
    .line 59
    const/16 v3, 0x92

    .line 60
    .line 61
    if-eq v2, v3, :cond_6

    .line 62
    .line 63
    const/4 v2, 0x1

    .line 64
    goto :goto_4

    .line 65
    :cond_6
    const/4 v2, 0x0

    .line 66
    :goto_4
    and-int/lit8 v3, v0, 0x1

    .line 67
    .line 68
    invoke-virtual {p2, v3, v2}, Lki2;->Y(IZ)Z

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    if-eqz v2, :cond_7

    .line 73
    .line 74
    new-instance v2, Lr31;

    .line 75
    .line 76
    const/16 v3, 0x1b

    .line 77
    .line 78
    invoke-direct {v2, v3}, Lr31;-><init>(B)V

    .line 79
    .line 80
    .line 81
    const v3, 0x1c8fc646

    .line 82
    .line 83
    .line 84
    invoke-static {v3, v2, p2}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    new-instance v2, Lkn;

    .line 89
    .line 90
    const/16 v3, 0xf

    .line 91
    .line 92
    invoke-direct {v2, p1, v3}, Lkn;-><init>(Lq21;B)V

    .line 93
    .line 94
    .line 95
    const v3, -0x70559638

    .line 96
    .line 97
    .line 98
    invoke-static {v3, v2, p2}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 99
    .line 100
    .line 101
    move-result-object v6

    .line 102
    and-int/lit8 v0, v0, 0x70

    .line 103
    .line 104
    or-int/lit16 v8, v0, 0x186

    .line 105
    .line 106
    const/4 v9, 0x0

    .line 107
    move-object v5, p0

    .line 108
    move-object v7, p2

    .line 109
    invoke-static/range {v4 .. v9}, Lkb;->h(Lq21;Lha4;Lq21;Lki2;II)V

    .line 110
    .line 111
    .line 112
    goto :goto_5

    .line 113
    :cond_7
    move-object v5, p0

    .line 114
    move-object v7, p2

    .line 115
    invoke-virtual {v7}, Lki2;->b0()V

    .line 116
    .line 117
    .line 118
    :goto_5
    invoke-virtual {v7}, Lki2;->w()Lhu5;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    if-eqz p0, :cond_8

    .line 123
    .line 124
    new-instance p2, Lbf;

    .line 125
    .line 126
    invoke-direct {p2, v5, p1, p3, v1}, Lbf;-><init>(Lha4;Lq21;IB)V

    .line 127
    .line 128
    .line 129
    iput-object p2, p0, Lhu5;->d:Llh2;

    .line 130
    .line 131
    :cond_8
    return-void
.end method
