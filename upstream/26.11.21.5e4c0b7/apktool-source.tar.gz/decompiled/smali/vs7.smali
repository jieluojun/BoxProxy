.class public final Lvs7;
.super Lky5;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lrw6;


# instance fields
.field public final i:Lr14;

.field public final j:J


# direct methods
.method public constructor <init>(Lr14;J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvs7;->i:Lr14;

    .line 5
    .line 6
    iput-wide p2, p0, Lvs7;->j:J

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final B()Ltg0;
    .locals 1

    .line 1
    new-instance v0, Lft5;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lft5;-><init>(Lrw6;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final a()Ljj7;
    .locals 0

    .line 1
    sget-object p0, Ljj7;->d:Lij7;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lvs7;->j:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final close()V
    .locals 0

    .line 1
    return-void
.end method

.method public final e()Lr14;
    .locals 0

    .line 1
    iget-object p0, p0, Lvs7;->i:Lr14;

    .line 2
    .line 3
    return-object p0
.end method

.method public final t(Lhg0;J)J
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 5
    .line 6
    const-string p1, "Unreadable ResponseBody! These Response objects have bodies that are stripped:\n * Response.cacheResponse\n * Response.networkResponse\n * Response.priorResponse\n * EventSourceListener\n * WebSocketListener\n(It is safe to call contentType() and contentLength() on these response bodies.)"

    .line 7
    .line 8
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    throw p0
.end method
