.class public final synthetic Lb31;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lnh2;


# instance fields
.field public final synthetic h:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lb31;->h:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final r(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v0, v0, Lb31;->h:B

    .line 4
    .line 5
    sget-object v1, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    const/16 v3, 0x90

    .line 9
    .line 10
    const/16 v4, 0x10

    .line 11
    .line 12
    const/16 v5, 0x20

    .line 13
    .line 14
    const/4 v6, 0x1

    .line 15
    const/4 v7, 0x3

    .line 16
    packed-switch v0, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object/from16 v0, p1

    .line 20
    .line 21
    check-cast v0, Lii1;

    .line 22
    .line 23
    move-object/from16 v1, p2

    .line 24
    .line 25
    check-cast v1, Landroid/content/Context;

    .line 26
    .line 27
    move-object/from16 v2, p3

    .line 28
    .line 29
    check-cast v2, Lzh6;

    .line 30
    .line 31
    move-object/from16 v3, p4

    .line 32
    .line 33
    check-cast v3, Lpt3;

    .line 34
    .line 35
    new-instance v4, Ldb5;

    .line 36
    .line 37
    invoke-direct {v4, v0, v1, v2, v3}, Ldb5;-><init>(Lii1;Landroid/content/Context;Lzh6;Lpt3;)V

    .line 38
    .line 39
    .line 40
    return-object v4

    .line 41
    :pswitch_0
    move-object/from16 v0, p1

    .line 42
    .line 43
    check-cast v0, Luh;

    .line 44
    .line 45
    move-object/from16 v8, p2

    .line 46
    .line 47
    check-cast v8, Lvy2;

    .line 48
    .line 49
    move-object/from16 v14, p3

    .line 50
    .line 51
    check-cast v14, Lki2;

    .line 52
    .line 53
    move-object/from16 v9, p4

    .line 54
    .line 55
    check-cast v9, Ljava/lang/Integer;

    .line 56
    .line 57
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 58
    .line 59
    .line 60
    move-result v9

    .line 61
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    and-int/lit8 v0, v9, 0x30

    .line 68
    .line 69
    if-nez v0, :cond_1

    .line 70
    .line 71
    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    invoke-virtual {v14, v0}, Lki2;->e(I)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_0

    .line 80
    .line 81
    move v4, v5

    .line 82
    :cond_0
    or-int/2addr v9, v4

    .line 83
    :cond_1
    and-int/lit16 v0, v9, 0x91

    .line 84
    .line 85
    if-eq v0, v3, :cond_2

    .line 86
    .line 87
    move v2, v6

    .line 88
    :cond_2
    and-int/2addr v9, v6

    .line 89
    invoke-virtual {v14, v9, v2}, Lki2;->Y(IZ)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_9

    .line 94
    .line 95
    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    const/high16 v9, 0x40800000    # 4.0f

    .line 100
    .line 101
    const/high16 v12, 0x40000000    # 2.0f

    .line 102
    .line 103
    const/high16 v5, 0x40c00000    # 6.0f

    .line 104
    .line 105
    const/high16 v2, 0x41000000    # 8.0f

    .line 106
    .line 107
    const-wide/high16 v3, -0x100000000000000L

    .line 108
    .line 109
    const/high16 v15, 0x41400000    # 12.0f

    .line 110
    .line 111
    if-eqz v0, :cond_7

    .line 112
    .line 113
    const/high16 v13, -0x40000000    # -2.0f

    .line 114
    .line 115
    const/high16 v10, 0x41300000    # 11.0f

    .line 116
    .line 117
    const/high16 v11, 0x40e00000    # 7.0f

    .line 118
    .line 119
    if-eq v0, v6, :cond_6

    .line 120
    .line 121
    const/4 v6, 0x2

    .line 122
    if-eq v0, v6, :cond_5

    .line 123
    .line 124
    if-ne v0, v7, :cond_4

    .line 125
    .line 126
    sget-object v0, Lvl6;->a:La53;

    .line 127
    .line 128
    if-nez v0, :cond_3

    .line 129
    .line 130
    new-instance v16, Lz43;

    .line 131
    .line 132
    const/16 v24, 0x0

    .line 133
    .line 134
    const/16 v26, 0x60

    .line 135
    .line 136
    const-string v17, "Outlined.Sync"

    .line 137
    .line 138
    const/high16 v18, 0x41c00000    # 24.0f

    .line 139
    .line 140
    const/high16 v19, 0x41c00000    # 24.0f

    .line 141
    .line 142
    const/high16 v20, 0x41c00000    # 24.0f

    .line 143
    .line 144
    const/high16 v21, 0x41c00000    # 24.0f

    .line 145
    .line 146
    const-wide/16 v22, 0x0

    .line 147
    .line 148
    const/16 v25, 0x0

    .line 149
    .line 150
    invoke-direct/range {v16 .. v26}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 151
    .line 152
    .line 153
    new-instance v0, Lnw6;

    .line 154
    .line 155
    invoke-direct {v0, v3, v4}, Lnw6;-><init>(J)V

    .line 156
    .line 157
    .line 158
    new-instance v3, Ly75;

    .line 159
    .line 160
    invoke-direct {v3}, Ly75;-><init>()V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v3, v15, v9}, Ly75;->h(FF)V

    .line 164
    .line 165
    .line 166
    const/high16 v4, 0x3f800000    # 1.0f

    .line 167
    .line 168
    invoke-virtual {v3, v15, v4}, Ly75;->f(FF)V

    .line 169
    .line 170
    .line 171
    const/high16 v4, 0x40a00000    # 5.0f

    .line 172
    .line 173
    invoke-virtual {v3, v2, v4}, Ly75;->f(FF)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v3, v9, v9}, Ly75;->g(FF)V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v3, v15, v5}, Ly75;->f(FF)V

    .line 180
    .line 181
    .line 182
    const/high16 v22, 0x40c00000    # 6.0f

    .line 183
    .line 184
    const/high16 v23, 0x40c00000    # 6.0f

    .line 185
    .line 186
    const v18, 0x4053d70a    # 3.31f

    .line 187
    .line 188
    .line 189
    const/16 v19, 0x0

    .line 190
    .line 191
    const/high16 v20, 0x40c00000    # 6.0f

    .line 192
    .line 193
    const v21, 0x402c28f6    # 2.69f

    .line 194
    .line 195
    .line 196
    move-object/from16 v17, v3

    .line 197
    .line 198
    invoke-virtual/range {v17 .. v23}, Ly75;->c(FFFFFF)V

    .line 199
    .line 200
    .line 201
    const v22, -0x40cccccd    # -0.7f

    .line 202
    .line 203
    .line 204
    const v23, 0x40333333    # 2.8f

    .line 205
    .line 206
    .line 207
    const/16 v18, 0x0

    .line 208
    .line 209
    const v19, 0x3f8147ae    # 1.01f

    .line 210
    .line 211
    .line 212
    const/high16 v20, -0x41800000    # -0.25f

    .line 213
    .line 214
    const v21, 0x3ffc28f6    # 1.97f

    .line 215
    .line 216
    .line 217
    invoke-virtual/range {v17 .. v23}, Ly75;->c(FFFFFF)V

    .line 218
    .line 219
    .line 220
    move-object/from16 v2, v17

    .line 221
    .line 222
    const v3, 0x3fbae148    # 1.46f

    .line 223
    .line 224
    .line 225
    invoke-virtual {v2, v3, v3}, Ly75;->g(FF)V

    .line 226
    .line 227
    .line 228
    const/high16 v22, 0x41a00000    # 20.0f

    .line 229
    .line 230
    const/high16 v23, 0x41400000    # 12.0f

    .line 231
    .line 232
    const v18, 0x419c51ec    # 19.54f

    .line 233
    .line 234
    .line 235
    const v19, 0x41707ae1    # 15.03f

    .line 236
    .line 237
    .line 238
    const/high16 v20, 0x41a00000    # 20.0f

    .line 239
    .line 240
    const v21, 0x41591eb8    # 13.57f

    .line 241
    .line 242
    .line 243
    invoke-virtual/range {v17 .. v23}, Ly75;->b(FFFFFF)V

    .line 244
    .line 245
    .line 246
    const/high16 v22, -0x3f000000    # -8.0f

    .line 247
    .line 248
    const/high16 v23, -0x3f000000    # -8.0f

    .line 249
    .line 250
    const/16 v18, 0x0

    .line 251
    .line 252
    const v19, -0x3f728f5c    # -4.42f

    .line 253
    .line 254
    .line 255
    const v20, -0x3f9ae148    # -3.58f

    .line 256
    .line 257
    .line 258
    const/high16 v21, -0x3f000000    # -8.0f

    .line 259
    .line 260
    invoke-virtual/range {v17 .. v23}, Ly75;->c(FFFFFF)V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v2}, Ly75;->a()V

    .line 264
    .line 265
    .line 266
    const/high16 v3, 0x41900000    # 18.0f

    .line 267
    .line 268
    invoke-virtual {v2, v15, v3}, Ly75;->h(FF)V

    .line 269
    .line 270
    .line 271
    const/high16 v22, -0x3f400000    # -6.0f

    .line 272
    .line 273
    const/high16 v23, -0x3f400000    # -6.0f

    .line 274
    .line 275
    const v18, -0x3fac28f6    # -3.31f

    .line 276
    .line 277
    .line 278
    const/16 v19, 0x0

    .line 279
    .line 280
    const/high16 v20, -0x3f400000    # -6.0f

    .line 281
    .line 282
    const v21, -0x3fd3d70a    # -2.69f

    .line 283
    .line 284
    .line 285
    invoke-virtual/range {v17 .. v23}, Ly75;->c(FFFFFF)V

    .line 286
    .line 287
    .line 288
    const v22, 0x3f333333    # 0.7f

    .line 289
    .line 290
    .line 291
    const v23, -0x3fcccccd    # -2.8f

    .line 292
    .line 293
    .line 294
    const/16 v18, 0x0

    .line 295
    .line 296
    const v19, -0x407eb852    # -1.01f

    .line 297
    .line 298
    .line 299
    const/high16 v20, 0x3e800000    # 0.25f

    .line 300
    .line 301
    const v21, -0x4003d70a    # -1.97f

    .line 302
    .line 303
    .line 304
    invoke-virtual/range {v17 .. v23}, Ly75;->c(FFFFFF)V

    .line 305
    .line 306
    .line 307
    const v3, 0x40a7ae14    # 5.24f

    .line 308
    .line 309
    .line 310
    const v4, 0x40f7ae14    # 7.74f

    .line 311
    .line 312
    .line 313
    invoke-virtual {v2, v3, v4}, Ly75;->f(FF)V

    .line 314
    .line 315
    .line 316
    const/high16 v22, 0x40800000    # 4.0f

    .line 317
    .line 318
    const/high16 v23, 0x41400000    # 12.0f

    .line 319
    .line 320
    const v18, 0x408eb852    # 4.46f

    .line 321
    .line 322
    .line 323
    const v19, 0x410f851f    # 8.97f

    .line 324
    .line 325
    .line 326
    const/high16 v20, 0x40800000    # 4.0f

    .line 327
    .line 328
    const v21, 0x4126e148    # 10.43f

    .line 329
    .line 330
    .line 331
    invoke-virtual/range {v17 .. v23}, Ly75;->b(FFFFFF)V

    .line 332
    .line 333
    .line 334
    const/high16 v22, 0x41000000    # 8.0f

    .line 335
    .line 336
    const/high16 v23, 0x41000000    # 8.0f

    .line 337
    .line 338
    const/16 v18, 0x0

    .line 339
    .line 340
    const v19, 0x408d70a4    # 4.42f

    .line 341
    .line 342
    .line 343
    const v20, 0x40651eb8    # 3.58f

    .line 344
    .line 345
    .line 346
    const/high16 v21, 0x41000000    # 8.0f

    .line 347
    .line 348
    invoke-virtual/range {v17 .. v23}, Ly75;->c(FFFFFF)V

    .line 349
    .line 350
    .line 351
    const/high16 v3, 0x40400000    # 3.0f

    .line 352
    .line 353
    invoke-virtual {v2, v3}, Ly75;->m(F)V

    .line 354
    .line 355
    .line 356
    const/high16 v4, -0x3f800000    # -4.0f

    .line 357
    .line 358
    invoke-virtual {v2, v9, v4}, Ly75;->g(FF)V

    .line 359
    .line 360
    .line 361
    invoke-virtual {v2, v4, v4}, Ly75;->g(FF)V

    .line 362
    .line 363
    .line 364
    invoke-virtual {v2, v3}, Ly75;->m(F)V

    .line 365
    .line 366
    .line 367
    invoke-virtual {v2}, Ly75;->a()V

    .line 368
    .line 369
    .line 370
    iget-object v2, v2, Ly75;->a:Ljava/util/ArrayList;

    .line 371
    .line 372
    const/16 v25, 0x3800

    .line 373
    .line 374
    const/16 v18, 0x0

    .line 375
    .line 376
    const/16 v20, 0x0

    .line 377
    .line 378
    const/high16 v21, 0x3f800000    # 1.0f

    .line 379
    .line 380
    const/16 v22, 0x0

    .line 381
    .line 382
    const/16 v23, 0x2

    .line 383
    .line 384
    const/high16 v24, 0x3f800000    # 1.0f

    .line 385
    .line 386
    move-object/from16 v19, v0

    .line 387
    .line 388
    move-object/from16 v17, v2

    .line 389
    .line 390
    invoke-static/range {v16 .. v25}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 391
    .line 392
    .line 393
    invoke-virtual/range {v16 .. v16}, Lz43;->c()La53;

    .line 394
    .line 395
    .line 396
    move-result-object v0

    .line 397
    sput-object v0, Lvl6;->a:La53;

    .line 398
    .line 399
    :cond_3
    :goto_0
    move-object v9, v0

    .line 400
    goto/16 :goto_1

    .line 401
    .line 402
    :cond_4
    invoke-static {}, Lfb1;->a()V

    .line 403
    .line 404
    .line 405
    const/4 v1, 0x0

    .line 406
    goto/16 :goto_2

    .line 407
    .line 408
    :cond_5
    sget-object v0, Lcj;->b:La53;

    .line 409
    .line 410
    if-nez v0, :cond_3

    .line 411
    .line 412
    new-instance v19, Lz43;

    .line 413
    .line 414
    const/16 v27, 0x0

    .line 415
    .line 416
    const/16 v29, 0x60

    .line 417
    .line 418
    const-string v20, "Outlined.ErrorOutline"

    .line 419
    .line 420
    const/high16 v21, 0x41c00000    # 24.0f

    .line 421
    .line 422
    const/high16 v22, 0x41c00000    # 24.0f

    .line 423
    .line 424
    const/high16 v23, 0x41c00000    # 24.0f

    .line 425
    .line 426
    const/high16 v24, 0x41c00000    # 24.0f

    .line 427
    .line 428
    const-wide/16 v25, 0x0

    .line 429
    .line 430
    const/16 v28, 0x0

    .line 431
    .line 432
    invoke-direct/range {v19 .. v29}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 433
    .line 434
    .line 435
    new-instance v0, Lnw6;

    .line 436
    .line 437
    invoke-direct {v0, v3, v4}, Lnw6;-><init>(J)V

    .line 438
    .line 439
    .line 440
    new-instance v3, Ly75;

    .line 441
    .line 442
    invoke-direct {v3}, Ly75;-><init>()V

    .line 443
    .line 444
    .line 445
    const/high16 v4, 0x41700000    # 15.0f

    .line 446
    .line 447
    invoke-virtual {v3, v10, v4}, Ly75;->h(FF)V

    .line 448
    .line 449
    .line 450
    invoke-virtual {v3, v12}, Ly75;->e(F)V

    .line 451
    .line 452
    .line 453
    invoke-virtual {v3, v12}, Ly75;->m(F)V

    .line 454
    .line 455
    .line 456
    invoke-virtual {v3, v13}, Ly75;->e(F)V

    .line 457
    .line 458
    .line 459
    invoke-virtual {v3, v13}, Ly75;->m(F)V

    .line 460
    .line 461
    .line 462
    invoke-virtual {v3}, Ly75;->a()V

    .line 463
    .line 464
    .line 465
    invoke-virtual {v3, v10, v11}, Ly75;->h(FF)V

    .line 466
    .line 467
    .line 468
    invoke-virtual {v3, v12}, Ly75;->e(F)V

    .line 469
    .line 470
    .line 471
    invoke-virtual {v3, v5}, Ly75;->m(F)V

    .line 472
    .line 473
    .line 474
    invoke-virtual {v3, v13}, Ly75;->e(F)V

    .line 475
    .line 476
    .line 477
    invoke-virtual {v3, v10, v11}, Ly75;->f(FF)V

    .line 478
    .line 479
    .line 480
    invoke-virtual {v3}, Ly75;->a()V

    .line 481
    .line 482
    .line 483
    const v4, 0x413fd70a    # 11.99f

    .line 484
    .line 485
    .line 486
    invoke-virtual {v3, v4, v12}, Ly75;->h(FF)V

    .line 487
    .line 488
    .line 489
    const/high16 v25, 0x40000000    # 2.0f

    .line 490
    .line 491
    const/high16 v26, 0x41400000    # 12.0f

    .line 492
    .line 493
    const v21, 0x40cf0a3d    # 6.47f

    .line 494
    .line 495
    .line 496
    const/high16 v22, 0x40000000    # 2.0f

    .line 497
    .line 498
    const/high16 v23, 0x40000000    # 2.0f

    .line 499
    .line 500
    const v24, 0x40cf5c29    # 6.48f

    .line 501
    .line 502
    .line 503
    move-object/from16 v20, v3

    .line 504
    .line 505
    invoke-virtual/range {v20 .. v26}, Ly75;->b(FFFFFF)V

    .line 506
    .line 507
    .line 508
    const v5, 0x408f0a3d    # 4.47f

    .line 509
    .line 510
    .line 511
    const v6, 0x411fd70a    # 9.99f

    .line 512
    .line 513
    .line 514
    const/high16 v7, 0x41200000    # 10.0f

    .line 515
    .line 516
    invoke-virtual {v3, v5, v7, v6, v7}, Ly75;->k(FFFF)V

    .line 517
    .line 518
    .line 519
    const/high16 v25, 0x41b00000    # 22.0f

    .line 520
    .line 521
    const v21, 0x418c28f6    # 17.52f

    .line 522
    .line 523
    .line 524
    const/high16 v22, 0x41b00000    # 22.0f

    .line 525
    .line 526
    const/high16 v23, 0x41b00000    # 22.0f

    .line 527
    .line 528
    const v24, 0x418c28f6    # 17.52f

    .line 529
    .line 530
    .line 531
    invoke-virtual/range {v20 .. v26}, Ly75;->b(FFFFFF)V

    .line 532
    .line 533
    .line 534
    const v5, 0x418c28f6    # 17.52f

    .line 535
    .line 536
    .line 537
    invoke-virtual {v3, v5, v12, v4, v12}, Ly75;->j(FFFF)V

    .line 538
    .line 539
    .line 540
    invoke-virtual {v3}, Ly75;->a()V

    .line 541
    .line 542
    .line 543
    const/high16 v4, 0x41a00000    # 20.0f

    .line 544
    .line 545
    invoke-virtual {v3, v15, v4}, Ly75;->h(FF)V

    .line 546
    .line 547
    .line 548
    const/high16 v25, -0x3f000000    # -8.0f

    .line 549
    .line 550
    const/high16 v26, -0x3f000000    # -8.0f

    .line 551
    .line 552
    const v21, -0x3f728f5c    # -4.42f

    .line 553
    .line 554
    .line 555
    const/16 v22, 0x0

    .line 556
    .line 557
    const/high16 v23, -0x3f000000    # -8.0f

    .line 558
    .line 559
    const v24, -0x3f9ae148    # -3.58f

    .line 560
    .line 561
    .line 562
    invoke-virtual/range {v20 .. v26}, Ly75;->c(FFFFFF)V

    .line 563
    .line 564
    .line 565
    const v4, 0x40651eb8    # 3.58f

    .line 566
    .line 567
    .line 568
    const/high16 v5, -0x3f000000    # -8.0f

    .line 569
    .line 570
    invoke-virtual {v3, v4, v5, v2, v5}, Ly75;->k(FFFF)V

    .line 571
    .line 572
    .line 573
    invoke-virtual {v3, v2, v4, v2, v2}, Ly75;->k(FFFF)V

    .line 574
    .line 575
    .line 576
    const v4, -0x3f9ae148    # -3.58f

    .line 577
    .line 578
    .line 579
    invoke-virtual {v3, v4, v2, v5, v2}, Ly75;->k(FFFF)V

    .line 580
    .line 581
    .line 582
    invoke-virtual {v3}, Ly75;->a()V

    .line 583
    .line 584
    .line 585
    iget-object v2, v3, Ly75;->a:Ljava/util/ArrayList;

    .line 586
    .line 587
    const/16 v28, 0x3800

    .line 588
    .line 589
    const/16 v21, 0x0

    .line 590
    .line 591
    const/16 v23, 0x0

    .line 592
    .line 593
    const/high16 v24, 0x3f800000    # 1.0f

    .line 594
    .line 595
    const/16 v25, 0x0

    .line 596
    .line 597
    const/16 v26, 0x2

    .line 598
    .line 599
    const/high16 v27, 0x3f800000    # 1.0f

    .line 600
    .line 601
    move-object/from16 v22, v0

    .line 602
    .line 603
    move-object/from16 v20, v2

    .line 604
    .line 605
    invoke-static/range {v19 .. v28}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 606
    .line 607
    .line 608
    invoke-virtual/range {v19 .. v19}, Lz43;->c()La53;

    .line 609
    .line 610
    .line 611
    move-result-object v0

    .line 612
    sput-object v0, Lcj;->b:La53;

    .line 613
    .line 614
    goto/16 :goto_0

    .line 615
    .line 616
    :cond_6
    sget-object v0, Lkk;->i:La53;

    .line 617
    .line 618
    if-nez v0, :cond_3

    .line 619
    .line 620
    new-instance v19, Lz43;

    .line 621
    .line 622
    const/16 v27, 0x0

    .line 623
    .line 624
    const/16 v29, 0x60

    .line 625
    .line 626
    const-string v20, "Outlined.DoNotDisturbOn"

    .line 627
    .line 628
    const/high16 v21, 0x41c00000    # 24.0f

    .line 629
    .line 630
    const/high16 v22, 0x41c00000    # 24.0f

    .line 631
    .line 632
    const/high16 v23, 0x41c00000    # 24.0f

    .line 633
    .line 634
    const/high16 v24, 0x41c00000    # 24.0f

    .line 635
    .line 636
    const-wide/16 v25, 0x0

    .line 637
    .line 638
    const/16 v28, 0x0

    .line 639
    .line 640
    invoke-direct/range {v19 .. v29}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 641
    .line 642
    .line 643
    new-instance v0, Lnw6;

    .line 644
    .line 645
    invoke-direct {v0, v3, v4}, Lnw6;-><init>(J)V

    .line 646
    .line 647
    .line 648
    new-instance v3, Ly75;

    .line 649
    .line 650
    invoke-direct {v3}, Ly75;-><init>()V

    .line 651
    .line 652
    .line 653
    invoke-virtual {v3, v11, v10}, Ly75;->h(FF)V

    .line 654
    .line 655
    .line 656
    invoke-virtual {v3, v12}, Ly75;->m(F)V

    .line 657
    .line 658
    .line 659
    const/high16 v7, 0x41200000    # 10.0f

    .line 660
    .line 661
    invoke-virtual {v3, v7}, Ly75;->e(F)V

    .line 662
    .line 663
    .line 664
    invoke-virtual {v3, v13}, Ly75;->m(F)V

    .line 665
    .line 666
    .line 667
    invoke-virtual {v3, v11}, Ly75;->d(F)V

    .line 668
    .line 669
    .line 670
    invoke-virtual {v3}, Ly75;->a()V

    .line 671
    .line 672
    .line 673
    invoke-virtual {v3, v15, v12}, Ly75;->h(FF)V

    .line 674
    .line 675
    .line 676
    const/high16 v25, 0x40000000    # 2.0f

    .line 677
    .line 678
    const/high16 v26, 0x41400000    # 12.0f

    .line 679
    .line 680
    const v21, 0x40cf5c29    # 6.48f

    .line 681
    .line 682
    .line 683
    const/high16 v22, 0x40000000    # 2.0f

    .line 684
    .line 685
    const/high16 v23, 0x40000000    # 2.0f

    .line 686
    .line 687
    const v24, 0x40cf5c29    # 6.48f

    .line 688
    .line 689
    .line 690
    move-object/from16 v20, v3

    .line 691
    .line 692
    invoke-virtual/range {v20 .. v26}, Ly75;->b(FFFFFF)V

    .line 693
    .line 694
    .line 695
    const v4, 0x408f5c29    # 4.48f

    .line 696
    .line 697
    .line 698
    const/high16 v7, 0x41200000    # 10.0f

    .line 699
    .line 700
    invoke-virtual {v3, v4, v7, v7, v7}, Ly75;->k(FFFF)V

    .line 701
    .line 702
    .line 703
    const/high16 v4, -0x3ee00000    # -10.0f

    .line 704
    .line 705
    const v5, -0x3f70a3d7    # -4.48f

    .line 706
    .line 707
    .line 708
    invoke-virtual {v3, v7, v5, v7, v4}, Ly75;->k(FFFF)V

    .line 709
    .line 710
    .line 711
    const v5, 0x418c28f6    # 17.52f

    .line 712
    .line 713
    .line 714
    invoke-virtual {v3, v5, v12, v15, v12}, Ly75;->j(FFFF)V

    .line 715
    .line 716
    .line 717
    invoke-virtual {v3}, Ly75;->a()V

    .line 718
    .line 719
    .line 720
    const/high16 v4, 0x41a00000    # 20.0f

    .line 721
    .line 722
    invoke-virtual {v3, v15, v4}, Ly75;->h(FF)V

    .line 723
    .line 724
    .line 725
    const/high16 v25, -0x3f000000    # -8.0f

    .line 726
    .line 727
    const/high16 v26, -0x3f000000    # -8.0f

    .line 728
    .line 729
    const v21, -0x3f72e148    # -4.41f

    .line 730
    .line 731
    .line 732
    const/16 v22, 0x0

    .line 733
    .line 734
    const/high16 v23, -0x3f000000    # -8.0f

    .line 735
    .line 736
    const v24, -0x3f9a3d71    # -3.59f

    .line 737
    .line 738
    .line 739
    invoke-virtual/range {v20 .. v26}, Ly75;->c(FFFFFF)V

    .line 740
    .line 741
    .line 742
    const v5, 0x4065c28f    # 3.59f

    .line 743
    .line 744
    .line 745
    const/high16 v6, -0x3f000000    # -8.0f

    .line 746
    .line 747
    invoke-virtual {v3, v5, v6, v2, v6}, Ly75;->k(FFFF)V

    .line 748
    .line 749
    .line 750
    invoke-virtual {v3, v2, v5, v2, v2}, Ly75;->k(FFFF)V

    .line 751
    .line 752
    .line 753
    const v2, 0x418347ae    # 16.41f

    .line 754
    .line 755
    .line 756
    invoke-virtual {v3, v2, v4, v15, v4}, Ly75;->j(FFFF)V

    .line 757
    .line 758
    .line 759
    invoke-virtual {v3}, Ly75;->a()V

    .line 760
    .line 761
    .line 762
    iget-object v2, v3, Ly75;->a:Ljava/util/ArrayList;

    .line 763
    .line 764
    const/16 v28, 0x3800

    .line 765
    .line 766
    const/16 v21, 0x0

    .line 767
    .line 768
    const/16 v23, 0x0

    .line 769
    .line 770
    const/high16 v24, 0x3f800000    # 1.0f

    .line 771
    .line 772
    const/16 v25, 0x0

    .line 773
    .line 774
    const/16 v26, 0x2

    .line 775
    .line 776
    const/high16 v27, 0x3f800000    # 1.0f

    .line 777
    .line 778
    move-object/from16 v22, v0

    .line 779
    .line 780
    move-object/from16 v20, v2

    .line 781
    .line 782
    invoke-static/range {v19 .. v28}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 783
    .line 784
    .line 785
    invoke-virtual/range {v19 .. v19}, Lz43;->c()La53;

    .line 786
    .line 787
    .line 788
    move-result-object v0

    .line 789
    sput-object v0, Lkk;->i:La53;

    .line 790
    .line 791
    goto/16 :goto_0

    .line 792
    .line 793
    :cond_7
    sget-object v0, Lel;->b:La53;

    .line 794
    .line 795
    if-eqz v0, :cond_8

    .line 796
    .line 797
    goto/16 :goto_0

    .line 798
    .line 799
    :cond_8
    new-instance v19, Lz43;

    .line 800
    .line 801
    const/16 v27, 0x0

    .line 802
    .line 803
    const/16 v29, 0x60

    .line 804
    .line 805
    const-string v20, "Outlined.CheckCircle"

    .line 806
    .line 807
    const/high16 v21, 0x41c00000    # 24.0f

    .line 808
    .line 809
    const/high16 v22, 0x41c00000    # 24.0f

    .line 810
    .line 811
    const/high16 v23, 0x41c00000    # 24.0f

    .line 812
    .line 813
    const/high16 v24, 0x41c00000    # 24.0f

    .line 814
    .line 815
    const-wide/16 v25, 0x0

    .line 816
    .line 817
    const/16 v28, 0x0

    .line 818
    .line 819
    invoke-direct/range {v19 .. v29}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 820
    .line 821
    .line 822
    new-instance v0, Lnw6;

    .line 823
    .line 824
    invoke-direct {v0, v3, v4}, Lnw6;-><init>(J)V

    .line 825
    .line 826
    .line 827
    invoke-static {v15, v12}, Lx82;->j(FF)Ly75;

    .line 828
    .line 829
    .line 830
    move-result-object v20

    .line 831
    const/high16 v25, 0x40000000    # 2.0f

    .line 832
    .line 833
    const/high16 v26, 0x41400000    # 12.0f

    .line 834
    .line 835
    const v21, 0x40cf5c29    # 6.48f

    .line 836
    .line 837
    .line 838
    const/high16 v22, 0x40000000    # 2.0f

    .line 839
    .line 840
    const/high16 v23, 0x40000000    # 2.0f

    .line 841
    .line 842
    const v24, 0x40cf5c29    # 6.48f

    .line 843
    .line 844
    .line 845
    invoke-virtual/range {v20 .. v26}, Ly75;->b(FFFFFF)V

    .line 846
    .line 847
    .line 848
    move-object/from16 v3, v20

    .line 849
    .line 850
    const v4, 0x408f5c29    # 4.48f

    .line 851
    .line 852
    .line 853
    const/high16 v7, 0x41200000    # 10.0f

    .line 854
    .line 855
    invoke-virtual {v3, v4, v7, v7, v7}, Ly75;->k(FFFF)V

    .line 856
    .line 857
    .line 858
    const/high16 v4, -0x3ee00000    # -10.0f

    .line 859
    .line 860
    const v6, -0x3f70a3d7    # -4.48f

    .line 861
    .line 862
    .line 863
    invoke-virtual {v3, v7, v6, v7, v4}, Ly75;->k(FFFF)V

    .line 864
    .line 865
    .line 866
    const v4, 0x418c28f6    # 17.52f

    .line 867
    .line 868
    .line 869
    invoke-virtual {v3, v4, v12, v15, v12}, Ly75;->j(FFFF)V

    .line 870
    .line 871
    .line 872
    invoke-virtual {v3}, Ly75;->a()V

    .line 873
    .line 874
    .line 875
    const/high16 v4, 0x41a00000    # 20.0f

    .line 876
    .line 877
    invoke-virtual {v3, v15, v4}, Ly75;->h(FF)V

    .line 878
    .line 879
    .line 880
    const/high16 v25, -0x3f000000    # -8.0f

    .line 881
    .line 882
    const/high16 v26, -0x3f000000    # -8.0f

    .line 883
    .line 884
    const v21, -0x3f72e148    # -4.41f

    .line 885
    .line 886
    .line 887
    const/16 v22, 0x0

    .line 888
    .line 889
    const/high16 v23, -0x3f000000    # -8.0f

    .line 890
    .line 891
    const v24, -0x3f9a3d71    # -3.59f

    .line 892
    .line 893
    .line 894
    invoke-virtual/range {v20 .. v26}, Ly75;->c(FFFFFF)V

    .line 895
    .line 896
    .line 897
    const v4, 0x4065c28f    # 3.59f

    .line 898
    .line 899
    .line 900
    const/high16 v6, -0x3f000000    # -8.0f

    .line 901
    .line 902
    invoke-virtual {v3, v4, v6, v2, v6}, Ly75;->k(FFFF)V

    .line 903
    .line 904
    .line 905
    invoke-virtual {v3, v2, v4, v2, v2}, Ly75;->k(FFFF)V

    .line 906
    .line 907
    .line 908
    const v4, -0x3f9a3d71    # -3.59f

    .line 909
    .line 910
    .line 911
    invoke-virtual {v3, v4, v2, v6, v2}, Ly75;->k(FFFF)V

    .line 912
    .line 913
    .line 914
    invoke-virtual {v3}, Ly75;->a()V

    .line 915
    .line 916
    .line 917
    const v4, 0x4184b852    # 16.59f

    .line 918
    .line 919
    .line 920
    const v6, 0x40f28f5c    # 7.58f

    .line 921
    .line 922
    .line 923
    invoke-virtual {v3, v4, v6}, Ly75;->h(FF)V

    .line 924
    .line 925
    .line 926
    const v4, 0x4162b852    # 14.17f

    .line 927
    .line 928
    .line 929
    const/high16 v7, 0x41200000    # 10.0f

    .line 930
    .line 931
    invoke-virtual {v3, v7, v4}, Ly75;->f(FF)V

    .line 932
    .line 933
    .line 934
    const v4, -0x3fda3d71    # -2.59f

    .line 935
    .line 936
    .line 937
    const v6, -0x3fdae148    # -2.58f

    .line 938
    .line 939
    .line 940
    invoke-virtual {v3, v4, v6}, Ly75;->g(FF)V

    .line 941
    .line 942
    .line 943
    const/high16 v4, 0x41500000    # 13.0f

    .line 944
    .line 945
    invoke-virtual {v3, v5, v4}, Ly75;->f(FF)V

    .line 946
    .line 947
    .line 948
    invoke-virtual {v3, v9, v9}, Ly75;->g(FF)V

    .line 949
    .line 950
    .line 951
    const/high16 v6, -0x3f000000    # -8.0f

    .line 952
    .line 953
    invoke-virtual {v3, v2, v6}, Ly75;->g(FF)V

    .line 954
    .line 955
    .line 956
    invoke-virtual {v3}, Ly75;->a()V

    .line 957
    .line 958
    .line 959
    iget-object v2, v3, Ly75;->a:Ljava/util/ArrayList;

    .line 960
    .line 961
    const/16 v28, 0x3800

    .line 962
    .line 963
    const/16 v21, 0x0

    .line 964
    .line 965
    const/16 v23, 0x0

    .line 966
    .line 967
    const/high16 v24, 0x3f800000    # 1.0f

    .line 968
    .line 969
    const/16 v25, 0x0

    .line 970
    .line 971
    const/16 v26, 0x2

    .line 972
    .line 973
    const/high16 v27, 0x3f800000    # 1.0f

    .line 974
    .line 975
    move-object/from16 v22, v0

    .line 976
    .line 977
    move-object/from16 v20, v2

    .line 978
    .line 979
    invoke-static/range {v19 .. v28}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 980
    .line 981
    .line 982
    invoke-virtual/range {v19 .. v19}, Lz43;->c()La53;

    .line 983
    .line 984
    .line 985
    move-result-object v0

    .line 986
    sput-object v0, Lel;->b:La53;

    .line 987
    .line 988
    goto/16 :goto_0

    .line 989
    .line 990
    :goto_1
    invoke-static {v8, v14}, Ldj;->i0(Lvy2;Lki2;)J

    .line 991
    .line 992
    .line 993
    move-result-wide v12

    .line 994
    const/16 v15, 0x30

    .line 995
    .line 996
    const/16 v16, 0x4

    .line 997
    .line 998
    const/4 v10, 0x0

    .line 999
    const/4 v11, 0x0

    .line 1000
    invoke-static/range {v9 .. v16}, Lw33;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 1001
    .line 1002
    .line 1003
    goto :goto_2

    .line 1004
    :cond_9
    invoke-virtual {v14}, Lki2;->b0()V

    .line 1005
    .line 1006
    .line 1007
    :goto_2
    return-object v1

    .line 1008
    :pswitch_1
    move-object/from16 v0, p1

    .line 1009
    .line 1010
    check-cast v0, Luh;

    .line 1011
    .line 1012
    move-object/from16 v8, p2

    .line 1013
    .line 1014
    check-cast v8, Llh2;

    .line 1015
    .line 1016
    move-object/from16 v9, p3

    .line 1017
    .line 1018
    check-cast v9, Lki2;

    .line 1019
    .line 1020
    move-object/from16 v10, p4

    .line 1021
    .line 1022
    check-cast v10, Ljava/lang/Integer;

    .line 1023
    .line 1024
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 1025
    .line 1026
    .line 1027
    move-result v10

    .line 1028
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1029
    .line 1030
    .line 1031
    and-int/lit8 v0, v10, 0x30

    .line 1032
    .line 1033
    if-nez v0, :cond_b

    .line 1034
    .line 1035
    invoke-virtual {v9, v8}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1036
    .line 1037
    .line 1038
    move-result v0

    .line 1039
    if-eqz v0, :cond_a

    .line 1040
    .line 1041
    move v4, v5

    .line 1042
    :cond_a
    or-int/2addr v10, v4

    .line 1043
    :cond_b
    and-int/lit16 v0, v10, 0x91

    .line 1044
    .line 1045
    if-eq v0, v3, :cond_c

    .line 1046
    .line 1047
    move v0, v6

    .line 1048
    goto :goto_3

    .line 1049
    :cond_c
    move v0, v2

    .line 1050
    :goto_3
    and-int/lit8 v3, v10, 0x1

    .line 1051
    .line 1052
    invoke-virtual {v9, v3, v0}, Lki2;->Y(IZ)Z

    .line 1053
    .line 1054
    .line 1055
    move-result v0

    .line 1056
    if-eqz v0, :cond_f

    .line 1057
    .line 1058
    sget-object v0, Ly6;->j:La40;

    .line 1059
    .line 1060
    invoke-static {v0, v2}, Lxc0;->c(La40;Z)Ld14;

    .line 1061
    .line 1062
    .line 1063
    move-result-object v0

    .line 1064
    iget-wide v3, v9, Lki2;->U:J

    .line 1065
    .line 1066
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 1067
    .line 1068
    .line 1069
    move-result v3

    .line 1070
    invoke-virtual {v9}, Lki2;->m()Lr95;

    .line 1071
    .line 1072
    .line 1073
    move-result-object v4

    .line 1074
    sget-object v5, Lea4;->h:Lea4;

    .line 1075
    .line 1076
    invoke-static {v9, v5}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 1077
    .line 1078
    .line 1079
    move-result-object v5

    .line 1080
    sget-object v11, Lp41;->d:Ly6;

    .line 1081
    .line 1082
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1083
    .line 1084
    .line 1085
    invoke-virtual {v9}, Lki2;->k0()V

    .line 1086
    .line 1087
    .line 1088
    iget-boolean v11, v9, Lki2;->T:Z

    .line 1089
    .line 1090
    if-eqz v11, :cond_d

    .line 1091
    .line 1092
    sget-object v11, Lwi3;->Z:Lj43;

    .line 1093
    .line 1094
    invoke-virtual {v9, v11}, Lki2;->l(Lwg2;)V

    .line 1095
    .line 1096
    .line 1097
    goto :goto_4

    .line 1098
    :cond_d
    invoke-virtual {v9}, Lki2;->t0()V

    .line 1099
    .line 1100
    .line 1101
    :goto_4
    sget-object v11, Ly6;->T:Lu31;

    .line 1102
    .line 1103
    invoke-static {v11, v9, v0}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 1104
    .line 1105
    .line 1106
    sget-object v0, Ly6;->S:Lu31;

    .line 1107
    .line 1108
    invoke-static {v0, v9, v4}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 1109
    .line 1110
    .line 1111
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1112
    .line 1113
    .line 1114
    move-result-object v0

    .line 1115
    sget-object v3, Ly6;->U:Lu31;

    .line 1116
    .line 1117
    invoke-static {v3, v9, v0}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 1118
    .line 1119
    .line 1120
    invoke-static {v9}, Lml6;->p(Lki2;)V

    .line 1121
    .line 1122
    .line 1123
    sget-object v0, Ly6;->R:Lu31;

    .line 1124
    .line 1125
    invoke-static {v0, v9, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 1126
    .line 1127
    .line 1128
    if-nez v8, :cond_e

    .line 1129
    .line 1130
    const v0, -0x64c6a596

    .line 1131
    .line 1132
    .line 1133
    invoke-virtual {v9, v0}, Lki2;->h0(I)V

    .line 1134
    .line 1135
    .line 1136
    :goto_5
    invoke-virtual {v9, v2}, Lki2;->r(Z)V

    .line 1137
    .line 1138
    .line 1139
    goto :goto_6

    .line 1140
    :cond_e
    const v0, -0x4d92cb89

    .line 1141
    .line 1142
    .line 1143
    invoke-virtual {v9, v0}, Lki2;->h0(I)V

    .line 1144
    .line 1145
    .line 1146
    shr-int/2addr v10, v7

    .line 1147
    and-int/lit8 v10, v10, 0xe

    .line 1148
    .line 1149
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1150
    .line 1151
    .line 1152
    move-result-object v0

    .line 1153
    invoke-interface {v8, v9, v0}, Llh2;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1154
    .line 1155
    .line 1156
    goto :goto_5

    .line 1157
    :goto_6
    invoke-virtual {v9, v6}, Lki2;->r(Z)V

    .line 1158
    .line 1159
    .line 1160
    goto :goto_7

    .line 1161
    :cond_f
    invoke-virtual {v9}, Lki2;->b0()V

    .line 1162
    .line 1163
    .line 1164
    :goto_7
    return-object v1

    .line 1165
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
