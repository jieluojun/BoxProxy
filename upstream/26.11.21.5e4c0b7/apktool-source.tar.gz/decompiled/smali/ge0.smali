.class public final Lge0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lfe0;


# static fields
.field public static final a:Lge0;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lge0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lge0;->a:Lge0;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Lha4;Ln8;)Lha4;
    .locals 1

    .line 1
    new-instance p0, Lmc0;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-direct {p0, p2, v0}, Lmc0;-><init>(Ln8;Z)V

    .line 5
    .line 6
    .line 7
    invoke-interface {p1, p0}, Lha4;->b0(Lha4;)Lha4;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public final b(Lha4;)Lha4;
    .locals 2

    .line 1
    new-instance p0, Lmc0;

    .line 2
    .line 3
    sget-object v0, Ly6;->n:La40;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-direct {p0, v0, v1}, Lmc0;-><init>(Ln8;Z)V

    .line 7
    .line 8
    .line 9
    invoke-interface {p1, p0}, Lha4;->b0(Lha4;)Lha4;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method
