.class public final synthetic Lry7;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lzd4;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lry7;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lry7;->i:Lzd4;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lry7;->h:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    sget-object v2, Los7;->a:Los7;

    .line 5
    .line 6
    iget-object p0, p0, Lry7;->i:Lzd4;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    invoke-static {p0, v1}, Lx87;->f(Lzd4;Z)V

    .line 12
    .line 13
    .line 14
    return-object v2

    .line 15
    :pswitch_0
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 16
    .line 17
    invoke-interface {p0, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    return-object v2

    .line 21
    :pswitch_1
    invoke-static {p0, v1}, Lw04;->o(Lzd4;Z)V

    .line 22
    .line 23
    .line 24
    return-object v2

    .line 25
    :pswitch_2
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 26
    .line 27
    invoke-interface {p0, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-object v2

    .line 31
    :pswitch_3
    const/4 v0, 0x0

    .line 32
    invoke-static {p0, v0}, Lw04;->o(Lzd4;Z)V

    .line 33
    .line 34
    .line 35
    return-object v2

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
