.class public final Lf32;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lbo6;

.field public b:Z

.field public c:Lu22;

.field public d:Z

.field public e:Lg32;

.field public f:Lz42;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lbo6;

    .line 5
    .line 6
    invoke-direct {v0}, Lbo6;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lf32;->a:Lbo6;

    .line 10
    .line 11
    return-void
.end method
