.class public final Lb93;
.super Lor2;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final m:[I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lor2;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lb93;->m:[I

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(ILor2;Lhs7;[ILor2;)V
    .locals 0

    .line 8
    invoke-direct {p0, p1, p2, p3, p5}, Lor2;-><init>(ILor2;Ljava/lang/Object;Lor2;)V

    .line 9
    iput-object p4, p0, Lb93;->m:[I

    return-void
.end method
