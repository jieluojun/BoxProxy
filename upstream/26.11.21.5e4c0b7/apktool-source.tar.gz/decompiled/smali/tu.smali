.class public final synthetic Ltu;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:F

.field public final synthetic j:Z

.field public final synthetic k:Z

.field public final synthetic l:Z

.field public final synthetic m:Lhh2;

.field public final synthetic n:Z

.field public final synthetic o:Lwg2;

.field public final synthetic p:Lwg2;

.field public final synthetic q:Lwg2;

.field public final synthetic r:Ljava/lang/Object;

.field public final synthetic s:Ljava/lang/Object;

.field public final synthetic t:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(FZZZLhh2;ZLwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lwg2;I)V
    .locals 0

    .line 1
    const/4 p13, 0x1

    .line 2
    iput-byte p13, p0, Ltu;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Ltu;->i:F

    .line 8
    .line 9
    iput-boolean p2, p0, Ltu;->j:Z

    .line 10
    .line 11
    iput-boolean p3, p0, Ltu;->k:Z

    .line 12
    .line 13
    iput-boolean p4, p0, Ltu;->l:Z

    .line 14
    .line 15
    iput-object p5, p0, Ltu;->m:Lhh2;

    .line 16
    .line 17
    iput-boolean p6, p0, Ltu;->n:Z

    .line 18
    .line 19
    iput-object p7, p0, Ltu;->o:Lwg2;

    .line 20
    .line 21
    iput-object p8, p0, Ltu;->p:Lwg2;

    .line 22
    .line 23
    iput-object p9, p0, Ltu;->q:Lwg2;

    .line 24
    .line 25
    iput-object p10, p0, Ltu;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iput-object p11, p0, Ltu;->s:Ljava/lang/Object;

    .line 28
    .line 29
    iput-object p12, p0, Ltu;->t:Ljava/lang/Object;

    .line 30
    .line 31
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Lhh2;ZFLp64;ZZLjava/lang/String;Lwg2;ZLwg2;Lwg2;)V
    .locals 1

    .line 32
    const/4 v0, 0x0

    iput-byte v0, p0, Ltu;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ltu;->r:Ljava/lang/Object;

    iput-object p2, p0, Ltu;->m:Lhh2;

    iput-boolean p3, p0, Ltu;->j:Z

    iput p4, p0, Ltu;->i:F

    iput-object p5, p0, Ltu;->s:Ljava/lang/Object;

    iput-boolean p6, p0, Ltu;->k:Z

    iput-boolean p7, p0, Ltu;->l:Z

    iput-object p8, p0, Ltu;->t:Ljava/lang/Object;

    iput-object p9, p0, Ltu;->o:Lwg2;

    iput-boolean p10, p0, Ltu;->n:Z

    iput-object p11, p0, Ltu;->p:Lwg2;

    iput-object p12, p0, Ltu;->q:Lwg2;

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Ltu;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    iget-object v4, v0, Ltu;->t:Ljava/lang/Object;

    .line 9
    .line 10
    iget-object v5, v0, Ltu;->s:Ljava/lang/Object;

    .line 11
    .line 12
    iget-object v6, v0, Ltu;->r:Ljava/lang/Object;

    .line 13
    .line 14
    packed-switch v1, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    move-object/from16 v16, v6

    .line 18
    .line 19
    check-cast v16, Lwg2;

    .line 20
    .line 21
    move-object/from16 v17, v5

    .line 22
    .line 23
    check-cast v17, Lwg2;

    .line 24
    .line 25
    move-object/from16 v18, v4

    .line 26
    .line 27
    check-cast v18, Lwg2;

    .line 28
    .line 29
    move-object/from16 v19, p1

    .line 30
    .line 31
    check-cast v19, Lki2;

    .line 32
    .line 33
    move-object/from16 v1, p2

    .line 34
    .line 35
    check-cast v1, Ljava/lang/Integer;

    .line 36
    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    invoke-static {v3}, Ld43;->P(I)I

    .line 41
    .line 42
    .line 43
    move-result v20

    .line 44
    iget v7, v0, Ltu;->i:F

    .line 45
    .line 46
    iget-boolean v8, v0, Ltu;->j:Z

    .line 47
    .line 48
    iget-boolean v9, v0, Ltu;->k:Z

    .line 49
    .line 50
    iget-boolean v10, v0, Ltu;->l:Z

    .line 51
    .line 52
    iget-object v11, v0, Ltu;->m:Lhh2;

    .line 53
    .line 54
    iget-boolean v12, v0, Ltu;->n:Z

    .line 55
    .line 56
    iget-object v13, v0, Ltu;->o:Lwg2;

    .line 57
    .line 58
    iget-object v14, v0, Ltu;->p:Lwg2;

    .line 59
    .line 60
    iget-object v15, v0, Ltu;->q:Lwg2;

    .line 61
    .line 62
    invoke-static/range {v7 .. v20}, Lo80;->m(FZZZLhh2;ZLwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lki2;I)V

    .line 63
    .line 64
    .line 65
    return-object v2

    .line 66
    :pswitch_0
    move-object/from16 v22, v6

    .line 67
    .line 68
    check-cast v22, Ljava/util/List;

    .line 69
    .line 70
    move-object/from16 v26, v5

    .line 71
    .line 72
    check-cast v26, Lp64;

    .line 73
    .line 74
    move-object/from16 v29, v4

    .line 75
    .line 76
    check-cast v29, Ljava/lang/String;

    .line 77
    .line 78
    move-object/from16 v14, p1

    .line 79
    .line 80
    check-cast v14, Lki2;

    .line 81
    .line 82
    move-object/from16 v1, p2

    .line 83
    .line 84
    check-cast v1, Ljava/lang/Integer;

    .line 85
    .line 86
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 87
    .line 88
    .line 89
    move-result v1

    .line 90
    and-int/lit8 v4, v1, 0x3

    .line 91
    .line 92
    const/4 v5, 0x2

    .line 93
    const/4 v6, 0x0

    .line 94
    if-eq v4, v5, :cond_0

    .line 95
    .line 96
    move v4, v3

    .line 97
    goto :goto_0

    .line 98
    :cond_0
    move v4, v6

    .line 99
    :goto_0
    and-int/2addr v1, v3

    .line 100
    invoke-virtual {v14, v1, v4}, Lki2;->Y(IZ)Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    if-eqz v1, :cond_7

    .line 105
    .line 106
    sget-object v1, Lea4;->h:Lea4;

    .line 107
    .line 108
    const/high16 v4, 0x3f800000    # 1.0f

    .line 109
    .line 110
    invoke-static {v1, v4}, Lit6;->e(Lha4;F)Lha4;

    .line 111
    .line 112
    .line 113
    move-result-object v7

    .line 114
    sget-object v8, Lx87;->e:Lsw;

    .line 115
    .line 116
    sget-object v9, Ly6;->v:Ly30;

    .line 117
    .line 118
    invoke-static {v8, v9, v14, v6}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 119
    .line 120
    .line 121
    move-result-object v6

    .line 122
    iget-wide v8, v14, Lki2;->U:J

    .line 123
    .line 124
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 125
    .line 126
    .line 127
    move-result v8

    .line 128
    invoke-virtual {v14}, Lki2;->m()Lr95;

    .line 129
    .line 130
    .line 131
    move-result-object v9

    .line 132
    invoke-static {v14, v7}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 133
    .line 134
    .line 135
    move-result-object v7

    .line 136
    sget-object v10, Lp41;->d:Ly6;

    .line 137
    .line 138
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 139
    .line 140
    .line 141
    invoke-virtual {v14}, Lki2;->k0()V

    .line 142
    .line 143
    .line 144
    iget-boolean v10, v14, Lki2;->T:Z

    .line 145
    .line 146
    sget-object v11, Lwi3;->Z:Lj43;

    .line 147
    .line 148
    if-eqz v10, :cond_1

    .line 149
    .line 150
    invoke-virtual {v14, v11}, Lki2;->l(Lwg2;)V

    .line 151
    .line 152
    .line 153
    goto :goto_1

    .line 154
    :cond_1
    invoke-virtual {v14}, Lki2;->t0()V

    .line 155
    .line 156
    .line 157
    :goto_1
    sget-object v10, Ly6;->T:Lu31;

    .line 158
    .line 159
    invoke-static {v10, v14, v6}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 160
    .line 161
    .line 162
    sget-object v6, Ly6;->S:Lu31;

    .line 163
    .line 164
    invoke-static {v6, v14, v9}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 168
    .line 169
    .line 170
    move-result-object v8

    .line 171
    sget-object v9, Ly6;->U:Lu31;

    .line 172
    .line 173
    invoke-static {v9, v14, v8}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    invoke-static {v14}, Lml6;->p(Lki2;)V

    .line 177
    .line 178
    .line 179
    sget-object v8, Ly6;->R:Lu31;

    .line 180
    .line 181
    invoke-static {v8, v14, v7}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 182
    .line 183
    .line 184
    invoke-static {v14}, Lug6;->v(Lki2;)Lxl0;

    .line 185
    .line 186
    .line 187
    move-result-object v7

    .line 188
    new-instance v21, Luu;

    .line 189
    .line 190
    iget-object v12, v0, Ltu;->m:Lhh2;

    .line 191
    .line 192
    iget-boolean v13, v0, Ltu;->j:Z

    .line 193
    .line 194
    iget v15, v0, Ltu;->i:F

    .line 195
    .line 196
    iget-boolean v4, v0, Ltu;->k:Z

    .line 197
    .line 198
    iget-boolean v5, v0, Ltu;->l:Z

    .line 199
    .line 200
    iget-object v3, v0, Ltu;->o:Lwg2;

    .line 201
    .line 202
    move-object/from16 v30, v3

    .line 203
    .line 204
    move/from16 v27, v4

    .line 205
    .line 206
    move/from16 v28, v5

    .line 207
    .line 208
    move-object/from16 v23, v12

    .line 209
    .line 210
    move/from16 v24, v13

    .line 211
    .line 212
    move/from16 v25, v15

    .line 213
    .line 214
    invoke-direct/range {v21 .. v30}, Luu;-><init>(Ljava/util/List;Lhh2;ZFLp64;ZZLjava/lang/String;Lwg2;)V

    .line 215
    .line 216
    .line 217
    move-object/from16 v3, v21

    .line 218
    .line 219
    const v4, -0xf412caa

    .line 220
    .line 221
    .line 222
    invoke-static {v4, v3, v14}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 223
    .line 224
    .line 225
    move-result-object v15

    .line 226
    const/16 v17, 0x0

    .line 227
    .line 228
    const/16 v18, 0x7f7

    .line 229
    .line 230
    const/4 v4, 0x0

    .line 231
    const/4 v5, 0x0

    .line 232
    move-object v3, v6

    .line 233
    const/4 v6, 0x0

    .line 234
    move-object v12, v8

    .line 235
    const/4 v8, 0x0

    .line 236
    move-object v13, v9

    .line 237
    const/4 v9, 0x0

    .line 238
    move-object/from16 v16, v10

    .line 239
    .line 240
    const/4 v10, 0x0

    .line 241
    move-object/from16 v20, v11

    .line 242
    .line 243
    const/4 v11, 0x0

    .line 244
    move-object/from16 v21, v12

    .line 245
    .line 246
    const/4 v12, 0x0

    .line 247
    move-object/from16 v23, v13

    .line 248
    .line 249
    move-object/from16 v22, v16

    .line 250
    .line 251
    move-object/from16 v16, v14

    .line 252
    .line 253
    const-wide/16 v13, 0x0

    .line 254
    .line 255
    move-object/from16 v33, v20

    .line 256
    .line 257
    move-object/from16 v31, v21

    .line 258
    .line 259
    move/from16 v32, v24

    .line 260
    .line 261
    const/high16 v0, 0x3f800000    # 1.0f

    .line 262
    .line 263
    move-object/from16 v20, v2

    .line 264
    .line 265
    move-object v2, v3

    .line 266
    move-object/from16 v3, v22

    .line 267
    .line 268
    invoke-static/range {v4 .. v18}, Ll64;->a(Lha4;FLu35;Lxl0;Lye5;ZLwg2;Lwg2;ZJLq21;Lki2;II)V

    .line 269
    .line 270
    .line 271
    move-object/from16 v14, v16

    .line 272
    .line 273
    const/high16 v4, 0x41400000    # 12.0f

    .line 274
    .line 275
    invoke-static {v1, v4}, Lit6;->f(Lha4;F)Lha4;

    .line 276
    .line 277
    .line 278
    move-result-object v4

    .line 279
    invoke-static {v14, v4}, Lck6;->b(Lki2;Lha4;)V

    .line 280
    .line 281
    .line 282
    invoke-static {v1, v0}, Lit6;->e(Lha4;F)Lha4;

    .line 283
    .line 284
    .line 285
    move-result-object v4

    .line 286
    sget-object v5, Lx87;->i:Ln28;

    .line 287
    .line 288
    sget-object v6, Ly6;->s:Lz30;

    .line 289
    .line 290
    const/4 v7, 0x6

    .line 291
    invoke-static {v5, v6, v14, v7}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 292
    .line 293
    .line 294
    move-result-object v5

    .line 295
    iget-wide v6, v14, Lki2;->U:J

    .line 296
    .line 297
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 298
    .line 299
    .line 300
    move-result v6

    .line 301
    invoke-virtual {v14}, Lki2;->m()Lr95;

    .line 302
    .line 303
    .line 304
    move-result-object v7

    .line 305
    invoke-static {v14, v4}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 306
    .line 307
    .line 308
    move-result-object v4

    .line 309
    invoke-virtual {v14}, Lki2;->k0()V

    .line 310
    .line 311
    .line 312
    iget-boolean v8, v14, Lki2;->T:Z

    .line 313
    .line 314
    if-eqz v8, :cond_2

    .line 315
    .line 316
    move-object/from16 v8, v33

    .line 317
    .line 318
    invoke-virtual {v14, v8}, Lki2;->l(Lwg2;)V

    .line 319
    .line 320
    .line 321
    goto :goto_2

    .line 322
    :cond_2
    invoke-virtual {v14}, Lki2;->t0()V

    .line 323
    .line 324
    .line 325
    :goto_2
    invoke-static {v3, v14, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 326
    .line 327
    .line 328
    invoke-static {v2, v14, v7}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 329
    .line 330
    .line 331
    move-object/from16 v13, v23

    .line 332
    .line 333
    invoke-static {v6, v14, v13, v14}, Lx82;->w(ILki2;Lu31;Lki2;)V

    .line 334
    .line 335
    .line 336
    move-object/from16 v12, v31

    .line 337
    .line 338
    invoke-static {v12, v14, v4}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 339
    .line 340
    .line 341
    const v2, 0x7f0f0033

    .line 342
    .line 343
    .line 344
    invoke-static {v2, v14}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 345
    .line 346
    .line 347
    move-result-object v4

    .line 348
    move-object/from16 v2, p0

    .line 349
    .line 350
    iget-boolean v3, v2, Ltu;->n:Z

    .line 351
    .line 352
    invoke-virtual {v14, v3}, Lki2;->h(Z)Z

    .line 353
    .line 354
    .line 355
    move-result v5

    .line 356
    iget-object v6, v2, Ltu;->p:Lwg2;

    .line 357
    .line 358
    invoke-virtual {v14, v6}, Lki2;->g(Ljava/lang/Object;)Z

    .line 359
    .line 360
    .line 361
    move-result v7

    .line 362
    or-int/2addr v5, v7

    .line 363
    invoke-virtual {v14}, Lki2;->T()Ljava/lang/Object;

    .line 364
    .line 365
    .line 366
    move-result-object v7

    .line 367
    sget-object v8, Lz41;->a:Lql0;

    .line 368
    .line 369
    if-nez v5, :cond_3

    .line 370
    .line 371
    if-ne v7, v8, :cond_4

    .line 372
    .line 373
    :cond_3
    new-instance v7, Llt;

    .line 374
    .line 375
    const/4 v5, 0x2

    .line 376
    invoke-direct {v7, v3, v6, v5}, Llt;-><init>(ZLwg2;B)V

    .line 377
    .line 378
    .line 379
    invoke-virtual {v14, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 380
    .line 381
    .line 382
    :cond_4
    move-object v5, v7

    .line 383
    check-cast v5, Lwg2;

    .line 384
    .line 385
    new-instance v6, Lmj3;

    .line 386
    .line 387
    const/4 v7, 0x1

    .line 388
    invoke-direct {v6, v0, v7}, Lmj3;-><init>(FZ)V

    .line 389
    .line 390
    .line 391
    xor-int/2addr v3, v7

    .line 392
    const/4 v15, 0x0

    .line 393
    const/16 v16, 0xff0

    .line 394
    .line 395
    move-object v7, v8

    .line 396
    const/4 v8, 0x0

    .line 397
    const/4 v9, 0x0

    .line 398
    const/4 v10, 0x0

    .line 399
    const/4 v11, 0x0

    .line 400
    const/4 v12, 0x0

    .line 401
    const/4 v13, 0x0

    .line 402
    move-object/from16 v34, v7

    .line 403
    .line 404
    move v7, v3

    .line 405
    move-object/from16 v3, v34

    .line 406
    .line 407
    invoke-static/range {v4 .. v16}, Lx53;->f(Ljava/lang/String;Lwg2;Lha4;ZFFFLm64;Lu35;Ld63;Lki2;II)V

    .line 408
    .line 409
    .line 410
    const/high16 v4, 0x41a00000    # 20.0f

    .line 411
    .line 412
    const v5, 0x7f0f0465

    .line 413
    .line 414
    .line 415
    invoke-static {v1, v4, v14, v5, v14}, Lx82;->o(Lea4;FLki2;ILki2;)Ljava/lang/String;

    .line 416
    .line 417
    .line 418
    move-result-object v4

    .line 419
    move/from16 v7, v32

    .line 420
    .line 421
    invoke-virtual {v14, v7}, Lki2;->h(Z)Z

    .line 422
    .line 423
    .line 424
    move-result v1

    .line 425
    iget-object v2, v2, Ltu;->q:Lwg2;

    .line 426
    .line 427
    invoke-virtual {v14, v2}, Lki2;->g(Ljava/lang/Object;)Z

    .line 428
    .line 429
    .line 430
    move-result v5

    .line 431
    or-int/2addr v1, v5

    .line 432
    invoke-virtual {v14}, Lki2;->T()Ljava/lang/Object;

    .line 433
    .line 434
    .line 435
    move-result-object v5

    .line 436
    if-nez v1, :cond_5

    .line 437
    .line 438
    if-ne v5, v3, :cond_6

    .line 439
    .line 440
    :cond_5
    new-instance v5, Llt;

    .line 441
    .line 442
    const/4 v1, 0x3

    .line 443
    invoke-direct {v5, v7, v2, v1}, Llt;-><init>(ZLwg2;B)V

    .line 444
    .line 445
    .line 446
    invoke-virtual {v14, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 447
    .line 448
    .line 449
    :cond_6
    check-cast v5, Lwg2;

    .line 450
    .line 451
    new-instance v6, Lmj3;

    .line 452
    .line 453
    const/4 v1, 0x1

    .line 454
    invoke-direct {v6, v0, v1}, Lmj3;-><init>(FZ)V

    .line 455
    .line 456
    .line 457
    const/high16 v15, 0xc00000

    .line 458
    .line 459
    const/16 v16, 0xf70

    .line 460
    .line 461
    const/4 v8, 0x0

    .line 462
    const/4 v9, 0x0

    .line 463
    const/4 v10, 0x0

    .line 464
    sget-object v11, Lm64;->i:Lm64;

    .line 465
    .line 466
    const/4 v12, 0x0

    .line 467
    const/4 v13, 0x0

    .line 468
    invoke-static/range {v4 .. v16}, Lx53;->f(Ljava/lang/String;Lwg2;Lha4;ZFFFLm64;Lu35;Ld63;Lki2;II)V

    .line 469
    .line 470
    .line 471
    invoke-virtual {v14, v1}, Lki2;->r(Z)V

    .line 472
    .line 473
    .line 474
    invoke-virtual {v14, v1}, Lki2;->r(Z)V

    .line 475
    .line 476
    .line 477
    goto :goto_3

    .line 478
    :cond_7
    move-object/from16 v20, v2

    .line 479
    .line 480
    invoke-virtual {v14}, Lki2;->b0()V

    .line 481
    .line 482
    .line 483
    :goto_3
    return-object v20

    .line 484
    nop

    .line 485
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
