.class public final synthetic Lyh;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lai;


# direct methods
.method public synthetic constructor <init>(Lai;B)V
    .locals 0

    .line 10
    iput-byte p2, p0, Lyh;->h:B

    iput-object p1, p0, Lyh;->i:Lai;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lai;J)V
    .locals 0

    .line 1
    const/4 p2, 0x0

    .line 2
    iput-byte p2, p0, Lyh;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lyh;->i:Lai;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    iget-byte v0, p0, Lyh;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const-wide v2, 0xffffffffL

    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    const/16 v4, 0x20

    .line 11
    .line 12
    iget-object p0, p0, Lyh;->i:Lai;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    check-cast p1, Lka5;

    .line 18
    .line 19
    iget-object v0, p0, Lai;->A:Lla5;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    iget-wide v8, p0, Lai;->C:J

    .line 25
    .line 26
    iget-object p0, p0, Lai;->y:Lbi;

    .line 27
    .line 28
    iget-object v5, p0, Lbi;->b:La40;

    .line 29
    .line 30
    iget p0, v0, Lla5;->h:I

    .line 31
    .line 32
    iget v6, v0, Lla5;->i:I

    .line 33
    .line 34
    int-to-long v10, p0

    .line 35
    shl-long/2addr v10, v4

    .line 36
    int-to-long v6, v6

    .line 37
    and-long/2addr v6, v2

    .line 38
    or-long/2addr v6, v10

    .line 39
    sget-object v10, Lgi3;->h:Lgi3;

    .line 40
    .line 41
    invoke-virtual/range {v5 .. v10}, La40;->a(JJLgi3;)J

    .line 42
    .line 43
    .line 44
    move-result-wide v2

    .line 45
    invoke-static {p1, v0, v2, v3}, Lka5;->i(Lka5;Lla5;J)V

    .line 46
    .line 47
    .line 48
    return-object v1

    .line 49
    :pswitch_0
    check-cast p1, Lka5;

    .line 50
    .line 51
    iget-object v0, p0, Lai;->z:Lla5;

    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    iget-wide v8, p0, Lai;->B:J

    .line 57
    .line 58
    iget-object p0, p0, Lai;->y:Lbi;

    .line 59
    .line 60
    iget-object v5, p0, Lbi;->b:La40;

    .line 61
    .line 62
    iget p0, v0, Lla5;->h:I

    .line 63
    .line 64
    iget v6, v0, Lla5;->i:I

    .line 65
    .line 66
    int-to-long v10, p0

    .line 67
    shl-long/2addr v10, v4

    .line 68
    int-to-long v6, v6

    .line 69
    and-long/2addr v6, v2

    .line 70
    or-long/2addr v6, v10

    .line 71
    sget-object v10, Lgi3;->h:Lgi3;

    .line 72
    .line 73
    invoke-virtual/range {v5 .. v10}, La40;->a(JJLgi3;)J

    .line 74
    .line 75
    .line 76
    move-result-wide v2

    .line 77
    invoke-static {p1, v0, v2, v3}, Lka5;->i(Lka5;Lla5;J)V

    .line 78
    .line 79
    .line 80
    return-object v1

    .line 81
    :pswitch_1
    check-cast p1, Lnn7;

    .line 82
    .line 83
    invoke-interface {p1}, Lnn7;->b()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    iget-object v1, p0, Lai;->y:Lbi;

    .line 88
    .line 89
    invoke-virtual {v1}, Lbi;->b()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-static {v0, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-nez v0, :cond_0

    .line 98
    .line 99
    iget-object v0, p0, Lai;->y:Lbi;

    .line 100
    .line 101
    iget-object v0, v0, Lbi;->d:Ltd4;

    .line 102
    .line 103
    invoke-interface {p1}, Lnn7;->b()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-virtual {v0, v1}, Ltd4;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    check-cast v0, Lxy6;

    .line 112
    .line 113
    if-eqz v0, :cond_0

    .line 114
    .line 115
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    check-cast v0, Lu93;

    .line 120
    .line 121
    iget-wide v0, v0, Lu93;->a:J

    .line 122
    .line 123
    :cond_0
    iget-object v0, p0, Lai;->y:Lbi;

    .line 124
    .line 125
    iget-object v0, v0, Lbi;->d:Ltd4;

    .line 126
    .line 127
    invoke-interface {p1}, Lnn7;->d()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    invoke-virtual {v0, p1}, Ltd4;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    check-cast p1, Lxy6;

    .line 136
    .line 137
    if-eqz p1, :cond_1

    .line 138
    .line 139
    invoke-interface {p1}, Lxy6;->getValue()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    check-cast p1, Lu93;

    .line 144
    .line 145
    iget-wide v0, p1, Lu93;->a:J

    .line 146
    .line 147
    :cond_1
    iget-object p0, p0, Lai;->x:Lzd4;

    .line 148
    .line 149
    invoke-interface {p0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object p0

    .line 153
    check-cast p0, Llt6;

    .line 154
    .line 155
    if-eqz p0, :cond_2

    .line 156
    .line 157
    sget-object p0, Llh;->a:Ltx6;

    .line 158
    .line 159
    if-nez p0, :cond_3

    .line 160
    .line 161
    :cond_2
    sget-object p0, Llh;->a:Ltx6;

    .line 162
    .line 163
    :cond_3
    return-object p0

    .line 164
    nop

    .line 165
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
