.class public final synthetic Luc5;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/String;

.field public final synthetic j:Z

.field public final synthetic k:Lwg2;

.field public final synthetic l:Lwg2;

.field public final synthetic m:Lwg2;

.field public final synthetic n:Lwg2;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;ZLwg2;Lwg2;Lwg2;Lwg2;B)V
    .locals 0

    .line 1
    iput-byte p7, p0, Luc5;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Luc5;->i:Ljava/lang/String;

    .line 4
    .line 5
    iput-boolean p2, p0, Luc5;->j:Z

    .line 6
    .line 7
    iput-object p3, p0, Luc5;->k:Lwg2;

    .line 8
    .line 9
    iput-object p4, p0, Luc5;->l:Lwg2;

    .line 10
    .line 11
    iput-object p5, p0, Luc5;->m:Lwg2;

    .line 12
    .line 13
    iput-object p6, p0, Luc5;->n:Lwg2;

    .line 14
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Luc5;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x0

    .line 9
    const/4 v5, 0x1

    .line 10
    packed-switch v1, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    move-object/from16 v13, p1

    .line 14
    .line 15
    check-cast v13, Lki2;

    .line 16
    .line 17
    move-object/from16 v1, p2

    .line 18
    .line 19
    check-cast v1, Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    and-int/lit8 v6, v1, 0x3

    .line 26
    .line 27
    if-eq v6, v3, :cond_0

    .line 28
    .line 29
    move v3, v5

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move v3, v4

    .line 32
    :goto_0
    and-int/2addr v1, v5

    .line 33
    invoke-virtual {v13, v1, v3}, Lki2;->Y(IZ)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_7

    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    const/high16 v3, 0x43700000    # 240.0f

    .line 41
    .line 42
    sget-object v6, Lea4;->h:Lea4;

    .line 43
    .line 44
    invoke-static {v6, v1, v3, v5}, Lit6;->s(Lha4;FFI)Lha4;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    const/high16 v3, 0x41800000    # 16.0f

    .line 49
    .line 50
    const/high16 v6, 0x41000000    # 8.0f

    .line 51
    .line 52
    invoke-static {v1, v3, v6}, Ljb3;->y(Lha4;FF)Lha4;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    sget-object v3, Lx87;->e:Lsw;

    .line 57
    .line 58
    sget-object v6, Ly6;->v:Ly30;

    .line 59
    .line 60
    invoke-static {v3, v6, v13, v4}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    iget-wide v6, v13, Lki2;->U:J

    .line 65
    .line 66
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 67
    .line 68
    .line 69
    move-result v6

    .line 70
    invoke-virtual {v13}, Lki2;->m()Lr95;

    .line 71
    .line 72
    .line 73
    move-result-object v7

    .line 74
    invoke-static {v13, v1}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    sget-object v8, Lp41;->d:Ly6;

    .line 79
    .line 80
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v13}, Lki2;->k0()V

    .line 84
    .line 85
    .line 86
    iget-boolean v8, v13, Lki2;->T:Z

    .line 87
    .line 88
    if-eqz v8, :cond_1

    .line 89
    .line 90
    sget-object v8, Lwi3;->Z:Lj43;

    .line 91
    .line 92
    invoke-virtual {v13, v8}, Lki2;->l(Lwg2;)V

    .line 93
    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_1
    invoke-virtual {v13}, Lki2;->t0()V

    .line 97
    .line 98
    .line 99
    :goto_1
    sget-object v8, Ly6;->T:Lu31;

    .line 100
    .line 101
    invoke-static {v8, v13, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    sget-object v3, Ly6;->S:Lu31;

    .line 105
    .line 106
    invoke-static {v3, v13, v7}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 110
    .line 111
    .line 112
    move-result-object v3

    .line 113
    sget-object v6, Ly6;->U:Lu31;

    .line 114
    .line 115
    invoke-static {v6, v13, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    invoke-static {v13}, Lml6;->p(Lki2;)V

    .line 119
    .line 120
    .line 121
    sget-object v3, Ly6;->R:Lu31;

    .line 122
    .line 123
    invoke-static {v3, v13, v1}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    sget-object v1, Lsz0;->a:Lcx1;

    .line 127
    .line 128
    invoke-virtual {v13, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    check-cast v3, Lrz0;

    .line 133
    .line 134
    invoke-virtual {v3}, Lrz0;->i()J

    .line 135
    .line 136
    .line 137
    move-result-wide v8

    .line 138
    const/16 v3, 0xe

    .line 139
    .line 140
    invoke-static {v3}, Lpk6;->o(I)J

    .line 141
    .line 142
    .line 143
    move-result-wide v10

    .line 144
    sget-object v12, Lsf2;->l:Lsf2;

    .line 145
    .line 146
    const/16 v27, 0x6180

    .line 147
    .line 148
    const v28, 0x3afaa

    .line 149
    .line 150
    .line 151
    iget-object v6, v0, Luc5;->i:Ljava/lang/String;

    .line 152
    .line 153
    const/4 v7, 0x0

    .line 154
    move-object/from16 v25, v13

    .line 155
    .line 156
    const/4 v13, 0x0

    .line 157
    const-wide/16 v14, 0x0

    .line 158
    .line 159
    const/16 v16, 0x0

    .line 160
    .line 161
    const-wide/16 v17, 0x0

    .line 162
    .line 163
    const/16 v19, 0x2

    .line 164
    .line 165
    const/16 v20, 0x0

    .line 166
    .line 167
    const/16 v21, 0x2

    .line 168
    .line 169
    const/16 v22, 0x0

    .line 170
    .line 171
    const/16 v23, 0x0

    .line 172
    .line 173
    const/16 v24, 0x0

    .line 174
    .line 175
    const v26, 0x186000

    .line 176
    .line 177
    .line 178
    invoke-static/range {v6 .. v28}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 179
    .line 180
    .line 181
    move-object/from16 v13, v25

    .line 182
    .line 183
    iget-boolean v3, v0, Luc5;->j:Z

    .line 184
    .line 185
    if-eqz v3, :cond_2

    .line 186
    .line 187
    const v6, 0x10ee1aec

    .line 188
    .line 189
    .line 190
    invoke-virtual {v13, v6}, Lki2;->h0(I)V

    .line 191
    .line 192
    .line 193
    const v6, 0x7f0f03c5

    .line 194
    .line 195
    .line 196
    invoke-static {v6, v13}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v6

    .line 200
    invoke-virtual {v13, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    check-cast v1, Lrz0;

    .line 205
    .line 206
    invoke-virtual {v1}, Lrz0;->n()J

    .line 207
    .line 208
    .line 209
    move-result-wide v8

    .line 210
    const/16 v1, 0xc

    .line 211
    .line 212
    invoke-static {v1}, Lpk6;->o(I)J

    .line 213
    .line 214
    .line 215
    move-result-wide v10

    .line 216
    const/16 v27, 0x0

    .line 217
    .line 218
    const v28, 0x3ffea

    .line 219
    .line 220
    .line 221
    const/4 v7, 0x0

    .line 222
    const/4 v12, 0x0

    .line 223
    move-object/from16 v25, v13

    .line 224
    .line 225
    const/4 v13, 0x0

    .line 226
    const-wide/16 v14, 0x0

    .line 227
    .line 228
    const/16 v16, 0x0

    .line 229
    .line 230
    const-wide/16 v17, 0x0

    .line 231
    .line 232
    const/16 v19, 0x0

    .line 233
    .line 234
    const/16 v20, 0x0

    .line 235
    .line 236
    const/16 v21, 0x0

    .line 237
    .line 238
    const/16 v22, 0x0

    .line 239
    .line 240
    const/16 v23, 0x0

    .line 241
    .line 242
    const/16 v24, 0x0

    .line 243
    .line 244
    const/16 v26, 0x6000

    .line 245
    .line 246
    invoke-static/range {v6 .. v28}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 247
    .line 248
    .line 249
    move-object/from16 v13, v25

    .line 250
    .line 251
    invoke-virtual {v13, v4}, Lki2;->r(Z)V

    .line 252
    .line 253
    .line 254
    goto :goto_2

    .line 255
    :cond_2
    const v1, 0x10f23243

    .line 256
    .line 257
    .line 258
    invoke-virtual {v13, v1}, Lki2;->h0(I)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v13, v4}, Lki2;->r(Z)V

    .line 262
    .line 263
    .line 264
    :goto_2
    invoke-virtual {v13, v5}, Lki2;->r(Z)V

    .line 265
    .line 266
    .line 267
    const v1, -0x170b64b6

    .line 268
    .line 269
    .line 270
    invoke-virtual {v13, v1}, Lki2;->h0(I)V

    .line 271
    .line 272
    .line 273
    invoke-static {}, Lqf;->u()Lfr3;

    .line 274
    .line 275
    .line 276
    move-result-object v1

    .line 277
    const v5, 0x7f0f03c9

    .line 278
    .line 279
    .line 280
    invoke-static {v5, v13}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v5

    .line 284
    new-instance v6, Lj65;

    .line 285
    .line 286
    iget-object v7, v0, Luc5;->k:Lwg2;

    .line 287
    .line 288
    invoke-direct {v6, v5, v7}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {v1, v6}, Lfr3;->add(Ljava/lang/Object;)Z

    .line 292
    .line 293
    .line 294
    const v5, 0x7f0f03c7

    .line 295
    .line 296
    .line 297
    invoke-static {v5, v13}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v5

    .line 301
    new-instance v6, Lj65;

    .line 302
    .line 303
    iget-object v7, v0, Luc5;->l:Lwg2;

    .line 304
    .line 305
    invoke-direct {v6, v5, v7}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 306
    .line 307
    .line 308
    invoke-virtual {v1, v6}, Lfr3;->add(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    const v5, 0x7f0f03c6

    .line 312
    .line 313
    .line 314
    invoke-static {v5, v13}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 315
    .line 316
    .line 317
    move-result-object v5

    .line 318
    new-instance v6, Lj65;

    .line 319
    .line 320
    iget-object v7, v0, Luc5;->m:Lwg2;

    .line 321
    .line 322
    invoke-direct {v6, v5, v7}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 323
    .line 324
    .line 325
    invoke-virtual {v1, v6}, Lfr3;->add(Ljava/lang/Object;)Z

    .line 326
    .line 327
    .line 328
    if-eqz v3, :cond_3

    .line 329
    .line 330
    const v3, 0x6e2c208e

    .line 331
    .line 332
    .line 333
    invoke-virtual {v13, v3}, Lki2;->h0(I)V

    .line 334
    .line 335
    .line 336
    const v3, 0x7f0f03cf

    .line 337
    .line 338
    .line 339
    invoke-static {v3, v13}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v3

    .line 343
    new-instance v5, Lj65;

    .line 344
    .line 345
    iget-object v0, v0, Luc5;->n:Lwg2;

    .line 346
    .line 347
    invoke-direct {v5, v3, v0}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    invoke-virtual {v1, v5}, Lfr3;->add(Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    :goto_3
    invoke-virtual {v13, v4}, Lki2;->r(Z)V

    .line 354
    .line 355
    .line 356
    goto :goto_4

    .line 357
    :cond_3
    const v0, 0x57593b8c

    .line 358
    .line 359
    .line 360
    invoke-virtual {v13, v0}, Lki2;->h0(I)V

    .line 361
    .line 362
    .line 363
    goto :goto_3

    .line 364
    :goto_4
    invoke-static {v1}, Lqf;->k(Lfr3;)Lfr3;

    .line 365
    .line 366
    .line 367
    move-result-object v0

    .line 368
    invoke-virtual {v13, v4}, Lki2;->r(Z)V

    .line 369
    .line 370
    .line 371
    invoke-virtual {v0, v4}, Lfr3;->listIterator(I)Ljava/util/ListIterator;

    .line 372
    .line 373
    .line 374
    move-result-object v1

    .line 375
    :goto_5
    move v9, v4

    .line 376
    move-object v3, v1

    .line 377
    check-cast v3, Lhs2;

    .line 378
    .line 379
    invoke-virtual {v3}, Lhs2;->hasNext()Z

    .line 380
    .line 381
    .line 382
    move-result v4

    .line 383
    if-eqz v4, :cond_8

    .line 384
    .line 385
    invoke-virtual {v3}, Lhs2;->next()Ljava/lang/Object;

    .line 386
    .line 387
    .line 388
    move-result-object v3

    .line 389
    add-int/lit8 v4, v9, 0x1

    .line 390
    .line 391
    if-ltz v9, :cond_6

    .line 392
    .line 393
    check-cast v3, Lj65;

    .line 394
    .line 395
    iget-object v5, v3, Lj65;->h:Ljava/lang/Object;

    .line 396
    .line 397
    move-object v6, v5

    .line 398
    check-cast v6, Ljava/lang/String;

    .line 399
    .line 400
    iget-object v3, v3, Lj65;->i:Ljava/lang/Object;

    .line 401
    .line 402
    check-cast v3, Lwg2;

    .line 403
    .line 404
    iget v7, v0, Lfr3;->i:I

    .line 405
    .line 406
    invoke-virtual {v13, v3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 407
    .line 408
    .line 409
    move-result v5

    .line 410
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 411
    .line 412
    .line 413
    move-result-object v8

    .line 414
    if-nez v5, :cond_4

    .line 415
    .line 416
    sget-object v5, Lz41;->a:Lql0;

    .line 417
    .line 418
    if-ne v8, v5, :cond_5

    .line 419
    .line 420
    :cond_4
    new-instance v8, Lmp;

    .line 421
    .line 422
    const/16 v5, 0x17

    .line 423
    .line 424
    invoke-direct {v8, v3, v5}, Lmp;-><init>(Lwg2;B)V

    .line 425
    .line 426
    .line 427
    invoke-virtual {v13, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 428
    .line 429
    .line 430
    :cond_5
    move-object v12, v8

    .line 431
    check-cast v12, Lhh2;

    .line 432
    .line 433
    const/16 v14, 0x180

    .line 434
    .line 435
    const/16 v15, 0x70

    .line 436
    .line 437
    const/4 v8, 0x0

    .line 438
    const/4 v10, 0x0

    .line 439
    const/4 v11, 0x0

    .line 440
    invoke-static/range {v6 .. v15}, Le74;->c(Ljava/lang/String;IZILgw1;ZLhh2;Lki2;II)V

    .line 441
    .line 442
    .line 443
    goto :goto_5

    .line 444
    :cond_6
    invoke-static {}, Lqf;->z0()V

    .line 445
    .line 446
    .line 447
    const/4 v0, 0x0

    .line 448
    throw v0

    .line 449
    :cond_7
    move-object/from16 v25, v13

    .line 450
    .line 451
    invoke-virtual/range {v25 .. v25}, Lki2;->b0()V

    .line 452
    .line 453
    .line 454
    :cond_8
    return-object v2

    .line 455
    :pswitch_0
    move-object/from16 v1, p1

    .line 456
    .line 457
    check-cast v1, Lki2;

    .line 458
    .line 459
    move-object/from16 v6, p2

    .line 460
    .line 461
    check-cast v6, Ljava/lang/Integer;

    .line 462
    .line 463
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 464
    .line 465
    .line 466
    move-result v6

    .line 467
    and-int/lit8 v7, v6, 0x3

    .line 468
    .line 469
    if-eq v7, v3, :cond_9

    .line 470
    .line 471
    move v4, v5

    .line 472
    :cond_9
    and-int/2addr v6, v5

    .line 473
    invoke-virtual {v1, v6, v4}, Lki2;->Y(IZ)Z

    .line 474
    .line 475
    .line 476
    move-result v3

    .line 477
    if-eqz v3, :cond_a

    .line 478
    .line 479
    new-instance v4, Luc5;

    .line 480
    .line 481
    const/4 v11, 0x1

    .line 482
    iget-object v5, v0, Luc5;->i:Ljava/lang/String;

    .line 483
    .line 484
    iget-boolean v6, v0, Luc5;->j:Z

    .line 485
    .line 486
    iget-object v7, v0, Luc5;->k:Lwg2;

    .line 487
    .line 488
    iget-object v8, v0, Luc5;->l:Lwg2;

    .line 489
    .line 490
    iget-object v9, v0, Luc5;->m:Lwg2;

    .line 491
    .line 492
    iget-object v10, v0, Luc5;->n:Lwg2;

    .line 493
    .line 494
    invoke-direct/range {v4 .. v11}, Luc5;-><init>(Ljava/lang/String;ZLwg2;Lwg2;Lwg2;Lwg2;B)V

    .line 495
    .line 496
    .line 497
    const v0, 0x990e749

    .line 498
    .line 499
    .line 500
    invoke-static {v0, v4, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 501
    .line 502
    .line 503
    move-result-object v0

    .line 504
    const/4 v3, 0x6

    .line 505
    invoke-static {v0, v1, v3}, Le74;->f(Lq21;Lki2;I)V

    .line 506
    .line 507
    .line 508
    goto :goto_6

    .line 509
    :cond_a
    invoke-virtual {v1}, Lki2;->b0()V

    .line 510
    .line 511
    .line 512
    :goto_6
    return-object v2

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
