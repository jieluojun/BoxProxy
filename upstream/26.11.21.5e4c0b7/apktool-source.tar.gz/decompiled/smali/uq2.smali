.class public final Luq2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final g:Lxf2;

.field public static final h:I

.field public static final i:I


# instance fields
.field public final a:Ljava/lang/ThreadLocal;

.field public final b:Ljava/util/concurrent/ConcurrentHashMap;

.field public final c:Lor;

.field public final d:Lrd3;

.field public final e:Ljava/util/List;

.field public final f:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lxf2;->d:Lxf2;

    .line 2
    .line 3
    sput-object v0, Luq2;->g:Lxf2;

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    sput v0, Luq2;->h:I

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    sput v0, Luq2;->i:I

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(Lm42;Ljava/util/HashMap;ILjava/util/ArrayList;IILjava/util/ArrayList;)V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/ThreadLocal;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Luq2;->a:Ljava/lang/ThreadLocal;

    .line 10
    .line 11
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Luq2;->b:Ljava/util/concurrent/ConcurrentHashMap;

    .line 17
    .line 18
    new-instance v0, Lor;

    .line 19
    .line 20
    const/16 v1, 0x17

    .line 21
    .line 22
    invoke-direct {v0, p2, p7, v1}, Lor;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Luq2;->c:Lor;

    .line 26
    .line 27
    iput p3, p0, Luq2;->f:I

    .line 28
    .line 29
    new-instance p2, Ljava/util/ArrayList;

    .line 30
    .line 31
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 32
    .line 33
    .line 34
    sget-object p3, Lwp7;->A:Lmp7;

    .line 35
    .line 36
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    const/4 p3, 0x1

    .line 40
    if-ne p5, p3, :cond_0

    .line 41
    .line 42
    sget-object p5, Ltu4;->d:Ldv4;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    new-instance v1, Ldv4;

    .line 46
    .line 47
    invoke-direct {v1, p5}, Ldv4;-><init>(I)V

    .line 48
    .line 49
    .line 50
    move-object p5, v1

    .line 51
    :goto_0
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 58
    .line 59
    .line 60
    sget-object p4, Lwp7;->p:Lmp7;

    .line 61
    .line 62
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    sget-object p4, Lwp7;->g:Lop7;

    .line 66
    .line 67
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    sget-object p4, Lwp7;->d:Lop7;

    .line 71
    .line 72
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    sget-object p4, Lwp7;->e:Lop7;

    .line 76
    .line 77
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    sget-object p4, Lwp7;->f:Lop7;

    .line 81
    .line 82
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    sget-object p4, Lwp7;->k:Luo7;

    .line 86
    .line 87
    new-instance p5, Lop7;

    .line 88
    .line 89
    sget-object v1, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 90
    .line 91
    const-class v2, Ljava/lang/Long;

    .line 92
    .line 93
    invoke-direct {p5, v1, v2, p4}, Lop7;-><init>(Ljava/lang/Class;Ljava/lang/Class;Lro7;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    new-instance p5, Lrq2;

    .line 100
    .line 101
    const/4 v1, 0x0

    .line 102
    invoke-direct {p5, v1}, Lrq2;-><init>(B)V

    .line 103
    .line 104
    .line 105
    new-instance v2, Lop7;

    .line 106
    .line 107
    sget-object v3, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    .line 108
    .line 109
    const-class v4, Ljava/lang/Double;

    .line 110
    .line 111
    invoke-direct {v2, v3, v4, p5}, Lop7;-><init>(Ljava/lang/Class;Ljava/lang/Class;Lro7;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    new-instance p5, Lrq2;

    .line 118
    .line 119
    invoke-direct {p5, p3}, Lrq2;-><init>(B)V

    .line 120
    .line 121
    .line 122
    new-instance v2, Lop7;

    .line 123
    .line 124
    sget-object v3, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    .line 125
    .line 126
    const-class v4, Ljava/lang/Float;

    .line 127
    .line 128
    invoke-direct {v2, v3, v4, p5}, Lop7;-><init>(Ljava/lang/Class;Ljava/lang/Class;Lro7;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    const/4 p5, 0x2

    .line 135
    if-ne p6, p5, :cond_1

    .line 136
    .line 137
    sget-object p5, Ltu4;->c:Lsu4;

    .line 138
    .line 139
    goto :goto_1

    .line 140
    :cond_1
    new-instance p5, Ltu4;

    .line 141
    .line 142
    invoke-direct {p5, p6}, Ltu4;-><init>(I)V

    .line 143
    .line 144
    .line 145
    new-instance p6, Lsu4;

    .line 146
    .line 147
    invoke-direct {p6, p5, v1}, Lsu4;-><init>(Lro7;B)V

    .line 148
    .line 149
    .line 150
    move-object p5, p6

    .line 151
    :goto_1
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    sget-object p5, Lwp7;->h:Lmp7;

    .line 155
    .line 156
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    sget-object p5, Lwp7;->i:Lmp7;

    .line 160
    .line 161
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    new-instance p5, Lsq2;

    .line 165
    .line 166
    invoke-direct {p5, p4, v1}, Lsq2;-><init>(Lro7;B)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {p5}, Lro7;->a()Lqo7;

    .line 170
    .line 171
    .line 172
    move-result-object p5

    .line 173
    new-instance p6, Lmp7;

    .line 174
    .line 175
    const-class v2, Ljava/util/concurrent/atomic/AtomicLong;

    .line 176
    .line 177
    invoke-direct {p6, v2, p5, v1}, Lmp7;-><init>(Ljava/lang/Object;Lro7;B)V

    .line 178
    .line 179
    .line 180
    invoke-virtual {p2, p6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    new-instance p5, Lsq2;

    .line 184
    .line 185
    invoke-direct {p5, p4, p3}, Lsq2;-><init>(Lro7;B)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {p5}, Lro7;->a()Lqo7;

    .line 189
    .line 190
    .line 191
    move-result-object p4

    .line 192
    new-instance p5, Lmp7;

    .line 193
    .line 194
    const-class p6, Ljava/util/concurrent/atomic/AtomicLongArray;

    .line 195
    .line 196
    invoke-direct {p5, p6, p4, v1}, Lmp7;-><init>(Ljava/lang/Object;Lro7;B)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 200
    .line 201
    .line 202
    sget-object p4, Lwp7;->j:Lmp7;

    .line 203
    .line 204
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 205
    .line 206
    .line 207
    sget-object p4, Lwp7;->l:Lop7;

    .line 208
    .line 209
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 210
    .line 211
    .line 212
    sget-object p4, Lwp7;->q:Lmp7;

    .line 213
    .line 214
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    sget-object p4, Lwp7;->r:Lmp7;

    .line 218
    .line 219
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    sget-object p4, Lwp7;->m:Lzo7;

    .line 223
    .line 224
    new-instance p5, Lmp7;

    .line 225
    .line 226
    const-class p6, Ljava/math/BigDecimal;

    .line 227
    .line 228
    invoke-direct {p5, p6, p4, v1}, Lmp7;-><init>(Ljava/lang/Object;Lro7;B)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    sget-object p4, Lwp7;->n:Lap7;

    .line 235
    .line 236
    new-instance p5, Lmp7;

    .line 237
    .line 238
    const-class p6, Ljava/math/BigInteger;

    .line 239
    .line 240
    invoke-direct {p5, p6, p4, v1}, Lmp7;-><init>(Ljava/lang/Object;Lro7;B)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    sget-object p4, Lwp7;->o:Lbp7;

    .line 247
    .line 248
    new-instance p5, Lmp7;

    .line 249
    .line 250
    const-class p6, Loj3;

    .line 251
    .line 252
    invoke-direct {p5, p6, p4, v1}, Lmp7;-><init>(Ljava/lang/Object;Lro7;B)V

    .line 253
    .line 254
    .line 255
    invoke-virtual {p2, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    sget-object p4, Lwp7;->s:Lmp7;

    .line 259
    .line 260
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 261
    .line 262
    .line 263
    sget-object p4, Lwp7;->t:Lmp7;

    .line 264
    .line 265
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 266
    .line 267
    .line 268
    sget-object p4, Lwp7;->v:Lmp7;

    .line 269
    .line 270
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 271
    .line 272
    .line 273
    sget-object p4, Lwp7;->w:Lmp7;

    .line 274
    .line 275
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 276
    .line 277
    .line 278
    sget-object p4, Lwp7;->y:Lmp7;

    .line 279
    .line 280
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 281
    .line 282
    .line 283
    sget-object p4, Lwp7;->u:Lmp7;

    .line 284
    .line 285
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 286
    .line 287
    .line 288
    sget-object p4, Lwp7;->b:Lmp7;

    .line 289
    .line 290
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 291
    .line 292
    .line 293
    sget-object p4, Lim1;->c:Lfm1;

    .line 294
    .line 295
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 296
    .line 297
    .line 298
    sget-object p4, Lwp7;->x:Lsu4;

    .line 299
    .line 300
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 301
    .line 302
    .line 303
    sget-boolean p4, Lay6;->a:Z

    .line 304
    .line 305
    if-eqz p4, :cond_2

    .line 306
    .line 307
    sget-object p4, Lay6;->c:Lwx6$a;

    .line 308
    .line 309
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 310
    .line 311
    .line 312
    sget-object p4, Lay6;->b:Lvx6$a;

    .line 313
    .line 314
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 315
    .line 316
    .line 317
    sget-object p4, Lay6;->d:Lxx6;

    .line 318
    .line 319
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 320
    .line 321
    .line 322
    :cond_2
    sget-object p4, Lmx;->c:Llx;

    .line 323
    .line 324
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 325
    .line 326
    .line 327
    sget-object p4, Lwp7;->a:Lmp7;

    .line 328
    .line 329
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 330
    .line 331
    .line 332
    new-instance p4, Lwx0;

    .line 333
    .line 334
    invoke-direct {p4, v0, v1}, Lwx0;-><init>(Lor;B)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 338
    .line 339
    .line 340
    new-instance p4, Lwx0;

    .line 341
    .line 342
    invoke-direct {p4, v0, p3}, Lwx0;-><init>(Lor;B)V

    .line 343
    .line 344
    .line 345
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 346
    .line 347
    .line 348
    new-instance p3, Lrd3;

    .line 349
    .line 350
    invoke-direct {p3, v0}, Lrd3;-><init>(Lor;)V

    .line 351
    .line 352
    .line 353
    iput-object p3, p0, Luq2;->d:Lrd3;

    .line 354
    .line 355
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 356
    .line 357
    .line 358
    sget-object p4, Lwp7;->B:Ll32;

    .line 359
    .line 360
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 361
    .line 362
    .line 363
    new-instance p4, Llv5;

    .line 364
    .line 365
    invoke-direct {p4, v0, p1, p3, p7}, Llv5;-><init>(Lor;Lm42;Lrd3;Ljava/util/ArrayList;)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 369
    .line 370
    .line 371
    invoke-static {p2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 372
    .line 373
    .line 374
    move-result-object p1

    .line 375
    iput-object p1, p0, Luq2;->e:Ljava/util/List;

    .line 376
    .line 377
    return-void
.end method


# virtual methods
.method public final a(Ljava/io/Reader;Lyp7;)Ljava/lang/Object;
    .locals 8

    .line 1
    new-instance v0, Lgf3;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Lgf3;-><init>(Ljava/io/Reader;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x2

    .line 7
    iget v1, p0, Luq2;->f:I

    .line 8
    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    move v2, p1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move v2, v1

    .line 14
    :goto_0
    const/4 v3, 0x0

    .line 15
    if-eqz v2, :cond_a

    .line 16
    .line 17
    iput v2, v0, Lgf3;->v:I

    .line 18
    .line 19
    const-string v4, "AssertionError (GSON 2.13.2): "

    .line 20
    .line 21
    const-string v5, "Type adapter \'"

    .line 22
    .line 23
    const/4 v6, 0x1

    .line 24
    if-eqz v1, :cond_2

    .line 25
    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    iput v1, v0, Lgf3;->v:I

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_1
    throw v3

    .line 32
    :cond_2
    if-ne v2, p1, :cond_3

    .line 33
    .line 34
    iput v6, v0, Lgf3;->v:I

    .line 35
    .line 36
    :cond_3
    :goto_1
    :try_start_0
    invoke-virtual {v0}, Lgf3;->K()I

    .line 37
    .line 38
    .line 39
    const/4 v6, 0x0

    .line 40
    invoke-virtual {p0, p2}, Luq2;->b(Lyp7;)Lro7;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    iget-object p1, p2, Lyp7;->a:Ljava/lang/Class;

    .line 45
    .line 46
    invoke-virtual {p0, v0}, Lro7;->b(Lgf3;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    invoke-static {p1}, Lx43;->a0(Ljava/lang/Class;)Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    if-eqz p2, :cond_4

    .line 55
    .line 56
    invoke-virtual {v1, p2}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-nez v1, :cond_4

    .line 61
    .line 62
    new-instance v1, Ljava/lang/ClassCastException;

    .line 63
    .line 64
    new-instance v7, Ljava/lang/StringBuilder;

    .line 65
    .line 66
    invoke-direct {v7, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    const-string p0, "\' returned wrong type; requested "

    .line 73
    .line 74
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    const-string p0, " but got instance of "

    .line 81
    .line 82
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string p0, "\nVerify that the adapter was registered for the correct type."

    .line 93
    .line 94
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object p0

    .line 101
    invoke-direct {v1, p0}, Ljava/lang/ClassCastException;-><init>(Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    throw v1
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/AssertionError; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 105
    :cond_4
    if-eqz v2, :cond_5

    .line 106
    .line 107
    iput v2, v0, Lgf3;->v:I

    .line 108
    .line 109
    move-object v3, p2

    .line 110
    goto :goto_2

    .line 111
    :cond_5
    throw v3

    .line 112
    :catch_0
    move-exception p0

    .line 113
    :try_start_1
    new-instance p1, Ljava/lang/AssertionError;

    .line 114
    .line 115
    new-instance p2, Ljava/lang/StringBuilder;

    .line 116
    .line 117
    invoke-direct {p2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    .line 126
    .line 127
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object p2

    .line 131
    invoke-direct {p1, p2, p0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 132
    .line 133
    .line 134
    throw p1

    .line 135
    :catch_1
    move-exception p0

    .line 136
    new-instance p1, Lme3;

    .line 137
    .line 138
    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 139
    .line 140
    .line 141
    throw p1

    .line 142
    :catch_2
    move-exception p0

    .line 143
    new-instance p1, Lme3;

    .line 144
    .line 145
    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 146
    .line 147
    .line 148
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 149
    :catch_3
    move-exception p0

    .line 150
    if-eqz v6, :cond_8

    .line 151
    .line 152
    if-eqz v2, :cond_7

    .line 153
    .line 154
    iput v2, v0, Lgf3;->v:I

    .line 155
    .line 156
    :goto_2
    if-eqz v3, :cond_6

    .line 157
    .line 158
    :try_start_2
    invoke-virtual {v0}, Lgf3;->K()I

    .line 159
    .line 160
    .line 161
    move-result p0

    .line 162
    const/16 p1, 0xa

    .line 163
    .line 164
    if-eq p0, p1, :cond_6

    .line 165
    .line 166
    new-instance p0, Lme3;

    .line 167
    .line 168
    const-string p1, "JSON document was not fully consumed."

    .line 169
    .line 170
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    throw p0
    :try_end_2
    .catch Lpx3; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_4

    .line 174
    :catch_4
    move-exception p0

    .line 175
    new-instance p1, Lme3;

    .line 176
    .line 177
    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 178
    .line 179
    .line 180
    throw p1

    .line 181
    :catch_5
    move-exception p0

    .line 182
    new-instance p1, Lme3;

    .line 183
    .line 184
    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 185
    .line 186
    .line 187
    throw p1

    .line 188
    :cond_6
    return-object v3

    .line 189
    :cond_7
    throw v3

    .line 190
    :cond_8
    :try_start_3
    new-instance p1, Lme3;

    .line 191
    .line 192
    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 193
    .line 194
    .line 195
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 196
    :catchall_0
    move-exception p0

    .line 197
    if-eqz v2, :cond_9

    .line 198
    .line 199
    iput v2, v0, Lgf3;->v:I

    .line 200
    .line 201
    throw p0

    .line 202
    :cond_9
    throw v3

    .line 203
    :cond_a
    throw v3
.end method

.method public final b(Lyp7;)Lro7;
    .locals 9

    .line 1
    const-string v0, "type must not be null"

    .line 2
    .line 3
    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Luq2;->b:Ljava/util/concurrent/ConcurrentHashMap;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Lro7;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    return-object v1

    .line 17
    :cond_0
    iget-object v1, p0, Luq2;->a:Ljava/lang/ThreadLocal;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    check-cast v2, Ljava/util/Map;

    .line 24
    .line 25
    if-nez v2, :cond_1

    .line 26
    .line 27
    new-instance v2, Ljava/util/HashMap;

    .line 28
    .line 29
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    const/4 v3, 0x1

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    invoke-interface {v2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    check-cast v3, Lro7;

    .line 42
    .line 43
    if-eqz v3, :cond_2

    .line 44
    .line 45
    return-object v3

    .line 46
    :cond_2
    const/4 v3, 0x0

    .line 47
    :goto_0
    :try_start_0
    new-instance v4, Ltq2;

    .line 48
    .line 49
    invoke-direct {v4}, Ltq2;-><init>()V

    .line 50
    .line 51
    .line 52
    invoke-interface {v2, p1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    iget-object v5, p0, Luq2;->e:Ljava/util/List;

    .line 56
    .line 57
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    const/4 v6, 0x0

    .line 62
    move-object v7, v6

    .line 63
    :cond_3
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 64
    .line 65
    .line 66
    move-result v8

    .line 67
    if-eqz v8, :cond_5

    .line 68
    .line 69
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    check-cast v7, Lso7;

    .line 74
    .line 75
    invoke-interface {v7, p0, p1}, Lso7;->a(Luq2;Lyp7;)Lro7;

    .line 76
    .line 77
    .line 78
    move-result-object v7

    .line 79
    if-eqz v7, :cond_3

    .line 80
    .line 81
    iget-object p0, v4, Ltq2;->a:Lro7;

    .line 82
    .line 83
    if-nez p0, :cond_4

    .line 84
    .line 85
    iput-object v7, v4, Ltq2;->a:Lro7;

    .line 86
    .line 87
    invoke-interface {v2, p1, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_4
    new-instance p0, Ljava/lang/AssertionError;

    .line 92
    .line 93
    const-string p1, "Delegate is already set"

    .line 94
    .line 95
    invoke-direct {p0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    throw p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 99
    :cond_5
    :goto_1
    if-eqz v3, :cond_6

    .line 100
    .line 101
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    .line 102
    .line 103
    .line 104
    :cond_6
    if-eqz v7, :cond_8

    .line 105
    .line 106
    if-eqz v3, :cond_7

    .line 107
    .line 108
    invoke-virtual {v0, v2}, Ljava/util/concurrent/ConcurrentHashMap;->putAll(Ljava/util/Map;)V

    .line 109
    .line 110
    .line 111
    :cond_7
    return-object v7

    .line 112
    :cond_8
    const-string p0, "GSON (2.13.2) cannot handle "

    .line 113
    .line 114
    invoke-static {p0, p1}, Lfb1;->q(Ljava/lang/String;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    return-object v6

    .line 118
    :catchall_0
    move-exception p0

    .line 119
    if-eqz v3, :cond_9

    .line 120
    .line 121
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    .line 122
    .line 123
    .line 124
    :cond_9
    throw p0
.end method

.method public final c(Lso7;Lyp7;)Lro7;
    .locals 7

    .line 1
    const-string v0, "skipPast must not be null"

    .line 2
    .line 3
    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    const-string v0, "type must not be null"

    .line 7
    .line 8
    invoke-static {p2, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Luq2;->d:Lrd3;

    .line 12
    .line 13
    iget-object v1, v0, Lrd3;->i:Ljava/util/concurrent/ConcurrentHashMap;

    .line 14
    .line 15
    sget-object v2, Lrd3;->j:Lqd3;

    .line 16
    .line 17
    const/4 v3, 0x1

    .line 18
    if-eq p1, v2, :cond_2

    .line 19
    .line 20
    iget-object v2, p2, Lyp7;->a:Ljava/lang/Class;

    .line 21
    .line 22
    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    check-cast v4, Lso7;

    .line 27
    .line 28
    if-eqz v4, :cond_0

    .line 29
    .line 30
    if-ne v4, p1, :cond_3

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    const-class v4, Lpd3;

    .line 34
    .line 35
    invoke-virtual {v2, v4}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    check-cast v4, Lpd3;

    .line 40
    .line 41
    if-eqz v4, :cond_3

    .line 42
    .line 43
    invoke-interface {v4}, Lpd3;->value()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    const-class v5, Lso7;

    .line 48
    .line 49
    invoke-virtual {v5, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    if-eqz v5, :cond_3

    .line 54
    .line 55
    iget-object v5, v0, Lrd3;->h:Lor;

    .line 56
    .line 57
    new-instance v6, Lyp7;

    .line 58
    .line 59
    invoke-direct {v6, v4}, Lyp7;-><init>(Ljava/lang/reflect/Type;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v5, v6, v3}, Lor;->q(Lyp7;Z)Lyu4;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    invoke-interface {v4}, Lyu4;->e()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    check-cast v4, Lso7;

    .line 71
    .line 72
    invoke-virtual {v1, v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    check-cast v1, Lso7;

    .line 77
    .line 78
    if-eqz v1, :cond_1

    .line 79
    .line 80
    move-object v4, v1

    .line 81
    :cond_1
    if-ne v4, p1, :cond_3

    .line 82
    .line 83
    :cond_2
    :goto_0
    move-object p1, v0

    .line 84
    :cond_3
    iget-object v0, p0, Luq2;->e:Ljava/util/List;

    .line 85
    .line 86
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    const/4 v1, 0x0

    .line 91
    :cond_4
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    if-eqz v2, :cond_6

    .line 96
    .line 97
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    check-cast v2, Lso7;

    .line 102
    .line 103
    if-nez v1, :cond_5

    .line 104
    .line 105
    if-ne v2, p1, :cond_4

    .line 106
    .line 107
    move v1, v3

    .line 108
    goto :goto_1

    .line 109
    :cond_5
    invoke-interface {v2, p0, p2}, Lso7;->a(Luq2;Lyp7;)Lro7;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    if-eqz v2, :cond_4

    .line 114
    .line 115
    return-object v2

    .line 116
    :cond_6
    if-nez v1, :cond_7

    .line 117
    .line 118
    invoke-virtual {p0, p2}, Luq2;->b(Lyp7;)Lro7;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    return-object p0

    .line 123
    :cond_7
    const-string p0, "GSON cannot serialize or deserialize "

    .line 124
    .line 125
    invoke-static {p0, p2}, Lfb1;->q(Ljava/lang/String;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    const/4 p0, 0x0

    .line 129
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "{serializeNulls:false,factories:"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Luq2;->e:Ljava/util/List;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ",instanceCreators:"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object p0, p0, Luq2;->c:Lor;

    .line 19
    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p0, "}"

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0
.end method
