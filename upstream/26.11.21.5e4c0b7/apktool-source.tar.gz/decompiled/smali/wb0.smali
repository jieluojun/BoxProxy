.class public final synthetic Lwb0;
.super Lwh2;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic o:B


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V
    .locals 0

    .line 1
    iput-byte p7, p0, Lwb0;->o:B

    .line 2
    .line 3
    invoke-direct/range {p0 .. p6}, Lwh2;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, Lwb0;->o:B

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    const-string v2, ""

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x0

    .line 8
    sget-object v5, Los7;->a:Los7;

    .line 9
    .line 10
    iget-object p0, p0, Lyk0;->i:Ljava/lang/Object;

    .line 11
    .line 12
    packed-switch v0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    check-cast p0, Ljc5;

    .line 16
    .line 17
    invoke-virtual {p0, v4}, Ljc5;->c(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-object v5

    .line 21
    :pswitch_0
    check-cast p0, Ljc5;

    .line 22
    .line 23
    invoke-virtual {p0, v4}, Ljc5;->c(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    return-object v5

    .line 27
    :pswitch_1
    check-cast p0, Ljc5;

    .line 28
    .line 29
    invoke-virtual {p0, v4}, Ljc5;->b(Lvo5;)V

    .line 30
    .line 31
    .line 32
    return-object v5

    .line 33
    :pswitch_2
    check-cast p0, Ljc5;

    .line 34
    .line 35
    invoke-virtual {p0, v4}, Ljc5;->f(Lvo5;)V

    .line 36
    .line 37
    .line 38
    return-object v5

    .line 39
    :pswitch_3
    check-cast p0, Ljc5;

    .line 40
    .line 41
    invoke-virtual {p0, v3}, Ljc5;->e(Z)V

    .line 42
    .line 43
    .line 44
    return-object v5

    .line 45
    :pswitch_4
    check-cast p0, Ljc5;

    .line 46
    .line 47
    invoke-virtual {p0, v4}, Ljc5;->a(Lvo5;)V

    .line 48
    .line 49
    .line 50
    return-object v5

    .line 51
    :pswitch_5
    check-cast p0, Ljc5;

    .line 52
    .line 53
    invoke-virtual {p0, v3}, Ljc5;->d(Z)V

    .line 54
    .line 55
    .line 56
    return-object v5

    .line 57
    :pswitch_6
    check-cast p0, Lee1;

    .line 58
    .line 59
    invoke-virtual {p0}, Lee1;->a()V

    .line 60
    .line 61
    .line 62
    return-object v5

    .line 63
    :pswitch_7
    check-cast p0, Lee1;

    .line 64
    .line 65
    invoke-virtual {p0}, Lee1;->b()V

    .line 66
    .line 67
    .line 68
    return-object v5

    .line 69
    :pswitch_8
    check-cast p0, Lee1;

    .line 70
    .line 71
    invoke-virtual {p0}, Lee1;->a()V

    .line 72
    .line 73
    .line 74
    return-object v5

    .line 75
    :pswitch_9
    check-cast p0, Lee1;

    .line 76
    .line 77
    invoke-virtual {p0}, Lee1;->b()V

    .line 78
    .line 79
    .line 80
    return-object v5

    .line 81
    :pswitch_a
    check-cast p0, Lw81;

    .line 82
    .line 83
    invoke-virtual {p0, v4}, Lw81;->n(Lvo5;)V

    .line 84
    .line 85
    .line 86
    iget-object p0, p0, Lw81;->e:Lf75;

    .line 87
    .line 88
    invoke-virtual {p0, v4}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    return-object v5

    .line 92
    :pswitch_b
    check-cast p0, Lw81;

    .line 93
    .line 94
    invoke-virtual {p0, v4}, Lw81;->n(Lvo5;)V

    .line 95
    .line 96
    .line 97
    iget-object p0, p0, Lw81;->e:Lf75;

    .line 98
    .line 99
    invoke-virtual {p0, v4}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    return-object v5

    .line 103
    :pswitch_c
    check-cast p0, Lk71;

    .line 104
    .line 105
    invoke-virtual {p0}, Lk71;->a()V

    .line 106
    .line 107
    .line 108
    return-object v5

    .line 109
    :pswitch_d
    check-cast p0, Lbv0;

    .line 110
    .line 111
    invoke-virtual {p0}, Lbv0;->g()V

    .line 112
    .line 113
    .line 114
    return-object v5

    .line 115
    :pswitch_e
    check-cast p0, Lbv0;

    .line 116
    .line 117
    invoke-virtual {p0}, Lbv0;->j()V

    .line 118
    .line 119
    .line 120
    return-object v5

    .line 121
    :pswitch_f
    check-cast p0, Lbv0;

    .line 122
    .line 123
    iget-object p0, p0, Lbv0;->c:Luu0;

    .line 124
    .line 125
    invoke-virtual {p0}, Luu0;->a()Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    xor-int/lit8 v0, v0, 0x1

    .line 130
    .line 131
    iget-object v1, p0, Luu0;->f:Lzd4;

    .line 132
    .line 133
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    invoke-interface {v1, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {p0}, Luu0;->a()Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    if-nez v0, :cond_0

    .line 145
    .line 146
    iget-object p0, p0, Luu0;->g:Lzd4;

    .line 147
    .line 148
    invoke-interface {p0, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    :cond_0
    return-object v5

    .line 152
    :pswitch_10
    check-cast p0, Lbv0;

    .line 153
    .line 154
    invoke-virtual {p0}, Lbv0;->b()V

    .line 155
    .line 156
    .line 157
    return-object v5

    .line 158
    :pswitch_11
    check-cast p0, Lbv0;

    .line 159
    .line 160
    invoke-virtual {p0}, Lbv0;->g()V

    .line 161
    .line 162
    .line 163
    return-object v5

    .line 164
    :pswitch_12
    check-cast p0, Lbv0;

    .line 165
    .line 166
    invoke-virtual {p0}, Lbv0;->j()V

    .line 167
    .line 168
    .line 169
    return-object v5

    .line 170
    :pswitch_13
    check-cast p0, Lbv0;

    .line 171
    .line 172
    iget-object p0, p0, Lbv0;->c:Luu0;

    .line 173
    .line 174
    invoke-virtual {p0}, Luu0;->a()Z

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    xor-int/lit8 v0, v0, 0x1

    .line 179
    .line 180
    iget-object v1, p0, Luu0;->f:Lzd4;

    .line 181
    .line 182
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    invoke-interface {v1, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {p0}, Luu0;->a()Z

    .line 190
    .line 191
    .line 192
    move-result v0

    .line 193
    if-nez v0, :cond_1

    .line 194
    .line 195
    iget-object p0, p0, Luu0;->g:Lzd4;

    .line 196
    .line 197
    invoke-interface {p0, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    :cond_1
    return-object v5

    .line 201
    :pswitch_14
    check-cast p0, Lbv0;

    .line 202
    .line 203
    invoke-virtual {p0}, Lbv0;->b()V

    .line 204
    .line 205
    .line 206
    return-object v5

    .line 207
    :pswitch_15
    check-cast p0, Lph0;

    .line 208
    .line 209
    iget-object p0, p0, Lph0;->c:Lsh0;

    .line 210
    .line 211
    iget-object v0, p0, Lsh0;->a:Lzd4;

    .line 212
    .line 213
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 214
    .line 215
    invoke-interface {v0, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    iget-object p0, p0, Lsh0;->b:Lzd4;

    .line 219
    .line 220
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-interface {p0, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 225
    .line 226
    .line 227
    return-object v5

    .line 228
    :pswitch_16
    check-cast p0, Lph0;

    .line 229
    .line 230
    iget-object p0, p0, Lph0;->c:Lsh0;

    .line 231
    .line 232
    iget-object v0, p0, Lsh0;->a:Lzd4;

    .line 233
    .line 234
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 235
    .line 236
    invoke-interface {v0, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 237
    .line 238
    .line 239
    iget-object p0, p0, Lsh0;->b:Lzd4;

    .line 240
    .line 241
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    invoke-interface {p0, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    return-object v5

    .line 249
    :pswitch_17
    check-cast p0, Lhj4;

    .line 250
    .line 251
    invoke-virtual {p0}, Lhj4;->a()V

    .line 252
    .line 253
    .line 254
    return-object v5

    .line 255
    :pswitch_18
    check-cast p0, Lhj4;

    .line 256
    .line 257
    invoke-virtual {p0}, Lhj4;->a()V

    .line 258
    .line 259
    .line 260
    return-object v5

    .line 261
    :pswitch_19
    check-cast p0, Lhj4;

    .line 262
    .line 263
    invoke-virtual {p0}, Lhj4;->a()V

    .line 264
    .line 265
    .line 266
    return-object v5

    .line 267
    :pswitch_1a
    check-cast p0, Lhj4;

    .line 268
    .line 269
    invoke-virtual {p0}, Lhj4;->a()V

    .line 270
    .line 271
    .line 272
    return-object v5

    .line 273
    :pswitch_1b
    check-cast p0, Lhj4;

    .line 274
    .line 275
    invoke-virtual {p0}, Lhj4;->a()V

    .line 276
    .line 277
    .line 278
    return-object v5

    .line 279
    :pswitch_1c
    check-cast p0, Lhj4;

    .line 280
    .line 281
    invoke-virtual {p0}, Lhj4;->a()V

    .line 282
    .line 283
    .line 284
    return-object v5

    .line 285
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
