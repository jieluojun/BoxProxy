.class public final synthetic Lql;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Z

.field public final synthetic j:Lhh2;


# direct methods
.method public synthetic constructor <init>(BLhh2;Z)V
    .locals 0

    .line 12
    iput-byte p1, p0, Lql;->h:B

    iput-boolean p3, p0, Lql;->i:Z

    iput-object p2, p0, Lql;->j:Lhh2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lhh2;Z)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lql;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lql;->j:Lhh2;

    .line 8
    .line 9
    iput-boolean p2, p0, Lql;->i:Z

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lql;->h:B

    .line 4
    .line 5
    sget-object v2, Lea4;->h:Lea4;

    .line 6
    .line 7
    iget-object v3, v0, Lql;->j:Lhh2;

    .line 8
    .line 9
    iget-boolean v4, v0, Lql;->i:Z

    .line 10
    .line 11
    sget-object v5, Los7;->a:Los7;

    .line 12
    .line 13
    const/4 v6, 0x2

    .line 14
    const/4 v7, 0x1

    .line 15
    const/4 v8, 0x0

    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object/from16 v14, p1

    .line 20
    .line 21
    check-cast v14, Lki2;

    .line 22
    .line 23
    move-object/from16 v1, p2

    .line 24
    .line 25
    check-cast v1, Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    and-int/lit8 v2, v1, 0x3

    .line 32
    .line 33
    if-eq v2, v6, :cond_0

    .line 34
    .line 35
    move v8, v7

    .line 36
    :cond_0
    and-int/2addr v1, v7

    .line 37
    invoke-virtual {v14, v1, v8}, Lki2;->Y(IZ)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_1

    .line 42
    .line 43
    sget-object v1, Ls50;->m:Ls50;

    .line 44
    .line 45
    iget-object v10, v1, Ls50;->j:La53;

    .line 46
    .line 47
    const v1, 0x7f0f0486

    .line 48
    .line 49
    .line 50
    invoke-static {v1, v14}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v9

    .line 54
    const/4 v15, 0x0

    .line 55
    const/16 v16, 0x2a

    .line 56
    .line 57
    iget-boolean v11, v0, Lql;->i:Z

    .line 58
    .line 59
    const/4 v12, 0x0

    .line 60
    iget-object v13, v0, Lql;->j:Lhh2;

    .line 61
    .line 62
    invoke-static/range {v9 .. v16}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_1
    invoke-virtual {v14}, Lki2;->b0()V

    .line 67
    .line 68
    .line 69
    :goto_0
    return-object v5

    .line 70
    :pswitch_0
    move-object/from16 v11, p1

    .line 71
    .line 72
    check-cast v11, Lki2;

    .line 73
    .line 74
    move-object/from16 v1, p2

    .line 75
    .line 76
    check-cast v1, Ljava/lang/Integer;

    .line 77
    .line 78
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    and-int/lit8 v2, v1, 0x3

    .line 83
    .line 84
    if-eq v2, v6, :cond_2

    .line 85
    .line 86
    move v8, v7

    .line 87
    :cond_2
    and-int/2addr v1, v7

    .line 88
    invoke-virtual {v11, v1, v8}, Lki2;->Y(IZ)Z

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    if-eqz v1, :cond_3

    .line 93
    .line 94
    const v1, 0x7f0f032f

    .line 95
    .line 96
    .line 97
    invoke-static {v1, v11}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v6

    .line 101
    const/4 v12, 0x0

    .line 102
    const/16 v13, 0x2e

    .line 103
    .line 104
    const/4 v7, 0x0

    .line 105
    iget-boolean v8, v0, Lql;->i:Z

    .line 106
    .line 107
    const/4 v9, 0x0

    .line 108
    iget-object v10, v0, Lql;->j:Lhh2;

    .line 109
    .line 110
    invoke-static/range {v6 .. v13}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 111
    .line 112
    .line 113
    goto :goto_1

    .line 114
    :cond_3
    invoke-virtual {v11}, Lki2;->b0()V

    .line 115
    .line 116
    .line 117
    :goto_1
    return-object v5

    .line 118
    :pswitch_1
    move-object/from16 v0, p1

    .line 119
    .line 120
    check-cast v0, Lki2;

    .line 121
    .line 122
    move-object/from16 v1, p2

    .line 123
    .line 124
    check-cast v1, Ljava/lang/Integer;

    .line 125
    .line 126
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 127
    .line 128
    .line 129
    move-result v1

    .line 130
    and-int/lit8 v9, v1, 0x3

    .line 131
    .line 132
    if-eq v9, v6, :cond_4

    .line 133
    .line 134
    move v8, v7

    .line 135
    :cond_4
    and-int/2addr v1, v7

    .line 136
    invoke-virtual {v0, v1, v8}, Lki2;->Y(IZ)Z

    .line 137
    .line 138
    .line 139
    move-result v1

    .line 140
    if-eqz v1, :cond_5

    .line 141
    .line 142
    const/high16 v1, 0x3f800000    # 1.0f

    .line 143
    .line 144
    invoke-static {v2, v1}, Lit6;->e(Lha4;F)Lha4;

    .line 145
    .line 146
    .line 147
    move-result-object v12

    .line 148
    new-instance v1, Lbn;

    .line 149
    .line 150
    invoke-direct {v1, v4, v3}, Lbn;-><init>(ZLhh2;)V

    .line 151
    .line 152
    .line 153
    const v2, 0x610be1f6

    .line 154
    .line 155
    .line 156
    invoke-static {v2, v1, v0}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 157
    .line 158
    .line 159
    move-result-object v23

    .line 160
    const/16 v25, 0x6

    .line 161
    .line 162
    const/16 v26, 0x7fe

    .line 163
    .line 164
    const/4 v13, 0x0

    .line 165
    const/4 v14, 0x0

    .line 166
    const/4 v15, 0x0

    .line 167
    const/16 v16, 0x0

    .line 168
    .line 169
    const/16 v17, 0x0

    .line 170
    .line 171
    const/16 v18, 0x0

    .line 172
    .line 173
    const/16 v19, 0x0

    .line 174
    .line 175
    const/16 v20, 0x0

    .line 176
    .line 177
    const-wide/16 v21, 0x0

    .line 178
    .line 179
    move-object/from16 v24, v0

    .line 180
    .line 181
    invoke-static/range {v12 .. v26}, Ll64;->a(Lha4;FLu35;Lxl0;Lye5;ZLwg2;Lwg2;ZJLq21;Lki2;II)V

    .line 182
    .line 183
    .line 184
    goto :goto_2

    .line 185
    :cond_5
    move-object/from16 v24, v0

    .line 186
    .line 187
    invoke-virtual/range {v24 .. v24}, Lki2;->b0()V

    .line 188
    .line 189
    .line 190
    :goto_2
    return-object v5

    .line 191
    :pswitch_2
    move-object/from16 v12, p1

    .line 192
    .line 193
    check-cast v12, Lki2;

    .line 194
    .line 195
    move-object/from16 v0, p2

    .line 196
    .line 197
    check-cast v0, Ljava/lang/Integer;

    .line 198
    .line 199
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 200
    .line 201
    .line 202
    move-result v0

    .line 203
    and-int/lit8 v1, v0, 0x3

    .line 204
    .line 205
    if-eq v1, v6, :cond_6

    .line 206
    .line 207
    move v1, v7

    .line 208
    goto :goto_3

    .line 209
    :cond_6
    move v1, v8

    .line 210
    :goto_3
    and-int/2addr v0, v7

    .line 211
    invoke-virtual {v12, v0, v1}, Lki2;->Y(IZ)Z

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    if-eqz v0, :cond_9

    .line 216
    .line 217
    const/high16 v0, 0x42000000    # 32.0f

    .line 218
    .line 219
    invoke-static {v2, v0}, Lit6;->m(Lha4;F)Lha4;

    .line 220
    .line 221
    .line 222
    move-result-object v7

    .line 223
    invoke-virtual {v12, v3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 224
    .line 225
    .line 226
    move-result v0

    .line 227
    invoke-virtual {v12, v4}, Lki2;->h(Z)Z

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    or-int/2addr v0, v1

    .line 232
    invoke-virtual {v12}, Lki2;->T()Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object v1

    .line 236
    if-nez v0, :cond_7

    .line 237
    .line 238
    sget-object v0, Lz41;->a:Lql0;

    .line 239
    .line 240
    if-ne v1, v0, :cond_8

    .line 241
    .line 242
    :cond_7
    new-instance v1, Lvl;

    .line 243
    .line 244
    invoke-direct {v1, v8, v3, v4}, Lvl;-><init>(BLhh2;Z)V

    .line 245
    .line 246
    .line 247
    invoke-virtual {v12, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    :cond_8
    move-object v6, v1

    .line 251
    check-cast v6, Lwg2;

    .line 252
    .line 253
    new-instance v0, Lwl;

    .line 254
    .line 255
    invoke-direct {v0, v8, v4}, Lwl;-><init>(BZ)V

    .line 256
    .line 257
    .line 258
    const v1, -0x2f835d7c

    .line 259
    .line 260
    .line 261
    invoke-static {v1, v0, v12}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 262
    .line 263
    .line 264
    move-result-object v11

    .line 265
    const v13, 0x180030

    .line 266
    .line 267
    .line 268
    const/16 v14, 0x3c

    .line 269
    .line 270
    const/4 v8, 0x0

    .line 271
    const/4 v9, 0x0

    .line 272
    const/4 v10, 0x0

    .line 273
    invoke-static/range {v6 .. v14}, Ls33;->c(Lwg2;Lha4;ZLq33;Lkn6;Llh2;Lki2;II)V

    .line 274
    .line 275
    .line 276
    goto :goto_4

    .line 277
    :cond_9
    invoke-virtual {v12}, Lki2;->b0()V

    .line 278
    .line 279
    .line 280
    :goto_4
    return-object v5

    .line 281
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
