.class public final Lrc4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llv1;


# instance fields
.field public final h:Llv1;

.field public i:J


# direct methods
.method public constructor <init>(Llv1;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lrc4;->h:Llv1;

    .line 5
    .line 6
    invoke-super {p0}, Llv1;->b()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    iput-wide v0, p0, Lrc4;->i:J

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final A()F
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0}, Lso1;->A()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final A0(Luc;JJJFLey0;I)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 5
    .line 6
    invoke-interface/range {p0 .. p10}, Llv1;->A0(Luc;JJJFLey0;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final D0()J
    .locals 2

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0}, Llv1;->D0()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final G(Lbg0;JJJFLmv1;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 5
    .line 6
    const/high16 p8, 0x3f800000    # 1.0f

    .line 7
    .line 8
    invoke-interface/range {p0 .. p9}, Llv1;->G(Lbg0;JJJFLmv1;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final H0(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lso1;->H0(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final I(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lso1;->I(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final J(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lso1;->J(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final K(JJJJLmv1;)V
    .locals 0

    .line 1
    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 5
    .line 6
    invoke-interface/range {p0 .. p9}, Llv1;->K(JJJJLmv1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final L(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lso1;->L(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final O0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lso1;->O0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final Q(Luc;JFLey0;I)V
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p6}, Llv1;->Q(Luc;JFLey0;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final V()Lvh7;
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0}, Llv1;->V()Lvh7;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final V0(JJJFI)V
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p8}, Llv1;->V0(JJJFI)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final Z0(JFJLmv1;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p6}, Llv1;->Z0(JFJLmv1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final a()F
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0}, Lso1;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final a1(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lso1;->a1(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final b()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lrc4;->i:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final c0(J)I
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lso1;->c0(J)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final d0(Lcq2;JLhh2;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 5
    .line 6
    invoke-interface {p0, p1, p2, p3, p4}, Llv1;->d0(Lcq2;JLhh2;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final e0(JFFJJFLmv1;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p10}, Llv1;->e0(JFFJJFLmv1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final g0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lso1;->g0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final getLayoutDirection()Lgi3;
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0}, Llv1;->getLayoutDirection()Lgi3;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final l1(I)F
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lso1;->l1(I)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final p(Lbg0;JJFLmv1;I)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 5
    .line 6
    invoke-interface/range {p0 .. p8}, Llv1;->p(Lbg0;JJFLmv1;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final p1(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lso1;->p1(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final r(Lgd;Lbg0;FLmv1;I)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 11
    .line 12
    invoke-interface/range {p0 .. p5}, Llv1;->r(Lgd;Lbg0;FLmv1;I)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final s(Lgd;JFLmv1;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 8
    .line 9
    invoke-interface/range {p0 .. p5}, Llv1;->s(Lgd;JFLmv1;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final s0(F)I
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lso1;->s0(F)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final z0(JJJFI)V
    .locals 0

    .line 1
    iget-object p0, p0, Lrc4;->h:Llv1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p8}, Llv1;->z0(JJJFI)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
