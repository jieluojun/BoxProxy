.class public final synthetic Lml4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lvm4;

.field public final synthetic j:Lvo4;

.field public final synthetic k:Lwg2;


# direct methods
.method public synthetic constructor <init>(Lvm4;Lvo4;Lwg2;)V
    .locals 1

    .line 14
    const/4 v0, 0x1

    iput-byte v0, p0, Lml4;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lml4;->i:Lvm4;

    iput-object p2, p0, Lml4;->j:Lvo4;

    iput-object p3, p0, Lml4;->k:Lwg2;

    return-void
.end method

.method public synthetic constructor <init>(Lvo4;Lvm4;Lwg2;IB)V
    .locals 0

    .line 15
    iput-byte p5, p0, Lml4;->h:B

    iput-object p1, p0, Lml4;->j:Lvo4;

    iput-object p2, p0, Lml4;->i:Lvm4;

    iput-object p3, p0, Lml4;->k:Lwg2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lwg2;Lvm4;Lvo4;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Lml4;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lml4;->k:Lwg2;

    .line 8
    .line 9
    iput-object p2, p0, Lml4;->i:Lvm4;

    .line 10
    .line 11
    iput-object p3, p0, Lml4;->j:Lvo4;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lml4;->h:B

    .line 4
    .line 5
    sget-object v2, Lz41;->a:Lql0;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x0

    .line 9
    iget-object v5, v0, Lml4;->k:Lwg2;

    .line 10
    .line 11
    sget-object v6, Los7;->a:Los7;

    .line 12
    .line 13
    iget-object v7, v0, Lml4;->i:Lvm4;

    .line 14
    .line 15
    iget-object v8, v0, Lml4;->j:Lvo4;

    .line 16
    .line 17
    const/4 v9, 0x1

    .line 18
    packed-switch v1, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    move-object/from16 v0, p1

    .line 22
    .line 23
    check-cast v0, Lki2;

    .line 24
    .line 25
    move-object/from16 v1, p2

    .line 26
    .line 27
    check-cast v1, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-static {v9}, Ld43;->P(I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-static {v8, v7, v5, v0, v1}, Lx43;->h(Lvo4;Lvm4;Lwg2;Lki2;I)V

    .line 37
    .line 38
    .line 39
    return-object v6

    .line 40
    :pswitch_0
    move-object/from16 v1, p1

    .line 41
    .line 42
    check-cast v1, Lki2;

    .line 43
    .line 44
    move-object/from16 v5, p2

    .line 45
    .line 46
    check-cast v5, Ljava/lang/Integer;

    .line 47
    .line 48
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    and-int/lit8 v10, v5, 0x3

    .line 53
    .line 54
    if-eq v10, v3, :cond_0

    .line 55
    .line 56
    move v4, v9

    .line 57
    :cond_0
    and-int/2addr v5, v9

    .line 58
    invoke-virtual {v1, v5, v4}, Lki2;->Y(IZ)Z

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    if-eqz v3, :cond_4

    .line 63
    .line 64
    sget-object v3, Lea4;->h:Lea4;

    .line 65
    .line 66
    const/high16 v4, 0x3f800000    # 1.0f

    .line 67
    .line 68
    invoke-static {v3, v4}, Lit6;->e(Lha4;F)Lha4;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    new-instance v5, Luw;

    .line 73
    .line 74
    new-instance v10, Lt32;

    .line 75
    .line 76
    const/4 v11, 0x3

    .line 77
    invoke-direct {v10, v11}, Lt32;-><init>(B)V

    .line 78
    .line 79
    .line 80
    const/high16 v11, 0x41a00000    # 20.0f

    .line 81
    .line 82
    invoke-direct {v5, v11, v9, v10}, Luw;-><init>(FZLt32;)V

    .line 83
    .line 84
    .line 85
    sget-object v10, Ly6;->s:Lz30;

    .line 86
    .line 87
    const/4 v11, 0x6

    .line 88
    invoke-static {v5, v10, v1, v11}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 89
    .line 90
    .line 91
    move-result-object v5

    .line 92
    iget-wide v10, v1, Lki2;->U:J

    .line 93
    .line 94
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 95
    .line 96
    .line 97
    move-result v10

    .line 98
    invoke-virtual {v1}, Lki2;->m()Lr95;

    .line 99
    .line 100
    .line 101
    move-result-object v11

    .line 102
    invoke-static {v1, v3}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    sget-object v12, Lp41;->d:Ly6;

    .line 107
    .line 108
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    .line 110
    .line 111
    invoke-virtual {v1}, Lki2;->k0()V

    .line 112
    .line 113
    .line 114
    iget-boolean v12, v1, Lki2;->T:Z

    .line 115
    .line 116
    if-eqz v12, :cond_1

    .line 117
    .line 118
    sget-object v12, Lwi3;->Z:Lj43;

    .line 119
    .line 120
    invoke-virtual {v1, v12}, Lki2;->l(Lwg2;)V

    .line 121
    .line 122
    .line 123
    goto :goto_0

    .line 124
    :cond_1
    invoke-virtual {v1}, Lki2;->t0()V

    .line 125
    .line 126
    .line 127
    :goto_0
    sget-object v12, Ly6;->T:Lu31;

    .line 128
    .line 129
    invoke-static {v12, v1, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    sget-object v5, Ly6;->S:Lu31;

    .line 133
    .line 134
    invoke-static {v5, v1, v11}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 138
    .line 139
    .line 140
    move-result-object v5

    .line 141
    sget-object v10, Ly6;->U:Lu31;

    .line 142
    .line 143
    invoke-static {v10, v1, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    invoke-static {v1}, Lml6;->p(Lki2;)V

    .line 147
    .line 148
    .line 149
    sget-object v5, Ly6;->R:Lu31;

    .line 150
    .line 151
    invoke-static {v5, v1, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    const/high16 v3, 0x1040000

    .line 155
    .line 156
    invoke-static {v3, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v10

    .line 160
    new-instance v12, Lmj3;

    .line 161
    .line 162
    invoke-direct {v12, v4, v9}, Lmj3;-><init>(FZ)V

    .line 163
    .line 164
    .line 165
    const/16 v21, 0x0

    .line 166
    .line 167
    const/16 v22, 0xff8

    .line 168
    .line 169
    iget-object v11, v0, Lml4;->k:Lwg2;

    .line 170
    .line 171
    const/4 v13, 0x0

    .line 172
    const/4 v14, 0x0

    .line 173
    const/4 v15, 0x0

    .line 174
    const/16 v16, 0x0

    .line 175
    .line 176
    const/16 v17, 0x0

    .line 177
    .line 178
    const/16 v18, 0x0

    .line 179
    .line 180
    const/16 v19, 0x0

    .line 181
    .line 182
    move-object/from16 v20, v1

    .line 183
    .line 184
    invoke-static/range {v10 .. v22}, Lx53;->f(Ljava/lang/String;Lwg2;Lha4;ZFFFLm64;Lu35;Ld63;Lki2;II)V

    .line 185
    .line 186
    .line 187
    move-object/from16 v0, v20

    .line 188
    .line 189
    const v1, 0x7f0f0465

    .line 190
    .line 191
    .line 192
    invoke-static {v1, v0}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object v10

    .line 196
    invoke-virtual {v0, v7}, Lki2;->g(Ljava/lang/Object;)Z

    .line 197
    .line 198
    .line 199
    move-result v1

    .line 200
    invoke-virtual {v0, v8}, Lki2;->i(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    move-result v3

    .line 204
    or-int/2addr v1, v3

    .line 205
    invoke-virtual {v0, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result v3

    .line 209
    or-int/2addr v1, v3

    .line 210
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object v3

    .line 214
    if-nez v1, :cond_2

    .line 215
    .line 216
    if-ne v3, v2, :cond_3

    .line 217
    .line 218
    :cond_2
    new-instance v3, Lhl4;

    .line 219
    .line 220
    invoke-direct {v3, v7, v8, v11, v9}, Lhl4;-><init>(Lvm4;Lvo4;Lwg2;B)V

    .line 221
    .line 222
    .line 223
    invoke-virtual {v0, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 224
    .line 225
    .line 226
    :cond_3
    move-object v11, v3

    .line 227
    check-cast v11, Lwg2;

    .line 228
    .line 229
    new-instance v12, Lmj3;

    .line 230
    .line 231
    invoke-direct {v12, v4, v9}, Lmj3;-><init>(FZ)V

    .line 232
    .line 233
    .line 234
    const/high16 v21, 0xc00000

    .line 235
    .line 236
    const/16 v22, 0xf78

    .line 237
    .line 238
    const/4 v13, 0x0

    .line 239
    const/4 v14, 0x0

    .line 240
    const/4 v15, 0x0

    .line 241
    const/16 v16, 0x0

    .line 242
    .line 243
    sget-object v17, Lm64;->i:Lm64;

    .line 244
    .line 245
    const/16 v18, 0x0

    .line 246
    .line 247
    const/16 v19, 0x0

    .line 248
    .line 249
    move-object/from16 v20, v0

    .line 250
    .line 251
    invoke-static/range {v10 .. v22}, Lx53;->f(Ljava/lang/String;Lwg2;Lha4;ZFFFLm64;Lu35;Ld63;Lki2;II)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v0, v9}, Lki2;->r(Z)V

    .line 255
    .line 256
    .line 257
    goto :goto_1

    .line 258
    :cond_4
    move-object v0, v1

    .line 259
    invoke-virtual {v0}, Lki2;->b0()V

    .line 260
    .line 261
    .line 262
    :goto_1
    return-object v6

    .line 263
    :pswitch_1
    move-object/from16 v0, p1

    .line 264
    .line 265
    check-cast v0, Lki2;

    .line 266
    .line 267
    move-object/from16 v1, p2

    .line 268
    .line 269
    check-cast v1, Ljava/lang/Integer;

    .line 270
    .line 271
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 272
    .line 273
    .line 274
    move-result v1

    .line 275
    and-int/lit8 v10, v1, 0x3

    .line 276
    .line 277
    if-eq v10, v3, :cond_5

    .line 278
    .line 279
    move v3, v9

    .line 280
    goto :goto_2

    .line 281
    :cond_5
    move v3, v4

    .line 282
    :goto_2
    and-int/2addr v1, v9

    .line 283
    invoke-virtual {v0, v1, v3}, Lki2;->Y(IZ)Z

    .line 284
    .line 285
    .line 286
    move-result v1

    .line 287
    if-eqz v1, :cond_8

    .line 288
    .line 289
    invoke-virtual {v0, v7}, Lki2;->g(Ljava/lang/Object;)Z

    .line 290
    .line 291
    .line 292
    move-result v1

    .line 293
    invoke-virtual {v0, v8}, Lki2;->i(Ljava/lang/Object;)Z

    .line 294
    .line 295
    .line 296
    move-result v3

    .line 297
    or-int/2addr v1, v3

    .line 298
    invoke-virtual {v0, v5}, Lki2;->g(Ljava/lang/Object;)Z

    .line 299
    .line 300
    .line 301
    move-result v3

    .line 302
    or-int/2addr v1, v3

    .line 303
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v3

    .line 307
    if-nez v1, :cond_6

    .line 308
    .line 309
    if-ne v3, v2, :cond_7

    .line 310
    .line 311
    :cond_6
    new-instance v3, Lhl4;

    .line 312
    .line 313
    invoke-direct {v3, v7, v8, v5, v4}, Lhl4;-><init>(Lvm4;Lvo4;Lwg2;B)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v0, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 317
    .line 318
    .line 319
    :cond_7
    move-object v10, v3

    .line 320
    check-cast v10, Lwg2;

    .line 321
    .line 322
    sget-object v16, Ll80;->v:Lq21;

    .line 323
    .line 324
    const/high16 v18, 0x30000000

    .line 325
    .line 326
    const/16 v19, 0x1fe

    .line 327
    .line 328
    const/4 v11, 0x0

    .line 329
    const/4 v12, 0x0

    .line 330
    const/4 v13, 0x0

    .line 331
    const/4 v14, 0x0

    .line 332
    const/4 v15, 0x0

    .line 333
    move-object/from16 v17, v0

    .line 334
    .line 335
    invoke-static/range {v10 .. v19}, Lel;->u(Lwg2;Lha4;ZLkn6;Lah0;Lu35;Lmh2;Lki2;II)V

    .line 336
    .line 337
    .line 338
    goto :goto_3

    .line 339
    :cond_8
    move-object/from16 v17, v0

    .line 340
    .line 341
    invoke-virtual/range {v17 .. v17}, Lki2;->b0()V

    .line 342
    .line 343
    .line 344
    :goto_3
    return-object v6

    .line 345
    :pswitch_2
    move-object/from16 v0, p1

    .line 346
    .line 347
    check-cast v0, Lki2;

    .line 348
    .line 349
    move-object/from16 v1, p2

    .line 350
    .line 351
    check-cast v1, Ljava/lang/Integer;

    .line 352
    .line 353
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 354
    .line 355
    .line 356
    invoke-static {v9}, Ld43;->P(I)I

    .line 357
    .line 358
    .line 359
    move-result v1

    .line 360
    invoke-static {v8, v7, v5, v0, v1}, Lv43;->o(Lvo4;Lvm4;Lwg2;Lki2;I)V

    .line 361
    .line 362
    .line 363
    return-object v6

    .line 364
    nop

    .line 365
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
