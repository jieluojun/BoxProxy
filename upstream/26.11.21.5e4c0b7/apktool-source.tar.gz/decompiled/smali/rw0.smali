.class public final synthetic Lrw0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lzd4;

.field public final synthetic j:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lzd4;Lzd4;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lrw0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lrw0;->i:Lzd4;

    .line 4
    .line 5
    iput-object p2, p0, Lrw0;->j:Lzd4;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lrw0;->h:B

    .line 4
    .line 5
    const v2, 0x2fd4df92

    .line 6
    .line 7
    .line 8
    const-string v3, ""

    .line 9
    .line 10
    const/4 v4, 0x1

    .line 11
    sget-object v5, Los7;->a:Los7;

    .line 12
    .line 13
    iget-object v6, v0, Lrw0;->j:Lzd4;

    .line 14
    .line 15
    iget-object v0, v0, Lrw0;->i:Lzd4;

    .line 16
    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, Ljava/lang/Boolean;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Lhh2;

    .line 33
    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    invoke-interface {v0, v1}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    :cond_0
    invoke-interface {v6}, Lxy6;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    check-cast v0, Lkr2;

    .line 44
    .line 45
    if-eqz v2, :cond_1

    .line 46
    .line 47
    const/16 v1, 0x15

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_1
    const/16 v1, 0x16

    .line 51
    .line 52
    :goto_0
    check-cast v0, Lsa5;

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Lsa5;->a(I)V

    .line 55
    .line 56
    .line 57
    return-object v5

    .line 58
    :pswitch_0
    move-object/from16 v1, p1

    .line 59
    .line 60
    check-cast v1, Ljava/lang/Boolean;

    .line 61
    .line 62
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    if-nez v1, :cond_2

    .line 67
    .line 68
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 69
    .line 70
    invoke-interface {v0, v1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    invoke-interface {v6, v3}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_2
    return-object v5

    .line 77
    :pswitch_1
    move-object/from16 v1, p1

    .line 78
    .line 79
    check-cast v1, Ljava/lang/Boolean;

    .line 80
    .line 81
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v3

    .line 89
    check-cast v3, Ljava/lang/Boolean;

    .line 90
    .line 91
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 92
    .line 93
    .line 94
    move-result v3

    .line 95
    if-eq v3, v2, :cond_3

    .line 96
    .line 97
    invoke-interface {v0, v1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    invoke-interface {v6}, Lxy6;->getValue()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    check-cast v0, Lhh2;

    .line 105
    .line 106
    if-eqz v0, :cond_3

    .line 107
    .line 108
    invoke-interface {v0, v1}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    :cond_3
    return-object v5

    .line 112
    :pswitch_2
    move-object/from16 v1, p1

    .line 113
    .line 114
    check-cast v1, Ljava/lang/Boolean;

    .line 115
    .line 116
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 117
    .line 118
    .line 119
    move-result v1

    .line 120
    if-nez v1, :cond_4

    .line 121
    .line 122
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 123
    .line 124
    invoke-interface {v0, v1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    invoke-interface {v6, v3}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :cond_4
    return-object v5

    .line 131
    :pswitch_3
    move-object/from16 v1, p1

    .line 132
    .line 133
    check-cast v1, Lhm3;

    .line 134
    .line 135
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 136
    .line 137
    .line 138
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    check-cast v0, Ljava/util/List;

    .line 143
    .line 144
    new-instance v3, Lsk4;

    .line 145
    .line 146
    const/16 v7, 0xe

    .line 147
    .line 148
    invoke-direct {v3, v7}, Lsk4;-><init>(B)V

    .line 149
    .line 150
    .line 151
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 152
    .line 153
    .line 154
    move-result v7

    .line 155
    new-instance v8, Lf0;

    .line 156
    .line 157
    const/16 v9, 0x10

    .line 158
    .line 159
    invoke-direct {v8, v3, v0, v9}, Lf0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 160
    .line 161
    .line 162
    new-instance v3, Lg0;

    .line 163
    .line 164
    const/16 v9, 0x9

    .line 165
    .line 166
    invoke-direct {v3, v0, v9}, Lg0;-><init>(Ljava/util/List;B)V

    .line 167
    .line 168
    .line 169
    new-instance v9, Lhs0;

    .line 170
    .line 171
    const/4 v10, 0x3

    .line 172
    invoke-direct {v9, v0, v6, v10}, Lhs0;-><init>(Ljava/util/List;Lzd4;B)V

    .line 173
    .line 174
    .line 175
    new-instance v0, Lq21;

    .line 176
    .line 177
    invoke-direct {v0, v2, v4, v9}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    invoke-virtual {v1, v7, v8, v3, v0}, Lhm3;->c0(ILhh2;Lhh2;Lq21;)V

    .line 181
    .line 182
    .line 183
    return-object v5

    .line 184
    :pswitch_4
    move-object/from16 v1, p1

    .line 185
    .line 186
    check-cast v1, Lhm3;

    .line 187
    .line 188
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 189
    .line 190
    .line 191
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    check-cast v0, Ljava/util/List;

    .line 196
    .line 197
    new-instance v3, Lsk4;

    .line 198
    .line 199
    const/16 v7, 0xd

    .line 200
    .line 201
    invoke-direct {v3, v7}, Lsk4;-><init>(B)V

    .line 202
    .line 203
    .line 204
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 205
    .line 206
    .line 207
    move-result v7

    .line 208
    new-instance v8, Lf0;

    .line 209
    .line 210
    const/16 v9, 0xf

    .line 211
    .line 212
    invoke-direct {v8, v3, v0, v9}, Lf0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 213
    .line 214
    .line 215
    new-instance v3, Lg0;

    .line 216
    .line 217
    const/16 v9, 0x8

    .line 218
    .line 219
    invoke-direct {v3, v0, v9}, Lg0;-><init>(Ljava/util/List;B)V

    .line 220
    .line 221
    .line 222
    new-instance v9, Lhs0;

    .line 223
    .line 224
    const/4 v10, 0x2

    .line 225
    invoke-direct {v9, v0, v6, v10}, Lhs0;-><init>(Ljava/util/List;Lzd4;B)V

    .line 226
    .line 227
    .line 228
    new-instance v0, Lq21;

    .line 229
    .line 230
    invoke-direct {v0, v2, v4, v9}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v1, v7, v8, v3, v0}, Lhm3;->c0(ILhh2;Lhh2;Lq21;)V

    .line 234
    .line 235
    .line 236
    return-object v5

    .line 237
    :pswitch_5
    move-object/from16 v1, p1

    .line 238
    .line 239
    check-cast v1, Lfi3;

    .line 240
    .line 241
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 242
    .line 243
    .line 244
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    check-cast v0, Ljava/lang/Boolean;

    .line 249
    .line 250
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 251
    .line 252
    .line 253
    move-result v0

    .line 254
    if-nez v0, :cond_5

    .line 255
    .line 256
    invoke-static {v1, v4}, Lx43;->p(Lfi3;Z)Lsu5;

    .line 257
    .line 258
    .line 259
    move-result-object v0

    .line 260
    invoke-interface {v6, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 261
    .line 262
    .line 263
    :cond_5
    return-object v5

    .line 264
    :pswitch_6
    move-object/from16 v1, p1

    .line 265
    .line 266
    check-cast v1, Lqh1;

    .line 267
    .line 268
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 269
    .line 270
    .line 271
    new-instance v2, Lrh1;

    .line 272
    .line 273
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object v3

    .line 277
    check-cast v3, Lrh1;

    .line 278
    .line 279
    iget-object v3, v3, Lrh1;->b:Ljava/lang/String;

    .line 280
    .line 281
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v0

    .line 285
    check-cast v0, Lrh1;

    .line 286
    .line 287
    iget-object v0, v0, Lrh1;->c:Lse1;

    .line 288
    .line 289
    invoke-direct {v2, v1, v3, v0}, Lrh1;-><init>(Lqh1;Ljava/lang/String;Lse1;)V

    .line 290
    .line 291
    .line 292
    invoke-interface {v6, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 293
    .line 294
    .line 295
    return-object v5

    .line 296
    :pswitch_7
    move-object/from16 v19, p1

    .line 297
    .line 298
    check-cast v19, Lbi1;

    .line 299
    .line 300
    invoke-virtual/range {v19 .. v19}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 301
    .line 302
    .line 303
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v1

    .line 307
    move-object v7, v1

    .line 308
    check-cast v7, Lqh1;

    .line 309
    .line 310
    const/16 v20, 0x0

    .line 311
    .line 312
    const/16 v21, 0x17ff

    .line 313
    .line 314
    const/4 v8, 0x0

    .line 315
    const/4 v9, 0x0

    .line 316
    const/4 v10, 0x0

    .line 317
    const/4 v11, 0x0

    .line 318
    const/4 v12, 0x0

    .line 319
    const/4 v13, 0x0

    .line 320
    const/4 v14, 0x0

    .line 321
    const/4 v15, 0x0

    .line 322
    const/16 v16, 0x0

    .line 323
    .line 324
    const/16 v17, 0x0

    .line 325
    .line 326
    const/16 v18, 0x0

    .line 327
    .line 328
    invoke-static/range {v7 .. v21}, Lqh1;->a(Lqh1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Lbi1;ZI)Lqh1;

    .line 329
    .line 330
    .line 331
    move-result-object v1

    .line 332
    invoke-interface {v0, v1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 333
    .line 334
    .line 335
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 336
    .line 337
    invoke-interface {v6, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    return-object v5

    .line 341
    :pswitch_8
    move-object/from16 v1, p1

    .line 342
    .line 343
    check-cast v1, Ljava/lang/Integer;

    .line 344
    .line 345
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 346
    .line 347
    .line 348
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 349
    .line 350
    invoke-interface {v0, v1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 351
    .line 352
    .line 353
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 354
    .line 355
    invoke-interface {v6, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 356
    .line 357
    .line 358
    return-object v5

    .line 359
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
