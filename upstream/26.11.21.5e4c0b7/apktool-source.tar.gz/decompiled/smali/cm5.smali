.class public final synthetic Lcm5;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/util/List;

.field public final synthetic j:Lvo5;

.field public final synthetic k:Lhh2;

.field public final synthetic l:Ljava/util/Set;

.field public final synthetic m:I

.field public final synthetic n:Ljo5;

.field public final synthetic o:Ljava/util/Map;

.field public final synthetic p:Ljava/util/Map;

.field public final synthetic q:Ljava/util/Map;

.field public final synthetic r:Ljava/util/Set;

.field public final synthetic s:Ljava/util/Map;

.field public final synthetic t:Lak5;

.field public final synthetic u:Ljava/util/Map;

.field public final synthetic v:Lhh2;

.field public final synthetic w:Lhh2;

.field public final synthetic x:Lhh2;

.field public final synthetic y:Ljava/lang/String;

.field public final synthetic z:Llh2;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lvo5;ILjo5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lak5;Ljava/util/Map;Lhh2;Lhh2;Lhh2;Ljava/lang/String;Ljava/util/Set;Lhh2;Llh2;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lcm5;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcm5;->i:Ljava/util/List;

    .line 8
    .line 9
    iput-object p2, p0, Lcm5;->j:Lvo5;

    .line 10
    .line 11
    iput p3, p0, Lcm5;->m:I

    .line 12
    .line 13
    iput-object p4, p0, Lcm5;->n:Ljo5;

    .line 14
    .line 15
    iput-object p5, p0, Lcm5;->o:Ljava/util/Map;

    .line 16
    .line 17
    iput-object p6, p0, Lcm5;->p:Ljava/util/Map;

    .line 18
    .line 19
    iput-object p7, p0, Lcm5;->q:Ljava/util/Map;

    .line 20
    .line 21
    iput-object p8, p0, Lcm5;->l:Ljava/util/Set;

    .line 22
    .line 23
    iput-object p9, p0, Lcm5;->s:Ljava/util/Map;

    .line 24
    .line 25
    iput-object p10, p0, Lcm5;->t:Lak5;

    .line 26
    .line 27
    iput-object p11, p0, Lcm5;->u:Ljava/util/Map;

    .line 28
    .line 29
    iput-object p12, p0, Lcm5;->k:Lhh2;

    .line 30
    .line 31
    iput-object p13, p0, Lcm5;->v:Lhh2;

    .line 32
    .line 33
    iput-object p14, p0, Lcm5;->w:Lhh2;

    .line 34
    .line 35
    move-object/from16 p1, p15

    .line 36
    .line 37
    iput-object p1, p0, Lcm5;->y:Ljava/lang/String;

    .line 38
    .line 39
    move-object/from16 p1, p16

    .line 40
    .line 41
    iput-object p1, p0, Lcm5;->r:Ljava/util/Set;

    .line 42
    .line 43
    move-object/from16 p1, p17

    .line 44
    .line 45
    iput-object p1, p0, Lcm5;->x:Lhh2;

    .line 46
    .line 47
    move-object/from16 p1, p18

    .line 48
    .line 49
    iput-object p1, p0, Lcm5;->z:Llh2;

    .line 50
    .line 51
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Lvo5;Lhh2;Ljava/util/Set;ILjo5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lak5;Ljava/util/Map;Lhh2;Lhh2;Lhh2;Ljava/lang/String;Llh2;)V
    .locals 1

    .line 52
    const/4 v0, 0x1

    iput-byte v0, p0, Lcm5;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcm5;->i:Ljava/util/List;

    iput-object p2, p0, Lcm5;->j:Lvo5;

    iput-object p3, p0, Lcm5;->k:Lhh2;

    iput-object p4, p0, Lcm5;->l:Ljava/util/Set;

    iput p5, p0, Lcm5;->m:I

    iput-object p6, p0, Lcm5;->n:Ljo5;

    iput-object p7, p0, Lcm5;->o:Ljava/util/Map;

    iput-object p8, p0, Lcm5;->p:Ljava/util/Map;

    iput-object p9, p0, Lcm5;->q:Ljava/util/Map;

    iput-object p10, p0, Lcm5;->r:Ljava/util/Set;

    iput-object p11, p0, Lcm5;->s:Ljava/util/Map;

    iput-object p12, p0, Lcm5;->t:Lak5;

    iput-object p13, p0, Lcm5;->u:Ljava/util/Map;

    iput-object p14, p0, Lcm5;->v:Lhh2;

    move-object/from16 p1, p15

    iput-object p1, p0, Lcm5;->w:Lhh2;

    move-object/from16 p1, p16

    iput-object p1, p0, Lcm5;->x:Lhh2;

    move-object/from16 p1, p17

    iput-object p1, p0, Lcm5;->y:Ljava/lang/String;

    move-object/from16 p1, p18

    iput-object p1, p0, Lcm5;->z:Llh2;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lcm5;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    move-object/from16 v1, p1

    .line 11
    .line 12
    check-cast v1, Lhm3;

    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance v5, Lrk5;

    .line 18
    .line 19
    const/16 v6, 0xf

    .line 20
    .line 21
    invoke-direct {v5, v6}, Lrk5;-><init>(B)V

    .line 22
    .line 23
    .line 24
    iget-object v8, v0, Lcm5;->i:Ljava/util/List;

    .line 25
    .line 26
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    new-instance v7, Lf0;

    .line 31
    .line 32
    const/16 v9, 0x17

    .line 33
    .line 34
    invoke-direct {v7, v5, v8, v9}, Lf0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 35
    .line 36
    .line 37
    new-instance v5, Lg0;

    .line 38
    .line 39
    const/16 v9, 0xe

    .line 40
    .line 41
    invoke-direct {v5, v8, v9}, Lg0;-><init>(Ljava/util/List;B)V

    .line 42
    .line 43
    .line 44
    move-object v9, v7

    .line 45
    new-instance v7, Lim5;

    .line 46
    .line 47
    move-object v10, v9

    .line 48
    iget-object v9, v0, Lcm5;->j:Lvo5;

    .line 49
    .line 50
    move-object v11, v10

    .line 51
    iget-object v10, v0, Lcm5;->k:Lhh2;

    .line 52
    .line 53
    move-object v12, v11

    .line 54
    iget-object v11, v0, Lcm5;->l:Ljava/util/Set;

    .line 55
    .line 56
    move-object v13, v12

    .line 57
    iget v12, v0, Lcm5;->m:I

    .line 58
    .line 59
    move-object v14, v13

    .line 60
    iget-object v13, v0, Lcm5;->n:Ljo5;

    .line 61
    .line 62
    move-object v15, v14

    .line 63
    iget-object v14, v0, Lcm5;->o:Ljava/util/Map;

    .line 64
    .line 65
    move-object/from16 v16, v15

    .line 66
    .line 67
    iget-object v15, v0, Lcm5;->p:Ljava/util/Map;

    .line 68
    .line 69
    iget-object v3, v0, Lcm5;->q:Ljava/util/Map;

    .line 70
    .line 71
    iget-object v4, v0, Lcm5;->r:Ljava/util/Set;

    .line 72
    .line 73
    move-object/from16 v26, v2

    .line 74
    .line 75
    iget-object v2, v0, Lcm5;->s:Ljava/util/Map;

    .line 76
    .line 77
    move-object/from16 v18, v2

    .line 78
    .line 79
    iget-object v2, v0, Lcm5;->t:Lak5;

    .line 80
    .line 81
    move-object/from16 v19, v2

    .line 82
    .line 83
    iget-object v2, v0, Lcm5;->u:Ljava/util/Map;

    .line 84
    .line 85
    move-object/from16 v20, v2

    .line 86
    .line 87
    iget-object v2, v0, Lcm5;->v:Lhh2;

    .line 88
    .line 89
    move-object/from16 v21, v2

    .line 90
    .line 91
    iget-object v2, v0, Lcm5;->w:Lhh2;

    .line 92
    .line 93
    move-object/from16 v22, v2

    .line 94
    .line 95
    iget-object v2, v0, Lcm5;->x:Lhh2;

    .line 96
    .line 97
    move-object/from16 v23, v2

    .line 98
    .line 99
    iget-object v2, v0, Lcm5;->y:Ljava/lang/String;

    .line 100
    .line 101
    iget-object v0, v0, Lcm5;->z:Llh2;

    .line 102
    .line 103
    move-object/from16 v25, v0

    .line 104
    .line 105
    move-object/from16 v24, v2

    .line 106
    .line 107
    move-object/from16 v17, v4

    .line 108
    .line 109
    move-object/from16 v0, v16

    .line 110
    .line 111
    move-object/from16 v16, v3

    .line 112
    .line 113
    invoke-direct/range {v7 .. v25}, Lim5;-><init>(Ljava/util/List;Lvo5;Lhh2;Ljava/util/Set;ILjo5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lak5;Ljava/util/Map;Lhh2;Lhh2;Lhh2;Ljava/lang/String;Llh2;)V

    .line 114
    .line 115
    .line 116
    new-instance v2, Lq21;

    .line 117
    .line 118
    const/4 v3, 0x1

    .line 119
    const v4, 0x2fd4df92

    .line 120
    .line 121
    .line 122
    invoke-direct {v2, v4, v3, v7}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v1, v6, v0, v5, v2}, Lhm3;->c0(ILhh2;Lhh2;Lq21;)V

    .line 126
    .line 127
    .line 128
    return-object v26

    .line 129
    :pswitch_0
    move-object/from16 v26, v2

    .line 130
    .line 131
    move-object/from16 v1, p1

    .line 132
    .line 133
    check-cast v1, Lhm3;

    .line 134
    .line 135
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 136
    .line 137
    .line 138
    new-instance v2, Lrk5;

    .line 139
    .line 140
    const/4 v3, 0x7

    .line 141
    invoke-direct {v2, v3}, Lrk5;-><init>(B)V

    .line 142
    .line 143
    .line 144
    iget-object v5, v0, Lcm5;->i:Ljava/util/List;

    .line 145
    .line 146
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 147
    .line 148
    .line 149
    move-result v3

    .line 150
    new-instance v4, Lf0;

    .line 151
    .line 152
    const/16 v6, 0x15

    .line 153
    .line 154
    invoke-direct {v4, v2, v5, v6}, Lf0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 155
    .line 156
    .line 157
    new-instance v2, Lg0;

    .line 158
    .line 159
    const/16 v6, 0xc

    .line 160
    .line 161
    invoke-direct {v2, v5, v6}, Lg0;-><init>(Ljava/util/List;B)V

    .line 162
    .line 163
    .line 164
    move-object v6, v4

    .line 165
    new-instance v4, Lim5;

    .line 166
    .line 167
    move-object v7, v6

    .line 168
    iget-object v6, v0, Lcm5;->j:Lvo5;

    .line 169
    .line 170
    move-object v8, v7

    .line 171
    iget v7, v0, Lcm5;->m:I

    .line 172
    .line 173
    move-object v9, v8

    .line 174
    iget-object v8, v0, Lcm5;->n:Ljo5;

    .line 175
    .line 176
    move-object v10, v9

    .line 177
    iget-object v9, v0, Lcm5;->o:Ljava/util/Map;

    .line 178
    .line 179
    move-object v11, v10

    .line 180
    iget-object v10, v0, Lcm5;->p:Ljava/util/Map;

    .line 181
    .line 182
    move-object v12, v11

    .line 183
    iget-object v11, v0, Lcm5;->q:Ljava/util/Map;

    .line 184
    .line 185
    move-object v13, v12

    .line 186
    iget-object v12, v0, Lcm5;->l:Ljava/util/Set;

    .line 187
    .line 188
    move-object v14, v13

    .line 189
    iget-object v13, v0, Lcm5;->s:Ljava/util/Map;

    .line 190
    .line 191
    move-object v15, v14

    .line 192
    iget-object v14, v0, Lcm5;->t:Lak5;

    .line 193
    .line 194
    move-object/from16 v16, v15

    .line 195
    .line 196
    iget-object v15, v0, Lcm5;->u:Ljava/util/Map;

    .line 197
    .line 198
    move-object/from16 p1, v4

    .line 199
    .line 200
    iget-object v4, v0, Lcm5;->k:Lhh2;

    .line 201
    .line 202
    move-object/from16 v17, v4

    .line 203
    .line 204
    iget-object v4, v0, Lcm5;->v:Lhh2;

    .line 205
    .line 206
    move-object/from16 v18, v4

    .line 207
    .line 208
    iget-object v4, v0, Lcm5;->w:Lhh2;

    .line 209
    .line 210
    move-object/from16 v19, v4

    .line 211
    .line 212
    iget-object v4, v0, Lcm5;->y:Ljava/lang/String;

    .line 213
    .line 214
    move-object/from16 v20, v4

    .line 215
    .line 216
    iget-object v4, v0, Lcm5;->r:Ljava/util/Set;

    .line 217
    .line 218
    move-object/from16 v21, v4

    .line 219
    .line 220
    iget-object v4, v0, Lcm5;->x:Lhh2;

    .line 221
    .line 222
    iget-object v0, v0, Lcm5;->z:Llh2;

    .line 223
    .line 224
    move-object/from16 v22, v0

    .line 225
    .line 226
    move-object/from16 v0, v16

    .line 227
    .line 228
    move-object/from16 v16, v17

    .line 229
    .line 230
    move-object/from16 v17, v18

    .line 231
    .line 232
    move-object/from16 v18, v19

    .line 233
    .line 234
    move-object/from16 v19, v20

    .line 235
    .line 236
    move-object/from16 v20, v21

    .line 237
    .line 238
    move-object/from16 v21, v4

    .line 239
    .line 240
    move-object/from16 v4, p1

    .line 241
    .line 242
    invoke-direct/range {v4 .. v22}, Lim5;-><init>(Ljava/util/List;Lvo5;ILjo5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Lak5;Ljava/util/Map;Lhh2;Lhh2;Lhh2;Ljava/lang/String;Ljava/util/Set;Lhh2;Llh2;)V

    .line 243
    .line 244
    .line 245
    new-instance v5, Lq21;

    .line 246
    .line 247
    const/4 v6, 0x1

    .line 248
    const v7, 0x2fd4df92

    .line 249
    .line 250
    .line 251
    invoke-direct {v5, v7, v6, v4}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v1, v3, v0, v2, v5}, Lhm3;->c0(ILhh2;Lhh2;Lq21;)V

    .line 255
    .line 256
    .line 257
    return-object v26

    .line 258
    nop

    .line 259
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
