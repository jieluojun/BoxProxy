.class public final Ljl0;
.super Lva5;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final i:Ljl0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ljl0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-direct {v0, v1, v2}, Lva5;-><init>(Ljava/lang/String;B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Ljl0;->i:Ljl0;

    .line 9
    .line 10
    return-void
.end method
