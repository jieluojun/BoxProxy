.class public final synthetic Lh91;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:Lwg2;

.field public final synthetic i:Lhh2;

.field public final synthetic j:Z

.field public final synthetic k:Z

.field public final synthetic l:Ldy0;

.field public final synthetic m:Z

.field public final synthetic n:Z

.field public final synthetic o:Z

.field public final synthetic p:Lhh2;

.field public final synthetic q:Lhh2;

.field public final synthetic r:F

.field public final synthetic s:F

.field public final synthetic t:Lha4;

.field public final synthetic u:F

.field public final synthetic v:Lwg2;

.field public final synthetic w:Lwg2;

.field public final synthetic x:Lwg2;

.field public final synthetic y:Lha4;


# direct methods
.method public synthetic constructor <init>(Lwg2;Lhh2;ZZLdy0;ZZZLhh2;Lhh2;FFLha4;FLwg2;Lwg2;Lwg2;Lha4;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lh91;->h:Lwg2;

    .line 5
    .line 6
    iput-object p2, p0, Lh91;->i:Lhh2;

    .line 7
    .line 8
    iput-boolean p3, p0, Lh91;->j:Z

    .line 9
    .line 10
    iput-boolean p4, p0, Lh91;->k:Z

    .line 11
    .line 12
    iput-object p5, p0, Lh91;->l:Ldy0;

    .line 13
    .line 14
    iput-boolean p6, p0, Lh91;->m:Z

    .line 15
    .line 16
    iput-boolean p7, p0, Lh91;->n:Z

    .line 17
    .line 18
    iput-boolean p8, p0, Lh91;->o:Z

    .line 19
    .line 20
    iput-object p9, p0, Lh91;->p:Lhh2;

    .line 21
    .line 22
    iput-object p10, p0, Lh91;->q:Lhh2;

    .line 23
    .line 24
    iput p11, p0, Lh91;->r:F

    .line 25
    .line 26
    iput p12, p0, Lh91;->s:F

    .line 27
    .line 28
    iput-object p13, p0, Lh91;->t:Lha4;

    .line 29
    .line 30
    iput p14, p0, Lh91;->u:F

    .line 31
    .line 32
    iput-object p15, p0, Lh91;->v:Lwg2;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lh91;->w:Lwg2;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Lh91;->x:Lwg2;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lh91;->y:Lha4;

    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v18, p1

    .line 4
    .line 5
    check-cast v18, Lki2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const v1, 0x36c36c31

    .line 15
    .line 16
    .line 17
    invoke-static {v1}, Ld43;->P(I)I

    .line 18
    .line 19
    .line 20
    move-result v19

    .line 21
    iget-object v1, v0, Lh91;->h:Lwg2;

    .line 22
    .line 23
    move-object v2, v1

    .line 24
    iget-object v1, v0, Lh91;->i:Lhh2;

    .line 25
    .line 26
    move-object v3, v2

    .line 27
    iget-boolean v2, v0, Lh91;->j:Z

    .line 28
    .line 29
    move-object v4, v3

    .line 30
    iget-boolean v3, v0, Lh91;->k:Z

    .line 31
    .line 32
    move-object v5, v4

    .line 33
    iget-object v4, v0, Lh91;->l:Ldy0;

    .line 34
    .line 35
    move-object v6, v5

    .line 36
    iget-boolean v5, v0, Lh91;->m:Z

    .line 37
    .line 38
    move-object v7, v6

    .line 39
    iget-boolean v6, v0, Lh91;->n:Z

    .line 40
    .line 41
    move-object v8, v7

    .line 42
    iget-boolean v7, v0, Lh91;->o:Z

    .line 43
    .line 44
    move-object v9, v8

    .line 45
    iget-object v8, v0, Lh91;->p:Lhh2;

    .line 46
    .line 47
    move-object v10, v9

    .line 48
    iget-object v9, v0, Lh91;->q:Lhh2;

    .line 49
    .line 50
    move-object v11, v10

    .line 51
    iget v10, v0, Lh91;->r:F

    .line 52
    .line 53
    move-object v12, v11

    .line 54
    iget v11, v0, Lh91;->s:F

    .line 55
    .line 56
    move-object v13, v12

    .line 57
    iget-object v12, v0, Lh91;->t:Lha4;

    .line 58
    .line 59
    move-object v14, v13

    .line 60
    iget v13, v0, Lh91;->u:F

    .line 61
    .line 62
    move-object v15, v14

    .line 63
    iget-object v14, v0, Lh91;->v:Lwg2;

    .line 64
    .line 65
    move-object/from16 v16, v15

    .line 66
    .line 67
    iget-object v15, v0, Lh91;->w:Lwg2;

    .line 68
    .line 69
    move-object/from16 v17, v1

    .line 70
    .line 71
    iget-object v1, v0, Lh91;->x:Lwg2;

    .line 72
    .line 73
    iget-object v0, v0, Lh91;->y:Lha4;

    .line 74
    .line 75
    move-object/from16 v20, v17

    .line 76
    .line 77
    move-object/from16 v17, v0

    .line 78
    .line 79
    move-object/from16 v0, v16

    .line 80
    .line 81
    move-object/from16 v16, v1

    .line 82
    .line 83
    move-object/from16 v1, v20

    .line 84
    .line 85
    invoke-static/range {v0 .. v19}, Ljj;->r(Lwg2;Lhh2;ZZLdy0;ZZZLhh2;Lhh2;FFLha4;FLwg2;Lwg2;Lwg2;Lha4;Lki2;I)V

    .line 86
    .line 87
    .line 88
    sget-object v0, Los7;->a:Los7;

    .line 89
    .line 90
    return-object v0
.end method
