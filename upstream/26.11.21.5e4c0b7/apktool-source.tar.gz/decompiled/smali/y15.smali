.class public final synthetic Ly15;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lb35;

.field public final synthetic j:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lb35;Lzd4;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Ly15;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Ly15;->i:Lb35;

    .line 4
    .line 5
    iput-object p2, p0, Ly15;->j:Lzd4;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Ly15;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    iget-object v2, p0, Ly15;->j:Lzd4;

    .line 6
    .line 7
    iget-object p0, p0, Ly15;->i:Lb35;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget-object p0, p0, Lb35;->v:Lwg2;

    .line 13
    .line 14
    invoke-interface {p0}, Lwg2;->a()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 18
    .line 19
    invoke-interface {v2, p0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    return-object v1

    .line 23
    :pswitch_0
    iget-object p0, p0, Lb35;->v:Lwg2;

    .line 24
    .line 25
    invoke-interface {p0}, Lwg2;->a()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 29
    .line 30
    invoke-interface {v2, p0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    return-object v1

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
