.class public final Lsp2;
.super Lkp2;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public A:Ltj0;

.field public v:Ltj0;

.field public w:Ltj0;

.field public x:Ltj0;

.field public y:Ltj0;

.field public z:Ltj0;


# virtual methods
.method public final c(Lorg/xml/sax/Attributes;ILrb6;Ljava/lang/String;)Z
    .locals 3

    .line 1
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x13

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eq v0, v1, :cond_2

    .line 9
    .line 10
    const/16 v1, 0x14

    .line 11
    .line 12
    if-eq v0, v1, :cond_1

    .line 13
    .line 14
    const/16 v1, 0x82

    .line 15
    .line 16
    if-eq v0, v1, :cond_0

    .line 17
    .line 18
    packed-switch v0, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    invoke-super {p0, p1, p2, p3, p4}, Lkp2;->c(Lorg/xml/sax/Attributes;ILrb6;Ljava/lang/String;)Z

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    return p0

    .line 26
    :pswitch_0
    const-string p1, "Invalid <radialGradient> element. fr cannot be negative"

    .line 27
    .line 28
    invoke-static {p4, p1}, Lwi;->X(Ljava/lang/String;Ljava/lang/String;)Ltj0;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iput-object p1, p0, Lsp2;->A:Ltj0;

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :pswitch_1
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    invoke-static {v2, p4, p1}, Lwi;->T(ILjava/lang/String;I)Ltj0;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    iput-object p1, p0, Lsp2;->z:Ltj0;

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :pswitch_2
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    invoke-static {v2, p4, p1}, Lwi;->T(ILjava/lang/String;I)Ltj0;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    iput-object p1, p0, Lsp2;->y:Ltj0;

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_0
    const-string p1, "Invalid <radialGradient> element. r cannot be negative"

    .line 58
    .line 59
    invoke-static {p4, p1}, Lwi;->X(Ljava/lang/String;Ljava/lang/String;)Ltj0;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    iput-object p1, p0, Lsp2;->x:Ltj0;

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_1
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    invoke-static {v2, p4, p1}, Lwi;->T(ILjava/lang/String;I)Ltj0;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    iput-object p1, p0, Lsp2;->w:Ltj0;

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_2
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 78
    .line 79
    .line 80
    move-result p1

    .line 81
    invoke-static {v2, p4, p1}, Lwi;->T(ILjava/lang/String;I)Ltj0;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    iput-object p1, p0, Lsp2;->v:Ltj0;

    .line 86
    .line 87
    :goto_0
    const/4 p0, 0x1

    .line 88
    return p0

    .line 89
    :pswitch_data_0
    .packed-switch 0x1a
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
