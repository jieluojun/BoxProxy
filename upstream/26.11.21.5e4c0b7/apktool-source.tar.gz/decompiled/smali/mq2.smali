.class public Lmq2;
.super Lf61;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# virtual methods
.method public q()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "g"

    .line 2
    .line 3
    return-object p0
.end method
