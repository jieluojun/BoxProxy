.class public final Lrv6;
.super Ljz6;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(JLjava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Ljz6;-><init>(J)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lrv6;->c:Ljava/lang/Object;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljz6;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    check-cast p1, Lrv6;

    .line 5
    .line 6
    iget-object p1, p1, Lrv6;->c:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p1, p0, Lrv6;->c:Ljava/lang/Object;

    .line 9
    .line 10
    return-void
.end method

.method public final b()Ljz6;
    .locals 3

    .line 1
    new-instance v0, Lrv6;

    .line 2
    .line 3
    invoke-static {}, Llv6;->h()Lev6;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v1}, Lev6;->g()J

    .line 8
    .line 9
    .line 10
    move-result-wide v1

    .line 11
    iget-object p0, p0, Lrv6;->c:Ljava/lang/Object;

    .line 12
    .line 13
    invoke-direct {v0, v1, v2, p0}, Lrv6;-><init>(JLjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public final c(J)Ljz6;
    .locals 1

    .line 1
    new-instance v0, Lrv6;

    .line 2
    .line 3
    iget-object p0, p0, Lrv6;->c:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {v0, p1, p2, p0}, Lrv6;-><init>(JLjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method
