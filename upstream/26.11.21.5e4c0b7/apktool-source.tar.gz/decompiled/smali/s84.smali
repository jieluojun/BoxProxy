.class public final Ls84;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lzd4;

.field public final b:F

.field public final c:Lf75;

.field public final d:Lf75;

.field public final e:Lf75;

.field public final f:Lf75;

.field public final g:Lf75;

.field public final h:Lf75;

.field public final i:Lf75;


# direct methods
.method public constructor <init>(Lzd4;F)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ls84;->a:Lzd4;

    .line 5
    .line 6
    iput p2, p0, Ls84;->b:F

    .line 7
    .line 8
    const/4 p1, 0x0

    .line 9
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 10
    .line 11
    .line 12
    move-result-object p2

    .line 13
    iput-object p2, p0, Ls84;->c:Lf75;

    .line 14
    .line 15
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    iput-object p2, p0, Ls84;->d:Lf75;

    .line 20
    .line 21
    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 22
    .line 23
    invoke-static {p2}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, Ls84;->e:Lf75;

    .line 28
    .line 29
    invoke-static {p2}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    iput-object p2, p0, Ls84;->f:Lf75;

    .line 34
    .line 35
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    iput-object p2, p0, Ls84;->g:Lf75;

    .line 40
    .line 41
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    iput-object p1, p0, Ls84;->h:Lf75;

    .line 46
    .line 47
    sget-object p1, Lx87;->v:Lq21;

    .line 48
    .line 49
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    iput-object p1, p0, Ls84;->i:Lf75;

    .line 54
    .line 55
    return-void
.end method
