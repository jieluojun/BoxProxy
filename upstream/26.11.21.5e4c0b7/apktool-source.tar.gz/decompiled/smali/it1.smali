.class public interface abstract Lit1;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# virtual methods
.method public abstract M(Lbt1;)V
.end method

.method public abstract O(Lbt1;)V
.end method

.method public abstract f1(Lbt1;)Z
.end method

.method public abstract i0(Lbt1;)V
.end method

.method public abstract k0(Lbt1;)V
.end method

.method public abstract p0(Lbt1;)V
.end method
