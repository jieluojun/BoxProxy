.class public final synthetic Lcc7;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:Lq21;

.field public final synthetic i:Ljava/lang/CharSequence;

.field public final synthetic j:Lq21;

.field public final synthetic k:Lq21;

.field public final synthetic l:Lq21;

.field public final synthetic m:Lq21;

.field public final synthetic n:Lq21;

.field public final synthetic o:Lq21;

.field public final synthetic p:Z

.field public final synthetic q:Lnc7;

.field public final synthetic r:Ljc7;

.field public final synthetic s:Ljc7;

.field public final synthetic t:Ljc7;

.field public final synthetic u:Lq21;

.field public final synthetic v:Lq21;

.field public final synthetic w:Lu35;


# direct methods
.method public synthetic constructor <init>(Lq21;Ljava/lang/CharSequence;Lq21;Lq21;Lq21;Lq21;Lq21;Lq21;ZLnc7;Ljc7;Ljc7;Ljc7;Lq21;Lq21;Lu35;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcc7;->h:Lq21;

    .line 5
    .line 6
    iput-object p2, p0, Lcc7;->i:Ljava/lang/CharSequence;

    .line 7
    .line 8
    iput-object p3, p0, Lcc7;->j:Lq21;

    .line 9
    .line 10
    iput-object p4, p0, Lcc7;->k:Lq21;

    .line 11
    .line 12
    iput-object p5, p0, Lcc7;->l:Lq21;

    .line 13
    .line 14
    iput-object p6, p0, Lcc7;->m:Lq21;

    .line 15
    .line 16
    iput-object p7, p0, Lcc7;->n:Lq21;

    .line 17
    .line 18
    iput-object p8, p0, Lcc7;->o:Lq21;

    .line 19
    .line 20
    iput-boolean p9, p0, Lcc7;->p:Z

    .line 21
    .line 22
    iput-object p10, p0, Lcc7;->q:Lnc7;

    .line 23
    .line 24
    iput-object p11, p0, Lcc7;->r:Ljc7;

    .line 25
    .line 26
    iput-object p12, p0, Lcc7;->s:Ljc7;

    .line 27
    .line 28
    iput-object p13, p0, Lcc7;->t:Ljc7;

    .line 29
    .line 30
    iput-object p14, p0, Lcc7;->u:Lq21;

    .line 31
    .line 32
    iput-object p15, p0, Lcc7;->v:Lq21;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lcc7;->w:Lu35;

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v16, p1

    .line 4
    .line 5
    check-cast v16, Lki2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const/16 v1, 0x37

    .line 15
    .line 16
    invoke-static {v1}, Ld43;->P(I)I

    .line 17
    .line 18
    .line 19
    move-result v17

    .line 20
    iget-object v1, v0, Lcc7;->h:Lq21;

    .line 21
    .line 22
    move-object v2, v1

    .line 23
    iget-object v1, v0, Lcc7;->i:Ljava/lang/CharSequence;

    .line 24
    .line 25
    move-object v3, v2

    .line 26
    iget-object v2, v0, Lcc7;->j:Lq21;

    .line 27
    .line 28
    move-object v4, v3

    .line 29
    iget-object v3, v0, Lcc7;->k:Lq21;

    .line 30
    .line 31
    move-object v5, v4

    .line 32
    iget-object v4, v0, Lcc7;->l:Lq21;

    .line 33
    .line 34
    move-object v6, v5

    .line 35
    iget-object v5, v0, Lcc7;->m:Lq21;

    .line 36
    .line 37
    move-object v7, v6

    .line 38
    iget-object v6, v0, Lcc7;->n:Lq21;

    .line 39
    .line 40
    move-object v8, v7

    .line 41
    iget-object v7, v0, Lcc7;->o:Lq21;

    .line 42
    .line 43
    move-object v9, v8

    .line 44
    iget-boolean v8, v0, Lcc7;->p:Z

    .line 45
    .line 46
    move-object v10, v9

    .line 47
    iget-object v9, v0, Lcc7;->q:Lnc7;

    .line 48
    .line 49
    move-object v11, v10

    .line 50
    iget-object v10, v0, Lcc7;->r:Ljc7;

    .line 51
    .line 52
    move-object v12, v11

    .line 53
    iget-object v11, v0, Lcc7;->s:Ljc7;

    .line 54
    .line 55
    move-object v13, v12

    .line 56
    iget-object v12, v0, Lcc7;->t:Ljc7;

    .line 57
    .line 58
    move-object v14, v13

    .line 59
    iget-object v13, v0, Lcc7;->u:Lq21;

    .line 60
    .line 61
    move-object v15, v14

    .line 62
    iget-object v14, v0, Lcc7;->v:Lq21;

    .line 63
    .line 64
    iget-object v0, v0, Lcc7;->w:Lu35;

    .line 65
    .line 66
    move-object/from16 v18, v15

    .line 67
    .line 68
    move-object v15, v0

    .line 69
    move-object/from16 v0, v18

    .line 70
    .line 71
    invoke-static/range {v0 .. v17}, Lzi6;->f(Lq21;Ljava/lang/CharSequence;Lq21;Lq21;Lq21;Lq21;Lq21;Lq21;ZLnc7;Ljc7;Ljc7;Ljc7;Lq21;Lq21;Lu35;Lki2;I)V

    .line 72
    .line 73
    .line 74
    sget-object v0, Los7;->a:Los7;

    .line 75
    .line 76
    return-object v0
.end method
