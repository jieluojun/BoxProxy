.class public final Lbp;
.super Lgd1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public k:Ljava/io/InputStream;

.field public l:Ljava/util/Set;

.field public m:Landroid/content/Context;

.field public n:Ljava/io/File;

.field public o:Ljava/lang/Object;

.field public synthetic p:Ljava/lang/Object;

.field public final synthetic q:Llp;

.field public r:I


# direct methods
.method public constructor <init>(Llp;Lgd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lbp;->q:Llp;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lgd1;-><init>(Lfd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lbp;->p:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lbp;->r:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lbp;->r:I

    .line 9
    .line 10
    iget-object p1, p0, Lbp;->q:Llp;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, v0, p0}, Llp;->i(Landroid/content/Context;Ljava/io/InputStream;Ljava/util/Set;Lgd1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    sget-object p1, Lsi1;->h:Lsi1;

    .line 18
    .line 19
    if-ne p0, p1, :cond_0

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_0
    new-instance p1, Loy5;

    .line 23
    .line 24
    invoke-direct {p1, p0}, Loy5;-><init>(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-object p1
.end method
