.class public final Ll54;
.super Lgd1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public k:Ln54;

.field public synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ln54;

.field public n:I


# direct methods
.method public constructor <init>(Ln54;Lgd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ll54;->m:Ln54;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lgd1;-><init>(Lfd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Ll54;->l:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Ll54;->n:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Ll54;->n:I

    .line 9
    .line 10
    iget-object p1, p0, Ll54;->m:Ln54;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, v0, p0}, Ln54;->o(Lwp5;Landroid/content/Context;Ljava/lang/String;Lgd1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
