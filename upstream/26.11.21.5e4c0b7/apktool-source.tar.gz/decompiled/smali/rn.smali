.class public final synthetic Lrn;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic A:Lt66;

.field public final synthetic h:Lrk;

.field public final synthetic i:Lor7;

.field public final synthetic j:Lwg2;

.field public final synthetic k:Ldy0;

.field public final synthetic l:F

.field public final synthetic m:F

.field public final synthetic n:Lha4;

.field public final synthetic o:F

.field public final synthetic p:Lwg2;

.field public final synthetic q:Lwg2;

.field public final synthetic r:Lwg2;

.field public final synthetic s:Lwg2;

.field public final synthetic t:Llh2;

.field public final synthetic u:Z

.field public final synthetic v:Llh2;

.field public final synthetic w:Lhh2;

.field public final synthetic x:Lhh2;

.field public final synthetic y:Lwg2;

.field public final synthetic z:Z


# direct methods
.method public synthetic constructor <init>(Lrk;Lor7;Lwg2;Ldy0;FFLha4;FLwg2;Lwg2;Lwg2;Lwg2;Llh2;ZLlh2;Lhh2;Lhh2;Lwg2;ZLt66;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lrn;->h:Lrk;

    .line 5
    .line 6
    iput-object p2, p0, Lrn;->i:Lor7;

    .line 7
    .line 8
    iput-object p3, p0, Lrn;->j:Lwg2;

    .line 9
    .line 10
    iput-object p4, p0, Lrn;->k:Ldy0;

    .line 11
    .line 12
    iput p5, p0, Lrn;->l:F

    .line 13
    .line 14
    iput p6, p0, Lrn;->m:F

    .line 15
    .line 16
    iput-object p7, p0, Lrn;->n:Lha4;

    .line 17
    .line 18
    iput p8, p0, Lrn;->o:F

    .line 19
    .line 20
    iput-object p9, p0, Lrn;->p:Lwg2;

    .line 21
    .line 22
    iput-object p10, p0, Lrn;->q:Lwg2;

    .line 23
    .line 24
    iput-object p11, p0, Lrn;->r:Lwg2;

    .line 25
    .line 26
    iput-object p12, p0, Lrn;->s:Lwg2;

    .line 27
    .line 28
    iput-object p13, p0, Lrn;->t:Llh2;

    .line 29
    .line 30
    iput-boolean p14, p0, Lrn;->u:Z

    .line 31
    .line 32
    iput-object p15, p0, Lrn;->v:Llh2;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lrn;->w:Lhh2;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Lrn;->x:Lhh2;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lrn;->y:Lwg2;

    .line 45
    .line 46
    move/from16 p1, p19

    .line 47
    .line 48
    iput-boolean p1, p0, Lrn;->z:Z

    .line 49
    .line 50
    move-object/from16 p1, p20

    .line 51
    .line 52
    iput-object p1, p0, Lrn;->A:Lt66;

    .line 53
    .line 54
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 33

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v13, p1

    .line 4
    .line 5
    check-cast v13, Lki2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    and-int/lit8 v2, v1, 0x3

    .line 16
    .line 17
    const/4 v15, 0x0

    .line 18
    const/4 v3, 0x1

    .line 19
    const/4 v4, 0x2

    .line 20
    if-eq v2, v4, :cond_0

    .line 21
    .line 22
    move v2, v3

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    move v2, v15

    .line 25
    :goto_0
    and-int/2addr v1, v3

    .line 26
    invoke-virtual {v13, v1, v2}, Lki2;->Y(IZ)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_73

    .line 31
    .line 32
    iget-object v1, v0, Lrn;->h:Lrk;

    .line 33
    .line 34
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    iget-object v8, v0, Lrn;->i:Lor7;

    .line 39
    .line 40
    iget-object v7, v0, Lrn;->j:Lwg2;

    .line 41
    .line 42
    iget-object v4, v0, Lrn;->k:Ldy0;

    .line 43
    .line 44
    iget v5, v0, Lrn;->l:F

    .line 45
    .line 46
    iget v6, v0, Lrn;->m:F

    .line 47
    .line 48
    move-object/from16 v25, v8

    .line 49
    .line 50
    iget-object v8, v0, Lrn;->n:Lha4;

    .line 51
    .line 52
    iget v9, v0, Lrn;->o:F

    .line 53
    .line 54
    iget-object v12, v0, Lrn;->t:Llh2;

    .line 55
    .line 56
    iget-boolean v14, v0, Lrn;->u:Z

    .line 57
    .line 58
    iget-object v11, v0, Lrn;->v:Llh2;

    .line 59
    .line 60
    move-object/from16 v28, v4

    .line 61
    .line 62
    iget-object v4, v0, Lrn;->A:Lt66;

    .line 63
    .line 64
    const/high16 v29, 0x41400000    # 12.0f

    .line 65
    .line 66
    const/high16 v30, 0x41c00000    # 24.0f

    .line 67
    .line 68
    sget-object v10, Lz41;->a:Lql0;

    .line 69
    .line 70
    const/4 v3, 0x3

    .line 71
    packed-switch v2, :pswitch_data_0

    .line 72
    .line 73
    .line 74
    const v0, -0x26466627

    .line 75
    .line 76
    .line 77
    invoke-static {v0, v13, v15}, Lx82;->f(ILki2;Z)Ll11;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    throw v0

    .line 82
    :pswitch_0
    const v0, 0x5e5a9f68

    .line 83
    .line 84
    .line 85
    invoke-virtual {v13, v0}, Lki2;->h0(I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-eqz v0, :cond_7

    .line 93
    .line 94
    const/4 v2, 0x1

    .line 95
    if-ne v0, v2, :cond_6

    .line 96
    .line 97
    const v0, -0x263e930b

    .line 98
    .line 99
    .line 100
    invoke-virtual {v13, v0}, Lki2;->h0(I)V

    .line 101
    .line 102
    .line 103
    if-eqz v14, :cond_1

    .line 104
    .line 105
    move/from16 v29, v30

    .line 106
    .line 107
    :cond_1
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 112
    .line 113
    .line 114
    move-result v2

    .line 115
    invoke-virtual {v13, v2}, Lki2;->e(I)Z

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    or-int/2addr v0, v2

    .line 120
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    if-nez v0, :cond_2

    .line 125
    .line 126
    if-ne v2, v10, :cond_3

    .line 127
    .line 128
    :cond_2
    new-instance v2, Lnn;

    .line 129
    .line 130
    const/16 v0, 0xf

    .line 131
    .line 132
    invoke-direct {v2, v12, v1, v0}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v13, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    :cond_3
    check-cast v2, Lhh2;

    .line 139
    .line 140
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 145
    .line 146
    .line 147
    move-result v3

    .line 148
    invoke-virtual {v13, v3}, Lki2;->e(I)Z

    .line 149
    .line 150
    .line 151
    move-result v3

    .line 152
    or-int/2addr v0, v3

    .line 153
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v3

    .line 157
    if-nez v0, :cond_4

    .line 158
    .line 159
    if-ne v3, v10, :cond_5

    .line 160
    .line 161
    :cond_4
    new-instance v3, Lnn;

    .line 162
    .line 163
    const/16 v0, 0x10

    .line 164
    .line 165
    invoke-direct {v3, v11, v1, v0}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v13, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    :cond_5
    move-object v11, v3

    .line 172
    check-cast v11, Lhh2;

    .line 173
    .line 174
    sget-object v12, Lit6;->c:Lk92;

    .line 175
    .line 176
    const/16 v14, 0x1b0

    .line 177
    .line 178
    const/4 v1, 0x0

    .line 179
    move-object v10, v2

    .line 180
    const/4 v2, 0x1

    .line 181
    move-object v0, v7

    .line 182
    move-object/from16 v3, v28

    .line 183
    .line 184
    move/from16 v7, v29

    .line 185
    .line 186
    invoke-static/range {v0 .. v14}, Lx53;->k(Lwg2;ZZLdy0;Lt66;FFFLha4;FLhh2;Lhh2;Lha4;Lki2;I)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v13, v15}, Lki2;->r(Z)V

    .line 190
    .line 191
    .line 192
    goto/16 :goto_1

    .line 193
    .line 194
    :cond_6
    const v0, -0x263f2426

    .line 195
    .line 196
    .line 197
    invoke-static {v0, v13, v15}, Lx82;->f(ILki2;Z)Ll11;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    throw v0

    .line 202
    :cond_7
    move v2, v5

    .line 203
    move v5, v6

    .line 204
    move-object v0, v7

    .line 205
    move-object/from16 v18, v8

    .line 206
    .line 207
    move v6, v9

    .line 208
    move-object/from16 v3, v28

    .line 209
    .line 210
    const v7, -0x263f1e50

    .line 211
    .line 212
    .line 213
    invoke-virtual {v13, v7}, Lki2;->h0(I)V

    .line 214
    .line 215
    .line 216
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result v7

    .line 220
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 221
    .line 222
    .line 223
    move-result v8

    .line 224
    invoke-virtual {v13, v8}, Lki2;->e(I)Z

    .line 225
    .line 226
    .line 227
    move-result v8

    .line 228
    or-int/2addr v7, v8

    .line 229
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v8

    .line 233
    if-nez v7, :cond_8

    .line 234
    .line 235
    if-ne v8, v10, :cond_9

    .line 236
    .line 237
    :cond_8
    new-instance v8, Lnn;

    .line 238
    .line 239
    const/16 v7, 0xd

    .line 240
    .line 241
    invoke-direct {v8, v12, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v13, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    :cond_9
    move-object v9, v8

    .line 248
    check-cast v9, Lhh2;

    .line 249
    .line 250
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 251
    .line 252
    .line 253
    move-result v7

    .line 254
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 255
    .line 256
    .line 257
    move-result v8

    .line 258
    invoke-virtual {v13, v8}, Lki2;->e(I)Z

    .line 259
    .line 260
    .line 261
    move-result v8

    .line 262
    or-int/2addr v7, v8

    .line 263
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 264
    .line 265
    .line 266
    move-result-object v8

    .line 267
    if-nez v7, :cond_a

    .line 268
    .line 269
    if-ne v8, v10, :cond_b

    .line 270
    .line 271
    :cond_a
    new-instance v8, Lnn;

    .line 272
    .line 273
    const/16 v7, 0xe

    .line 274
    .line 275
    invoke-direct {v8, v11, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v13, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 279
    .line 280
    .line 281
    :cond_b
    move-object v10, v8

    .line 282
    check-cast v10, Lhh2;

    .line 283
    .line 284
    sget-object v11, Lit6;->c:Lk92;

    .line 285
    .line 286
    move-object/from16 v17, v13

    .line 287
    .line 288
    const v13, 0x60001b0

    .line 289
    .line 290
    .line 291
    const/4 v1, 0x0

    .line 292
    move v8, v2

    .line 293
    const/4 v2, 0x1

    .line 294
    move v7, v5

    .line 295
    move v5, v6

    .line 296
    move v6, v8

    .line 297
    move-object/from16 v12, v17

    .line 298
    .line 299
    move-object/from16 v8, v18

    .line 300
    .line 301
    invoke-static/range {v0 .. v13}, Lu53;->e(Lwg2;ZZLdy0;Lt66;FFFLha4;Lhh2;Lhh2;Lha4;Lki2;I)V

    .line 302
    .line 303
    .line 304
    move-object v13, v12

    .line 305
    invoke-virtual {v13, v15}, Lki2;->r(Z)V

    .line 306
    .line 307
    .line 308
    :goto_1
    invoke-virtual {v13, v15}, Lki2;->r(Z)V

    .line 309
    .line 310
    .line 311
    goto/16 :goto_a

    .line 312
    .line 313
    :pswitch_1
    move v2, v5

    .line 314
    move v5, v6

    .line 315
    move-object v0, v7

    .line 316
    move-object/from16 v18, v8

    .line 317
    .line 318
    move v6, v9

    .line 319
    move-object/from16 v3, v28

    .line 320
    .line 321
    const v4, 0x5e37ddec

    .line 322
    .line 323
    .line 324
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 325
    .line 326
    .line 327
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 328
    .line 329
    .line 330
    move-result v4

    .line 331
    if-eqz v4, :cond_12

    .line 332
    .line 333
    const/4 v7, 0x1

    .line 334
    if-ne v4, v7, :cond_11

    .line 335
    .line 336
    const v4, -0x263fb81d

    .line 337
    .line 338
    .line 339
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 340
    .line 341
    .line 342
    if-eqz v14, :cond_c

    .line 343
    .line 344
    move/from16 v29, v30

    .line 345
    .line 346
    :cond_c
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 347
    .line 348
    .line 349
    move-result v4

    .line 350
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 351
    .line 352
    .line 353
    move-result v7

    .line 354
    invoke-virtual {v13, v7}, Lki2;->e(I)Z

    .line 355
    .line 356
    .line 357
    move-result v7

    .line 358
    or-int/2addr v4, v7

    .line 359
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    move-result-object v7

    .line 363
    if-nez v4, :cond_d

    .line 364
    .line 365
    if-ne v7, v10, :cond_e

    .line 366
    .line 367
    :cond_d
    new-instance v7, Lnn;

    .line 368
    .line 369
    const/16 v4, 0xb

    .line 370
    .line 371
    invoke-direct {v7, v12, v1, v4}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 372
    .line 373
    .line 374
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 375
    .line 376
    .line 377
    :cond_e
    move-object v9, v7

    .line 378
    check-cast v9, Lhh2;

    .line 379
    .line 380
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 381
    .line 382
    .line 383
    move-result v4

    .line 384
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 385
    .line 386
    .line 387
    move-result v7

    .line 388
    invoke-virtual {v13, v7}, Lki2;->e(I)Z

    .line 389
    .line 390
    .line 391
    move-result v7

    .line 392
    or-int/2addr v4, v7

    .line 393
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    move-result-object v7

    .line 397
    if-nez v4, :cond_f

    .line 398
    .line 399
    if-ne v7, v10, :cond_10

    .line 400
    .line 401
    :cond_f
    new-instance v7, Lnn;

    .line 402
    .line 403
    const/16 v4, 0xc

    .line 404
    .line 405
    invoke-direct {v7, v11, v1, v4}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 406
    .line 407
    .line 408
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 409
    .line 410
    .line 411
    :cond_10
    move-object v10, v7

    .line 412
    check-cast v10, Lhh2;

    .line 413
    .line 414
    sget-object v11, Lit6;->c:Lk92;

    .line 415
    .line 416
    move-object/from16 v17, v13

    .line 417
    .line 418
    const/16 v13, 0x1b0

    .line 419
    .line 420
    const/4 v1, 0x0

    .line 421
    move v8, v2

    .line 422
    const/4 v2, 0x1

    .line 423
    move v4, v8

    .line 424
    move-object/from16 v12, v17

    .line 425
    .line 426
    move-object/from16 v7, v18

    .line 427
    .line 428
    move v8, v6

    .line 429
    move/from16 v6, v29

    .line 430
    .line 431
    invoke-static/range {v0 .. v13}, Lok;->l(Lwg2;ZZLdy0;FFFLha4;FLhh2;Lhh2;Lha4;Lki2;I)V

    .line 432
    .line 433
    .line 434
    move-object v13, v12

    .line 435
    invoke-virtual {v13, v15}, Lki2;->r(Z)V

    .line 436
    .line 437
    .line 438
    goto :goto_2

    .line 439
    :cond_11
    const v0, -0x2640432a

    .line 440
    .line 441
    .line 442
    invoke-static {v0, v13, v15}, Lx82;->f(ILki2;Z)Ll11;

    .line 443
    .line 444
    .line 445
    move-result-object v0

    .line 446
    throw v0

    .line 447
    :cond_12
    const v4, -0x26403d22

    .line 448
    .line 449
    .line 450
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 451
    .line 452
    .line 453
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 454
    .line 455
    .line 456
    move-result v4

    .line 457
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 458
    .line 459
    .line 460
    move-result v7

    .line 461
    invoke-virtual {v13, v7}, Lki2;->e(I)Z

    .line 462
    .line 463
    .line 464
    move-result v7

    .line 465
    or-int/2addr v4, v7

    .line 466
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 467
    .line 468
    .line 469
    move-result-object v7

    .line 470
    if-nez v4, :cond_13

    .line 471
    .line 472
    if-ne v7, v10, :cond_14

    .line 473
    .line 474
    :cond_13
    new-instance v7, Lnn;

    .line 475
    .line 476
    const/16 v4, 0x9

    .line 477
    .line 478
    invoke-direct {v7, v12, v1, v4}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 479
    .line 480
    .line 481
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 482
    .line 483
    .line 484
    :cond_14
    move-object v8, v7

    .line 485
    check-cast v8, Lhh2;

    .line 486
    .line 487
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 488
    .line 489
    .line 490
    move-result v4

    .line 491
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 492
    .line 493
    .line 494
    move-result v7

    .line 495
    invoke-virtual {v13, v7}, Lki2;->e(I)Z

    .line 496
    .line 497
    .line 498
    move-result v7

    .line 499
    or-int/2addr v4, v7

    .line 500
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 501
    .line 502
    .line 503
    move-result-object v7

    .line 504
    if-nez v4, :cond_15

    .line 505
    .line 506
    if-ne v7, v10, :cond_16

    .line 507
    .line 508
    :cond_15
    new-instance v7, Lnn;

    .line 509
    .line 510
    const/16 v4, 0xa

    .line 511
    .line 512
    invoke-direct {v7, v11, v1, v4}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 513
    .line 514
    .line 515
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 516
    .line 517
    .line 518
    :cond_16
    move-object v9, v7

    .line 519
    check-cast v9, Lhh2;

    .line 520
    .line 521
    sget-object v10, Lit6;->c:Lk92;

    .line 522
    .line 523
    const v12, 0x1801b0

    .line 524
    .line 525
    .line 526
    const/4 v1, 0x0

    .line 527
    move v4, v2

    .line 528
    const/4 v2, 0x1

    .line 529
    move v7, v6

    .line 530
    move-object v11, v13

    .line 531
    move-object/from16 v6, v18

    .line 532
    .line 533
    invoke-static/range {v0 .. v12}, Lnk;->d(Lwg2;ZZLdy0;FFLha4;FLhh2;Lhh2;Lha4;Lki2;I)V

    .line 534
    .line 535
    .line 536
    invoke-virtual {v13, v15}, Lki2;->r(Z)V

    .line 537
    .line 538
    .line 539
    :goto_2
    invoke-virtual {v13, v15}, Lki2;->r(Z)V

    .line 540
    .line 541
    .line 542
    goto/16 :goto_a

    .line 543
    .line 544
    :pswitch_2
    move v2, v5

    .line 545
    move v5, v6

    .line 546
    move-object v0, v7

    .line 547
    move-object/from16 v18, v8

    .line 548
    .line 549
    move v6, v9

    .line 550
    move-object/from16 v3, v28

    .line 551
    .line 552
    const v7, 0x5e8007be

    .line 553
    .line 554
    .line 555
    invoke-virtual {v13, v7}, Lki2;->h0(I)V

    .line 556
    .line 557
    .line 558
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 559
    .line 560
    .line 561
    move-result v7

    .line 562
    sget-object v8, Lk46;->i:Lk46;

    .line 563
    .line 564
    sget-object v9, Lk46;->j:Lk46;

    .line 565
    .line 566
    if-eqz v7, :cond_21

    .line 567
    .line 568
    const/4 v15, 0x1

    .line 569
    if-ne v7, v15, :cond_20

    .line 570
    .line 571
    const v7, -0x263d1d96

    .line 572
    .line 573
    .line 574
    invoke-virtual {v13, v7}, Lki2;->h0(I)V

    .line 575
    .line 576
    .line 577
    sget-object v7, Lsn;->a:[I

    .line 578
    .line 579
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 580
    .line 581
    .line 582
    move-result v16

    .line 583
    aget v7, v7, v16

    .line 584
    .line 585
    if-ne v7, v15, :cond_17

    .line 586
    .line 587
    move-object v8, v9

    .line 588
    :cond_17
    if-eqz v14, :cond_18

    .line 589
    .line 590
    move/from16 v29, v30

    .line 591
    .line 592
    :cond_18
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 593
    .line 594
    .line 595
    move-result v7

    .line 596
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 597
    .line 598
    .line 599
    move-result v9

    .line 600
    invoke-virtual {v13, v9}, Lki2;->e(I)Z

    .line 601
    .line 602
    .line 603
    move-result v9

    .line 604
    or-int/2addr v7, v9

    .line 605
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 606
    .line 607
    .line 608
    move-result-object v9

    .line 609
    if-nez v7, :cond_19

    .line 610
    .line 611
    if-ne v9, v10, :cond_1a

    .line 612
    .line 613
    :cond_19
    new-instance v9, Lnn;

    .line 614
    .line 615
    const/16 v7, 0x14

    .line 616
    .line 617
    invoke-direct {v9, v12, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 618
    .line 619
    .line 620
    invoke-virtual {v13, v9}, Lki2;->q0(Ljava/lang/Object;)V

    .line 621
    .line 622
    .line 623
    :cond_1a
    check-cast v9, Lhh2;

    .line 624
    .line 625
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 626
    .line 627
    .line 628
    move-result v7

    .line 629
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 630
    .line 631
    .line 632
    move-result v12

    .line 633
    invoke-virtual {v13, v12}, Lki2;->e(I)Z

    .line 634
    .line 635
    .line 636
    move-result v12

    .line 637
    or-int/2addr v7, v12

    .line 638
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 639
    .line 640
    .line 641
    move-result-object v12

    .line 642
    if-nez v7, :cond_1b

    .line 643
    .line 644
    if-ne v12, v10, :cond_1c

    .line 645
    .line 646
    :cond_1b
    new-instance v12, Lnn;

    .line 647
    .line 648
    const/16 v7, 0x15

    .line 649
    .line 650
    invoke-direct {v12, v11, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 651
    .line 652
    .line 653
    invoke-virtual {v13, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 654
    .line 655
    .line 656
    :cond_1c
    check-cast v12, Lhh2;

    .line 657
    .line 658
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 659
    .line 660
    .line 661
    move-result-object v1

    .line 662
    if-ne v1, v10, :cond_1d

    .line 663
    .line 664
    new-instance v1, Lon;

    .line 665
    .line 666
    const/16 v7, 0x9

    .line 667
    .line 668
    invoke-direct {v1, v7}, Lon;-><init>(B)V

    .line 669
    .line 670
    .line 671
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 672
    .line 673
    .line 674
    :cond_1d
    check-cast v1, Lwg2;

    .line 675
    .line 676
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 677
    .line 678
    .line 679
    move-result-object v7

    .line 680
    if-ne v7, v10, :cond_1e

    .line 681
    .line 682
    new-instance v7, Lon;

    .line 683
    .line 684
    const/16 v11, 0xa

    .line 685
    .line 686
    invoke-direct {v7, v11}, Lon;-><init>(B)V

    .line 687
    .line 688
    .line 689
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 690
    .line 691
    .line 692
    :cond_1e
    move-object v14, v7

    .line 693
    check-cast v14, Lwg2;

    .line 694
    .line 695
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 696
    .line 697
    .line 698
    move-result-object v7

    .line 699
    if-ne v7, v10, :cond_1f

    .line 700
    .line 701
    new-instance v7, Lon;

    .line 702
    .line 703
    const/16 v10, 0xb

    .line 704
    .line 705
    invoke-direct {v7, v10}, Lon;-><init>(B)V

    .line 706
    .line 707
    .line 708
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 709
    .line 710
    .line 711
    :cond_1f
    move-object v15, v7

    .line 712
    check-cast v15, Lwg2;

    .line 713
    .line 714
    sget-object v16, Lit6;->c:Lk92;

    .line 715
    .line 716
    move-object/from16 v7, v18

    .line 717
    .line 718
    const/16 v18, 0xdb0

    .line 719
    .line 720
    move-object/from16 v17, v13

    .line 721
    .line 722
    move-object v13, v1

    .line 723
    const/4 v1, 0x0

    .line 724
    move v10, v2

    .line 725
    const/4 v2, 0x1

    .line 726
    move v11, v10

    .line 727
    move v10, v6

    .line 728
    move v6, v11

    .line 729
    move-object v11, v9

    .line 730
    move-object v9, v7

    .line 731
    move v7, v5

    .line 732
    move-object v5, v8

    .line 733
    move/from16 v8, v29

    .line 734
    .line 735
    invoke-static/range {v0 .. v18}, Lw04;->m(Lwg2;ZZLdy0;Lt66;Lk46;FFFLha4;FLhh2;Lhh2;Lwg2;Lwg2;Lwg2;Lha4;Lki2;I)V

    .line 736
    .line 737
    .line 738
    move-object/from16 v13, v17

    .line 739
    .line 740
    const/4 v0, 0x0

    .line 741
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 742
    .line 743
    .line 744
    move v2, v0

    .line 745
    goto/16 :goto_3

    .line 746
    .line 747
    :cond_20
    const/4 v0, 0x0

    .line 748
    const v1, -0x263def3c

    .line 749
    .line 750
    .line 751
    invoke-static {v1, v13, v0}, Lx82;->f(ILki2;Z)Ll11;

    .line 752
    .line 753
    .line 754
    move-result-object v0

    .line 755
    throw v0

    .line 756
    :cond_21
    const v7, -0x263deb7b

    .line 757
    .line 758
    .line 759
    invoke-virtual {v13, v7}, Lki2;->h0(I)V

    .line 760
    .line 761
    .line 762
    sget-object v7, Lsn;->a:[I

    .line 763
    .line 764
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 765
    .line 766
    .line 767
    move-result v14

    .line 768
    aget v7, v7, v14

    .line 769
    .line 770
    const/4 v15, 0x1

    .line 771
    if-ne v7, v15, :cond_22

    .line 772
    .line 773
    move-object v8, v9

    .line 774
    :cond_22
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 775
    .line 776
    .line 777
    move-result v7

    .line 778
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 779
    .line 780
    .line 781
    move-result v9

    .line 782
    invoke-virtual {v13, v9}, Lki2;->e(I)Z

    .line 783
    .line 784
    .line 785
    move-result v9

    .line 786
    or-int/2addr v7, v9

    .line 787
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 788
    .line 789
    .line 790
    move-result-object v9

    .line 791
    if-nez v7, :cond_23

    .line 792
    .line 793
    if-ne v9, v10, :cond_24

    .line 794
    .line 795
    :cond_23
    new-instance v9, Lnn;

    .line 796
    .line 797
    const/16 v7, 0x11

    .line 798
    .line 799
    invoke-direct {v9, v12, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 800
    .line 801
    .line 802
    invoke-virtual {v13, v9}, Lki2;->q0(Ljava/lang/Object;)V

    .line 803
    .line 804
    .line 805
    :cond_24
    check-cast v9, Lhh2;

    .line 806
    .line 807
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 808
    .line 809
    .line 810
    move-result v7

    .line 811
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 812
    .line 813
    .line 814
    move-result v12

    .line 815
    invoke-virtual {v13, v12}, Lki2;->e(I)Z

    .line 816
    .line 817
    .line 818
    move-result v12

    .line 819
    or-int/2addr v7, v12

    .line 820
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 821
    .line 822
    .line 823
    move-result-object v12

    .line 824
    if-nez v7, :cond_25

    .line 825
    .line 826
    if-ne v12, v10, :cond_26

    .line 827
    .line 828
    :cond_25
    new-instance v12, Lnn;

    .line 829
    .line 830
    const/16 v7, 0x12

    .line 831
    .line 832
    invoke-direct {v12, v11, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 833
    .line 834
    .line 835
    invoke-virtual {v13, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 836
    .line 837
    .line 838
    :cond_26
    move-object v11, v12

    .line 839
    check-cast v11, Lhh2;

    .line 840
    .line 841
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 842
    .line 843
    .line 844
    move-result-object v1

    .line 845
    if-ne v1, v10, :cond_27

    .line 846
    .line 847
    new-instance v1, Lon;

    .line 848
    .line 849
    const/4 v7, 0x6

    .line 850
    invoke-direct {v1, v7}, Lon;-><init>(B)V

    .line 851
    .line 852
    .line 853
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 854
    .line 855
    .line 856
    :cond_27
    move-object v12, v1

    .line 857
    check-cast v12, Lwg2;

    .line 858
    .line 859
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 860
    .line 861
    .line 862
    move-result-object v1

    .line 863
    if-ne v1, v10, :cond_28

    .line 864
    .line 865
    new-instance v1, Lon;

    .line 866
    .line 867
    const/4 v7, 0x7

    .line 868
    invoke-direct {v1, v7}, Lon;-><init>(B)V

    .line 869
    .line 870
    .line 871
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 872
    .line 873
    .line 874
    :cond_28
    check-cast v1, Lwg2;

    .line 875
    .line 876
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 877
    .line 878
    .line 879
    move-result-object v7

    .line 880
    if-ne v7, v10, :cond_29

    .line 881
    .line 882
    new-instance v7, Lon;

    .line 883
    .line 884
    const/16 v10, 0x8

    .line 885
    .line 886
    invoke-direct {v7, v10}, Lon;-><init>(B)V

    .line 887
    .line 888
    .line 889
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 890
    .line 891
    .line 892
    :cond_29
    move-object v14, v7

    .line 893
    check-cast v14, Lwg2;

    .line 894
    .line 895
    sget-object v15, Lit6;->c:Lk92;

    .line 896
    .line 897
    const/16 v17, 0xdb0

    .line 898
    .line 899
    move-object/from16 v16, v13

    .line 900
    .line 901
    move-object v13, v1

    .line 902
    const/4 v1, 0x0

    .line 903
    move v10, v2

    .line 904
    const/4 v2, 0x1

    .line 905
    move-object v7, v8

    .line 906
    move v8, v5

    .line 907
    move-object v5, v7

    .line 908
    move v7, v10

    .line 909
    move-object v10, v9

    .line 910
    move-object/from16 v9, v18

    .line 911
    .line 912
    invoke-static/range {v0 .. v17}, Lkb3;->i(Lwg2;ZZLdy0;Lt66;Lk46;FFFLha4;Lhh2;Lhh2;Lwg2;Lwg2;Lwg2;Lha4;Lki2;I)V

    .line 913
    .line 914
    .line 915
    move-object/from16 v13, v16

    .line 916
    .line 917
    const/4 v2, 0x0

    .line 918
    invoke-virtual {v13, v2}, Lki2;->r(Z)V

    .line 919
    .line 920
    .line 921
    :goto_3
    invoke-virtual {v13, v2}, Lki2;->r(Z)V

    .line 922
    .line 923
    .line 924
    goto/16 :goto_a

    .line 925
    .line 926
    :pswitch_3
    move-object v2, v8

    .line 927
    move v8, v5

    .line 928
    move v5, v6

    .line 929
    move v6, v9

    .line 930
    move-object v9, v7

    .line 931
    move-object v7, v2

    .line 932
    move-object/from16 v4, v28

    .line 933
    .line 934
    const v15, 0x5dc8e706

    .line 935
    .line 936
    .line 937
    invoke-virtual {v13, v15}, Lki2;->h0(I)V

    .line 938
    .line 939
    .line 940
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 941
    .line 942
    .line 943
    move-result v15

    .line 944
    iget-object v0, v0, Lrn;->w:Lhh2;

    .line 945
    .line 946
    if-eqz v15, :cond_33

    .line 947
    .line 948
    const/4 v2, 0x1

    .line 949
    if-ne v15, v2, :cond_32

    .line 950
    .line 951
    const v2, -0x2643008a

    .line 952
    .line 953
    .line 954
    invoke-virtual {v13, v2}, Lki2;->h0(I)V

    .line 955
    .line 956
    .line 957
    if-eqz v14, :cond_2a

    .line 958
    .line 959
    move/from16 v29, v30

    .line 960
    .line 961
    :cond_2a
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 962
    .line 963
    .line 964
    move-result v2

    .line 965
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 966
    .line 967
    .line 968
    move-result v14

    .line 969
    invoke-virtual {v13, v14}, Lki2;->e(I)Z

    .line 970
    .line 971
    .line 972
    move-result v14

    .line 973
    or-int/2addr v2, v14

    .line 974
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 975
    .line 976
    .line 977
    move-result-object v14

    .line 978
    if-nez v2, :cond_2b

    .line 979
    .line 980
    if-ne v14, v10, :cond_2c

    .line 981
    .line 982
    :cond_2b
    new-instance v14, Lnn;

    .line 983
    .line 984
    invoke-direct {v14, v12, v1, v3}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 985
    .line 986
    .line 987
    invoke-virtual {v13, v14}, Lki2;->q0(Ljava/lang/Object;)V

    .line 988
    .line 989
    .line 990
    :cond_2c
    check-cast v14, Lhh2;

    .line 991
    .line 992
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 993
    .line 994
    .line 995
    move-result v2

    .line 996
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 997
    .line 998
    .line 999
    move-result v3

    .line 1000
    invoke-virtual {v13, v3}, Lki2;->e(I)Z

    .line 1001
    .line 1002
    .line 1003
    move-result v3

    .line 1004
    or-int/2addr v2, v3

    .line 1005
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1006
    .line 1007
    .line 1008
    move-result-object v3

    .line 1009
    if-nez v2, :cond_2d

    .line 1010
    .line 1011
    if-ne v3, v10, :cond_2e

    .line 1012
    .line 1013
    :cond_2d
    new-instance v3, Lnn;

    .line 1014
    .line 1015
    const/4 v2, 0x4

    .line 1016
    invoke-direct {v3, v11, v1, v2}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1017
    .line 1018
    .line 1019
    invoke-virtual {v13, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1020
    .line 1021
    .line 1022
    :cond_2e
    check-cast v3, Lhh2;

    .line 1023
    .line 1024
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1025
    .line 1026
    .line 1027
    move-result-object v1

    .line 1028
    if-ne v1, v10, :cond_2f

    .line 1029
    .line 1030
    new-instance v1, Lr;

    .line 1031
    .line 1032
    const/16 v2, 0x18

    .line 1033
    .line 1034
    invoke-direct {v1, v2}, Lr;-><init>(B)V

    .line 1035
    .line 1036
    .line 1037
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1038
    .line 1039
    .line 1040
    :cond_2f
    move-object v15, v1

    .line 1041
    check-cast v15, Lwg2;

    .line 1042
    .line 1043
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1044
    .line 1045
    .line 1046
    move-result-object v1

    .line 1047
    if-ne v1, v10, :cond_30

    .line 1048
    .line 1049
    new-instance v1, Lr;

    .line 1050
    .line 1051
    const/16 v2, 0x1a

    .line 1052
    .line 1053
    invoke-direct {v1, v2}, Lr;-><init>(B)V

    .line 1054
    .line 1055
    .line 1056
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1057
    .line 1058
    .line 1059
    :cond_30
    move-object/from16 v16, v1

    .line 1060
    .line 1061
    check-cast v16, Lwg2;

    .line 1062
    .line 1063
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1064
    .line 1065
    .line 1066
    move-result-object v1

    .line 1067
    if-ne v1, v10, :cond_31

    .line 1068
    .line 1069
    new-instance v1, Lr;

    .line 1070
    .line 1071
    const/16 v2, 0x1b

    .line 1072
    .line 1073
    invoke-direct {v1, v2}, Lr;-><init>(B)V

    .line 1074
    .line 1075
    .line 1076
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1077
    .line 1078
    .line 1079
    :cond_31
    move-object/from16 v17, v1

    .line 1080
    .line 1081
    check-cast v17, Lwg2;

    .line 1082
    .line 1083
    sget-object v18, Lit6;->c:Lk92;

    .line 1084
    .line 1085
    const v20, 0x36c36c30

    .line 1086
    .line 1087
    .line 1088
    const/4 v2, 0x0

    .line 1089
    move-object v12, v13

    .line 1090
    move-object v13, v14

    .line 1091
    move-object v14, v3

    .line 1092
    const/4 v3, 0x1

    .line 1093
    move v1, v5

    .line 1094
    const/4 v5, 0x0

    .line 1095
    move v10, v6

    .line 1096
    const/4 v6, 0x0

    .line 1097
    move-object v11, v7

    .line 1098
    const/4 v7, 0x0

    .line 1099
    move/from16 v19, v1

    .line 1100
    .line 1101
    move-object v1, v0

    .line 1102
    move-object v0, v9

    .line 1103
    move/from16 v9, v19

    .line 1104
    .line 1105
    move-object/from16 v19, v12

    .line 1106
    .line 1107
    move v12, v10

    .line 1108
    move/from16 v10, v29

    .line 1109
    .line 1110
    invoke-static/range {v0 .. v20}, Lkk;->o(Lwg2;Lhh2;ZZLdy0;ZZZFFFLha4;FLhh2;Lhh2;Lwg2;Lwg2;Lwg2;Lha4;Lki2;I)V

    .line 1111
    .line 1112
    .line 1113
    move-object/from16 v13, v19

    .line 1114
    .line 1115
    const/4 v0, 0x0

    .line 1116
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 1117
    .line 1118
    .line 1119
    move v2, v0

    .line 1120
    goto/16 :goto_4

    .line 1121
    .line 1122
    :cond_32
    const/4 v0, 0x0

    .line 1123
    const v1, -0x2643d784

    .line 1124
    .line 1125
    .line 1126
    invoke-static {v1, v13, v0}, Lx82;->f(ILki2;Z)Ll11;

    .line 1127
    .line 1128
    .line 1129
    move-result-object v0

    .line 1130
    throw v0

    .line 1131
    :cond_33
    move-object v3, v4

    .line 1132
    move-object/from16 v18, v7

    .line 1133
    .line 1134
    move-object v4, v0

    .line 1135
    move v2, v8

    .line 1136
    const v7, -0x2643d3ef

    .line 1137
    .line 1138
    .line 1139
    invoke-virtual {v13, v7}, Lki2;->h0(I)V

    .line 1140
    .line 1141
    .line 1142
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1143
    .line 1144
    .line 1145
    move-result v7

    .line 1146
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1147
    .line 1148
    .line 1149
    move-result v8

    .line 1150
    invoke-virtual {v13, v8}, Lki2;->e(I)Z

    .line 1151
    .line 1152
    .line 1153
    move-result v8

    .line 1154
    or-int/2addr v7, v8

    .line 1155
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1156
    .line 1157
    .line 1158
    move-result-object v8

    .line 1159
    if-nez v7, :cond_34

    .line 1160
    .line 1161
    if-ne v8, v10, :cond_35

    .line 1162
    .line 1163
    :cond_34
    new-instance v8, Lnn;

    .line 1164
    .line 1165
    const/4 v15, 0x1

    .line 1166
    invoke-direct {v8, v12, v1, v15}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1167
    .line 1168
    .line 1169
    invoke-virtual {v13, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1170
    .line 1171
    .line 1172
    :cond_35
    check-cast v8, Lhh2;

    .line 1173
    .line 1174
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1175
    .line 1176
    .line 1177
    move-result v7

    .line 1178
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1179
    .line 1180
    .line 1181
    move-result v12

    .line 1182
    invoke-virtual {v13, v12}, Lki2;->e(I)Z

    .line 1183
    .line 1184
    .line 1185
    move-result v12

    .line 1186
    or-int/2addr v7, v12

    .line 1187
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1188
    .line 1189
    .line 1190
    move-result-object v12

    .line 1191
    if-nez v7, :cond_36

    .line 1192
    .line 1193
    if-ne v12, v10, :cond_37

    .line 1194
    .line 1195
    :cond_36
    new-instance v12, Lnn;

    .line 1196
    .line 1197
    const/4 v7, 0x2

    .line 1198
    invoke-direct {v12, v11, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1199
    .line 1200
    .line 1201
    invoke-virtual {v13, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1202
    .line 1203
    .line 1204
    :cond_37
    check-cast v12, Lhh2;

    .line 1205
    .line 1206
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1207
    .line 1208
    .line 1209
    move-result-object v1

    .line 1210
    if-ne v1, v10, :cond_38

    .line 1211
    .line 1212
    new-instance v1, Lr;

    .line 1213
    .line 1214
    const/16 v7, 0x15

    .line 1215
    .line 1216
    invoke-direct {v1, v7}, Lr;-><init>(B)V

    .line 1217
    .line 1218
    .line 1219
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1220
    .line 1221
    .line 1222
    :cond_38
    move-object v14, v1

    .line 1223
    check-cast v14, Lwg2;

    .line 1224
    .line 1225
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v1

    .line 1229
    if-ne v1, v10, :cond_39

    .line 1230
    .line 1231
    new-instance v1, Lr;

    .line 1232
    .line 1233
    const/16 v7, 0x16

    .line 1234
    .line 1235
    invoke-direct {v1, v7}, Lr;-><init>(B)V

    .line 1236
    .line 1237
    .line 1238
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1239
    .line 1240
    .line 1241
    :cond_39
    move-object v15, v1

    .line 1242
    check-cast v15, Lwg2;

    .line 1243
    .line 1244
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1245
    .line 1246
    .line 1247
    move-result-object v1

    .line 1248
    if-ne v1, v10, :cond_3a

    .line 1249
    .line 1250
    new-instance v1, Lr;

    .line 1251
    .line 1252
    const/16 v7, 0x17

    .line 1253
    .line 1254
    invoke-direct {v1, v7}, Lr;-><init>(B)V

    .line 1255
    .line 1256
    .line 1257
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1258
    .line 1259
    .line 1260
    :cond_3a
    move-object/from16 v16, v1

    .line 1261
    .line 1262
    check-cast v16, Lwg2;

    .line 1263
    .line 1264
    sget-object v17, Lit6;->c:Lk92;

    .line 1265
    .line 1266
    const v19, 0x36c36c30

    .line 1267
    .line 1268
    .line 1269
    move v10, v2

    .line 1270
    const/4 v2, 0x0

    .line 1271
    move-object v1, v3

    .line 1272
    const/4 v3, 0x1

    .line 1273
    move v7, v5

    .line 1274
    const/4 v5, 0x0

    .line 1275
    move-object v11, v13

    .line 1276
    move v13, v6

    .line 1277
    const/4 v6, 0x0

    .line 1278
    move-object v0, v9

    .line 1279
    move-object v9, v12

    .line 1280
    move-object/from16 v12, v18

    .line 1281
    .line 1282
    move-object/from16 v18, v11

    .line 1283
    .line 1284
    move v11, v7

    .line 1285
    const/4 v7, 0x0

    .line 1286
    move-object/from16 v32, v4

    .line 1287
    .line 1288
    move-object v4, v1

    .line 1289
    move-object/from16 v1, v32

    .line 1290
    .line 1291
    invoke-static/range {v0 .. v19}, Ljj;->r(Lwg2;Lhh2;ZZLdy0;ZZZLhh2;Lhh2;FFLha4;FLwg2;Lwg2;Lwg2;Lha4;Lki2;I)V

    .line 1292
    .line 1293
    .line 1294
    move-object/from16 v13, v18

    .line 1295
    .line 1296
    const/4 v2, 0x0

    .line 1297
    invoke-virtual {v13, v2}, Lki2;->r(Z)V

    .line 1298
    .line 1299
    .line 1300
    :goto_4
    invoke-virtual {v13, v2}, Lki2;->r(Z)V

    .line 1301
    .line 1302
    .line 1303
    goto/16 :goto_a

    .line 1304
    .line 1305
    :pswitch_4
    move-object/from16 v18, v8

    .line 1306
    .line 1307
    move-object/from16 v4, v28

    .line 1308
    .line 1309
    move v8, v5

    .line 1310
    move v5, v6

    .line 1311
    move v6, v9

    .line 1312
    move-object v9, v7

    .line 1313
    const v7, 0x5dfed378

    .line 1314
    .line 1315
    .line 1316
    invoke-virtual {v13, v7}, Lki2;->h0(I)V

    .line 1317
    .line 1318
    .line 1319
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 1320
    .line 1321
    .line 1322
    move-result v7

    .line 1323
    move v15, v14

    .line 1324
    iget-object v14, v0, Lrn;->x:Lhh2;

    .line 1325
    .line 1326
    iget-object v2, v0, Lrn;->y:Lwg2;

    .line 1327
    .line 1328
    iget-boolean v0, v0, Lrn;->z:Z

    .line 1329
    .line 1330
    if-eqz v7, :cond_44

    .line 1331
    .line 1332
    const/4 v3, 0x1

    .line 1333
    if-ne v7, v3, :cond_43

    .line 1334
    .line 1335
    const v3, -0x264132e3

    .line 1336
    .line 1337
    .line 1338
    invoke-virtual {v13, v3}, Lki2;->h0(I)V

    .line 1339
    .line 1340
    .line 1341
    if-eqz v15, :cond_3b

    .line 1342
    .line 1343
    move/from16 v29, v30

    .line 1344
    .line 1345
    :cond_3b
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1346
    .line 1347
    .line 1348
    move-result v3

    .line 1349
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1350
    .line 1351
    .line 1352
    move-result v7

    .line 1353
    invoke-virtual {v13, v7}, Lki2;->e(I)Z

    .line 1354
    .line 1355
    .line 1356
    move-result v7

    .line 1357
    or-int/2addr v3, v7

    .line 1358
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1359
    .line 1360
    .line 1361
    move-result-object v7

    .line 1362
    if-nez v3, :cond_3c

    .line 1363
    .line 1364
    if-ne v7, v10, :cond_3d

    .line 1365
    .line 1366
    :cond_3c
    new-instance v7, Lnn;

    .line 1367
    .line 1368
    const/4 v3, 0x7

    .line 1369
    invoke-direct {v7, v12, v1, v3}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1370
    .line 1371
    .line 1372
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1373
    .line 1374
    .line 1375
    :cond_3d
    move-object v15, v7

    .line 1376
    check-cast v15, Lhh2;

    .line 1377
    .line 1378
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1379
    .line 1380
    .line 1381
    move-result v3

    .line 1382
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1383
    .line 1384
    .line 1385
    move-result v7

    .line 1386
    invoke-virtual {v13, v7}, Lki2;->e(I)Z

    .line 1387
    .line 1388
    .line 1389
    move-result v7

    .line 1390
    or-int/2addr v3, v7

    .line 1391
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1392
    .line 1393
    .line 1394
    move-result-object v7

    .line 1395
    if-nez v3, :cond_3e

    .line 1396
    .line 1397
    if-ne v7, v10, :cond_3f

    .line 1398
    .line 1399
    :cond_3e
    new-instance v7, Lnn;

    .line 1400
    .line 1401
    const/16 v3, 0x8

    .line 1402
    .line 1403
    invoke-direct {v7, v11, v1, v3}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1404
    .line 1405
    .line 1406
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1407
    .line 1408
    .line 1409
    :cond_3f
    check-cast v7, Lhh2;

    .line 1410
    .line 1411
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1412
    .line 1413
    .line 1414
    move-result-object v1

    .line 1415
    if-ne v1, v10, :cond_40

    .line 1416
    .line 1417
    new-instance v1, Lon;

    .line 1418
    .line 1419
    const/4 v3, 0x2

    .line 1420
    invoke-direct {v1, v3}, Lon;-><init>(B)V

    .line 1421
    .line 1422
    .line 1423
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1424
    .line 1425
    .line 1426
    :cond_40
    move-object v11, v1

    .line 1427
    check-cast v11, Lwg2;

    .line 1428
    .line 1429
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1430
    .line 1431
    .line 1432
    move-result-object v1

    .line 1433
    if-ne v1, v10, :cond_41

    .line 1434
    .line 1435
    new-instance v1, Lon;

    .line 1436
    .line 1437
    const/4 v3, 0x3

    .line 1438
    invoke-direct {v1, v3}, Lon;-><init>(B)V

    .line 1439
    .line 1440
    .line 1441
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1442
    .line 1443
    .line 1444
    :cond_41
    move-object v12, v1

    .line 1445
    check-cast v12, Lwg2;

    .line 1446
    .line 1447
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1448
    .line 1449
    .line 1450
    move-result-object v1

    .line 1451
    if-ne v1, v10, :cond_42

    .line 1452
    .line 1453
    new-instance v1, Lon;

    .line 1454
    .line 1455
    const/4 v3, 0x4

    .line 1456
    invoke-direct {v1, v3}, Lon;-><init>(B)V

    .line 1457
    .line 1458
    .line 1459
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1460
    .line 1461
    .line 1462
    :cond_42
    check-cast v1, Lwg2;

    .line 1463
    .line 1464
    sget-object v19, Lit6;->c:Lk92;

    .line 1465
    .line 1466
    move v3, v6

    .line 1467
    const/16 v6, 0x1b6

    .line 1468
    .line 1469
    move-object/from16 v16, v7

    .line 1470
    .line 1471
    const/4 v7, 0x0

    .line 1472
    move-object/from16 v28, v4

    .line 1473
    .line 1474
    const v4, 0x61b6030

    .line 1475
    .line 1476
    .line 1477
    move-object/from16 v17, v13

    .line 1478
    .line 1479
    move-object v13, v1

    .line 1480
    move v1, v5

    .line 1481
    const v5, 0x30000036

    .line 1482
    .line 1483
    .line 1484
    const/16 v20, 0x1

    .line 1485
    .line 1486
    const/16 v21, 0x1

    .line 1487
    .line 1488
    const/16 v22, 0x0

    .line 1489
    .line 1490
    const/16 v23, 0x1

    .line 1491
    .line 1492
    const/16 v24, 0x0

    .line 1493
    .line 1494
    const/16 v26, 0x0

    .line 1495
    .line 1496
    const/16 v27, 0x1

    .line 1497
    .line 1498
    move/from16 v25, v0

    .line 1499
    .line 1500
    move-object v10, v2

    .line 1501
    move v0, v8

    .line 1502
    move-object/from16 v8, v28

    .line 1503
    .line 1504
    move/from16 v2, v29

    .line 1505
    .line 1506
    invoke-static/range {v0 .. v27}, Llf;->s(FFFFIIIILdy0;Lwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lhh2;Lhh2;Lhh2;Lki2;Lha4;Lha4;ZZZZZZZZ)V

    .line 1507
    .line 1508
    .line 1509
    move-object/from16 v13, v17

    .line 1510
    .line 1511
    const/4 v0, 0x0

    .line 1512
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 1513
    .line 1514
    .line 1515
    goto/16 :goto_5

    .line 1516
    .line 1517
    :cond_43
    const/4 v0, 0x0

    .line 1518
    const v1, -0x26421a36

    .line 1519
    .line 1520
    .line 1521
    invoke-static {v1, v13, v0}, Lx82;->f(ILki2;Z)Ll11;

    .line 1522
    .line 1523
    .line 1524
    move-result-object v0

    .line 1525
    throw v0

    .line 1526
    :cond_44
    move/from16 v25, v0

    .line 1527
    .line 1528
    move-object v3, v4

    .line 1529
    const/4 v0, 0x0

    .line 1530
    move-object v4, v2

    .line 1531
    move v2, v8

    .line 1532
    const v7, -0x26421728

    .line 1533
    .line 1534
    .line 1535
    invoke-virtual {v13, v7}, Lki2;->h0(I)V

    .line 1536
    .line 1537
    .line 1538
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1539
    .line 1540
    .line 1541
    move-result v7

    .line 1542
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1543
    .line 1544
    .line 1545
    move-result v8

    .line 1546
    invoke-virtual {v13, v8}, Lki2;->e(I)Z

    .line 1547
    .line 1548
    .line 1549
    move-result v8

    .line 1550
    or-int/2addr v7, v8

    .line 1551
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1552
    .line 1553
    .line 1554
    move-result-object v8

    .line 1555
    if-nez v7, :cond_45

    .line 1556
    .line 1557
    if-ne v8, v10, :cond_46

    .line 1558
    .line 1559
    :cond_45
    new-instance v8, Lnn;

    .line 1560
    .line 1561
    const/4 v7, 0x5

    .line 1562
    invoke-direct {v8, v12, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1563
    .line 1564
    .line 1565
    invoke-virtual {v13, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1566
    .line 1567
    .line 1568
    :cond_46
    move-object v15, v8

    .line 1569
    check-cast v15, Lhh2;

    .line 1570
    .line 1571
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1572
    .line 1573
    .line 1574
    move-result v7

    .line 1575
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1576
    .line 1577
    .line 1578
    move-result v8

    .line 1579
    invoke-virtual {v13, v8}, Lki2;->e(I)Z

    .line 1580
    .line 1581
    .line 1582
    move-result v8

    .line 1583
    or-int/2addr v7, v8

    .line 1584
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1585
    .line 1586
    .line 1587
    move-result-object v8

    .line 1588
    if-nez v7, :cond_47

    .line 1589
    .line 1590
    if-ne v8, v10, :cond_48

    .line 1591
    .line 1592
    :cond_47
    new-instance v8, Lnn;

    .line 1593
    .line 1594
    const/4 v7, 0x6

    .line 1595
    invoke-direct {v8, v11, v1, v7}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1596
    .line 1597
    .line 1598
    invoke-virtual {v13, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1599
    .line 1600
    .line 1601
    :cond_48
    move-object/from16 v16, v8

    .line 1602
    .line 1603
    check-cast v16, Lhh2;

    .line 1604
    .line 1605
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1606
    .line 1607
    .line 1608
    move-result-object v1

    .line 1609
    if-ne v1, v10, :cond_49

    .line 1610
    .line 1611
    new-instance v1, Lr;

    .line 1612
    .line 1613
    const/16 v7, 0x1c

    .line 1614
    .line 1615
    invoke-direct {v1, v7}, Lr;-><init>(B)V

    .line 1616
    .line 1617
    .line 1618
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1619
    .line 1620
    .line 1621
    :cond_49
    move-object v11, v1

    .line 1622
    check-cast v11, Lwg2;

    .line 1623
    .line 1624
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1625
    .line 1626
    .line 1627
    move-result-object v1

    .line 1628
    if-ne v1, v10, :cond_4a

    .line 1629
    .line 1630
    new-instance v1, Lr;

    .line 1631
    .line 1632
    const/16 v7, 0x1d

    .line 1633
    .line 1634
    invoke-direct {v1, v7}, Lr;-><init>(B)V

    .line 1635
    .line 1636
    .line 1637
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1638
    .line 1639
    .line 1640
    :cond_4a
    move-object v12, v1

    .line 1641
    check-cast v12, Lwg2;

    .line 1642
    .line 1643
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1644
    .line 1645
    .line 1646
    move-result-object v1

    .line 1647
    if-ne v1, v10, :cond_4b

    .line 1648
    .line 1649
    new-instance v1, Lon;

    .line 1650
    .line 1651
    invoke-direct {v1, v0}, Lon;-><init>(B)V

    .line 1652
    .line 1653
    .line 1654
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1655
    .line 1656
    .line 1657
    :cond_4b
    check-cast v1, Lwg2;

    .line 1658
    .line 1659
    sget-object v19, Lit6;->c:Lk92;

    .line 1660
    .line 1661
    move v10, v6

    .line 1662
    const/16 v6, 0x1b6

    .line 1663
    .line 1664
    const/4 v7, 0x0

    .line 1665
    move v8, v2

    .line 1666
    const/high16 v2, 0x41800000    # 16.0f

    .line 1667
    .line 1668
    move-object/from16 v28, v3

    .line 1669
    .line 1670
    move v3, v10

    .line 1671
    move-object v10, v4

    .line 1672
    const v4, 0x61b6030

    .line 1673
    .line 1674
    .line 1675
    move-object/from16 v17, v13

    .line 1676
    .line 1677
    move-object v13, v1

    .line 1678
    move v1, v5

    .line 1679
    const v5, 0x30180036

    .line 1680
    .line 1681
    .line 1682
    const/16 v20, 0x1

    .line 1683
    .line 1684
    const/16 v21, 0x1

    .line 1685
    .line 1686
    const/16 v22, 0x0

    .line 1687
    .line 1688
    const/16 v23, 0x1

    .line 1689
    .line 1690
    const/16 v24, 0x0

    .line 1691
    .line 1692
    const/16 v26, 0x0

    .line 1693
    .line 1694
    const/16 v27, 0x1

    .line 1695
    .line 1696
    move v0, v8

    .line 1697
    move-object/from16 v8, v28

    .line 1698
    .line 1699
    invoke-static/range {v0 .. v27}, Lel;->t(FFFFIIIILdy0;Lwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lhh2;Lhh2;Lhh2;Lki2;Lha4;Lha4;ZZZZZZZZ)V

    .line 1700
    .line 1701
    .line 1702
    move-object/from16 v13, v17

    .line 1703
    .line 1704
    const/4 v0, 0x0

    .line 1705
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 1706
    .line 1707
    .line 1708
    :goto_5
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 1709
    .line 1710
    .line 1711
    goto/16 :goto_a

    .line 1712
    .line 1713
    :pswitch_5
    move v2, v5

    .line 1714
    move v5, v6

    .line 1715
    move v6, v9

    .line 1716
    move v0, v15

    .line 1717
    move-object/from16 v3, v28

    .line 1718
    .line 1719
    move-object v9, v7

    .line 1720
    move-object v7, v8

    .line 1721
    move v15, v14

    .line 1722
    const v4, 0x5d9d1f50

    .line 1723
    .line 1724
    .line 1725
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 1726
    .line 1727
    .line 1728
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 1729
    .line 1730
    .line 1731
    move-result v4

    .line 1732
    if-eqz v4, :cond_55

    .line 1733
    .line 1734
    const/4 v14, 0x1

    .line 1735
    if-ne v4, v14, :cond_54

    .line 1736
    .line 1737
    const v4, 0x5db22781

    .line 1738
    .line 1739
    .line 1740
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 1741
    .line 1742
    .line 1743
    if-eqz v15, :cond_4c

    .line 1744
    .line 1745
    move/from16 v29, v30

    .line 1746
    .line 1747
    :cond_4c
    sget-object v15, Lit6;->c:Lk92;

    .line 1748
    .line 1749
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1750
    .line 1751
    .line 1752
    move-result-object v4

    .line 1753
    if-ne v4, v10, :cond_4d

    .line 1754
    .line 1755
    new-instance v4, Lon;

    .line 1756
    .line 1757
    const/16 v14, 0xc

    .line 1758
    .line 1759
    invoke-direct {v4, v14}, Lon;-><init>(B)V

    .line 1760
    .line 1761
    .line 1762
    invoke-virtual {v13, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1763
    .line 1764
    .line 1765
    :cond_4d
    check-cast v4, Lwg2;

    .line 1766
    .line 1767
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1768
    .line 1769
    .line 1770
    move-result-object v14

    .line 1771
    if-ne v14, v10, :cond_4e

    .line 1772
    .line 1773
    new-instance v14, Lon;

    .line 1774
    .line 1775
    const/16 v0, 0xd

    .line 1776
    .line 1777
    invoke-direct {v14, v0}, Lon;-><init>(B)V

    .line 1778
    .line 1779
    .line 1780
    invoke-virtual {v13, v14}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1781
    .line 1782
    .line 1783
    :cond_4e
    check-cast v14, Lwg2;

    .line 1784
    .line 1785
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1786
    .line 1787
    .line 1788
    move-result-object v0

    .line 1789
    if-ne v0, v10, :cond_4f

    .line 1790
    .line 1791
    new-instance v0, Lon;

    .line 1792
    .line 1793
    const/16 v8, 0xe

    .line 1794
    .line 1795
    invoke-direct {v0, v8}, Lon;-><init>(B)V

    .line 1796
    .line 1797
    .line 1798
    invoke-virtual {v13, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1799
    .line 1800
    .line 1801
    :cond_4f
    check-cast v0, Lwg2;

    .line 1802
    .line 1803
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1804
    .line 1805
    .line 1806
    move-result v8

    .line 1807
    move-object/from16 p1, v0

    .line 1808
    .line 1809
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1810
    .line 1811
    .line 1812
    move-result v0

    .line 1813
    invoke-virtual {v13, v0}, Lki2;->e(I)Z

    .line 1814
    .line 1815
    .line 1816
    move-result v0

    .line 1817
    or-int/2addr v8, v0

    .line 1818
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1819
    .line 1820
    .line 1821
    move-result-object v0

    .line 1822
    if-nez v8, :cond_50

    .line 1823
    .line 1824
    if-ne v0, v10, :cond_51

    .line 1825
    .line 1826
    :cond_50
    new-instance v0, Lnn;

    .line 1827
    .line 1828
    const/16 v8, 0x19

    .line 1829
    .line 1830
    invoke-direct {v0, v12, v1, v8}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1831
    .line 1832
    .line 1833
    invoke-virtual {v13, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1834
    .line 1835
    .line 1836
    :cond_51
    check-cast v0, Lhh2;

    .line 1837
    .line 1838
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1839
    .line 1840
    .line 1841
    move-result v8

    .line 1842
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1843
    .line 1844
    .line 1845
    move-result v12

    .line 1846
    invoke-virtual {v13, v12}, Lki2;->e(I)Z

    .line 1847
    .line 1848
    .line 1849
    move-result v12

    .line 1850
    or-int/2addr v8, v12

    .line 1851
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1852
    .line 1853
    .line 1854
    move-result-object v12

    .line 1855
    if-nez v8, :cond_52

    .line 1856
    .line 1857
    if-ne v12, v10, :cond_53

    .line 1858
    .line 1859
    :cond_52
    new-instance v12, Lnn;

    .line 1860
    .line 1861
    const/4 v8, 0x0

    .line 1862
    invoke-direct {v12, v11, v1, v8}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 1863
    .line 1864
    .line 1865
    invoke-virtual {v13, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1866
    .line 1867
    .line 1868
    :cond_53
    move-object v10, v12

    .line 1869
    check-cast v10, Lhh2;

    .line 1870
    .line 1871
    const v17, 0xdb6db0

    .line 1872
    .line 1873
    .line 1874
    move-object v1, v4

    .line 1875
    const/4 v4, 0x0

    .line 1876
    move v11, v5

    .line 1877
    const/4 v5, 0x1

    .line 1878
    move v12, v6

    .line 1879
    const/4 v6, 0x0

    .line 1880
    move-object v8, v9

    .line 1881
    move-object v9, v0

    .line 1882
    move-object v0, v8

    .line 1883
    move v8, v11

    .line 1884
    move v11, v2

    .line 1885
    move-object v2, v14

    .line 1886
    move v14, v12

    .line 1887
    move v12, v8

    .line 1888
    move-object/from16 v16, v13

    .line 1889
    .line 1890
    move/from16 v8, v29

    .line 1891
    .line 1892
    move-object v13, v7

    .line 1893
    move-object v7, v3

    .line 1894
    move-object/from16 v3, p1

    .line 1895
    .line 1896
    invoke-static/range {v0 .. v17}, Ll80;->w(Lwg2;Lwg2;Lwg2;Lwg2;ZZZLdy0;FLhh2;Lhh2;FFLha4;FLha4;Lki2;I)V

    .line 1897
    .line 1898
    .line 1899
    move-object/from16 v13, v16

    .line 1900
    .line 1901
    const/4 v0, 0x0

    .line 1902
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 1903
    .line 1904
    .line 1905
    move v2, v0

    .line 1906
    goto/16 :goto_7

    .line 1907
    .line 1908
    :cond_54
    const v1, -0x2645410e

    .line 1909
    .line 1910
    .line 1911
    invoke-static {v1, v13, v0}, Lx82;->f(ILki2;Z)Ll11;

    .line 1912
    .line 1913
    .line 1914
    move-result-object v0

    .line 1915
    throw v0

    .line 1916
    :cond_55
    const v4, 0x5d9db7a6

    .line 1917
    .line 1918
    .line 1919
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 1920
    .line 1921
    .line 1922
    sget-object v14, Lit6;->c:Lk92;

    .line 1923
    .line 1924
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1925
    .line 1926
    .line 1927
    move-result-object v4

    .line 1928
    if-ne v4, v10, :cond_56

    .line 1929
    .line 1930
    new-instance v4, Lr;

    .line 1931
    .line 1932
    const/16 v8, 0x19

    .line 1933
    .line 1934
    invoke-direct {v4, v8}, Lr;-><init>(B)V

    .line 1935
    .line 1936
    .line 1937
    invoke-virtual {v13, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1938
    .line 1939
    .line 1940
    :cond_56
    check-cast v4, Lwg2;

    .line 1941
    .line 1942
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1943
    .line 1944
    .line 1945
    move-result-object v8

    .line 1946
    if-ne v8, v10, :cond_57

    .line 1947
    .line 1948
    new-instance v8, Lon;

    .line 1949
    .line 1950
    const/4 v15, 0x1

    .line 1951
    invoke-direct {v8, v15}, Lon;-><init>(B)V

    .line 1952
    .line 1953
    .line 1954
    invoke-virtual {v13, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1955
    .line 1956
    .line 1957
    :cond_57
    check-cast v8, Lwg2;

    .line 1958
    .line 1959
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1960
    .line 1961
    .line 1962
    move-result-object v15

    .line 1963
    if-ne v15, v10, :cond_58

    .line 1964
    .line 1965
    new-instance v15, Lon;

    .line 1966
    .line 1967
    const/4 v0, 0x5

    .line 1968
    invoke-direct {v15, v0}, Lon;-><init>(B)V

    .line 1969
    .line 1970
    .line 1971
    invoke-virtual {v13, v15}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1972
    .line 1973
    .line 1974
    :cond_58
    check-cast v15, Lwg2;

    .line 1975
    .line 1976
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 1977
    .line 1978
    .line 1979
    move-result v0

    .line 1980
    move/from16 p0, v0

    .line 1981
    .line 1982
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 1983
    .line 1984
    .line 1985
    move-result v0

    .line 1986
    invoke-virtual {v13, v0}, Lki2;->e(I)Z

    .line 1987
    .line 1988
    .line 1989
    move-result v0

    .line 1990
    or-int v0, p0, v0

    .line 1991
    .line 1992
    move/from16 p0, v0

    .line 1993
    .line 1994
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1995
    .line 1996
    .line 1997
    move-result-object v0

    .line 1998
    if-nez p0, :cond_59

    .line 1999
    .line 2000
    if-eq v0, v10, :cond_59

    .line 2001
    .line 2002
    move/from16 p0, v2

    .line 2003
    .line 2004
    goto :goto_6

    .line 2005
    :cond_59
    new-instance v0, Lnn;

    .line 2006
    .line 2007
    move/from16 p0, v2

    .line 2008
    .line 2009
    const/16 v2, 0x16

    .line 2010
    .line 2011
    invoke-direct {v0, v12, v1, v2}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 2012
    .line 2013
    .line 2014
    invoke-virtual {v13, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2015
    .line 2016
    .line 2017
    :goto_6
    check-cast v0, Lhh2;

    .line 2018
    .line 2019
    invoke-virtual {v13, v11}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2020
    .line 2021
    .line 2022
    move-result v2

    .line 2023
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 2024
    .line 2025
    .line 2026
    move-result v12

    .line 2027
    invoke-virtual {v13, v12}, Lki2;->e(I)Z

    .line 2028
    .line 2029
    .line 2030
    move-result v12

    .line 2031
    or-int/2addr v2, v12

    .line 2032
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2033
    .line 2034
    .line 2035
    move-result-object v12

    .line 2036
    if-nez v2, :cond_5a

    .line 2037
    .line 2038
    if-ne v12, v10, :cond_5b

    .line 2039
    .line 2040
    :cond_5a
    new-instance v12, Lnn;

    .line 2041
    .line 2042
    const/16 v2, 0x18

    .line 2043
    .line 2044
    invoke-direct {v12, v11, v1, v2}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 2045
    .line 2046
    .line 2047
    invoke-virtual {v13, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2048
    .line 2049
    .line 2050
    :cond_5b
    check-cast v12, Lhh2;

    .line 2051
    .line 2052
    const v16, 0x30db6db0

    .line 2053
    .line 2054
    .line 2055
    move-object v1, v4

    .line 2056
    const/4 v4, 0x0

    .line 2057
    move v11, v5

    .line 2058
    const/4 v5, 0x1

    .line 2059
    move v10, v6

    .line 2060
    const/4 v6, 0x0

    .line 2061
    move v2, v11

    .line 2062
    move-object v11, v0

    .line 2063
    move-object v0, v9

    .line 2064
    move v9, v2

    .line 2065
    move-object v2, v7

    .line 2066
    move-object v7, v3

    .line 2067
    move-object v3, v15

    .line 2068
    move-object v15, v13

    .line 2069
    move v13, v10

    .line 2070
    move-object v10, v2

    .line 2071
    move-object v2, v8

    .line 2072
    move/from16 v8, p0

    .line 2073
    .line 2074
    invoke-static/range {v0 .. v16}, Lf48;->p(Lwg2;Lwg2;Lwg2;Lwg2;ZZZLdy0;FFLha4;Lhh2;Lhh2;FLha4;Lki2;I)V

    .line 2075
    .line 2076
    .line 2077
    move-object v13, v15

    .line 2078
    const/4 v2, 0x0

    .line 2079
    invoke-virtual {v13, v2}, Lki2;->r(Z)V

    .line 2080
    .line 2081
    .line 2082
    :goto_7
    invoke-virtual {v13, v2}, Lki2;->r(Z)V

    .line 2083
    .line 2084
    .line 2085
    goto/16 :goto_a

    .line 2086
    .line 2087
    :pswitch_6
    move-object/from16 v18, v8

    .line 2088
    .line 2089
    move-object/from16 v3, v28

    .line 2090
    .line 2091
    move v8, v5

    .line 2092
    move v5, v6

    .line 2093
    move v6, v9

    .line 2094
    move v15, v14

    .line 2095
    move-object v9, v7

    .line 2096
    const v4, 0x5d72040a

    .line 2097
    .line 2098
    .line 2099
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 2100
    .line 2101
    .line 2102
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Enum;->ordinal()I

    .line 2103
    .line 2104
    .line 2105
    move-result v4

    .line 2106
    iget-object v7, v0, Lrn;->p:Lwg2;

    .line 2107
    .line 2108
    move-object v11, v9

    .line 2109
    iget-object v14, v0, Lrn;->q:Lwg2;

    .line 2110
    .line 2111
    iget-object v2, v0, Lrn;->r:Lwg2;

    .line 2112
    .line 2113
    iget-object v0, v0, Lrn;->s:Lwg2;

    .line 2114
    .line 2115
    if-eqz v4, :cond_68

    .line 2116
    .line 2117
    const/4 v9, 0x1

    .line 2118
    if-ne v4, v9, :cond_67

    .line 2119
    .line 2120
    const v4, 0x5d86db6e

    .line 2121
    .line 2122
    .line 2123
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 2124
    .line 2125
    .line 2126
    if-eqz v15, :cond_5c

    .line 2127
    .line 2128
    move/from16 v4, v30

    .line 2129
    .line 2130
    goto :goto_8

    .line 2131
    :cond_5c
    move/from16 v4, v29

    .line 2132
    .line 2133
    :goto_8
    sget-object v9, Lit6;->c:Lk92;

    .line 2134
    .line 2135
    invoke-virtual {v13, v7}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2136
    .line 2137
    .line 2138
    move-result v15

    .line 2139
    move-object/from16 v28, v3

    .line 2140
    .line 2141
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2142
    .line 2143
    .line 2144
    move-result-object v3

    .line 2145
    if-nez v15, :cond_5d

    .line 2146
    .line 2147
    if-ne v3, v10, :cond_5e

    .line 2148
    .line 2149
    :cond_5d
    new-instance v3, Lmn;

    .line 2150
    .line 2151
    const/4 v15, 0x4

    .line 2152
    invoke-direct {v3, v7, v15}, Lmn;-><init>(Lwg2;B)V

    .line 2153
    .line 2154
    .line 2155
    invoke-virtual {v13, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2156
    .line 2157
    .line 2158
    :cond_5e
    check-cast v3, Lwg2;

    .line 2159
    .line 2160
    invoke-virtual {v13, v14}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2161
    .line 2162
    .line 2163
    move-result v7

    .line 2164
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2165
    .line 2166
    .line 2167
    move-result-object v15

    .line 2168
    if-nez v7, :cond_5f

    .line 2169
    .line 2170
    if-ne v15, v10, :cond_60

    .line 2171
    .line 2172
    :cond_5f
    new-instance v15, Lmn;

    .line 2173
    .line 2174
    const/4 v7, 0x5

    .line 2175
    invoke-direct {v15, v14, v7}, Lmn;-><init>(Lwg2;B)V

    .line 2176
    .line 2177
    .line 2178
    invoke-virtual {v13, v15}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2179
    .line 2180
    .line 2181
    :cond_60
    check-cast v15, Lwg2;

    .line 2182
    .line 2183
    invoke-virtual {v13, v2}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2184
    .line 2185
    .line 2186
    move-result v7

    .line 2187
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2188
    .line 2189
    .line 2190
    move-result-object v14

    .line 2191
    if-nez v7, :cond_61

    .line 2192
    .line 2193
    if-ne v14, v10, :cond_62

    .line 2194
    .line 2195
    :cond_61
    new-instance v14, Lmn;

    .line 2196
    .line 2197
    const/4 v7, 0x6

    .line 2198
    invoke-direct {v14, v2, v7}, Lmn;-><init>(Lwg2;B)V

    .line 2199
    .line 2200
    .line 2201
    invoke-virtual {v13, v14}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2202
    .line 2203
    .line 2204
    :cond_62
    check-cast v14, Lwg2;

    .line 2205
    .line 2206
    invoke-virtual {v13, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2207
    .line 2208
    .line 2209
    move-result v2

    .line 2210
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2211
    .line 2212
    .line 2213
    move-result-object v7

    .line 2214
    if-nez v2, :cond_63

    .line 2215
    .line 2216
    if-ne v7, v10, :cond_64

    .line 2217
    .line 2218
    :cond_63
    new-instance v7, Lmn;

    .line 2219
    .line 2220
    const/4 v2, 0x7

    .line 2221
    invoke-direct {v7, v0, v2}, Lmn;-><init>(Lwg2;B)V

    .line 2222
    .line 2223
    .line 2224
    invoke-virtual {v13, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2225
    .line 2226
    .line 2227
    :cond_64
    check-cast v7, Lwg2;

    .line 2228
    .line 2229
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2230
    .line 2231
    .line 2232
    move-result v0

    .line 2233
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 2234
    .line 2235
    .line 2236
    move-result v2

    .line 2237
    invoke-virtual {v13, v2}, Lki2;->e(I)Z

    .line 2238
    .line 2239
    .line 2240
    move-result v2

    .line 2241
    or-int/2addr v0, v2

    .line 2242
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2243
    .line 2244
    .line 2245
    move-result-object v2

    .line 2246
    if-nez v0, :cond_65

    .line 2247
    .line 2248
    if-ne v2, v10, :cond_66

    .line 2249
    .line 2250
    :cond_65
    new-instance v2, Lnn;

    .line 2251
    .line 2252
    const/16 v0, 0x17

    .line 2253
    .line 2254
    invoke-direct {v2, v12, v1, v0}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 2255
    .line 2256
    .line 2257
    invoke-virtual {v13, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2258
    .line 2259
    .line 2260
    :cond_66
    check-cast v2, Lhh2;

    .line 2261
    .line 2262
    move-object v10, v15

    .line 2263
    const v15, 0x300001b0

    .line 2264
    .line 2265
    .line 2266
    move-object v12, v7

    .line 2267
    move-object v7, v9

    .line 2268
    move-object v0, v11

    .line 2269
    move-object v11, v14

    .line 2270
    move-object/from16 v1, v28

    .line 2271
    .line 2272
    const/4 v9, 0x1

    .line 2273
    move-object v14, v13

    .line 2274
    move-object v13, v2

    .line 2275
    move v2, v8

    .line 2276
    move-object v8, v3

    .line 2277
    move v3, v5

    .line 2278
    move-object/from16 v5, v18

    .line 2279
    .line 2280
    invoke-static/range {v0 .. v15}, Lo63;->n(Lwg2;Ldy0;FFFLha4;FLha4;Lwg2;ZLwg2;Lwg2;Lwg2;Lhh2;Lki2;I)V

    .line 2281
    .line 2282
    .line 2283
    move-object v13, v14

    .line 2284
    const/4 v15, 0x0

    .line 2285
    invoke-virtual {v13, v15}, Lki2;->r(Z)V

    .line 2286
    .line 2287
    .line 2288
    move v0, v15

    .line 2289
    goto/16 :goto_9

    .line 2290
    .line 2291
    :cond_67
    const/4 v15, 0x0

    .line 2292
    const v0, -0x2646a508

    .line 2293
    .line 2294
    .line 2295
    invoke-static {v0, v13, v15}, Lx82;->f(ILki2;Z)Ll11;

    .line 2296
    .line 2297
    .line 2298
    move-result-object v0

    .line 2299
    throw v0

    .line 2300
    :cond_68
    move-object v9, v11

    .line 2301
    const/16 v20, 0x1

    .line 2302
    .line 2303
    const v4, 0x5d729df3

    .line 2304
    .line 2305
    .line 2306
    invoke-virtual {v13, v4}, Lki2;->h0(I)V

    .line 2307
    .line 2308
    .line 2309
    move v11, v5

    .line 2310
    move v5, v6

    .line 2311
    sget-object v6, Lit6;->c:Lk92;

    .line 2312
    .line 2313
    invoke-virtual {v13, v7}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2314
    .line 2315
    .line 2316
    move-result v4

    .line 2317
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2318
    .line 2319
    .line 2320
    move-result-object v15

    .line 2321
    if-nez v4, :cond_69

    .line 2322
    .line 2323
    if-ne v15, v10, :cond_6a

    .line 2324
    .line 2325
    :cond_69
    new-instance v15, Lmn;

    .line 2326
    .line 2327
    const/4 v4, 0x0

    .line 2328
    invoke-direct {v15, v7, v4}, Lmn;-><init>(Lwg2;B)V

    .line 2329
    .line 2330
    .line 2331
    invoke-virtual {v13, v15}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2332
    .line 2333
    .line 2334
    :cond_6a
    move-object v7, v15

    .line 2335
    check-cast v7, Lwg2;

    .line 2336
    .line 2337
    invoke-virtual {v13, v14}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2338
    .line 2339
    .line 2340
    move-result v4

    .line 2341
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2342
    .line 2343
    .line 2344
    move-result-object v15

    .line 2345
    if-nez v4, :cond_6b

    .line 2346
    .line 2347
    if-ne v15, v10, :cond_6c

    .line 2348
    .line 2349
    :cond_6b
    new-instance v15, Lmn;

    .line 2350
    .line 2351
    const/4 v4, 0x1

    .line 2352
    invoke-direct {v15, v14, v4}, Lmn;-><init>(Lwg2;B)V

    .line 2353
    .line 2354
    .line 2355
    invoke-virtual {v13, v15}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2356
    .line 2357
    .line 2358
    :cond_6c
    check-cast v15, Lwg2;

    .line 2359
    .line 2360
    invoke-virtual {v13, v2}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2361
    .line 2362
    .line 2363
    move-result v4

    .line 2364
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2365
    .line 2366
    .line 2367
    move-result-object v14

    .line 2368
    if-nez v4, :cond_6d

    .line 2369
    .line 2370
    if-ne v14, v10, :cond_6e

    .line 2371
    .line 2372
    :cond_6d
    new-instance v14, Lmn;

    .line 2373
    .line 2374
    const/4 v4, 0x2

    .line 2375
    invoke-direct {v14, v2, v4}, Lmn;-><init>(Lwg2;B)V

    .line 2376
    .line 2377
    .line 2378
    invoke-virtual {v13, v14}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2379
    .line 2380
    .line 2381
    :cond_6e
    check-cast v14, Lwg2;

    .line 2382
    .line 2383
    invoke-virtual {v13, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2384
    .line 2385
    .line 2386
    move-result v2

    .line 2387
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2388
    .line 2389
    .line 2390
    move-result-object v4

    .line 2391
    if-nez v2, :cond_6f

    .line 2392
    .line 2393
    if-ne v4, v10, :cond_70

    .line 2394
    .line 2395
    :cond_6f
    new-instance v4, Lmn;

    .line 2396
    .line 2397
    const/4 v2, 0x3

    .line 2398
    invoke-direct {v4, v0, v2}, Lmn;-><init>(Lwg2;B)V

    .line 2399
    .line 2400
    .line 2401
    invoke-virtual {v13, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2402
    .line 2403
    .line 2404
    :cond_70
    check-cast v4, Lwg2;

    .line 2405
    .line 2406
    invoke-virtual {v13, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2407
    .line 2408
    .line 2409
    move-result v0

    .line 2410
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 2411
    .line 2412
    .line 2413
    move-result v2

    .line 2414
    invoke-virtual {v13, v2}, Lki2;->e(I)Z

    .line 2415
    .line 2416
    .line 2417
    move-result v2

    .line 2418
    or-int/2addr v0, v2

    .line 2419
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 2420
    .line 2421
    .line 2422
    move-result-object v2

    .line 2423
    if-nez v0, :cond_71

    .line 2424
    .line 2425
    if-ne v2, v10, :cond_72

    .line 2426
    .line 2427
    :cond_71
    new-instance v2, Lnn;

    .line 2428
    .line 2429
    const/16 v0, 0x13

    .line 2430
    .line 2431
    invoke-direct {v2, v12, v1, v0}, Lnn;-><init>(Llh2;Lrk;B)V

    .line 2432
    .line 2433
    .line 2434
    invoke-virtual {v13, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2435
    .line 2436
    .line 2437
    :cond_72
    move-object v12, v2

    .line 2438
    check-cast v12, Lhh2;

    .line 2439
    .line 2440
    move-object v10, v14

    .line 2441
    const v14, 0x301801b0

    .line 2442
    .line 2443
    .line 2444
    move-object v1, v3

    .line 2445
    move v2, v8

    .line 2446
    move-object v0, v9

    .line 2447
    move v3, v11

    .line 2448
    move-object v9, v15

    .line 2449
    move/from16 v8, v20

    .line 2450
    .line 2451
    move-object v11, v4

    .line 2452
    move-object/from16 v4, v18

    .line 2453
    .line 2454
    invoke-static/range {v0 .. v14}, Ll63;->o(Lwg2;Ldy0;FFLha4;FLha4;Lwg2;ZLwg2;Lwg2;Lwg2;Lhh2;Lki2;I)V

    .line 2455
    .line 2456
    .line 2457
    const/4 v0, 0x0

    .line 2458
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 2459
    .line 2460
    .line 2461
    :goto_9
    invoke-virtual {v13, v0}, Lki2;->r(Z)V

    .line 2462
    .line 2463
    .line 2464
    goto :goto_a

    .line 2465
    :cond_73
    invoke-virtual {v13}, Lki2;->b0()V

    .line 2466
    .line 2467
    .line 2468
    :goto_a
    sget-object v0, Los7;->a:Los7;

    .line 2469
    .line 2470
    return-object v0

    .line 2471
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
