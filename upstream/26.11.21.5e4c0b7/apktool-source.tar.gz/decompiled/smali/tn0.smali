.class public interface abstract Ltn0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# virtual methods
.method public abstract a(Lfo0;Lun0;Llc4;Ljava/lang/Object;)V
.end method

.method public abstract b(Lfo0;Lun0;FLjava/lang/Object;)V
.end method
