.class public final Lav0;
.super Lf57;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic l:B

.field public m:Z

.field public final synthetic n:Lbv0;


# direct methods
.method public synthetic constructor <init>(Lbv0;Lfd1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lav0;->l:B

    .line 2
    .line 3
    iput-object p1, p0, Lav0;->n:Lbv0;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1, p2}, Lf57;-><init>(ILfd1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lav0;->l:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    iget-object p0, p0, Lav0;->n:Lbv0;

    .line 6
    .line 7
    check-cast p1, Lfd1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    new-instance v0, Lav0;

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    invoke-direct {v0, p0, p1, v2}, Lav0;-><init>(Lbv0;Lfd1;B)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lav0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    new-instance v0, Lav0;

    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    invoke-direct {v0, p0, p1, v2}, Lav0;-><init>(Lbv0;Lfd1;B)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0, v1}, Lav0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget-byte v0, p0, Lav0;->l:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 6
    .line 7
    sget-object v3, Lsi1;->h:Lsi1;

    .line 8
    .line 9
    iget-object v4, p0, Lav0;->n:Lbv0;

    .line 10
    .line 11
    const/4 v5, 0x1

    .line 12
    const/4 v6, 0x0

    .line 13
    packed-switch v0, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    iget-object v0, v4, Lbv0;->d:Lww0;

    .line 17
    .line 18
    iget-object v4, v4, Lbv0;->a:Ld1;

    .line 19
    .line 20
    iget-boolean v7, p0, Lav0;->m:Z

    .line 21
    .line 22
    if-eqz v7, :cond_1

    .line 23
    .line 24
    if-ne v7, v5, :cond_0

    .line 25
    .line 26
    :try_start_0
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    invoke-static {v2}, Lt32;->d(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    move-object v1, v6

    .line 34
    goto :goto_2

    .line 35
    :cond_1
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    :try_start_1
    sget-object p1, Lkx0;->a:Lkx0;

    .line 39
    .line 40
    iput-boolean v5, p0, Lav0;->m:Z

    .line 41
    .line 42
    sget-object p1, Lhr1;->a:Lin1;

    .line 43
    .line 44
    sget-object p1, Lzm1;->j:Lzm1;

    .line 45
    .line 46
    new-instance v2, Ljx0;

    .line 47
    .line 48
    const/4 v5, 0x2

    .line 49
    const/4 v7, 0x0

    .line 50
    invoke-direct {v2, v5, v6, v7}, Ljx0;-><init>(ILfd1;B)V

    .line 51
    .line 52
    .line 53
    invoke-static {p1, v2, p0}, Ljj;->u0(Lii1;Llh2;Lfd1;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    if-ne p1, v3, :cond_2

    .line 58
    .line 59
    move-object v1, v3

    .line 60
    goto :goto_2

    .line 61
    :cond_2
    :goto_0
    check-cast p1, Lex0;

    .line 62
    .line 63
    iget-object p0, p1, Lex0;->b:Ljava/lang/String;

    .line 64
    .line 65
    invoke-static {p0}, Lq07;->W(Ljava/lang/CharSequence;)Z

    .line 66
    .line 67
    .line 68
    move-result p0

    .line 69
    if-nez p0, :cond_3

    .line 70
    .line 71
    iget-object p0, p1, Lex0;->b:Ljava/lang/String;

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_3
    iget-boolean p0, p1, Lex0;->a:Z

    .line 75
    .line 76
    if-eqz p0, :cond_4

    .line 77
    .line 78
    invoke-virtual {v4}, Ld1;->a()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    check-cast p0, Landroid/content/Context;

    .line 83
    .line 84
    const p1, 0x7f0f00ab

    .line 85
    .line 86
    .line 87
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    .line 93
    .line 94
    goto :goto_1

    .line 95
    :cond_4
    invoke-virtual {v4}, Ld1;->a()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    check-cast p0, Landroid/content/Context;

    .line 100
    .line 101
    const p1, 0x7f0f00aa

    .line 102
    .line 103
    .line 104
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object p0

    .line 108
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    .line 110
    .line 111
    :goto_1
    sget-object p1, Lnr7;->a:Landroid/os/Handler;

    .line 112
    .line 113
    invoke-virtual {v4}, Ld1;->a()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    check-cast p1, Landroid/content/Context;

    .line 118
    .line 119
    sget-object v2, Lmr7;->i:Lmr7;

    .line 120
    .line 121
    invoke-static {p1, p0, v2}, Lnr7;->a(Landroid/content/Context;Ljava/lang/String;Lmr7;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 122
    .line 123
    .line 124
    iget-object p0, v0, Lww0;->b:Lzd4;

    .line 125
    .line 126
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 127
    .line 128
    invoke-interface {p0, p1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    :goto_2
    return-object v1

    .line 132
    :catchall_0
    move-exception p0

    .line 133
    iget-object p1, v0, Lww0;->b:Lzd4;

    .line 134
    .line 135
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 136
    .line 137
    invoke-interface {p1, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    throw p0

    .line 141
    :pswitch_0
    iget-object v0, v4, Lbv0;->d:Lww0;

    .line 142
    .line 143
    iget-object v7, v4, Lbv0;->a:Ld1;

    .line 144
    .line 145
    iget-boolean v8, p0, Lav0;->m:Z

    .line 146
    .line 147
    if-eqz v8, :cond_6

    .line 148
    .line 149
    if-ne v8, v5, :cond_5

    .line 150
    .line 151
    :try_start_2
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 152
    .line 153
    .line 154
    goto :goto_3

    .line 155
    :cond_5
    invoke-static {v2}, Lt32;->d(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    move-object v1, v6

    .line 159
    goto :goto_5

    .line 160
    :cond_6
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    :try_start_3
    iget-object p1, v4, Lbv0;->b:Lcv0;

    .line 164
    .line 165
    invoke-virtual {p1}, Lcv0;->b()Lyw0;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    iput-boolean v5, p0, Lav0;->m:Z

    .line 170
    .line 171
    sget-object v2, Lhr1;->a:Lin1;

    .line 172
    .line 173
    sget-object v2, Lzm1;->j:Lzm1;

    .line 174
    .line 175
    new-instance v4, Ly3;

    .line 176
    .line 177
    const/16 v5, 0x8

    .line 178
    .line 179
    invoke-direct {v4, p1, v6, v5}, Ly3;-><init>(Ljava/lang/Object;Lfd1;B)V

    .line 180
    .line 181
    .line 182
    invoke-static {v2, v4, p0}, Ljj;->u0(Lii1;Llh2;Lfd1;)Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object p1

    .line 186
    if-ne p1, v3, :cond_7

    .line 187
    .line 188
    move-object v1, v3

    .line 189
    goto :goto_5

    .line 190
    :cond_7
    :goto_3
    check-cast p1, Lax0;

    .line 191
    .line 192
    iget-object p0, p1, Lax0;->b:Ljava/lang/String;

    .line 193
    .line 194
    sget-object p1, Lnr7;->a:Landroid/os/Handler;

    .line 195
    .line 196
    invoke-virtual {v7}, Ld1;->a()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    check-cast p1, Landroid/content/Context;

    .line 201
    .line 202
    if-eqz p0, :cond_8

    .line 203
    .line 204
    invoke-static {p0}, Lq07;->W(Ljava/lang/CharSequence;)Z

    .line 205
    .line 206
    .line 207
    move-result v2

    .line 208
    if-nez v2, :cond_8

    .line 209
    .line 210
    invoke-static {p0}, Lq07;->W(Ljava/lang/CharSequence;)Z

    .line 211
    .line 212
    .line 213
    move-result v2

    .line 214
    if-eqz v2, :cond_9

    .line 215
    .line 216
    invoke-virtual {v7}, Ld1;->a()Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object p0

    .line 220
    check-cast p0, Landroid/content/Context;

    .line 221
    .line 222
    const v2, 0x7f0f00a6

    .line 223
    .line 224
    .line 225
    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object p0

    .line 229
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 230
    .line 231
    .line 232
    goto :goto_4

    .line 233
    :cond_8
    invoke-virtual {v7}, Ld1;->a()Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object p0

    .line 237
    check-cast p0, Landroid/content/Context;

    .line 238
    .line 239
    const v2, 0x7f0f00d5

    .line 240
    .line 241
    .line 242
    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object p0

    .line 246
    :cond_9
    :goto_4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 247
    .line 248
    .line 249
    invoke-static {p1, p0}, Lnr7;->b(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 250
    .line 251
    .line 252
    iget-object p0, v0, Lww0;->c:Lzd4;

    .line 253
    .line 254
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 255
    .line 256
    invoke-interface {p0, p1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    :goto_5
    return-object v1

    .line 260
    :catchall_1
    move-exception p0

    .line 261
    iget-object p1, v0, Lww0;->c:Lzd4;

    .line 262
    .line 263
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 264
    .line 265
    invoke-interface {p1, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    throw p0

    .line 269
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
