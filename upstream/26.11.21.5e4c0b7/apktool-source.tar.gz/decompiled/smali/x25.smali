.class public final synthetic Lx25;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lhh2;

.field public final synthetic j:Lv15;


# direct methods
.method public synthetic constructor <init>(Lhh2;Lv15;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lx25;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lx25;->i:Lhh2;

    .line 4
    .line 5
    iput-object p2, p0, Lx25;->j:Lv15;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lx25;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    iget-object v2, p0, Lx25;->j:Lv15;

    .line 6
    .line 7
    iget-object p0, p0, Lx25;->i:Lhh2;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget-object v0, v2, Lv15;->b:Lfr0;

    .line 13
    .line 14
    invoke-interface {p0, v0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    return-object v1

    .line 18
    :pswitch_0
    iget-object v0, v2, Lv15;->b:Lfr0;

    .line 19
    .line 20
    invoke-interface {p0, v0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    return-object v1

    .line 24
    nop

    .line 25
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
