.class public interface abstract Lpl0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# direct methods
.method public static m(Lpl0;Lsu5;)V
    .locals 6

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v1, p1, Lsu5;->a:F

    .line 5
    .line 6
    iget v2, p1, Lsu5;->b:F

    .line 7
    .line 8
    iget v3, p1, Lsu5;->c:F

    .line 9
    .line 10
    iget v4, p1, Lsu5;->d:F

    .line 11
    .line 12
    const/4 v5, 0x1

    .line 13
    move-object v0, p0

    .line 14
    invoke-interface/range {v0 .. v5}, Lpl0;->h(FFFFI)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public abstract a(Luc;JLbz4;)V
.end method

.method public abstract b(FF)V
.end method

.method public abstract c(F)V
.end method

.method public abstract d(Lgd;Lbz4;)V
.end method

.method public abstract e(FFFFFFLbz4;)V
.end method

.method public abstract f(Lsu5;Lbz4;)V
.end method

.method public abstract g(FFFFLbz4;)V
.end method

.method public abstract h(FFFFI)V
.end method

.method public abstract i(FF)V
.end method

.method public abstract j()V
.end method

.method public abstract k(FFFFFFLbz4;)V
.end method

.method public abstract l(FJLbz4;)V
.end method

.method public abstract n()V
.end method

.method public abstract o()V
.end method

.method public abstract p([F)V
.end method

.method public abstract q()V
.end method

.method public abstract r(JJLbz4;)V
.end method

.method public abstract s(Lgd;)V
.end method

.method public abstract t(Luc;JJJLbz4;)V
.end method
