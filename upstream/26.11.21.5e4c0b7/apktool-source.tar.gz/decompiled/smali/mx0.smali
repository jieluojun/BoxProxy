.class public final synthetic Lmx0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lox0;

.field public final synthetic j:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Lox0;Ljava/lang/Runnable;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lmx0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lmx0;->i:Lox0;

    .line 4
    .line 5
    iput-object p2, p0, Lmx0;->j:Ljava/lang/Runnable;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-byte v0, p0, Lmx0;->h:B

    .line 2
    .line 3
    iget-object v1, p0, Lmx0;->j:Ljava/lang/Runnable;

    .line 4
    .line 5
    iget-object p0, p0, Lmx0;->i:Lox0;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    iget-boolean p0, p0, Lox0;->W:Z

    .line 11
    .line 12
    if-nez p0, :cond_0

    .line 13
    .line 14
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void

    .line 18
    :pswitch_0
    iget-boolean p0, p0, Lox0;->W:Z

    .line 19
    .line 20
    if-nez p0, :cond_1

    .line 21
    .line 22
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 23
    .line 24
    .line 25
    :cond_1
    return-void

    .line 26
    nop

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
