.class public final synthetic Lf21;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lf21;->h:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v0, v0, Lf21;->h:B

    .line 4
    .line 5
    const-string v3, ""

    .line 6
    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget-object v0, Los7;->a:Los7;

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_0
    sget-object v0, Los7;->a:Los7;

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_1
    const-string v6, "core_update_monitor"

    .line 19
    .line 20
    new-instance v7, Lng1;

    .line 21
    .line 22
    sget-object v8, Lug1;->a:Lcd1;

    .line 23
    .line 24
    new-instance v9, Lbg1;

    .line 25
    .line 26
    invoke-direct {v9, v4}, Lbg1;-><init>(B)V

    .line 27
    .line 28
    .line 29
    const-string v10, "{}"

    .line 30
    .line 31
    sget-object v0, Lsh1;->a:Lsh1;

    .line 32
    .line 33
    invoke-static {}, Lsh1;->d()Ljava/util/ArrayList;

    .line 34
    .line 35
    .line 36
    move-result-object v11

    .line 37
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    .line 38
    .line 39
    sget-object v12, Lcom/box/app/AppApplication;->h:Landroid/content/Context;

    .line 40
    .line 41
    invoke-static {}, Ldj;->U()Landroid/content/Context;

    .line 42
    .line 43
    .line 44
    move-result-object v12

    .line 45
    invoke-virtual {v12, v6, v5}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 46
    .line 47
    .line 48
    move-result-object v12

    .line 49
    const-string v13, "cache"

    .line 50
    .line 51
    invoke-interface {v12, v13, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v12

    .line 55
    if-nez v12, :cond_0

    .line 56
    .line 57
    move-object v12, v3

    .line 58
    :cond_0
    invoke-direct {v0, v12}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :catchall_0
    move-exception v0

    .line 63
    new-instance v12, Lny5;

    .line 64
    .line 65
    invoke-direct {v12, v0}, Lny5;-><init>(Ljava/lang/Throwable;)V

    .line 66
    .line 67
    .line 68
    move-object v0, v12

    .line 69
    :goto_0
    new-instance v12, Lorg/json/JSONObject;

    .line 70
    .line 71
    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    .line 72
    .line 73
    .line 74
    instance-of v13, v0, Lny5;

    .line 75
    .line 76
    if-eqz v13, :cond_1

    .line 77
    .line 78
    move-object v0, v12

    .line 79
    :cond_1
    move-object v12, v0

    .line 80
    check-cast v12, Lorg/json/JSONObject;

    .line 81
    .line 82
    new-instance v13, Ljava/util/ArrayList;

    .line 83
    .line 84
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 88
    .line 89
    .line 90
    move-result-object v14

    .line 91
    :goto_1
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_8

    .line 96
    .line 97
    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    check-cast v0, Lqh1;

    .line 102
    .line 103
    :try_start_1
    iget-object v15, v0, Lqh1;->a:Ljava/lang/String;

    .line 104
    .line 105
    invoke-virtual {v12, v15}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 106
    .line 107
    .line 108
    move-result-object v15
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    .line 109
    if-nez v15, :cond_2

    .line 110
    .line 111
    move-object/from16 v25, v3

    .line 112
    .line 113
    move/from16 v24, v4

    .line 114
    .line 115
    const/16 p0, 0x0

    .line 116
    .line 117
    const/4 v0, 0x0

    .line 118
    goto/16 :goto_4

    .line 119
    .line 120
    :cond_2
    const/16 p0, 0x0

    .line 121
    .line 122
    :try_start_2
    const-string v2, "source"

    .line 123
    .line 124
    invoke-virtual {v15, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    invoke-static {v0}, Llf;->X(Lqh1;)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    invoke-static {v2, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v1

    .line 136
    if-nez v1, :cond_3

    .line 137
    .line 138
    move-object/from16 v0, p0

    .line 139
    .line 140
    move-object/from16 v25, v3

    .line 141
    .line 142
    move/from16 v24, v4

    .line 143
    .line 144
    goto/16 :goto_4

    .line 145
    .line 146
    :cond_3
    const-string v1, "asset"

    .line 147
    .line 148
    invoke-virtual {v15, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    if-eqz v1, :cond_5

    .line 153
    .line 154
    const-string v2, "version"

    .line 155
    .line 156
    invoke-virtual {v15, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 161
    .line 162
    .line 163
    move/from16 v24, v4

    .line 164
    .line 165
    :try_start_3
    const-string v4, "name"

    .line 166
    .line 167
    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 168
    .line 169
    .line 170
    move-result-object v4

    .line 171
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    .line 173
    .line 174
    const-string v5, "url"

    .line 175
    .line 176
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v5

    .line 180
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 181
    .line 182
    .line 183
    move-object/from16 v25, v3

    .line 184
    .line 185
    :try_start_4
    const-string v3, "sha256"

    .line 186
    .line 187
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    invoke-static {v1}, Lq07;->W(Ljava/lang/CharSequence;)Z

    .line 192
    .line 193
    .line 194
    move-result v3

    .line 195
    if-eqz v3, :cond_4

    .line 196
    .line 197
    move-object/from16 v1, p0

    .line 198
    .line 199
    :cond_4
    new-instance v3, Lse1;

    .line 200
    .line 201
    invoke-direct {v3, v4, v5, v1}, Lse1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    new-instance v1, Lrh1;

    .line 205
    .line 206
    invoke-direct {v1, v0, v2, v3}, Lrh1;-><init>(Lqh1;Ljava/lang/String;Lse1;)V

    .line 207
    .line 208
    .line 209
    move-object/from16 v17, v1

    .line 210
    .line 211
    goto :goto_2

    .line 212
    :catchall_1
    move-exception v0

    .line 213
    move-object/from16 v25, v3

    .line 214
    .line 215
    goto :goto_3

    .line 216
    :cond_5
    move-object/from16 v25, v3

    .line 217
    .line 218
    move/from16 v24, v4

    .line 219
    .line 220
    move-object/from16 v17, p0

    .line 221
    .line 222
    :goto_2
    iget-object v1, v0, Lqh1;->a:Ljava/lang/String;

    .line 223
    .line 224
    new-instance v2, Lmd1;

    .line 225
    .line 226
    const-string v3, "failed"

    .line 227
    .line 228
    invoke-virtual {v15, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    .line 229
    .line 230
    .line 231
    move-result v18

    .line 232
    const-string v3, "time"

    .line 233
    .line 234
    invoke-virtual {v15, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    .line 235
    .line 236
    .line 237
    move-result-wide v19

    .line 238
    const/16 v21, 0x0

    .line 239
    .line 240
    const/16 v22, 0x24

    .line 241
    .line 242
    move-object/from16 v16, v0

    .line 243
    .line 244
    move-object v15, v2

    .line 245
    invoke-direct/range {v15 .. v22}, Lmd1;-><init>(Lqh1;Lrh1;ZJLjava/lang/String;I)V

    .line 246
    .line 247
    .line 248
    new-instance v0, Lj65;

    .line 249
    .line 250
    invoke-direct {v0, v1, v15}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 251
    .line 252
    .line 253
    goto :goto_4

    .line 254
    :catchall_2
    move-exception v0

    .line 255
    goto :goto_3

    .line 256
    :catchall_3
    move-exception v0

    .line 257
    move-object/from16 v25, v3

    .line 258
    .line 259
    move/from16 v24, v4

    .line 260
    .line 261
    goto :goto_3

    .line 262
    :catchall_4
    move-exception v0

    .line 263
    move-object/from16 v25, v3

    .line 264
    .line 265
    move/from16 v24, v4

    .line 266
    .line 267
    const/16 p0, 0x0

    .line 268
    .line 269
    :goto_3
    new-instance v1, Lny5;

    .line 270
    .line 271
    invoke-direct {v1, v0}, Lny5;-><init>(Ljava/lang/Throwable;)V

    .line 272
    .line 273
    .line 274
    move-object v0, v1

    .line 275
    :goto_4
    instance-of v1, v0, Lny5;

    .line 276
    .line 277
    if-eqz v1, :cond_6

    .line 278
    .line 279
    move-object/from16 v0, p0

    .line 280
    .line 281
    :cond_6
    check-cast v0, Lj65;

    .line 282
    .line 283
    if-eqz v0, :cond_7

    .line 284
    .line 285
    invoke-virtual {v13, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 286
    .line 287
    .line 288
    :cond_7
    move/from16 v4, v24

    .line 289
    .line 290
    move-object/from16 v3, v25

    .line 291
    .line 292
    goto/16 :goto_1

    .line 293
    .line 294
    :cond_8
    move-object/from16 v25, v3

    .line 295
    .line 296
    move/from16 v24, v4

    .line 297
    .line 298
    const/16 v23, 0x2

    .line 299
    .line 300
    invoke-static {v13}, Lhy3;->j0(Ljava/util/ArrayList;)Ljava/util/Map;

    .line 301
    .line 302
    .line 303
    move-result-object v1

    .line 304
    :try_start_5
    new-instance v0, Lorg/json/JSONObject;

    .line 305
    .line 306
    sget-object v2, Lcom/box/app/AppApplication;->h:Landroid/content/Context;

    .line 307
    .line 308
    invoke-static {}, Ldj;->U()Landroid/content/Context;

    .line 309
    .line 310
    .line 311
    move-result-object v2

    .line 312
    const/4 v3, 0x0

    .line 313
    invoke-virtual {v2, v6, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 314
    .line 315
    .line 316
    move-result-object v2

    .line 317
    const-string v3, "ignored_versions"

    .line 318
    .line 319
    invoke-interface {v2, v3, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 320
    .line 321
    .line 322
    move-result-object v2

    .line 323
    if-nez v2, :cond_9

    .line 324
    .line 325
    move-object/from16 v3, v25

    .line 326
    .line 327
    goto :goto_5

    .line 328
    :cond_9
    move-object v3, v2

    .line 329
    :goto_5
    invoke-direct {v0, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 330
    .line 331
    .line 332
    goto :goto_6

    .line 333
    :catchall_5
    move-exception v0

    .line 334
    new-instance v2, Lny5;

    .line 335
    .line 336
    invoke-direct {v2, v0}, Lny5;-><init>(Ljava/lang/Throwable;)V

    .line 337
    .line 338
    .line 339
    move-object v0, v2

    .line 340
    :goto_6
    new-instance v2, Lorg/json/JSONObject;

    .line 341
    .line 342
    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 343
    .line 344
    .line 345
    instance-of v3, v0, Lny5;

    .line 346
    .line 347
    if-eqz v3, :cond_a

    .line 348
    .line 349
    move-object v0, v2

    .line 350
    :cond_a
    check-cast v0, Lorg/json/JSONObject;

    .line 351
    .line 352
    invoke-virtual {v0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    .line 353
    .line 354
    .line 355
    move-result-object v2

    .line 356
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 357
    .line 358
    .line 359
    invoke-static {v2}, Lcl6;->t(Ljava/util/Iterator;)Lyk6;

    .line 360
    .line 361
    .line 362
    move-result-object v2

    .line 363
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 364
    .line 365
    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 366
    .line 367
    .line 368
    check-cast v2, Lqa1;

    .line 369
    .line 370
    invoke-virtual {v2}, Lqa1;->iterator()Ljava/util/Iterator;

    .line 371
    .line 372
    .line 373
    move-result-object v2

    .line 374
    :goto_7
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 375
    .line 376
    .line 377
    move-result v4

    .line 378
    if-eqz v4, :cond_b

    .line 379
    .line 380
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 381
    .line 382
    .line 383
    move-result-object v4

    .line 384
    move-object v5, v4

    .line 385
    check-cast v5, Ljava/lang/String;

    .line 386
    .line 387
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 388
    .line 389
    .line 390
    move-result-object v5

    .line 391
    invoke-interface {v3, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 392
    .line 393
    .line 394
    goto :goto_7

    .line 395
    :cond_b
    new-instance v12, Lvg1;

    .line 396
    .line 397
    sget-object v15, Lx12;->h:Lx12;

    .line 398
    .line 399
    const/16 v0, 0x14

    .line 400
    .line 401
    and-int/lit8 v4, v0, 0x1

    .line 402
    .line 403
    if-eqz v4, :cond_c

    .line 404
    .line 405
    sget-object v11, Lw12;->h:Lw12;

    .line 406
    .line 407
    :cond_c
    move-object v13, v11

    .line 408
    and-int/lit8 v2, v0, 0x2

    .line 409
    .line 410
    if-eqz v2, :cond_d

    .line 411
    .line 412
    move-object v14, v15

    .line 413
    goto :goto_8

    .line 414
    :cond_d
    move-object v14, v1

    .line 415
    :goto_8
    and-int/lit8 v0, v0, 0x8

    .line 416
    .line 417
    if-eqz v0, :cond_e

    .line 418
    .line 419
    move-object/from16 v16, v15

    .line 420
    .line 421
    goto :goto_9

    .line 422
    :cond_e
    move-object/from16 v16, v3

    .line 423
    .line 424
    :goto_9
    move-object/from16 v17, v15

    .line 425
    .line 426
    invoke-direct/range {v12 .. v17}, Lvg1;-><init>(Ljava/util/List;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V

    .line 427
    .line 428
    .line 429
    invoke-direct {v7, v8, v9, v12}, Lng1;-><init>(Lcd1;Lbg1;Lvg1;)V

    .line 430
    .line 431
    .line 432
    return-object v7

    .line 433
    :pswitch_2
    sget-object v0, Los7;->a:Los7;

    .line 434
    .line 435
    return-object v0

    .line 436
    :pswitch_3
    sget-object v0, Los7;->a:Los7;

    .line 437
    .line 438
    return-object v0

    .line 439
    :pswitch_4
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 440
    .line 441
    invoke-static {v0}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 442
    .line 443
    .line 444
    move-result-object v0

    .line 445
    return-object v0

    .line 446
    :pswitch_5
    sget-object v0, Los7;->a:Los7;

    .line 447
    .line 448
    return-object v0

    .line 449
    :pswitch_6
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 450
    .line 451
    invoke-static {v0}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 452
    .line 453
    .line 454
    move-result-object v0

    .line 455
    return-object v0

    .line 456
    :pswitch_7
    sget-object v0, Los7;->a:Los7;

    .line 457
    .line 458
    return-object v0

    .line 459
    :pswitch_8
    move-object/from16 v25, v3

    .line 460
    .line 461
    invoke-static/range {v25 .. v25}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 462
    .line 463
    .line 464
    move-result-object v0

    .line 465
    return-object v0

    .line 466
    :pswitch_9
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 467
    .line 468
    invoke-static {v0}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 469
    .line 470
    .line 471
    move-result-object v0

    .line 472
    return-object v0

    .line 473
    :pswitch_a
    sget-object v0, Los7;->a:Los7;

    .line 474
    .line 475
    return-object v0

    .line 476
    :pswitch_b
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 477
    .line 478
    invoke-static {v0}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 479
    .line 480
    .line 481
    move-result-object v0

    .line 482
    return-object v0

    .line 483
    :pswitch_c
    move-object/from16 v25, v3

    .line 484
    .line 485
    invoke-static/range {v25 .. v25}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 486
    .line 487
    .line 488
    move-result-object v0

    .line 489
    return-object v0

    .line 490
    :pswitch_d
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 491
    .line 492
    invoke-static {v0}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 493
    .line 494
    .line 495
    move-result-object v0

    .line 496
    return-object v0

    .line 497
    :pswitch_e
    sget-object v0, Los7;->a:Los7;

    .line 498
    .line 499
    return-object v0

    .line 500
    :pswitch_f
    move v3, v5

    .line 501
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 502
    .line 503
    .line 504
    move-result-object v0

    .line 505
    invoke-static {v0}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 506
    .line 507
    .line 508
    move-result-object v0

    .line 509
    return-object v0

    .line 510
    :pswitch_10
    const-string v0, "Unexpected call to default provider"

    .line 511
    .line 512
    invoke-static {v0}, Lx82;->C(Ljava/lang/String;)Ll11;

    .line 513
    .line 514
    .line 515
    move-result-object v0

    .line 516
    throw v0

    .line 517
    :pswitch_11
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 518
    .line 519
    const-string v1, "CompositionLocal LocalOwner not present"

    .line 520
    .line 521
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 522
    .line 523
    .line 524
    move-result-object v1

    .line 525
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 526
    .line 527
    .line 528
    throw v0

    .line 529
    :pswitch_12
    move/from16 v24, v4

    .line 530
    .line 531
    move v3, v5

    .line 532
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 533
    .line 534
    const/16 v1, 0x100

    .line 535
    .line 536
    move/from16 v2, v24

    .line 537
    .line 538
    invoke-static {v1, v2, v0}, Ll40;->a(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 539
    .line 540
    .line 541
    move-result-object v4

    .line 542
    sget-object v0, Lha1;->e:[I

    .line 543
    .line 544
    new-array v5, v1, [I

    .line 545
    .line 546
    :goto_a
    if-ge v3, v1, :cond_f

    .line 547
    .line 548
    and-int/lit16 v2, v3, 0xff

    .line 549
    .line 550
    aget v2, v0, v2

    .line 551
    .line 552
    shl-int/lit8 v6, v2, 0x10

    .line 553
    .line 554
    const/high16 v7, -0x1000000

    .line 555
    .line 556
    or-int/2addr v6, v7

    .line 557
    shl-int/lit8 v7, v2, 0x8

    .line 558
    .line 559
    or-int/2addr v6, v7

    .line 560
    or-int/2addr v6, v2

    .line 561
    aput v6, v5, v3

    .line 562
    .line 563
    add-int/lit8 v3, v3, 0x1

    .line 564
    .line 565
    goto :goto_a

    .line 566
    :cond_f
    const/16 v10, 0x100

    .line 567
    .line 568
    const/4 v11, 0x1

    .line 569
    const/4 v6, 0x0

    .line 570
    const/16 v7, 0x100

    .line 571
    .line 572
    const/4 v8, 0x0

    .line 573
    const/4 v9, 0x0

    .line 574
    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V

    .line 575
    .line 576
    .line 577
    return-object v4

    .line 578
    :pswitch_13
    const/16 p0, 0x0

    .line 579
    .line 580
    return-object p0

    .line 581
    :pswitch_14
    const/16 v23, 0x2

    .line 582
    .line 583
    new-instance v0, Lwi3;

    .line 584
    .line 585
    move/from16 v1, v23

    .line 586
    .line 587
    invoke-direct {v0, v1}, Lwi3;-><init>(I)V

    .line 588
    .line 589
    .line 590
    return-object v0

    .line 591
    :pswitch_15
    sget-object v0, Los7;->a:Los7;

    .line 592
    .line 593
    return-object v0

    .line 594
    :pswitch_16
    sget-object v0, Los7;->a:Los7;

    .line 595
    .line 596
    return-object v0

    .line 597
    :pswitch_17
    sget-object v0, Los7;->a:Los7;

    .line 598
    .line 599
    return-object v0

    .line 600
    :pswitch_18
    sget-object v0, Los7;->a:Los7;

    .line 601
    .line 602
    return-object v0

    .line 603
    :pswitch_19
    sget-object v0, Los7;->a:Los7;

    .line 604
    .line 605
    return-object v0

    .line 606
    :pswitch_1a
    sget-object v0, Los7;->a:Los7;

    .line 607
    .line 608
    return-object v0

    .line 609
    :pswitch_1b
    new-instance v0, Lzc4;

    .line 610
    .line 611
    invoke-direct {v0}, Lzc4;-><init>()V

    .line 612
    .line 613
    .line 614
    return-object v0

    .line 615
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_13
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
