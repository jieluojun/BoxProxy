.class public final Lip0;
.super Lqf5;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final c:Lip0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lip0;

    .line 2
    .line 3
    sget-object v1, Lpp0;->a:Lpp0;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lqf5;-><init>(Ldg3;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lip0;->c:Lip0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)I
    .locals 0

    .line 1
    check-cast p1, [C

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    array-length p0, p1

    .line 7
    return p0
.end method

.method public final j(Lg51;ILjava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p3, Lgp0;

    .line 2
    .line 3
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lqf5;->b:Lpf5;

    .line 7
    .line 8
    invoke-interface {p1, p0, p2}, Lg51;->k(Lpf5;I)C

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    invoke-static {p3}, Lof5;->c(Lof5;)V

    .line 13
    .line 14
    .line 15
    iget-object p1, p3, Lgp0;->a:[C

    .line 16
    .line 17
    iget p2, p3, Lgp0;->b:I

    .line 18
    .line 19
    add-int/lit8 v0, p2, 0x1

    .line 20
    .line 21
    iput v0, p3, Lgp0;->b:I

    .line 22
    .line 23
    aput-char p0, p1, p2

    .line 24
    .line 25
    return-void
.end method

.method public final m()Lof5;
    .locals 1

    .line 1
    new-instance p0, Lgp0;

    .line 2
    .line 3
    const/16 v0, 0xa

    .line 4
    .line 5
    new-array v0, v0, [C

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lgp0;->a:[C

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    iput v0, p0, Lgp0;->b:I

    .line 14
    .line 15
    return-object p0
.end method

.method public final n(Lh07;Ljava/lang/Object;I)V
    .locals 3

    .line 1
    check-cast p2, [C

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    :goto_0
    if-ge v0, p3, :cond_0

    .line 11
    .line 12
    aget-char v1, p2, v0

    .line 13
    .line 14
    iget-object v2, p0, Lqf5;->b:Lpf5;

    .line 15
    .line 16
    invoke-virtual {p1, v2, v0}, Lh07;->f(Lgl6;I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1, v1}, Lh07;->d(C)V

    .line 20
    .line 21
    .line 22
    add-int/lit8 v0, v0, 0x1

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    return-void
.end method
