.class public abstract Lej6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lfj;

.field public static final b:Lpo7;

.field public static final c:Ltx6;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, Lfj;

    .line 2
    .line 3
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 4
    .line 5
    invoke-direct {v0, v1, v1}, Lfj;-><init>(FF)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lej6;->a:Lfj;

    .line 9
    .line 10
    new-instance v0, Ldd6;

    .line 11
    .line 12
    const/16 v1, 0x11

    .line 13
    .line 14
    invoke-direct {v0, v1}, Ldd6;-><init>(B)V

    .line 15
    .line 16
    .line 17
    new-instance v1, Ldd6;

    .line 18
    .line 19
    const/16 v2, 0x12

    .line 20
    .line 21
    invoke-direct {v1, v2}, Ldd6;-><init>(B)V

    .line 22
    .line 23
    .line 24
    new-instance v2, Lpo7;

    .line 25
    .line 26
    invoke-direct {v2, v0, v1}, Lpo7;-><init>(Lhh2;Lhh2;)V

    .line 27
    .line 28
    .line 29
    sput-object v2, Lej6;->b:Lpo7;

    .line 30
    .line 31
    new-instance v0, Ltx6;

    .line 32
    .line 33
    new-instance v1, Lhv4;

    .line 34
    .line 35
    const-wide v2, 0x3c23d70a3c23d70aL    # 5.377642754525469E-19

    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    invoke-direct {v1, v2, v3}, Lhv4;-><init>(J)V

    .line 41
    .line 42
    .line 43
    const/4 v2, 0x3

    .line 44
    invoke-direct {v0, v2, v1}, Ltx6;-><init>(ILjava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    sput-object v0, Lej6;->c:Ltx6;

    .line 48
    .line 49
    return-void
.end method
