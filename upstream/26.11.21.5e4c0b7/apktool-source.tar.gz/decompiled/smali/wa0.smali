.class public final Lwa0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Ljb0;


# static fields
.field public static final INSTANCE:Lwa0;

.field public static final synthetic a:Lpj3;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lwa0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lwa0;->INSTANCE:Lwa0;

    .line 7
    .line 8
    new-instance v0, Lra0;

    .line 9
    .line 10
    const/4 v1, 0x4

    .line 11
    invoke-direct {v0, v1}, Lra0;-><init>(B)V

    .line 12
    .line 13
    .line 14
    sget-object v1, Lzm3;->i:Lzm3;

    .line 15
    .line 16
    invoke-static {v1, v0}, Lh43;->R(Lzm3;Lwg2;)Lpj3;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lwa0;->a:Lpj3;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of p0, p1, Lwa0;

    .line 6
    .line 7
    if-nez p0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_1
    return v0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    const p0, -0x5ed71c8e

    .line 2
    .line 3
    .line 4
    return p0
.end method

.method public final serializer()Ldg3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ldg3;"
        }
    .end annotation

    .line 1
    sget-object p0, Lwa0;->a:Lpj3;

    .line 2
    .line 3
    invoke-interface {p0}, Lpj3;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ldg3;

    .line 8
    .line 9
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "Rules"

    .line 2
    .line 3
    return-object p0
.end method
