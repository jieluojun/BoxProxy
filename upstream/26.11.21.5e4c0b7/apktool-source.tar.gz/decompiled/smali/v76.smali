.class public final synthetic Lv76;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lzd4;

.field public final synthetic j:Lf86;

.field public final synthetic k:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lzd4;Lf86;Lzd4;)V
    .locals 1

    .line 14
    const/4 v0, 0x1

    iput-byte v0, p0, Lv76;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lv76;->i:Lzd4;

    iput-object p2, p0, Lv76;->j:Lf86;

    iput-object p3, p0, Lv76;->k:Lzd4;

    return-void
.end method

.method public synthetic constructor <init>(Lzd4;Lzd4;Lf86;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lv76;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lv76;->i:Lzd4;

    .line 8
    .line 9
    iput-object p2, p0, Lv76;->k:Lzd4;

    .line 10
    .line 11
    iput-object p3, p0, Lv76;->j:Lf86;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lv76;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    const/4 v5, 0x0

    .line 10
    iget-object v6, v0, Lv76;->k:Lzd4;

    .line 11
    .line 12
    iget-object v7, v0, Lv76;->j:Lf86;

    .line 13
    .line 14
    iget-object v0, v0, Lv76;->i:Lzd4;

    .line 15
    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object/from16 v1, p1

    .line 20
    .line 21
    check-cast v1, Lki2;

    .line 22
    .line 23
    move-object/from16 v8, p2

    .line 24
    .line 25
    check-cast v8, Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 28
    .line 29
    .line 30
    move-result v8

    .line 31
    and-int/lit8 v9, v8, 0x3

    .line 32
    .line 33
    if-eq v9, v3, :cond_0

    .line 34
    .line 35
    move v3, v4

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move v3, v5

    .line 38
    :goto_0
    and-int/2addr v8, v4

    .line 39
    invoke-virtual {v1, v8, v3}, Lki2;->Y(IZ)Z

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    if-eqz v3, :cond_6

    .line 44
    .line 45
    sget-object v3, Lea4;->h:Lea4;

    .line 46
    .line 47
    const/high16 v8, 0x3f800000    # 1.0f

    .line 48
    .line 49
    invoke-static {v3, v8}, Lit6;->e(Lha4;F)Lha4;

    .line 50
    .line 51
    .line 52
    move-result-object v9

    .line 53
    sget-object v10, Lx87;->c:Lrw;

    .line 54
    .line 55
    sget-object v11, Ly6;->s:Lz30;

    .line 56
    .line 57
    invoke-static {v10, v11, v1, v5}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    iget-wide v10, v1, Lki2;->U:J

    .line 62
    .line 63
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 64
    .line 65
    .line 66
    move-result v10

    .line 67
    invoke-virtual {v1}, Lki2;->m()Lr95;

    .line 68
    .line 69
    .line 70
    move-result-object v11

    .line 71
    invoke-static {v1, v9}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 72
    .line 73
    .line 74
    move-result-object v9

    .line 75
    sget-object v12, Lp41;->d:Ly6;

    .line 76
    .line 77
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v1}, Lki2;->k0()V

    .line 81
    .line 82
    .line 83
    iget-boolean v12, v1, Lki2;->T:Z

    .line 84
    .line 85
    if-eqz v12, :cond_1

    .line 86
    .line 87
    sget-object v12, Lwi3;->Z:Lj43;

    .line 88
    .line 89
    invoke-virtual {v1, v12}, Lki2;->l(Lwg2;)V

    .line 90
    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_1
    invoke-virtual {v1}, Lki2;->t0()V

    .line 94
    .line 95
    .line 96
    :goto_1
    sget-object v12, Ly6;->T:Lu31;

    .line 97
    .line 98
    invoke-static {v12, v1, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    sget-object v5, Ly6;->S:Lu31;

    .line 102
    .line 103
    invoke-static {v5, v1, v11}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 107
    .line 108
    .line 109
    move-result-object v5

    .line 110
    sget-object v10, Ly6;->U:Lu31;

    .line 111
    .line 112
    invoke-static {v10, v1, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    invoke-static {v1}, Lml6;->p(Lki2;)V

    .line 116
    .line 117
    .line 118
    sget-object v5, Ly6;->R:Lu31;

    .line 119
    .line 120
    invoke-static {v5, v1, v9}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    const/high16 v5, 0x1040000

    .line 124
    .line 125
    invoke-static {v5, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    invoke-virtual {v1, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v9

    .line 133
    invoke-virtual {v1}, Lki2;->T()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v10

    .line 137
    sget-object v11, Lz41;->a:Lql0;

    .line 138
    .line 139
    if-nez v9, :cond_2

    .line 140
    .line 141
    if-ne v10, v11, :cond_3

    .line 142
    .line 143
    :cond_2
    new-instance v10, Lg76;

    .line 144
    .line 145
    const/16 v9, 0xd

    .line 146
    .line 147
    invoke-direct {v10, v0, v9}, Lg76;-><init>(Lzd4;B)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v1, v10}, Lki2;->q0(Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    :cond_3
    move-object v9, v10

    .line 154
    check-cast v9, Lwg2;

    .line 155
    .line 156
    new-instance v10, Lmj3;

    .line 157
    .line 158
    invoke-direct {v10, v8, v4}, Lmj3;-><init>(FZ)V

    .line 159
    .line 160
    .line 161
    const/16 v19, 0x0

    .line 162
    .line 163
    const/16 v20, 0xff8

    .line 164
    .line 165
    move-object v0, v11

    .line 166
    const/4 v11, 0x0

    .line 167
    const/4 v12, 0x0

    .line 168
    const/4 v13, 0x0

    .line 169
    const/4 v14, 0x0

    .line 170
    const/4 v15, 0x0

    .line 171
    const/16 v16, 0x0

    .line 172
    .line 173
    const/16 v17, 0x0

    .line 174
    .line 175
    move-object/from16 v18, v1

    .line 176
    .line 177
    move-object v1, v0

    .line 178
    move v0, v8

    .line 179
    move-object v8, v5

    .line 180
    invoke-static/range {v8 .. v20}, Lx53;->f(Ljava/lang/String;Lwg2;Lha4;ZFFFLm64;Lu35;Ld63;Lki2;II)V

    .line 181
    .line 182
    .line 183
    move-object/from16 v5, v18

    .line 184
    .line 185
    const/high16 v8, 0x41a00000    # 20.0f

    .line 186
    .line 187
    const v9, 0x7f0f041f

    .line 188
    .line 189
    .line 190
    invoke-static {v3, v8, v5, v9, v5}, Lx82;->o(Lea4;FLki2;ILki2;)Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v8

    .line 194
    invoke-interface {v6}, Lxy6;->getValue()Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v3

    .line 198
    check-cast v3, Ljava/lang/String;

    .line 199
    .line 200
    invoke-static {v3}, Lq07;->W(Ljava/lang/CharSequence;)Z

    .line 201
    .line 202
    .line 203
    move-result v3

    .line 204
    xor-int/lit8 v11, v3, 0x1

    .line 205
    .line 206
    new-instance v10, Lmj3;

    .line 207
    .line 208
    invoke-direct {v10, v0, v4}, Lmj3;-><init>(FZ)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v5, v7}, Lki2;->g(Ljava/lang/Object;)Z

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    invoke-virtual {v5}, Lki2;->T()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v3

    .line 219
    if-nez v0, :cond_4

    .line 220
    .line 221
    if-ne v3, v1, :cond_5

    .line 222
    .line 223
    :cond_4
    new-instance v3, Ll76;

    .line 224
    .line 225
    const/4 v0, 0x3

    .line 226
    invoke-direct {v3, v7, v0}, Ll76;-><init>(Lf86;B)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v5, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    :cond_5
    move-object v9, v3

    .line 233
    check-cast v9, Lwg2;

    .line 234
    .line 235
    const/high16 v19, 0xc00000

    .line 236
    .line 237
    const/16 v20, 0xf70

    .line 238
    .line 239
    const/4 v12, 0x0

    .line 240
    const/4 v13, 0x0

    .line 241
    const/4 v14, 0x0

    .line 242
    sget-object v15, Lm64;->i:Lm64;

    .line 243
    .line 244
    const/16 v16, 0x0

    .line 245
    .line 246
    const/16 v17, 0x0

    .line 247
    .line 248
    move-object/from16 v18, v5

    .line 249
    .line 250
    invoke-static/range {v8 .. v20}, Lx53;->f(Ljava/lang/String;Lwg2;Lha4;ZFFFLm64;Lu35;Ld63;Lki2;II)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v5, v4}, Lki2;->r(Z)V

    .line 254
    .line 255
    .line 256
    goto :goto_2

    .line 257
    :cond_6
    move-object v5, v1

    .line 258
    invoke-virtual {v5}, Lki2;->b0()V

    .line 259
    .line 260
    .line 261
    :goto_2
    return-object v2

    .line 262
    :pswitch_0
    move-object/from16 v12, p1

    .line 263
    .line 264
    check-cast v12, Lki2;

    .line 265
    .line 266
    move-object/from16 v1, p2

    .line 267
    .line 268
    check-cast v1, Ljava/lang/Integer;

    .line 269
    .line 270
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 271
    .line 272
    .line 273
    move-result v1

    .line 274
    and-int/lit8 v8, v1, 0x3

    .line 275
    .line 276
    if-eq v8, v3, :cond_7

    .line 277
    .line 278
    move v5, v4

    .line 279
    :cond_7
    and-int/2addr v1, v4

    .line 280
    invoke-virtual {v12, v1, v5}, Lki2;->Y(IZ)Z

    .line 281
    .line 282
    .line 283
    move-result v1

    .line 284
    if-eqz v1, :cond_8

    .line 285
    .line 286
    new-instance v1, Lb71;

    .line 287
    .line 288
    const/16 v3, 0xa

    .line 289
    .line 290
    invoke-direct {v1, v0, v3}, Lb71;-><init>(Lzd4;B)V

    .line 291
    .line 292
    .line 293
    const v3, 0x5a8e213f    # 2.00030006E16f

    .line 294
    .line 295
    .line 296
    invoke-static {v3, v1, v12}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 297
    .line 298
    .line 299
    move-result-object v10

    .line 300
    new-instance v1, Lv76;

    .line 301
    .line 302
    invoke-direct {v1, v6, v7, v0}, Lv76;-><init>(Lzd4;Lf86;Lzd4;)V

    .line 303
    .line 304
    .line 305
    const v0, 0x3ab097ee

    .line 306
    .line 307
    .line 308
    invoke-static {v0, v1, v12}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 309
    .line 310
    .line 311
    move-result-object v11

    .line 312
    const v13, 0x36000

    .line 313
    .line 314
    .line 315
    const/16 v14, 0xf

    .line 316
    .line 317
    const/4 v6, 0x0

    .line 318
    const/4 v7, 0x0

    .line 319
    const/4 v8, 0x0

    .line 320
    const/4 v9, 0x0

    .line 321
    invoke-static/range {v6 .. v14}, Lug6;->b(Lha4;FLuw;Lyf6;Lq21;Lq21;Lki2;II)V

    .line 322
    .line 323
    .line 324
    goto :goto_3

    .line 325
    :cond_8
    invoke-virtual {v12}, Lki2;->b0()V

    .line 326
    .line 327
    .line 328
    :goto_3
    return-object v2

    .line 329
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
