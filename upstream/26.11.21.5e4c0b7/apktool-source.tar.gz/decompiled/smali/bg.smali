.class public final synthetic Lbg;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ldc1;Lgt7;Luc3;Lng6;)V
    .locals 0

    .line 1
    const/16 p2, 0xa

    .line 2
    .line 3
    iput-byte p2, p0, Lbg;->h:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lbg;->i:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p3, p0, Lbg;->j:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p4, p0, Lbg;->k:Ljava/lang/Object;

    .line 13
    .line 14
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 17
    iput-byte p4, p0, Lbg;->h:B

    iput-object p1, p0, Lbg;->i:Ljava/lang/Object;

    iput-object p2, p0, Lbg;->j:Ljava/lang/Object;

    iput-object p3, p0, Lbg;->k:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lmw7;Lwi3;Lmw7;)V
    .locals 1

    .line 16
    const/4 v0, 0x0

    iput-byte v0, p0, Lbg;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbg;->i:Ljava/lang/Object;

    iput-object p2, p0, Lbg;->k:Ljava/lang/Object;

    iput-object p3, p0, Lbg;->j:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lxu5;Lwf6;Lxu5;Lum1;)V
    .locals 0

    .line 15
    const/16 p4, 0xd

    iput-byte p4, p0, Lbg;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbg;->i:Ljava/lang/Object;

    iput-object p2, p0, Lbg;->j:Ljava/lang/Object;

    iput-object p3, p0, Lbg;->k:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lbg;->h:B

    .line 4
    .line 5
    const/4 v2, 0x4

    .line 6
    const/high16 v3, 0x3f800000    # 1.0f

    .line 7
    .line 8
    const/high16 v4, -0x40800000    # -1.0f

    .line 9
    .line 10
    const/high16 v5, 0x3f000000    # 0.5f

    .line 11
    .line 12
    const/16 v6, 0x8

    .line 13
    .line 14
    const/4 v7, 0x0

    .line 15
    const/16 v10, 0x20

    .line 16
    .line 17
    const/4 v11, 0x2

    .line 18
    const/4 v12, 0x3

    .line 19
    const/16 v13, 0xb

    .line 20
    .line 21
    const/4 v14, 0x0

    .line 22
    const/4 v15, 0x0

    .line 23
    const-wide v16, 0xffffffffL

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    const/4 v8, 0x1

    .line 29
    packed-switch v1, :pswitch_data_0

    .line 30
    .line 31
    .line 32
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v1, Lco3;

    .line 35
    .line 36
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v2, Lko3;

    .line 39
    .line 40
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v0, Lhh2;

    .line 43
    .line 44
    move-object/from16 v3, p1

    .line 45
    .line 46
    check-cast v3, Lsr1;

    .line 47
    .line 48
    new-instance v3, Lav5;

    .line 49
    .line 50
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 51
    .line 52
    .line 53
    new-instance v4, Lyn3;

    .line 54
    .line 55
    invoke-direct {v4, v2, v3, v0}, Lyn3;-><init>(Lko3;Lav5;Lhh2;)V

    .line 56
    .line 57
    .line 58
    invoke-interface {v1}, Lco3;->g()Lfo3;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-virtual {v0, v4}, Lfo3;->a(Lbo3;)V

    .line 63
    .line 64
    .line 65
    new-instance v0, Lrh;

    .line 66
    .line 67
    invoke-direct {v0, v1, v4, v3, v8}, Lrh;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 68
    .line 69
    .line 70
    return-object v0

    .line 71
    :pswitch_0
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v1, Lyi3;

    .line 74
    .line 75
    iget-object v2, v1, Lyi3;->h:Ltl0;

    .line 76
    .line 77
    iget-object v3, v0, Lbg;->j:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v3, Lkv1;

    .line 80
    .line 81
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v0, Lhh2;

    .line 84
    .line 85
    move-object/from16 v4, p1

    .line 86
    .line 87
    check-cast v4, Llv1;

    .line 88
    .line 89
    iget-object v5, v1, Lyi3;->i:Lkv1;

    .line 90
    .line 91
    iput-object v3, v1, Lyi3;->i:Lkv1;

    .line 92
    .line 93
    :try_start_0
    invoke-interface {v4}, Llv1;->V()Lvh7;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    invoke-virtual {v3}, Lvh7;->a()Lso1;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    invoke-interface {v4}, Llv1;->V()Lvh7;

    .line 102
    .line 103
    .line 104
    move-result-object v6

    .line 105
    invoke-virtual {v6}, Lvh7;->N()Lgi3;

    .line 106
    .line 107
    .line 108
    move-result-object v6

    .line 109
    invoke-interface {v4}, Llv1;->V()Lvh7;

    .line 110
    .line 111
    .line 112
    move-result-object v7

    .line 113
    invoke-virtual {v7}, Lvh7;->K()Lpl0;

    .line 114
    .line 115
    .line 116
    move-result-object v7

    .line 117
    invoke-interface {v4}, Llv1;->V()Lvh7;

    .line 118
    .line 119
    .line 120
    move-result-object v8

    .line 121
    invoke-virtual {v8}, Lvh7;->P()J

    .line 122
    .line 123
    .line 124
    move-result-wide v8

    .line 125
    invoke-interface {v4}, Llv1;->V()Lvh7;

    .line 126
    .line 127
    .line 128
    move-result-object v4

    .line 129
    iget-object v4, v4, Lvh7;->j:Ljava/lang/Object;

    .line 130
    .line 131
    check-cast v4, Lcq2;

    .line 132
    .line 133
    iget-object v10, v2, Ltl0;->i:Lvh7;

    .line 134
    .line 135
    invoke-virtual {v10}, Lvh7;->a()Lso1;

    .line 136
    .line 137
    .line 138
    move-result-object v10

    .line 139
    iget-object v11, v2, Ltl0;->i:Lvh7;

    .line 140
    .line 141
    invoke-virtual {v11}, Lvh7;->N()Lgi3;

    .line 142
    .line 143
    .line 144
    move-result-object v11

    .line 145
    iget-object v12, v2, Ltl0;->i:Lvh7;

    .line 146
    .line 147
    invoke-virtual {v12}, Lvh7;->K()Lpl0;

    .line 148
    .line 149
    .line 150
    move-result-object v12

    .line 151
    iget-object v13, v2, Ltl0;->i:Lvh7;

    .line 152
    .line 153
    invoke-virtual {v13}, Lvh7;->P()J

    .line 154
    .line 155
    .line 156
    move-result-wide v13

    .line 157
    iget-object v15, v2, Ltl0;->i:Lvh7;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 158
    .line 159
    move-object/from16 v16, v5

    .line 160
    .line 161
    :try_start_1
    iget-object v5, v15, Lvh7;->j:Ljava/lang/Object;

    .line 162
    .line 163
    check-cast v5, Lcq2;

    .line 164
    .line 165
    invoke-virtual {v15, v3}, Lvh7;->p0(Lso1;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v15, v6}, Lvh7;->q0(Lgi3;)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v15, v7}, Lvh7;->o0(Lpl0;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v15, v8, v9}, Lvh7;->r0(J)V

    .line 175
    .line 176
    .line 177
    iput-object v4, v15, Lvh7;->j:Ljava/lang/Object;

    .line 178
    .line 179
    invoke-interface {v7}, Lpl0;->n()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 180
    .line 181
    .line 182
    :try_start_2
    invoke-interface {v0, v1}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 183
    .line 184
    .line 185
    :try_start_3
    invoke-interface {v7}, Lpl0;->j()V

    .line 186
    .line 187
    .line 188
    iget-object v0, v2, Ltl0;->i:Lvh7;

    .line 189
    .line 190
    invoke-virtual {v0, v10}, Lvh7;->p0(Lso1;)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v0, v11}, Lvh7;->q0(Lgi3;)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v0, v12}, Lvh7;->o0(Lpl0;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v0, v13, v14}, Lvh7;->r0(J)V

    .line 200
    .line 201
    .line 202
    iput-object v5, v0, Lvh7;->j:Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 203
    .line 204
    move-object/from16 v3, v16

    .line 205
    .line 206
    iput-object v3, v1, Lyi3;->i:Lkv1;

    .line 207
    .line 208
    sget-object v0, Los7;->a:Los7;

    .line 209
    .line 210
    return-object v0

    .line 211
    :catchall_0
    move-exception v0

    .line 212
    move-object/from16 v3, v16

    .line 213
    .line 214
    :try_start_4
    invoke-interface {v7}, Lpl0;->j()V

    .line 215
    .line 216
    .line 217
    iget-object v2, v2, Ltl0;->i:Lvh7;

    .line 218
    .line 219
    invoke-virtual {v2, v10}, Lvh7;->p0(Lso1;)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v2, v11}, Lvh7;->q0(Lgi3;)V

    .line 223
    .line 224
    .line 225
    invoke-virtual {v2, v12}, Lvh7;->o0(Lpl0;)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v2, v13, v14}, Lvh7;->r0(J)V

    .line 229
    .line 230
    .line 231
    iput-object v5, v2, Lvh7;->j:Ljava/lang/Object;

    .line 232
    .line 233
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 234
    :catchall_1
    move-exception v0

    .line 235
    goto :goto_0

    .line 236
    :catchall_2
    move-exception v0

    .line 237
    move-object/from16 v3, v16

    .line 238
    .line 239
    goto :goto_0

    .line 240
    :catchall_3
    move-exception v0

    .line 241
    move-object v3, v5

    .line 242
    :goto_0
    iput-object v3, v1, Lyi3;->i:Lkv1;

    .line 243
    .line 244
    throw v0

    .line 245
    :pswitch_1
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast v1, Ljava/util/ArrayList;

    .line 248
    .line 249
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast v2, Lxl0;

    .line 252
    .line 253
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v0, Lmh3;

    .line 256
    .line 257
    move-object/from16 v3, p1

    .line 258
    .line 259
    check-cast v3, Lhm3;

    .line 260
    .line 261
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 262
    .line 263
    .line 264
    new-instance v4, Lm;

    .line 265
    .line 266
    invoke-direct {v4, v1, v2, v0, v13}, Lm;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 267
    .line 268
    .line 269
    new-instance v0, Lq21;

    .line 270
    .line 271
    const v1, 0x25b54484

    .line 272
    .line 273
    .line 274
    invoke-direct {v0, v1, v8, v4}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 275
    .line 276
    .line 277
    invoke-static {v3, v15, v0, v12}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 278
    .line 279
    .line 280
    sget-object v0, Los7;->a:Los7;

    .line 281
    .line 282
    return-object v0

    .line 283
    :pswitch_2
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 284
    .line 285
    move-object v3, v1

    .line 286
    check-cast v3, Lvh7;

    .line 287
    .line 288
    iget-object v1, v0, Lbg;->j:Ljava/lang/Object;

    .line 289
    .line 290
    move-object v4, v1

    .line 291
    check-cast v4, Ljava/io/Serializable;

    .line 292
    .line 293
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 294
    .line 295
    move-object v5, v0

    .line 296
    check-cast v5, Lxn1;

    .line 297
    .line 298
    move-object/from16 v0, p1

    .line 299
    .line 300
    check-cast v0, Ljava/lang/Throwable;

    .line 301
    .line 302
    iget-object v0, v3, Lvh7;->i:Ljava/lang/Object;

    .line 303
    .line 304
    check-cast v0, Lri1;

    .line 305
    .line 306
    new-instance v2, Lc70;

    .line 307
    .line 308
    const/4 v7, 0x5

    .line 309
    const/4 v6, 0x0

    .line 310
    invoke-direct/range {v2 .. v7}, Lc70;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lfd1;B)V

    .line 311
    .line 312
    .line 313
    invoke-static {v0, v6, v6, v2, v12}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 314
    .line 315
    .line 316
    sget-object v0, Los7;->a:Los7;

    .line 317
    .line 318
    return-object v0

    .line 319
    :pswitch_3
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 320
    .line 321
    check-cast v1, Ltr2;

    .line 322
    .line 323
    iget-object v3, v0, Lbg;->j:Ljava/lang/Object;

    .line 324
    .line 325
    check-cast v3, Ljg6;

    .line 326
    .line 327
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 328
    .line 329
    check-cast v0, Lzd4;

    .line 330
    .line 331
    move-object/from16 v4, p1

    .line 332
    .line 333
    check-cast v4, Lsr1;

    .line 334
    .line 335
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 336
    .line 337
    .line 338
    new-instance v4, Ldp;

    .line 339
    .line 340
    invoke-direct {v4, v0, v15, v11}, Ldp;-><init>(Ljava/lang/Object;Lfd1;B)V

    .line 341
    .line 342
    .line 343
    iget-object v0, v1, Ltr2;->a:Ljava/util/LinkedHashMap;

    .line 344
    .line 345
    invoke-interface {v0, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 346
    .line 347
    .line 348
    new-instance v0, Lpv;

    .line 349
    .line 350
    invoke-direct {v0, v1, v3, v2}, Lpv;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 351
    .line 352
    .line 353
    return-object v0

    .line 354
    :pswitch_4
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 355
    .line 356
    check-cast v1, Lla5;

    .line 357
    .line 358
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 359
    .line 360
    check-cast v2, Lsu5;

    .line 361
    .line 362
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v0, Lzd4;

    .line 365
    .line 366
    move-object/from16 v3, p1

    .line 367
    .line 368
    check-cast v3, Lka5;

    .line 369
    .line 370
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 371
    .line 372
    .line 373
    iget v4, v2, Lsu5;->a:F

    .line 374
    .line 375
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 376
    .line 377
    .line 378
    move-result-object v5

    .line 379
    check-cast v5, Lhv4;

    .line 380
    .line 381
    iget-wide v5, v5, Lhv4;->a:J

    .line 382
    .line 383
    shr-long/2addr v5, v10

    .line 384
    long-to-int v5, v5

    .line 385
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 386
    .line 387
    .line 388
    move-result v5

    .line 389
    sub-float/2addr v4, v5

    .line 390
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    .line 391
    .line 392
    .line 393
    move-result v4

    .line 394
    iget v2, v2, Lsu5;->b:F

    .line 395
    .line 396
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v0

    .line 400
    check-cast v0, Lhv4;

    .line 401
    .line 402
    iget-wide v5, v0, Lhv4;->a:J

    .line 403
    .line 404
    and-long v5, v5, v16

    .line 405
    .line 406
    long-to-int v0, v5

    .line 407
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 408
    .line 409
    .line 410
    move-result v0

    .line 411
    sub-float/2addr v2, v0

    .line 412
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 413
    .line 414
    .line 415
    move-result v0

    .line 416
    invoke-virtual {v3, v1, v4, v0, v7}, Lka5;->g(Lla5;IIF)V

    .line 417
    .line 418
    .line 419
    sget-object v0, Los7;->a:Los7;

    .line 420
    .line 421
    return-object v0

    .line 422
    :pswitch_5
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 423
    .line 424
    check-cast v1, Lla5;

    .line 425
    .line 426
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 427
    .line 428
    check-cast v2, Lj14;

    .line 429
    .line 430
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 431
    .line 432
    check-cast v0, Lzd4;

    .line 433
    .line 434
    move-object/from16 v3, p1

    .line 435
    .line 436
    check-cast v3, Lka5;

    .line 437
    .line 438
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 439
    .line 440
    .line 441
    iget-object v4, v2, Lj14;->b:Lsu5;

    .line 442
    .line 443
    iget v4, v4, Lsu5;->a:F

    .line 444
    .line 445
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 446
    .line 447
    .line 448
    move-result-object v5

    .line 449
    check-cast v5, Lhv4;

    .line 450
    .line 451
    iget-wide v5, v5, Lhv4;->a:J

    .line 452
    .line 453
    shr-long/2addr v5, v10

    .line 454
    long-to-int v5, v5

    .line 455
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 456
    .line 457
    .line 458
    move-result v5

    .line 459
    sub-float/2addr v4, v5

    .line 460
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    .line 461
    .line 462
    .line 463
    move-result v4

    .line 464
    iget-object v2, v2, Lj14;->b:Lsu5;

    .line 465
    .line 466
    iget v2, v2, Lsu5;->b:F

    .line 467
    .line 468
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 469
    .line 470
    .line 471
    move-result-object v0

    .line 472
    check-cast v0, Lhv4;

    .line 473
    .line 474
    iget-wide v5, v0, Lhv4;->a:J

    .line 475
    .line 476
    and-long v5, v5, v16

    .line 477
    .line 478
    long-to-int v0, v5

    .line 479
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 480
    .line 481
    .line 482
    move-result v0

    .line 483
    sub-float/2addr v2, v0

    .line 484
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 485
    .line 486
    .line 487
    move-result v0

    .line 488
    invoke-virtual {v3, v1, v4, v0, v7}, Lka5;->g(Lla5;IIF)V

    .line 489
    .line 490
    .line 491
    sget-object v0, Los7;->a:Los7;

    .line 492
    .line 493
    return-object v0

    .line 494
    :pswitch_6
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 495
    .line 496
    check-cast v1, Lje2;

    .line 497
    .line 498
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 499
    .line 500
    check-cast v2, Lud2;

    .line 501
    .line 502
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 503
    .line 504
    check-cast v0, Lhh2;

    .line 505
    .line 506
    move-object/from16 v3, p1

    .line 507
    .line 508
    check-cast v3, Lje2;

    .line 509
    .line 510
    invoke-static {v3, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 511
    .line 512
    .line 513
    move-result v1

    .line 514
    if-nez v1, :cond_0

    .line 515
    .line 516
    iget-object v1, v2, Lud2;->d:Lje2;

    .line 517
    .line 518
    invoke-static {v3, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 519
    .line 520
    .line 521
    move-result v1

    .line 522
    if-nez v1, :cond_1

    .line 523
    .line 524
    invoke-interface {v0, v3}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 525
    .line 526
    .line 527
    move-result-object v0

    .line 528
    check-cast v0, Ljava/lang/Boolean;

    .line 529
    .line 530
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 531
    .line 532
    .line 533
    move-result v14

    .line 534
    :cond_0
    invoke-static {v14}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 535
    .line 536
    .line 537
    move-result-object v15

    .line 538
    goto :goto_1

    .line 539
    :cond_1
    const-string v0, "Focus search landed at the root."

    .line 540
    .line 541
    invoke-static {v0}, Lt32;->d(Ljava/lang/String;)V

    .line 542
    .line 543
    .line 544
    :goto_1
    return-object v15

    .line 545
    :pswitch_7
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 546
    .line 547
    check-cast v1, Lt06;

    .line 548
    .line 549
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 550
    .line 551
    check-cast v2, Lxy6;

    .line 552
    .line 553
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 554
    .line 555
    check-cast v0, Lgl1;

    .line 556
    .line 557
    move-object/from16 v3, p1

    .line 558
    .line 559
    check-cast v3, Llv1;

    .line 560
    .line 561
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 562
    .line 563
    .line 564
    if-eqz v2, :cond_2

    .line 565
    .line 566
    invoke-interface {v2}, Lxy6;->getValue()Ljava/lang/Object;

    .line 567
    .line 568
    .line 569
    move-result-object v2

    .line 570
    check-cast v2, Ltx1;

    .line 571
    .line 572
    invoke-virtual {v0}, Lgl1;->a()F

    .line 573
    .line 574
    .line 575
    move-result v0

    .line 576
    invoke-static {v3, v1, v2, v0}, Lcj;->H(Llv1;Lkn6;Ltx1;F)V

    .line 577
    .line 578
    .line 579
    sget-object v15, Los7;->a:Los7;

    .line 580
    .line 581
    goto :goto_2

    .line 582
    :cond_2
    const-string v0, "Required value was null."

    .line 583
    .line 584
    invoke-static {v0}, Lt32;->g(Ljava/lang/String;)V

    .line 585
    .line 586
    .line 587
    :goto_2
    return-object v15

    .line 588
    :pswitch_8
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 589
    .line 590
    check-cast v1, Lri1;

    .line 591
    .line 592
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 593
    .line 594
    check-cast v2, Lc75;

    .line 595
    .line 596
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 597
    .line 598
    check-cast v0, Lug;

    .line 599
    .line 600
    move-object/from16 v3, p1

    .line 601
    .line 602
    check-cast v3, Lgl1;

    .line 603
    .line 604
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 605
    .line 606
    .line 607
    invoke-virtual {v2}, Lc75;->h()I

    .line 608
    .line 609
    .line 610
    move-result v2

    .line 611
    int-to-float v2, v2

    .line 612
    invoke-virtual {v3, v2}, Lgl1;->c(F)V

    .line 613
    .line 614
    .line 615
    new-instance v2, Ls70;

    .line 616
    .line 617
    invoke-direct {v2, v0, v15, v6}, Ls70;-><init>(Lug;Lfd1;B)V

    .line 618
    .line 619
    .line 620
    invoke-static {v1, v15, v15, v2, v12}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 621
    .line 622
    .line 623
    sget-object v0, Los7;->a:Los7;

    .line 624
    .line 625
    return-object v0

    .line 626
    :pswitch_9
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 627
    .line 628
    check-cast v1, Lbn7;

    .line 629
    .line 630
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 631
    .line 632
    check-cast v2, Lg32;

    .line 633
    .line 634
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 635
    .line 636
    check-cast v0, Lz42;

    .line 637
    .line 638
    iget-object v0, v0, Lz42;->a:Lw22;

    .line 639
    .line 640
    move-object/from16 v3, p1

    .line 641
    .line 642
    check-cast v3, Lu22;

    .line 643
    .line 644
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 645
    .line 646
    .line 647
    move-result v3

    .line 648
    if-eqz v3, :cond_6

    .line 649
    .line 650
    if-eq v3, v8, :cond_5

    .line 651
    .line 652
    if-ne v3, v11, :cond_4

    .line 653
    .line 654
    iget-object v0, v0, Lw22;->d:Lbe6;

    .line 655
    .line 656
    if-eqz v0, :cond_3

    .line 657
    .line 658
    iget-wide v0, v0, Lbe6;->b:J

    .line 659
    .line 660
    goto :goto_3

    .line 661
    :cond_3
    invoke-static {v5, v5}, Lsi6;->m(FF)J

    .line 662
    .line 663
    .line 664
    move-result-wide v0

    .line 665
    :goto_3
    new-instance v15, Lbn7;

    .line 666
    .line 667
    invoke-direct {v15, v0, v1}, Lbn7;-><init>(J)V

    .line 668
    .line 669
    .line 670
    goto :goto_4

    .line 671
    :cond_4
    invoke-static {}, Lfb1;->a()V

    .line 672
    .line 673
    .line 674
    goto :goto_6

    .line 675
    :cond_5
    move-object v15, v1

    .line 676
    goto :goto_4

    .line 677
    :cond_6
    iget-object v1, v2, Lg32;->a:Lw22;

    .line 678
    .line 679
    iget-object v1, v1, Lw22;->d:Lbe6;

    .line 680
    .line 681
    if-eqz v1, :cond_7

    .line 682
    .line 683
    iget-wide v0, v1, Lbe6;->b:J

    .line 684
    .line 685
    new-instance v15, Lbn7;

    .line 686
    .line 687
    invoke-direct {v15, v0, v1}, Lbn7;-><init>(J)V

    .line 688
    .line 689
    .line 690
    goto :goto_4

    .line 691
    :cond_7
    iget-object v0, v0, Lw22;->d:Lbe6;

    .line 692
    .line 693
    if-eqz v0, :cond_8

    .line 694
    .line 695
    iget-wide v0, v0, Lbe6;->b:J

    .line 696
    .line 697
    new-instance v15, Lbn7;

    .line 698
    .line 699
    invoke-direct {v15, v0, v1}, Lbn7;-><init>(J)V

    .line 700
    .line 701
    .line 702
    :cond_8
    :goto_4
    if-eqz v15, :cond_9

    .line 703
    .line 704
    iget-wide v0, v15, Lbn7;->a:J

    .line 705
    .line 706
    goto :goto_5

    .line 707
    :cond_9
    invoke-static {v5, v5}, Lsi6;->m(FF)J

    .line 708
    .line 709
    .line 710
    move-result-wide v0

    .line 711
    :goto_5
    new-instance v15, Lbn7;

    .line 712
    .line 713
    invoke-direct {v15, v0, v1}, Lbn7;-><init>(J)V

    .line 714
    .line 715
    .line 716
    :goto_6
    return-object v15

    .line 717
    :pswitch_a
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 718
    .line 719
    check-cast v1, Lpm1;

    .line 720
    .line 721
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 722
    .line 723
    check-cast v2, Lsu1;

    .line 724
    .line 725
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 726
    .line 727
    check-cast v0, Liz4;

    .line 728
    .line 729
    move-object/from16 v5, p1

    .line 730
    .line 731
    check-cast v5, Lpt1;

    .line 732
    .line 733
    iget-wide v5, v5, Lpt1;->a:J

    .line 734
    .line 735
    iget-boolean v2, v2, Lsu1;->W:Z

    .line 736
    .line 737
    if-eqz v2, :cond_a

    .line 738
    .line 739
    invoke-static {v4, v5, v6}, Lhv4;->h(FJ)J

    .line 740
    .line 741
    .line 742
    move-result-wide v2

    .line 743
    goto :goto_7

    .line 744
    :cond_a
    invoke-static {v3, v5, v6}, Lhv4;->h(FJ)J

    .line 745
    .line 746
    .line 747
    move-result-wide v2

    .line 748
    :goto_7
    sget-object v4, Lqu1;->a:Lpu1;

    .line 749
    .line 750
    sget-object v4, Liz4;->h:Liz4;

    .line 751
    .line 752
    if-ne v0, v4, :cond_b

    .line 753
    .line 754
    and-long v2, v2, v16

    .line 755
    .line 756
    :goto_8
    long-to-int v0, v2

    .line 757
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 758
    .line 759
    .line 760
    move-result v0

    .line 761
    goto :goto_9

    .line 762
    :cond_b
    shr-long/2addr v2, v10

    .line 763
    goto :goto_8

    .line 764
    :goto_9
    iget-byte v2, v1, Lpm1;->a:B

    .line 765
    .line 766
    packed-switch v2, :pswitch_data_1

    .line 767
    .line 768
    .line 769
    iget-object v1, v1, Lpm1;->b:Ltu1;

    .line 770
    .line 771
    check-cast v1, Llu6;

    .line 772
    .line 773
    invoke-virtual {v1, v0, v15}, Llu6;->c(FLhh2;)V

    .line 774
    .line 775
    .line 776
    goto :goto_a

    .line 777
    :pswitch_b
    iget-object v1, v1, Lpm1;->b:Ltu1;

    .line 778
    .line 779
    check-cast v1, Lqm1;

    .line 780
    .line 781
    iget-object v1, v1, Lqm1;->a:Lgf1;

    .line 782
    .line 783
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 784
    .line 785
    .line 786
    move-result-object v0

    .line 787
    invoke-virtual {v1, v0}, Lgf1;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 788
    .line 789
    .line 790
    :goto_a
    sget-object v0, Los7;->a:Los7;

    .line 791
    .line 792
    return-object v0

    .line 793
    :pswitch_c
    sget-object v1, Los7;->a:Los7;

    .line 794
    .line 795
    sget-object v2, Liz4;->i:Liz4;

    .line 796
    .line 797
    iget-object v5, v0, Lbg;->i:Ljava/lang/Object;

    .line 798
    .line 799
    check-cast v5, Lh14;

    .line 800
    .line 801
    iget-object v6, v0, Lbg;->j:Ljava/lang/Object;

    .line 802
    .line 803
    check-cast v6, Lmu1;

    .line 804
    .line 805
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 806
    .line 807
    check-cast v0, Lla5;

    .line 808
    .line 809
    move-object/from16 v9, p1

    .line 810
    .line 811
    check-cast v9, Lka5;

    .line 812
    .line 813
    invoke-interface {v5}, Lcb3;->F()Z

    .line 814
    .line 815
    .line 816
    move-result v10

    .line 817
    iget-object v11, v6, Lmu1;->v:Lu9;

    .line 818
    .line 819
    if-eqz v10, :cond_c

    .line 820
    .line 821
    invoke-virtual {v11}, Lu9;->e()Lom1;

    .line 822
    .line 823
    .line 824
    move-result-object v10

    .line 825
    iget-object v11, v6, Lmu1;->v:Lu9;

    .line 826
    .line 827
    iget-object v11, v11, Lu9;->h:Ljava/lang/Object;

    .line 828
    .line 829
    check-cast v11, Lbp1;

    .line 830
    .line 831
    invoke-virtual {v11}, Lbp1;->getValue()Ljava/lang/Object;

    .line 832
    .line 833
    .line 834
    move-result-object v11

    .line 835
    invoke-virtual {v10, v11}, Lom1;->f(Ljava/lang/Object;)F

    .line 836
    .line 837
    .line 838
    move-result v10

    .line 839
    goto :goto_b

    .line 840
    :cond_c
    iget-object v10, v11, Lu9;->i:Ljava/lang/Object;

    .line 841
    .line 842
    check-cast v10, Lb75;

    .line 843
    .line 844
    invoke-virtual {v10}, Lb75;->h()F

    .line 845
    .line 846
    .line 847
    move-result v10

    .line 848
    :goto_b
    invoke-interface {v5}, Lcb3;->F()Z

    .line 849
    .line 850
    .line 851
    move-result v5

    .line 852
    invoke-static {v10}, Ljava/lang/Float;->isNaN(F)Z

    .line 853
    .line 854
    .line 855
    move-result v11

    .line 856
    if-nez v11, :cond_10

    .line 857
    .line 858
    invoke-static {v6}, Lkk;->g0(Lio1;)Lwi3;

    .line 859
    .line 860
    .line 861
    move-result-object v5

    .line 862
    iget-object v5, v5, Lwi3;->G:Lgi3;

    .line 863
    .line 864
    sget-object v11, Lgi3;->i:Lgi3;

    .line 865
    .line 866
    if-ne v5, v11, :cond_d

    .line 867
    .line 868
    iget-object v5, v6, Lmu1;->x:Liz4;

    .line 869
    .line 870
    if-ne v5, v2, :cond_d

    .line 871
    .line 872
    move v3, v4

    .line 873
    :cond_d
    iget-object v4, v6, Lmu1;->x:Liz4;

    .line 874
    .line 875
    if-ne v4, v2, :cond_e

    .line 876
    .line 877
    mul-float/2addr v3, v10

    .line 878
    goto :goto_c

    .line 879
    :cond_e
    move v3, v7

    .line 880
    :goto_c
    sget-object v2, Liz4;->h:Liz4;

    .line 881
    .line 882
    if-ne v4, v2, :cond_f

    .line 883
    .line 884
    move v7, v10

    .line 885
    :cond_f
    iput-boolean v8, v9, Lka5;->h:Z

    .line 886
    .line 887
    invoke-static {v3}, Lw04;->w(F)I

    .line 888
    .line 889
    .line 890
    move-result v2

    .line 891
    invoke-static {v7}, Lw04;->w(F)I

    .line 892
    .line 893
    .line 894
    move-result v3

    .line 895
    invoke-static {v9, v0, v2, v3}, Lka5;->h(Lka5;Lla5;II)V

    .line 896
    .line 897
    .line 898
    iput-boolean v14, v9, Lka5;->h:Z

    .line 899
    .line 900
    return-object v1

    .line 901
    :cond_10
    new-instance v0, Lv9;

    .line 902
    .line 903
    iget-boolean v1, v6, Lmu1;->y:Z

    .line 904
    .line 905
    iget-object v2, v6, Lmu1;->v:Lu9;

    .line 906
    .line 907
    invoke-virtual {v2}, Lu9;->e()Lom1;

    .line 908
    .line 909
    .line 910
    move-result-object v2

    .line 911
    iget-object v3, v6, Lmu1;->v:Lu9;

    .line 912
    .line 913
    iget-object v3, v3, Lu9;->h:Ljava/lang/Object;

    .line 914
    .line 915
    check-cast v3, Lbp1;

    .line 916
    .line 917
    invoke-virtual {v3}, Lbp1;->getValue()Ljava/lang/Object;

    .line 918
    .line 919
    .line 920
    move-result-object v3

    .line 921
    invoke-direct {v0, v5, v1, v2, v3}, Lv9;-><init>(ZZLom1;Ljava/lang/Object;)V

    .line 922
    .line 923
    .line 924
    throw v0

    .line 925
    :pswitch_d
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 926
    .line 927
    check-cast v1, Lbt1;

    .line 928
    .line 929
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 930
    .line 931
    check-cast v2, Lht1;

    .line 932
    .line 933
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 934
    .line 935
    check-cast v0, Lwu5;

    .line 936
    .line 937
    move-object/from16 v3, p1

    .line 938
    .line 939
    check-cast v3, Lht1;

    .line 940
    .line 941
    iget-boolean v4, v3, Lga4;->u:Z

    .line 942
    .line 943
    if-nez v4, :cond_11

    .line 944
    .line 945
    sget-object v0, Lwn7;->i:Lwn7;

    .line 946
    .line 947
    goto :goto_e

    .line 948
    :cond_11
    iget-object v4, v3, Lht1;->x:Lit1;

    .line 949
    .line 950
    if-eqz v4, :cond_12

    .line 951
    .line 952
    const-string v4, "DragAndDropTarget self reference must be null at the start of a drag and drop session"

    .line 953
    .line 954
    invoke-static {v4}, Lm73;->b(Ljava/lang/String;)V

    .line 955
    .line 956
    .line 957
    :cond_12
    iget-object v4, v3, Lht1;->v:Lhh2;

    .line 958
    .line 959
    if-eqz v4, :cond_13

    .line 960
    .line 961
    invoke-interface {v4, v1}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 962
    .line 963
    .line 964
    move-result-object v1

    .line 965
    move-object v15, v1

    .line 966
    check-cast v15, Lit1;

    .line 967
    .line 968
    :cond_13
    iput-object v15, v3, Lht1;->x:Lit1;

    .line 969
    .line 970
    if-eqz v15, :cond_14

    .line 971
    .line 972
    move v1, v8

    .line 973
    goto :goto_d

    .line 974
    :cond_14
    move v1, v14

    .line 975
    :goto_d
    if-eqz v1, :cond_15

    .line 976
    .line 977
    invoke-static {v2}, Lkk;->h0(Lio1;)Lbb;

    .line 978
    .line 979
    .line 980
    move-result-object v2

    .line 981
    invoke-virtual {v2}, Lbb;->getDragAndDropManager()Lgt1;

    .line 982
    .line 983
    .line 984
    move-result-object v2

    .line 985
    check-cast v2, Lhc;

    .line 986
    .line 987
    iget-object v2, v2, Lhc;->b:Ljx;

    .line 988
    .line 989
    invoke-virtual {v2, v3}, Ljx;->add(Ljava/lang/Object;)Z

    .line 990
    .line 991
    .line 992
    :cond_15
    iget-boolean v2, v0, Lwu5;->h:Z

    .line 993
    .line 994
    if-nez v2, :cond_16

    .line 995
    .line 996
    if-eqz v1, :cond_17

    .line 997
    .line 998
    :cond_16
    move v14, v8

    .line 999
    :cond_17
    iput-boolean v14, v0, Lwu5;->h:Z

    .line 1000
    .line 1001
    sget-object v0, Lwn7;->h:Lwn7;

    .line 1002
    .line 1003
    :goto_e
    return-object v0

    .line 1004
    :pswitch_e
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1005
    .line 1006
    check-cast v1, Landroid/content/Context;

    .line 1007
    .line 1008
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1009
    .line 1010
    check-cast v2, Lco3;

    .line 1011
    .line 1012
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1013
    .line 1014
    move-object/from16 v28, v0

    .line 1015
    .line 1016
    check-cast v28, Lzd4;

    .line 1017
    .line 1018
    move-object/from16 v0, p1

    .line 1019
    .line 1020
    check-cast v0, Lsr1;

    .line 1021
    .line 1022
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1023
    .line 1024
    .line 1025
    const-string v0, "sensor"

    .line 1026
    .line 1027
    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v0

    .line 1031
    instance-of v1, v0, Landroid/hardware/SensorManager;

    .line 1032
    .line 1033
    if-eqz v1, :cond_18

    .line 1034
    .line 1035
    check-cast v0, Landroid/hardware/SensorManager;

    .line 1036
    .line 1037
    goto :goto_f

    .line 1038
    :cond_18
    move-object v0, v15

    .line 1039
    :goto_f
    if-eqz v0, :cond_19

    .line 1040
    .line 1041
    const/16 v1, 0xf

    .line 1042
    .line 1043
    invoke-virtual {v0, v1}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    .line 1044
    .line 1045
    .line 1046
    move-result-object v15

    .line 1047
    if-nez v15, :cond_19

    .line 1048
    .line 1049
    invoke-virtual {v0, v13}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v15

    .line 1053
    :cond_19
    if-eqz v0, :cond_1a

    .line 1054
    .line 1055
    if-eqz v15, :cond_1a

    .line 1056
    .line 1057
    const/16 v1, 0x9

    .line 1058
    .line 1059
    new-array v1, v1, [F

    .line 1060
    .line 1061
    new-array v3, v12, [F

    .line 1062
    .line 1063
    new-instance v20, Lxu5;

    .line 1064
    .line 1065
    invoke-direct/range {v20 .. v20}, Ljava/lang/Object;-><init>()V

    .line 1066
    .line 1067
    .line 1068
    new-instance v21, Lxu5;

    .line 1069
    .line 1070
    invoke-direct/range {v21 .. v21}, Ljava/lang/Object;-><init>()V

    .line 1071
    .line 1072
    .line 1073
    new-instance v22, Lxu5;

    .line 1074
    .line 1075
    invoke-direct/range {v22 .. v22}, Ljava/lang/Object;-><init>()V

    .line 1076
    .line 1077
    .line 1078
    new-instance v23, Lxu5;

    .line 1079
    .line 1080
    invoke-direct/range {v23 .. v23}, Ljava/lang/Object;-><init>()V

    .line 1081
    .line 1082
    .line 1083
    new-instance v24, Lxu5;

    .line 1084
    .line 1085
    invoke-direct/range {v24 .. v24}, Ljava/lang/Object;-><init>()V

    .line 1086
    .line 1087
    .line 1088
    new-instance v25, Lxu5;

    .line 1089
    .line 1090
    invoke-direct/range {v25 .. v25}, Ljava/lang/Object;-><init>()V

    .line 1091
    .line 1092
    .line 1093
    new-instance v26, Lxu5;

    .line 1094
    .line 1095
    invoke-direct/range {v26 .. v26}, Ljava/lang/Object;-><init>()V

    .line 1096
    .line 1097
    .line 1098
    new-instance v27, Lxu5;

    .line 1099
    .line 1100
    invoke-direct/range {v27 .. v27}, Ljava/lang/Object;-><init>()V

    .line 1101
    .line 1102
    .line 1103
    new-instance v19, Lwu5;

    .line 1104
    .line 1105
    invoke-direct/range {v19 .. v19}, Ljava/lang/Object;-><init>()V

    .line 1106
    .line 1107
    .line 1108
    new-instance v4, Lwu5;

    .line 1109
    .line 1110
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 1111
    .line 1112
    .line 1113
    new-instance v16, Lkp1;

    .line 1114
    .line 1115
    move-object/from16 v17, v1

    .line 1116
    .line 1117
    move-object/from16 v18, v3

    .line 1118
    .line 1119
    invoke-direct/range {v16 .. v28}, Lkp1;-><init>([F[FLwu5;Lxu5;Lxu5;Lxu5;Lxu5;Lxu5;Lxu5;Lxu5;Lxu5;Lzd4;)V

    .line 1120
    .line 1121
    .line 1122
    new-instance v18, Lip1;

    .line 1123
    .line 1124
    move-object/from16 v17, v4

    .line 1125
    .line 1126
    move-object/from16 v20, v15

    .line 1127
    .line 1128
    move-object/from16 v21, v19

    .line 1129
    .line 1130
    move-object/from16 v19, v16

    .line 1131
    .line 1132
    move-object/from16 v16, v18

    .line 1133
    .line 1134
    move-object/from16 v18, v0

    .line 1135
    .line 1136
    invoke-direct/range {v16 .. v21}, Lip1;-><init>(Lwu5;Landroid/hardware/SensorManager;Lkp1;Landroid/hardware/Sensor;Lwu5;)V

    .line 1137
    .line 1138
    .line 1139
    move-object/from16 v0, v16

    .line 1140
    .line 1141
    move-object/from16 v16, v19

    .line 1142
    .line 1143
    move-object/from16 v19, v21

    .line 1144
    .line 1145
    invoke-interface {v2}, Lco3;->g()Lfo3;

    .line 1146
    .line 1147
    .line 1148
    move-result-object v1

    .line 1149
    invoke-virtual {v1, v0}, Lfo3;->a(Lbo3;)V

    .line 1150
    .line 1151
    .line 1152
    move-object/from16 v21, v16

    .line 1153
    .line 1154
    new-instance v16, Llp1;

    .line 1155
    .line 1156
    move-object/from16 v20, v18

    .line 1157
    .line 1158
    move-object/from16 v22, v19

    .line 1159
    .line 1160
    move-object/from16 v18, v0

    .line 1161
    .line 1162
    move-object/from16 v19, v17

    .line 1163
    .line 1164
    move-object/from16 v17, v1

    .line 1165
    .line 1166
    invoke-direct/range {v16 .. v22}, Llp1;-><init>(Lfo3;Lip1;Lwu5;Landroid/hardware/SensorManager;Lkp1;Lwu5;)V

    .line 1167
    .line 1168
    .line 1169
    goto :goto_10

    .line 1170
    :cond_1a
    new-instance v0, Ltd;

    .line 1171
    .line 1172
    invoke-direct {v0, v6}, Ltd;-><init>(B)V

    .line 1173
    .line 1174
    .line 1175
    move-object/from16 v16, v0

    .line 1176
    .line 1177
    :goto_10
    return-object v16

    .line 1178
    :pswitch_f
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1179
    .line 1180
    check-cast v1, Lz97;

    .line 1181
    .line 1182
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1183
    .line 1184
    check-cast v2, Landroid/content/Context;

    .line 1185
    .line 1186
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1187
    .line 1188
    check-cast v0, Lla7;

    .line 1189
    .line 1190
    move-object/from16 v3, p1

    .line 1191
    .line 1192
    check-cast v3, Lzc1;

    .line 1193
    .line 1194
    iget-object v1, v1, Lz97;->a:Ljava/util/List;

    .line 1195
    .line 1196
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 1197
    .line 1198
    .line 1199
    move-result v4

    .line 1200
    move v5, v14

    .line 1201
    :goto_11
    if-ge v5, v4, :cond_22

    .line 1202
    .line 1203
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1204
    .line 1205
    .line 1206
    move-result-object v6

    .line 1207
    check-cast v6, Ly97;

    .line 1208
    .line 1209
    instance-of v7, v6, Lga7;

    .line 1210
    .line 1211
    const/16 v9, 0x13

    .line 1212
    .line 1213
    const/4 v10, 0x6

    .line 1214
    if-eqz v7, :cond_1c

    .line 1215
    .line 1216
    new-instance v7, Lv;

    .line 1217
    .line 1218
    check-cast v6, Lga7;

    .line 1219
    .line 1220
    invoke-direct {v7, v6, v9}, Lv;-><init>(Ljava/lang/Object;B)V

    .line 1221
    .line 1222
    .line 1223
    iget v9, v6, Lga7;->c:I

    .line 1224
    .line 1225
    if-nez v9, :cond_1b

    .line 1226
    .line 1227
    move-object v11, v15

    .line 1228
    goto :goto_12

    .line 1229
    :cond_1b
    new-instance v9, Lrn1;

    .line 1230
    .line 1231
    invoke-direct {v9, v6, v14}, Lrn1;-><init>(Ljava/lang/Object;B)V

    .line 1232
    .line 1233
    .line 1234
    new-instance v11, Lq21;

    .line 1235
    .line 1236
    const v12, -0x731428a5

    .line 1237
    .line 1238
    .line 1239
    invoke-direct {v11, v12, v8, v9}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 1240
    .line 1241
    .line 1242
    :goto_12
    new-instance v9, Lqn1;

    .line 1243
    .line 1244
    invoke-direct {v9, v6, v0, v8}, Lqn1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1245
    .line 1246
    .line 1247
    invoke-static {v3, v7, v11, v9, v10}, Lzc1;->b(Lzc1;Llh2;Lq21;Lwg2;I)V

    .line 1248
    .line 1249
    .line 1250
    goto :goto_15

    .line 1251
    :cond_1c
    instance-of v7, v6, Lma7;

    .line 1252
    .line 1253
    if-eqz v7, :cond_20

    .line 1254
    .line 1255
    check-cast v6, Lma7;

    .line 1256
    .line 1257
    if-eqz v2, :cond_21

    .line 1258
    .line 1259
    iget v7, v6, Lma7;->c:I

    .line 1260
    .line 1261
    iget-object v11, v6, Lma7;->b:Landroid/view/textclassifier/TextClassification;

    .line 1262
    .line 1263
    iget-object v6, v6, Lma7;->d:Landroid/graphics/drawable/Drawable;

    .line 1264
    .line 1265
    if-gez v7, :cond_1e

    .line 1266
    .line 1267
    new-instance v7, Ll46;

    .line 1268
    .line 1269
    invoke-direct {v7, v11, v9}, Ll46;-><init>(Ljava/lang/Object;B)V

    .line 1270
    .line 1271
    .line 1272
    if-eqz v6, :cond_1d

    .line 1273
    .line 1274
    new-instance v9, Lfa7;

    .line 1275
    .line 1276
    invoke-direct {v9, v6, v14}, Lfa7;-><init>(Landroid/graphics/drawable/Drawable;B)V

    .line 1277
    .line 1278
    .line 1279
    new-instance v6, Lq21;

    .line 1280
    .line 1281
    const v12, -0x42f30a7b

    .line 1282
    .line 1283
    .line 1284
    invoke-direct {v6, v12, v8, v9}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 1285
    .line 1286
    .line 1287
    goto :goto_13

    .line 1288
    :cond_1d
    move-object v6, v15

    .line 1289
    :goto_13
    new-instance v9, Lir4;

    .line 1290
    .line 1291
    const/16 v12, 0x19

    .line 1292
    .line 1293
    invoke-direct {v9, v2, v11, v12}, Lir4;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1294
    .line 1295
    .line 1296
    invoke-static {v3, v7, v6, v9, v10}, Lzc1;->b(Lzc1;Llh2;Lq21;Lwg2;I)V

    .line 1297
    .line 1298
    .line 1299
    goto :goto_15

    .line 1300
    :cond_1e
    invoke-virtual {v11}, Landroid/view/textclassifier/TextClassification;->getActions()Ljava/util/List;

    .line 1301
    .line 1302
    .line 1303
    move-result-object v9

    .line 1304
    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1305
    .line 1306
    .line 1307
    move-result-object v7

    .line 1308
    check-cast v7, Landroid/app/RemoteAction;

    .line 1309
    .line 1310
    new-instance v9, Ll46;

    .line 1311
    .line 1312
    const/16 v11, 0x14

    .line 1313
    .line 1314
    invoke-direct {v9, v7, v11}, Ll46;-><init>(Ljava/lang/Object;B)V

    .line 1315
    .line 1316
    .line 1317
    if-eqz v6, :cond_1f

    .line 1318
    .line 1319
    new-instance v11, Lfa7;

    .line 1320
    .line 1321
    invoke-direct {v11, v6, v8}, Lfa7;-><init>(Landroid/graphics/drawable/Drawable;B)V

    .line 1322
    .line 1323
    .line 1324
    new-instance v6, Lq21;

    .line 1325
    .line 1326
    const v12, 0x41eeb29c

    .line 1327
    .line 1328
    .line 1329
    invoke-direct {v6, v12, v8, v11}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 1330
    .line 1331
    .line 1332
    goto :goto_14

    .line 1333
    :cond_1f
    move-object v6, v15

    .line 1334
    :goto_14
    new-instance v11, Llc6;

    .line 1335
    .line 1336
    const/16 v12, 0xd

    .line 1337
    .line 1338
    invoke-direct {v11, v7, v12}, Llc6;-><init>(Ljava/lang/Object;B)V

    .line 1339
    .line 1340
    .line 1341
    invoke-static {v3, v9, v6, v11, v10}, Lzc1;->b(Lzc1;Llh2;Lq21;Lwg2;I)V

    .line 1342
    .line 1343
    .line 1344
    goto :goto_15

    .line 1345
    :cond_20
    instance-of v6, v6, Lka7;

    .line 1346
    .line 1347
    if-eqz v6, :cond_21

    .line 1348
    .line 1349
    iget-object v6, v3, Lzc1;->a:Lwv6;

    .line 1350
    .line 1351
    sget-object v7, Lw04;->m:Lq21;

    .line 1352
    .line 1353
    invoke-virtual {v6, v7}, Lwv6;->add(Ljava/lang/Object;)Z

    .line 1354
    .line 1355
    .line 1356
    :cond_21
    :goto_15
    add-int/lit8 v5, v5, 0x1

    .line 1357
    .line 1358
    goto/16 :goto_11

    .line 1359
    .line 1360
    :cond_22
    sget-object v0, Los7;->a:Los7;

    .line 1361
    .line 1362
    return-object v0

    .line 1363
    :pswitch_10
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1364
    .line 1365
    check-cast v1, Lxu5;

    .line 1366
    .line 1367
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1368
    .line 1369
    check-cast v2, Lwf6;

    .line 1370
    .line 1371
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1372
    .line 1373
    check-cast v0, Lxu5;

    .line 1374
    .line 1375
    move-object/from16 v3, p1

    .line 1376
    .line 1377
    check-cast v3, Lzi;

    .line 1378
    .line 1379
    iget-object v4, v3, Lzi;->e:Lf75;

    .line 1380
    .line 1381
    invoke-virtual {v4}, Lf75;->getValue()Ljava/lang/Object;

    .line 1382
    .line 1383
    .line 1384
    move-result-object v4

    .line 1385
    check-cast v4, Ljava/lang/Number;

    .line 1386
    .line 1387
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 1388
    .line 1389
    .line 1390
    move-result v4

    .line 1391
    iget v6, v1, Lxu5;->h:F

    .line 1392
    .line 1393
    sub-float/2addr v4, v6

    .line 1394
    invoke-interface {v2, v4}, Lwf6;->a(F)F

    .line 1395
    .line 1396
    .line 1397
    move-result v2

    .line 1398
    iget-object v6, v3, Lzi;->e:Lf75;

    .line 1399
    .line 1400
    invoke-virtual {v6}, Lf75;->getValue()Ljava/lang/Object;

    .line 1401
    .line 1402
    .line 1403
    move-result-object v6

    .line 1404
    check-cast v6, Ljava/lang/Number;

    .line 1405
    .line 1406
    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    .line 1407
    .line 1408
    .line 1409
    move-result v6

    .line 1410
    iput v6, v1, Lxu5;->h:F

    .line 1411
    .line 1412
    invoke-virtual {v3}, Lzi;->b()Ljava/lang/Object;

    .line 1413
    .line 1414
    .line 1415
    move-result-object v1

    .line 1416
    check-cast v1, Ljava/lang/Number;

    .line 1417
    .line 1418
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 1419
    .line 1420
    .line 1421
    move-result v1

    .line 1422
    iput v1, v0, Lxu5;->h:F

    .line 1423
    .line 1424
    sub-float/2addr v4, v2

    .line 1425
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 1426
    .line 1427
    .line 1428
    move-result v0

    .line 1429
    cmpl-float v0, v0, v5

    .line 1430
    .line 1431
    if-lez v0, :cond_23

    .line 1432
    .line 1433
    invoke-virtual {v3}, Lzi;->a()V

    .line 1434
    .line 1435
    .line 1436
    :cond_23
    sget-object v0, Los7;->a:Los7;

    .line 1437
    .line 1438
    return-object v0

    .line 1439
    :pswitch_11
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1440
    .line 1441
    check-cast v1, Lng1;

    .line 1442
    .line 1443
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1444
    .line 1445
    check-cast v2, Lzd4;

    .line 1446
    .line 1447
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1448
    .line 1449
    check-cast v0, Lzd4;

    .line 1450
    .line 1451
    move-object/from16 v21, p1

    .line 1452
    .line 1453
    check-cast v21, Lbi1;

    .line 1454
    .line 1455
    invoke-virtual/range {v21 .. v21}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1456
    .line 1457
    .line 1458
    invoke-interface {v2}, Lxy6;->getValue()Ljava/lang/Object;

    .line 1459
    .line 1460
    .line 1461
    move-result-object v3

    .line 1462
    check-cast v3, Lrh1;

    .line 1463
    .line 1464
    iget-object v9, v3, Lrh1;->a:Lqh1;

    .line 1465
    .line 1466
    const/16 v22, 0x0

    .line 1467
    .line 1468
    const/16 v23, 0x17ff

    .line 1469
    .line 1470
    const/4 v10, 0x0

    .line 1471
    const/4 v11, 0x0

    .line 1472
    const/4 v12, 0x0

    .line 1473
    const/4 v13, 0x0

    .line 1474
    const/4 v14, 0x0

    .line 1475
    const/4 v15, 0x0

    .line 1476
    const/16 v16, 0x0

    .line 1477
    .line 1478
    const/16 v17, 0x0

    .line 1479
    .line 1480
    const/16 v18, 0x0

    .line 1481
    .line 1482
    const/16 v19, 0x0

    .line 1483
    .line 1484
    const/16 v20, 0x0

    .line 1485
    .line 1486
    invoke-static/range {v9 .. v23}, Lqh1;->a(Lqh1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Lbi1;ZI)Lqh1;

    .line 1487
    .line 1488
    .line 1489
    move-result-object v3

    .line 1490
    iget-object v1, v1, Lng1;->l:Ldt5;

    .line 1491
    .line 1492
    iget-object v1, v1, Ldt5;->h:Laz6;

    .line 1493
    .line 1494
    invoke-virtual {v1}, Laz6;->getValue()Ljava/lang/Object;

    .line 1495
    .line 1496
    .line 1497
    move-result-object v1

    .line 1498
    check-cast v1, Lvg1;

    .line 1499
    .line 1500
    iget-object v1, v1, Lvg1;->a:Ljava/util/List;

    .line 1501
    .line 1502
    if-eqz v1, :cond_24

    .line 1503
    .line 1504
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 1505
    .line 1506
    .line 1507
    move-result v4

    .line 1508
    if-nez v4, :cond_28

    .line 1509
    .line 1510
    :cond_24
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1511
    .line 1512
    .line 1513
    move-result-object v4

    .line 1514
    :cond_25
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1515
    .line 1516
    .line 1517
    move-result v5

    .line 1518
    if-eqz v5, :cond_28

    .line 1519
    .line 1520
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1521
    .line 1522
    .line 1523
    move-result-object v5

    .line 1524
    check-cast v5, Lqh1;

    .line 1525
    .line 1526
    invoke-interface {v2}, Lxy6;->getValue()Ljava/lang/Object;

    .line 1527
    .line 1528
    .line 1529
    move-result-object v6

    .line 1530
    check-cast v6, Lrh1;

    .line 1531
    .line 1532
    iget-object v6, v6, Lrh1;->a:Lqh1;

    .line 1533
    .line 1534
    invoke-static {v5, v6}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1535
    .line 1536
    .line 1537
    move-result v5

    .line 1538
    if-eqz v5, :cond_25

    .line 1539
    .line 1540
    new-instance v4, Lrh1;

    .line 1541
    .line 1542
    invoke-interface {v2}, Lxy6;->getValue()Ljava/lang/Object;

    .line 1543
    .line 1544
    .line 1545
    move-result-object v5

    .line 1546
    check-cast v5, Lrh1;

    .line 1547
    .line 1548
    iget-object v5, v5, Lrh1;->b:Ljava/lang/String;

    .line 1549
    .line 1550
    invoke-interface {v2}, Lxy6;->getValue()Ljava/lang/Object;

    .line 1551
    .line 1552
    .line 1553
    move-result-object v6

    .line 1554
    check-cast v6, Lrh1;

    .line 1555
    .line 1556
    iget-object v6, v6, Lrh1;->c:Lse1;

    .line 1557
    .line 1558
    invoke-direct {v4, v3, v5, v6}, Lrh1;-><init>(Lqh1;Ljava/lang/String;Lse1;)V

    .line 1559
    .line 1560
    .line 1561
    invoke-interface {v2, v4}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 1562
    .line 1563
    .line 1564
    sget-object v2, Lsh1;->a:Lsh1;

    .line 1565
    .line 1566
    new-instance v2, Ljava/util/ArrayList;

    .line 1567
    .line 1568
    const/16 v4, 0xa

    .line 1569
    .line 1570
    invoke-static {v1, v4}, Lyx0;->F0(Ljava/lang/Iterable;I)I

    .line 1571
    .line 1572
    .line 1573
    move-result v4

    .line 1574
    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 1575
    .line 1576
    .line 1577
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1578
    .line 1579
    .line 1580
    move-result-object v1

    .line 1581
    :goto_16
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1582
    .line 1583
    .line 1584
    move-result v4

    .line 1585
    if-eqz v4, :cond_27

    .line 1586
    .line 1587
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1588
    .line 1589
    .line 1590
    move-result-object v4

    .line 1591
    check-cast v4, Lqh1;

    .line 1592
    .line 1593
    iget-object v5, v4, Lqh1;->a:Ljava/lang/String;

    .line 1594
    .line 1595
    iget-object v6, v3, Lqh1;->a:Ljava/lang/String;

    .line 1596
    .line 1597
    invoke-static {v5, v6}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1598
    .line 1599
    .line 1600
    move-result v5

    .line 1601
    if-eqz v5, :cond_26

    .line 1602
    .line 1603
    move-object v4, v3

    .line 1604
    :cond_26
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1605
    .line 1606
    .line 1607
    goto :goto_16

    .line 1608
    :cond_27
    invoke-static {v2, v8}, Lsh1;->f(Ljava/util/ArrayList;Z)V

    .line 1609
    .line 1610
    .line 1611
    :cond_28
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1612
    .line 1613
    invoke-interface {v0, v1}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 1614
    .line 1615
    .line 1616
    sget-object v0, Los7;->a:Los7;

    .line 1617
    .line 1618
    return-object v0

    .line 1619
    :pswitch_12
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1620
    .line 1621
    check-cast v1, Lng1;

    .line 1622
    .line 1623
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1624
    .line 1625
    check-cast v2, Lqh1;

    .line 1626
    .line 1627
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1628
    .line 1629
    check-cast v0, Lxn1;

    .line 1630
    .line 1631
    move-object/from16 v3, p1

    .line 1632
    .line 1633
    check-cast v3, Ljava/lang/Throwable;

    .line 1634
    .line 1635
    iget-object v3, v1, Lng1;->g:Ljava/lang/Object;

    .line 1636
    .line 1637
    monitor-enter v3

    .line 1638
    :try_start_5
    iget-object v4, v1, Lng1;->h:Ljava/util/LinkedHashMap;

    .line 1639
    .line 1640
    iget-object v5, v2, Lqh1;->a:Ljava/lang/String;

    .line 1641
    .line 1642
    invoke-virtual {v4, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1643
    .line 1644
    .line 1645
    move-result-object v4

    .line 1646
    if-ne v4, v0, :cond_29

    .line 1647
    .line 1648
    iget-object v0, v1, Lng1;->h:Ljava/util/LinkedHashMap;

    .line 1649
    .line 1650
    iget-object v1, v2, Lqh1;->a:Ljava/lang/String;

    .line 1651
    .line 1652
    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 1653
    .line 1654
    .line 1655
    :cond_29
    monitor-exit v3

    .line 1656
    sget-object v0, Los7;->a:Los7;

    .line 1657
    .line 1658
    return-object v0

    .line 1659
    :catchall_4
    move-exception v0

    .line 1660
    monitor-exit v3

    .line 1661
    throw v0

    .line 1662
    :pswitch_13
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1663
    .line 1664
    check-cast v1, Ldc1;

    .line 1665
    .line 1666
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1667
    .line 1668
    check-cast v2, Luc3;

    .line 1669
    .line 1670
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1671
    .line 1672
    check-cast v0, Lng6;

    .line 1673
    .line 1674
    move-object/from16 v5, p1

    .line 1675
    .line 1676
    check-cast v5, Ljava/lang/Float;

    .line 1677
    .line 1678
    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    .line 1679
    .line 1680
    .line 1681
    move-result v5

    .line 1682
    iget-boolean v6, v1, Ldc1;->x:Z

    .line 1683
    .line 1684
    if-nez v6, :cond_2a

    .line 1685
    .line 1686
    move v3, v4

    .line 1687
    :cond_2a
    mul-float v4, v3, v5

    .line 1688
    .line 1689
    iget-object v1, v1, Ldc1;->w:Lpg6;

    .line 1690
    .line 1691
    invoke-virtual {v1, v4}, Lpg6;->i(F)J

    .line 1692
    .line 1693
    .line 1694
    move-result-wide v6

    .line 1695
    invoke-virtual {v1, v6, v7}, Lpg6;->f(J)J

    .line 1696
    .line 1697
    .line 1698
    move-result-wide v6

    .line 1699
    iget-object v0, v0, Lng6;->a:Lpg6;

    .line 1700
    .line 1701
    iget-object v4, v0, Lpg6;->k:Lwf6;

    .line 1702
    .line 1703
    invoke-virtual {v0, v4, v6, v7, v8}, Lpg6;->d(Lwf6;JI)J

    .line 1704
    .line 1705
    .line 1706
    move-result-wide v6

    .line 1707
    invoke-virtual {v1, v6, v7}, Lpg6;->f(J)J

    .line 1708
    .line 1709
    .line 1710
    move-result-wide v6

    .line 1711
    invoke-virtual {v1, v6, v7}, Lpg6;->h(J)F

    .line 1712
    .line 1713
    .line 1714
    move-result v0

    .line 1715
    mul-float/2addr v0, v3

    .line 1716
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 1717
    .line 1718
    .line 1719
    move-result v1

    .line 1720
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 1721
    .line 1722
    .line 1723
    move-result v3

    .line 1724
    cmpg-float v1, v1, v3

    .line 1725
    .line 1726
    if-gez v1, :cond_2b

    .line 1727
    .line 1728
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1729
    .line 1730
    const-string v3, "Scroll animation cancelled because scroll was not consumed (|"

    .line 1731
    .line 1732
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1733
    .line 1734
    .line 1735
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 1736
    .line 1737
    .line 1738
    const-string v0, "| < |"

    .line 1739
    .line 1740
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1741
    .line 1742
    .line 1743
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 1744
    .line 1745
    .line 1746
    const-string v0, "|)"

    .line 1747
    .line 1748
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1749
    .line 1750
    .line 1751
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1752
    .line 1753
    .line 1754
    move-result-object v0

    .line 1755
    new-instance v1, Ljava/util/concurrent/CancellationException;

    .line 1756
    .line 1757
    invoke-direct {v1, v0}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 1758
    .line 1759
    .line 1760
    invoke-virtual {v1, v15}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 1761
    .line 1762
    .line 1763
    invoke-interface {v2, v1}, Luc3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 1764
    .line 1765
    .line 1766
    :cond_2b
    sget-object v0, Los7;->a:Los7;

    .line 1767
    .line 1768
    return-object v0

    .line 1769
    :pswitch_14
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1770
    .line 1771
    check-cast v1, Li71;

    .line 1772
    .line 1773
    iget-object v3, v0, Lbg;->j:Ljava/lang/Object;

    .line 1774
    .line 1775
    check-cast v3, Ljava/util/List;

    .line 1776
    .line 1777
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1778
    .line 1779
    check-cast v0, Lk71;

    .line 1780
    .line 1781
    move-object/from16 v4, p1

    .line 1782
    .line 1783
    check-cast v4, Lhm3;

    .line 1784
    .line 1785
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1786
    .line 1787
    .line 1788
    const-string v5, "source"

    .line 1789
    .line 1790
    new-instance v6, La71;

    .line 1791
    .line 1792
    invoke-direct {v6, v1, v3, v0, v8}, La71;-><init>(Li71;Ljava/util/List;Lk71;B)V

    .line 1793
    .line 1794
    .line 1795
    new-instance v3, Lq21;

    .line 1796
    .line 1797
    const v7, 0x5065139d

    .line 1798
    .line 1799
    .line 1800
    invoke-direct {v3, v7, v8, v6}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 1801
    .line 1802
    .line 1803
    invoke-static {v4, v5, v3, v11}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 1804
    .line 1805
    .line 1806
    const-string v3, "rules"

    .line 1807
    .line 1808
    new-instance v5, Lz61;

    .line 1809
    .line 1810
    invoke-direct {v5, v1, v0, v8}, Lz61;-><init>(Li71;Lk71;B)V

    .line 1811
    .line 1812
    .line 1813
    new-instance v6, Lq21;

    .line 1814
    .line 1815
    const v7, 0x7c0cd606

    .line 1816
    .line 1817
    .line 1818
    invoke-direct {v6, v7, v8, v5}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 1819
    .line 1820
    .line 1821
    invoke-static {v4, v3, v6, v11}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 1822
    .line 1823
    .line 1824
    invoke-virtual {v1}, Li71;->b()Z

    .line 1825
    .line 1826
    .line 1827
    move-result v1

    .line 1828
    if-eqz v1, :cond_2c

    .line 1829
    .line 1830
    const-string v1, "clear"

    .line 1831
    .line 1832
    new-instance v3, Lo84;

    .line 1833
    .line 1834
    invoke-direct {v3, v0, v2}, Lo84;-><init>(Ljava/lang/Object;B)V

    .line 1835
    .line 1836
    .line 1837
    new-instance v0, Lq21;

    .line 1838
    .line 1839
    const v2, 0x2bd3d562

    .line 1840
    .line 1841
    .line 1842
    invoke-direct {v0, v2, v8, v3}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 1843
    .line 1844
    .line 1845
    invoke-static {v4, v1, v0, v11}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 1846
    .line 1847
    .line 1848
    :cond_2c
    sget-object v0, Los7;->a:Los7;

    .line 1849
    .line 1850
    return-object v0

    .line 1851
    :pswitch_15
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1852
    .line 1853
    check-cast v1, Lhh2;

    .line 1854
    .line 1855
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1856
    .line 1857
    check-cast v2, Ljava/util/List;

    .line 1858
    .line 1859
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1860
    .line 1861
    check-cast v0, Lgy1;

    .line 1862
    .line 1863
    move-object/from16 v3, p1

    .line 1864
    .line 1865
    check-cast v3, Ljava/lang/String;

    .line 1866
    .line 1867
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1868
    .line 1869
    .line 1870
    iget-wide v4, v0, Lgy1;->a:J

    .line 1871
    .line 1872
    invoke-static {v4, v5, v3, v2}, Lxo4;->e(JLjava/lang/String;Ljava/util/List;)Ljava/util/List;

    .line 1873
    .line 1874
    .line 1875
    move-result-object v0

    .line 1876
    invoke-interface {v1, v0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1877
    .line 1878
    .line 1879
    sget-object v0, Los7;->a:Los7;

    .line 1880
    .line 1881
    return-object v0

    .line 1882
    :pswitch_16
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1883
    .line 1884
    check-cast v1, Llw;

    .line 1885
    .line 1886
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1887
    .line 1888
    check-cast v2, Landroid/content/Context;

    .line 1889
    .line 1890
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1891
    .line 1892
    check-cast v0, Lqx3;

    .line 1893
    .line 1894
    move-object/from16 v3, p1

    .line 1895
    .line 1896
    check-cast v3, Ljava/lang/Boolean;

    .line 1897
    .line 1898
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1899
    .line 1900
    .line 1901
    move-result v3

    .line 1902
    const-string v4, "android.permission.POST_NOTIFICATIONS"

    .line 1903
    .line 1904
    if-nez v3, :cond_2d

    .line 1905
    .line 1906
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1907
    .line 1908
    .line 1909
    new-instance v0, Lys;

    .line 1910
    .line 1911
    invoke-direct {v0, v13, v14}, Lys;-><init>(BZ)V

    .line 1912
    .line 1913
    .line 1914
    invoke-virtual {v1, v0}, Llw;->c(Lhh2;)V

    .line 1915
    .line 1916
    .line 1917
    sget-object v0, Lid0;->a:Lid0;

    .line 1918
    .line 1919
    invoke-static {v2}, Lid0;->b(Landroid/content/Context;)V

    .line 1920
    .line 1921
    .line 1922
    goto :goto_17

    .line 1923
    :cond_2d
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1924
    .line 1925
    .line 1926
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1927
    .line 1928
    const/16 v5, 0x21

    .line 1929
    .line 1930
    if-lt v3, v5, :cond_2e

    .line 1931
    .line 1932
    invoke-static {v2, v4}, Lnt7;->H(Landroid/content/Context;Ljava/lang/String;)I

    .line 1933
    .line 1934
    .line 1935
    move-result v2

    .line 1936
    if-nez v2, :cond_2f

    .line 1937
    .line 1938
    :cond_2e
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1939
    .line 1940
    .line 1941
    new-instance v0, Lys;

    .line 1942
    .line 1943
    invoke-direct {v0, v13, v8}, Lys;-><init>(BZ)V

    .line 1944
    .line 1945
    .line 1946
    invoke-virtual {v1, v0}, Llw;->c(Lhh2;)V

    .line 1947
    .line 1948
    .line 1949
    goto :goto_17

    .line 1950
    :cond_2f
    if-lt v3, v5, :cond_30

    .line 1951
    .line 1952
    invoke-virtual {v0, v4}, Lqx3;->h0(Ljava/lang/Object;)V

    .line 1953
    .line 1954
    .line 1955
    goto :goto_17

    .line 1956
    :cond_30
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1957
    .line 1958
    .line 1959
    new-instance v0, Lys;

    .line 1960
    .line 1961
    invoke-direct {v0, v13, v8}, Lys;-><init>(BZ)V

    .line 1962
    .line 1963
    .line 1964
    invoke-virtual {v1, v0}, Llw;->c(Lhh2;)V

    .line 1965
    .line 1966
    .line 1967
    :goto_17
    sget-object v0, Los7;->a:Los7;

    .line 1968
    .line 1969
    return-object v0

    .line 1970
    :pswitch_17
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 1971
    .line 1972
    check-cast v1, Llw;

    .line 1973
    .line 1974
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 1975
    .line 1976
    check-cast v2, Landroid/content/Context;

    .line 1977
    .line 1978
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 1979
    .line 1980
    check-cast v0, Ljava/lang/String;

    .line 1981
    .line 1982
    move-object/from16 v3, p1

    .line 1983
    .line 1984
    check-cast v3, Ljava/lang/Boolean;

    .line 1985
    .line 1986
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1987
    .line 1988
    .line 1989
    move-result v3

    .line 1990
    if-eqz v3, :cond_31

    .line 1991
    .line 1992
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1993
    .line 1994
    .line 1995
    new-instance v0, Lys;

    .line 1996
    .line 1997
    invoke-direct {v0, v13, v8}, Lys;-><init>(BZ)V

    .line 1998
    .line 1999
    .line 2000
    invoke-virtual {v1, v0}, Llw;->c(Lhh2;)V

    .line 2001
    .line 2002
    .line 2003
    goto :goto_18

    .line 2004
    :cond_31
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2005
    .line 2006
    .line 2007
    new-instance v3, Lys;

    .line 2008
    .line 2009
    invoke-direct {v3, v13, v14}, Lys;-><init>(BZ)V

    .line 2010
    .line 2011
    .line 2012
    invoke-virtual {v1, v3}, Llw;->c(Lhh2;)V

    .line 2013
    .line 2014
    .line 2015
    invoke-static {v2, v0}, Lzi6;->D(Landroid/content/Context;Ljava/lang/String;)V

    .line 2016
    .line 2017
    .line 2018
    :goto_18
    sget-object v0, Los7;->a:Los7;

    .line 2019
    .line 2020
    return-object v0

    .line 2021
    :pswitch_18
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 2022
    .line 2023
    check-cast v1, Lgw;

    .line 2024
    .line 2025
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 2026
    .line 2027
    check-cast v2, Llw;

    .line 2028
    .line 2029
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 2030
    .line 2031
    check-cast v0, Landroid/app/Activity;

    .line 2032
    .line 2033
    move-object/from16 v3, p1

    .line 2034
    .line 2035
    check-cast v3, Ljava/lang/Float;

    .line 2036
    .line 2037
    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    .line 2038
    .line 2039
    .line 2040
    move-result v3

    .line 2041
    const v4, 0x3f4ccccd    # 0.8f

    .line 2042
    .line 2043
    .line 2044
    const v5, 0x3f99999a    # 1.2f

    .line 2045
    .line 2046
    .line 2047
    invoke-static {v3, v4, v5}, Ls33;->D(FFF)F

    .line 2048
    .line 2049
    .line 2050
    move-result v3

    .line 2051
    iget v1, v1, Lgw;->R:F

    .line 2052
    .line 2053
    cmpg-float v1, v1, v3

    .line 2054
    .line 2055
    if-eqz v1, :cond_32

    .line 2056
    .line 2057
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2058
    .line 2059
    .line 2060
    new-instance v1, Lk1;

    .line 2061
    .line 2062
    invoke-direct {v1, v3, v12}, Lk1;-><init>(FB)V

    .line 2063
    .line 2064
    .line 2065
    invoke-virtual {v2, v1}, Llw;->c(Lhh2;)V

    .line 2066
    .line 2067
    .line 2068
    if-eqz v0, :cond_32

    .line 2069
    .line 2070
    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    .line 2071
    .line 2072
    .line 2073
    :cond_32
    sget-object v0, Los7;->a:Los7;

    .line 2074
    .line 2075
    return-object v0

    .line 2076
    :pswitch_19
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 2077
    .line 2078
    check-cast v1, Ljava/lang/String;

    .line 2079
    .line 2080
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 2081
    .line 2082
    check-cast v2, Lri1;

    .line 2083
    .line 2084
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 2085
    .line 2086
    check-cast v0, Lkl7;

    .line 2087
    .line 2088
    move-object/from16 v3, p1

    .line 2089
    .line 2090
    check-cast v3, Lnk6;

    .line 2091
    .line 2092
    new-instance v4, Lx;

    .line 2093
    .line 2094
    const/16 v5, 0x10

    .line 2095
    .line 2096
    invoke-direct {v4, v2, v0, v5}, Lx;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 2097
    .line 2098
    .line 2099
    sget-object v0, Llk6;->a:[Lag3;

    .line 2100
    .line 2101
    sget-object v0, Lwj6;->c:Lmk6;

    .line 2102
    .line 2103
    new-instance v2, Lu4;

    .line 2104
    .line 2105
    invoke-direct {v2, v1, v4}, Lu4;-><init>(Ljava/lang/String;Lth2;)V

    .line 2106
    .line 2107
    .line 2108
    invoke-interface {v3, v0, v2}, Lnk6;->a(Lmk6;Ljava/lang/Object;)V

    .line 2109
    .line 2110
    .line 2111
    sget-object v0, Los7;->a:Los7;

    .line 2112
    .line 2113
    return-object v0

    .line 2114
    :pswitch_1a
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 2115
    .line 2116
    check-cast v1, Lri1;

    .line 2117
    .line 2118
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 2119
    .line 2120
    move-object v5, v2

    .line 2121
    check-cast v5, Lzd4;

    .line 2122
    .line 2123
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 2124
    .line 2125
    move-object v6, v0

    .line 2126
    check-cast v6, Lkl7;

    .line 2127
    .line 2128
    move-object/from16 v4, p1

    .line 2129
    .line 2130
    check-cast v4, Lfe2;

    .line 2131
    .line 2132
    new-instance v3, Lq2;

    .line 2133
    .line 2134
    const/16 v8, 0xa

    .line 2135
    .line 2136
    const/4 v7, 0x0

    .line 2137
    invoke-direct/range {v3 .. v8}, Lq2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lfd1;B)V

    .line 2138
    .line 2139
    .line 2140
    invoke-static {v1, v7, v7, v3, v12}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 2141
    .line 2142
    .line 2143
    sget-object v0, Los7;->a:Los7;

    .line 2144
    .line 2145
    return-object v0

    .line 2146
    :pswitch_1b
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 2147
    .line 2148
    check-cast v1, Lxu5;

    .line 2149
    .line 2150
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 2151
    .line 2152
    check-cast v2, Lfm7;

    .line 2153
    .line 2154
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 2155
    .line 2156
    check-cast v0, Lxu5;

    .line 2157
    .line 2158
    move-object/from16 v3, p1

    .line 2159
    .line 2160
    check-cast v3, Lzi;

    .line 2161
    .line 2162
    iget-object v4, v3, Lzi;->e:Lf75;

    .line 2163
    .line 2164
    invoke-virtual {v4}, Lf75;->getValue()Ljava/lang/Object;

    .line 2165
    .line 2166
    .line 2167
    move-result-object v4

    .line 2168
    check-cast v4, Ljava/lang/Number;

    .line 2169
    .line 2170
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 2171
    .line 2172
    .line 2173
    move-result v4

    .line 2174
    iget v6, v1, Lxu5;->h:F

    .line 2175
    .line 2176
    sub-float/2addr v4, v6

    .line 2177
    iget-object v6, v2, Lfm7;->c:Lb75;

    .line 2178
    .line 2179
    invoke-virtual {v6}, Lb75;->h()F

    .line 2180
    .line 2181
    .line 2182
    move-result v6

    .line 2183
    add-float v7, v6, v4

    .line 2184
    .line 2185
    invoke-virtual {v2, v7}, Lfm7;->b(F)V

    .line 2186
    .line 2187
    .line 2188
    iget-object v2, v2, Lfm7;->c:Lb75;

    .line 2189
    .line 2190
    invoke-virtual {v2}, Lb75;->h()F

    .line 2191
    .line 2192
    .line 2193
    move-result v2

    .line 2194
    sub-float/2addr v6, v2

    .line 2195
    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    .line 2196
    .line 2197
    .line 2198
    move-result v2

    .line 2199
    iget-object v6, v3, Lzi;->e:Lf75;

    .line 2200
    .line 2201
    invoke-virtual {v6}, Lf75;->getValue()Ljava/lang/Object;

    .line 2202
    .line 2203
    .line 2204
    move-result-object v6

    .line 2205
    check-cast v6, Ljava/lang/Number;

    .line 2206
    .line 2207
    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    .line 2208
    .line 2209
    .line 2210
    move-result v6

    .line 2211
    iput v6, v1, Lxu5;->h:F

    .line 2212
    .line 2213
    invoke-virtual {v3}, Lzi;->b()Ljava/lang/Object;

    .line 2214
    .line 2215
    .line 2216
    move-result-object v1

    .line 2217
    check-cast v1, Ljava/lang/Number;

    .line 2218
    .line 2219
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 2220
    .line 2221
    .line 2222
    move-result v1

    .line 2223
    iput v1, v0, Lxu5;->h:F

    .line 2224
    .line 2225
    sub-float/2addr v4, v2

    .line 2226
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 2227
    .line 2228
    .line 2229
    move-result v0

    .line 2230
    cmpl-float v0, v0, v5

    .line 2231
    .line 2232
    if-lez v0, :cond_33

    .line 2233
    .line 2234
    invoke-virtual {v3}, Lzi;->a()V

    .line 2235
    .line 2236
    .line 2237
    :cond_33
    sget-object v0, Los7;->a:Los7;

    .line 2238
    .line 2239
    return-object v0

    .line 2240
    :pswitch_1c
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 2241
    .line 2242
    check-cast v1, Lwv6;

    .line 2243
    .line 2244
    iget-object v2, v0, Lbg;->j:Ljava/lang/Object;

    .line 2245
    .line 2246
    iget-object v0, v0, Lbg;->k:Ljava/lang/Object;

    .line 2247
    .line 2248
    check-cast v0, Lbi;

    .line 2249
    .line 2250
    move-object/from16 v3, p1

    .line 2251
    .line 2252
    check-cast v3, Lsr1;

    .line 2253
    .line 2254
    new-instance v3, Lrh;

    .line 2255
    .line 2256
    invoke-direct {v3, v1, v2, v0, v14}, Lrh;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 2257
    .line 2258
    .line 2259
    return-object v3

    .line 2260
    :pswitch_1d
    iget-object v1, v0, Lbg;->i:Ljava/lang/Object;

    .line 2261
    .line 2262
    check-cast v1, Lmw7;

    .line 2263
    .line 2264
    iget-object v2, v0, Lbg;->k:Ljava/lang/Object;

    .line 2265
    .line 2266
    check-cast v2, Lwi3;

    .line 2267
    .line 2268
    iget-object v0, v0, Lbg;->j:Ljava/lang/Object;

    .line 2269
    .line 2270
    check-cast v0, Lmw7;

    .line 2271
    .line 2272
    move-object/from16 v3, p1

    .line 2273
    .line 2274
    check-cast v3, Llv1;

    .line 2275
    .line 2276
    invoke-interface {v3}, Llv1;->V()Lvh7;

    .line 2277
    .line 2278
    .line 2279
    move-result-object v3

    .line 2280
    invoke-virtual {v3}, Lvh7;->K()Lpl0;

    .line 2281
    .line 2282
    .line 2283
    move-result-object v3

    .line 2284
    iget-object v4, v1, Ljg;->i:Landroid/view/View;

    .line 2285
    .line 2286
    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    .line 2287
    .line 2288
    .line 2289
    move-result v4

    .line 2290
    if-eq v4, v6, :cond_36

    .line 2291
    .line 2292
    iput-boolean v8, v1, Ljg;->F:Z

    .line 2293
    .line 2294
    iget-object v2, v2, Lwi3;->u:Lbb;

    .line 2295
    .line 2296
    if-eqz v2, :cond_34

    .line 2297
    .line 2298
    move-object v15, v2

    .line 2299
    :cond_34
    if-eqz v15, :cond_35

    .line 2300
    .line 2301
    invoke-static {v3}, Lfa;->b(Lpl0;)Landroid/graphics/Canvas;

    .line 2302
    .line 2303
    .line 2304
    move-result-object v2

    .line 2305
    iget-object v3, v15, Lbb;->W:Log;

    .line 2306
    .line 2307
    if-eqz v3, :cond_35

    .line 2308
    .line 2309
    invoke-virtual {v0, v2}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    .line 2310
    .line 2311
    .line 2312
    :cond_35
    iput-boolean v14, v1, Ljg;->F:Z

    .line 2313
    .line 2314
    :cond_36
    sget-object v0, Los7;->a:Los7;

    .line 2315
    .line 2316
    return-object v0

    .line 2317
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 2318
    .line 2319
    .line 2320
    .line 2321
    .line 2322
    .line 2323
    .line 2324
    .line 2325
    .line 2326
    .line 2327
    .line 2328
    .line 2329
    .line 2330
    .line 2331
    .line 2332
    .line 2333
    .line 2334
    .line 2335
    .line 2336
    .line 2337
    .line 2338
    .line 2339
    .line 2340
    .line 2341
    .line 2342
    .line 2343
    .line 2344
    .line 2345
    .line 2346
    .line 2347
    .line 2348
    .line 2349
    .line 2350
    .line 2351
    .line 2352
    .line 2353
    .line 2354
    .line 2355
    .line 2356
    .line 2357
    .line 2358
    .line 2359
    .line 2360
    .line 2361
    .line 2362
    .line 2363
    .line 2364
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_b
    .end packed-switch
.end method
