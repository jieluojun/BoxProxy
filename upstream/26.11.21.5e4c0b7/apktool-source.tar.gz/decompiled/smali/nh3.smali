.class public final synthetic Lnh3;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lmh3;


# direct methods
.method public synthetic constructor <init>(Lmh3;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lnh3;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lnh3;->i:Lmh3;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, Lnh3;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x0

    .line 7
    const-string v4, "latency-targets-reset"

    .line 8
    .line 9
    iget-object p0, p0, Lnh3;->i:Lmh3;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lmh3;->c:Lip6;

    .line 15
    .line 16
    new-instance v5, Llh3;

    .line 17
    .line 18
    invoke-direct {v5, p0, v3, v2}, Llh3;-><init>(Lmh3;Lfd1;B)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, v5, v4}, Lip6;->d(Lhh2;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-object v1

    .line 25
    :pswitch_0
    iget-object v0, p0, Lmh3;->c:Lip6;

    .line 26
    .line 27
    new-instance v5, Llh3;

    .line 28
    .line 29
    invoke-direct {v5, p0, v3, v2}, Llh3;-><init>(Lmh3;Lfd1;B)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0, v5, v4}, Lip6;->d(Lhh2;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    return-object v1

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
