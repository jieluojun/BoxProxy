.class public final Lvw7;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Llt0;

.field public final b:Lk34;


# direct methods
.method public constructor <init>(Llt0;Lk34;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvw7;->a:Llt0;

    .line 5
    .line 6
    iput-object p2, p0, Lvw7;->b:Lk34;

    .line 7
    .line 8
    return-void
.end method
