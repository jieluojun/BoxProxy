.class public final synthetic Lnc5;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lad5;


# direct methods
.method public synthetic constructor <init>(Lad5;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lnc5;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lnc5;->i:Lad5;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 33

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lnc5;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/high16 v3, 0x3f800000    # 1.0f

    .line 8
    .line 9
    sget-object v4, Lea4;->h:Lea4;

    .line 10
    .line 11
    sget-object v5, Lz41;->a:Lql0;

    .line 12
    .line 13
    const/16 v6, 0x10

    .line 14
    .line 15
    const/4 v7, 0x0

    .line 16
    const/4 v8, 0x1

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, Lpi;

    .line 23
    .line 24
    move-object/from16 v9, p2

    .line 25
    .line 26
    check-cast v9, Lki2;

    .line 27
    .line 28
    move-object/from16 v10, p3

    .line 29
    .line 30
    check-cast v10, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result v10

    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    and-int/lit8 v1, v10, 0x11

    .line 40
    .line 41
    if-eq v1, v6, :cond_0

    .line 42
    .line 43
    move v7, v8

    .line 44
    :cond_0
    and-int/2addr v10, v8

    .line 45
    invoke-virtual {v9, v10, v7}, Lki2;->Y(IZ)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-eqz v1, :cond_3

    .line 50
    .line 51
    iget-object v12, v0, Lnc5;->i:Lad5;

    .line 52
    .line 53
    iget-object v0, v12, Lad5;->f:Lzd4;

    .line 54
    .line 55
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, Ljava/lang/String;

    .line 60
    .line 61
    invoke-virtual {v9, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    invoke-virtual {v9}, Lki2;->T()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    if-nez v1, :cond_1

    .line 70
    .line 71
    if-ne v6, v5, :cond_2

    .line 72
    .line 73
    :cond_1
    new-instance v10, Lde1;

    .line 74
    .line 75
    const/16 v16, 0x0

    .line 76
    .line 77
    const/16 v17, 0x1c

    .line 78
    .line 79
    const/4 v11, 0x1

    .line 80
    const-class v13, Lad5;

    .line 81
    .line 82
    const-string v14, "updateSearch"

    .line 83
    .line 84
    const-string v15, "updateSearch(Ljava/lang/String;)V"

    .line 85
    .line 86
    invoke-direct/range {v10 .. v17}, Lde1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v9, v10}, Lki2;->q0(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    move-object v6, v10

    .line 93
    :cond_2
    check-cast v6, Lwh2;

    .line 94
    .line 95
    invoke-static {v4, v3}, Lit6;->e(Lha4;F)Lha4;

    .line 96
    .line 97
    .line 98
    move-result-object v13

    .line 99
    const/high16 v17, 0x41400000    # 12.0f

    .line 100
    .line 101
    const/16 v18, 0x7

    .line 102
    .line 103
    const/4 v14, 0x0

    .line 104
    const/4 v15, 0x0

    .line 105
    const/16 v16, 0x0

    .line 106
    .line 107
    invoke-static/range {v13 .. v18}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 108
    .line 109
    .line 110
    move-result-object v11

    .line 111
    const v1, 0x7f0f03d2

    .line 112
    .line 113
    .line 114
    invoke-static {v1, v9}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v16

    .line 118
    invoke-static {v9}, Lj53;->M(Lki2;)Lwg7;

    .line 119
    .line 120
    .line 121
    move-result-object v19

    .line 122
    move-object v10, v6

    .line 123
    check-cast v10, Lhh2;

    .line 124
    .line 125
    new-instance v1, Lmc5;

    .line 126
    .line 127
    invoke-direct {v1, v12, v8}, Lmc5;-><init>(Lad5;B)V

    .line 128
    .line 129
    .line 130
    const v3, 0x4931321

    .line 131
    .line 132
    .line 133
    invoke-static {v3, v1, v9}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 134
    .line 135
    .line 136
    move-result-object v21

    .line 137
    const v30, 0x36000

    .line 138
    .line 139
    .line 140
    const v31, 0x3f3b38

    .line 141
    .line 142
    .line 143
    const-wide/16 v12, 0x0

    .line 144
    .line 145
    const/4 v14, 0x0

    .line 146
    const/16 v17, 0x1

    .line 147
    .line 148
    const/16 v18, 0x0

    .line 149
    .line 150
    const/16 v20, 0x0

    .line 151
    .line 152
    const/16 v22, 0x1

    .line 153
    .line 154
    const/16 v23, 0x0

    .line 155
    .line 156
    const/16 v24, 0x0

    .line 157
    .line 158
    const/16 v25, 0x0

    .line 159
    .line 160
    const/16 v26, 0x0

    .line 161
    .line 162
    const/16 v27, 0x0

    .line 163
    .line 164
    const v29, 0xc00180

    .line 165
    .line 166
    .line 167
    move-object/from16 v28, v9

    .line 168
    .line 169
    move-object v9, v0

    .line 170
    invoke-static/range {v9 .. v31}, Lj53;->d(Ljava/lang/String;Lhh2;Lha4;JLab7;FLjava/lang/String;ZZLwg7;Lrg3;Lq21;ZIILt32;Lt32;Lnw6;Lki2;III)V

    .line 171
    .line 172
    .line 173
    goto :goto_0

    .line 174
    :cond_3
    move-object/from16 v28, v9

    .line 175
    .line 176
    invoke-virtual/range {v28 .. v28}, Lki2;->b0()V

    .line 177
    .line 178
    .line 179
    :goto_0
    return-object v2

    .line 180
    :pswitch_0
    move-object/from16 v1, p1

    .line 181
    .line 182
    check-cast v1, Lpi;

    .line 183
    .line 184
    move-object/from16 v9, p2

    .line 185
    .line 186
    check-cast v9, Lki2;

    .line 187
    .line 188
    move-object/from16 v10, p3

    .line 189
    .line 190
    check-cast v10, Ljava/lang/Integer;

    .line 191
    .line 192
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 193
    .line 194
    .line 195
    move-result v10

    .line 196
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 197
    .line 198
    .line 199
    and-int/lit8 v1, v10, 0x11

    .line 200
    .line 201
    if-eq v1, v6, :cond_4

    .line 202
    .line 203
    move v7, v8

    .line 204
    :cond_4
    and-int/2addr v10, v8

    .line 205
    invoke-virtual {v9, v10, v7}, Lki2;->Y(IZ)Z

    .line 206
    .line 207
    .line 208
    move-result v1

    .line 209
    if-eqz v1, :cond_7

    .line 210
    .line 211
    iget-object v12, v0, Lnc5;->i:Lad5;

    .line 212
    .line 213
    iget-object v0, v12, Lad5;->f:Lzd4;

    .line 214
    .line 215
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    check-cast v0, Ljava/lang/String;

    .line 220
    .line 221
    invoke-virtual {v9, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    move-result v1

    .line 225
    invoke-virtual {v9}, Lki2;->T()Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v6

    .line 229
    if-nez v1, :cond_5

    .line 230
    .line 231
    if-ne v6, v5, :cond_6

    .line 232
    .line 233
    :cond_5
    new-instance v10, Lde1;

    .line 234
    .line 235
    const/16 v16, 0x0

    .line 236
    .line 237
    const/16 v17, 0x19

    .line 238
    .line 239
    const/4 v11, 0x1

    .line 240
    const-class v13, Lad5;

    .line 241
    .line 242
    const-string v14, "updateSearch"

    .line 243
    .line 244
    const-string v15, "updateSearch(Ljava/lang/String;)V"

    .line 245
    .line 246
    invoke-direct/range {v10 .. v17}, Lde1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 247
    .line 248
    .line 249
    invoke-virtual {v9, v10}, Lki2;->q0(Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    move-object v6, v10

    .line 253
    :cond_6
    check-cast v6, Lwh2;

    .line 254
    .line 255
    invoke-static {v4, v3}, Lit6;->e(Lha4;F)Lha4;

    .line 256
    .line 257
    .line 258
    move-result-object v10

    .line 259
    const/high16 v14, 0x41400000    # 12.0f

    .line 260
    .line 261
    const/4 v15, 0x7

    .line 262
    const/4 v11, 0x0

    .line 263
    const/4 v12, 0x0

    .line 264
    const/4 v13, 0x0

    .line 265
    invoke-static/range {v10 .. v15}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 266
    .line 267
    .line 268
    move-result-object v11

    .line 269
    const/high16 v1, 0x41e00000    # 28.0f

    .line 270
    .line 271
    invoke-static {v1}, Lv06;->a(F)Lt06;

    .line 272
    .line 273
    .line 274
    move-result-object v27

    .line 275
    sget-object v1, Lq04;->b:Lcx1;

    .line 276
    .line 277
    invoke-virtual {v9, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 278
    .line 279
    .line 280
    move-result-object v3

    .line 281
    check-cast v3, Ln04;

    .line 282
    .line 283
    iget-object v3, v3, Ln04;->b:Lgq7;

    .line 284
    .line 285
    iget-object v12, v3, Lgq7;->j:Lwg7;

    .line 286
    .line 287
    invoke-virtual {v9, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 288
    .line 289
    .line 290
    move-result-object v1

    .line 291
    check-cast v1, Ln04;

    .line 292
    .line 293
    iget-object v1, v1, Ln04;->a:Lky0;

    .line 294
    .line 295
    iget-wide v13, v1, Lky0;->q:J

    .line 296
    .line 297
    const/16 v23, 0x0

    .line 298
    .line 299
    const v24, 0xfffffe

    .line 300
    .line 301
    .line 302
    const-wide/16 v15, 0x0

    .line 303
    .line 304
    const/16 v17, 0x0

    .line 305
    .line 306
    const/16 v18, 0x0

    .line 307
    .line 308
    const-wide/16 v19, 0x0

    .line 309
    .line 310
    const-wide/16 v21, 0x0

    .line 311
    .line 312
    invoke-static/range {v12 .. v24}, Lwg7;->a(Lwg7;JJLsf2;Lre2;JJLwp3;I)Lwg7;

    .line 313
    .line 314
    .line 315
    move-result-object v13

    .line 316
    invoke-static {v9}, Lx43;->M(Lki2;)Lbb7;

    .line 317
    .line 318
    .line 319
    move-result-object v28

    .line 320
    move-object v10, v6

    .line 321
    check-cast v10, Lhh2;

    .line 322
    .line 323
    sget-object v15, Lha1;->A:Lq21;

    .line 324
    .line 325
    sget-object v16, Lha1;->B:Lq21;

    .line 326
    .line 327
    const/16 v31, 0x6000

    .line 328
    .line 329
    const v32, 0x7be58

    .line 330
    .line 331
    .line 332
    const/4 v12, 0x0

    .line 333
    const/4 v14, 0x0

    .line 334
    const/16 v19, 0x0

    .line 335
    .line 336
    const/16 v20, 0x0

    .line 337
    .line 338
    const/16 v21, 0x0

    .line 339
    .line 340
    const/16 v22, 0x1

    .line 341
    .line 342
    const/16 v23, 0x0

    .line 343
    .line 344
    const/16 v24, 0x0

    .line 345
    .line 346
    const/16 v25, 0x0

    .line 347
    .line 348
    const/16 v26, 0x0

    .line 349
    .line 350
    const v30, 0x6c00180

    .line 351
    .line 352
    .line 353
    move-object/from16 v29, v9

    .line 354
    .line 355
    move-object v9, v0

    .line 356
    invoke-static/range {v9 .. v32}, Lz33;->d(Ljava/lang/String;Lhh2;Lha4;ZLwg7;Llh2;Llh2;Llh2;Lq21;Lq21;ZLrg3;Lpg3;ZIILt32;Lt32;Lkn6;Lbb7;Lki2;III)V

    .line 357
    .line 358
    .line 359
    goto :goto_1

    .line 360
    :cond_7
    move-object/from16 v29, v9

    .line 361
    .line 362
    invoke-virtual/range {v29 .. v29}, Lki2;->b0()V

    .line 363
    .line 364
    .line 365
    :goto_1
    return-object v2

    .line 366
    nop

    .line 367
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
