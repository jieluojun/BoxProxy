.class public final Lh82;
.super Lw92;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final d:[Lic6;

.field public final e:Lm5;

.field public f:Landroid/graphics/Bitmap;

.field public g:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>(Lg82;[Lic6;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, Lw92;-><init>(Lv92;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lh82;->d:[Lic6;

    .line 5
    .line 6
    new-instance p1, Lm5;

    .line 7
    .line 8
    const/16 p2, 0x10

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p1, p2, v0}, Lm5;-><init>(BZ)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lh82;->e:Lm5;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final a()I
    .locals 0

    .line 1
    const/16 p0, 0x8

    .line 2
    .line 3
    return p0
.end method
