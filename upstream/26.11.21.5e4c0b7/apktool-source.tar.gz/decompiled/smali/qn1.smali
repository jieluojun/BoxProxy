.class public final synthetic Lqn1;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lqn1;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lqn1;->i:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Lqn1;->j:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 15

    .line 1
    iget-byte v0, p0, Lqn1;->h:B

    .line 2
    .line 3
    const/high16 v1, 0x3f800000    # 1.0f

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/16 v3, 0x10

    .line 7
    .line 8
    const/4 v4, 0x3

    .line 9
    const/4 v5, 0x0

    .line 10
    const/4 v6, 0x0

    .line 11
    const/4 v7, 0x1

    .line 12
    packed-switch v0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lzd4;

    .line 18
    .line 19
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p0, Lfp4;

    .line 22
    .line 23
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    check-cast v1, Ljava/lang/Integer;

    .line 28
    .line 29
    if-eqz v1, :cond_0

    .line 30
    .line 31
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    invoke-virtual {p0, v1}, Lfp4;->c(I)V

    .line 36
    .line 37
    .line 38
    :cond_0
    invoke-interface {v0, v6}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    sget-object p0, Los7;->a:Los7;

    .line 42
    .line 43
    return-object p0

    .line 44
    :pswitch_0
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v0, Lhh2;

    .line 47
    .line 48
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast p0, Lro4;

    .line 51
    .line 52
    invoke-interface {v0, p0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    sget-object p0, Los7;->a:Los7;

    .line 56
    .line 57
    return-object p0

    .line 58
    :pswitch_1
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v0, Lri1;

    .line 61
    .line 62
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast p0, Lh08;

    .line 65
    .line 66
    new-instance v1, Lc11;

    .line 67
    .line 68
    const/4 v2, 0x6

    .line 69
    invoke-direct {v1, p0, v6, v2}, Lc11;-><init>(Ljava/lang/Object;Lfd1;B)V

    .line 70
    .line 71
    .line 72
    invoke-static {v0, v6, v6, v1, v4}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 73
    .line 74
    .line 75
    sget-object p0, Los7;->a:Los7;

    .line 76
    .line 77
    return-object p0

    .line 78
    :pswitch_2
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Lt74;

    .line 81
    .line 82
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast p0, Lq21;

    .line 85
    .line 86
    new-instance v1, Lm24;

    .line 87
    .line 88
    const/16 v2, 0x9

    .line 89
    .line 90
    invoke-direct {v1, p0, v2}, Lm24;-><init>(Lq21;B)V

    .line 91
    .line 92
    .line 93
    new-instance p0, Lq21;

    .line 94
    .line 95
    const v2, 0x18ac0709

    .line 96
    .line 97
    .line 98
    invoke-direct {p0, v2, v7, v1}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    iput-object p0, v0, Lt74;->b:Lq21;

    .line 102
    .line 103
    sget-object p0, Los7;->a:Los7;

    .line 104
    .line 105
    return-object p0

    .line 106
    :pswitch_3
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast v0, Ljava/util/ArrayList;

    .line 109
    .line 110
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 111
    .line 112
    check-cast p0, Lzd4;

    .line 113
    .line 114
    invoke-interface {p0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    check-cast v1, Ljava/util/List;

    .line 119
    .line 120
    invoke-static {v1, v0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result v1

    .line 124
    if-nez v1, :cond_1

    .line 125
    .line 126
    invoke-static {v0}, Lxx0;->s1(Ljava/lang/Iterable;)Ljava/util/List;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-interface {p0, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_1
    sget-object p0, Los7;->a:Los7;

    .line 134
    .line 135
    return-object p0

    .line 136
    :pswitch_4
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v0, Lfb1;

    .line 139
    .line 140
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast p0, Lvy3;

    .line 143
    .line 144
    invoke-static {p0}, Lkk;->g0(Lio1;)Lwi3;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    iget-object v1, v1, Lwi3;->F:Lso1;

    .line 149
    .line 150
    iget-object v1, p0, Lvy3;->z:Lc75;

    .line 151
    .line 152
    invoke-virtual {v1}, Lc75;->h()I

    .line 153
    .line 154
    .line 155
    iget-object p0, p0, Lvy3;->A:Lc75;

    .line 156
    .line 157
    invoke-virtual {p0}, Lc75;->h()I

    .line 158
    .line 159
    .line 160
    move-result p0

    .line 161
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 162
    .line 163
    .line 164
    const v0, 0x3eaaaaab

    .line 165
    .line 166
    .line 167
    int-to-float p0, p0

    .line 168
    mul-float/2addr v0, p0

    .line 169
    invoke-static {v0}, Lw04;->w(F)I

    .line 170
    .line 171
    .line 172
    move-result p0

    .line 173
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 174
    .line 175
    .line 176
    move-result-object p0

    .line 177
    return-object p0

    .line 178
    :pswitch_5
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 179
    .line 180
    check-cast v0, Lkr2;

    .line 181
    .line 182
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 183
    .line 184
    check-cast p0, Lkv3;

    .line 185
    .line 186
    check-cast v0, Lsa5;

    .line 187
    .line 188
    invoke-virtual {v0, v7}, Lsa5;->a(I)V

    .line 189
    .line 190
    .line 191
    iget-object v0, p0, Lkv3;->b:Lip6;

    .line 192
    .line 193
    const-string v1, "refresh"

    .line 194
    .line 195
    new-instance v2, Lfv3;

    .line 196
    .line 197
    invoke-direct {v2, p0, v6, v7}, Lfv3;-><init>(Lkv3;Lfd1;B)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {v0, v2, v1}, Lip6;->e(Lhh2;Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    sget-object p0, Los7;->a:Los7;

    .line 204
    .line 205
    return-object p0

    .line 206
    :pswitch_6
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 207
    .line 208
    check-cast v0, Lri1;

    .line 209
    .line 210
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 211
    .line 212
    check-cast p0, Lug;

    .line 213
    .line 214
    new-instance v1, Ls70;

    .line 215
    .line 216
    const/16 v2, 0xe

    .line 217
    .line 218
    invoke-direct {v1, p0, v6, v2}, Ls70;-><init>(Lug;Lfd1;B)V

    .line 219
    .line 220
    .line 221
    invoke-static {v0, v6, v6, v1, v4}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 222
    .line 223
    .line 224
    sget-object p0, Los7;->a:Los7;

    .line 225
    .line 226
    return-object p0

    .line 227
    :pswitch_7
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 228
    .line 229
    check-cast v0, Lhc6;

    .line 230
    .line 231
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast p0, Lec6;

    .line 234
    .line 235
    new-instance v1, Lwm3;

    .line 236
    .line 237
    sget-object v2, Lx12;->h:Lx12;

    .line 238
    .line 239
    invoke-direct {v1, v0, v2, p0}, Lwm3;-><init>(Lhc6;Ljava/util/Map;Lec6;)V

    .line 240
    .line 241
    .line 242
    return-object v1

    .line 243
    :pswitch_8
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 244
    .line 245
    check-cast v0, Lbp1;

    .line 246
    .line 247
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast p0, Lgn1;

    .line 250
    .line 251
    invoke-virtual {v0}, Lbp1;->getValue()Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    check-cast v0, Li45;

    .line 256
    .line 257
    new-instance v1, Lq53;

    .line 258
    .line 259
    iget-object v2, p0, Lu55;->k:Lg55;

    .line 260
    .line 261
    iget-object v2, v2, Lg55;->f:Lnl3;

    .line 262
    .line 263
    invoke-virtual {v2}, Lnl3;->getValue()Ljava/lang/Object;

    .line 264
    .line 265
    .line 266
    move-result-object v2

    .line 267
    check-cast v2, Lp93;

    .line 268
    .line 269
    invoke-direct {v1, v2, v0}, Lq53;-><init>(Lp93;Lx43;)V

    .line 270
    .line 271
    .line 272
    new-instance v2, Lj45;

    .line 273
    .line 274
    invoke-direct {v2, p0, v0, v1}, Lj45;-><init>(Lgn1;Li45;Lq53;)V

    .line 275
    .line 276
    .line 277
    return-object v2

    .line 278
    :pswitch_9
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 279
    .line 280
    check-cast v0, Lbp1;

    .line 281
    .line 282
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 283
    .line 284
    check-cast p0, Lrk3;

    .line 285
    .line 286
    invoke-virtual {v0}, Lbp1;->getValue()Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    check-cast v0, Lwj3;

    .line 291
    .line 292
    new-instance v1, Lq53;

    .line 293
    .line 294
    iget-object v2, p0, Lrk3;->j:Ljk3;

    .line 295
    .line 296
    iget-object v2, v2, Ljk3;->f:Lnl3;

    .line 297
    .line 298
    invoke-virtual {v2}, Lnl3;->getValue()Ljava/lang/Object;

    .line 299
    .line 300
    .line 301
    move-result-object v2

    .line 302
    check-cast v2, Lp93;

    .line 303
    .line 304
    invoke-direct {v1, v2, v0}, Lq53;-><init>(Lp93;Lx43;)V

    .line 305
    .line 306
    .line 307
    new-instance v2, Lxj3;

    .line 308
    .line 309
    invoke-direct {v2, p0, v0, v1}, Lxj3;-><init>(Lrk3;Lwj3;Lq53;)V

    .line 310
    .line 311
    .line 312
    return-object v2

    .line 313
    :pswitch_a
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 314
    .line 315
    check-cast v0, Lwi3;

    .line 316
    .line 317
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 318
    .line 319
    check-cast p0, Lav5;

    .line 320
    .line 321
    iget-object v0, v0, Lwi3;->M:Lu9;

    .line 322
    .line 323
    iget-object v1, v0, Lu9;->g:Ljava/lang/Object;

    .line 324
    .line 325
    check-cast v1, Lga4;

    .line 326
    .line 327
    iget v1, v1, Lga4;->k:I

    .line 328
    .line 329
    and-int/lit8 v1, v1, 0x8

    .line 330
    .line 331
    if-eqz v1, :cond_d

    .line 332
    .line 333
    iget-object v0, v0, Lu9;->f:Ljava/lang/Object;

    .line 334
    .line 335
    check-cast v0, Ld87;

    .line 336
    .line 337
    :goto_0
    if-eqz v0, :cond_d

    .line 338
    .line 339
    iget v1, v0, Lga4;->j:I

    .line 340
    .line 341
    and-int/lit8 v1, v1, 0x8

    .line 342
    .line 343
    if-eqz v1, :cond_c

    .line 344
    .line 345
    move-object v1, v0

    .line 346
    move-object v2, v6

    .line 347
    :cond_2
    :goto_1
    if-eqz v1, :cond_c

    .line 348
    .line 349
    instance-of v4, v1, Lbk6;

    .line 350
    .line 351
    if-eqz v4, :cond_5

    .line 352
    .line 353
    check-cast v1, Lbk6;

    .line 354
    .line 355
    invoke-interface {v1}, Lbk6;->W0()Z

    .line 356
    .line 357
    .line 358
    move-result v4

    .line 359
    if-eqz v4, :cond_3

    .line 360
    .line 361
    new-instance v4, Lxj6;

    .line 362
    .line 363
    invoke-direct {v4}, Lxj6;-><init>()V

    .line 364
    .line 365
    .line 366
    iput-object v4, p0, Lav5;->h:Ljava/lang/Object;

    .line 367
    .line 368
    iput-boolean v7, v4, Lxj6;->k:Z

    .line 369
    .line 370
    :cond_3
    invoke-interface {v1}, Lbk6;->X0()Z

    .line 371
    .line 372
    .line 373
    move-result v4

    .line 374
    if-eqz v4, :cond_4

    .line 375
    .line 376
    iget-object v4, p0, Lav5;->h:Ljava/lang/Object;

    .line 377
    .line 378
    check-cast v4, Lxj6;

    .line 379
    .line 380
    iput-boolean v7, v4, Lxj6;->j:Z

    .line 381
    .line 382
    :cond_4
    iget-object v4, p0, Lav5;->h:Ljava/lang/Object;

    .line 383
    .line 384
    check-cast v4, Lnk6;

    .line 385
    .line 386
    invoke-interface {v1, v4}, Lbk6;->R0(Lnk6;)V

    .line 387
    .line 388
    .line 389
    goto :goto_4

    .line 390
    :cond_5
    iget v4, v1, Lga4;->j:I

    .line 391
    .line 392
    and-int/lit8 v4, v4, 0x8

    .line 393
    .line 394
    if-eqz v4, :cond_b

    .line 395
    .line 396
    instance-of v4, v1, Lko1;

    .line 397
    .line 398
    if-eqz v4, :cond_b

    .line 399
    .line 400
    move-object v4, v1

    .line 401
    check-cast v4, Lko1;

    .line 402
    .line 403
    iget-object v4, v4, Lko1;->w:Lga4;

    .line 404
    .line 405
    move v8, v5

    .line 406
    :goto_2
    if-eqz v4, :cond_a

    .line 407
    .line 408
    iget v9, v4, Lga4;->j:I

    .line 409
    .line 410
    and-int/lit8 v9, v9, 0x8

    .line 411
    .line 412
    if-eqz v9, :cond_9

    .line 413
    .line 414
    add-int/lit8 v8, v8, 0x1

    .line 415
    .line 416
    if-ne v8, v7, :cond_6

    .line 417
    .line 418
    move-object v1, v4

    .line 419
    goto :goto_3

    .line 420
    :cond_6
    if-nez v2, :cond_7

    .line 421
    .line 422
    new-instance v2, Lbe4;

    .line 423
    .line 424
    new-array v9, v3, [Lga4;

    .line 425
    .line 426
    invoke-direct {v2, v5, v9}, Lbe4;-><init>(I[Ljava/lang/Object;)V

    .line 427
    .line 428
    .line 429
    :cond_7
    if-eqz v1, :cond_8

    .line 430
    .line 431
    invoke-virtual {v2, v1}, Lbe4;->b(Ljava/lang/Object;)V

    .line 432
    .line 433
    .line 434
    move-object v1, v6

    .line 435
    :cond_8
    invoke-virtual {v2, v4}, Lbe4;->b(Ljava/lang/Object;)V

    .line 436
    .line 437
    .line 438
    :cond_9
    :goto_3
    iget-object v4, v4, Lga4;->m:Lga4;

    .line 439
    .line 440
    goto :goto_2

    .line 441
    :cond_a
    if-eq v8, v7, :cond_2

    .line 442
    .line 443
    :cond_b
    :goto_4
    invoke-static {v2}, Lkk;->X(Lbe4;)Lga4;

    .line 444
    .line 445
    .line 446
    move-result-object v1

    .line 447
    goto :goto_1

    .line 448
    :cond_c
    iget-object v0, v0, Lga4;->l:Lga4;

    .line 449
    .line 450
    goto :goto_0

    .line 451
    :cond_d
    sget-object p0, Los7;->a:Los7;

    .line 452
    .line 453
    return-object p0

    .line 454
    :pswitch_b
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 455
    .line 456
    check-cast v0, Lgl6;

    .line 457
    .line 458
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 459
    .line 460
    check-cast p0, Lod3;

    .line 461
    .line 462
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 463
    .line 464
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 465
    .line 466
    .line 467
    iget-object v2, p0, Lod3;->a:Lyd3;

    .line 468
    .line 469
    invoke-static {v0, p0}, Lnx3;->d0(Lgl6;Lod3;)V

    .line 470
    .line 471
    .line 472
    invoke-interface {v0}, Lgl6;->d()I

    .line 473
    .line 474
    .line 475
    move-result p0

    .line 476
    move v2, v5

    .line 477
    :goto_5
    if-ge v2, p0, :cond_13

    .line 478
    .line 479
    invoke-interface {v0, v2}, Lgl6;->i(I)Ljava/util/List;

    .line 480
    .line 481
    .line 482
    move-result-object v3

    .line 483
    new-instance v4, Ljava/util/ArrayList;

    .line 484
    .line 485
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 486
    .line 487
    .line 488
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 489
    .line 490
    .line 491
    move-result-object v3

    .line 492
    :cond_e
    :goto_6
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 493
    .line 494
    .line 495
    move-result v7

    .line 496
    if-eqz v7, :cond_f

    .line 497
    .line 498
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 499
    .line 500
    .line 501
    move-result-object v7

    .line 502
    instance-of v8, v7, Lre3;

    .line 503
    .line 504
    if-eqz v8, :cond_e

    .line 505
    .line 506
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 507
    .line 508
    .line 509
    goto :goto_6

    .line 510
    :cond_f
    invoke-static {v4}, Lxx0;->j1(Ljava/util/List;)Ljava/lang/Object;

    .line 511
    .line 512
    .line 513
    move-result-object v3

    .line 514
    check-cast v3, Lre3;

    .line 515
    .line 516
    if-eqz v3, :cond_12

    .line 517
    .line 518
    invoke-interface {v3}, Lre3;->names()[Ljava/lang/String;

    .line 519
    .line 520
    .line 521
    move-result-object v3

    .line 522
    if-eqz v3, :cond_12

    .line 523
    .line 524
    array-length v4, v3

    .line 525
    move v7, v5

    .line 526
    :goto_7
    if-ge v7, v4, :cond_12

    .line 527
    .line 528
    aget-object v8, v3, v7

    .line 529
    .line 530
    invoke-interface {v0}, Lgl6;->c()Lml6;

    .line 531
    .line 532
    .line 533
    move-result-object v9

    .line 534
    sget-object v10, Lll6;->e:Lll6;

    .line 535
    .line 536
    invoke-static {v9, v10}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 537
    .line 538
    .line 539
    move-result v9

    .line 540
    if-eqz v9, :cond_10

    .line 541
    .line 542
    const-string v9, "enum value"

    .line 543
    .line 544
    goto :goto_8

    .line 545
    :cond_10
    const-string v9, "property"

    .line 546
    .line 547
    :goto_8
    invoke-interface {v1, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 548
    .line 549
    .line 550
    move-result v10

    .line 551
    if-nez v10, :cond_11

    .line 552
    .line 553
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 554
    .line 555
    .line 556
    move-result-object v9

    .line 557
    invoke-interface {v1, v8, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 558
    .line 559
    .line 560
    add-int/lit8 v7, v7, 0x1

    .line 561
    .line 562
    goto :goto_7

    .line 563
    :cond_11
    new-instance p0, Ljava/lang/StringBuilder;

    .line 564
    .line 565
    const-string v3, "The suggested name \'"

    .line 566
    .line 567
    invoke-direct {p0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 568
    .line 569
    .line 570
    invoke-virtual {p0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 571
    .line 572
    .line 573
    const-string v3, "\' for "

    .line 574
    .line 575
    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 576
    .line 577
    .line 578
    invoke-virtual {p0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 579
    .line 580
    .line 581
    const/16 v3, 0x20

    .line 582
    .line 583
    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 584
    .line 585
    .line 586
    invoke-interface {v0, v2}, Lgl6;->e(I)Ljava/lang/String;

    .line 587
    .line 588
    .line 589
    move-result-object v2

    .line 590
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 591
    .line 592
    .line 593
    const-string v2, " is already one of the names for "

    .line 594
    .line 595
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 596
    .line 597
    .line 598
    invoke-virtual {p0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 599
    .line 600
    .line 601
    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 602
    .line 603
    .line 604
    invoke-static {v8, v1}, Lhy3;->b0(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 605
    .line 606
    .line 607
    move-result-object v1

    .line 608
    check-cast v1, Ljava/lang/Number;

    .line 609
    .line 610
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 611
    .line 612
    .line 613
    move-result v1

    .line 614
    invoke-interface {v0, v1}, Lgl6;->e(I)Ljava/lang/String;

    .line 615
    .line 616
    .line 617
    move-result-object v1

    .line 618
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 619
    .line 620
    .line 621
    const-string v1, " in "

    .line 622
    .line 623
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 624
    .line 625
    .line 626
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 627
    .line 628
    .line 629
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 630
    .line 631
    .line 632
    move-result-object p0

    .line 633
    new-instance v0, Lbe3;

    .line 634
    .line 635
    const/4 v1, -0x1

    .line 636
    invoke-static {v1, p0, v6, v6, v6}, Lv43;->L(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 637
    .line 638
    .line 639
    move-result-object p0

    .line 640
    invoke-direct {v0, p0}, Lbe3;-><init>(Ljava/lang/String;)V

    .line 641
    .line 642
    .line 643
    throw v0

    .line 644
    :cond_12
    add-int/lit8 v2, v2, 0x1

    .line 645
    .line 646
    goto/16 :goto_5

    .line 647
    .line 648
    :cond_13
    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    .line 649
    .line 650
    .line 651
    move-result p0

    .line 652
    if-eqz p0, :cond_14

    .line 653
    .line 654
    sget-object v1, Lx12;->h:Lx12;

    .line 655
    .line 656
    :cond_14
    return-object v1

    .line 657
    :pswitch_c
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 658
    .line 659
    check-cast v0, Le23;

    .line 660
    .line 661
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 662
    .line 663
    check-cast p0, Lav5;

    .line 664
    .line 665
    iget-object v1, v0, Le23;->h:Lc23;

    .line 666
    .line 667
    iget-object p0, p0, Lav5;->h:Ljava/lang/Object;

    .line 668
    .line 669
    check-cast p0, Lwl6;

    .line 670
    .line 671
    invoke-virtual {v1, v0, p0}, Lc23;->a(Le23;Lwl6;)V

    .line 672
    .line 673
    .line 674
    sget-object p0, Los7;->a:Los7;

    .line 675
    .line 676
    return-object p0

    .line 677
    :pswitch_d
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 678
    .line 679
    check-cast v0, Lyp;

    .line 680
    .line 681
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 682
    .line 683
    check-cast p0, Lwl6;

    .line 684
    .line 685
    new-instance v1, Lav5;

    .line 686
    .line 687
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 688
    .line 689
    .line 690
    iget-object v0, v0, Lyp;->j:Ljava/lang/Object;

    .line 691
    .line 692
    move-object v2, v0

    .line 693
    check-cast v2, Le23;

    .line 694
    .line 695
    iget-object v4, v2, Le23;->E:Lm23;

    .line 696
    .line 697
    monitor-enter v4

    .line 698
    :try_start_0
    monitor-enter v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 699
    :try_start_1
    iget-object v0, v2, Le23;->z:Lwl6;

    .line 700
    .line 701
    new-instance v8, Lwl6;

    .line 702
    .line 703
    invoke-direct {v8}, Lwl6;-><init>()V

    .line 704
    .line 705
    .line 706
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 707
    .line 708
    .line 709
    move v9, v5

    .line 710
    :goto_9
    const/16 v10, 0xa

    .line 711
    .line 712
    if-ge v9, v10, :cond_16

    .line 713
    .line 714
    shl-int v10, v7, v9

    .line 715
    .line 716
    iget v11, v0, Lwl6;->a:I

    .line 717
    .line 718
    and-int/2addr v11, v10

    .line 719
    if-eqz v11, :cond_15

    .line 720
    .line 721
    iget-object v10, v0, Lwl6;->b:[I

    .line 722
    .line 723
    aget v10, v10, v9

    .line 724
    .line 725
    invoke-virtual {v8, v9, v10}, Lwl6;->b(II)V

    .line 726
    .line 727
    .line 728
    :cond_15
    add-int/lit8 v9, v9, 0x1

    .line 729
    .line 730
    goto :goto_9

    .line 731
    :cond_16
    move v9, v5

    .line 732
    :goto_a
    if-ge v9, v10, :cond_18

    .line 733
    .line 734
    shl-int v11, v7, v9

    .line 735
    .line 736
    iget v12, p0, Lwl6;->a:I

    .line 737
    .line 738
    and-int/2addr v12, v11

    .line 739
    if-eqz v12, :cond_17

    .line 740
    .line 741
    iget-object v11, p0, Lwl6;->b:[I

    .line 742
    .line 743
    aget v11, v11, v9

    .line 744
    .line 745
    invoke-virtual {v8, v9, v11}, Lwl6;->b(II)V

    .line 746
    .line 747
    .line 748
    :cond_17
    add-int/lit8 v9, v9, 0x1

    .line 749
    .line 750
    goto :goto_a

    .line 751
    :cond_18
    iput-object v8, v1, Lav5;->h:Ljava/lang/Object;

    .line 752
    .line 753
    invoke-virtual {v8}, Lwl6;->a()I

    .line 754
    .line 755
    .line 756
    move-result p0

    .line 757
    int-to-long v7, p0

    .line 758
    invoke-virtual {v0}, Lwl6;->a()I

    .line 759
    .line 760
    .line 761
    move-result p0

    .line 762
    int-to-long v9, p0

    .line 763
    sub-long/2addr v7, v9

    .line 764
    const-wide/16 v9, 0x0

    .line 765
    .line 766
    cmp-long p0, v7, v9

    .line 767
    .line 768
    if-eqz p0, :cond_19

    .line 769
    .line 770
    iget-object v0, v2, Le23;->i:Ljava/util/LinkedHashMap;

    .line 771
    .line 772
    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    .line 773
    .line 774
    .line 775
    move-result v0

    .line 776
    if-nez v0, :cond_19

    .line 777
    .line 778
    iget-object v0, v2, Le23;->i:Ljava/util/LinkedHashMap;

    .line 779
    .line 780
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 781
    .line 782
    .line 783
    move-result-object v0

    .line 784
    new-array v6, v5, [Ll23;

    .line 785
    .line 786
    invoke-interface {v0, v6}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 787
    .line 788
    .line 789
    move-result-object v0

    .line 790
    move-object v6, v0

    .line 791
    check-cast v6, [Ll23;

    .line 792
    .line 793
    :cond_19
    iget-object v0, v1, Lav5;->h:Ljava/lang/Object;

    .line 794
    .line 795
    check-cast v0, Lwl6;

    .line 796
    .line 797
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 798
    .line 799
    .line 800
    iput-object v0, v2, Le23;->z:Lwl6;

    .line 801
    .line 802
    iget-object v9, v2, Le23;->q:Lt87;

    .line 803
    .line 804
    new-instance v0, Ljava/lang/StringBuilder;

    .line 805
    .line 806
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 807
    .line 808
    .line 809
    iget-object v10, v2, Le23;->j:Ljava/lang/String;

    .line 810
    .line 811
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 812
    .line 813
    .line 814
    const-string v10, " onSettings"

    .line 815
    .line 816
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 817
    .line 818
    .line 819
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 820
    .line 821
    .line 822
    move-result-object v10

    .line 823
    new-instance v13, Lqn1;

    .line 824
    .line 825
    invoke-direct {v13, v2, v1, v3}, Lqn1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 826
    .line 827
    .line 828
    const/4 v14, 0x6

    .line 829
    const-wide/16 v11, 0x0

    .line 830
    .line 831
    invoke-static/range {v9 .. v14}, Lt87;->c(Lt87;Ljava/lang/String;JLwg2;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 832
    .line 833
    .line 834
    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 835
    :try_start_3
    iget-object v0, v2, Le23;->E:Lm23;

    .line 836
    .line 837
    iget-object v1, v1, Lav5;->h:Ljava/lang/Object;

    .line 838
    .line 839
    check-cast v1, Lwl6;

    .line 840
    .line 841
    invoke-virtual {v0, v1}, Lm23;->b(Lwl6;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 842
    .line 843
    .line 844
    goto :goto_b

    .line 845
    :catch_0
    move-exception v0

    .line 846
    :try_start_4
    sget-object v1, Ln32;->k:Ln32;

    .line 847
    .line 848
    invoke-virtual {v2, v1, v1, v0}, Le23;->b(Ln32;Ln32;Ljava/io/IOException;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 849
    .line 850
    .line 851
    :goto_b
    monitor-exit v4

    .line 852
    if-eqz v6, :cond_1b

    .line 853
    .line 854
    array-length v0, v6

    .line 855
    :goto_c
    if-ge v5, v0, :cond_1b

    .line 856
    .line 857
    aget-object v1, v6, v5

    .line 858
    .line 859
    monitor-enter v1

    .line 860
    :try_start_5
    iget-wide v2, v1, Ll23;->l:J

    .line 861
    .line 862
    add-long/2addr v2, v7

    .line 863
    iput-wide v2, v1, Ll23;->l:J

    .line 864
    .line 865
    if-lez p0, :cond_1a

    .line 866
    .line 867
    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 868
    .line 869
    .line 870
    :cond_1a
    monitor-exit v1

    .line 871
    add-int/lit8 v5, v5, 0x1

    .line 872
    .line 873
    goto :goto_c

    .line 874
    :catchall_0
    move-exception v0

    .line 875
    move-object p0, v0

    .line 876
    monitor-exit v1

    .line 877
    throw p0

    .line 878
    :cond_1b
    sget-object p0, Los7;->a:Los7;

    .line 879
    .line 880
    return-object p0

    .line 881
    :catchall_1
    move-exception v0

    .line 882
    move-object p0, v0

    .line 883
    :try_start_6
    monitor-exit v2

    .line 884
    throw p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 885
    :catchall_2
    move-exception v0

    .line 886
    move-object p0, v0

    .line 887
    monitor-exit v4

    .line 888
    throw p0

    .line 889
    :pswitch_e
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 890
    .line 891
    move-object v1, v0

    .line 892
    check-cast v1, Le23;

    .line 893
    .line 894
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 895
    .line 896
    check-cast p0, Ll23;

    .line 897
    .line 898
    :try_start_7
    iget-object v0, v1, Le23;->h:Lc23;

    .line 899
    .line 900
    invoke-virtual {v0, p0}, Lc23;->c(Ll23;)V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_1

    .line 901
    .line 902
    .line 903
    goto :goto_d

    .line 904
    :catch_1
    move-exception v0

    .line 905
    sget-object v2, Lra5;->a:Lz9;

    .line 906
    .line 907
    sget-object v2, Lra5;->a:Lz9;

    .line 908
    .line 909
    new-instance v3, Ljava/lang/StringBuilder;

    .line 910
    .line 911
    const-string v4, "Http2Connection.Listener failure for "

    .line 912
    .line 913
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 914
    .line 915
    .line 916
    iget-object v1, v1, Le23;->j:Ljava/lang/String;

    .line 917
    .line 918
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 919
    .line 920
    .line 921
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 922
    .line 923
    .line 924
    move-result-object v1

    .line 925
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 926
    .line 927
    .line 928
    const-string v2, "OkHttp"

    .line 929
    .line 930
    invoke-static {v2, v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 931
    .line 932
    .line 933
    :try_start_8
    sget-object v1, Ln32;->k:Ln32;

    .line 934
    .line 935
    invoke-virtual {p0, v1, v0}, Ll23;->d(Ln32;Ljava/io/IOException;)V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_2

    .line 936
    .line 937
    .line 938
    :catch_2
    :goto_d
    sget-object p0, Los7;->a:Los7;

    .line 939
    .line 940
    return-object p0

    .line 941
    :pswitch_f
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 942
    .line 943
    check-cast v0, Lgs2;

    .line 944
    .line 945
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 946
    .line 947
    check-cast p0, Lga4;

    .line 948
    .line 949
    invoke-virtual {v0, p0}, Lgs2;->d(Lga4;)V

    .line 950
    .line 951
    .line 952
    sget-object p0, Los7;->a:Los7;

    .line 953
    .line 954
    return-object p0

    .line 955
    :pswitch_10
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 956
    .line 957
    check-cast v0, Lum2;

    .line 958
    .line 959
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 960
    .line 961
    check-cast p0, Lvg;

    .line 962
    .line 963
    iget-object v0, v0, Lum2;->o:Lf75;

    .line 964
    .line 965
    invoke-virtual {v0, p0}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 966
    .line 967
    .line 968
    sget-object p0, Los7;->a:Los7;

    .line 969
    .line 970
    return-object p0

    .line 971
    :pswitch_11
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 972
    .line 973
    check-cast v0, Lpn7;

    .line 974
    .line 975
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 976
    .line 977
    check-cast p0, Lbj;

    .line 978
    .line 979
    iget-object v0, v0, Lpn7;->o:Lf75;

    .line 980
    .line 981
    invoke-virtual {v0}, Lf75;->getValue()Ljava/lang/Object;

    .line 982
    .line 983
    .line 984
    move-result-object v0

    .line 985
    check-cast v0, Ljava/lang/Number;

    .line 986
    .line 987
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 988
    .line 989
    .line 990
    move-result v0

    .line 991
    iget-object p0, p0, Lbj;->i:Lf75;

    .line 992
    .line 993
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 994
    .line 995
    .line 996
    move-result-object p0

    .line 997
    check-cast p0, Ljava/lang/Number;

    .line 998
    .line 999
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 1000
    .line 1001
    .line 1002
    move-result p0

    .line 1003
    invoke-static {v0, p0}, Lkk;->Y(FF)F

    .line 1004
    .line 1005
    .line 1006
    move-result p0

    .line 1007
    invoke-static {p0, v2, v1}, Ls33;->D(FFF)F

    .line 1008
    .line 1009
    .line 1010
    move-result p0

    .line 1011
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1012
    .line 1013
    .line 1014
    move-result-object p0

    .line 1015
    return-object p0

    .line 1016
    :pswitch_12
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1017
    .line 1018
    check-cast v0, Lum2;

    .line 1019
    .line 1020
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1021
    .line 1022
    check-cast p0, Lgn2;

    .line 1023
    .line 1024
    iget-object v0, v0, Lum2;->e:Lf75;

    .line 1025
    .line 1026
    invoke-virtual {v0, p0}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 1027
    .line 1028
    .line 1029
    sget-object p0, Los7;->a:Los7;

    .line 1030
    .line 1031
    return-object p0

    .line 1032
    :pswitch_13
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1033
    .line 1034
    check-cast v0, Lpn7;

    .line 1035
    .line 1036
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1037
    .line 1038
    check-cast p0, Lxy6;

    .line 1039
    .line 1040
    invoke-interface {p0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 1041
    .line 1042
    .line 1043
    move-result-object p0

    .line 1044
    check-cast p0, Ljava/lang/Boolean;

    .line 1045
    .line 1046
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1047
    .line 1048
    .line 1049
    move-result p0

    .line 1050
    if-nez p0, :cond_1d

    .line 1051
    .line 1052
    iget-object p0, v0, Lpn7;->o:Lf75;

    .line 1053
    .line 1054
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 1055
    .line 1056
    .line 1057
    move-result-object p0

    .line 1058
    check-cast p0, Ljava/lang/Number;

    .line 1059
    .line 1060
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 1061
    .line 1062
    .line 1063
    move-result p0

    .line 1064
    cmpl-float p0, p0, v2

    .line 1065
    .line 1066
    if-lez p0, :cond_1e

    .line 1067
    .line 1068
    goto :goto_f

    .line 1069
    :pswitch_14
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1070
    .line 1071
    check-cast v0, Lg00;

    .line 1072
    .line 1073
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1074
    .line 1075
    check-cast p0, Lvg;

    .line 1076
    .line 1077
    if-eqz v0, :cond_1e

    .line 1078
    .line 1079
    invoke-virtual {p0}, Lvg;->getValue()Ljava/lang/Object;

    .line 1080
    .line 1081
    .line 1082
    move-result-object p0

    .line 1083
    check-cast p0, Ljava/lang/Number;

    .line 1084
    .line 1085
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 1086
    .line 1087
    .line 1088
    move-result p0

    .line 1089
    const v0, 0x3a83126f    # 0.001f

    .line 1090
    .line 1091
    .line 1092
    cmpl-float p0, p0, v0

    .line 1093
    .line 1094
    if-lez p0, :cond_1e

    .line 1095
    .line 1096
    goto :goto_f

    .line 1097
    :pswitch_15
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1098
    .line 1099
    check-cast v0, Lsm2;

    .line 1100
    .line 1101
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1102
    .line 1103
    check-cast p0, Ljava/util/List;

    .line 1104
    .line 1105
    iget-object v2, v0, Lsm2;->a:Lf75;

    .line 1106
    .line 1107
    invoke-virtual {v2}, Lf75;->getValue()Ljava/lang/Object;

    .line 1108
    .line 1109
    .line 1110
    move-result-object v2

    .line 1111
    check-cast v2, Ljava/lang/Boolean;

    .line 1112
    .line 1113
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1114
    .line 1115
    .line 1116
    move-result v2

    .line 1117
    if-eqz v2, :cond_1e

    .line 1118
    .line 1119
    iget-object v0, v0, Lsm2;->b:Lug;

    .line 1120
    .line 1121
    invoke-virtual {v0}, Lug;->e()Ljava/lang/Object;

    .line 1122
    .line 1123
    .line 1124
    move-result-object v0

    .line 1125
    check-cast v0, Ljava/lang/Number;

    .line 1126
    .line 1127
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 1128
    .line 1129
    .line 1130
    move-result v0

    .line 1131
    cmpg-float v0, v0, v1

    .line 1132
    .line 1133
    if-nez v0, :cond_1e

    .line 1134
    .line 1135
    if-eqz p0, :cond_1c

    .line 1136
    .line 1137
    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    .line 1138
    .line 1139
    .line 1140
    move-result v0

    .line 1141
    if-nez v0, :cond_1d

    .line 1142
    .line 1143
    :cond_1c
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1144
    .line 1145
    .line 1146
    move-result-object p0

    .line 1147
    :goto_e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 1148
    .line 1149
    .line 1150
    move-result v0

    .line 1151
    if-eqz v0, :cond_1d

    .line 1152
    .line 1153
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1154
    .line 1155
    .line 1156
    move-result-object v0

    .line 1157
    check-cast v0, Lug;

    .line 1158
    .line 1159
    invoke-virtual {v0}, Lug;->e()Ljava/lang/Object;

    .line 1160
    .line 1161
    .line 1162
    move-result-object v0

    .line 1163
    check-cast v0, Ljava/lang/Number;

    .line 1164
    .line 1165
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 1166
    .line 1167
    .line 1168
    move-result v0

    .line 1169
    cmpg-float v0, v0, v1

    .line 1170
    .line 1171
    if-nez v0, :cond_1e

    .line 1172
    .line 1173
    goto :goto_e

    .line 1174
    :cond_1d
    :goto_f
    move v5, v7

    .line 1175
    :cond_1e
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1176
    .line 1177
    .line 1178
    move-result-object p0

    .line 1179
    return-object p0

    .line 1180
    :pswitch_16
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1181
    .line 1182
    check-cast v0, Ljava/util/List;

    .line 1183
    .line 1184
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1185
    .line 1186
    check-cast p0, Ljava/util/List;

    .line 1187
    .line 1188
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 1189
    .line 1190
    .line 1191
    move-result p0

    .line 1192
    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1193
    .line 1194
    .line 1195
    move-result-object p0

    .line 1196
    check-cast p0, Lug;

    .line 1197
    .line 1198
    invoke-virtual {p0}, Lug;->e()Ljava/lang/Object;

    .line 1199
    .line 1200
    .line 1201
    move-result-object p0

    .line 1202
    check-cast p0, Ljava/lang/Number;

    .line 1203
    .line 1204
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 1205
    .line 1206
    .line 1207
    move-result p0

    .line 1208
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1209
    .line 1210
    .line 1211
    move-result-object p0

    .line 1212
    return-object p0

    .line 1213
    :pswitch_17
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1214
    .line 1215
    check-cast v0, Lki2;

    .line 1216
    .line 1217
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1218
    .line 1219
    check-cast p0, Lnb4;

    .line 1220
    .line 1221
    iget-object v1, p0, Lnb4;->a:Llb4;

    .line 1222
    .line 1223
    iget-object v2, p0, Lnb4;->g:Lr95;

    .line 1224
    .line 1225
    iget-object p0, p0, Lnb4;->b:Ljava/lang/Object;

    .line 1226
    .line 1227
    invoke-virtual {v0, v1, v2, p0, v7}, Lki2;->J(Llb4;Lr95;Ljava/lang/Object;Z)V

    .line 1228
    .line 1229
    .line 1230
    sget-object p0, Los7;->a:Los7;

    .line 1231
    .line 1232
    return-object p0

    .line 1233
    :pswitch_18
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1234
    .line 1235
    check-cast v0, Lav5;

    .line 1236
    .line 1237
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1238
    .line 1239
    check-cast p0, Loe2;

    .line 1240
    .line 1241
    sget-object v1, Lja5;->a:Lcx1;

    .line 1242
    .line 1243
    invoke-static {p0, v1}, Lxj;->N(Lr51;Lch5;)Ljava/lang/Object;

    .line 1244
    .line 1245
    .line 1246
    move-result-object p0

    .line 1247
    iput-object p0, v0, Lav5;->h:Ljava/lang/Object;

    .line 1248
    .line 1249
    sget-object p0, Los7;->a:Los7;

    .line 1250
    .line 1251
    return-object p0

    .line 1252
    :pswitch_19
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1253
    .line 1254
    check-cast v0, Lav5;

    .line 1255
    .line 1256
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1257
    .line 1258
    check-cast p0, Lje2;

    .line 1259
    .line 1260
    invoke-virtual {p0}, Lje2;->I1()Lxd2;

    .line 1261
    .line 1262
    .line 1263
    move-result-object p0

    .line 1264
    iput-object p0, v0, Lav5;->h:Ljava/lang/Object;

    .line 1265
    .line 1266
    sget-object p0, Los7;->a:Los7;

    .line 1267
    .line 1268
    return-object p0

    .line 1269
    :pswitch_1a
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1270
    .line 1271
    check-cast v0, Lav5;

    .line 1272
    .line 1273
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1274
    .line 1275
    check-cast p0, Lhe2;

    .line 1276
    .line 1277
    sget-object v1, Lja5;->a:Lcx1;

    .line 1278
    .line 1279
    invoke-static {p0, v1}, Lxj;->N(Lr51;Lch5;)Ljava/lang/Object;

    .line 1280
    .line 1281
    .line 1282
    move-result-object p0

    .line 1283
    iput-object p0, v0, Lav5;->h:Ljava/lang/Object;

    .line 1284
    .line 1285
    sget-object p0, Los7;->a:Los7;

    .line 1286
    .line 1287
    return-object p0

    .line 1288
    :pswitch_1b
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1289
    .line 1290
    check-cast v0, Lga7;

    .line 1291
    .line 1292
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1293
    .line 1294
    check-cast p0, Lla7;

    .line 1295
    .line 1296
    iget-object v0, v0, Lga7;->d:Lhh2;

    .line 1297
    .line 1298
    invoke-interface {v0, p0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1299
    .line 1300
    .line 1301
    sget-object p0, Los7;->a:Los7;

    .line 1302
    .line 1303
    return-object p0

    .line 1304
    :pswitch_1c
    iget-object v0, p0, Lqn1;->i:Ljava/lang/Object;

    .line 1305
    .line 1306
    check-cast v0, Laa7;

    .line 1307
    .line 1308
    iget-object p0, p0, Lqn1;->j:Ljava/lang/Object;

    .line 1309
    .line 1310
    check-cast p0, Lwg2;

    .line 1311
    .line 1312
    invoke-interface {p0}, Lwg2;->a()Ljava/lang/Object;

    .line 1313
    .line 1314
    .line 1315
    move-result-object p0

    .line 1316
    check-cast p0, Lfi3;

    .line 1317
    .line 1318
    invoke-interface {v0, p0}, Laa7;->t(Lfi3;)J

    .line 1319
    .line 1320
    .line 1321
    move-result-wide v0

    .line 1322
    invoke-static {v0, v1}, Lv43;->f0(J)J

    .line 1323
    .line 1324
    .line 1325
    move-result-wide v0

    .line 1326
    new-instance p0, Lm93;

    .line 1327
    .line 1328
    invoke-direct {p0, v0, v1}, Lm93;-><init>(J)V

    .line 1329
    .line 1330
    .line 1331
    return-object p0

    .line 1332
    nop

    .line 1333
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
