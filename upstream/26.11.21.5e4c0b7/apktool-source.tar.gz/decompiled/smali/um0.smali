.class public final Lum0;
.super Lf57;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic l:B

.field public m:Z

.field public final synthetic n:F

.field public o:Ljava/lang/Object;

.field public synthetic p:Ljava/lang/Object;

.field public final synthetic q:Ljava/lang/Object;


# direct methods
.method public constructor <init>(FLaj;Lxu5;Lfd1;)V
    .locals 1

    const/4 v0, 0x5

    iput-byte v0, p0, Lum0;->l:B

    .line 18
    iput p1, p0, Lum0;->n:F

    iput-object p2, p0, Lum0;->p:Ljava/lang/Object;

    iput-object p3, p0, Lum0;->q:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lf57;-><init>(ILfd1;)V

    return-void
.end method

.method public constructor <init>(Lfg4;FLcg4;Lfd1;)V
    .locals 1

    const/4 v0, 0x3

    iput-byte v0, p0, Lum0;->l:B

    .line 19
    iput-object p1, p0, Lum0;->p:Ljava/lang/Object;

    iput p2, p0, Lum0;->n:F

    iput-object p3, p0, Lum0;->q:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lf57;-><init>(ILfd1;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Lfd1;B)V
    .locals 0

    .line 20
    iput-byte p6, p0, Lum0;->l:B

    iput-object p1, p0, Lum0;->o:Ljava/lang/Object;

    iput p2, p0, Lum0;->n:F

    iput-object p3, p0, Lum0;->p:Ljava/lang/Object;

    iput-object p4, p0, Lum0;->q:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lf57;-><init>(ILfd1;)V

    return-void
.end method

.method public constructor <init>(Lmh2;Lvt7;FLwu5;Lfd1;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lum0;->l:B

    .line 3
    .line 4
    iput-object p1, p0, Lum0;->o:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Lum0;->p:Ljava/lang/Object;

    .line 7
    .line 8
    iput p3, p0, Lum0;->n:F

    .line 9
    .line 10
    iput-object p4, p0, Lum0;->q:Ljava/lang/Object;

    .line 11
    .line 12
    const/4 p1, 0x2

    .line 13
    invoke-direct {p0, p1, p5}, Lf57;-><init>(ILfd1;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Log0;FLfd1;)V
    .locals 1

    const/4 v0, 0x4

    iput-byte v0, p0, Lum0;->l:B

    .line 17
    iput-object p1, p0, Lum0;->q:Ljava/lang/Object;

    iput p2, p0, Lum0;->n:F

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lf57;-><init>(ILfd1;)V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lum0;->l:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lwf6;

    .line 9
    .line 10
    check-cast p2, Lfd1;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lum0;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lum0;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lum0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    check-cast p1, Lwf6;

    .line 24
    .line 25
    check-cast p2, Lfd1;

    .line 26
    .line 27
    invoke-virtual {p0, p2, p1}, Lum0;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lum0;

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Lum0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_1
    check-cast p1, Lwg2;

    .line 39
    .line 40
    check-cast p2, Lfd1;

    .line 41
    .line 42
    invoke-virtual {p0, p2, p1}, Lum0;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Lum0;

    .line 47
    .line 48
    invoke-virtual {p0, v1}, Lum0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_2
    check-cast p1, Lri1;

    .line 54
    .line 55
    check-cast p2, Lfd1;

    .line 56
    .line 57
    invoke-virtual {p0, p2, p1}, Lum0;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    check-cast p0, Lum0;

    .line 62
    .line 63
    invoke-virtual {p0, v1}, Lum0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    return-object p0

    .line 68
    :pswitch_3
    check-cast p1, Lri1;

    .line 69
    .line 70
    check-cast p2, Lfd1;

    .line 71
    .line 72
    invoke-virtual {p0, p2, p1}, Lum0;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    check-cast p0, Lum0;

    .line 77
    .line 78
    invoke-virtual {p0, v1}, Lum0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    return-object p0

    .line 83
    :pswitch_4
    check-cast p1, Lri1;

    .line 84
    .line 85
    check-cast p2, Lfd1;

    .line 86
    .line 87
    invoke-virtual {p0, p2, p1}, Lum0;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    check-cast p0, Lum0;

    .line 92
    .line 93
    invoke-virtual {p0, v1}, Lum0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    return-object p0

    .line 98
    nop

    .line 99
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final s(Lfd1;Ljava/lang/Object;)Lfd1;
    .locals 11

    .line 1
    iget-byte v0, p0, Lum0;->l:B

    .line 2
    .line 3
    iget v1, p0, Lum0;->n:F

    .line 4
    .line 5
    iget-object v2, p0, Lum0;->q:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    new-instance v0, Lum0;

    .line 11
    .line 12
    iget-object p0, p0, Lum0;->p:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p0, Laj;

    .line 15
    .line 16
    check-cast v2, Lxu5;

    .line 17
    .line 18
    invoke-direct {v0, v1, p0, v2, p1}, Lum0;-><init>(FLaj;Lxu5;Lfd1;)V

    .line 19
    .line 20
    .line 21
    iput-object p2, v0, Lum0;->o:Ljava/lang/Object;

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_0
    new-instance p0, Lum0;

    .line 25
    .line 26
    check-cast v2, Log0;

    .line 27
    .line 28
    invoke-direct {p0, v2, v1, p1}, Lum0;-><init>(Log0;FLfd1;)V

    .line 29
    .line 30
    .line 31
    iput-object p2, p0, Lum0;->p:Ljava/lang/Object;

    .line 32
    .line 33
    return-object p0

    .line 34
    :pswitch_1
    new-instance v0, Lum0;

    .line 35
    .line 36
    iget-object p0, p0, Lum0;->p:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p0, Lfg4;

    .line 39
    .line 40
    check-cast v2, Lcg4;

    .line 41
    .line 42
    invoke-direct {v0, p0, v1, v2, p1}, Lum0;-><init>(Lfg4;FLcg4;Lfd1;)V

    .line 43
    .line 44
    .line 45
    iput-object p2, v0, Lum0;->o:Ljava/lang/Object;

    .line 46
    .line 47
    return-object v0

    .line 48
    :pswitch_2
    new-instance v3, Lum0;

    .line 49
    .line 50
    iget-object p2, p0, Lum0;->o:Ljava/lang/Object;

    .line 51
    .line 52
    move-object v4, p2

    .line 53
    check-cast v4, Lin0;

    .line 54
    .line 55
    iget-object p2, p0, Lum0;->p:Ljava/lang/Object;

    .line 56
    .line 57
    move-object v6, p2

    .line 58
    check-cast v6, Lwm0;

    .line 59
    .line 60
    move-object v7, v2

    .line 61
    check-cast v7, Lpn0;

    .line 62
    .line 63
    const/4 v9, 0x2

    .line 64
    iget v5, p0, Lum0;->n:F

    .line 65
    .line 66
    move-object v8, p1

    .line 67
    invoke-direct/range {v3 .. v9}, Lum0;-><init>(Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Lfd1;B)V

    .line 68
    .line 69
    .line 70
    return-object v3

    .line 71
    :pswitch_3
    move-object v9, p1

    .line 72
    new-instance v4, Lum0;

    .line 73
    .line 74
    iget-object p1, p0, Lum0;->o:Ljava/lang/Object;

    .line 75
    .line 76
    move-object v5, p1

    .line 77
    check-cast v5, Lmh2;

    .line 78
    .line 79
    iget-object p1, p0, Lum0;->p:Ljava/lang/Object;

    .line 80
    .line 81
    move-object v6, p1

    .line 82
    check-cast v6, Lvt7;

    .line 83
    .line 84
    iget v7, p0, Lum0;->n:F

    .line 85
    .line 86
    move-object v8, v2

    .line 87
    check-cast v8, Lwu5;

    .line 88
    .line 89
    invoke-direct/range {v4 .. v9}, Lum0;-><init>(Lmh2;Lvt7;FLwu5;Lfd1;)V

    .line 90
    .line 91
    .line 92
    return-object v4

    .line 93
    :pswitch_4
    move-object v9, p1

    .line 94
    new-instance v4, Lum0;

    .line 95
    .line 96
    iget-object p1, p0, Lum0;->o:Ljava/lang/Object;

    .line 97
    .line 98
    move-object v5, p1

    .line 99
    check-cast v5, Luv7;

    .line 100
    .line 101
    iget-object p1, p0, Lum0;->p:Ljava/lang/Object;

    .line 102
    .line 103
    move-object v7, p1

    .line 104
    check-cast v7, Lhv4;

    .line 105
    .line 106
    move-object v8, v2

    .line 107
    check-cast v8, Lov7;

    .line 108
    .line 109
    const/4 v10, 0x0

    .line 110
    iget v6, p0, Lum0;->n:F

    .line 111
    .line 112
    invoke-direct/range {v4 .. v10}, Lum0;-><init>(Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Lfd1;B)V

    .line 113
    .line 114
    .line 115
    return-object v4

    .line 116
    nop

    .line 117
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-byte v0, p0, Lum0;->l:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget v2, p0, Lum0;->n:F

    .line 5
    .line 6
    sget-object v6, Los7;->a:Los7;

    .line 7
    .line 8
    iget-object v3, p0, Lum0;->q:Ljava/lang/Object;

    .line 9
    .line 10
    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    .line 11
    .line 12
    sget-object v7, Lsi1;->h:Lsi1;

    .line 13
    .line 14
    const/4 v8, 0x1

    .line 15
    const/4 v9, 0x0

    .line 16
    packed-switch v0, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lum0;->o:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v0, Lwf6;

    .line 22
    .line 23
    iget-boolean v1, p0, Lum0;->m:Z

    .line 24
    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    if-ne v1, v8, :cond_0

    .line 28
    .line 29
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    invoke-static {v5}, Lt32;->d(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    move-object v6, v9

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    iget-object v1, p0, Lum0;->p:Ljava/lang/Object;

    .line 42
    .line 43
    move-object v2, v1

    .line 44
    check-cast v2, Laj;

    .line 45
    .line 46
    check-cast v3, Lxu5;

    .line 47
    .line 48
    new-instance v1, Lb45;

    .line 49
    .line 50
    invoke-direct {v1, v3, v0, v8}, Lb45;-><init>(Lxu5;Lwf6;B)V

    .line 51
    .line 52
    .line 53
    iput-object v9, p0, Lum0;->o:Ljava/lang/Object;

    .line 54
    .line 55
    iput-boolean v8, p0, Lum0;->m:Z

    .line 56
    .line 57
    const/4 v0, 0x0

    .line 58
    move-object v3, v1

    .line 59
    iget v1, p0, Lum0;->n:F

    .line 60
    .line 61
    const/4 v5, 0x4

    .line 62
    move-object v4, p0

    .line 63
    invoke-static/range {v0 .. v5}, Lgk6;->e(FFLaj;Llh2;Lf57;I)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    if-ne v0, v7, :cond_2

    .line 68
    .line 69
    move-object v6, v7

    .line 70
    :cond_2
    :goto_0
    return-object v6

    .line 71
    :pswitch_0
    iget-object v0, p0, Lum0;->p:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v0, Lwf6;

    .line 74
    .line 75
    iget-boolean v1, p0, Lum0;->m:Z

    .line 76
    .line 77
    if-eqz v1, :cond_4

    .line 78
    .line 79
    if-ne v1, v8, :cond_3

    .line 80
    .line 81
    iget-object v1, p0, Lum0;->o:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v1, Llg0;

    .line 84
    .line 85
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    move-object v3, p1

    .line 89
    goto :goto_2

    .line 90
    :cond_3
    invoke-static {v5}, Lt32;->d(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    move-object v6, v9

    .line 94
    goto :goto_3

    .line 95
    :cond_4
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    check-cast v3, Log0;

    .line 99
    .line 100
    new-instance v1, Llg0;

    .line 101
    .line 102
    invoke-direct {v1, v3}, Llg0;-><init>(Log0;)V

    .line 103
    .line 104
    .line 105
    :goto_1
    iput-object v0, p0, Lum0;->p:Ljava/lang/Object;

    .line 106
    .line 107
    iput-object v1, p0, Lum0;->o:Ljava/lang/Object;

    .line 108
    .line 109
    iput-boolean v8, p0, Lum0;->m:Z

    .line 110
    .line 111
    invoke-virtual {v1, p0}, Llg0;->b(Lfd1;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v3

    .line 115
    if-ne v3, v7, :cond_5

    .line 116
    .line 117
    move-object v6, v7

    .line 118
    goto :goto_3

    .line 119
    :cond_5
    :goto_2
    check-cast v3, Ljava/lang/Boolean;

    .line 120
    .line 121
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 122
    .line 123
    .line 124
    move-result v3

    .line 125
    if-eqz v3, :cond_6

    .line 126
    .line 127
    invoke-virtual {v1}, Llg0;->c()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    check-cast v3, Ljava/lang/Number;

    .line 132
    .line 133
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 134
    .line 135
    .line 136
    move-result v3

    .line 137
    mul-float/2addr v3, v2

    .line 138
    invoke-interface {v0, v3}, Lwf6;->a(F)F

    .line 139
    .line 140
    .line 141
    goto :goto_1

    .line 142
    :cond_6
    :goto_3
    return-object v6

    .line 143
    :pswitch_1
    iget-object v0, p0, Lum0;->o:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast v0, Lwg2;

    .line 146
    .line 147
    iget-boolean v1, p0, Lum0;->m:Z

    .line 148
    .line 149
    if-eqz v1, :cond_8

    .line 150
    .line 151
    if-ne v1, v8, :cond_7

    .line 152
    .line 153
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    goto :goto_4

    .line 157
    :cond_7
    invoke-static {v5}, Lt32;->d(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    move-object v6, v9

    .line 161
    goto :goto_4

    .line 162
    :cond_8
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    iget-object v1, p0, Lum0;->p:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast v1, Lfg4;

    .line 168
    .line 169
    iget-object v1, v1, Lfg4;->a:Lug;

    .line 170
    .line 171
    check-cast v3, Lcg4;

    .line 172
    .line 173
    iput-object v9, p0, Lum0;->o:Ljava/lang/Object;

    .line 174
    .line 175
    iput-boolean v8, p0, Lum0;->m:Z

    .line 176
    .line 177
    invoke-static {v1, v2, v3, v0, p0}, Lx33;->X(Lug;FLcg4;Lwg2;Lgd1;)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    if-ne v0, v7, :cond_9

    .line 182
    .line 183
    move-object v6, v7

    .line 184
    :cond_9
    :goto_4
    return-object v6

    .line 185
    :pswitch_2
    iget-object v0, p0, Lum0;->o:Ljava/lang/Object;

    .line 186
    .line 187
    check-cast v0, Lin0;

    .line 188
    .line 189
    iget-boolean v1, p0, Lum0;->m:Z

    .line 190
    .line 191
    if-eqz v1, :cond_b

    .line 192
    .line 193
    if-ne v1, v8, :cond_a

    .line 194
    .line 195
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    goto :goto_5

    .line 199
    :cond_a
    invoke-static {v5}, Lt32;->d(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    move-object v6, v9

    .line 203
    goto :goto_6

    .line 204
    :cond_b
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    iget-object v1, v0, Lin0;->f:Lbn0;

    .line 208
    .line 209
    iget-object v5, v0, Lin0;->d:Lsc4;

    .line 210
    .line 211
    new-instance v9, Ljava/lang/Float;

    .line 212
    .line 213
    invoke-direct {v9, v2}, Ljava/lang/Float;-><init>(F)V

    .line 214
    .line 215
    .line 216
    iput-boolean v8, p0, Lum0;->m:Z

    .line 217
    .line 218
    invoke-virtual {v1, v5, v9, p0}, Lbn0;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    if-ne v1, v7, :cond_c

    .line 223
    .line 224
    move-object v6, v7

    .line 225
    goto :goto_6

    .line 226
    :cond_c
    :goto_5
    iget-object v1, p0, Lgd1;->i:Lii1;

    .line 227
    .line 228
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 229
    .line 230
    .line 231
    invoke-static {v1}, Le43;->x(Lii1;)V

    .line 232
    .line 233
    .line 234
    iget-object v1, v0, Lin0;->c:Lo84;

    .line 235
    .line 236
    iget-object v2, p0, Lum0;->p:Ljava/lang/Object;

    .line 237
    .line 238
    check-cast v2, Lwm0;

    .line 239
    .line 240
    check-cast v3, Lpn0;

    .line 241
    .line 242
    iget-object v0, v0, Lin0;->d:Lsc4;

    .line 243
    .line 244
    new-instance v4, Lsc4;

    .line 245
    .line 246
    iget-object v0, v0, Lsc4;->a:Ljava/util/LinkedHashMap;

    .line 247
    .line 248
    invoke-direct {v4, v0}, Lsc4;-><init>(Ljava/util/Map;)V

    .line 249
    .line 250
    .line 251
    invoke-virtual {v1, v2, v3, v4}, Lo84;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    :goto_6
    return-object v6

    .line 255
    :pswitch_3
    iget-boolean v0, p0, Lum0;->m:Z

    .line 256
    .line 257
    if-eqz v0, :cond_e

    .line 258
    .line 259
    if-ne v0, v8, :cond_d

    .line 260
    .line 261
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 262
    .line 263
    .line 264
    goto :goto_7

    .line 265
    :cond_d
    invoke-static {v5}, Lt32;->d(Ljava/lang/String;)V

    .line 266
    .line 267
    .line 268
    move-object v6, v9

    .line 269
    goto :goto_8

    .line 270
    :cond_e
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 271
    .line 272
    .line 273
    iget-object v0, p0, Lum0;->o:Ljava/lang/Object;

    .line 274
    .line 275
    check-cast v0, Lmh2;

    .line 276
    .line 277
    iget-object v5, p0, Lum0;->p:Ljava/lang/Object;

    .line 278
    .line 279
    check-cast v5, Lvt7;

    .line 280
    .line 281
    new-instance v9, Ljava/lang/Float;

    .line 282
    .line 283
    invoke-direct {v9, v2}, Ljava/lang/Float;-><init>(F)V

    .line 284
    .line 285
    .line 286
    iput-boolean v8, p0, Lum0;->m:Z

    .line 287
    .line 288
    invoke-interface {v0, v5, v9, p0}, Lmh2;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    if-ne v0, v7, :cond_f

    .line 293
    .line 294
    move-object v6, v7

    .line 295
    goto :goto_8

    .line 296
    :cond_f
    :goto_7
    check-cast v3, Lwu5;

    .line 297
    .line 298
    iput-boolean v1, v3, Lwu5;->h:Z

    .line 299
    .line 300
    :goto_8
    return-object v6

    .line 301
    :pswitch_4
    iget-boolean v0, p0, Lum0;->m:Z

    .line 302
    .line 303
    if-eqz v0, :cond_11

    .line 304
    .line 305
    if-ne v0, v8, :cond_10

    .line 306
    .line 307
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 308
    .line 309
    .line 310
    goto :goto_9

    .line 311
    :cond_10
    invoke-static {v5}, Lt32;->d(Ljava/lang/String;)V

    .line 312
    .line 313
    .line 314
    move-object v6, v9

    .line 315
    goto :goto_9

    .line 316
    :cond_11
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 317
    .line 318
    .line 319
    iget-object v0, p0, Lum0;->o:Ljava/lang/Object;

    .line 320
    .line 321
    check-cast v0, Luv7;

    .line 322
    .line 323
    iget-object v5, p0, Lum0;->p:Ljava/lang/Object;

    .line 324
    .line 325
    check-cast v5, Lhv4;

    .line 326
    .line 327
    iget-wide v9, v5, Lhv4;->a:J

    .line 328
    .line 329
    const/16 v5, 0x20

    .line 330
    .line 331
    shr-long/2addr v9, v5

    .line 332
    long-to-int v5, v9

    .line 333
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 334
    .line 335
    .line 336
    move-result v5

    .line 337
    check-cast v3, Lov7;

    .line 338
    .line 339
    new-instance v9, Ltm0;

    .line 340
    .line 341
    invoke-direct {v9, v3, v1}, Ltm0;-><init>(Lov7;B)V

    .line 342
    .line 343
    .line 344
    iput-boolean v8, p0, Lum0;->m:Z

    .line 345
    .line 346
    invoke-virtual {v0, v2, v5, v9, p0}, Luv7;->b(FFLtm0;Lgd1;)Ljava/lang/Object;

    .line 347
    .line 348
    .line 349
    move-result-object v0

    .line 350
    if-ne v0, v7, :cond_12

    .line 351
    .line 352
    move-object v6, v7

    .line 353
    :cond_12
    :goto_9
    return-object v6

    .line 354
    nop

    .line 355
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
