.class public abstract Lpa4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lfa4;


# virtual methods
.method public a()Lga4;
    .locals 1

    .line 1
    new-instance p0, Lvx;

    .line 2
    .line 3
    invoke-direct {p0}, Lga4;-><init>()V

    .line 4
    .line 5
    .line 6
    const/high16 v0, 0x3f800000    # 1.0f

    .line 7
    .line 8
    iput v0, p0, Lvx;->v:F

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    iput-boolean v0, p0, Lvx;->w:Z

    .line 12
    .line 13
    return-object p0
.end method

.method public b(Lga4;)V
    .locals 0

    .line 1
    check-cast p1, Lta;

    .line 2
    .line 3
    return-void
.end method
