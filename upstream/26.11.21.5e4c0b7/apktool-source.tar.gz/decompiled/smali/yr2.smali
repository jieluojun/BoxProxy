.class public abstract Lyr2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lcx1;

.field public static final b:Lcx1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lyg1;

    .line 2
    .line 3
    const/16 v1, 0xf

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lyg1;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lcx1;

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Lyr2;->a:Lcx1;

    .line 15
    .line 16
    new-instance v0, Lyg1;

    .line 17
    .line 18
    const/16 v1, 0x10

    .line 19
    .line 20
    invoke-direct {v0, v1}, Lyg1;-><init>(B)V

    .line 21
    .line 22
    .line 23
    new-instance v1, Lcx1;

    .line 24
    .line 25
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 26
    .line 27
    .line 28
    sput-object v1, Lyr2;->b:Lcx1;

    .line 29
    .line 30
    return-void
.end method

.method public static final a(Ljg6;Lhh2;Lki2;I)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    const v0, -0x33476a1c    # -9.6775968E7f

    .line 8
    .line 9
    .line 10
    invoke-virtual {p2, v0}, Lki2;->i0(I)Lki2;

    .line 11
    .line 12
    .line 13
    invoke-virtual {p2, p0}, Lki2;->i(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const/4 v0, 0x4

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v0, 0x2

    .line 22
    :goto_0
    or-int/2addr v0, p3

    .line 23
    invoke-virtual {p2, p1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_1

    .line 28
    .line 29
    const/16 v1, 0x20

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_1
    const/16 v1, 0x10

    .line 33
    .line 34
    :goto_1
    or-int/2addr v0, v1

    .line 35
    and-int/lit8 v1, v0, 0x13

    .line 36
    .line 37
    const/16 v2, 0x12

    .line 38
    .line 39
    const/4 v3, 0x0

    .line 40
    const/4 v4, 0x1

    .line 41
    if-eq v1, v2, :cond_2

    .line 42
    .line 43
    move v1, v4

    .line 44
    goto :goto_2

    .line 45
    :cond_2
    move v1, v3

    .line 46
    :goto_2
    and-int/2addr v0, v4

    .line 47
    invoke-virtual {p2, v0, v1}, Lki2;->Y(IZ)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_6

    .line 52
    .line 53
    sget-object v0, Lyr2;->b:Lcx1;

    .line 54
    .line 55
    invoke-virtual {p2, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, Ltr2;

    .line 60
    .line 61
    if-nez v0, :cond_3

    .line 62
    .line 63
    invoke-virtual {p2}, Lki2;->w()Lhu5;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    if-eqz p2, :cond_7

    .line 68
    .line 69
    new-instance v0, Lur2;

    .line 70
    .line 71
    invoke-direct {v0, p0, p1, p3, v3}, Lur2;-><init>(Ljg6;Lhh2;IB)V

    .line 72
    .line 73
    .line 74
    :goto_3
    iput-object v0, p2, Lhu5;->d:Llh2;

    .line 75
    .line 76
    return-void

    .line 77
    :cond_3
    invoke-static {p1, p2}, Lzi6;->x(Ljava/lang/Object;Lki2;)Lzd4;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    invoke-virtual {p2, v0}, Lki2;->i(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    invoke-virtual {p2, p0}, Lki2;->i(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v3

    .line 89
    or-int/2addr v2, v3

    .line 90
    invoke-virtual {p2, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    or-int/2addr v2, v3

    .line 95
    invoke-virtual {p2}, Lki2;->T()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v3

    .line 99
    if-nez v2, :cond_4

    .line 100
    .line 101
    sget-object v2, Lz41;->a:Lql0;

    .line 102
    .line 103
    if-ne v3, v2, :cond_5

    .line 104
    .line 105
    :cond_4
    new-instance v3, Lbg;

    .line 106
    .line 107
    const/16 v2, 0x19

    .line 108
    .line 109
    invoke-direct {v3, v0, p0, v1, v2}, Lbg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {p2, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    :cond_5
    check-cast v3, Lhh2;

    .line 116
    .line 117
    invoke-static {v0, p0, v3, p2}, Lnt7;->d(Ljava/lang/Object;Ljava/lang/Object;Lhh2;Lki2;)V

    .line 118
    .line 119
    .line 120
    goto :goto_4

    .line 121
    :cond_6
    invoke-virtual {p2}, Lki2;->b0()V

    .line 122
    .line 123
    .line 124
    :goto_4
    invoke-virtual {p2}, Lki2;->w()Lhu5;

    .line 125
    .line 126
    .line 127
    move-result-object p2

    .line 128
    if-eqz p2, :cond_7

    .line 129
    .line 130
    new-instance v0, Lur2;

    .line 131
    .line 132
    invoke-direct {v0, p0, p1, p3, v4}, Lur2;-><init>(Ljg6;Lhh2;IB)V

    .line 133
    .line 134
    .line 135
    goto :goto_3

    .line 136
    :cond_7
    return-void
.end method

.method public static final b(Lha4;Lki2;I)Lha4;
    .locals 8

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const v0, -0x769e7523

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1, v0}, Lki2;->h0(I)V

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    and-int/2addr p2, v0

    .line 12
    const/4 v1, 0x0

    .line 13
    if-eqz p2, :cond_0

    .line 14
    .line 15
    move v0, v1

    .line 16
    :cond_0
    sget-object p2, Lyr2;->a:Lcx1;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    move-object v3, p2

    .line 23
    check-cast v3, Las2;

    .line 24
    .line 25
    if-nez v3, :cond_1

    .line 26
    .line 27
    invoke-virtual {p1, v1}, Lki2;->r(Z)V

    .line 28
    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1
    sget-object p2, Lw51;->o:Lx51;

    .line 32
    .line 33
    invoke-virtual {p1, p2}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    check-cast p2, Llw7;

    .line 38
    .line 39
    invoke-interface {p2}, Llw7;->h()J

    .line 40
    .line 41
    .line 42
    move-result-wide v4

    .line 43
    sget-object p2, Lw51;->d:Lx51;

    .line 44
    .line 45
    invoke-virtual {p1, p2}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    check-cast p2, Lso1;

    .line 50
    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    invoke-static {v4, v5}, Lzs1;->b(J)F

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-interface {p2, v0}, Lso1;->L(F)F

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    invoke-static {v4, v5}, Lzs1;->a(J)F

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    invoke-interface {p2, v2}, Lso1;->L(F)F

    .line 66
    .line 67
    .line 68
    move-result p2

    .line 69
    move v6, p2

    .line 70
    move v5, v0

    .line 71
    goto :goto_0

    .line 72
    :cond_2
    const/4 v0, 0x0

    .line 73
    move v5, v0

    .line 74
    move v6, v5

    .line 75
    :goto_0
    invoke-virtual {p1, v3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result p2

    .line 79
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    sget-object v2, Lz41;->a:Lql0;

    .line 84
    .line 85
    if-nez p2, :cond_3

    .line 86
    .line 87
    if-eq v0, v2, :cond_3

    .line 88
    .line 89
    :goto_1
    move-object v4, v0

    .line 90
    goto :goto_2

    .line 91
    :cond_3
    new-instance v0, Ljava/lang/Object;

    .line 92
    .line 93
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p1, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :goto_2
    invoke-virtual {p1, v3}, Lki2;->i(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result p2

    .line 104
    invoke-virtual {p1, v4}, Lki2;->i(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    or-int/2addr p2, v0

    .line 109
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    if-nez p2, :cond_4

    .line 114
    .line 115
    if-ne v0, v2, :cond_5

    .line 116
    .line 117
    :cond_4
    new-instance v0, Lvr2;

    .line 118
    .line 119
    invoke-direct {v0, v3, v4, v1}, Lvr2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p1, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    :cond_5
    check-cast v0, Lhh2;

    .line 126
    .line 127
    invoke-static {v3, v4, v0, p1}, Lnt7;->d(Ljava/lang/Object;Ljava/lang/Object;Lhh2;Lki2;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {p1, v3}, Lki2;->i(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result p2

    .line 134
    invoke-virtual {p1, v4}, Lki2;->i(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    or-int/2addr p2, v0

    .line 139
    invoke-virtual {p1, v5}, Lki2;->d(F)Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    or-int/2addr p2, v0

    .line 144
    invoke-virtual {p1, v6}, Lki2;->d(F)Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    or-int/2addr p2, v0

    .line 149
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    if-nez p2, :cond_6

    .line 154
    .line 155
    if-ne v0, v2, :cond_7

    .line 156
    .line 157
    :cond_6
    new-instance v2, Len2;

    .line 158
    .line 159
    const/4 v7, 0x1

    .line 160
    invoke-direct/range {v2 .. v7}, Len2;-><init>(Ljava/lang/Object;Ljava/lang/Object;FFB)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {p1, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    move-object v0, v2

    .line 167
    :cond_7
    check-cast v0, Lhh2;

    .line 168
    .line 169
    invoke-static {p0, v0}, Lnt7;->a0(Lha4;Lhh2;)Lha4;

    .line 170
    .line 171
    .line 172
    move-result-object p0

    .line 173
    invoke-virtual {p1, v1}, Lki2;->r(Z)V

    .line 174
    .line 175
    .line 176
    return-object p0
.end method

.method public static final c(Lha4;Las2;ZLwg2;Lki2;II)Lha4;
    .locals 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    and-int/lit8 p6, p6, 0x2

    .line 11
    .line 12
    if-eqz p6, :cond_0

    .line 13
    .line 14
    const/4 p2, 0x1

    .line 15
    :cond_0
    invoke-static {p3, p4}, Lzi6;->x(Ljava/lang/Object;Lki2;)Lzd4;

    .line 16
    .line 17
    .line 18
    move-result-object p3

    .line 19
    sget-object p5, Llb;->f:Lx51;

    .line 20
    .line 21
    invoke-virtual {p4, p5}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p5

    .line 25
    check-cast p5, Landroid/view/View;

    .line 26
    .line 27
    invoke-virtual {p5}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object p5

    .line 31
    invoke-static {p5}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 32
    .line 33
    .line 34
    move-result-object p5

    .line 35
    invoke-virtual {p5}, Landroid/view/ViewConfiguration;->getScaledDoubleTapSlop()I

    .line 36
    .line 37
    .line 38
    move-result p5

    .line 39
    int-to-float p5, p5

    .line 40
    const/4 p6, 0x0

    .line 41
    if-nez p2, :cond_1

    .line 42
    .line 43
    const p1, -0x1e8d5f18

    .line 44
    .line 45
    .line 46
    invoke-virtual {p4, p1}, Lki2;->h0(I)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p4, p6}, Lki2;->r(Z)V

    .line 50
    .line 51
    .line 52
    return-object p0

    .line 53
    :cond_1
    const p2, -0x1e8d50b8

    .line 54
    .line 55
    .line 56
    invoke-virtual {p4, p2}, Lki2;->h0(I)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p4, p1}, Lki2;->i(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result p2

    .line 63
    invoke-virtual {p4}, Lki2;->T()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    sget-object v1, Lz41;->a:Lql0;

    .line 68
    .line 69
    if-nez p2, :cond_2

    .line 70
    .line 71
    if-ne v0, v1, :cond_3

    .line 72
    .line 73
    :cond_2
    new-instance v0, Lk41;

    .line 74
    .line 75
    const/16 p2, 0x10

    .line 76
    .line 77
    invoke-direct {v0, p1, p2}, Lk41;-><init>(Ljava/lang/Object;B)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p4, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    :cond_3
    check-cast v0, Lhh2;

    .line 84
    .line 85
    invoke-static {p0, v0}, Lnt7;->a0(Lha4;Lhh2;)Lha4;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    invoke-static {p5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 90
    .line 91
    .line 92
    move-result-object p2

    .line 93
    invoke-virtual {p4, p5}, Lki2;->d(F)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    invoke-virtual {p4, p1}, Lki2;->i(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v2

    .line 101
    or-int/2addr v0, v2

    .line 102
    invoke-virtual {p4, p3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    move-result v2

    .line 106
    or-int/2addr v0, v2

    .line 107
    invoke-virtual {p4}, Lki2;->T()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    if-nez v0, :cond_4

    .line 112
    .line 113
    if-ne v2, v1, :cond_5

    .line 114
    .line 115
    :cond_4
    new-instance v2, Lxr2;

    .line 116
    .line 117
    invoke-direct {v2, p5, p1, p3}, Lxr2;-><init>(FLas2;Lzd4;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {p4, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    :cond_5
    check-cast v2, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 124
    .line 125
    invoke-static {p0, p1, p2, v2}, Lh57;->c(Lha4;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Lha4;

    .line 126
    .line 127
    .line 128
    move-result-object p0

    .line 129
    invoke-virtual {p4, p6}, Lki2;->r(Z)V

    .line 130
    .line 131
    .line 132
    return-object p0
.end method

.method public static final d(Lhh2;Lki2;)Lwg2;
    .locals 4

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-static {p0, p1}, Lzi6;->x(Ljava/lang/Object;Lki2;)Lzd4;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    sget-object v1, Lz41;->a:Lql0;

    .line 13
    .line 14
    if-ne v0, v1, :cond_0

    .line 15
    .line 16
    sget-object v0, Ls12;->h:Ls12;

    .line 17
    .line 18
    invoke-static {v0, p1}, Lnt7;->J(Lii1;Lki2;)Lri1;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    check-cast v0, Lri1;

    .line 26
    .line 27
    invoke-virtual {p1, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    if-nez v2, :cond_1

    .line 36
    .line 37
    if-ne v3, v1, :cond_2

    .line 38
    .line 39
    :cond_1
    new-instance v1, Lav5;

    .line 40
    .line 41
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 42
    .line 43
    .line 44
    new-instance v3, Lzm;

    .line 45
    .line 46
    const/16 v2, 0x16

    .line 47
    .line 48
    invoke-direct {v3, v1, v0, p0, v2}, Lzm;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p1, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :cond_2
    check-cast v3, Lwg2;

    .line 55
    .line 56
    return-object v3
.end method
