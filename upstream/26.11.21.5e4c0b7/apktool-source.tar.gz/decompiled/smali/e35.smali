.class public final Le35;
.super Lgd1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public k:I

.field public l:B

.field public synthetic m:Ljava/lang/Object;

.field public n:I


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Le35;->m:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Le35;->n:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Le35;->n:I

    .line 9
    .line 10
    invoke-static {p0}, Lnl1;->Y(Lgd1;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0
.end method
