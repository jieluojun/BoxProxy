.class public final Lov6;
.super Ljz6;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public c:I


# direct methods
.method public constructor <init>(IJ)V
    .locals 0

    .line 1
    invoke-direct {p0, p2, p3}, Ljz6;-><init>(J)V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lov6;->c:I

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljz6;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    check-cast p1, Lov6;

    .line 5
    .line 6
    iget p1, p1, Lov6;->c:I

    .line 7
    .line 8
    iput p1, p0, Lov6;->c:I

    .line 9
    .line 10
    return-void
.end method

.method public final b()Ljz6;
    .locals 2

    .line 1
    invoke-static {}, Llv6;->h()Lev6;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lev6;->g()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    invoke-virtual {p0, v0, v1}, Lov6;->c(J)Ljz6;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public final c(J)Ljz6;
    .locals 1

    .line 1
    new-instance v0, Lov6;

    .line 2
    .line 3
    iget p0, p0, Lov6;->c:I

    .line 4
    .line 5
    invoke-direct {v0, p0, p1, p2}, Lov6;-><init>(IJ)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method
