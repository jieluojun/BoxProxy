.class public final synthetic Llc6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lca2;)V
    .locals 1

    .line 1
    const/16 v0, 0x18

    .line 2
    .line 3
    iput-byte v0, p0, Llc6;->h:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Llc6;->i:Ljava/lang/Object;

    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 11
    iput-byte p2, p0, Llc6;->h:B

    iput-object p1, p0, Llc6;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Llc6;->h:B

    .line 4
    .line 5
    const/16 v6, 0x8

    .line 6
    .line 7
    const-wide v7, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    const/4 v9, 0x7

    .line 13
    const/4 v10, 0x1

    .line 14
    const/4 v11, 0x0

    .line 15
    const/4 v12, 0x0

    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    sget-object v1, Li08;->h:Li08;

    .line 20
    .line 21
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lca2;

    .line 24
    .line 25
    new-instance v2, Lh08;

    .line 26
    .line 27
    invoke-direct {v2, v1, v0}, Lh08;-><init>(Li08;Laj;)V

    .line 28
    .line 29
    .line 30
    return-object v2

    .line 31
    :pswitch_0
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v0, Lh08;

    .line 34
    .line 35
    iget-object v0, v0, Lh08;->b:Lug;

    .line 36
    .line 37
    invoke-virtual {v0}, Lug;->e()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    check-cast v0, Ljava/lang/Number;

    .line 42
    .line 43
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    const/high16 v1, 0x3f800000    # 1.0f

    .line 48
    .line 49
    cmpg-float v0, v0, v1

    .line 50
    .line 51
    if-nez v0, :cond_0

    .line 52
    .line 53
    sget-object v0, Li08;->i:Li08;

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_0
    sget-object v0, Li08;->h:Li08;

    .line 57
    .line 58
    :goto_0
    return-object v0

    .line 59
    :pswitch_1
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v0, Landroid/webkit/WebView;

    .line 62
    .line 63
    invoke-virtual {v0}, Landroid/webkit/WebView;->stopLoading()V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, v11}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0, v11}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 70
    .line 71
    .line 72
    new-instance v1, Landroid/webkit/WebViewClient;

    .line 73
    .line 74
    invoke-direct {v1}, Landroid/webkit/WebViewClient;-><init>()V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 78
    .line 79
    .line 80
    const-string v1, "WEB_MESSAGE_LISTENER"

    .line 81
    .line 82
    invoke-static {v1}, Ltz7;->a(Ljava/lang/String;)Z

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    if-eqz v1, :cond_2

    .line 87
    .line 88
    const-string v1, "BoxAndroid"

    .line 89
    .line 90
    sget-object v2, Lcz7;->a:Ljava/util/WeakHashMap;

    .line 91
    .line 92
    sget-object v2, Ltz7;->c:Lqk;

    .line 93
    .line 94
    invoke-virtual {v2}, Lqk;->a()Z

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    if-eqz v2, :cond_1

    .line 99
    .line 100
    invoke-static {v0}, Lcz7;->a(Landroid/webkit/WebView;)Lvz7;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    iget-object v2, v2, Lvz7;->a:Lorg/chromium/support_lib_boundary/WebViewProviderBoundaryInterface;

    .line 105
    .line 106
    invoke-interface {v2, v1}, Lorg/chromium/support_lib_boundary/WebViewProviderBoundaryInterface;->removeWebMessageListener(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 111
    .line 112
    const-string v1, "This method is not supported by the current version of the framework and the current WebView APK"

    .line 113
    .line 114
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw v0

    .line 118
    :cond_2
    :goto_1
    const-string v1, "ksu"

    .line 119
    .line 120
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v0, v11}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    .line 127
    .line 128
    .line 129
    sget-object v0, Los7;->a:Los7;

    .line 130
    .line 131
    return-object v0

    .line 132
    :pswitch_2
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v0, Lju7;

    .line 135
    .line 136
    sget-object v1, Los7;->a:Los7;

    .line 137
    .line 138
    iget-object v0, v0, Lju7;->p:Lf75;

    .line 139
    .line 140
    invoke-virtual {v0, v1}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    return-object v1

    .line 144
    :pswitch_3
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v0, Lsj7;

    .line 147
    .line 148
    iget-object v1, v0, Lsj7;->U:Lhh2;

    .line 149
    .line 150
    iget-boolean v0, v0, Lsj7;->T:Z

    .line 151
    .line 152
    xor-int/2addr v0, v10

    .line 153
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-interface {v1, v0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    sget-object v0, Los7;->a:Los7;

    .line 161
    .line 162
    return-object v0

    .line 163
    :pswitch_4
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 164
    .line 165
    check-cast v0, Lvg7;

    .line 166
    .line 167
    iput-object v11, v0, Lvg7;->H:Lug7;

    .line 168
    .line 169
    invoke-static {v0}, Lck6;->m(Lbk6;)V

    .line 170
    .line 171
    .line 172
    invoke-static {v0}, Lu53;->s(Loi3;)V

    .line 173
    .line 174
    .line 175
    invoke-static {v0}, Loo0;->L(Lkv1;)V

    .line 176
    .line 177
    .line 178
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 179
    .line 180
    return-object v0

    .line 181
    :pswitch_5
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 182
    .line 183
    check-cast v0, Lq93;

    .line 184
    .line 185
    invoke-virtual {v0}, Lq93;->c()J

    .line 186
    .line 187
    .line 188
    move-result-wide v0

    .line 189
    new-instance v2, Lm93;

    .line 190
    .line 191
    invoke-direct {v2, v0, v1}, Lm93;-><init>(J)V

    .line 192
    .line 193
    .line 194
    return-object v2

    .line 195
    :pswitch_6
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v0, Lte7;

    .line 198
    .line 199
    iget-object v0, v0, Lte7;->a:Lrc7;

    .line 200
    .line 201
    iget-object v1, v0, Lrc7;->h:Lf75;

    .line 202
    .line 203
    invoke-virtual {v1}, Lf75;->getValue()Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object v1

    .line 207
    check-cast v1, Lqc7;

    .line 208
    .line 209
    if-eqz v1, :cond_3

    .line 210
    .line 211
    iget-object v2, v0, Lrc7;->i:Lf75;

    .line 212
    .line 213
    invoke-virtual {v2}, Lf75;->getValue()Ljava/lang/Object;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    check-cast v2, Lpc7;

    .line 218
    .line 219
    if-eqz v2, :cond_3

    .line 220
    .line 221
    invoke-virtual {v0, v1, v2}, Lrc7;->f(Lqc7;Lpc7;)Lse7;

    .line 222
    .line 223
    .line 224
    move-result-object v11

    .line 225
    :cond_3
    return-object v11

    .line 226
    :pswitch_7
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 227
    .line 228
    check-cast v0, Lge7;

    .line 229
    .line 230
    new-instance v1, Landroid/view/inputmethod/BaseInputConnection;

    .line 231
    .line 232
    iget-object v0, v0, Lge7;->a:Lbb;

    .line 233
    .line 234
    invoke-direct {v1, v0, v12}, Landroid/view/inputmethod/BaseInputConnection;-><init>(Landroid/view/View;Z)V

    .line 235
    .line 236
    .line 237
    return-object v1

    .line 238
    :pswitch_8
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v0, Lwc7;

    .line 241
    .line 242
    iget-object v1, v0, Lwc7;->x:Lhn7;

    .line 243
    .line 244
    iget-object v2, v0, Lwc7;->y:Lod7;

    .line 245
    .line 246
    iget-object v3, v0, Lwc7;->z:Lte7;

    .line 247
    .line 248
    iget-object v0, v0, Lwc7;->B:Lf75;

    .line 249
    .line 250
    invoke-virtual {v0}, Lf75;->getValue()Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    check-cast v0, Lu93;

    .line 255
    .line 256
    iget-wide v4, v0, Lu93;->a:J

    .line 257
    .line 258
    invoke-static {v1, v2, v3, v4, v5}, Lgk6;->i(Lhn7;Lod7;Lte7;J)J

    .line 259
    .line 260
    .line 261
    move-result-wide v0

    .line 262
    new-instance v2, Lhv4;

    .line 263
    .line 264
    invoke-direct {v2, v0, v1}, Lhv4;-><init>(J)V

    .line 265
    .line 266
    .line 267
    return-object v2

    .line 268
    :pswitch_9
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 269
    .line 270
    check-cast v0, Loa7;

    .line 271
    .line 272
    iget-boolean v1, v0, Lga4;->u:Z

    .line 273
    .line 274
    if-eqz v1, :cond_4

    .line 275
    .line 276
    invoke-static {v0}, Ljl6;->c(Lio1;)Lz97;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    goto :goto_2

    .line 281
    :cond_4
    sget-object v0, Lz97;->b:Lz97;

    .line 282
    .line 283
    :goto_2
    return-object v0

    .line 284
    :pswitch_a
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 285
    .line 286
    check-cast v0, Landroid/app/RemoteAction;

    .line 287
    .line 288
    invoke-virtual {v0}, Landroid/app/RemoteAction;->getActionIntent()Landroid/app/PendingIntent;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    invoke-static {v0}, Ldl6;->r(Landroid/app/PendingIntent;)V

    .line 293
    .line 294
    .line 295
    sget-object v0, Los7;->a:Los7;

    .line 296
    .line 297
    return-object v0

    .line 298
    :pswitch_b
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 299
    .line 300
    check-cast v0, Ln14;

    .line 301
    .line 302
    new-instance v1, Lff7;

    .line 303
    .line 304
    invoke-interface {v0}, Ln14;->e()Lqe2;

    .line 305
    .line 306
    .line 307
    move-result-object v2

    .line 308
    invoke-interface {v0}, Ln14;->a()Lso1;

    .line 309
    .line 310
    .line 311
    move-result-object v4

    .line 312
    invoke-interface {v0}, Ln14;->getLayoutDirection()Lgi3;

    .line 313
    .line 314
    .line 315
    move-result-object v5

    .line 316
    sget-object v0, Lpt3;->j:Lpt3;

    .line 317
    .line 318
    sget-object v0, Lua5;->a:Lvh7;

    .line 319
    .line 320
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 321
    .line 322
    .line 323
    invoke-static {}, Landroid/os/LocaleList;->getDefault()Landroid/os/LocaleList;

    .line 324
    .line 325
    .line 326
    move-result-object v3

    .line 327
    iget-object v6, v0, Lvh7;->k:Ljava/lang/Object;

    .line 328
    .line 329
    check-cast v6, Lpf6;

    .line 330
    .line 331
    monitor-enter v6

    .line 332
    :try_start_0
    iget-object v7, v0, Lvh7;->j:Ljava/lang/Object;

    .line 333
    .line 334
    check-cast v7, Lpt3;

    .line 335
    .line 336
    if-eqz v7, :cond_5

    .line 337
    .line 338
    iget-object v8, v0, Lvh7;->i:Ljava/lang/Object;

    .line 339
    .line 340
    check-cast v8, Landroid/os/LocaleList;

    .line 341
    .line 342
    if-eq v3, v8, :cond_7

    .line 343
    .line 344
    :cond_5
    invoke-virtual {v3}, Landroid/os/LocaleList;->size()I

    .line 345
    .line 346
    .line 347
    move-result v7

    .line 348
    new-instance v8, Ljava/util/ArrayList;

    .line 349
    .line 350
    invoke-direct {v8, v7}, Ljava/util/ArrayList;-><init>(I)V

    .line 351
    .line 352
    .line 353
    :goto_3
    if-ge v12, v7, :cond_6

    .line 354
    .line 355
    new-instance v9, Lot3;

    .line 356
    .line 357
    invoke-virtual {v3, v12}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    .line 358
    .line 359
    .line 360
    move-result-object v10

    .line 361
    invoke-direct {v9, v10}, Lot3;-><init>(Ljava/util/Locale;)V

    .line 362
    .line 363
    .line 364
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 365
    .line 366
    .line 367
    add-int/lit8 v12, v12, 0x1

    .line 368
    .line 369
    goto :goto_3

    .line 370
    :cond_6
    new-instance v7, Lpt3;

    .line 371
    .line 372
    invoke-direct {v7, v8}, Lpt3;-><init>(Ljava/util/List;)V

    .line 373
    .line 374
    .line 375
    iput-object v3, v0, Lvh7;->i:Ljava/lang/Object;

    .line 376
    .line 377
    iput-object v7, v0, Lvh7;->j:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 378
    .line 379
    :cond_7
    monitor-exit v6

    .line 380
    move-object v3, v7

    .line 381
    const/4 v6, 0x0

    .line 382
    invoke-direct/range {v1 .. v6}, Lff7;-><init>(Lqe2;Lpt3;Lso1;Lgi3;I)V

    .line 383
    .line 384
    .line 385
    return-object v1

    .line 386
    :catchall_0
    move-exception v0

    .line 387
    monitor-exit v6

    .line 388
    throw v0

    .line 389
    :pswitch_c
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 390
    .line 391
    check-cast v0, Lk97;

    .line 392
    .line 393
    iput-object v11, v0, Lk97;->M:Lj97;

    .line 394
    .line 395
    invoke-static {v0}, Lck6;->m(Lbk6;)V

    .line 396
    .line 397
    .line 398
    invoke-static {v0}, Lu53;->s(Loi3;)V

    .line 399
    .line 400
    .line 401
    invoke-static {v0}, Loo0;->L(Lkv1;)V

    .line 402
    .line 403
    .line 404
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 405
    .line 406
    return-object v0

    .line 407
    :pswitch_d
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 408
    .line 409
    check-cast v0, Ls27;

    .line 410
    .line 411
    iget v0, v0, Ls27;->j:F

    .line 412
    .line 413
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 414
    .line 415
    .line 416
    move-result-object v0

    .line 417
    return-object v0

    .line 418
    :pswitch_e
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 419
    .line 420
    check-cast v0, Ln27;

    .line 421
    .line 422
    invoke-virtual {v0}, Ln27;->a()Lkj3;

    .line 423
    .line 424
    .line 425
    move-result-object v0

    .line 426
    iget-object v1, v0, Lkj3;->h:Lwi3;

    .line 427
    .line 428
    invoke-virtual {v1}, Lwi3;->o()Ljava/util/List;

    .line 429
    .line 430
    .line 431
    move-result-object v11

    .line 432
    check-cast v11, Ljd4;

    .line 433
    .line 434
    iget-object v11, v11, Ljd4;->i:Ljava/lang/Object;

    .line 435
    .line 436
    check-cast v11, Lbe4;

    .line 437
    .line 438
    iget v11, v11, Lbe4;->j:I

    .line 439
    .line 440
    iget v13, v0, Lkj3;->u:I

    .line 441
    .line 442
    if-eq v13, v11, :cond_d

    .line 443
    .line 444
    iget-object v0, v0, Lkj3;->m:Ltd4;

    .line 445
    .line 446
    iget-object v11, v0, Ltd4;->c:[Ljava/lang/Object;

    .line 447
    .line 448
    iget-object v0, v0, Ltd4;->a:[J

    .line 449
    .line 450
    array-length v13, v0

    .line 451
    add-int/lit8 v13, v13, -0x2

    .line 452
    .line 453
    if-ltz v13, :cond_b

    .line 454
    .line 455
    move v14, v12

    .line 456
    const-wide/16 v15, 0x80

    .line 457
    .line 458
    :goto_4
    aget-wide v2, v0, v14

    .line 459
    .line 460
    const-wide/16 v17, 0xff

    .line 461
    .line 462
    not-long v4, v2

    .line 463
    shl-long/2addr v4, v9

    .line 464
    and-long/2addr v4, v2

    .line 465
    and-long/2addr v4, v7

    .line 466
    cmp-long v4, v4, v7

    .line 467
    .line 468
    if-eqz v4, :cond_a

    .line 469
    .line 470
    sub-int v4, v14, v13

    .line 471
    .line 472
    not-int v4, v4

    .line 473
    ushr-int/lit8 v4, v4, 0x1f

    .line 474
    .line 475
    rsub-int/lit8 v4, v4, 0x8

    .line 476
    .line 477
    move v5, v12

    .line 478
    :goto_5
    if-ge v5, v4, :cond_9

    .line 479
    .line 480
    and-long v19, v2, v17

    .line 481
    .line 482
    cmp-long v19, v19, v15

    .line 483
    .line 484
    if-gez v19, :cond_8

    .line 485
    .line 486
    shl-int/lit8 v19, v14, 0x3

    .line 487
    .line 488
    add-int v19, v19, v5

    .line 489
    .line 490
    aget-object v19, v11, v19

    .line 491
    .line 492
    move-wide/from16 v20, v7

    .line 493
    .line 494
    move-object/from16 v7, v19

    .line 495
    .line 496
    check-cast v7, Lcj3;

    .line 497
    .line 498
    iput-boolean v10, v7, Lcj3;->d:Z

    .line 499
    .line 500
    goto :goto_6

    .line 501
    :cond_8
    move-wide/from16 v20, v7

    .line 502
    .line 503
    :goto_6
    shr-long/2addr v2, v6

    .line 504
    add-int/lit8 v5, v5, 0x1

    .line 505
    .line 506
    move-wide/from16 v7, v20

    .line 507
    .line 508
    goto :goto_5

    .line 509
    :cond_9
    move-wide/from16 v20, v7

    .line 510
    .line 511
    if-ne v4, v6, :cond_b

    .line 512
    .line 513
    goto :goto_7

    .line 514
    :cond_a
    move-wide/from16 v20, v7

    .line 515
    .line 516
    :goto_7
    if-eq v14, v13, :cond_b

    .line 517
    .line 518
    add-int/lit8 v14, v14, 0x1

    .line 519
    .line 520
    move-wide/from16 v7, v20

    .line 521
    .line 522
    goto :goto_4

    .line 523
    :cond_b
    iget-object v0, v1, Lwi3;->o:Lwi3;

    .line 524
    .line 525
    if-eqz v0, :cond_c

    .line 526
    .line 527
    iget-object v0, v1, Lwi3;->N:Laj3;

    .line 528
    .line 529
    iget-boolean v0, v0, Laj3;->e:Z

    .line 530
    .line 531
    if-nez v0, :cond_d

    .line 532
    .line 533
    invoke-static {v1, v12, v9}, Lwi3;->U(Lwi3;ZI)V

    .line 534
    .line 535
    .line 536
    goto :goto_8

    .line 537
    :cond_c
    invoke-virtual {v1}, Lwi3;->q()Z

    .line 538
    .line 539
    .line 540
    move-result v0

    .line 541
    if-nez v0, :cond_d

    .line 542
    .line 543
    invoke-static {v1, v12, v9}, Lwi3;->W(Lwi3;ZI)V

    .line 544
    .line 545
    .line 546
    :cond_d
    :goto_8
    sget-object v0, Los7;->a:Los7;

    .line 547
    .line 548
    return-object v0

    .line 549
    :pswitch_f
    move-wide/from16 v20, v7

    .line 550
    .line 551
    const-wide/16 v15, 0x80

    .line 552
    .line 553
    const-wide/16 v17, 0xff

    .line 554
    .line 555
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 556
    .line 557
    move-object v1, v0

    .line 558
    check-cast v1, Law6;

    .line 559
    .line 560
    :goto_9
    iget-object v2, v1, Law6;->g:Ljava/lang/Object;

    .line 561
    .line 562
    monitor-enter v2

    .line 563
    :try_start_1
    iget-boolean v0, v1, Law6;->c:Z

    .line 564
    .line 565
    if-nez v0, :cond_13

    .line 566
    .line 567
    iput-boolean v10, v1, Law6;->c:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 568
    .line 569
    :try_start_2
    iget-object v0, v1, Law6;->f:Lbe4;

    .line 570
    .line 571
    iget-object v3, v0, Lbe4;->h:[Ljava/lang/Object;

    .line 572
    .line 573
    iget v0, v0, Lbe4;->j:I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 574
    .line 575
    move v4, v12

    .line 576
    :goto_a
    if-ge v4, v0, :cond_12

    .line 577
    .line 578
    :try_start_3
    aget-object v5, v3, v4

    .line 579
    .line 580
    check-cast v5, Lzv6;

    .line 581
    .line 582
    iget-object v7, v5, Lzv6;->h:Lud4;

    .line 583
    .line 584
    iget-object v5, v5, Lzv6;->a:Lhh2;

    .line 585
    .line 586
    iget-object v8, v7, Lud4;->b:[Ljava/lang/Object;

    .line 587
    .line 588
    iget-object v11, v7, Lud4;->a:[J

    .line 589
    .line 590
    array-length v13, v11

    .line 591
    add-int/lit8 v13, v13, -0x2

    .line 592
    .line 593
    move/from16 v22, v9

    .line 594
    .line 595
    if-ltz v13, :cond_11

    .line 596
    .line 597
    move v14, v12

    .line 598
    :goto_b
    aget-wide v9, v11, v14

    .line 599
    .line 600
    move/from16 p0, v13

    .line 601
    .line 602
    not-long v12, v9

    .line 603
    shl-long v12, v12, v22

    .line 604
    .line 605
    and-long/2addr v12, v9

    .line 606
    and-long v12, v12, v20

    .line 607
    .line 608
    cmp-long v12, v12, v20

    .line 609
    .line 610
    if-eqz v12, :cond_10

    .line 611
    .line 612
    sub-int v12, v14, p0

    .line 613
    .line 614
    not-int v12, v12

    .line 615
    ushr-int/lit8 v12, v12, 0x1f

    .line 616
    .line 617
    rsub-int/lit8 v12, v12, 0x8

    .line 618
    .line 619
    const/4 v13, 0x0

    .line 620
    :goto_c
    if-ge v13, v12, :cond_f

    .line 621
    .line 622
    and-long v23, v9, v17

    .line 623
    .line 624
    cmp-long v23, v23, v15

    .line 625
    .line 626
    if-gez v23, :cond_e

    .line 627
    .line 628
    shl-int/lit8 v23, v14, 0x3

    .line 629
    .line 630
    add-int v23, v23, v13

    .line 631
    .line 632
    aget-object v15, v8, v23

    .line 633
    .line 634
    invoke-interface {v5, v15}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 635
    .line 636
    .line 637
    :cond_e
    shr-long/2addr v9, v6

    .line 638
    add-int/lit8 v13, v13, 0x1

    .line 639
    .line 640
    const-wide/16 v15, 0x80

    .line 641
    .line 642
    goto :goto_c

    .line 643
    :cond_f
    if-ne v12, v6, :cond_11

    .line 644
    .line 645
    :cond_10
    move/from16 v13, p0

    .line 646
    .line 647
    if-eq v14, v13, :cond_11

    .line 648
    .line 649
    add-int/lit8 v14, v14, 0x1

    .line 650
    .line 651
    const-wide/16 v15, 0x80

    .line 652
    .line 653
    goto :goto_b

    .line 654
    :cond_11
    invoke-virtual {v7}, Lud4;->c()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 655
    .line 656
    .line 657
    add-int/lit8 v4, v4, 0x1

    .line 658
    .line 659
    move/from16 v9, v22

    .line 660
    .line 661
    const/4 v12, 0x0

    .line 662
    const-wide/16 v15, 0x80

    .line 663
    .line 664
    goto :goto_a

    .line 665
    :goto_d
    const/4 v3, 0x0

    .line 666
    goto :goto_e

    .line 667
    :catchall_1
    move-exception v0

    .line 668
    goto :goto_d

    .line 669
    :cond_12
    move/from16 v22, v9

    .line 670
    .line 671
    move v3, v12

    .line 672
    :try_start_4
    iput-boolean v3, v1, Law6;->c:Z

    .line 673
    .line 674
    goto :goto_f

    .line 675
    :catchall_2
    move-exception v0

    .line 676
    move v3, v12

    .line 677
    :goto_e
    iput-boolean v3, v1, Law6;->c:Z

    .line 678
    .line 679
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 680
    :cond_13
    move/from16 v22, v9

    .line 681
    .line 682
    :goto_f
    monitor-exit v2

    .line 683
    invoke-virtual {v1}, Law6;->b()Z

    .line 684
    .line 685
    .line 686
    move-result v0

    .line 687
    if-nez v0, :cond_14

    .line 688
    .line 689
    sget-object v0, Los7;->a:Los7;

    .line 690
    .line 691
    return-object v0

    .line 692
    :cond_14
    move/from16 v9, v22

    .line 693
    .line 694
    const/4 v10, 0x1

    .line 695
    const/4 v12, 0x0

    .line 696
    const-wide/16 v15, 0x80

    .line 697
    .line 698
    goto/16 :goto_9

    .line 699
    .line 700
    :catchall_3
    move-exception v0

    .line 701
    monitor-exit v2

    .line 702
    throw v0

    .line 703
    :pswitch_10
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 704
    .line 705
    check-cast v0, Lcn6;

    .line 706
    .line 707
    iget-object v1, v0, Lcn6;->j:Lf75;

    .line 708
    .line 709
    invoke-virtual {v1}, Lf75;->getValue()Ljava/lang/Object;

    .line 710
    .line 711
    .line 712
    move-result-object v2

    .line 713
    check-cast v2, Lct6;

    .line 714
    .line 715
    iget-wide v2, v2, Lct6;->a:J

    .line 716
    .line 717
    const-wide v4, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    cmp-long v2, v2, v4

    .line 723
    .line 724
    if-eqz v2, :cond_15

    .line 725
    .line 726
    invoke-virtual {v1}, Lf75;->getValue()Ljava/lang/Object;

    .line 727
    .line 728
    .line 729
    move-result-object v2

    .line 730
    check-cast v2, Lct6;

    .line 731
    .line 732
    iget-wide v2, v2, Lct6;->a:J

    .line 733
    .line 734
    invoke-static {v2, v3}, Lct6;->c(J)Z

    .line 735
    .line 736
    .line 737
    move-result v2

    .line 738
    if-nez v2, :cond_15

    .line 739
    .line 740
    iget-object v0, v0, Lcn6;->h:Lbn6;

    .line 741
    .line 742
    invoke-virtual {v1}, Lf75;->getValue()Ljava/lang/Object;

    .line 743
    .line 744
    .line 745
    move-result-object v1

    .line 746
    check-cast v1, Lct6;

    .line 747
    .line 748
    iget-wide v1, v1, Lct6;->a:J

    .line 749
    .line 750
    invoke-virtual {v0, v1, v2}, Lbn6;->c(J)Landroid/graphics/Shader;

    .line 751
    .line 752
    .line 753
    move-result-object v11

    .line 754
    :cond_15
    return-object v11

    .line 755
    :pswitch_11
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 756
    .line 757
    check-cast v0, Lil6;

    .line 758
    .line 759
    iget-object v1, v0, Lil6;->k:[Lgl6;

    .line 760
    .line 761
    invoke-static {v0, v1}, Ll63;->S(Lgl6;[Lgl6;)I

    .line 762
    .line 763
    .line 764
    move-result v0

    .line 765
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    return-object v0

    .line 770
    :pswitch_12
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 771
    .line 772
    return-object v0

    .line 773
    :pswitch_13
    const-string v1, "com.box.app.ui.app.BoxAppRoute"

    .line 774
    .line 775
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 776
    .line 777
    check-cast v0, Lsg6;

    .line 778
    .line 779
    sget-object v2, Lmd5;->e:Lmd5;

    .line 780
    .line 781
    const/4 v3, 0x0

    .line 782
    new-array v4, v3, [Lgl6;

    .line 783
    .line 784
    new-instance v5, Lrg6;

    .line 785
    .line 786
    invoke-direct {v5, v0, v3}, Lrg6;-><init>(Lsg6;B)V

    .line 787
    .line 788
    .line 789
    invoke-static {v1, v2, v4, v5}, Ljl6;->b(Ljava/lang/String;Lml6;[Lgl6;Lhh2;)Lil6;

    .line 790
    .line 791
    .line 792
    move-result-object v0

    .line 793
    return-object v0

    .line 794
    :pswitch_14
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 795
    .line 796
    check-cast v0, Lbg6;

    .line 797
    .line 798
    sget-object v1, Le15;->a:Lx51;

    .line 799
    .line 800
    invoke-static {v0, v1}, Lxj;->N(Lr51;Lch5;)Ljava/lang/Object;

    .line 801
    .line 802
    .line 803
    move-result-object v1

    .line 804
    check-cast v1, Lc15;

    .line 805
    .line 806
    iput-object v1, v0, Lbg6;->H:Lc15;

    .line 807
    .line 808
    if-eqz v1, :cond_16

    .line 809
    .line 810
    invoke-interface {v1}, Lc15;->a()La15;

    .line 811
    .line 812
    .line 813
    move-result-object v11

    .line 814
    :cond_16
    iput-object v11, v0, Lbg6;->I:La15;

    .line 815
    .line 816
    sget-object v0, Los7;->a:Los7;

    .line 817
    .line 818
    return-object v0

    .line 819
    :pswitch_15
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 820
    .line 821
    check-cast v0, Lwc6;

    .line 822
    .line 823
    invoke-interface {v0}, Lco3;->g()Lfo3;

    .line 824
    .line 825
    .line 826
    move-result-object v1

    .line 827
    new-instance v2, Lru5;

    .line 828
    .line 829
    const/4 v3, 0x0

    .line 830
    invoke-direct {v2, v0, v3}, Lru5;-><init>(Ljava/lang/Object;B)V

    .line 831
    .line 832
    .line 833
    invoke-virtual {v1, v2}, Lfo3;->a(Lbo3;)V

    .line 834
    .line 835
    .line 836
    sget-object v0, Los7;->a:Los7;

    .line 837
    .line 838
    return-object v0

    .line 839
    :pswitch_16
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 840
    .line 841
    check-cast v0, Lax7;

    .line 842
    .line 843
    invoke-static {v0}, Lnx3;->U(Lax7;)Lsc6;

    .line 844
    .line 845
    .line 846
    move-result-object v0

    .line 847
    return-object v0

    .line 848
    :pswitch_17
    iget-object v0, v0, Llc6;->i:Ljava/lang/Object;

    .line 849
    .line 850
    check-cast v0, Lmc6;

    .line 851
    .line 852
    iget-object v0, v0, Lmc6;->j:Lop2;

    .line 853
    .line 854
    if-eqz v0, :cond_17

    .line 855
    .line 856
    const/4 v3, 0x0

    .line 857
    new-array v1, v3, [Lj65;

    .line 858
    .line 859
    invoke-static {v1, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 860
    .line 861
    .line 862
    move-result-object v1

    .line 863
    check-cast v1, [Lj65;

    .line 864
    .line 865
    invoke-static {v1}, Lok;->B([Lj65;)Landroid/os/Bundle;

    .line 866
    .line 867
    .line 868
    move-result-object v1

    .line 869
    invoke-virtual {v0, v1}, Lop2;->X(Landroid/os/Bundle;)V

    .line 870
    .line 871
    .line 872
    invoke-virtual {v1}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 873
    .line 874
    .line 875
    move-result v0

    .line 876
    if-nez v0, :cond_17

    .line 877
    .line 878
    move-object v11, v1

    .line 879
    :cond_17
    return-object v11

    .line 880
    nop

    .line 881
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
