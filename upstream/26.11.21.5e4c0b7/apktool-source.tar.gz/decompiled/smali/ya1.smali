.class public final Lya1;
.super Lxa1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# virtual methods
.method public final a(Las4;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lxd6;

    .line 2
    .line 3
    iget-object p0, p1, Lxd6;->g:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {p0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method
