.class public interface abstract Lh75;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lio1;


# virtual methods
.method public abstract j(Lso1;Ljava/lang/Object;)Ljava/lang/Object;
.end method
