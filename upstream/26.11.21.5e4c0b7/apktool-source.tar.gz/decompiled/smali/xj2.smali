.class public final synthetic Lxj2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lum2;

.field public final synthetic j:Lbj;


# direct methods
.method public synthetic constructor <init>(Lum2;Lbj;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lxj2;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lxj2;->i:Lum2;

    .line 4
    .line 5
    iput-object p2, p0, Lxj2;->j:Lbj;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lxj2;->h:B

    .line 2
    .line 3
    iget-object v1, p0, Lxj2;->j:Lbj;

    .line 4
    .line 5
    iget-object p0, p0, Lxj2;->i:Lum2;

    .line 6
    .line 7
    check-cast p1, Lsr1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    if-eqz p0, :cond_0

    .line 16
    .line 17
    iget-object p1, p0, Lum2;->a:Lf75;

    .line 18
    .line 19
    invoke-virtual {p1, v1}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    new-instance p1, Lbk2;

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    invoke-direct {p1, p0, v1, v0}, Lbk2;-><init>(Lum2;Lbj;B)V

    .line 26
    .line 27
    .line 28
    return-object p1

    .line 29
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    if-eqz p0, :cond_1

    .line 33
    .line 34
    iget-object p1, p0, Lum2;->b:Lf75;

    .line 35
    .line 36
    invoke-virtual {p1, v1}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    const/4 p1, 0x0

    .line 40
    iget-object v0, p0, Lum2;->c:Lb75;

    .line 41
    .line 42
    invoke-virtual {v0, p1}, Lb75;->i(F)V

    .line 43
    .line 44
    .line 45
    :cond_1
    new-instance p1, Lbk2;

    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    invoke-direct {p1, p0, v1, v0}, Lbk2;-><init>(Lum2;Lbj;B)V

    .line 49
    .line 50
    .line 51
    return-object p1

    .line 52
    nop

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
