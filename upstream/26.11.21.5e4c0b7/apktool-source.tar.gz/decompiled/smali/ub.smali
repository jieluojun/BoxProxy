.class public final synthetic Lub;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:J

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(JLha4;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lub;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-wide p1, p0, Lub;->i:J

    .line 8
    .line 9
    iput-object p3, p0, Lub;->j:Ljava/lang/Object;

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(La53;JI)V
    .locals 0

    .line 12
    const/4 p4, 0x1

    iput-byte p4, p0, Lub;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lub;->j:Ljava/lang/Object;

    iput-wide p2, p0, Lub;->i:J

    return-void
.end method

.method public synthetic constructor <init>(Le26;J)V
    .locals 1

    .line 13
    const/4 v0, 0x2

    iput-byte v0, p0, Lub;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lub;->j:Ljava/lang/Object;

    iput-wide p2, p0, Lub;->i:J

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lub;->h:B

    .line 4
    .line 5
    iget-wide v2, v0, Lub;->i:J

    .line 6
    .line 7
    sget-object v4, Lwi3;->Z:Lj43;

    .line 8
    .line 9
    const/4 v5, 0x2

    .line 10
    const/4 v6, 0x0

    .line 11
    sget-object v7, Los7;->a:Los7;

    .line 12
    .line 13
    const/4 v8, 0x1

    .line 14
    iget-object v9, v0, Lub;->j:Ljava/lang/Object;

    .line 15
    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    check-cast v9, Le26;

    .line 20
    .line 21
    move-object/from16 v14, p1

    .line 22
    .line 23
    check-cast v14, Lki2;

    .line 24
    .line 25
    move-object/from16 v1, p2

    .line 26
    .line 27
    check-cast v1, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    and-int/lit8 v2, v1, 0x3

    .line 34
    .line 35
    if-eq v2, v5, :cond_0

    .line 36
    .line 37
    move v2, v8

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    move v2, v6

    .line 40
    :goto_0
    and-int/2addr v1, v8

    .line 41
    invoke-virtual {v14, v1, v2}, Lki2;->Y(IZ)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-eqz v1, :cond_3

    .line 46
    .line 47
    sget-object v1, Ly6;->t:Lz30;

    .line 48
    .line 49
    new-instance v2, Luw;

    .line 50
    .line 51
    new-instance v3, Lt32;

    .line 52
    .line 53
    const/4 v5, 0x3

    .line 54
    invoke-direct {v3, v5}, Lt32;-><init>(B)V

    .line 55
    .line 56
    .line 57
    const/high16 v5, 0x41400000    # 12.0f

    .line 58
    .line 59
    invoke-direct {v2, v5, v8, v3}, Luw;-><init>(FZLt32;)V

    .line 60
    .line 61
    .line 62
    const/16 v3, 0x36

    .line 63
    .line 64
    invoke-static {v2, v1, v14, v3}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    iget-wide v2, v14, Lki2;->U:J

    .line 69
    .line 70
    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    invoke-virtual {v14}, Lki2;->m()Lr95;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    sget-object v5, Lea4;->h:Lea4;

    .line 79
    .line 80
    invoke-static {v14, v5}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 81
    .line 82
    .line 83
    move-result-object v10

    .line 84
    sget-object v11, Lp41;->d:Ly6;

    .line 85
    .line 86
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v14}, Lki2;->k0()V

    .line 90
    .line 91
    .line 92
    iget-boolean v11, v14, Lki2;->T:Z

    .line 93
    .line 94
    if-eqz v11, :cond_1

    .line 95
    .line 96
    invoke-virtual {v14, v4}, Lki2;->l(Lwg2;)V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_1
    invoke-virtual {v14}, Lki2;->t0()V

    .line 101
    .line 102
    .line 103
    :goto_1
    sget-object v4, Ly6;->T:Lu31;

    .line 104
    .line 105
    invoke-static {v4, v14, v1}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    sget-object v1, Ly6;->S:Lu31;

    .line 109
    .line 110
    invoke-static {v1, v14, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    sget-object v2, Ly6;->U:Lu31;

    .line 118
    .line 119
    invoke-static {v2, v14, v1}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-static {v14}, Lml6;->p(Lki2;)V

    .line 123
    .line 124
    .line 125
    sget-object v1, Ly6;->R:Lu31;

    .line 126
    .line 127
    invoke-static {v1, v14, v10}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    iget-object v10, v9, Le26;->b:Ljava/lang/String;

    .line 131
    .line 132
    const/16 v15, 0xd80

    .line 133
    .line 134
    const/16 v16, 0x2

    .line 135
    .line 136
    const/4 v11, 0x0

    .line 137
    const/high16 v12, 0x41c00000    # 24.0f

    .line 138
    .line 139
    const/high16 v13, 0x40a00000    # 5.0f

    .line 140
    .line 141
    invoke-static/range {v10 .. v16}, Lug6;->i(Ljava/lang/String;Lha4;FFLki2;II)V

    .line 142
    .line 143
    .line 144
    iget-boolean v1, v9, Le26;->f:Z

    .line 145
    .line 146
    if-eqz v1, :cond_2

    .line 147
    .line 148
    const v1, 0x30ad68ea

    .line 149
    .line 150
    .line 151
    invoke-virtual {v14, v1}, Lki2;->h0(I)V

    .line 152
    .line 153
    .line 154
    invoke-static {}, Lj53;->F()La53;

    .line 155
    .line 156
    .line 157
    move-result-object v10

    .line 158
    const v1, 0x7f0f03b1

    .line 159
    .line 160
    .line 161
    invoke-static {v1, v14}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object v11

    .line 165
    const/high16 v1, 0x41500000    # 13.0f

    .line 166
    .line 167
    invoke-static {v5, v1}, Lit6;->m(Lha4;F)Lha4;

    .line 168
    .line 169
    .line 170
    move-result-object v12

    .line 171
    sget-object v1, Lq04;->b:Lcx1;

    .line 172
    .line 173
    invoke-virtual {v14, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v1

    .line 177
    check-cast v1, Ln04;

    .line 178
    .line 179
    iget-object v1, v1, Ln04;->a:Lky0;

    .line 180
    .line 181
    iget-wide v1, v1, Lky0;->s:J

    .line 182
    .line 183
    const/16 v16, 0x180

    .line 184
    .line 185
    const/16 v17, 0x0

    .line 186
    .line 187
    move-object v15, v14

    .line 188
    move-wide v13, v1

    .line 189
    invoke-static/range {v10 .. v17}, Lw33;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 190
    .line 191
    .line 192
    move-object v14, v15

    .line 193
    invoke-virtual {v14, v6}, Lki2;->r(Z)V

    .line 194
    .line 195
    .line 196
    goto :goto_2

    .line 197
    :cond_2
    const v1, 0x30b28707

    .line 198
    .line 199
    .line 200
    invoke-virtual {v14, v1}, Lki2;->h0(I)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v14, v6}, Lki2;->r(Z)V

    .line 204
    .line 205
    .line 206
    :goto_2
    iget-object v10, v9, Le26;->a:Ljava/lang/String;

    .line 207
    .line 208
    sget-object v1, Lq04;->b:Lcx1;

    .line 209
    .line 210
    invoke-virtual {v14, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object v1

    .line 214
    check-cast v1, Ln04;

    .line 215
    .line 216
    iget-object v1, v1, Ln04;->b:Lgq7;

    .line 217
    .line 218
    iget-object v1, v1, Lgq7;->j:Lwg7;

    .line 219
    .line 220
    const/16 v30, 0x6180

    .line 221
    .line 222
    const v31, 0x1affa

    .line 223
    .line 224
    .line 225
    const/4 v11, 0x0

    .line 226
    iget-wide v12, v0, Lub;->i:J

    .line 227
    .line 228
    move-object/from16 v28, v14

    .line 229
    .line 230
    const-wide/16 v14, 0x0

    .line 231
    .line 232
    const/16 v16, 0x0

    .line 233
    .line 234
    const/16 v17, 0x0

    .line 235
    .line 236
    const-wide/16 v18, 0x0

    .line 237
    .line 238
    const/16 v20, 0x0

    .line 239
    .line 240
    const-wide/16 v21, 0x0

    .line 241
    .line 242
    const/16 v23, 0x2

    .line 243
    .line 244
    const/16 v24, 0x0

    .line 245
    .line 246
    const/16 v25, 0x1

    .line 247
    .line 248
    const/16 v26, 0x0

    .line 249
    .line 250
    const/16 v29, 0x0

    .line 251
    .line 252
    move-object/from16 v27, v1

    .line 253
    .line 254
    invoke-static/range {v10 .. v31}, Loe7;->b(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILwg7;Lki2;III)V

    .line 255
    .line 256
    .line 257
    move-object/from16 v14, v28

    .line 258
    .line 259
    invoke-virtual {v14, v8}, Lki2;->r(Z)V

    .line 260
    .line 261
    .line 262
    goto :goto_3

    .line 263
    :cond_3
    invoke-virtual {v14}, Lki2;->b0()V

    .line 264
    .line 265
    .line 266
    :goto_3
    return-object v7

    .line 267
    :pswitch_0
    check-cast v9, La53;

    .line 268
    .line 269
    move-object/from16 v0, p1

    .line 270
    .line 271
    check-cast v0, Lki2;

    .line 272
    .line 273
    move-object/from16 v1, p2

    .line 274
    .line 275
    check-cast v1, Ljava/lang/Integer;

    .line 276
    .line 277
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 278
    .line 279
    .line 280
    invoke-static {v8}, Ld43;->P(I)I

    .line 281
    .line 282
    .line 283
    move-result v1

    .line 284
    invoke-static {v9, v2, v3, v0, v1}, Lug6;->h(La53;JLki2;I)V

    .line 285
    .line 286
    .line 287
    return-object v7

    .line 288
    :pswitch_1
    move-object v10, v9

    .line 289
    check-cast v10, Lha4;

    .line 290
    .line 291
    move-object/from16 v0, p1

    .line 292
    .line 293
    check-cast v0, Lki2;

    .line 294
    .line 295
    move-object/from16 v1, p2

    .line 296
    .line 297
    check-cast v1, Ljava/lang/Integer;

    .line 298
    .line 299
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 300
    .line 301
    .line 302
    move-result v1

    .line 303
    and-int/lit8 v9, v1, 0x3

    .line 304
    .line 305
    if-eq v9, v5, :cond_4

    .line 306
    .line 307
    move v5, v8

    .line 308
    goto :goto_4

    .line 309
    :cond_4
    move v5, v6

    .line 310
    :goto_4
    and-int/2addr v1, v8

    .line 311
    invoke-virtual {v0, v1, v5}, Lki2;->Y(IZ)Z

    .line 312
    .line 313
    .line 314
    move-result v1

    .line 315
    if-eqz v1, :cond_7

    .line 316
    .line 317
    const-wide v11, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    cmp-long v1, v2, v11

    .line 323
    .line 324
    if-eqz v1, :cond_6

    .line 325
    .line 326
    const v1, -0x4a262578

    .line 327
    .line 328
    .line 329
    invoke-virtual {v0, v1}, Lki2;->h0(I)V

    .line 330
    .line 331
    .line 332
    invoke-static {v2, v3}, Lzs1;->b(J)F

    .line 333
    .line 334
    .line 335
    move-result v11

    .line 336
    invoke-static {v2, v3}, Lzs1;->a(J)F

    .line 337
    .line 338
    .line 339
    move-result v12

    .line 340
    const/4 v14, 0x0

    .line 341
    const/16 v15, 0xc

    .line 342
    .line 343
    const/4 v13, 0x0

    .line 344
    invoke-static/range {v10 .. v15}, Lit6;->k(Lha4;FFFFI)Lha4;

    .line 345
    .line 346
    .line 347
    move-result-object v1

    .line 348
    sget-object v2, Ly6;->k:La40;

    .line 349
    .line 350
    invoke-static {v2, v6}, Lxc0;->c(La40;Z)Ld14;

    .line 351
    .line 352
    .line 353
    move-result-object v2

    .line 354
    iget-wide v9, v0, Lki2;->U:J

    .line 355
    .line 356
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 357
    .line 358
    .line 359
    move-result v3

    .line 360
    invoke-virtual {v0}, Lki2;->m()Lr95;

    .line 361
    .line 362
    .line 363
    move-result-object v5

    .line 364
    invoke-static {v0, v1}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 365
    .line 366
    .line 367
    move-result-object v1

    .line 368
    sget-object v9, Lp41;->d:Ly6;

    .line 369
    .line 370
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 371
    .line 372
    .line 373
    invoke-virtual {v0}, Lki2;->k0()V

    .line 374
    .line 375
    .line 376
    iget-boolean v9, v0, Lki2;->T:Z

    .line 377
    .line 378
    if-eqz v9, :cond_5

    .line 379
    .line 380
    invoke-virtual {v0, v4}, Lki2;->l(Lwg2;)V

    .line 381
    .line 382
    .line 383
    goto :goto_5

    .line 384
    :cond_5
    invoke-virtual {v0}, Lki2;->t0()V

    .line 385
    .line 386
    .line 387
    :goto_5
    sget-object v4, Ly6;->T:Lu31;

    .line 388
    .line 389
    invoke-static {v4, v0, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 390
    .line 391
    .line 392
    sget-object v2, Ly6;->S:Lu31;

    .line 393
    .line 394
    invoke-static {v2, v0, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 395
    .line 396
    .line 397
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 398
    .line 399
    .line 400
    move-result-object v2

    .line 401
    sget-object v3, Ly6;->U:Lu31;

    .line 402
    .line 403
    invoke-static {v3, v0, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 404
    .line 405
    .line 406
    invoke-static {v0}, Lml6;->p(Lki2;)V

    .line 407
    .line 408
    .line 409
    sget-object v2, Ly6;->R:Lu31;

    .line 410
    .line 411
    invoke-static {v2, v0, v1}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 412
    .line 413
    .line 414
    const/4 v1, 0x0

    .line 415
    invoke-static {v1, v0, v6, v8}, Ll80;->q(Lha4;Lki2;II)V

    .line 416
    .line 417
    .line 418
    invoke-virtual {v0, v8}, Lki2;->r(Z)V

    .line 419
    .line 420
    .line 421
    invoke-virtual {v0, v6}, Lki2;->r(Z)V

    .line 422
    .line 423
    .line 424
    goto :goto_6

    .line 425
    :cond_6
    const v1, -0x4a2083ba

    .line 426
    .line 427
    .line 428
    invoke-virtual {v0, v1}, Lki2;->h0(I)V

    .line 429
    .line 430
    .line 431
    invoke-static {v10, v0, v6, v6}, Ll80;->q(Lha4;Lki2;II)V

    .line 432
    .line 433
    .line 434
    invoke-virtual {v0, v6}, Lki2;->r(Z)V

    .line 435
    .line 436
    .line 437
    goto :goto_6

    .line 438
    :cond_7
    invoke-virtual {v0}, Lki2;->b0()V

    .line 439
    .line 440
    .line 441
    :goto_6
    return-object v7

    .line 442
    nop

    .line 443
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
