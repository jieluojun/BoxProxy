.class public final enum Lai1;
.super Ljava/lang/Enum;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final enum h:Lai1;

.field public static final enum i:Lai1;

.field public static final enum j:Lai1;

.field public static final enum k:Lai1;

.field public static final enum l:Lai1;

.field public static final enum m:Lai1;

.field public static final enum n:Lai1;

.field public static final enum o:Lai1;

.field public static final enum p:Lai1;

.field public static final enum q:Lai1;

.field public static final enum r:Lai1;

.field public static final enum s:Lai1;

.field public static final synthetic t:[Lai1;


# direct methods
.method static constructor <clinit>()V
    .locals 14

    .line 1
    new-instance v0, Lai1;

    .line 2
    .line 3
    const-string v1, "INVALID_REGEX"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lai1;->h:Lai1;

    .line 10
    .line 11
    new-instance v1, Lai1;

    .line 12
    .line 13
    const-string v2, "INVALID_SETTINGS"

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 17
    .line 18
    .line 19
    sput-object v1, Lai1;->i:Lai1;

    .line 20
    .line 21
    new-instance v2, Lai1;

    .line 22
    .line 23
    const-string v3, "LOCAL_UNAVAILABLE"

    .line 24
    .line 25
    const/4 v4, 0x2

    .line 26
    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 27
    .line 28
    .line 29
    sput-object v2, Lai1;->j:Lai1;

    .line 30
    .line 31
    new-instance v3, Lai1;

    .line 32
    .line 33
    const-string v4, "REMOTE_UNAVAILABLE"

    .line 34
    .line 35
    const/4 v5, 0x3

    .line 36
    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    sput-object v3, Lai1;->k:Lai1;

    .line 40
    .line 41
    new-instance v4, Lai1;

    .line 42
    .line 43
    const-string v5, "LOCAL_NOT_MATCHED"

    .line 44
    .line 45
    const/4 v6, 0x4

    .line 46
    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 47
    .line 48
    .line 49
    sput-object v4, Lai1;->l:Lai1;

    .line 50
    .line 51
    new-instance v5, Lai1;

    .line 52
    .line 53
    const-string v6, "REMOTE_NOT_MATCHED"

    .line 54
    .line 55
    const/4 v7, 0x5

    .line 56
    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 57
    .line 58
    .line 59
    sput-object v5, Lai1;->m:Lai1;

    .line 60
    .line 61
    new-instance v6, Lai1;

    .line 62
    .line 63
    const-string v7, "LOCAL_AMBIGUOUS"

    .line 64
    .line 65
    const/4 v8, 0x6

    .line 66
    invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 67
    .line 68
    .line 69
    sput-object v6, Lai1;->n:Lai1;

    .line 70
    .line 71
    new-instance v7, Lai1;

    .line 72
    .line 73
    const-string v8, "REMOTE_AMBIGUOUS"

    .line 74
    .line 75
    const/4 v9, 0x7

    .line 76
    invoke-direct {v7, v8, v9}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 77
    .line 78
    .line 79
    sput-object v7, Lai1;->o:Lai1;

    .line 80
    .line 81
    new-instance v8, Lai1;

    .line 82
    .line 83
    const-string v9, "LOCAL_INVALID_VERSION"

    .line 84
    .line 85
    const/16 v10, 0x8

    .line 86
    .line 87
    invoke-direct {v8, v9, v10}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 88
    .line 89
    .line 90
    sput-object v8, Lai1;->p:Lai1;

    .line 91
    .line 92
    new-instance v9, Lai1;

    .line 93
    .line 94
    const-string v10, "REMOTE_INVALID_VERSION"

    .line 95
    .line 96
    const/16 v11, 0x9

    .line 97
    .line 98
    invoke-direct {v9, v10, v11}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 99
    .line 100
    .line 101
    sput-object v9, Lai1;->q:Lai1;

    .line 102
    .line 103
    new-instance v10, Lai1;

    .line 104
    .line 105
    const-string v11, "LOCAL_INVALID_NUMBER"

    .line 106
    .line 107
    const/16 v12, 0xa

    .line 108
    .line 109
    invoke-direct {v10, v11, v12}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 110
    .line 111
    .line 112
    sput-object v10, Lai1;->r:Lai1;

    .line 113
    .line 114
    new-instance v11, Lai1;

    .line 115
    .line 116
    const-string v12, "REMOTE_INVALID_NUMBER"

    .line 117
    .line 118
    const/16 v13, 0xb

    .line 119
    .line 120
    invoke-direct {v11, v12, v13}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 121
    .line 122
    .line 123
    sput-object v11, Lai1;->s:Lai1;

    .line 124
    .line 125
    filled-new-array/range {v0 .. v11}, [Lai1;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    sput-object v0, Lai1;->t:[Lai1;

    .line 130
    .line 131
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lai1;
    .locals 1

    .line 1
    const-class v0, Lai1;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lai1;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lai1;
    .locals 1

    .line 1
    sget-object v0, Lai1;->t:[Lai1;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lai1;

    .line 8
    .line 9
    return-object v0
.end method
