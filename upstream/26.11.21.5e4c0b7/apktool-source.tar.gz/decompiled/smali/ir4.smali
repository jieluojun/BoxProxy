.class public final synthetic Lir4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 14
    iput-byte p3, p0, Lir4;->h:B

    iput-object p1, p0, Lir4;->i:Ljava/lang/Object;

    iput-object p2, p0, Lir4;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Lzd4;B)V
    .locals 0

    .line 13
    iput-byte p3, p0, Lir4;->h:B

    iput-object p1, p0, Lir4;->j:Ljava/lang/Object;

    iput-object p2, p0, Lir4;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lwe7;Lpj;Ljt7;)V
    .locals 0

    .line 1
    const/16 p1, 0x1c

    .line 2
    .line 3
    iput-byte p1, p0, Lir4;->h:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p2, p0, Lir4;->i:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p3, p0, Lir4;->j:Ljava/lang/Object;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 15

    .line 1
    iget-byte v0, p0, Lir4;->h:B

    .line 2
    .line 3
    const-string v1, "*/*"

    .line 4
    .line 5
    const/4 v2, -0x1

    .line 6
    const/4 v3, 0x3

    .line 7
    const/4 v4, 0x2

    .line 8
    const/4 v5, 0x0

    .line 9
    const/4 v6, 0x1

    .line 10
    const/4 v7, 0x0

    .line 11
    sget-object v8, Los7;->a:Los7;

    .line 12
    .line 13
    iget-object v9, p0, Lir4;->j:Ljava/lang/Object;

    .line 14
    .line 15
    iget-object p0, p0, Lir4;->i:Ljava/lang/Object;

    .line 16
    .line 17
    packed-switch v0, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    check-cast p0, Lhh2;

    .line 21
    .line 22
    check-cast v9, Lth7;

    .line 23
    .line 24
    invoke-interface {p0, v9}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    return-object v8

    .line 28
    :pswitch_0
    check-cast p0, Lpj;

    .line 29
    .line 30
    check-cast v9, Ljt7;

    .line 31
    .line 32
    iget-object p0, p0, Lpj;->a:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p0, Lpq3;

    .line 35
    .line 36
    instance-of v0, p0, Loq3;

    .line 37
    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    :try_start_0
    check-cast p0, Loq3;

    .line 41
    .line 42
    iget-object p0, p0, Loq3;->b:Ljava/lang/String;

    .line 43
    .line 44
    check-cast v9, Lxf;

    .line 45
    .line 46
    invoke-virtual {v9, p0}, Lxf;->a(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    .line 48
    .line 49
    :catch_0
    :cond_0
    return-object v8

    .line 50
    :pswitch_1
    check-cast p0, Lod7;

    .line 51
    .line 52
    check-cast v9, Lrb7;

    .line 53
    .line 54
    iget-boolean p0, p0, Lod7;->h:Z

    .line 55
    .line 56
    if-nez p0, :cond_1

    .line 57
    .line 58
    iget-object p0, v9, Lrb7;->G:Loe2;

    .line 59
    .line 60
    iget-boolean v0, p0, Lga4;->u:Z

    .line 61
    .line 62
    if-eqz v0, :cond_1

    .line 63
    .line 64
    iget-object p0, p0, Loe2;->B:Lje2;

    .line 65
    .line 66
    invoke-static {p0}, Lje2;->O1(Lje2;)Z

    .line 67
    .line 68
    .line 69
    :cond_1
    return-object v8

    .line 70
    :pswitch_2
    check-cast p0, Lfb7;

    .line 71
    .line 72
    check-cast v9, Lyu5;

    .line 73
    .line 74
    iget-object v0, p0, Lfb7;->A:Lhn7;

    .line 75
    .line 76
    invoke-virtual {v0}, Lhn7;->f()Lza7;

    .line 77
    .line 78
    .line 79
    iget-boolean v0, p0, Lga4;->u:Z

    .line 80
    .line 81
    if-eqz v0, :cond_2

    .line 82
    .line 83
    sget-object v0, Lw51;->p:Lx51;

    .line 84
    .line 85
    invoke-static {p0, v0}, Lxj;->N(Lr51;Lch5;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    check-cast p0, Lr08;

    .line 90
    .line 91
    check-cast p0, Lbn3;

    .line 92
    .line 93
    iget-object p0, p0, Lbn3;->c:Lf75;

    .line 94
    .line 95
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    check-cast p0, Ljava/lang/Boolean;

    .line 100
    .line 101
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 102
    .line 103
    .line 104
    move-result p0

    .line 105
    if-eqz p0, :cond_2

    .line 106
    .line 107
    move v4, v6

    .line 108
    :cond_2
    iget p0, v9, Lyu5;->h:I

    .line 109
    .line 110
    mul-int/2addr v4, p0

    .line 111
    mul-int/2addr p0, v2

    .line 112
    iput p0, v9, Lyu5;->h:I

    .line 113
    .line 114
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 115
    .line 116
    .line 117
    move-result-object p0

    .line 118
    return-object p0

    .line 119
    :pswitch_3
    check-cast p0, Landroid/content/Context;

    .line 120
    .line 121
    check-cast v9, Landroid/view/textclassifier/TextClassification;

    .line 122
    .line 123
    invoke-virtual {v9}, Landroid/view/textclassifier/TextClassification;->getText()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    if-eqz v0, :cond_3

    .line 128
    .line 129
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 130
    .line 131
    .line 132
    move-result v7

    .line 133
    :cond_3
    invoke-virtual {v9}, Landroid/view/textclassifier/TextClassification;->getIntent()Landroid/content/Intent;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    const/high16 v1, 0xc000000

    .line 138
    .line 139
    invoke-static {p0, v7, v0, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    invoke-static {p0}, Ldl6;->r(Landroid/app/PendingIntent;)V

    .line 144
    .line 145
    .line 146
    return-object v8

    .line 147
    :pswitch_4
    check-cast p0, Lay7;

    .line 148
    .line 149
    check-cast v9, Lm17;

    .line 150
    .line 151
    iget-object v0, v9, Lm17;->a:Ljava/lang/String;

    .line 152
    .line 153
    invoke-virtual {p0, v0}, Lay7;->m(Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    return-object v8

    .line 157
    :pswitch_5
    check-cast p0, Lwg2;

    .line 158
    .line 159
    check-cast v9, Lwg2;

    .line 160
    .line 161
    invoke-interface {p0}, Lwg2;->a()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    invoke-interface {v9}, Lwg2;->a()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    return-object v8

    .line 168
    :pswitch_6
    check-cast p0, Lir6;

    .line 169
    .line 170
    check-cast v9, Lqx3;

    .line 171
    .line 172
    iget-object p0, p0, Lir6;->a:Lzd4;

    .line 173
    .line 174
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 175
    .line 176
    invoke-interface {p0, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    const-string p0, "text/x-shellscript"

    .line 180
    .line 181
    const-string v0, "text/plain"

    .line 182
    .line 183
    filled-new-array {p0, v0, v1}, [Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    invoke-virtual {v9, p0}, Lqx3;->h0(Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    return-object v8

    .line 191
    :pswitch_7
    check-cast v9, Lij6;

    .line 192
    .line 193
    check-cast p0, Lzd4;

    .line 194
    .line 195
    invoke-interface {p0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object p0

    .line 199
    check-cast p0, Lu93;

    .line 200
    .line 201
    iget-wide v0, p0, Lu93;->a:J

    .line 202
    .line 203
    invoke-virtual {v9}, Lij6;->i()Lbi6;

    .line 204
    .line 205
    .line 206
    move-result-object p0

    .line 207
    const-wide v7, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    if-eqz p0, :cond_8

    .line 213
    .line 214
    invoke-virtual {v9}, Lij6;->h()Lar2;

    .line 215
    .line 216
    .line 217
    move-result-object v10

    .line 218
    if-nez v10, :cond_4

    .line 219
    .line 220
    move v10, v2

    .line 221
    goto :goto_0

    .line 222
    :cond_4
    sget-object v11, Ljj6;->a:[I

    .line 223
    .line 224
    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    .line 225
    .line 226
    .line 227
    move-result v10

    .line 228
    aget v10, v11, v10

    .line 229
    .line 230
    :goto_0
    if-eq v10, v2, :cond_8

    .line 231
    .line 232
    if-eq v10, v6, :cond_7

    .line 233
    .line 234
    if-eq v10, v4, :cond_6

    .line 235
    .line 236
    if-eq v10, v3, :cond_5

    .line 237
    .line 238
    invoke-static {}, Lfb1;->a()V

    .line 239
    .line 240
    .line 241
    goto :goto_2

    .line 242
    :cond_5
    const-string p0, "SelectionContainer does not support cursor"

    .line 243
    .line 244
    invoke-static {p0}, Lt32;->d(Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    goto :goto_2

    .line 248
    :cond_6
    iget-object p0, p0, Lbi6;->b:Lai6;

    .line 249
    .line 250
    invoke-static {v9, v0, v1, p0}, Lxp7;->s(Lij6;JLai6;)J

    .line 251
    .line 252
    .line 253
    move-result-wide v7

    .line 254
    goto :goto_1

    .line 255
    :cond_7
    iget-object p0, p0, Lbi6;->a:Lai6;

    .line 256
    .line 257
    invoke-static {v9, v0, v1, p0}, Lxp7;->s(Lij6;JLai6;)J

    .line 258
    .line 259
    .line 260
    move-result-wide v7

    .line 261
    :cond_8
    :goto_1
    new-instance v5, Lhv4;

    .line 262
    .line 263
    invoke-direct {v5, v7, v8}, Lhv4;-><init>(J)V

    .line 264
    .line 265
    .line 266
    :goto_2
    return-object v5

    .line 267
    :pswitch_8
    check-cast p0, Lav5;

    .line 268
    .line 269
    check-cast v9, Lxh6;

    .line 270
    .line 271
    sget-object v0, Lja5;->a:Lcx1;

    .line 272
    .line 273
    invoke-static {v9, v0}, Lxj;->N(Lr51;Lch5;)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object v0

    .line 277
    iput-object v0, p0, Lav5;->h:Ljava/lang/Object;

    .line 278
    .line 279
    return-object v8

    .line 280
    :pswitch_9
    check-cast p0, Lmb6;

    .line 281
    .line 282
    check-cast v9, Lqx3;

    .line 283
    .line 284
    invoke-virtual {p0, v7}, Lmb6;->j(Z)V

    .line 285
    .line 286
    .line 287
    filled-new-array {v1}, [Ljava/lang/String;

    .line 288
    .line 289
    .line 290
    move-result-object p0

    .line 291
    invoke-virtual {v9, p0}, Lqx3;->h0(Ljava/lang/Object;)V

    .line 292
    .line 293
    .line 294
    return-object v8

    .line 295
    :pswitch_a
    check-cast p0, Lkr2;

    .line 296
    .line 297
    check-cast v9, Ls86;

    .line 298
    .line 299
    check-cast p0, Lsa5;

    .line 300
    .line 301
    invoke-virtual {p0, v6}, Lsa5;->a(I)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v9}, Ls86;->e()Ljava/lang/String;

    .line 305
    .line 306
    .line 307
    move-result-object p0

    .line 308
    invoke-virtual {v9}, Ls86;->f()Ljava/util/List;

    .line 309
    .line 310
    .line 311
    move-result-object v0

    .line 312
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 313
    .line 314
    .line 315
    move-result v0

    .line 316
    invoke-virtual {v9}, Ls86;->f()Ljava/util/List;

    .line 317
    .line 318
    .line 319
    move-result-object v1

    .line 320
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 321
    .line 322
    .line 323
    move-result v1

    .line 324
    xor-int/2addr v1, v6

    .line 325
    invoke-virtual {v9, p0, v0, v1}, Ls86;->l(Ljava/lang/String;ZZ)V

    .line 326
    .line 327
    .line 328
    return-object v8

    .line 329
    :pswitch_b
    check-cast p0, La76;

    .line 330
    .line 331
    check-cast v9, Lox0;

    .line 332
    .line 333
    invoke-virtual {p0, v9}, La76;->b(Lox0;)V

    .line 334
    .line 335
    .line 336
    return-object v8

    .line 337
    :pswitch_c
    check-cast p0, Lhh2;

    .line 338
    .line 339
    check-cast v9, Lks6;

    .line 340
    .line 341
    invoke-interface {p0, v9}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 342
    .line 343
    .line 344
    return-object v8

    .line 345
    :pswitch_d
    check-cast p0, Lri1;

    .line 346
    .line 347
    check-cast v9, Ljava/lang/String;

    .line 348
    .line 349
    new-instance v0, Lc86;

    .line 350
    .line 351
    const/16 v1, 0x7fc

    .line 352
    .line 353
    invoke-direct {v0, p0, v9, v5, v1}, Lc86;-><init>(Lri1;Ljava/lang/String;Ljava/lang/String;I)V

    .line 354
    .line 355
    .line 356
    return-object v0

    .line 357
    :pswitch_e
    check-cast p0, Le26;

    .line 358
    .line 359
    check-cast v9, Lhh2;

    .line 360
    .line 361
    iget-object p0, p0, Le26;->d:Lvo5;

    .line 362
    .line 363
    if-eqz p0, :cond_9

    .line 364
    .line 365
    invoke-interface {v9, p0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 366
    .line 367
    .line 368
    :cond_9
    return-object v8

    .line 369
    :pswitch_f
    check-cast p0, Lav5;

    .line 370
    .line 371
    check-cast v9, Lde;

    .line 372
    .line 373
    iget-object v0, v9, Lde;->w:Lmo1;

    .line 374
    .line 375
    invoke-virtual {v0}, Lmo1;->a()Ljava/lang/Object;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    iput-object v0, p0, Lav5;->h:Ljava/lang/Object;

    .line 380
    .line 381
    return-object v8

    .line 382
    :pswitch_10
    check-cast p0, Lyv5;

    .line 383
    .line 384
    check-cast v9, Ljava/lang/String;

    .line 385
    .line 386
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 387
    .line 388
    .line 389
    iget-object p0, p0, Lyv5;->h:Ljava/util/regex/Pattern;

    .line 390
    .line 391
    invoke-virtual {p0, v9}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 392
    .line 393
    .line 394
    move-result-object p0

    .line 395
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 396
    .line 397
    .line 398
    invoke-static {p0, v7, v9}, Ls33;->N(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Llz3;

    .line 399
    .line 400
    .line 401
    move-result-object p0

    .line 402
    return-object p0

    .line 403
    :pswitch_11
    check-cast p0, Lud4;

    .line 404
    .line 405
    check-cast v9, Lq51;

    .line 406
    .line 407
    iget-object v0, p0, Lud4;->b:[Ljava/lang/Object;

    .line 408
    .line 409
    iget-object p0, p0, Lud4;->a:[J

    .line 410
    .line 411
    array-length v1, p0

    .line 412
    sub-int/2addr v1, v4

    .line 413
    if-ltz v1, :cond_d

    .line 414
    .line 415
    move v2, v7

    .line 416
    :goto_3
    aget-wide v3, p0, v2

    .line 417
    .line 418
    not-long v5, v3

    .line 419
    const/4 v10, 0x7

    .line 420
    shl-long/2addr v5, v10

    .line 421
    and-long/2addr v5, v3

    .line 422
    const-wide v10, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    and-long/2addr v5, v10

    .line 428
    cmp-long v5, v5, v10

    .line 429
    .line 430
    if-eqz v5, :cond_c

    .line 431
    .line 432
    sub-int v5, v2, v1

    .line 433
    .line 434
    not-int v5, v5

    .line 435
    ushr-int/lit8 v5, v5, 0x1f

    .line 436
    .line 437
    const/16 v6, 0x8

    .line 438
    .line 439
    rsub-int/lit8 v5, v5, 0x8

    .line 440
    .line 441
    move v10, v7

    .line 442
    :goto_4
    if-ge v10, v5, :cond_b

    .line 443
    .line 444
    const-wide/16 v11, 0xff

    .line 445
    .line 446
    and-long/2addr v11, v3

    .line 447
    const-wide/16 v13, 0x80

    .line 448
    .line 449
    cmp-long v11, v11, v13

    .line 450
    .line 451
    if-gez v11, :cond_a

    .line 452
    .line 453
    shl-int/lit8 v11, v2, 0x3

    .line 454
    .line 455
    add-int/2addr v11, v10

    .line 456
    aget-object v11, v0, v11

    .line 457
    .line 458
    invoke-virtual {v9, v11}, Lq51;->B(Ljava/lang/Object;)V

    .line 459
    .line 460
    .line 461
    :cond_a
    shr-long/2addr v3, v6

    .line 462
    add-int/lit8 v10, v10, 0x1

    .line 463
    .line 464
    goto :goto_4

    .line 465
    :cond_b
    if-ne v5, v6, :cond_d

    .line 466
    .line 467
    :cond_c
    if-eq v2, v1, :cond_d

    .line 468
    .line 469
    add-int/lit8 v2, v2, 0x1

    .line 470
    .line 471
    goto :goto_3

    .line 472
    :cond_d
    return-object v8

    .line 473
    :pswitch_12
    check-cast p0, Ltr5;

    .line 474
    .line 475
    check-cast v9, Ljava/util/List;

    .line 476
    .line 477
    invoke-virtual {p0}, Ltr5;->b()Lsv5;

    .line 478
    .line 479
    .line 480
    move-result-object v0

    .line 481
    sget-object v1, Lnv5;->a:Lnv5;

    .line 482
    .line 483
    invoke-static {v0, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 484
    .line 485
    .line 486
    move-result v1

    .line 487
    const-string v2, ""

    .line 488
    .line 489
    if-nez v1, :cond_f

    .line 490
    .line 491
    sget-object v1, Lov5;->a:Lov5;

    .line 492
    .line 493
    invoke-static {v0, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 494
    .line 495
    .line 496
    move-result v1

    .line 497
    if-eqz v1, :cond_10

    .line 498
    .line 499
    invoke-virtual {p0}, Ltr5;->c()F

    .line 500
    .line 501
    .line 502
    move-result p0

    .line 503
    float-to-double v0, p0

    .line 504
    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    .line 505
    .line 506
    cmpl-double p0, v0, v3

    .line 507
    .line 508
    if-lez p0, :cond_f

    .line 509
    .line 510
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 511
    .line 512
    .line 513
    move-result p0

    .line 514
    if-lez p0, :cond_e

    .line 515
    .line 516
    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 517
    .line 518
    .line 519
    move-result-object v2

    .line 520
    :cond_e
    move-object v5, v2

    .line 521
    check-cast v5, Ljava/lang/String;

    .line 522
    .line 523
    goto :goto_5

    .line 524
    :cond_f
    move-object v5, v2

    .line 525
    goto :goto_5

    .line 526
    :cond_10
    sget-object p0, Lrv5;->a:Lrv5;

    .line 527
    .line 528
    invoke-static {v0, p0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 529
    .line 530
    .line 531
    move-result p0

    .line 532
    if-eqz p0, :cond_12

    .line 533
    .line 534
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 535
    .line 536
    .line 537
    move-result p0

    .line 538
    if-ge v6, p0, :cond_11

    .line 539
    .line 540
    invoke-interface {v9, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 541
    .line 542
    .line 543
    move-result-object v2

    .line 544
    :cond_11
    move-object v5, v2

    .line 545
    check-cast v5, Ljava/lang/String;

    .line 546
    .line 547
    goto :goto_5

    .line 548
    :cond_12
    sget-object p0, Lqv5;->a:Lqv5;

    .line 549
    .line 550
    invoke-static {v0, p0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 551
    .line 552
    .line 553
    move-result p0

    .line 554
    if-eqz p0, :cond_14

    .line 555
    .line 556
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 557
    .line 558
    .line 559
    move-result p0

    .line 560
    if-ge v4, p0, :cond_13

    .line 561
    .line 562
    invoke-interface {v9, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 563
    .line 564
    .line 565
    move-result-object v2

    .line 566
    :cond_13
    move-object v5, v2

    .line 567
    check-cast v5, Ljava/lang/String;

    .line 568
    .line 569
    goto :goto_5

    .line 570
    :cond_14
    sget-object p0, Lpv5;->a:Lpv5;

    .line 571
    .line 572
    invoke-static {v0, p0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 573
    .line 574
    .line 575
    move-result p0

    .line 576
    if-eqz p0, :cond_16

    .line 577
    .line 578
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 579
    .line 580
    .line 581
    move-result p0

    .line 582
    if-ge v3, p0, :cond_15

    .line 583
    .line 584
    invoke-interface {v9, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 585
    .line 586
    .line 587
    move-result-object v2

    .line 588
    :cond_15
    move-object v5, v2

    .line 589
    check-cast v5, Ljava/lang/String;

    .line 590
    .line 591
    goto :goto_5

    .line 592
    :cond_16
    invoke-static {}, Lfb1;->a()V

    .line 593
    .line 594
    .line 595
    :goto_5
    return-object v5

    .line 596
    :pswitch_13
    check-cast p0, Lhh2;

    .line 597
    .line 598
    check-cast v9, Ljo5;

    .line 599
    .line 600
    invoke-interface {p0, v9}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 601
    .line 602
    .line 603
    return-object v8

    .line 604
    :pswitch_14
    check-cast p0, Lyh6;

    .line 605
    .line 606
    check-cast v9, Ltm3;

    .line 607
    .line 608
    if-eqz p0, :cond_1a

    .line 609
    .line 610
    invoke-virtual {v9}, Ltm3;->j()Lmm3;

    .line 611
    .line 612
    .line 613
    move-result-object v0

    .line 614
    iget v1, p0, Lyh6;->c:I

    .line 615
    .line 616
    iget-object v2, p0, Lyh6;->d:Ljava/lang/String;

    .line 617
    .line 618
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 619
    .line 620
    .line 621
    iget-object v3, v0, Lmm3;->n:Ljava/util/List;

    .line 622
    .line 623
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 624
    .line 625
    .line 626
    move-result-object v3

    .line 627
    :cond_17
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 628
    .line 629
    .line 630
    move-result v4

    .line 631
    if-eqz v4, :cond_18

    .line 632
    .line 633
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 634
    .line 635
    .line 636
    move-result-object v4

    .line 637
    move-object v6, v4

    .line 638
    check-cast v6, Lnm3;

    .line 639
    .line 640
    iget v8, v6, Lnm3;->a:I

    .line 641
    .line 642
    if-ne v8, v1, :cond_17

    .line 643
    .line 644
    iget-object v6, v6, Lnm3;->i:Ljava/lang/Object;

    .line 645
    .line 646
    invoke-virtual {v6, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 647
    .line 648
    .line 649
    move-result v6

    .line 650
    if-eqz v6, :cond_17

    .line 651
    .line 652
    goto :goto_6

    .line 653
    :cond_18
    move-object v4, v5

    .line 654
    :goto_6
    check-cast v4, Lnm3;

    .line 655
    .line 656
    if-eqz v4, :cond_19

    .line 657
    .line 658
    iget v1, v4, Lnm3;->l:I

    .line 659
    .line 660
    iget v2, v4, Lnm3;->m:I

    .line 661
    .line 662
    add-int/2addr v1, v2

    .line 663
    iget v2, v0, Lmm3;->o:I

    .line 664
    .line 665
    invoke-static {v2, v7}, Ljava/lang/Math;->max(II)I

    .line 666
    .line 667
    .line 668
    move-result v2

    .line 669
    if-le v1, v2, :cond_19

    .line 670
    .line 671
    iget v1, v4, Lnm3;->l:I

    .line 672
    .line 673
    iget v0, v0, Lmm3;->p:I

    .line 674
    .line 675
    if-lt v1, v0, :cond_1a

    .line 676
    .line 677
    :cond_19
    move-object v5, p0

    .line 678
    :cond_1a
    return-object v5

    .line 679
    :pswitch_15
    check-cast p0, Le41;

    .line 680
    .line 681
    check-cast v9, Llh2;

    .line 682
    .line 683
    iput-object v9, p0, Le41;->d:Llh2;

    .line 684
    .line 685
    return-object v8

    .line 686
    :pswitch_16
    check-cast v9, Lp64;

    .line 687
    .line 688
    check-cast p0, Lzd4;

    .line 689
    .line 690
    invoke-interface {p0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 691
    .line 692
    .line 693
    move-result-object v0

    .line 694
    check-cast v0, Ljava/util/List;

    .line 695
    .line 696
    new-instance v1, Lb74;

    .line 697
    .line 698
    const/16 v2, 0x19

    .line 699
    .line 700
    invoke-direct {v1, p0, v2}, Lb74;-><init>(Lzd4;B)V

    .line 701
    .line 702
    .line 703
    invoke-virtual {v9, v0, v1}, Lp64;->a(Ljava/util/List;Lhh2;)I

    .line 704
    .line 705
    .line 706
    return-object v8

    .line 707
    :pswitch_17
    check-cast p0, Lhh2;

    .line 708
    .line 709
    check-cast v9, Lbd5;

    .line 710
    .line 711
    iget-object v0, v9, Lbd5;->a:Lzd4;

    .line 712
    .line 713
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 714
    .line 715
    .line 716
    move-result-object v0

    .line 717
    check-cast v0, Ljava/util/List;

    .line 718
    .line 719
    invoke-interface {p0, v0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 720
    .line 721
    .line 722
    return-object v8

    .line 723
    :pswitch_18
    check-cast p0, Lzd4;

    .line 724
    .line 725
    check-cast v9, Ly25;

    .line 726
    .line 727
    invoke-interface {p0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 728
    .line 729
    .line 730
    move-result-object p0

    .line 731
    check-cast p0, Lhh2;

    .line 732
    .line 733
    invoke-interface {p0, v9}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 734
    .line 735
    .line 736
    return-object v8

    .line 737
    :pswitch_19
    check-cast p0, Lhh2;

    .line 738
    .line 739
    check-cast v9, Lc91;

    .line 740
    .line 741
    invoke-interface {p0, v9}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 742
    .line 743
    .line 744
    return-object v8

    .line 745
    :pswitch_1a
    check-cast p0, Ljava/lang/String;

    .line 746
    .line 747
    check-cast v9, Lcv4;

    .line 748
    .line 749
    sget-object v0, Lz07;->h:Lz07;

    .line 750
    .line 751
    new-array v1, v7, [Lgl6;

    .line 752
    .line 753
    new-instance v2, Ln64;

    .line 754
    .line 755
    const/16 v3, 0x10

    .line 756
    .line 757
    invoke-direct {v2, v9, v3}, Ln64;-><init>(Ljava/lang/Object;B)V

    .line 758
    .line 759
    .line 760
    invoke-static {p0, v0, v1, v2}, Ljl6;->b(Ljava/lang/String;Lml6;[Lgl6;Lhh2;)Lil6;

    .line 761
    .line 762
    .line 763
    move-result-object p0

    .line 764
    return-object p0

    .line 765
    :pswitch_1b
    check-cast p0, Lvh7;

    .line 766
    .line 767
    check-cast v9, Lju5;

    .line 768
    .line 769
    iget-object p0, p0, Lvh7;->i:Ljava/lang/Object;

    .line 770
    .line 771
    check-cast p0, Lty;

    .line 772
    .line 773
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 774
    .line 775
    .line 776
    move-result p0

    .line 777
    if-nez p0, :cond_1b

    .line 778
    .line 779
    invoke-virtual {v9}, Lju5;->a()Ljava/lang/Object;

    .line 780
    .line 781
    .line 782
    :cond_1b
    return-object v8

    .line 783
    :pswitch_1c
    check-cast p0, Lzd4;

    .line 784
    .line 785
    check-cast v9, Lnx6;

    .line 786
    .line 787
    invoke-interface {p0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 788
    .line 789
    .line 790
    move-result-object p0

    .line 791
    check-cast p0, Lhh2;

    .line 792
    .line 793
    invoke-interface {p0, v9}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 794
    .line 795
    .line 796
    return-object v8

    .line 797
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
