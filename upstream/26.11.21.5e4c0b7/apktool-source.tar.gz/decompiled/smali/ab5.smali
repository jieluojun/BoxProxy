.class public final Lab5;
.super Lgd1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public k:Ljava/lang/CharSequence;

.field public l:Landroid/view/textclassifier/TextClassifier;

.field public m:Loe4;

.field public n:Ls97;

.field public o:Loe4;

.field public p:J

.field public synthetic q:Ljava/lang/Object;

.field public final synthetic r:Ldb5;

.field public s:I


# direct methods
.method public constructor <init>(Ldb5;Lgd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lab5;->r:Ldb5;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lgd1;-><init>(Lfd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iput-object p1, p0, Lab5;->q:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lab5;->s:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lab5;->s:I

    .line 9
    .line 10
    const-wide/16 v2, 0x0

    .line 11
    .line 12
    const/4 v4, 0x0

    .line 13
    iget-object v0, p0, Lab5;->r:Ldb5;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    move-object v5, p0

    .line 17
    invoke-virtual/range {v0 .. v5}, Ldb5;->a(Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassifier;Lgd1;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0
.end method
