.class public final Lof7;
.super Lcg3;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final L:Landroid/graphics/Path;

.field public M:F

.field public final N:Z


# direct methods
.method public constructor <init>(Lmf7;Landroid/graphics/Path;FZLjava/util/List;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p5}, Lcg3;-><init>(Lw97;Ljava/util/List;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lof7;->L:Landroid/graphics/Path;

    .line 5
    .line 6
    iput p3, p0, Lof7;->M:F

    .line 7
    .line 8
    iput-boolean p4, p0, Lof7;->N:Z

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final h(Lyw5;Landroid/graphics/Canvas;)V
    .locals 0

    .line 1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p1, "TextPath is rendered via renderTextPathNode(node, processor) during text traversal"

    .line 4
    .line 5
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p0
.end method
