.class public final Lrf5;
.super Lml6;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final e:Lrf5;

.field public static final f:Lrf5;

.field public static final g:Lrf5;

.field public static final h:Lrf5;

.field public static final i:Lrf5;

.field public static final j:Lrf5;

.field public static final k:Lrf5;

.field public static final l:Lrf5;

.field public static final m:Lrf5;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lrf5;

    .line 2
    .line 3
    invoke-direct {v0}, Lml6;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lrf5;->e:Lrf5;

    .line 7
    .line 8
    new-instance v0, Lrf5;

    .line 9
    .line 10
    invoke-direct {v0}, Lml6;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, Lrf5;->f:Lrf5;

    .line 14
    .line 15
    new-instance v0, Lrf5;

    .line 16
    .line 17
    invoke-direct {v0}, Lml6;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lrf5;->g:Lrf5;

    .line 21
    .line 22
    new-instance v0, Lrf5;

    .line 23
    .line 24
    invoke-direct {v0}, Lml6;-><init>()V

    .line 25
    .line 26
    .line 27
    sput-object v0, Lrf5;->h:Lrf5;

    .line 28
    .line 29
    new-instance v0, Lrf5;

    .line 30
    .line 31
    invoke-direct {v0}, Lml6;-><init>()V

    .line 32
    .line 33
    .line 34
    sput-object v0, Lrf5;->i:Lrf5;

    .line 35
    .line 36
    new-instance v0, Lrf5;

    .line 37
    .line 38
    invoke-direct {v0}, Lml6;-><init>()V

    .line 39
    .line 40
    .line 41
    sput-object v0, Lrf5;->j:Lrf5;

    .line 42
    .line 43
    new-instance v0, Lrf5;

    .line 44
    .line 45
    invoke-direct {v0}, Lml6;-><init>()V

    .line 46
    .line 47
    .line 48
    sput-object v0, Lrf5;->k:Lrf5;

    .line 49
    .line 50
    new-instance v0, Lrf5;

    .line 51
    .line 52
    invoke-direct {v0}, Lml6;-><init>()V

    .line 53
    .line 54
    .line 55
    sput-object v0, Lrf5;->l:Lrf5;

    .line 56
    .line 57
    new-instance v0, Lrf5;

    .line 58
    .line 59
    invoke-direct {v0}, Lml6;-><init>()V

    .line 60
    .line 61
    .line 62
    sput-object v0, Lrf5;->m:Lrf5;

    .line 63
    .line 64
    return-void
.end method
