.class public final Llf5;
.super Le3;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final i:Llf5;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Llf5;

    .line 2
    .line 3
    sget-object v1, Lvb5;->j:Lvb5;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Le3;-><init>(Lhi1;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Llf5;->i:Llf5;

    .line 9
    .line 10
    return-void
.end method
