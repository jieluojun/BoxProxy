.class public final Lt74;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lum2;

.field public b:Lq21;

.field public final c:Lf75;

.field public final d:Lf75;


# direct methods
.method public constructor <init>(Lum2;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lt74;->a:Lum2;

    .line 5
    .line 6
    sget-object p1, Lw04;->o:Lq21;

    .line 7
    .line 8
    iput-object p1, p0, Lt74;->b:Lq21;

    .line 9
    .line 10
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 11
    .line 12
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Lt74;->c:Lf75;

    .line 17
    .line 18
    new-instance p1, Lws1;

    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    invoke-direct {p1, v0}, Lws1;-><init>(F)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    iput-object p1, p0, Lt74;->d:Lf75;

    .line 29
    .line 30
    return-void
.end method
