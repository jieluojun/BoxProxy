.class final Lm7;
.super Lpa4;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lpa4;"
    }
.end annotation


# instance fields
.field public final h:Llh2;


# direct methods
.method public constructor <init>(Llh2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lm7;->h:Llh2;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lga4;
    .locals 1

    .line 1
    new-instance v0, Lo7;

    .line 2
    .line 3
    iget-object p0, p0, Lm7;->h:Llh2;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Lo7;-><init>(Llh2;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final b(Lga4;)V
    .locals 0

    .line 1
    check-cast p1, Lo7;

    .line 2
    .line 3
    iget-object p0, p0, Lm7;->h:Llh2;

    .line 4
    .line 5
    iput-object p0, p1, Lo7;->x:Llh2;

    .line 6
    .line 7
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lm7;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, Lm7;

    .line 8
    .line 9
    iget-object p1, p1, Lm7;->h:Llh2;

    .line 10
    .line 11
    iget-object p0, p0, Lm7;->h:Llh2;

    .line 12
    .line 13
    if-eq p0, p1, :cond_1

    .line 14
    .line 15
    :cond_0
    const/4 p0, 0x0

    .line 16
    return p0

    .line 17
    :cond_1
    const/4 p0, 0x1

    .line 18
    return p0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lm7;->h:Llh2;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
