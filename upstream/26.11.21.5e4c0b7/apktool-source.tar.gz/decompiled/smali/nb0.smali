.class public final synthetic Lnb0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lkb0;


# direct methods
.method public synthetic constructor <init>(Lkb0;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lnb0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lnb0;->i:Lkb0;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method private final d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    check-cast p1, Lki2;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    and-int/lit8 v0, p2, 0x3

    .line 10
    .line 11
    const/4 v1, 0x2

    .line 12
    const/4 v2, 0x1

    .line 13
    if-eq v0, v1, :cond_0

    .line 14
    .line 15
    move v0, v2

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    :goto_0
    and-int/2addr p2, v2

    .line 19
    invoke-virtual {p1, p2, v0}, Lki2;->Y(IZ)Z

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    if-eqz p2, :cond_5

    .line 24
    .line 25
    iget-object p0, p0, Lnb0;->i:Lkb0;

    .line 26
    .line 27
    iget-object v2, p0, Lkb0;->e:Lhj4;

    .line 28
    .line 29
    invoke-virtual {p1, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result p2

    .line 33
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    sget-object v8, Lz41;->a:Lql0;

    .line 38
    .line 39
    if-nez p2, :cond_1

    .line 40
    .line 41
    if-ne v0, v8, :cond_2

    .line 42
    .line 43
    :cond_1
    new-instance v0, Lwb0;

    .line 44
    .line 45
    const/4 v6, 0x0

    .line 46
    const/4 v7, 0x0

    .line 47
    const/4 v1, 0x0

    .line 48
    const-class v3, Lhj4;

    .line 49
    .line 50
    const-string v4, "pop"

    .line 51
    .line 52
    const-string v5, "pop()V"

    .line 53
    .line 54
    invoke-direct/range {v0 .. v7}, Lwb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :cond_2
    check-cast v0, Lwh2;

    .line 61
    .line 62
    check-cast v0, Lwg2;

    .line 63
    .line 64
    invoke-virtual {p1, p0}, Lki2;->i(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result p2

    .line 68
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    if-nez p2, :cond_3

    .line 73
    .line 74
    if-ne v1, v8, :cond_4

    .line 75
    .line 76
    :cond_3
    new-instance v1, Lob0;

    .line 77
    .line 78
    const/16 p2, 0xd

    .line 79
    .line 80
    invoke-direct {v1, p0, p2}, Lob0;-><init>(Lkb0;B)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {p1, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    :cond_4
    check-cast v1, Lhh2;

    .line 87
    .line 88
    sget-object p0, Lit6;->c:Lk92;

    .line 89
    .line 90
    const/16 p2, 0x180

    .line 91
    .line 92
    invoke-static {v0, v1, p0, p1, p2}, Lha1;->x(Lwg2;Lhh2;Lha4;Lki2;I)V

    .line 93
    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_5
    invoke-virtual {p1}, Lki2;->b0()V

    .line 97
    .line 98
    .line 99
    :goto_1
    sget-object p0, Los7;->a:Los7;

    .line 100
    .line 101
    return-object p0
.end method

.method private final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    check-cast p1, Lki2;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    and-int/lit8 v0, p2, 0x3

    .line 10
    .line 11
    const/4 v1, 0x2

    .line 12
    const/4 v2, 0x1

    .line 13
    if-eq v0, v1, :cond_0

    .line 14
    .line 15
    move v0, v2

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    :goto_0
    and-int/2addr p2, v2

    .line 19
    invoke-virtual {p1, p2, v0}, Lki2;->Y(IZ)Z

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    if-eqz p2, :cond_3

    .line 24
    .line 25
    iget-object p0, p0, Lnb0;->i:Lkb0;

    .line 26
    .line 27
    iget-object v2, p0, Lkb0;->e:Lhj4;

    .line 28
    .line 29
    invoke-virtual {p1, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result p0

    .line 33
    invoke-virtual {p1}, Lki2;->T()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    if-nez p0, :cond_1

    .line 38
    .line 39
    sget-object p0, Lz41;->a:Lql0;

    .line 40
    .line 41
    if-ne p2, p0, :cond_2

    .line 42
    .line 43
    :cond_1
    new-instance v0, Lwb0;

    .line 44
    .line 45
    const/4 v6, 0x0

    .line 46
    const/4 v7, 0x4

    .line 47
    const/4 v1, 0x0

    .line 48
    const-class v3, Lhj4;

    .line 49
    .line 50
    const-string v4, "pop"

    .line 51
    .line 52
    const-string v5, "pop()V"

    .line 53
    .line 54
    invoke-direct/range {v0 .. v7}, Lwb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    move-object p2, v0

    .line 61
    :cond_2
    check-cast p2, Lwh2;

    .line 62
    .line 63
    check-cast p2, Lwg2;

    .line 64
    .line 65
    sget-object p0, Lit6;->c:Lk92;

    .line 66
    .line 67
    const/16 v0, 0x30

    .line 68
    .line 69
    invoke-static {p2, p0, p1, v0}, Lyg0;->q(Lwg2;Lha4;Lki2;I)V

    .line 70
    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_3
    invoke-virtual {p1}, Lki2;->b0()V

    .line 74
    .line 75
    .line 76
    :goto_1
    sget-object p0, Los7;->a:Los7;

    .line 77
    .line 78
    return-object p0
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lnb0;->h:B

    .line 4
    .line 5
    const/16 v2, 0x9

    .line 6
    .line 7
    const/16 v3, 0x8

    .line 8
    .line 9
    const/16 v4, 0x180

    .line 10
    .line 11
    const/16 v5, 0x30

    .line 12
    .line 13
    sget-object v6, Los7;->a:Los7;

    .line 14
    .line 15
    sget-object v7, Lz41;->a:Lql0;

    .line 16
    .line 17
    const/4 v8, 0x2

    .line 18
    const/4 v9, 0x1

    .line 19
    const/4 v10, 0x0

    .line 20
    iget-object v11, v0, Lnb0;->i:Lkb0;

    .line 21
    .line 22
    packed-switch v1, :pswitch_data_0

    .line 23
    .line 24
    .line 25
    move-object/from16 v0, p1

    .line 26
    .line 27
    check-cast v0, Lki2;

    .line 28
    .line 29
    move-object/from16 v1, p2

    .line 30
    .line 31
    check-cast v1, Ljava/lang/Integer;

    .line 32
    .line 33
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    and-int/lit8 v2, v1, 0x3

    .line 38
    .line 39
    if-eq v2, v8, :cond_0

    .line 40
    .line 41
    move v2, v9

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    move v2, v10

    .line 44
    :goto_0
    and-int/2addr v1, v9

    .line 45
    invoke-virtual {v0, v1, v2}, Lki2;->Y(IZ)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-eqz v1, :cond_3

    .line 50
    .line 51
    iget-object v1, v11, Lkb0;->c:Lor7;

    .line 52
    .line 53
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 54
    .line 55
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    if-nez v2, :cond_1

    .line 64
    .line 65
    if-ne v3, v7, :cond_2

    .line 66
    .line 67
    :cond_1
    new-instance v12, Ltb0;

    .line 68
    .line 69
    const/16 v18, 0x0

    .line 70
    .line 71
    const/16 v19, 0x1a

    .line 72
    .line 73
    const/4 v13, 0x0

    .line 74
    const-class v15, Lhj4;

    .line 75
    .line 76
    const-string v16, "pop"

    .line 77
    .line 78
    const-string v17, "pop()V"

    .line 79
    .line 80
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    move-object v3, v12

    .line 87
    :cond_2
    check-cast v3, Lwh2;

    .line 88
    .line 89
    check-cast v3, Lwg2;

    .line 90
    .line 91
    invoke-static {v1, v3, v0, v10}, Lf48;->d(Lor7;Lwg2;Lki2;I)V

    .line 92
    .line 93
    .line 94
    goto :goto_1

    .line 95
    :cond_3
    invoke-virtual {v0}, Lki2;->b0()V

    .line 96
    .line 97
    .line 98
    :goto_1
    return-object v6

    .line 99
    :pswitch_0
    invoke-direct/range {p0 .. p2}, Lnb0;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    return-object v0

    .line 104
    :pswitch_1
    invoke-direct/range {p0 .. p2}, Lnb0;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    return-object v0

    .line 109
    :pswitch_2
    move-object/from16 v0, p1

    .line 110
    .line 111
    check-cast v0, Lki2;

    .line 112
    .line 113
    move-object/from16 v1, p2

    .line 114
    .line 115
    check-cast v1, Ljava/lang/Integer;

    .line 116
    .line 117
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    and-int/lit8 v2, v1, 0x3

    .line 122
    .line 123
    if-eq v2, v8, :cond_4

    .line 124
    .line 125
    move v10, v9

    .line 126
    :cond_4
    and-int/2addr v1, v9

    .line 127
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    if-eqz v1, :cond_9

    .line 132
    .line 133
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 134
    .line 135
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v1

    .line 139
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    if-nez v1, :cond_5

    .line 144
    .line 145
    if-ne v2, v7, :cond_6

    .line 146
    .line 147
    :cond_5
    new-instance v12, Ltb0;

    .line 148
    .line 149
    const/16 v18, 0x0

    .line 150
    .line 151
    const/16 v19, 0x1c

    .line 152
    .line 153
    const/4 v13, 0x0

    .line 154
    const-class v15, Lhj4;

    .line 155
    .line 156
    const-string v16, "pop"

    .line 157
    .line 158
    const-string v17, "pop()V"

    .line 159
    .line 160
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    move-object v2, v12

    .line 167
    :cond_6
    check-cast v2, Lwh2;

    .line 168
    .line 169
    check-cast v2, Lwg2;

    .line 170
    .line 171
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v1

    .line 175
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v3

    .line 179
    if-nez v1, :cond_7

    .line 180
    .line 181
    if-ne v3, v7, :cond_8

    .line 182
    .line 183
    :cond_7
    new-instance v3, Lob0;

    .line 184
    .line 185
    const/16 v1, 0xc

    .line 186
    .line 187
    invoke-direct {v3, v11, v1}, Lob0;-><init>(Lkb0;B)V

    .line 188
    .line 189
    .line 190
    invoke-virtual {v0, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    :cond_8
    check-cast v3, Lhh2;

    .line 194
    .line 195
    sget-object v1, Lit6;->c:Lk92;

    .line 196
    .line 197
    invoke-static {v2, v3, v1, v0, v4}, Lnt7;->B(Lwg2;Lhh2;Lha4;Lki2;I)V

    .line 198
    .line 199
    .line 200
    goto :goto_2

    .line 201
    :cond_9
    invoke-virtual {v0}, Lki2;->b0()V

    .line 202
    .line 203
    .line 204
    :goto_2
    return-object v6

    .line 205
    :pswitch_3
    move-object/from16 v0, p1

    .line 206
    .line 207
    check-cast v0, Lki2;

    .line 208
    .line 209
    move-object/from16 v1, p2

    .line 210
    .line 211
    check-cast v1, Ljava/lang/Integer;

    .line 212
    .line 213
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 214
    .line 215
    .line 216
    move-result v1

    .line 217
    and-int/lit8 v2, v1, 0x3

    .line 218
    .line 219
    if-eq v2, v8, :cond_a

    .line 220
    .line 221
    move v10, v9

    .line 222
    :cond_a
    and-int/2addr v1, v9

    .line 223
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    if-eqz v1, :cond_27

    .line 228
    .line 229
    iget-object v1, v11, Lkb0;->a:Lgw;

    .line 230
    .line 231
    iget-object v14, v11, Lkb0;->b:Llw;

    .line 232
    .line 233
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 234
    .line 235
    .line 236
    move-result v2

    .line 237
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    move-result-object v3

    .line 241
    if-nez v2, :cond_b

    .line 242
    .line 243
    if-ne v3, v7, :cond_c

    .line 244
    .line 245
    :cond_b
    new-instance v12, Lp2;

    .line 246
    .line 247
    const/16 v18, 0x0

    .line 248
    .line 249
    const/16 v19, 0x1d

    .line 250
    .line 251
    const/4 v13, 0x1

    .line 252
    const-class v15, Llw;

    .line 253
    .line 254
    const-string v16, "setNotificationRefreshIntervalSeconds"

    .line 255
    .line 256
    const-string v17, "setNotificationRefreshIntervalSeconds(I)V"

    .line 257
    .line 258
    invoke-direct/range {v12 .. v19}, Lp2;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 262
    .line 263
    .line 264
    move-object v3, v12

    .line 265
    :cond_c
    check-cast v3, Lwh2;

    .line 266
    .line 267
    move-object v8, v3

    .line 268
    check-cast v8, Lhh2;

    .line 269
    .line 270
    iget-object v14, v11, Lkb0;->b:Llw;

    .line 271
    .line 272
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 273
    .line 274
    .line 275
    move-result v2

    .line 276
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object v3

    .line 280
    if-nez v2, :cond_d

    .line 281
    .line 282
    if-ne v3, v7, :cond_e

    .line 283
    .line 284
    :cond_d
    new-instance v12, Lub0;

    .line 285
    .line 286
    const/16 v18, 0x0

    .line 287
    .line 288
    const/16 v19, 0x4

    .line 289
    .line 290
    const/4 v13, 0x1

    .line 291
    const-class v15, Llw;

    .line 292
    .line 293
    const-string v16, "setNotificationTitle"

    .line 294
    .line 295
    const-string v17, "setNotificationTitle(Ljava/lang/String;)V"

    .line 296
    .line 297
    invoke-direct/range {v12 .. v19}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 301
    .line 302
    .line 303
    move-object v3, v12

    .line 304
    :cond_e
    check-cast v3, Lwh2;

    .line 305
    .line 306
    move-object v9, v3

    .line 307
    check-cast v9, Lhh2;

    .line 308
    .line 309
    iget-object v14, v11, Lkb0;->b:Llw;

    .line 310
    .line 311
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    move-result v2

    .line 315
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v3

    .line 319
    if-nez v2, :cond_f

    .line 320
    .line 321
    if-ne v3, v7, :cond_10

    .line 322
    .line 323
    :cond_f
    new-instance v12, Lub0;

    .line 324
    .line 325
    const/16 v18, 0x0

    .line 326
    .line 327
    const/16 v19, 0x5

    .line 328
    .line 329
    const/4 v13, 0x1

    .line 330
    const-class v15, Llw;

    .line 331
    .line 332
    const-string v16, "setNotificationContent"

    .line 333
    .line 334
    const-string v17, "setNotificationContent(Ljava/lang/String;)V"

    .line 335
    .line 336
    invoke-direct/range {v12 .. v19}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 337
    .line 338
    .line 339
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 340
    .line 341
    .line 342
    move-object v3, v12

    .line 343
    :cond_10
    check-cast v3, Lwh2;

    .line 344
    .line 345
    move-object v10, v3

    .line 346
    check-cast v10, Lhh2;

    .line 347
    .line 348
    iget-object v14, v11, Lkb0;->b:Llw;

    .line 349
    .line 350
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    move-result v2

    .line 354
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object v3

    .line 358
    if-nez v2, :cond_11

    .line 359
    .line 360
    if-ne v3, v7, :cond_12

    .line 361
    .line 362
    :cond_11
    new-instance v12, Lub0;

    .line 363
    .line 364
    const/16 v18, 0x0

    .line 365
    .line 366
    const/16 v19, 0x6

    .line 367
    .line 368
    const/4 v13, 0x1

    .line 369
    const-class v15, Llw;

    .line 370
    .line 371
    const-string v16, "setNotificationClickTarget"

    .line 372
    .line 373
    const-string v17, "setNotificationClickTarget(Lcom/box/app/data/NotificationClickTarget;)V"

    .line 374
    .line 375
    invoke-direct/range {v12 .. v19}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 376
    .line 377
    .line 378
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 379
    .line 380
    .line 381
    move-object v3, v12

    .line 382
    :cond_12
    check-cast v3, Lwh2;

    .line 383
    .line 384
    check-cast v3, Lhh2;

    .line 385
    .line 386
    iget-object v14, v11, Lkb0;->b:Llw;

    .line 387
    .line 388
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 389
    .line 390
    .line 391
    move-result v2

    .line 392
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    move-result-object v4

    .line 396
    if-nez v2, :cond_13

    .line 397
    .line 398
    if-ne v4, v7, :cond_14

    .line 399
    .line 400
    :cond_13
    new-instance v12, Lub0;

    .line 401
    .line 402
    const/16 v18, 0x0

    .line 403
    .line 404
    const/16 v19, 0x7

    .line 405
    .line 406
    const/4 v13, 0x1

    .line 407
    const-class v15, Llw;

    .line 408
    .line 409
    const-string v16, "setNotificationActionReload"

    .line 410
    .line 411
    const-string v17, "setNotificationActionReload(Z)V"

    .line 412
    .line 413
    invoke-direct/range {v12 .. v19}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 414
    .line 415
    .line 416
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 417
    .line 418
    .line 419
    move-object v4, v12

    .line 420
    :cond_14
    check-cast v4, Lwh2;

    .line 421
    .line 422
    move-object v12, v4

    .line 423
    check-cast v12, Lhh2;

    .line 424
    .line 425
    iget-object v15, v11, Lkb0;->b:Llw;

    .line 426
    .line 427
    invoke-virtual {v0, v15}, Lki2;->i(Ljava/lang/Object;)Z

    .line 428
    .line 429
    .line 430
    move-result v2

    .line 431
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    move-result-object v4

    .line 435
    if-nez v2, :cond_15

    .line 436
    .line 437
    if-ne v4, v7, :cond_16

    .line 438
    .line 439
    :cond_15
    new-instance v13, Lub0;

    .line 440
    .line 441
    const/16 v19, 0x0

    .line 442
    .line 443
    const/16 v20, 0x8

    .line 444
    .line 445
    const/4 v14, 0x1

    .line 446
    const-class v16, Llw;

    .line 447
    .line 448
    const-string v17, "setNotificationActionReloadTitle"

    .line 449
    .line 450
    const-string v18, "setNotificationActionReloadTitle(Ljava/lang/String;)V"

    .line 451
    .line 452
    invoke-direct/range {v13 .. v20}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {v0, v13}, Lki2;->q0(Ljava/lang/Object;)V

    .line 456
    .line 457
    .line 458
    move-object v4, v13

    .line 459
    :cond_16
    check-cast v4, Lwh2;

    .line 460
    .line 461
    move-object v13, v4

    .line 462
    check-cast v13, Lhh2;

    .line 463
    .line 464
    iget-object v2, v11, Lkb0;->b:Llw;

    .line 465
    .line 466
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 467
    .line 468
    .line 469
    move-result v4

    .line 470
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 471
    .line 472
    .line 473
    move-result-object v5

    .line 474
    if-nez v4, :cond_17

    .line 475
    .line 476
    if-ne v5, v7, :cond_18

    .line 477
    .line 478
    :cond_17
    new-instance v14, Lub0;

    .line 479
    .line 480
    const/16 v20, 0x0

    .line 481
    .line 482
    const/16 v21, 0x9

    .line 483
    .line 484
    const/4 v15, 0x1

    .line 485
    const-class v17, Llw;

    .line 486
    .line 487
    const-string v18, "setNotificationActionReloadTarget"

    .line 488
    .line 489
    const-string v19, "setNotificationActionReloadTarget(Lcom/box/app/data/NotificationButtonAction;)V"

    .line 490
    .line 491
    move-object/from16 v16, v2

    .line 492
    .line 493
    invoke-direct/range {v14 .. v21}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 494
    .line 495
    .line 496
    invoke-virtual {v0, v14}, Lki2;->q0(Ljava/lang/Object;)V

    .line 497
    .line 498
    .line 499
    move-object v5, v14

    .line 500
    :cond_18
    check-cast v5, Lwh2;

    .line 501
    .line 502
    move-object v14, v5

    .line 503
    check-cast v14, Lhh2;

    .line 504
    .line 505
    iget-object v2, v11, Lkb0;->b:Llw;

    .line 506
    .line 507
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 508
    .line 509
    .line 510
    move-result v4

    .line 511
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 512
    .line 513
    .line 514
    move-result-object v5

    .line 515
    if-nez v4, :cond_19

    .line 516
    .line 517
    if-ne v5, v7, :cond_1a

    .line 518
    .line 519
    :cond_19
    new-instance v15, Lub0;

    .line 520
    .line 521
    const/16 v21, 0x0

    .line 522
    .line 523
    const/16 v22, 0xa

    .line 524
    .line 525
    const/16 v16, 0x1

    .line 526
    .line 527
    const-class v18, Llw;

    .line 528
    .line 529
    const-string v19, "setNotificationActionStop"

    .line 530
    .line 531
    const-string v20, "setNotificationActionStop(Z)V"

    .line 532
    .line 533
    move-object/from16 v17, v2

    .line 534
    .line 535
    invoke-direct/range {v15 .. v22}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 536
    .line 537
    .line 538
    invoke-virtual {v0, v15}, Lki2;->q0(Ljava/lang/Object;)V

    .line 539
    .line 540
    .line 541
    move-object v5, v15

    .line 542
    :cond_1a
    check-cast v5, Lwh2;

    .line 543
    .line 544
    move-object v15, v5

    .line 545
    check-cast v15, Lhh2;

    .line 546
    .line 547
    iget-object v2, v11, Lkb0;->b:Llw;

    .line 548
    .line 549
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 550
    .line 551
    .line 552
    move-result v4

    .line 553
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 554
    .line 555
    .line 556
    move-result-object v5

    .line 557
    if-nez v4, :cond_1b

    .line 558
    .line 559
    if-ne v5, v7, :cond_1c

    .line 560
    .line 561
    :cond_1b
    new-instance v16, Lub0;

    .line 562
    .line 563
    const/16 v22, 0x0

    .line 564
    .line 565
    const/16 v23, 0xb

    .line 566
    .line 567
    const/16 v17, 0x1

    .line 568
    .line 569
    const-class v19, Llw;

    .line 570
    .line 571
    const-string v20, "setNotificationActionStopTitle"

    .line 572
    .line 573
    const-string v21, "setNotificationActionStopTitle(Ljava/lang/String;)V"

    .line 574
    .line 575
    move-object/from16 v18, v2

    .line 576
    .line 577
    invoke-direct/range {v16 .. v23}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 578
    .line 579
    .line 580
    move-object/from16 v5, v16

    .line 581
    .line 582
    invoke-virtual {v0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 583
    .line 584
    .line 585
    :cond_1c
    check-cast v5, Lwh2;

    .line 586
    .line 587
    move-object/from16 v16, v5

    .line 588
    .line 589
    check-cast v16, Lhh2;

    .line 590
    .line 591
    iget-object v2, v11, Lkb0;->b:Llw;

    .line 592
    .line 593
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 594
    .line 595
    .line 596
    move-result v4

    .line 597
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 598
    .line 599
    .line 600
    move-result-object v5

    .line 601
    if-nez v4, :cond_1d

    .line 602
    .line 603
    if-ne v5, v7, :cond_1e

    .line 604
    .line 605
    :cond_1d
    new-instance v17, Lub0;

    .line 606
    .line 607
    const/16 v23, 0x0

    .line 608
    .line 609
    const/16 v24, 0x0

    .line 610
    .line 611
    const/16 v18, 0x1

    .line 612
    .line 613
    const-class v20, Llw;

    .line 614
    .line 615
    const-string v21, "setNotificationActionStopTarget"

    .line 616
    .line 617
    const-string v22, "setNotificationActionStopTarget(Lcom/box/app/data/NotificationButtonAction;)V"

    .line 618
    .line 619
    move-object/from16 v19, v2

    .line 620
    .line 621
    invoke-direct/range {v17 .. v24}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 622
    .line 623
    .line 624
    move-object/from16 v5, v17

    .line 625
    .line 626
    invoke-virtual {v0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 627
    .line 628
    .line 629
    :cond_1e
    check-cast v5, Lwh2;

    .line 630
    .line 631
    move-object/from16 v17, v5

    .line 632
    .line 633
    check-cast v17, Lhh2;

    .line 634
    .line 635
    iget-object v2, v11, Lkb0;->b:Llw;

    .line 636
    .line 637
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 638
    .line 639
    .line 640
    move-result v4

    .line 641
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 642
    .line 643
    .line 644
    move-result-object v5

    .line 645
    if-nez v4, :cond_1f

    .line 646
    .line 647
    if-ne v5, v7, :cond_20

    .line 648
    .line 649
    :cond_1f
    new-instance v18, Lub0;

    .line 650
    .line 651
    const/16 v24, 0x0

    .line 652
    .line 653
    const/16 v25, 0x1

    .line 654
    .line 655
    const/16 v19, 0x1

    .line 656
    .line 657
    const-class v21, Llw;

    .line 658
    .line 659
    const-string v22, "setNotificationActionRestart"

    .line 660
    .line 661
    const-string v23, "setNotificationActionRestart(Z)V"

    .line 662
    .line 663
    move-object/from16 v20, v2

    .line 664
    .line 665
    invoke-direct/range {v18 .. v25}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 666
    .line 667
    .line 668
    move-object/from16 v5, v18

    .line 669
    .line 670
    invoke-virtual {v0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 671
    .line 672
    .line 673
    :cond_20
    check-cast v5, Lwh2;

    .line 674
    .line 675
    move-object/from16 v18, v5

    .line 676
    .line 677
    check-cast v18, Lhh2;

    .line 678
    .line 679
    iget-object v2, v11, Lkb0;->b:Llw;

    .line 680
    .line 681
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 682
    .line 683
    .line 684
    move-result v4

    .line 685
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 686
    .line 687
    .line 688
    move-result-object v5

    .line 689
    if-nez v4, :cond_21

    .line 690
    .line 691
    if-ne v5, v7, :cond_22

    .line 692
    .line 693
    :cond_21
    new-instance v19, Lub0;

    .line 694
    .line 695
    const/16 v25, 0x0

    .line 696
    .line 697
    const/16 v26, 0x2

    .line 698
    .line 699
    const/16 v20, 0x1

    .line 700
    .line 701
    const-class v22, Llw;

    .line 702
    .line 703
    const-string v23, "setNotificationActionRestartTitle"

    .line 704
    .line 705
    const-string v24, "setNotificationActionRestartTitle(Ljava/lang/String;)V"

    .line 706
    .line 707
    move-object/from16 v21, v2

    .line 708
    .line 709
    invoke-direct/range {v19 .. v26}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 710
    .line 711
    .line 712
    move-object/from16 v5, v19

    .line 713
    .line 714
    invoke-virtual {v0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 715
    .line 716
    .line 717
    :cond_22
    check-cast v5, Lwh2;

    .line 718
    .line 719
    move-object/from16 v19, v5

    .line 720
    .line 721
    check-cast v19, Lhh2;

    .line 722
    .line 723
    iget-object v2, v11, Lkb0;->b:Llw;

    .line 724
    .line 725
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 726
    .line 727
    .line 728
    move-result v4

    .line 729
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 730
    .line 731
    .line 732
    move-result-object v5

    .line 733
    if-nez v4, :cond_23

    .line 734
    .line 735
    if-ne v5, v7, :cond_24

    .line 736
    .line 737
    :cond_23
    new-instance v20, Lub0;

    .line 738
    .line 739
    const/16 v26, 0x0

    .line 740
    .line 741
    const/16 v27, 0x3

    .line 742
    .line 743
    const/16 v21, 0x1

    .line 744
    .line 745
    const-class v23, Llw;

    .line 746
    .line 747
    const-string v24, "setNotificationActionRestartTarget"

    .line 748
    .line 749
    const-string v25, "setNotificationActionRestartTarget(Lcom/box/app/data/NotificationButtonAction;)V"

    .line 750
    .line 751
    move-object/from16 v22, v2

    .line 752
    .line 753
    invoke-direct/range {v20 .. v27}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 754
    .line 755
    .line 756
    move-object/from16 v5, v20

    .line 757
    .line 758
    invoke-virtual {v0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 759
    .line 760
    .line 761
    :cond_24
    check-cast v5, Lwh2;

    .line 762
    .line 763
    move-object/from16 v20, v5

    .line 764
    .line 765
    check-cast v20, Lhh2;

    .line 766
    .line 767
    iget-object v2, v11, Lkb0;->e:Lhj4;

    .line 768
    .line 769
    invoke-virtual {v0, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 770
    .line 771
    .line 772
    move-result v4

    .line 773
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 774
    .line 775
    .line 776
    move-result-object v5

    .line 777
    if-nez v4, :cond_25

    .line 778
    .line 779
    if-ne v5, v7, :cond_26

    .line 780
    .line 781
    :cond_25
    new-instance v21, Ltb0;

    .line 782
    .line 783
    const/16 v27, 0x0

    .line 784
    .line 785
    const/16 v28, 0xb

    .line 786
    .line 787
    const/16 v22, 0x0

    .line 788
    .line 789
    const-class v24, Lhj4;

    .line 790
    .line 791
    const-string v25, "pop"

    .line 792
    .line 793
    const-string v26, "pop()V"

    .line 794
    .line 795
    move-object/from16 v23, v2

    .line 796
    .line 797
    invoke-direct/range {v21 .. v28}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 798
    .line 799
    .line 800
    move-object/from16 v5, v21

    .line 801
    .line 802
    invoke-virtual {v0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 803
    .line 804
    .line 805
    :cond_26
    check-cast v5, Lwh2;

    .line 806
    .line 807
    move-object/from16 v21, v5

    .line 808
    .line 809
    check-cast v21, Lwg2;

    .line 810
    .line 811
    sget-object v22, Lit6;->c:Lk92;

    .line 812
    .line 813
    const/16 v24, 0x0

    .line 814
    .line 815
    move-object/from16 v23, v0

    .line 816
    .line 817
    move-object v7, v1

    .line 818
    move-object v11, v3

    .line 819
    invoke-static/range {v7 .. v24}, Lau4;->d(Lgw;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lhh2;Lwg2;Lha4;Lki2;I)V

    .line 820
    .line 821
    .line 822
    goto :goto_3

    .line 823
    :cond_27
    move-object/from16 v23, v0

    .line 824
    .line 825
    invoke-virtual/range {v23 .. v23}, Lki2;->b0()V

    .line 826
    .line 827
    .line 828
    :goto_3
    return-object v6

    .line 829
    :pswitch_4
    move-object/from16 v0, p1

    .line 830
    .line 831
    check-cast v0, Lki2;

    .line 832
    .line 833
    move-object/from16 v1, p2

    .line 834
    .line 835
    check-cast v1, Ljava/lang/Integer;

    .line 836
    .line 837
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 838
    .line 839
    .line 840
    move-result v1

    .line 841
    and-int/lit8 v2, v1, 0x3

    .line 842
    .line 843
    if-eq v2, v8, :cond_28

    .line 844
    .line 845
    move v10, v9

    .line 846
    :cond_28
    and-int/2addr v1, v9

    .line 847
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 848
    .line 849
    .line 850
    move-result v1

    .line 851
    if-eqz v1, :cond_2b

    .line 852
    .line 853
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 854
    .line 855
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 856
    .line 857
    .line 858
    move-result v1

    .line 859
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 860
    .line 861
    .line 862
    move-result-object v2

    .line 863
    if-nez v1, :cond_29

    .line 864
    .line 865
    if-ne v2, v7, :cond_2a

    .line 866
    .line 867
    :cond_29
    new-instance v12, Ltb0;

    .line 868
    .line 869
    const/16 v18, 0x0

    .line 870
    .line 871
    const/16 v19, 0x5

    .line 872
    .line 873
    const/4 v13, 0x0

    .line 874
    const-class v15, Lhj4;

    .line 875
    .line 876
    const-string v16, "pop"

    .line 877
    .line 878
    const-string v17, "pop()V"

    .line 879
    .line 880
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 881
    .line 882
    .line 883
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 884
    .line 885
    .line 886
    move-object v2, v12

    .line 887
    :cond_2a
    check-cast v2, Lwh2;

    .line 888
    .line 889
    check-cast v2, Lwg2;

    .line 890
    .line 891
    sget-object v1, Lit6;->c:Lk92;

    .line 892
    .line 893
    invoke-static {v2, v1, v0, v5}, Lo80;->C(Lwg2;Lha4;Lki2;I)V

    .line 894
    .line 895
    .line 896
    goto :goto_4

    .line 897
    :cond_2b
    invoke-virtual {v0}, Lki2;->b0()V

    .line 898
    .line 899
    .line 900
    :goto_4
    return-object v6

    .line 901
    :pswitch_5
    move-object/from16 v0, p1

    .line 902
    .line 903
    check-cast v0, Lki2;

    .line 904
    .line 905
    move-object/from16 v1, p2

    .line 906
    .line 907
    check-cast v1, Ljava/lang/Integer;

    .line 908
    .line 909
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 910
    .line 911
    .line 912
    move-result v1

    .line 913
    and-int/lit8 v2, v1, 0x3

    .line 914
    .line 915
    if-eq v2, v8, :cond_2c

    .line 916
    .line 917
    move v10, v9

    .line 918
    :cond_2c
    and-int/2addr v1, v9

    .line 919
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 920
    .line 921
    .line 922
    move-result v1

    .line 923
    if-eqz v1, :cond_33

    .line 924
    .line 925
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 926
    .line 927
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 928
    .line 929
    .line 930
    move-result v1

    .line 931
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 932
    .line 933
    .line 934
    move-result-object v2

    .line 935
    if-nez v1, :cond_2d

    .line 936
    .line 937
    if-ne v2, v7, :cond_2e

    .line 938
    .line 939
    :cond_2d
    new-instance v12, Lal7;

    .line 940
    .line 941
    const/16 v18, 0x0

    .line 942
    .line 943
    const/16 v19, 0x1

    .line 944
    .line 945
    const/4 v13, 0x0

    .line 946
    const-class v15, Lhj4;

    .line 947
    .line 948
    const-string v16, "pop"

    .line 949
    .line 950
    const-string v17, "pop()V"

    .line 951
    .line 952
    invoke-direct/range {v12 .. v19}, Lal7;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 953
    .line 954
    .line 955
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 956
    .line 957
    .line 958
    move-object v2, v12

    .line 959
    :cond_2e
    check-cast v2, Lwh2;

    .line 960
    .line 961
    check-cast v2, Lwg2;

    .line 962
    .line 963
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 964
    .line 965
    .line 966
    move-result v1

    .line 967
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 968
    .line 969
    .line 970
    move-result-object v3

    .line 971
    if-nez v1, :cond_2f

    .line 972
    .line 973
    if-ne v3, v7, :cond_30

    .line 974
    .line 975
    :cond_2f
    new-instance v3, Lmb0;

    .line 976
    .line 977
    const/16 v1, 0x14

    .line 978
    .line 979
    invoke-direct {v3, v11, v1}, Lmb0;-><init>(Lkb0;B)V

    .line 980
    .line 981
    .line 982
    invoke-virtual {v0, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 983
    .line 984
    .line 985
    :cond_30
    move-object v8, v3

    .line 986
    check-cast v8, Lwg2;

    .line 987
    .line 988
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 989
    .line 990
    .line 991
    move-result v1

    .line 992
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 993
    .line 994
    .line 995
    move-result-object v3

    .line 996
    if-nez v1, :cond_31

    .line 997
    .line 998
    if-ne v3, v7, :cond_32

    .line 999
    .line 1000
    :cond_31
    new-instance v3, Lmb0;

    .line 1001
    .line 1002
    const/16 v1, 0x15

    .line 1003
    .line 1004
    invoke-direct {v3, v11, v1}, Lmb0;-><init>(Lkb0;B)V

    .line 1005
    .line 1006
    .line 1007
    invoke-virtual {v0, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1008
    .line 1009
    .line 1010
    :cond_32
    move-object v9, v3

    .line 1011
    check-cast v9, Lwg2;

    .line 1012
    .line 1013
    sget-object v10, Lit6;->c:Lk92;

    .line 1014
    .line 1015
    const/16 v12, 0xc00

    .line 1016
    .line 1017
    move-object v11, v0

    .line 1018
    move-object v7, v2

    .line 1019
    invoke-static/range {v7 .. v12}, Ll80;->a(Lwg2;Lwg2;Lwg2;Lha4;Lki2;I)V

    .line 1020
    .line 1021
    .line 1022
    goto :goto_5

    .line 1023
    :cond_33
    move-object v11, v0

    .line 1024
    invoke-virtual {v11}, Lki2;->b0()V

    .line 1025
    .line 1026
    .line 1027
    :goto_5
    return-object v6

    .line 1028
    :pswitch_6
    move-object/from16 v0, p1

    .line 1029
    .line 1030
    check-cast v0, Lki2;

    .line 1031
    .line 1032
    move-object/from16 v1, p2

    .line 1033
    .line 1034
    check-cast v1, Ljava/lang/Integer;

    .line 1035
    .line 1036
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1037
    .line 1038
    .line 1039
    move-result v1

    .line 1040
    and-int/lit8 v2, v1, 0x3

    .line 1041
    .line 1042
    if-eq v2, v8, :cond_34

    .line 1043
    .line 1044
    move v10, v9

    .line 1045
    :cond_34
    and-int/2addr v1, v9

    .line 1046
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1047
    .line 1048
    .line 1049
    move-result v1

    .line 1050
    if-eqz v1, :cond_37

    .line 1051
    .line 1052
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1053
    .line 1054
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1055
    .line 1056
    .line 1057
    move-result v1

    .line 1058
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1059
    .line 1060
    .line 1061
    move-result-object v2

    .line 1062
    if-nez v1, :cond_35

    .line 1063
    .line 1064
    if-ne v2, v7, :cond_36

    .line 1065
    .line 1066
    :cond_35
    new-instance v12, Ltb0;

    .line 1067
    .line 1068
    const/16 v18, 0x0

    .line 1069
    .line 1070
    const/16 v19, 0xd

    .line 1071
    .line 1072
    const/4 v13, 0x0

    .line 1073
    const-class v15, Lhj4;

    .line 1074
    .line 1075
    const-string v16, "pop"

    .line 1076
    .line 1077
    const-string v17, "pop()V"

    .line 1078
    .line 1079
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1080
    .line 1081
    .line 1082
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1083
    .line 1084
    .line 1085
    move-object v2, v12

    .line 1086
    :cond_36
    check-cast v2, Lwh2;

    .line 1087
    .line 1088
    check-cast v2, Lwg2;

    .line 1089
    .line 1090
    iget-object v1, v11, Lkb0;->a:Lgw;

    .line 1091
    .line 1092
    iget-boolean v1, v1, Lgw;->K:Z

    .line 1093
    .line 1094
    sget-object v3, Lit6;->c:Lk92;

    .line 1095
    .line 1096
    invoke-static {v4, v2, v0, v3, v1}, Lkb3;->j(ILwg2;Lki2;Lha4;Z)V

    .line 1097
    .line 1098
    .line 1099
    goto :goto_6

    .line 1100
    :cond_37
    invoke-virtual {v0}, Lki2;->b0()V

    .line 1101
    .line 1102
    .line 1103
    :goto_6
    return-object v6

    .line 1104
    :pswitch_7
    move-object/from16 v13, p1

    .line 1105
    .line 1106
    check-cast v13, Lki2;

    .line 1107
    .line 1108
    move-object/from16 v0, p2

    .line 1109
    .line 1110
    check-cast v0, Ljava/lang/Integer;

    .line 1111
    .line 1112
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1113
    .line 1114
    .line 1115
    move-result v0

    .line 1116
    and-int/lit8 v1, v0, 0x3

    .line 1117
    .line 1118
    if-eq v1, v8, :cond_38

    .line 1119
    .line 1120
    move v10, v9

    .line 1121
    :cond_38
    and-int/2addr v0, v9

    .line 1122
    invoke-virtual {v13, v0, v10}, Lki2;->Y(IZ)Z

    .line 1123
    .line 1124
    .line 1125
    move-result v0

    .line 1126
    if-eqz v0, :cond_41

    .line 1127
    .line 1128
    iget-object v0, v11, Lkb0;->e:Lhj4;

    .line 1129
    .line 1130
    invoke-virtual {v13, v0}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1131
    .line 1132
    .line 1133
    move-result v1

    .line 1134
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v2

    .line 1138
    if-nez v1, :cond_39

    .line 1139
    .line 1140
    if-ne v2, v7, :cond_3a

    .line 1141
    .line 1142
    :cond_39
    new-instance v14, Ltb0;

    .line 1143
    .line 1144
    const/16 v20, 0x0

    .line 1145
    .line 1146
    const/16 v21, 0x14

    .line 1147
    .line 1148
    const/4 v15, 0x0

    .line 1149
    const-class v17, Lhj4;

    .line 1150
    .line 1151
    const-string v18, "pop"

    .line 1152
    .line 1153
    const-string v19, "pop()V"

    .line 1154
    .line 1155
    move-object/from16 v16, v0

    .line 1156
    .line 1157
    invoke-direct/range {v14 .. v21}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1158
    .line 1159
    .line 1160
    invoke-virtual {v13, v14}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1161
    .line 1162
    .line 1163
    move-object v2, v14

    .line 1164
    :cond_3a
    check-cast v2, Lwh2;

    .line 1165
    .line 1166
    check-cast v2, Lwg2;

    .line 1167
    .line 1168
    invoke-virtual {v13, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1169
    .line 1170
    .line 1171
    move-result v0

    .line 1172
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1173
    .line 1174
    .line 1175
    move-result-object v1

    .line 1176
    if-nez v0, :cond_3b

    .line 1177
    .line 1178
    if-ne v1, v7, :cond_3c

    .line 1179
    .line 1180
    :cond_3b
    new-instance v1, Lmb0;

    .line 1181
    .line 1182
    const/16 v0, 0x12

    .line 1183
    .line 1184
    invoke-direct {v1, v11, v0}, Lmb0;-><init>(Lkb0;B)V

    .line 1185
    .line 1186
    .line 1187
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1188
    .line 1189
    .line 1190
    :cond_3c
    move-object v8, v1

    .line 1191
    check-cast v8, Lwg2;

    .line 1192
    .line 1193
    iget-object v0, v11, Lkb0;->b:Llw;

    .line 1194
    .line 1195
    invoke-virtual {v13, v0}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1196
    .line 1197
    .line 1198
    move-result v1

    .line 1199
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1200
    .line 1201
    .line 1202
    move-result-object v3

    .line 1203
    if-nez v1, :cond_3d

    .line 1204
    .line 1205
    if-ne v3, v7, :cond_3e

    .line 1206
    .line 1207
    :cond_3d
    new-instance v14, Lub0;

    .line 1208
    .line 1209
    const/16 v20, 0x0

    .line 1210
    .line 1211
    const/16 v21, 0x19

    .line 1212
    .line 1213
    const/4 v15, 0x1

    .line 1214
    const-class v17, Llw;

    .line 1215
    .line 1216
    const-string v18, "setSpeedTestSource"

    .line 1217
    .line 1218
    const-string v19, "setSpeedTestSource(Lcom/box/app/data/SpeedTestSource;)V"

    .line 1219
    .line 1220
    move-object/from16 v16, v0

    .line 1221
    .line 1222
    invoke-direct/range {v14 .. v21}, Lub0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1223
    .line 1224
    .line 1225
    invoke-virtual {v13, v14}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1226
    .line 1227
    .line 1228
    move-object v3, v14

    .line 1229
    :cond_3e
    check-cast v3, Lwh2;

    .line 1230
    .line 1231
    move-object v9, v3

    .line 1232
    check-cast v9, Lhh2;

    .line 1233
    .line 1234
    iget-object v0, v11, Lkb0;->a:Lgw;

    .line 1235
    .line 1236
    iget-boolean v10, v0, Lgw;->P:Z

    .line 1237
    .line 1238
    invoke-virtual {v13, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1239
    .line 1240
    .line 1241
    move-result v0

    .line 1242
    invoke-virtual {v13}, Lki2;->T()Ljava/lang/Object;

    .line 1243
    .line 1244
    .line 1245
    move-result-object v1

    .line 1246
    if-nez v0, :cond_3f

    .line 1247
    .line 1248
    if-ne v1, v7, :cond_40

    .line 1249
    .line 1250
    :cond_3f
    new-instance v1, Lmb0;

    .line 1251
    .line 1252
    const/16 v0, 0x13

    .line 1253
    .line 1254
    invoke-direct {v1, v11, v0}, Lmb0;-><init>(Lkb0;B)V

    .line 1255
    .line 1256
    .line 1257
    invoke-virtual {v13, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1258
    .line 1259
    .line 1260
    :cond_40
    move-object v11, v1

    .line 1261
    check-cast v11, Lwg2;

    .line 1262
    .line 1263
    sget-object v12, Lit6;->c:Lk92;

    .line 1264
    .line 1265
    const/high16 v14, 0x30000

    .line 1266
    .line 1267
    move-object v7, v2

    .line 1268
    invoke-static/range {v7 .. v14}, Lha1;->o(Lwg2;Lwg2;Lhh2;ZLwg2;Lha4;Lki2;I)V

    .line 1269
    .line 1270
    .line 1271
    goto :goto_7

    .line 1272
    :cond_41
    invoke-virtual {v13}, Lki2;->b0()V

    .line 1273
    .line 1274
    .line 1275
    :goto_7
    return-object v6

    .line 1276
    :pswitch_8
    move-object/from16 v0, p1

    .line 1277
    .line 1278
    check-cast v0, Lki2;

    .line 1279
    .line 1280
    move-object/from16 v1, p2

    .line 1281
    .line 1282
    check-cast v1, Ljava/lang/Integer;

    .line 1283
    .line 1284
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1285
    .line 1286
    .line 1287
    move-result v1

    .line 1288
    and-int/lit8 v2, v1, 0x3

    .line 1289
    .line 1290
    if-eq v2, v8, :cond_42

    .line 1291
    .line 1292
    move v10, v9

    .line 1293
    :cond_42
    and-int/2addr v1, v9

    .line 1294
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1295
    .line 1296
    .line 1297
    move-result v1

    .line 1298
    if-eqz v1, :cond_45

    .line 1299
    .line 1300
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1301
    .line 1302
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1303
    .line 1304
    .line 1305
    move-result v1

    .line 1306
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1307
    .line 1308
    .line 1309
    move-result-object v2

    .line 1310
    if-nez v1, :cond_43

    .line 1311
    .line 1312
    if-ne v2, v7, :cond_44

    .line 1313
    .line 1314
    :cond_43
    new-instance v12, Ltb0;

    .line 1315
    .line 1316
    const/16 v18, 0x0

    .line 1317
    .line 1318
    const/16 v19, 0x9

    .line 1319
    .line 1320
    const/4 v13, 0x0

    .line 1321
    const-class v15, Lhj4;

    .line 1322
    .line 1323
    const-string v16, "pop"

    .line 1324
    .line 1325
    const-string v17, "pop()V"

    .line 1326
    .line 1327
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1328
    .line 1329
    .line 1330
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1331
    .line 1332
    .line 1333
    move-object v2, v12

    .line 1334
    :cond_44
    check-cast v2, Lwh2;

    .line 1335
    .line 1336
    check-cast v2, Lwg2;

    .line 1337
    .line 1338
    sget-object v1, Lit6;->c:Lk92;

    .line 1339
    .line 1340
    invoke-static {v2, v1, v0, v5}, Ll80;->o(Lwg2;Lha4;Lki2;I)V

    .line 1341
    .line 1342
    .line 1343
    goto :goto_8

    .line 1344
    :cond_45
    invoke-virtual {v0}, Lki2;->b0()V

    .line 1345
    .line 1346
    .line 1347
    :goto_8
    return-object v6

    .line 1348
    :pswitch_9
    move-object/from16 v12, p1

    .line 1349
    .line 1350
    check-cast v12, Lki2;

    .line 1351
    .line 1352
    move-object/from16 v0, p2

    .line 1353
    .line 1354
    check-cast v0, Ljava/lang/Integer;

    .line 1355
    .line 1356
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1357
    .line 1358
    .line 1359
    move-result v0

    .line 1360
    and-int/lit8 v1, v0, 0x3

    .line 1361
    .line 1362
    if-eq v1, v8, :cond_46

    .line 1363
    .line 1364
    move v10, v9

    .line 1365
    :cond_46
    and-int/2addr v0, v9

    .line 1366
    invoke-virtual {v12, v0, v10}, Lki2;->Y(IZ)Z

    .line 1367
    .line 1368
    .line 1369
    move-result v0

    .line 1370
    if-eqz v0, :cond_4f

    .line 1371
    .line 1372
    iget-object v15, v11, Lkb0;->e:Lhj4;

    .line 1373
    .line 1374
    invoke-virtual {v12, v15}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1375
    .line 1376
    .line 1377
    move-result v0

    .line 1378
    invoke-virtual {v12}, Lki2;->T()Ljava/lang/Object;

    .line 1379
    .line 1380
    .line 1381
    move-result-object v1

    .line 1382
    if-nez v0, :cond_47

    .line 1383
    .line 1384
    if-ne v1, v7, :cond_48

    .line 1385
    .line 1386
    :cond_47
    new-instance v13, Ltb0;

    .line 1387
    .line 1388
    const/16 v19, 0x0

    .line 1389
    .line 1390
    const/16 v20, 0x1

    .line 1391
    .line 1392
    const/4 v14, 0x0

    .line 1393
    const-class v16, Lhj4;

    .line 1394
    .line 1395
    const-string v17, "pop"

    .line 1396
    .line 1397
    const-string v18, "pop()V"

    .line 1398
    .line 1399
    invoke-direct/range {v13 .. v20}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1400
    .line 1401
    .line 1402
    invoke-virtual {v12, v13}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1403
    .line 1404
    .line 1405
    move-object v1, v13

    .line 1406
    :cond_48
    check-cast v1, Lwh2;

    .line 1407
    .line 1408
    check-cast v1, Lwg2;

    .line 1409
    .line 1410
    invoke-virtual {v12, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1411
    .line 1412
    .line 1413
    move-result v0

    .line 1414
    invoke-virtual {v12}, Lki2;->T()Ljava/lang/Object;

    .line 1415
    .line 1416
    .line 1417
    move-result-object v4

    .line 1418
    if-nez v0, :cond_49

    .line 1419
    .line 1420
    if-ne v4, v7, :cond_4a

    .line 1421
    .line 1422
    :cond_49
    new-instance v4, Lob0;

    .line 1423
    .line 1424
    invoke-direct {v4, v11, v3}, Lob0;-><init>(Lkb0;B)V

    .line 1425
    .line 1426
    .line 1427
    invoke-virtual {v12, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1428
    .line 1429
    .line 1430
    :cond_4a
    move-object v8, v4

    .line 1431
    check-cast v8, Lhh2;

    .line 1432
    .line 1433
    invoke-virtual {v12, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1434
    .line 1435
    .line 1436
    move-result v0

    .line 1437
    invoke-virtual {v12}, Lki2;->T()Ljava/lang/Object;

    .line 1438
    .line 1439
    .line 1440
    move-result-object v3

    .line 1441
    if-nez v0, :cond_4b

    .line 1442
    .line 1443
    if-ne v3, v7, :cond_4c

    .line 1444
    .line 1445
    :cond_4b
    new-instance v3, Lmb0;

    .line 1446
    .line 1447
    const/16 v0, 0x11

    .line 1448
    .line 1449
    invoke-direct {v3, v11, v0}, Lmb0;-><init>(Lkb0;B)V

    .line 1450
    .line 1451
    .line 1452
    invoke-virtual {v12, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1453
    .line 1454
    .line 1455
    :cond_4c
    move-object v9, v3

    .line 1456
    check-cast v9, Lwg2;

    .line 1457
    .line 1458
    invoke-virtual {v12, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1459
    .line 1460
    .line 1461
    move-result v0

    .line 1462
    invoke-virtual {v12}, Lki2;->T()Ljava/lang/Object;

    .line 1463
    .line 1464
    .line 1465
    move-result-object v3

    .line 1466
    if-nez v0, :cond_4d

    .line 1467
    .line 1468
    if-ne v3, v7, :cond_4e

    .line 1469
    .line 1470
    :cond_4d
    new-instance v3, Lob0;

    .line 1471
    .line 1472
    invoke-direct {v3, v11, v2}, Lob0;-><init>(Lkb0;B)V

    .line 1473
    .line 1474
    .line 1475
    invoke-virtual {v12, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1476
    .line 1477
    .line 1478
    :cond_4e
    move-object v10, v3

    .line 1479
    check-cast v10, Lhh2;

    .line 1480
    .line 1481
    sget-object v11, Lit6;->c:Lk92;

    .line 1482
    .line 1483
    const/16 v13, 0x6000

    .line 1484
    .line 1485
    move-object v7, v1

    .line 1486
    invoke-static/range {v7 .. v13}, Lkb3;->h(Lwg2;Lhh2;Lwg2;Lhh2;Lha4;Lki2;I)V

    .line 1487
    .line 1488
    .line 1489
    goto :goto_9

    .line 1490
    :cond_4f
    invoke-virtual {v12}, Lki2;->b0()V

    .line 1491
    .line 1492
    .line 1493
    :goto_9
    return-object v6

    .line 1494
    :pswitch_a
    move-object/from16 v0, p1

    .line 1495
    .line 1496
    check-cast v0, Lki2;

    .line 1497
    .line 1498
    move-object/from16 v1, p2

    .line 1499
    .line 1500
    check-cast v1, Ljava/lang/Integer;

    .line 1501
    .line 1502
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1503
    .line 1504
    .line 1505
    move-result v1

    .line 1506
    and-int/lit8 v2, v1, 0x3

    .line 1507
    .line 1508
    if-eq v2, v8, :cond_50

    .line 1509
    .line 1510
    move v10, v9

    .line 1511
    :cond_50
    and-int/2addr v1, v9

    .line 1512
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1513
    .line 1514
    .line 1515
    move-result v1

    .line 1516
    if-eqz v1, :cond_53

    .line 1517
    .line 1518
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1519
    .line 1520
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1521
    .line 1522
    .line 1523
    move-result v1

    .line 1524
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1525
    .line 1526
    .line 1527
    move-result-object v2

    .line 1528
    if-nez v1, :cond_51

    .line 1529
    .line 1530
    if-ne v2, v7, :cond_52

    .line 1531
    .line 1532
    :cond_51
    new-instance v12, Ltb0;

    .line 1533
    .line 1534
    const/16 v18, 0x0

    .line 1535
    .line 1536
    const/16 v19, 0x12

    .line 1537
    .line 1538
    const/4 v13, 0x0

    .line 1539
    const-class v15, Lhj4;

    .line 1540
    .line 1541
    const-string v16, "pop"

    .line 1542
    .line 1543
    const-string v17, "pop()V"

    .line 1544
    .line 1545
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1546
    .line 1547
    .line 1548
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1549
    .line 1550
    .line 1551
    move-object v2, v12

    .line 1552
    :cond_52
    check-cast v2, Lwh2;

    .line 1553
    .line 1554
    check-cast v2, Lwg2;

    .line 1555
    .line 1556
    sget-object v1, Lit6;->c:Lk92;

    .line 1557
    .line 1558
    invoke-static {v2, v1, v0, v5}, Lha1;->i(Lwg2;Lha4;Lki2;I)V

    .line 1559
    .line 1560
    .line 1561
    goto :goto_a

    .line 1562
    :cond_53
    invoke-virtual {v0}, Lki2;->b0()V

    .line 1563
    .line 1564
    .line 1565
    :goto_a
    return-object v6

    .line 1566
    :pswitch_b
    move-object/from16 v0, p1

    .line 1567
    .line 1568
    check-cast v0, Lki2;

    .line 1569
    .line 1570
    move-object/from16 v1, p2

    .line 1571
    .line 1572
    check-cast v1, Ljava/lang/Integer;

    .line 1573
    .line 1574
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1575
    .line 1576
    .line 1577
    move-result v1

    .line 1578
    and-int/lit8 v2, v1, 0x3

    .line 1579
    .line 1580
    if-eq v2, v8, :cond_54

    .line 1581
    .line 1582
    move v10, v9

    .line 1583
    :cond_54
    and-int/2addr v1, v9

    .line 1584
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1585
    .line 1586
    .line 1587
    move-result v1

    .line 1588
    if-eqz v1, :cond_57

    .line 1589
    .line 1590
    iget-object v1, v11, Lkb0;->a:Lgw;

    .line 1591
    .line 1592
    iget-object v8, v11, Lkb0;->d:Lqh7;

    .line 1593
    .line 1594
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1595
    .line 1596
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1597
    .line 1598
    .line 1599
    move-result v2

    .line 1600
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1601
    .line 1602
    .line 1603
    move-result-object v3

    .line 1604
    if-nez v2, :cond_55

    .line 1605
    .line 1606
    if-ne v3, v7, :cond_56

    .line 1607
    .line 1608
    :cond_55
    new-instance v12, Lwa;

    .line 1609
    .line 1610
    const/16 v18, 0x0

    .line 1611
    .line 1612
    const/16 v19, 0x1b

    .line 1613
    .line 1614
    const/4 v13, 0x0

    .line 1615
    const-class v15, Lhj4;

    .line 1616
    .line 1617
    const-string v16, "pop"

    .line 1618
    .line 1619
    const-string v17, "pop()V"

    .line 1620
    .line 1621
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1622
    .line 1623
    .line 1624
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1625
    .line 1626
    .line 1627
    move-object v3, v12

    .line 1628
    :cond_56
    check-cast v3, Lwh2;

    .line 1629
    .line 1630
    move-object v9, v3

    .line 1631
    check-cast v9, Lwg2;

    .line 1632
    .line 1633
    sget-object v10, Lit6;->c:Lk92;

    .line 1634
    .line 1635
    const/16 v12, 0xc00

    .line 1636
    .line 1637
    move-object v11, v0

    .line 1638
    move-object v7, v1

    .line 1639
    invoke-static/range {v7 .. v12}, Lgi7;->e(Lgw;Lqh7;Lwg2;Lha4;Lki2;I)V

    .line 1640
    .line 1641
    .line 1642
    goto :goto_b

    .line 1643
    :cond_57
    move-object v11, v0

    .line 1644
    invoke-virtual {v11}, Lki2;->b0()V

    .line 1645
    .line 1646
    .line 1647
    :goto_b
    return-object v6

    .line 1648
    :pswitch_c
    move-object/from16 v0, p1

    .line 1649
    .line 1650
    check-cast v0, Lki2;

    .line 1651
    .line 1652
    move-object/from16 v1, p2

    .line 1653
    .line 1654
    check-cast v1, Ljava/lang/Integer;

    .line 1655
    .line 1656
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1657
    .line 1658
    .line 1659
    move-result v1

    .line 1660
    and-int/lit8 v2, v1, 0x3

    .line 1661
    .line 1662
    if-eq v2, v8, :cond_58

    .line 1663
    .line 1664
    move v10, v9

    .line 1665
    :cond_58
    and-int/2addr v1, v9

    .line 1666
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1667
    .line 1668
    .line 1669
    move-result v1

    .line 1670
    if-eqz v1, :cond_5b

    .line 1671
    .line 1672
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1673
    .line 1674
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1675
    .line 1676
    .line 1677
    move-result v1

    .line 1678
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1679
    .line 1680
    .line 1681
    move-result-object v2

    .line 1682
    if-nez v1, :cond_59

    .line 1683
    .line 1684
    if-ne v2, v7, :cond_5a

    .line 1685
    .line 1686
    :cond_59
    new-instance v12, Ltb0;

    .line 1687
    .line 1688
    const/16 v18, 0x0

    .line 1689
    .line 1690
    const/16 v19, 0x10

    .line 1691
    .line 1692
    const/4 v13, 0x0

    .line 1693
    const-class v15, Lhj4;

    .line 1694
    .line 1695
    const-string v16, "pop"

    .line 1696
    .line 1697
    const-string v17, "pop()V"

    .line 1698
    .line 1699
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1700
    .line 1701
    .line 1702
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1703
    .line 1704
    .line 1705
    move-object v2, v12

    .line 1706
    :cond_5a
    check-cast v2, Lwh2;

    .line 1707
    .line 1708
    check-cast v2, Lwg2;

    .line 1709
    .line 1710
    iget-object v1, v11, Lkb0;->a:Lgw;

    .line 1711
    .line 1712
    iget-boolean v1, v1, Lgw;->K:Z

    .line 1713
    .line 1714
    sget-object v3, Lit6;->c:Lk92;

    .line 1715
    .line 1716
    invoke-static {v4, v2, v0, v3, v1}, Lxl6;->a(ILwg2;Lki2;Lha4;Z)V

    .line 1717
    .line 1718
    .line 1719
    goto :goto_c

    .line 1720
    :cond_5b
    invoke-virtual {v0}, Lki2;->b0()V

    .line 1721
    .line 1722
    .line 1723
    :goto_c
    return-object v6

    .line 1724
    :pswitch_d
    move-object/from16 v0, p1

    .line 1725
    .line 1726
    check-cast v0, Lki2;

    .line 1727
    .line 1728
    move-object/from16 v1, p2

    .line 1729
    .line 1730
    check-cast v1, Ljava/lang/Integer;

    .line 1731
    .line 1732
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1733
    .line 1734
    .line 1735
    move-result v1

    .line 1736
    and-int/lit8 v2, v1, 0x3

    .line 1737
    .line 1738
    if-eq v2, v8, :cond_5c

    .line 1739
    .line 1740
    move v10, v9

    .line 1741
    :cond_5c
    and-int/2addr v1, v9

    .line 1742
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1743
    .line 1744
    .line 1745
    move-result v1

    .line 1746
    if-eqz v1, :cond_5f

    .line 1747
    .line 1748
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1749
    .line 1750
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1751
    .line 1752
    .line 1753
    move-result v1

    .line 1754
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1755
    .line 1756
    .line 1757
    move-result-object v2

    .line 1758
    if-nez v1, :cond_5d

    .line 1759
    .line 1760
    if-ne v2, v7, :cond_5e

    .line 1761
    .line 1762
    :cond_5d
    new-instance v12, Ltb0;

    .line 1763
    .line 1764
    const/16 v18, 0x0

    .line 1765
    .line 1766
    const/16 v19, 0x7

    .line 1767
    .line 1768
    const/4 v13, 0x0

    .line 1769
    const-class v15, Lhj4;

    .line 1770
    .line 1771
    const-string v16, "pop"

    .line 1772
    .line 1773
    const-string v17, "pop()V"

    .line 1774
    .line 1775
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1776
    .line 1777
    .line 1778
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1779
    .line 1780
    .line 1781
    move-object v2, v12

    .line 1782
    :cond_5e
    check-cast v2, Lwh2;

    .line 1783
    .line 1784
    check-cast v2, Lwg2;

    .line 1785
    .line 1786
    sget-object v1, Lit6;->c:Lk92;

    .line 1787
    .line 1788
    invoke-static {v2, v1, v0, v5}, Lo80;->Q(Lwg2;Lha4;Lki2;I)V

    .line 1789
    .line 1790
    .line 1791
    goto :goto_d

    .line 1792
    :cond_5f
    invoke-virtual {v0}, Lki2;->b0()V

    .line 1793
    .line 1794
    .line 1795
    :goto_d
    return-object v6

    .line 1796
    :pswitch_e
    move-object/from16 v0, p1

    .line 1797
    .line 1798
    check-cast v0, Lki2;

    .line 1799
    .line 1800
    move-object/from16 v1, p2

    .line 1801
    .line 1802
    check-cast v1, Ljava/lang/Integer;

    .line 1803
    .line 1804
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1805
    .line 1806
    .line 1807
    move-result v1

    .line 1808
    and-int/lit8 v2, v1, 0x3

    .line 1809
    .line 1810
    if-eq v2, v8, :cond_60

    .line 1811
    .line 1812
    move v10, v9

    .line 1813
    :cond_60
    and-int/2addr v1, v9

    .line 1814
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1815
    .line 1816
    .line 1817
    move-result v1

    .line 1818
    if-eqz v1, :cond_63

    .line 1819
    .line 1820
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1821
    .line 1822
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1823
    .line 1824
    .line 1825
    move-result v1

    .line 1826
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1827
    .line 1828
    .line 1829
    move-result-object v2

    .line 1830
    if-nez v1, :cond_61

    .line 1831
    .line 1832
    if-ne v2, v7, :cond_62

    .line 1833
    .line 1834
    :cond_61
    new-instance v12, Ltb0;

    .line 1835
    .line 1836
    const/16 v18, 0x0

    .line 1837
    .line 1838
    const/16 v19, 0x18

    .line 1839
    .line 1840
    const/4 v13, 0x0

    .line 1841
    const-class v15, Lhj4;

    .line 1842
    .line 1843
    const-string v16, "pop"

    .line 1844
    .line 1845
    const-string v17, "pop()V"

    .line 1846
    .line 1847
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1848
    .line 1849
    .line 1850
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1851
    .line 1852
    .line 1853
    move-object v2, v12

    .line 1854
    :cond_62
    check-cast v2, Lwh2;

    .line 1855
    .line 1856
    check-cast v2, Lwg2;

    .line 1857
    .line 1858
    sget-object v1, Lit6;->c:Lk92;

    .line 1859
    .line 1860
    invoke-static {v2, v1, v0, v5}, Lkb;->i(Lwg2;Lha4;Lki2;I)V

    .line 1861
    .line 1862
    .line 1863
    goto :goto_e

    .line 1864
    :cond_63
    invoke-virtual {v0}, Lki2;->b0()V

    .line 1865
    .line 1866
    .line 1867
    :goto_e
    return-object v6

    .line 1868
    :pswitch_f
    move-object/from16 v0, p1

    .line 1869
    .line 1870
    check-cast v0, Lki2;

    .line 1871
    .line 1872
    move-object/from16 v1, p2

    .line 1873
    .line 1874
    check-cast v1, Ljava/lang/Integer;

    .line 1875
    .line 1876
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1877
    .line 1878
    .line 1879
    move-result v1

    .line 1880
    and-int/lit8 v2, v1, 0x3

    .line 1881
    .line 1882
    if-eq v2, v8, :cond_64

    .line 1883
    .line 1884
    move v10, v9

    .line 1885
    :cond_64
    and-int/2addr v1, v9

    .line 1886
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1887
    .line 1888
    .line 1889
    move-result v1

    .line 1890
    if-eqz v1, :cond_67

    .line 1891
    .line 1892
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1893
    .line 1894
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1895
    .line 1896
    .line 1897
    move-result v1

    .line 1898
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1899
    .line 1900
    .line 1901
    move-result-object v2

    .line 1902
    if-nez v1, :cond_65

    .line 1903
    .line 1904
    if-ne v2, v7, :cond_66

    .line 1905
    .line 1906
    :cond_65
    new-instance v12, Ltb0;

    .line 1907
    .line 1908
    const/16 v18, 0x0

    .line 1909
    .line 1910
    const/16 v19, 0x16

    .line 1911
    .line 1912
    const/4 v13, 0x0

    .line 1913
    const-class v15, Lhj4;

    .line 1914
    .line 1915
    const-string v16, "pop"

    .line 1916
    .line 1917
    const-string v17, "pop()V"

    .line 1918
    .line 1919
    invoke-direct/range {v12 .. v19}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1920
    .line 1921
    .line 1922
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1923
    .line 1924
    .line 1925
    move-object v2, v12

    .line 1926
    :cond_66
    check-cast v2, Lwh2;

    .line 1927
    .line 1928
    check-cast v2, Lwg2;

    .line 1929
    .line 1930
    sget-object v1, Lit6;->c:Lk92;

    .line 1931
    .line 1932
    invoke-static {v2, v1, v0, v5}, Lix;->w(Lwg2;Lha4;Lki2;I)V

    .line 1933
    .line 1934
    .line 1935
    goto :goto_f

    .line 1936
    :cond_67
    invoke-virtual {v0}, Lki2;->b0()V

    .line 1937
    .line 1938
    .line 1939
    :goto_f
    return-object v6

    .line 1940
    :pswitch_10
    move-object/from16 v0, p1

    .line 1941
    .line 1942
    check-cast v0, Lki2;

    .line 1943
    .line 1944
    move-object/from16 v1, p2

    .line 1945
    .line 1946
    check-cast v1, Ljava/lang/Integer;

    .line 1947
    .line 1948
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1949
    .line 1950
    .line 1951
    move-result v1

    .line 1952
    and-int/lit8 v2, v1, 0x3

    .line 1953
    .line 1954
    if-eq v2, v8, :cond_68

    .line 1955
    .line 1956
    move v10, v9

    .line 1957
    :cond_68
    and-int/2addr v1, v9

    .line 1958
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 1959
    .line 1960
    .line 1961
    move-result v1

    .line 1962
    if-eqz v1, :cond_6d

    .line 1963
    .line 1964
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 1965
    .line 1966
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 1967
    .line 1968
    .line 1969
    move-result v1

    .line 1970
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 1971
    .line 1972
    .line 1973
    move-result-object v2

    .line 1974
    if-nez v1, :cond_69

    .line 1975
    .line 1976
    if-ne v2, v7, :cond_6a

    .line 1977
    .line 1978
    :cond_69
    new-instance v12, Lwa;

    .line 1979
    .line 1980
    const/16 v18, 0x0

    .line 1981
    .line 1982
    const/16 v19, 0x19

    .line 1983
    .line 1984
    const/4 v13, 0x0

    .line 1985
    const-class v15, Lhj4;

    .line 1986
    .line 1987
    const-string v16, "pop"

    .line 1988
    .line 1989
    const-string v17, "pop()V"

    .line 1990
    .line 1991
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1992
    .line 1993
    .line 1994
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 1995
    .line 1996
    .line 1997
    move-object v2, v12

    .line 1998
    :cond_6a
    check-cast v2, Lwh2;

    .line 1999
    .line 2000
    check-cast v2, Lwg2;

    .line 2001
    .line 2002
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2003
    .line 2004
    .line 2005
    move-result v1

    .line 2006
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2007
    .line 2008
    .line 2009
    move-result-object v3

    .line 2010
    if-nez v1, :cond_6b

    .line 2011
    .line 2012
    if-ne v3, v7, :cond_6c

    .line 2013
    .line 2014
    :cond_6b
    new-instance v3, Lob0;

    .line 2015
    .line 2016
    const/4 v1, 0x3

    .line 2017
    invoke-direct {v3, v11, v1}, Lob0;-><init>(Lkb0;B)V

    .line 2018
    .line 2019
    .line 2020
    invoke-virtual {v0, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2021
    .line 2022
    .line 2023
    :cond_6c
    check-cast v3, Lhh2;

    .line 2024
    .line 2025
    sget-object v1, Lit6;->c:Lk92;

    .line 2026
    .line 2027
    invoke-static {v2, v3, v1, v0, v4}, Lnx3;->f(Lwg2;Lhh2;Lha4;Lki2;I)V

    .line 2028
    .line 2029
    .line 2030
    goto :goto_10

    .line 2031
    :cond_6d
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2032
    .line 2033
    .line 2034
    :goto_10
    return-object v6

    .line 2035
    :pswitch_11
    move-object/from16 v0, p1

    .line 2036
    .line 2037
    check-cast v0, Lki2;

    .line 2038
    .line 2039
    move-object/from16 v1, p2

    .line 2040
    .line 2041
    check-cast v1, Ljava/lang/Integer;

    .line 2042
    .line 2043
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2044
    .line 2045
    .line 2046
    move-result v1

    .line 2047
    and-int/lit8 v2, v1, 0x3

    .line 2048
    .line 2049
    if-eq v2, v8, :cond_6e

    .line 2050
    .line 2051
    move v10, v9

    .line 2052
    :cond_6e
    and-int/2addr v1, v9

    .line 2053
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 2054
    .line 2055
    .line 2056
    move-result v1

    .line 2057
    if-eqz v1, :cond_71

    .line 2058
    .line 2059
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 2060
    .line 2061
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2062
    .line 2063
    .line 2064
    move-result v1

    .line 2065
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2066
    .line 2067
    .line 2068
    move-result-object v2

    .line 2069
    if-nez v1, :cond_6f

    .line 2070
    .line 2071
    if-ne v2, v7, :cond_70

    .line 2072
    .line 2073
    :cond_6f
    new-instance v12, Lwa;

    .line 2074
    .line 2075
    const/16 v18, 0x0

    .line 2076
    .line 2077
    const/16 v19, 0x11

    .line 2078
    .line 2079
    const/4 v13, 0x0

    .line 2080
    const-class v15, Lhj4;

    .line 2081
    .line 2082
    const-string v16, "pop"

    .line 2083
    .line 2084
    const-string v17, "pop()V"

    .line 2085
    .line 2086
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 2087
    .line 2088
    .line 2089
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2090
    .line 2091
    .line 2092
    move-object v2, v12

    .line 2093
    :cond_70
    check-cast v2, Lwh2;

    .line 2094
    .line 2095
    check-cast v2, Lwg2;

    .line 2096
    .line 2097
    sget-object v1, Lit6;->c:Lk92;

    .line 2098
    .line 2099
    invoke-static {v2, v1, v0, v5}, Lnl1;->E(Lwg2;Lha4;Lki2;I)V

    .line 2100
    .line 2101
    .line 2102
    goto :goto_11

    .line 2103
    :cond_71
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2104
    .line 2105
    .line 2106
    :goto_11
    return-object v6

    .line 2107
    :pswitch_12
    move-object/from16 v0, p1

    .line 2108
    .line 2109
    check-cast v0, Lki2;

    .line 2110
    .line 2111
    move-object/from16 v1, p2

    .line 2112
    .line 2113
    check-cast v1, Ljava/lang/Integer;

    .line 2114
    .line 2115
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2116
    .line 2117
    .line 2118
    move-result v1

    .line 2119
    and-int/lit8 v2, v1, 0x3

    .line 2120
    .line 2121
    if-eq v2, v8, :cond_72

    .line 2122
    .line 2123
    move v10, v9

    .line 2124
    :cond_72
    and-int/2addr v1, v9

    .line 2125
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 2126
    .line 2127
    .line 2128
    move-result v1

    .line 2129
    if-eqz v1, :cond_75

    .line 2130
    .line 2131
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 2132
    .line 2133
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2134
    .line 2135
    .line 2136
    move-result v1

    .line 2137
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2138
    .line 2139
    .line 2140
    move-result-object v2

    .line 2141
    if-nez v1, :cond_73

    .line 2142
    .line 2143
    if-ne v2, v7, :cond_74

    .line 2144
    .line 2145
    :cond_73
    new-instance v12, Lwa;

    .line 2146
    .line 2147
    const/16 v18, 0x0

    .line 2148
    .line 2149
    const/16 v19, 0x17

    .line 2150
    .line 2151
    const/4 v13, 0x0

    .line 2152
    const-class v15, Lhj4;

    .line 2153
    .line 2154
    const-string v16, "pop"

    .line 2155
    .line 2156
    const-string v17, "pop()V"

    .line 2157
    .line 2158
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 2159
    .line 2160
    .line 2161
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2162
    .line 2163
    .line 2164
    move-object v2, v12

    .line 2165
    :cond_74
    check-cast v2, Lwh2;

    .line 2166
    .line 2167
    check-cast v2, Lwg2;

    .line 2168
    .line 2169
    sget-object v1, Lit6;->c:Lk92;

    .line 2170
    .line 2171
    invoke-static {v2, v1, v0, v5}, Lw04;->e(Lwg2;Lha4;Lki2;I)V

    .line 2172
    .line 2173
    .line 2174
    goto :goto_12

    .line 2175
    :cond_75
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2176
    .line 2177
    .line 2178
    :goto_12
    return-object v6

    .line 2179
    :pswitch_13
    move-object/from16 v0, p1

    .line 2180
    .line 2181
    check-cast v0, Lki2;

    .line 2182
    .line 2183
    move-object/from16 v1, p2

    .line 2184
    .line 2185
    check-cast v1, Ljava/lang/Integer;

    .line 2186
    .line 2187
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2188
    .line 2189
    .line 2190
    move-result v1

    .line 2191
    and-int/lit8 v2, v1, 0x3

    .line 2192
    .line 2193
    if-eq v2, v8, :cond_76

    .line 2194
    .line 2195
    move v10, v9

    .line 2196
    :cond_76
    and-int/2addr v1, v9

    .line 2197
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 2198
    .line 2199
    .line 2200
    move-result v1

    .line 2201
    if-eqz v1, :cond_79

    .line 2202
    .line 2203
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 2204
    .line 2205
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2206
    .line 2207
    .line 2208
    move-result v1

    .line 2209
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2210
    .line 2211
    .line 2212
    move-result-object v2

    .line 2213
    if-nez v1, :cond_77

    .line 2214
    .line 2215
    if-ne v2, v7, :cond_78

    .line 2216
    .line 2217
    :cond_77
    new-instance v12, Lwa;

    .line 2218
    .line 2219
    const/16 v18, 0x0

    .line 2220
    .line 2221
    const/16 v19, 0x15

    .line 2222
    .line 2223
    const/4 v13, 0x0

    .line 2224
    const-class v15, Lhj4;

    .line 2225
    .line 2226
    const-string v16, "pop"

    .line 2227
    .line 2228
    const-string v17, "pop()V"

    .line 2229
    .line 2230
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 2231
    .line 2232
    .line 2233
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2234
    .line 2235
    .line 2236
    move-object v2, v12

    .line 2237
    :cond_78
    check-cast v2, Lwh2;

    .line 2238
    .line 2239
    check-cast v2, Lwg2;

    .line 2240
    .line 2241
    sget-object v1, Lit6;->c:Lk92;

    .line 2242
    .line 2243
    invoke-static {v2, v1, v0, v5}, Lo80;->K(Lwg2;Lha4;Lki2;I)V

    .line 2244
    .line 2245
    .line 2246
    goto :goto_13

    .line 2247
    :cond_79
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2248
    .line 2249
    .line 2250
    :goto_13
    return-object v6

    .line 2251
    :pswitch_14
    move-object/from16 v0, p1

    .line 2252
    .line 2253
    check-cast v0, Lki2;

    .line 2254
    .line 2255
    move-object/from16 v1, p2

    .line 2256
    .line 2257
    check-cast v1, Ljava/lang/Integer;

    .line 2258
    .line 2259
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2260
    .line 2261
    .line 2262
    move-result v1

    .line 2263
    and-int/lit8 v4, v1, 0x3

    .line 2264
    .line 2265
    if-eq v4, v8, :cond_7a

    .line 2266
    .line 2267
    move v10, v9

    .line 2268
    :cond_7a
    and-int/2addr v1, v9

    .line 2269
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 2270
    .line 2271
    .line 2272
    move-result v1

    .line 2273
    if-eqz v1, :cond_87

    .line 2274
    .line 2275
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 2276
    .line 2277
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2278
    .line 2279
    .line 2280
    move-result v1

    .line 2281
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2282
    .line 2283
    .line 2284
    move-result-object v4

    .line 2285
    if-nez v1, :cond_7b

    .line 2286
    .line 2287
    if-ne v4, v7, :cond_7c

    .line 2288
    .line 2289
    :cond_7b
    new-instance v12, Lwa;

    .line 2290
    .line 2291
    const/16 v18, 0x0

    .line 2292
    .line 2293
    const/16 v19, 0x8

    .line 2294
    .line 2295
    const/4 v13, 0x0

    .line 2296
    const-class v15, Lhj4;

    .line 2297
    .line 2298
    const-string v16, "pop"

    .line 2299
    .line 2300
    const-string v17, "pop()V"

    .line 2301
    .line 2302
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 2303
    .line 2304
    .line 2305
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2306
    .line 2307
    .line 2308
    move-object v4, v12

    .line 2309
    :cond_7c
    check-cast v4, Lwh2;

    .line 2310
    .line 2311
    move-object/from16 v16, v4

    .line 2312
    .line 2313
    check-cast v16, Lwg2;

    .line 2314
    .line 2315
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2316
    .line 2317
    .line 2318
    move-result v1

    .line 2319
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2320
    .line 2321
    .line 2322
    move-result-object v4

    .line 2323
    if-nez v1, :cond_7d

    .line 2324
    .line 2325
    if-ne v4, v7, :cond_7e

    .line 2326
    .line 2327
    :cond_7d
    new-instance v4, Lob0;

    .line 2328
    .line 2329
    const/4 v1, 0x4

    .line 2330
    invoke-direct {v4, v11, v1}, Lob0;-><init>(Lkb0;B)V

    .line 2331
    .line 2332
    .line 2333
    invoke-virtual {v0, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2334
    .line 2335
    .line 2336
    :cond_7e
    move-object/from16 v21, v4

    .line 2337
    .line 2338
    check-cast v21, Lhh2;

    .line 2339
    .line 2340
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2341
    .line 2342
    .line 2343
    move-result v1

    .line 2344
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2345
    .line 2346
    .line 2347
    move-result-object v4

    .line 2348
    if-nez v1, :cond_7f

    .line 2349
    .line 2350
    if-ne v4, v7, :cond_80

    .line 2351
    .line 2352
    :cond_7f
    new-instance v4, Lmb0;

    .line 2353
    .line 2354
    const/4 v1, 0x7

    .line 2355
    invoke-direct {v4, v11, v1}, Lmb0;-><init>(Lkb0;B)V

    .line 2356
    .line 2357
    .line 2358
    invoke-virtual {v0, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2359
    .line 2360
    .line 2361
    :cond_80
    move-object/from16 v17, v4

    .line 2362
    .line 2363
    check-cast v17, Lwg2;

    .line 2364
    .line 2365
    iget-object v1, v11, Lkb0;->a:Lgw;

    .line 2366
    .line 2367
    iget-boolean v1, v1, Lgw;->y:Z

    .line 2368
    .line 2369
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2370
    .line 2371
    .line 2372
    move-result v4

    .line 2373
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2374
    .line 2375
    .line 2376
    move-result-object v5

    .line 2377
    if-nez v4, :cond_81

    .line 2378
    .line 2379
    if-ne v5, v7, :cond_82

    .line 2380
    .line 2381
    :cond_81
    new-instance v5, Lmb0;

    .line 2382
    .line 2383
    invoke-direct {v5, v11, v3}, Lmb0;-><init>(Lkb0;B)V

    .line 2384
    .line 2385
    .line 2386
    invoke-virtual {v0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2387
    .line 2388
    .line 2389
    :cond_82
    move-object/from16 v18, v5

    .line 2390
    .line 2391
    check-cast v18, Lwg2;

    .line 2392
    .line 2393
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2394
    .line 2395
    .line 2396
    move-result v3

    .line 2397
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2398
    .line 2399
    .line 2400
    move-result-object v4

    .line 2401
    if-nez v3, :cond_83

    .line 2402
    .line 2403
    if-ne v4, v7, :cond_84

    .line 2404
    .line 2405
    :cond_83
    new-instance v4, Lmb0;

    .line 2406
    .line 2407
    invoke-direct {v4, v11, v2}, Lmb0;-><init>(Lkb0;B)V

    .line 2408
    .line 2409
    .line 2410
    invoke-virtual {v0, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2411
    .line 2412
    .line 2413
    :cond_84
    move-object/from16 v19, v4

    .line 2414
    .line 2415
    check-cast v19, Lwg2;

    .line 2416
    .line 2417
    invoke-virtual {v0, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2418
    .line 2419
    .line 2420
    move-result v2

    .line 2421
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2422
    .line 2423
    .line 2424
    move-result-object v3

    .line 2425
    if-nez v2, :cond_85

    .line 2426
    .line 2427
    if-ne v3, v7, :cond_86

    .line 2428
    .line 2429
    :cond_85
    new-instance v3, Lmb0;

    .line 2430
    .line 2431
    const/16 v2, 0xa

    .line 2432
    .line 2433
    invoke-direct {v3, v11, v2}, Lmb0;-><init>(Lkb0;B)V

    .line 2434
    .line 2435
    .line 2436
    invoke-virtual {v0, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2437
    .line 2438
    .line 2439
    :cond_86
    move-object/from16 v20, v3

    .line 2440
    .line 2441
    check-cast v20, Lwg2;

    .line 2442
    .line 2443
    sget-object v26, Lit6;->c:Lk92;

    .line 2444
    .line 2445
    const/16 v13, 0x180

    .line 2446
    .line 2447
    const v14, 0x7fee0

    .line 2448
    .line 2449
    .line 2450
    const/4 v7, 0x0

    .line 2451
    const/4 v8, 0x0

    .line 2452
    const/4 v9, 0x0

    .line 2453
    const/4 v10, 0x0

    .line 2454
    const v11, 0x6000030

    .line 2455
    .line 2456
    .line 2457
    const/4 v12, 0x0

    .line 2458
    const/4 v15, 0x0

    .line 2459
    const/16 v22, 0x0

    .line 2460
    .line 2461
    const/16 v23, 0x0

    .line 2462
    .line 2463
    const/16 v25, 0x0

    .line 2464
    .line 2465
    const/16 v27, 0x0

    .line 2466
    .line 2467
    const/16 v29, 0x0

    .line 2468
    .line 2469
    const/16 v30, 0x0

    .line 2470
    .line 2471
    const/16 v31, 0x0

    .line 2472
    .line 2473
    const/16 v32, 0x0

    .line 2474
    .line 2475
    const/16 v33, 0x0

    .line 2476
    .line 2477
    const/16 v34, 0x0

    .line 2478
    .line 2479
    move-object/from16 v24, v0

    .line 2480
    .line 2481
    move/from16 v28, v1

    .line 2482
    .line 2483
    invoke-static/range {v7 .. v34}, Lel;->t(FFFFIIIILdy0;Lwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lhh2;Lhh2;Lhh2;Lki2;Lha4;Lha4;ZZZZZZZZ)V

    .line 2484
    .line 2485
    .line 2486
    goto :goto_14

    .line 2487
    :cond_87
    move-object/from16 v24, v0

    .line 2488
    .line 2489
    invoke-virtual/range {v24 .. v24}, Lki2;->b0()V

    .line 2490
    .line 2491
    .line 2492
    :goto_14
    return-object v6

    .line 2493
    :pswitch_15
    move-object/from16 v0, p1

    .line 2494
    .line 2495
    check-cast v0, Lki2;

    .line 2496
    .line 2497
    move-object/from16 v1, p2

    .line 2498
    .line 2499
    check-cast v1, Ljava/lang/Integer;

    .line 2500
    .line 2501
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2502
    .line 2503
    .line 2504
    move-result v1

    .line 2505
    and-int/lit8 v2, v1, 0x3

    .line 2506
    .line 2507
    if-eq v2, v8, :cond_88

    .line 2508
    .line 2509
    move v10, v9

    .line 2510
    :cond_88
    and-int/2addr v1, v9

    .line 2511
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 2512
    .line 2513
    .line 2514
    move-result v1

    .line 2515
    if-eqz v1, :cond_8b

    .line 2516
    .line 2517
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 2518
    .line 2519
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2520
    .line 2521
    .line 2522
    move-result v1

    .line 2523
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2524
    .line 2525
    .line 2526
    move-result-object v2

    .line 2527
    if-nez v1, :cond_89

    .line 2528
    .line 2529
    if-ne v2, v7, :cond_8a

    .line 2530
    .line 2531
    :cond_89
    new-instance v12, Lwa;

    .line 2532
    .line 2533
    const/16 v18, 0x0

    .line 2534
    .line 2535
    const/16 v19, 0xa

    .line 2536
    .line 2537
    const/4 v13, 0x0

    .line 2538
    const-class v15, Lhj4;

    .line 2539
    .line 2540
    const-string v16, "pop"

    .line 2541
    .line 2542
    const-string v17, "pop()V"

    .line 2543
    .line 2544
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 2545
    .line 2546
    .line 2547
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2548
    .line 2549
    .line 2550
    move-object v2, v12

    .line 2551
    :cond_8a
    check-cast v2, Lwh2;

    .line 2552
    .line 2553
    check-cast v2, Lwg2;

    .line 2554
    .line 2555
    sget-object v1, Lit6;->c:Lk92;

    .line 2556
    .line 2557
    invoke-static {v2, v1, v0, v5}, Lyg0;->d(Lwg2;Lha4;Lki2;I)V

    .line 2558
    .line 2559
    .line 2560
    goto :goto_15

    .line 2561
    :cond_8b
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2562
    .line 2563
    .line 2564
    :goto_15
    return-object v6

    .line 2565
    :pswitch_16
    move-object/from16 v0, p1

    .line 2566
    .line 2567
    check-cast v0, Lki2;

    .line 2568
    .line 2569
    move-object/from16 v1, p2

    .line 2570
    .line 2571
    check-cast v1, Ljava/lang/Integer;

    .line 2572
    .line 2573
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2574
    .line 2575
    .line 2576
    move-result v1

    .line 2577
    and-int/lit8 v2, v1, 0x3

    .line 2578
    .line 2579
    if-eq v2, v8, :cond_8c

    .line 2580
    .line 2581
    move v10, v9

    .line 2582
    :cond_8c
    and-int/2addr v1, v9

    .line 2583
    invoke-virtual {v0, v1, v10}, Lki2;->Y(IZ)Z

    .line 2584
    .line 2585
    .line 2586
    move-result v1

    .line 2587
    if-eqz v1, :cond_8f

    .line 2588
    .line 2589
    iget-object v14, v11, Lkb0;->e:Lhj4;

    .line 2590
    .line 2591
    invoke-virtual {v0, v14}, Lki2;->i(Ljava/lang/Object;)Z

    .line 2592
    .line 2593
    .line 2594
    move-result v1

    .line 2595
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 2596
    .line 2597
    .line 2598
    move-result-object v2

    .line 2599
    if-nez v1, :cond_8d

    .line 2600
    .line 2601
    if-ne v2, v7, :cond_8e

    .line 2602
    .line 2603
    :cond_8d
    new-instance v12, Lwa;

    .line 2604
    .line 2605
    const/16 v18, 0x0

    .line 2606
    .line 2607
    const/16 v19, 0x13

    .line 2608
    .line 2609
    const/4 v13, 0x0

    .line 2610
    const-class v15, Lhj4;

    .line 2611
    .line 2612
    const-string v16, "pop"

    .line 2613
    .line 2614
    const-string v17, "pop()V"

    .line 2615
    .line 2616
    invoke-direct/range {v12 .. v19}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 2617
    .line 2618
    .line 2619
    invoke-virtual {v0, v12}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2620
    .line 2621
    .line 2622
    move-object v2, v12

    .line 2623
    :cond_8e
    check-cast v2, Lwh2;

    .line 2624
    .line 2625
    check-cast v2, Lwg2;

    .line 2626
    .line 2627
    sget-object v1, Lit6;->c:Lk92;

    .line 2628
    .line 2629
    invoke-static {v2, v1, v0, v5}, Lkb;->o(Lwg2;Lha4;Lki2;I)V

    .line 2630
    .line 2631
    .line 2632
    goto :goto_16

    .line 2633
    :cond_8f
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2634
    .line 2635
    .line 2636
    :goto_16
    return-object v6

    .line 2637
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
