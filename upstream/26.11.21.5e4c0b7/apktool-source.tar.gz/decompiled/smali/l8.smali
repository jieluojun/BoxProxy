.class public final Ll8;
.super Luj7;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final c:Lv8;


# direct methods
.method public constructor <init>(Lv8;Ljava/util/Optional;Ljava/util/Optional;)V
    .locals 0

    .line 1
    invoke-direct {p0, p2, p3}, Luj7;-><init>(Ljava/util/Optional;Ljava/util/Optional;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ll8;->c:Lv8;

    .line 5
    .line 6
    return-void
.end method
