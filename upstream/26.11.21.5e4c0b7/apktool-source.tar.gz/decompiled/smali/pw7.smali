.class public abstract Lpw7;
.super Landroid/view/View;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lm35;


# static fields
.field public static final synthetic h:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lem1;

    .line 2
    .line 3
    return-void
.end method
