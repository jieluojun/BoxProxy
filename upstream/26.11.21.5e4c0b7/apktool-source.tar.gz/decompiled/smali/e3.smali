.class public abstract Le3;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lgi1;


# instance fields
.field public final h:Lhi1;


# direct methods
.method public constructor <init>(Lhi1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Le3;->h:Lhi1;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final getKey()Lhi1;
    .locals 0

    .line 1
    iget-object p0, p0, Le3;->h:Lhi1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final bridge l(Lii1;)Lii1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Ldj;->u0(Lgi1;Lii1;)Lii1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge p(Lhi1;)Lgi1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Ldj;->T(Lgi1;Lhi1;)Lgi1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final v(Llh2;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, Llh2;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge z(Lhi1;)Lii1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Ldj;->k0(Lgi1;Lhi1;)Lii1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
