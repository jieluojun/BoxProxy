.class public abstract Lbh0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lu35;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lu35;

    .line 2
    .line 3
    const/high16 v1, 0x41800000    # 16.0f

    .line 4
    .line 5
    const/high16 v2, 0x41500000    # 13.0f

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, v1, v2}, Lu35;-><init>(FFFF)V

    .line 8
    .line 9
    .line 10
    sput-object v0, Lbh0;->a:Lu35;

    .line 11
    .line 12
    return-void
.end method

.method public static a(Lki2;)Lq97;
    .locals 11

    .line 1
    sget-object v0, Lsz0;->a:Lcx1;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Lrz0;

    .line 8
    .line 9
    iget-object v1, v1, Lrz0;->r:Lf75;

    .line 10
    .line 11
    invoke-virtual {v1}, Lf75;->getValue()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Ldy0;

    .line 16
    .line 17
    iget-wide v3, v1, Ldy0;->a:J

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Lrz0;

    .line 24
    .line 25
    iget-object v1, v1, Lrz0;->v:Lf75;

    .line 26
    .line 27
    invoke-virtual {v1}, Lf75;->getValue()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Ldy0;

    .line 32
    .line 33
    iget-wide v5, v1, Ldy0;->a:J

    .line 34
    .line 35
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Lrz0;

    .line 40
    .line 41
    iget-object v1, v1, Lrz0;->s:Lf75;

    .line 42
    .line 43
    invoke-virtual {v1}, Lf75;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    check-cast v1, Ldy0;

    .line 48
    .line 49
    iget-wide v7, v1, Ldy0;->a:J

    .line 50
    .line 51
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    check-cast v0, Lrz0;

    .line 56
    .line 57
    invoke-virtual {v0}, Lrz0;->d()J

    .line 58
    .line 59
    .line 60
    move-result-wide v9

    .line 61
    invoke-virtual {p0, v3, v4}, Lki2;->f(J)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-virtual {p0, v5, v6}, Lki2;->f(J)Z

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    or-int/2addr v0, v1

    .line 70
    invoke-virtual {p0, v7, v8}, Lki2;->f(J)Z

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    or-int/2addr v0, v1

    .line 75
    invoke-virtual {p0, v9, v10}, Lki2;->f(J)Z

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    or-int/2addr v0, v1

    .line 80
    invoke-virtual {p0}, Lki2;->T()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    if-nez v0, :cond_0

    .line 85
    .line 86
    sget-object v0, Lz41;->a:Lql0;

    .line 87
    .line 88
    if-ne v1, v0, :cond_1

    .line 89
    .line 90
    :cond_0
    new-instance v2, Lq97;

    .line 91
    .line 92
    invoke-direct/range {v2 .. v10}, Lq97;-><init>(JJJJ)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    move-object v1, v2

    .line 99
    :cond_1
    check-cast v1, Lq97;

    .line 100
    .line 101
    return-object v1
.end method
