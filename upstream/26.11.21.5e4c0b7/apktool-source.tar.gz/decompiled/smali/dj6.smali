.class public final synthetic Ldj6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lbj;


# direct methods
.method public synthetic constructor <init>(Lbj;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Ldj6;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Ldj6;->i:Lbj;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Ldj6;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object p0, p0, Ldj6;->i:Lbj;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    iput-boolean v2, p0, Lbj;->m:Z

    .line 12
    .line 13
    return-object v1

    .line 14
    :pswitch_0
    iput-boolean v2, p0, Lbj;->m:Z

    .line 15
    .line 16
    return-object v1

    .line 17
    :pswitch_1
    iget-object p0, p0, Lbj;->i:Lf75;

    .line 18
    .line 19
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    check-cast p0, Lhv4;

    .line 24
    .line 25
    iget-wide v0, p0, Lhv4;->a:J

    .line 26
    .line 27
    return-object p0

    .line 28
    nop

    .line 29
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
