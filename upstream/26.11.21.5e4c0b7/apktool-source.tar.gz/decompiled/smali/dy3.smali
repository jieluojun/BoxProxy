.class public final Ldy3;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lia3;


# instance fields
.field public final a:Lwg2;

.field public final b:Ljava/util/LinkedHashMap;

.field public final c:Lec2;


# direct methods
.method public constructor <init>(Lzc4;Lwg2;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Ldy3;->a:Lwg2;

    .line 5
    .line 6
    new-instance p2, Ljava/util/LinkedHashMap;

    .line 7
    .line 8
    invoke-direct {p2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p2, p0, Ldy3;->b:Ljava/util/LinkedHashMap;

    .line 12
    .line 13
    iget-object p1, p1, Lzc4;->a:Lxn6;

    .line 14
    .line 15
    new-instance p2, Lec2;

    .line 16
    .line 17
    const/4 v0, 0x3

    .line 18
    invoke-direct {p2, p1, p0, v0}, Lec2;-><init>(Ltb2;Ljava/lang/Object;B)V

    .line 19
    .line 20
    .line 21
    iput-object p2, p0, Ldy3;->c:Lec2;

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final a()Ltb2;
    .locals 0

    .line 1
    iget-object p0, p0, Ldy3;->c:Lec2;

    .line 2
    .line 3
    return-object p0
.end method
