.class public final Lkj7;
.super Ljava/util/concurrent/CancellationException;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final transient h:Llj7;


# direct methods
.method public constructor <init>(Ljava/lang/String;Llj7;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lkj7;->h:Llj7;

    .line 5
    .line 6
    return-void
.end method
