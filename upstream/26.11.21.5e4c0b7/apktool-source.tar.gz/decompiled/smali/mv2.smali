.class public final synthetic Lmv2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lvs2;

.field public final synthetic j:Lpx2;

.field public final synthetic k:Lwg2;

.field public final synthetic l:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lpx2;Lvs2;Lwg2;Lzd4;)V
    .locals 1

    .line 16
    const/4 v0, 0x0

    iput-byte v0, p0, Lmv2;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lmv2;->j:Lpx2;

    iput-object p2, p0, Lmv2;->i:Lvs2;

    iput-object p3, p0, Lmv2;->k:Lwg2;

    iput-object p4, p0, Lmv2;->l:Lzd4;

    return-void
.end method

.method public synthetic constructor <init>(Lvs2;Lpx2;Lwg2;Lzd4;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lmv2;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lmv2;->i:Lvs2;

    .line 8
    .line 9
    iput-object p2, p0, Lmv2;->j:Lpx2;

    .line 10
    .line 11
    iput-object p3, p0, Lmv2;->k:Lwg2;

    .line 12
    .line 13
    iput-object p4, p0, Lmv2;->l:Lzd4;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lmv2;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    sget-object v4, Lz41;->a:Lql0;

    .line 10
    .line 11
    iget-object v5, v0, Lmv2;->l:Lzd4;

    .line 12
    .line 13
    const/4 v6, 0x1

    .line 14
    const/4 v7, 0x0

    .line 15
    packed-switch v1, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    move-object/from16 v1, p1

    .line 19
    .line 20
    check-cast v1, Lvk3;

    .line 21
    .line 22
    move-object/from16 v15, p2

    .line 23
    .line 24
    check-cast v15, Lki2;

    .line 25
    .line 26
    move-object/from16 v8, p3

    .line 27
    .line 28
    check-cast v8, Ljava/lang/Integer;

    .line 29
    .line 30
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result v8

    .line 34
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    and-int/lit8 v1, v8, 0x11

    .line 38
    .line 39
    if-eq v1, v3, :cond_0

    .line 40
    .line 41
    move v7, v6

    .line 42
    :cond_0
    and-int/2addr v8, v6

    .line 43
    invoke-virtual {v15, v8, v7}, Lki2;->Y(IZ)Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_8

    .line 48
    .line 49
    const/4 v10, 0x0

    .line 50
    const/16 v11, 0xd

    .line 51
    .line 52
    sget-object v6, Lea4;->h:Lea4;

    .line 53
    .line 54
    const/4 v7, 0x0

    .line 55
    const/high16 v8, 0x41400000    # 12.0f

    .line 56
    .line 57
    const/4 v9, 0x0

    .line 58
    invoke-static/range {v6 .. v11}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 59
    .line 60
    .line 61
    move-result-object v14

    .line 62
    iget-object v8, v0, Lmv2;->i:Lvs2;

    .line 63
    .line 64
    invoke-virtual {v15, v8}, Lki2;->g(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    invoke-virtual {v15}, Lki2;->T()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    if-nez v1, :cond_1

    .line 73
    .line 74
    if-ne v3, v4, :cond_2

    .line 75
    .line 76
    :cond_1
    new-instance v6, Lpk1;

    .line 77
    .line 78
    const/4 v12, 0x0

    .line 79
    const/16 v13, 0x1b

    .line 80
    .line 81
    const/4 v7, 0x0

    .line 82
    const-class v9, Lvs2;

    .line 83
    .line 84
    const-string v10, "toggleIpMode"

    .line 85
    .line 86
    const-string v11, "toggleIpMode()V"

    .line 87
    .line 88
    invoke-direct/range {v6 .. v13}, Lpk1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v15, v6}, Lki2;->q0(Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    move-object v3, v6

    .line 95
    :cond_2
    check-cast v3, Lwh2;

    .line 96
    .line 97
    move-object v9, v3

    .line 98
    check-cast v9, Lwg2;

    .line 99
    .line 100
    invoke-virtual {v15, v8}, Lki2;->g(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    iget-object v3, v0, Lmv2;->j:Lpx2;

    .line 105
    .line 106
    invoke-virtual {v15, v3}, Lki2;->i(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v6

    .line 110
    or-int/2addr v1, v6

    .line 111
    invoke-virtual {v15}, Lki2;->T()Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v6

    .line 115
    const/4 v7, 0x2

    .line 116
    if-nez v1, :cond_3

    .line 117
    .line 118
    if-ne v6, v4, :cond_4

    .line 119
    .line 120
    :cond_3
    new-instance v6, Lov2;

    .line 121
    .line 122
    invoke-direct {v6, v8, v3, v7}, Lov2;-><init>(Lvs2;Lpx2;B)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v15, v6}, Lki2;->q0(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    :cond_4
    move-object v10, v6

    .line 129
    check-cast v10, Lwg2;

    .line 130
    .line 131
    invoke-virtual {v15, v8}, Lki2;->g(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v1

    .line 135
    invoke-virtual {v15, v3}, Lki2;->i(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v6

    .line 139
    or-int/2addr v1, v6

    .line 140
    invoke-virtual {v15}, Lki2;->T()Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v6

    .line 144
    if-nez v1, :cond_5

    .line 145
    .line 146
    if-ne v6, v4, :cond_6

    .line 147
    .line 148
    :cond_5
    new-instance v6, Lov2;

    .line 149
    .line 150
    const/4 v1, 0x3

    .line 151
    invoke-direct {v6, v8, v3, v1}, Lov2;-><init>(Lvs2;Lpx2;B)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v15, v6}, Lki2;->q0(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    :cond_6
    move-object v12, v6

    .line 158
    check-cast v12, Lwg2;

    .line 159
    .line 160
    invoke-virtual {v15}, Lki2;->T()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    if-ne v1, v4, :cond_7

    .line 165
    .line 166
    new-instance v1, Lpv2;

    .line 167
    .line 168
    invoke-direct {v1, v5, v7}, Lpv2;-><init>(Lzd4;B)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v15, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    :cond_7
    move-object v13, v1

    .line 175
    check-cast v13, Lwg2;

    .line 176
    .line 177
    const/high16 v16, 0x1b0000

    .line 178
    .line 179
    iget-object v11, v0, Lmv2;->k:Lwg2;

    .line 180
    .line 181
    move-object v8, v3

    .line 182
    invoke-static/range {v8 .. v16}, Lxj;->x(Lpx2;Lwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lha4;Lki2;I)V

    .line 183
    .line 184
    .line 185
    goto :goto_0

    .line 186
    :cond_8
    invoke-virtual {v15}, Lki2;->b0()V

    .line 187
    .line 188
    .line 189
    :goto_0
    return-object v2

    .line 190
    :pswitch_0
    move-object/from16 v1, p1

    .line 191
    .line 192
    check-cast v1, Lvk3;

    .line 193
    .line 194
    move-object/from16 v14, p2

    .line 195
    .line 196
    check-cast v14, Lki2;

    .line 197
    .line 198
    move-object/from16 v8, p3

    .line 199
    .line 200
    check-cast v8, Ljava/lang/Integer;

    .line 201
    .line 202
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 203
    .line 204
    .line 205
    move-result v8

    .line 206
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 207
    .line 208
    .line 209
    and-int/lit8 v1, v8, 0x11

    .line 210
    .line 211
    if-eq v1, v3, :cond_9

    .line 212
    .line 213
    move v1, v6

    .line 214
    goto :goto_1

    .line 215
    :cond_9
    move v1, v7

    .line 216
    :goto_1
    and-int/2addr v8, v6

    .line 217
    invoke-virtual {v14, v8, v1}, Lki2;->Y(IZ)Z

    .line 218
    .line 219
    .line 220
    move-result v1

    .line 221
    if-eqz v1, :cond_11

    .line 222
    .line 223
    iget-object v1, v0, Lmv2;->i:Lvs2;

    .line 224
    .line 225
    invoke-virtual {v14, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 226
    .line 227
    .line 228
    move-result v3

    .line 229
    invoke-virtual {v14}, Lki2;->T()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v8

    .line 233
    if-nez v3, :cond_a

    .line 234
    .line 235
    if-ne v8, v4, :cond_b

    .line 236
    .line 237
    :cond_a
    new-instance v15, Lpk1;

    .line 238
    .line 239
    const/16 v21, 0x0

    .line 240
    .line 241
    const/16 v22, 0x15

    .line 242
    .line 243
    const/16 v16, 0x0

    .line 244
    .line 245
    const-class v18, Lvs2;

    .line 246
    .line 247
    const-string v19, "toggleIpMode"

    .line 248
    .line 249
    const-string v20, "toggleIpMode()V"

    .line 250
    .line 251
    move-object/from16 v17, v1

    .line 252
    .line 253
    invoke-direct/range {v15 .. v22}, Lpk1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 254
    .line 255
    .line 256
    invoke-virtual {v14, v15}, Lki2;->q0(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    move-object v8, v15

    .line 260
    :cond_b
    check-cast v8, Lwh2;

    .line 261
    .line 262
    move-object v9, v8

    .line 263
    check-cast v9, Lwg2;

    .line 264
    .line 265
    invoke-virtual {v14, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 266
    .line 267
    .line 268
    move-result v3

    .line 269
    iget-object v8, v0, Lmv2;->j:Lpx2;

    .line 270
    .line 271
    invoke-virtual {v14, v8}, Lki2;->i(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v10

    .line 275
    or-int/2addr v3, v10

    .line 276
    invoke-virtual {v14}, Lki2;->T()Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object v10

    .line 280
    if-nez v3, :cond_c

    .line 281
    .line 282
    if-ne v10, v4, :cond_d

    .line 283
    .line 284
    :cond_c
    new-instance v10, Lov2;

    .line 285
    .line 286
    invoke-direct {v10, v1, v8, v7}, Lov2;-><init>(Lvs2;Lpx2;B)V

    .line 287
    .line 288
    .line 289
    invoke-virtual {v14, v10}, Lki2;->q0(Ljava/lang/Object;)V

    .line 290
    .line 291
    .line 292
    :cond_d
    check-cast v10, Lwg2;

    .line 293
    .line 294
    invoke-virtual {v14, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 295
    .line 296
    .line 297
    move-result v3

    .line 298
    invoke-virtual {v14, v8}, Lki2;->i(Ljava/lang/Object;)Z

    .line 299
    .line 300
    .line 301
    move-result v11

    .line 302
    or-int/2addr v3, v11

    .line 303
    invoke-virtual {v14}, Lki2;->T()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v11

    .line 307
    if-nez v3, :cond_e

    .line 308
    .line 309
    if-ne v11, v4, :cond_f

    .line 310
    .line 311
    :cond_e
    new-instance v11, Lov2;

    .line 312
    .line 313
    invoke-direct {v11, v1, v8, v6}, Lov2;-><init>(Lvs2;Lpx2;B)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v14, v11}, Lki2;->q0(Ljava/lang/Object;)V

    .line 317
    .line 318
    .line 319
    :cond_f
    move-object v12, v11

    .line 320
    check-cast v12, Lwg2;

    .line 321
    .line 322
    invoke-virtual {v14}, Lki2;->T()Ljava/lang/Object;

    .line 323
    .line 324
    .line 325
    move-result-object v1

    .line 326
    if-ne v1, v4, :cond_10

    .line 327
    .line 328
    new-instance v1, Lpv2;

    .line 329
    .line 330
    invoke-direct {v1, v5, v7}, Lpv2;-><init>(Lzd4;B)V

    .line 331
    .line 332
    .line 333
    invoke-virtual {v14, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    :cond_10
    move-object v13, v1

    .line 337
    check-cast v13, Lwg2;

    .line 338
    .line 339
    const/high16 v15, 0x30000

    .line 340
    .line 341
    iget-object v11, v0, Lmv2;->k:Lwg2;

    .line 342
    .line 343
    invoke-static/range {v8 .. v15}, Ldj;->n(Lpx2;Lwg2;Lwg2;Lwg2;Lwg2;Lwg2;Lki2;I)V

    .line 344
    .line 345
    .line 346
    goto :goto_2

    .line 347
    :cond_11
    invoke-virtual {v14}, Lki2;->b0()V

    .line 348
    .line 349
    .line 350
    :goto_2
    return-object v2

    .line 351
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
