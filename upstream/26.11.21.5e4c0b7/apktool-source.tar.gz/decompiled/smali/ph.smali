.class public final synthetic Lph;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Lq21;

.field public final synthetic l:I

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lha4;Ltw;Lvw;Lz30;Lp12;Lq21;I)V
    .locals 1

    .line 23
    const/4 v0, 0x4

    iput-byte v0, p0, Lph;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lph;->j:Ljava/lang/Object;

    iput-object p2, p0, Lph;->m:Ljava/lang/Object;

    iput-object p3, p0, Lph;->i:Ljava/lang/Object;

    iput-object p4, p0, Lph;->n:Ljava/lang/Object;

    iput-object p5, p0, Lph;->o:Ljava/lang/Object;

    iput-object p6, p0, Lph;->k:Lq21;

    iput p7, p0, Lph;->l:I

    return-void
.end method

.method public synthetic constructor <init>(Lq21;Ljava/lang/Object;Lmp0;Landroid/view/MotionEvent;Lxw6;Lvf7;I)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Lph;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lph;->k:Lq21;

    .line 8
    .line 9
    iput-object p2, p0, Lph;->m:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lph;->j:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lph;->i:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Lph;->n:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Lph;->o:Ljava/lang/Object;

    .line 18
    .line 19
    iput p7, p0, Lph;->l:I

    .line 20
    .line 21
    return-void
.end method

.method public synthetic constructor <init>(Lq21;Ljava/lang/String;Ljava/lang/Boolean;Lyc1;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 1

    .line 22
    const/4 v0, 0x3

    iput-byte v0, p0, Lph;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lph;->k:Lq21;

    iput-object p2, p0, Lph;->m:Ljava/lang/Object;

    iput-object p3, p0, Lph;->j:Ljava/lang/Object;

    iput-object p4, p0, Lph;->i:Ljava/lang/Object;

    iput-object p5, p0, Lph;->n:Ljava/lang/Object;

    iput-object p6, p0, Lph;->o:Ljava/lang/Object;

    iput p7, p0, Lph;->l:I

    return-void
.end method

.method public synthetic constructor <init>(Lrn7;Lhh2;Lha4;Lg32;Lz42;Lq21;I)V
    .locals 1

    .line 24
    const/4 v0, 0x1

    iput-byte v0, p0, Lph;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lph;->m:Ljava/lang/Object;

    iput-object p2, p0, Lph;->i:Ljava/lang/Object;

    iput-object p3, p0, Lph;->j:Ljava/lang/Object;

    iput-object p4, p0, Lph;->n:Ljava/lang/Object;

    iput-object p5, p0, Lph;->o:Ljava/lang/Object;

    iput-object p6, p0, Lph;->k:Lq21;

    iput p7, p0, Lph;->l:I

    return-void
.end method

.method public synthetic constructor <init>(Lsn7;Lha4;Lhh2;La40;Lhh2;Lq21;I)V
    .locals 1

    .line 25
    const/4 v0, 0x0

    iput-byte v0, p0, Lph;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lph;->m:Ljava/lang/Object;

    iput-object p2, p0, Lph;->j:Ljava/lang/Object;

    iput-object p3, p0, Lph;->i:Ljava/lang/Object;

    iput-object p4, p0, Lph;->o:Ljava/lang/Object;

    iput-object p5, p0, Lph;->n:Ljava/lang/Object;

    iput-object p6, p0, Lph;->k:Lq21;

    iput p7, p0, Lph;->l:I

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lph;->h:B

    .line 4
    .line 5
    iget-object v2, v0, Lph;->o:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, v0, Lph;->n:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, v0, Lph;->m:Ljava/lang/Object;

    .line 10
    .line 11
    sget-object v5, Los7;->a:Los7;

    .line 12
    .line 13
    iget v6, v0, Lph;->l:I

    .line 14
    .line 15
    iget-object v7, v0, Lph;->i:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v8, v0, Lph;->j:Ljava/lang/Object;

    .line 18
    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    move-object v9, v8

    .line 23
    check-cast v9, Lha4;

    .line 24
    .line 25
    move-object v10, v4

    .line 26
    check-cast v10, Ltw;

    .line 27
    .line 28
    move-object v11, v7

    .line 29
    check-cast v11, Lvw;

    .line 30
    .line 31
    move-object v12, v3

    .line 32
    check-cast v12, Lz30;

    .line 33
    .line 34
    move-object v13, v2

    .line 35
    check-cast v13, Lp12;

    .line 36
    .line 37
    move-object/from16 v15, p1

    .line 38
    .line 39
    check-cast v15, Lki2;

    .line 40
    .line 41
    move-object/from16 v1, p2

    .line 42
    .line 43
    check-cast v1, Ljava/lang/Integer;

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    or-int/lit8 v6, v6, 0x1

    .line 49
    .line 50
    invoke-static {v6}, Ld43;->P(I)I

    .line 51
    .line 52
    .line 53
    move-result v16

    .line 54
    iget-object v14, v0, Lph;->k:Lq21;

    .line 55
    .line 56
    invoke-static/range {v9 .. v16}, Lcj;->n(Lha4;Ltw;Lvw;Lz30;Lp12;Lq21;Lki2;I)V

    .line 57
    .line 58
    .line 59
    return-object v5

    .line 60
    :pswitch_0
    move-object/from16 v18, v4

    .line 61
    .line 62
    check-cast v18, Ljava/lang/String;

    .line 63
    .line 64
    move-object/from16 v19, v8

    .line 65
    .line 66
    check-cast v19, Ljava/lang/Boolean;

    .line 67
    .line 68
    move-object/from16 v20, v7

    .line 69
    .line 70
    check-cast v20, Lyc1;

    .line 71
    .line 72
    move-object/from16 v23, p1

    .line 73
    .line 74
    check-cast v23, Lki2;

    .line 75
    .line 76
    move-object/from16 v1, p2

    .line 77
    .line 78
    check-cast v1, Ljava/lang/Integer;

    .line 79
    .line 80
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    .line 82
    .line 83
    invoke-static {v6}, Ld43;->P(I)I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    or-int/lit8 v24, v1, 0x1

    .line 88
    .line 89
    iget-object v1, v0, Lph;->k:Lq21;

    .line 90
    .line 91
    iget-object v2, v0, Lph;->n:Ljava/lang/Object;

    .line 92
    .line 93
    iget-object v0, v0, Lph;->o:Ljava/lang/Object;

    .line 94
    .line 95
    move-object/from16 v22, v0

    .line 96
    .line 97
    move-object/from16 v17, v1

    .line 98
    .line 99
    move-object/from16 v21, v2

    .line 100
    .line 101
    invoke-virtual/range {v17 .. v24}, Lq21;->m(Ljava/lang/String;Ljava/lang/Boolean;Lyc1;Ljava/lang/Object;Ljava/lang/Object;Lki2;I)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    return-object v5

    .line 105
    :pswitch_1
    check-cast v8, Lmp0;

    .line 106
    .line 107
    move-object v9, v7

    .line 108
    check-cast v9, Landroid/view/MotionEvent;

    .line 109
    .line 110
    move-object v10, v3

    .line 111
    check-cast v10, Lxw6;

    .line 112
    .line 113
    move-object v11, v2

    .line 114
    check-cast v11, Lvf7;

    .line 115
    .line 116
    move-object/from16 v12, p1

    .line 117
    .line 118
    check-cast v12, Lki2;

    .line 119
    .line 120
    move-object/from16 v1, p2

    .line 121
    .line 122
    check-cast v1, Ljava/lang/Integer;

    .line 123
    .line 124
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 125
    .line 126
    .line 127
    invoke-static {v6}, Ld43;->P(I)I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    or-int/lit8 v13, v1, 0x1

    .line 132
    .line 133
    iget-object v6, v0, Lph;->k:Lq21;

    .line 134
    .line 135
    iget-object v7, v0, Lph;->m:Ljava/lang/Object;

    .line 136
    .line 137
    invoke-virtual/range {v6 .. v13}, Lq21;->f(Ljava/lang/Object;Lmp0;Landroid/view/MotionEvent;Lxw6;Lvf7;Lki2;I)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    return-object v5

    .line 141
    :pswitch_2
    move-object v14, v4

    .line 142
    check-cast v14, Lrn7;

    .line 143
    .line 144
    move-object v15, v7

    .line 145
    check-cast v15, Lhh2;

    .line 146
    .line 147
    move-object/from16 v16, v8

    .line 148
    .line 149
    check-cast v16, Lha4;

    .line 150
    .line 151
    move-object/from16 v17, v3

    .line 152
    .line 153
    check-cast v17, Lg32;

    .line 154
    .line 155
    move-object/from16 v18, v2

    .line 156
    .line 157
    check-cast v18, Lz42;

    .line 158
    .line 159
    move-object/from16 v20, p1

    .line 160
    .line 161
    check-cast v20, Lki2;

    .line 162
    .line 163
    move-object/from16 v1, p2

    .line 164
    .line 165
    check-cast v1, Ljava/lang/Integer;

    .line 166
    .line 167
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    or-int/lit8 v6, v6, 0x1

    .line 171
    .line 172
    invoke-static {v6}, Ld43;->P(I)I

    .line 173
    .line 174
    .line 175
    move-result v21

    .line 176
    iget-object v0, v0, Lph;->k:Lq21;

    .line 177
    .line 178
    move-object/from16 v19, v0

    .line 179
    .line 180
    invoke-static/range {v14 .. v21}, Lkb;->g(Lrn7;Lhh2;Lha4;Lg32;Lz42;Lq21;Lki2;I)V

    .line 181
    .line 182
    .line 183
    return-object v5

    .line 184
    :pswitch_3
    check-cast v4, Lsn7;

    .line 185
    .line 186
    check-cast v8, Lha4;

    .line 187
    .line 188
    check-cast v7, Lhh2;

    .line 189
    .line 190
    move-object v9, v2

    .line 191
    check-cast v9, La40;

    .line 192
    .line 193
    move-object v10, v3

    .line 194
    check-cast v10, Lhh2;

    .line 195
    .line 196
    move-object/from16 v12, p1

    .line 197
    .line 198
    check-cast v12, Lki2;

    .line 199
    .line 200
    move-object/from16 v1, p2

    .line 201
    .line 202
    check-cast v1, Ljava/lang/Integer;

    .line 203
    .line 204
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 205
    .line 206
    .line 207
    or-int/lit8 v6, v6, 0x1

    .line 208
    .line 209
    invoke-static {v6}, Ld43;->P(I)I

    .line 210
    .line 211
    .line 212
    move-result v13

    .line 213
    iget-object v11, v0, Lph;->k:Lq21;

    .line 214
    .line 215
    move-object v6, v8

    .line 216
    move-object v8, v7

    .line 217
    move-object v7, v6

    .line 218
    move-object v6, v4

    .line 219
    invoke-static/range {v6 .. v13}, Lf48;->a(Lsn7;Lha4;Lhh2;La40;Lhh2;Lq21;Lki2;I)V

    .line 220
    .line 221
    .line 222
    return-object v5

    .line 223
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
