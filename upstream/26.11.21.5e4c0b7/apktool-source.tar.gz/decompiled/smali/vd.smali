.class public final Lvd;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .locals 1

    .line 10
    const/16 v0, 0x8

    iput-byte v0, p0, Lvd;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 11
    iput-byte p2, p0, Lvd;->h:B

    iput-object p1, p0, Lvd;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lq21;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lvd;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lvd;->i:Ljava/lang/Object;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget-byte v0, p0, Lvd;->h:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Los7;->a:Los7;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    check-cast p1, Lu22;

    .line 12
    .line 13
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p0, Lwu7;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    const-wide/16 v2, 0x0

    .line 22
    .line 23
    if-eqz p1, :cond_3

    .line 24
    .line 25
    if-eq p1, v4, :cond_1

    .line 26
    .line 27
    const/4 v0, 0x2

    .line 28
    if-ne p1, v0, :cond_0

    .line 29
    .line 30
    iget-object p0, p0, Lwu7;->x:Lz42;

    .line 31
    .line 32
    iget-object p0, p0, Lz42;->a:Lw22;

    .line 33
    .line 34
    iget-object p0, p0, Lw22;->e:Luu7;

    .line 35
    .line 36
    if-eqz p0, :cond_4

    .line 37
    .line 38
    iget-wide v2, p0, Luu7;->b:J

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    invoke-static {}, Lfb1;->a()V

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_1
    iget-object p1, p0, Lwu7;->w:Lg32;

    .line 46
    .line 47
    iget-object p1, p1, Lg32;->a:Lw22;

    .line 48
    .line 49
    iget-object p1, p1, Lw22;->e:Luu7;

    .line 50
    .line 51
    if-eqz p1, :cond_2

    .line 52
    .line 53
    iget-wide v2, p1, Luu7;->b:J

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_2
    iget-object p0, p0, Lwu7;->x:Lz42;

    .line 57
    .line 58
    iget-object p0, p0, Lz42;->a:Lw22;

    .line 59
    .line 60
    iget-object p0, p0, Lw22;->e:Luu7;

    .line 61
    .line 62
    if-eqz p0, :cond_4

    .line 63
    .line 64
    iget-wide v2, p0, Luu7;->a:J

    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_3
    iget-object p0, p0, Lwu7;->w:Lg32;

    .line 68
    .line 69
    iget-object p0, p0, Lg32;->a:Lw22;

    .line 70
    .line 71
    iget-object p0, p0, Lw22;->e:Luu7;

    .line 72
    .line 73
    if-eqz p0, :cond_4

    .line 74
    .line 75
    iget-wide v2, p0, Luu7;->a:J

    .line 76
    .line 77
    :cond_4
    :goto_0
    new-instance v1, Ldy0;

    .line 78
    .line 79
    invoke-direct {v1, v2, v3}, Ldy0;-><init>(J)V

    .line 80
    .line 81
    .line 82
    :goto_1
    return-object v1

    .line 83
    :pswitch_0
    check-cast p1, Ljava/lang/Throwable;

    .line 84
    .line 85
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast p0, Ll57;

    .line 88
    .line 89
    iget-object v0, p0, Ll57;->j:Lll0;

    .line 90
    .line 91
    if-eqz v0, :cond_5

    .line 92
    .line 93
    invoke-virtual {v0, p1}, Lll0;->t(Ljava/lang/Throwable;)Z

    .line 94
    .line 95
    .line 96
    :cond_5
    iput-object v1, p0, Ll57;->j:Lll0;

    .line 97
    .line 98
    return-object v2

    .line 99
    :pswitch_1
    check-cast p1, Lig3;

    .line 100
    .line 101
    iget-object p1, p1, Lig3;->a:Landroid/view/KeyEvent;

    .line 102
    .line 103
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 104
    .line 105
    check-cast p0, Lij6;

    .line 106
    .line 107
    sget-object v0, Lo80;->T:Ly33;

    .line 108
    .line 109
    invoke-virtual {v0, p1}, Ly33;->s(Landroid/view/KeyEvent;)Lhg3;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    sget-object v0, Lhg3;->z:Lhg3;

    .line 114
    .line 115
    if-ne p1, v0, :cond_6

    .line 116
    .line 117
    invoke-virtual {p0}, Lij6;->c()V

    .line 118
    .line 119
    .line 120
    move v3, v4

    .line 121
    :cond_6
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 122
    .line 123
    .line 124
    move-result-object p0

    .line 125
    return-object p0

    .line 126
    :pswitch_2
    check-cast p1, Ljava/lang/Boolean;

    .line 127
    .line 128
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 129
    .line 130
    .line 131
    move-result p1

    .line 132
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast p0, Lfc5;

    .line 135
    .line 136
    if-eqz p0, :cond_7

    .line 137
    .line 138
    iput-boolean p1, p0, Lfc5;->j:Z

    .line 139
    .line 140
    :cond_7
    return-object v2

    .line 141
    :pswitch_3
    check-cast p1, Ldy0;

    .line 142
    .line 143
    iget-wide v2, p1, Ldy0;->a:J

    .line 144
    .line 145
    new-instance p1, Lbi3;

    .line 146
    .line 147
    new-instance v0, Lln6;

    .line 148
    .line 149
    new-instance v4, Li92;

    .line 150
    .line 151
    const v5, 0x3e23d70a    # 0.16f

    .line 152
    .line 153
    .line 154
    invoke-static {v5, v2, v3}, Ldy0;->b(FJ)J

    .line 155
    .line 156
    .line 157
    move-result-wide v5

    .line 158
    invoke-direct {v4, v5, v6, v1}, Li92;-><init>(JLiq3;)V

    .line 159
    .line 160
    .line 161
    sget-object v5, Lv06;->a:Lt06;

    .line 162
    .line 163
    invoke-direct {v0, v4, v5}, Lln6;-><init>(Li92;Lt06;)V

    .line 164
    .line 165
    .line 166
    new-instance v4, Lbi3;

    .line 167
    .line 168
    new-instance v6, Lln6;

    .line 169
    .line 170
    new-instance v7, Li92;

    .line 171
    .line 172
    invoke-direct {v7, v2, v3, v1}, Li92;-><init>(JLiq3;)V

    .line 173
    .line 174
    .line 175
    invoke-direct {v6, v7, v5}, Lln6;-><init>(Li92;Lt06;)V

    .line 176
    .line 177
    .line 178
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 179
    .line 180
    check-cast p0, Lln6;

    .line 181
    .line 182
    new-instance v1, Li83;

    .line 183
    .line 184
    const/high16 v2, 0x40800000    # 4.0f

    .line 185
    .line 186
    invoke-direct {v1, v2, v2, v2, v2}, Li83;-><init>(FFFF)V

    .line 187
    .line 188
    .line 189
    invoke-direct {v4, v6, p0, v1}, Lbi3;-><init>(Lln6;Lp11;Li83;)V

    .line 190
    .line 191
    .line 192
    new-instance p0, Li83;

    .line 193
    .line 194
    const/high16 v1, 0x41000000    # 8.0f

    .line 195
    .line 196
    invoke-direct {p0, v1, v1, v1, v1}, Li83;-><init>(FFFF)V

    .line 197
    .line 198
    .line 199
    invoke-direct {p1, v0, v4, p0}, Lbi3;-><init>(Lln6;Lp11;Li83;)V

    .line 200
    .line 201
    .line 202
    return-object p1

    .line 203
    :pswitch_4
    check-cast p1, Ls84;

    .line 204
    .line 205
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 206
    .line 207
    .line 208
    iget-object p1, p1, Ls84;->a:Lzd4;

    .line 209
    .line 210
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 211
    .line 212
    check-cast p0, Ls84;

    .line 213
    .line 214
    iget-object p0, p0, Ls84;->a:Lzd4;

    .line 215
    .line 216
    if-ne p1, p0, :cond_8

    .line 217
    .line 218
    move v3, v4

    .line 219
    :cond_8
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 220
    .line 221
    .line 222
    move-result-object p0

    .line 223
    return-object p0

    .line 224
    :pswitch_5
    check-cast p1, Lr84;

    .line 225
    .line 226
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 227
    .line 228
    .line 229
    iget-object p1, p1, Lr84;->a:Lzd4;

    .line 230
    .line 231
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast p0, Lr84;

    .line 234
    .line 235
    iget-object p0, p0, Lr84;->a:Lzd4;

    .line 236
    .line 237
    if-ne p1, p0, :cond_9

    .line 238
    .line 239
    move v3, v4

    .line 240
    :cond_9
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 241
    .line 242
    .line 243
    move-result-object p0

    .line 244
    return-object p0

    .line 245
    :pswitch_6
    check-cast p1, Lig3;

    .line 246
    .line 247
    iget-object p1, p1, Lig3;->a:Landroid/view/KeyEvent;

    .line 248
    .line 249
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 250
    .line 251
    .line 252
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 253
    .line 254
    .line 255
    move-result v0

    .line 256
    int-to-long v0, v0

    .line 257
    const/16 v2, 0x20

    .line 258
    .line 259
    shl-long/2addr v0, v2

    .line 260
    const-wide v5, 0x4200000000L

    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    invoke-static {v0, v1, v5, v6}, Lx53;->w(JJ)Z

    .line 266
    .line 267
    .line 268
    move-result v0

    .line 269
    if-nez v0, :cond_a

    .line 270
    .line 271
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 272
    .line 273
    .line 274
    move-result v0

    .line 275
    int-to-long v0, v0

    .line 276
    shl-long/2addr v0, v2

    .line 277
    const-wide v5, 0xa000000000L

    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    invoke-static {v0, v1, v5, v6}, Lx53;->w(JJ)Z

    .line 283
    .line 284
    .line 285
    move-result v0

    .line 286
    if-nez v0, :cond_a

    .line 287
    .line 288
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 289
    .line 290
    .line 291
    move-result v0

    .line 292
    int-to-long v0, v0

    .line 293
    shl-long/2addr v0, v2

    .line 294
    const-wide v5, 0x3e00000000L

    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    invoke-static {v0, v1, v5, v6}, Lx53;->w(JJ)Z

    .line 300
    .line 301
    .line 302
    move-result v0

    .line 303
    if-eqz v0, :cond_c

    .line 304
    .line 305
    :cond_a
    invoke-static {p1}, Ll63;->R(Landroid/view/KeyEvent;)I

    .line 306
    .line 307
    .line 308
    move-result p1

    .line 309
    if-ne p1, v4, :cond_b

    .line 310
    .line 311
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 312
    .line 313
    check-cast p0, Lwg2;

    .line 314
    .line 315
    invoke-interface {p0}, Lwg2;->a()Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    :cond_b
    move v3, v4

    .line 319
    :cond_c
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 320
    .line 321
    .line 322
    move-result-object p0

    .line 323
    return-object p0

    .line 324
    :pswitch_7
    check-cast p1, Lhj;

    .line 325
    .line 326
    iget v0, p1, Lhj;->b:F

    .line 327
    .line 328
    const/4 v1, 0x0

    .line 329
    cmpg-float v2, v0, v1

    .line 330
    .line 331
    if-gez v2, :cond_d

    .line 332
    .line 333
    move v0, v1

    .line 334
    :cond_d
    const/high16 v2, 0x3f800000    # 1.0f

    .line 335
    .line 336
    cmpl-float v3, v0, v2

    .line 337
    .line 338
    if-lez v3, :cond_e

    .line 339
    .line 340
    move v0, v2

    .line 341
    :cond_e
    iget v3, p1, Lhj;->c:F

    .line 342
    .line 343
    const/high16 v4, -0x41000000    # -0.5f

    .line 344
    .line 345
    cmpg-float v5, v3, v4

    .line 346
    .line 347
    if-gez v5, :cond_f

    .line 348
    .line 349
    move v3, v4

    .line 350
    :cond_f
    const/high16 v5, 0x3f000000    # 0.5f

    .line 351
    .line 352
    cmpl-float v6, v3, v5

    .line 353
    .line 354
    if-lez v6, :cond_10

    .line 355
    .line 356
    move v3, v5

    .line 357
    :cond_10
    iget v6, p1, Lhj;->d:F

    .line 358
    .line 359
    cmpg-float v7, v6, v4

    .line 360
    .line 361
    if-ltz v7, :cond_11

    .line 362
    .line 363
    move v4, v6

    .line 364
    :cond_11
    cmpl-float v6, v4, v5

    .line 365
    .line 366
    if-gtz v6, :cond_12

    .line 367
    .line 368
    move v5, v4

    .line 369
    :cond_12
    iget p1, p1, Lhj;->a:F

    .line 370
    .line 371
    cmpg-float v4, p1, v1

    .line 372
    .line 373
    if-ltz v4, :cond_13

    .line 374
    .line 375
    move v1, p1

    .line 376
    :cond_13
    cmpl-float p1, v1, v2

    .line 377
    .line 378
    if-gtz p1, :cond_14

    .line 379
    .line 380
    move v2, v1

    .line 381
    :cond_14
    sget-object p1, Lqy0;->x:Lsv4;

    .line 382
    .line 383
    invoke-static {v0, v3, v5, v2, p1}, Loo0;->g(FFFFLoy0;)J

    .line 384
    .line 385
    .line 386
    move-result-wide v0

    .line 387
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 388
    .line 389
    check-cast p0, Loy0;

    .line 390
    .line 391
    invoke-static {v0, v1, p0}, Ldy0;->a(JLoy0;)J

    .line 392
    .line 393
    .line 394
    move-result-wide p0

    .line 395
    new-instance v0, Ldy0;

    .line 396
    .line 397
    invoke-direct {v0, p0, p1}, Ldy0;-><init>(J)V

    .line 398
    .line 399
    .line 400
    return-object v0

    .line 401
    :pswitch_8
    check-cast p1, Ljava/lang/Throwable;

    .line 402
    .line 403
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 404
    .line 405
    check-cast p0, Lml0;

    .line 406
    .line 407
    invoke-interface {p0}, Lml0;->cancel()V

    .line 408
    .line 409
    .line 410
    return-object v2

    .line 411
    :pswitch_9
    check-cast p1, Ljb0;

    .line 412
    .line 413
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 414
    .line 415
    .line 416
    check-cast p1, Lza0;

    .line 417
    .line 418
    sget-object v0, Lug4;->h:Lug4;

    .line 419
    .line 420
    const-string v1, "top.yukonga.miuix.kmp.nav.swipeDismiss"

    .line 421
    .line 422
    invoke-static {v1, v0}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 423
    .line 424
    .line 425
    move-result-object v0

    .line 426
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 427
    .line 428
    .line 429
    new-instance v1, Lxf4;

    .line 430
    .line 431
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 432
    .line 433
    check-cast p0, Lq21;

    .line 434
    .line 435
    invoke-direct {v1, p1, p1, v0, p0}, Lxf4;-><init>(Ljb0;Ljava/lang/Object;Ljava/util/Map;Lmh2;)V

    .line 436
    .line 437
    .line 438
    return-object v1

    .line 439
    :pswitch_a
    check-cast p1, Lka5;

    .line 440
    .line 441
    iget-object p0, p0, Lvd;->i:Ljava/lang/Object;

    .line 442
    .line 443
    check-cast p0, Lla5;

    .line 444
    .line 445
    invoke-static {p1, p0, v3, v3}, Lka5;->k(Lka5;Lla5;II)V

    .line 446
    .line 447
    .line 448
    return-object v2

    .line 449
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
