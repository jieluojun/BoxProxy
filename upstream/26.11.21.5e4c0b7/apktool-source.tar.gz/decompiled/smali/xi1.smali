.class public final Lxi1;
.super Lr32;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final c:Landroid/view/ContextMenu;


# direct methods
.method public constructor <init>(Lox0;Landroid/view/ContextMenu;Lmp0;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, Lr32;-><init>(Lox0;)V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lxi1;->c:Landroid/view/ContextMenu;

    .line 8
    .line 9
    return-void
.end method
