.class public Lyw7;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lxw7;


# static fields
.field public static a:Lyw7;


# virtual methods
.method public a(Ljava/lang/Class;)Ltw7;
    .locals 0

    .line 1
    invoke-static {p1}, Lu53;->h(Ljava/lang/Class;)Ltw7;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public b(Ljava/lang/Class;Lpc4;)Ltw7;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lyw7;->a(Ljava/lang/Class;)Ltw7;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final c(Llt0;Lpc4;)Ltw7;
    .locals 0

    .line 1
    invoke-static {p1}, Lj53;->D(Llt0;)Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p0, p1, p2}, Lyw7;->b(Ljava/lang/Class;Lpc4;)Ltw7;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method
