.class public abstract Lo31;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lq21;

.field public static final b:Lq21;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    sget-object v0, Lcl0;->n:Lcl0;

    .line 2
    .line 3
    new-instance v1, Lq21;

    .line 4
    .line 5
    const v2, 0x3b9ababf

    .line 6
    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    invoke-direct {v1, v2, v3, v0}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    sput-object v1, Lo31;->a:Lq21;

    .line 13
    .line 14
    sget-object v0, Lcl0;->m:Lcl0;

    .line 15
    .line 16
    new-instance v1, Lq21;

    .line 17
    .line 18
    const v2, 0x187516bb

    .line 19
    .line 20
    .line 21
    invoke-direct {v1, v2, v3, v0}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    sput-object v1, Lo31;->b:Lq21;

    .line 25
    .line 26
    return-void
.end method
