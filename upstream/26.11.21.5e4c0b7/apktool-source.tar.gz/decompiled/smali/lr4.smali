.class public final synthetic Llr4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Z

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Z

.field public final synthetic n:Lth2;

.field public final synthetic o:Lth2;

.field public final synthetic p:Z

.field public final synthetic q:Ljava/lang/Object;

.field public final synthetic r:Ljava/lang/Object;

.field public final synthetic s:Ljava/lang/Object;

.field public final synthetic t:Ljava/lang/Object;

.field public final synthetic u:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;

.field public final synthetic w:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/CharSequence;Lq21;Lnc7;Lq21;Llh2;Llh2;Llh2;Lq21;ZZZLia3;Lu35;Lbb7;Lq21;I)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Llr4;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Llr4;->l:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Llr4;->q:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Llr4;->r:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Llr4;->j:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Llr4;->k:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Llr4;->n:Lth2;

    .line 18
    .line 19
    iput-object p7, p0, Llr4;->o:Lth2;

    .line 20
    .line 21
    iput-object p8, p0, Llr4;->s:Ljava/lang/Object;

    .line 22
    .line 23
    iput-boolean p9, p0, Llr4;->i:Z

    .line 24
    .line 25
    iput-boolean p10, p0, Llr4;->m:Z

    .line 26
    .line 27
    iput-boolean p11, p0, Llr4;->p:Z

    .line 28
    .line 29
    iput-object p12, p0, Llr4;->t:Ljava/lang/Object;

    .line 30
    .line 31
    iput-object p13, p0, Llr4;->u:Ljava/lang/Object;

    .line 32
    .line 33
    iput-object p14, p0, Llr4;->v:Ljava/lang/Object;

    .line 34
    .line 35
    move-object/from16 p1, p15

    .line 36
    .line 37
    iput-object p1, p0, Llr4;->w:Ljava/lang/Object;

    .line 38
    .line 39
    return-void
.end method

.method public synthetic constructor <init>(ZLtm3;ZLtm3;Ltm3;Lwh3;Ld52;Lwg2;Lzd4;Lqk4;ZLwg2;Lc75;Lzd4;Lzb3;)V
    .locals 1

    .line 41
    const/4 v0, 0x0

    iput-byte v0, p0, Llr4;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Llr4;->i:Z

    iput-object p2, p0, Llr4;->l:Ljava/lang/Object;

    iput-boolean p3, p0, Llr4;->m:Z

    iput-object p4, p0, Llr4;->q:Ljava/lang/Object;

    iput-object p5, p0, Llr4;->r:Ljava/lang/Object;

    iput-object p6, p0, Llr4;->j:Ljava/lang/Object;

    iput-object p7, p0, Llr4;->k:Ljava/lang/Object;

    iput-object p8, p0, Llr4;->n:Lth2;

    iput-object p9, p0, Llr4;->s:Ljava/lang/Object;

    iput-object p10, p0, Llr4;->u:Ljava/lang/Object;

    iput-boolean p11, p0, Llr4;->p:Z

    iput-object p12, p0, Llr4;->o:Lth2;

    iput-object p13, p0, Llr4;->v:Ljava/lang/Object;

    iput-object p14, p0, Llr4;->t:Ljava/lang/Object;

    move-object/from16 p1, p15

    iput-object p1, p0, Llr4;->w:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ZLwh3;Ld52;Ltm3;ZLwg2;Lq21;Lo21;Lwg2;Lwg2;Lwg2;ZLt66;Ll66;Ljava/util/List;)V
    .locals 1

    .line 40
    const/4 v0, 0x1

    iput-byte v0, p0, Llr4;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Llr4;->i:Z

    iput-object p2, p0, Llr4;->j:Ljava/lang/Object;

    iput-object p3, p0, Llr4;->k:Ljava/lang/Object;

    iput-object p4, p0, Llr4;->l:Ljava/lang/Object;

    iput-boolean p5, p0, Llr4;->m:Z

    iput-object p6, p0, Llr4;->n:Lth2;

    iput-object p7, p0, Llr4;->q:Ljava/lang/Object;

    iput-object p8, p0, Llr4;->r:Ljava/lang/Object;

    iput-object p9, p0, Llr4;->o:Lth2;

    iput-object p10, p0, Llr4;->s:Ljava/lang/Object;

    iput-object p11, p0, Llr4;->t:Ljava/lang/Object;

    iput-boolean p12, p0, Llr4;->p:Z

    iput-object p13, p0, Llr4;->u:Ljava/lang/Object;

    iput-object p14, p0, Llr4;->v:Ljava/lang/Object;

    move-object/from16 p1, p15

    iput-object p1, p0, Llr4;->w:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 47

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Llr4;->h:B

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    sget-object v5, Los7;->a:Los7;

    .line 7
    .line 8
    iget-object v6, v0, Llr4;->w:Ljava/lang/Object;

    .line 9
    .line 10
    iget-object v7, v0, Llr4;->v:Ljava/lang/Object;

    .line 11
    .line 12
    iget-object v8, v0, Llr4;->u:Ljava/lang/Object;

    .line 13
    .line 14
    iget-object v9, v0, Llr4;->t:Ljava/lang/Object;

    .line 15
    .line 16
    iget-object v10, v0, Llr4;->s:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object v11, v0, Llr4;->o:Lth2;

    .line 19
    .line 20
    iget-object v12, v0, Llr4;->n:Lth2;

    .line 21
    .line 22
    iget-object v13, v0, Llr4;->k:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v14, v0, Llr4;->j:Ljava/lang/Object;

    .line 25
    .line 26
    iget-object v15, v0, Llr4;->r:Ljava/lang/Object;

    .line 27
    .line 28
    const/16 v16, 0x1

    .line 29
    .line 30
    iget-object v3, v0, Llr4;->q:Ljava/lang/Object;

    .line 31
    .line 32
    iget-object v4, v0, Llr4;->l:Ljava/lang/Object;

    .line 33
    .line 34
    packed-switch v1, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    move-object/from16 v18, v4

    .line 38
    .line 39
    check-cast v18, Ljava/lang/CharSequence;

    .line 40
    .line 41
    move-object/from16 v19, v3

    .line 42
    .line 43
    check-cast v19, Lq21;

    .line 44
    .line 45
    move-object/from16 v20, v15

    .line 46
    .line 47
    check-cast v20, Lnc7;

    .line 48
    .line 49
    move-object/from16 v21, v14

    .line 50
    .line 51
    check-cast v21, Lq21;

    .line 52
    .line 53
    move-object/from16 v22, v13

    .line 54
    .line 55
    check-cast v22, Llh2;

    .line 56
    .line 57
    move-object/from16 v23, v12

    .line 58
    .line 59
    check-cast v23, Llh2;

    .line 60
    .line 61
    move-object/from16 v24, v11

    .line 62
    .line 63
    check-cast v24, Llh2;

    .line 64
    .line 65
    move-object/from16 v25, v10

    .line 66
    .line 67
    check-cast v25, Lq21;

    .line 68
    .line 69
    move-object/from16 v29, v9

    .line 70
    .line 71
    check-cast v29, Lia3;

    .line 72
    .line 73
    move-object/from16 v30, v8

    .line 74
    .line 75
    check-cast v30, Lu35;

    .line 76
    .line 77
    move-object/from16 v31, v7

    .line 78
    .line 79
    check-cast v31, Lbb7;

    .line 80
    .line 81
    move-object/from16 v32, v6

    .line 82
    .line 83
    check-cast v32, Lq21;

    .line 84
    .line 85
    move-object/from16 v33, p1

    .line 86
    .line 87
    check-cast v33, Lki2;

    .line 88
    .line 89
    move-object/from16 v1, p2

    .line 90
    .line 91
    check-cast v1, Ljava/lang/Integer;

    .line 92
    .line 93
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    .line 95
    .line 96
    const/16 v1, 0x31

    .line 97
    .line 98
    invoke-static {v1}, Ld43;->P(I)I

    .line 99
    .line 100
    .line 101
    move-result v34

    .line 102
    iget-boolean v1, v0, Llr4;->i:Z

    .line 103
    .line 104
    iget-boolean v2, v0, Llr4;->m:Z

    .line 105
    .line 106
    iget-boolean v0, v0, Llr4;->p:Z

    .line 107
    .line 108
    move/from16 v28, v0

    .line 109
    .line 110
    move/from16 v26, v1

    .line 111
    .line 112
    move/from16 v27, v2

    .line 113
    .line 114
    invoke-static/range {v18 .. v34}, Lzi6;->a(Ljava/lang/CharSequence;Lq21;Lnc7;Lq21;Llh2;Llh2;Llh2;Lq21;ZZZLia3;Lu35;Lbb7;Lq21;Lki2;I)V

    .line 115
    .line 116
    .line 117
    return-object v5

    .line 118
    :pswitch_0
    move-object/from16 v35, v14

    .line 119
    .line 120
    check-cast v35, Lwh3;

    .line 121
    .line 122
    move-object/from16 v20, v13

    .line 123
    .line 124
    check-cast v20, Ld52;

    .line 125
    .line 126
    move-object/from16 v19, v4

    .line 127
    .line 128
    check-cast v19, Ltm3;

    .line 129
    .line 130
    move-object/from16 v22, v12

    .line 131
    .line 132
    check-cast v22, Lwg2;

    .line 133
    .line 134
    move-object/from16 v23, v3

    .line 135
    .line 136
    check-cast v23, Lq21;

    .line 137
    .line 138
    move-object/from16 v24, v15

    .line 139
    .line 140
    check-cast v24, Lo21;

    .line 141
    .line 142
    move-object/from16 v25, v11

    .line 143
    .line 144
    check-cast v25, Lwg2;

    .line 145
    .line 146
    move-object/from16 v26, v10

    .line 147
    .line 148
    check-cast v26, Lwg2;

    .line 149
    .line 150
    move-object/from16 v27, v9

    .line 151
    .line 152
    check-cast v27, Lwg2;

    .line 153
    .line 154
    move-object/from16 v29, v8

    .line 155
    .line 156
    check-cast v29, Lt66;

    .line 157
    .line 158
    move-object/from16 v30, v7

    .line 159
    .line 160
    check-cast v30, Ll66;

    .line 161
    .line 162
    move-object/from16 v31, v6

    .line 163
    .line 164
    check-cast v31, Ljava/util/List;

    .line 165
    .line 166
    move-object/from16 v1, p1

    .line 167
    .line 168
    check-cast v1, Lki2;

    .line 169
    .line 170
    move-object/from16 v3, p2

    .line 171
    .line 172
    check-cast v3, Ljava/lang/Integer;

    .line 173
    .line 174
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 175
    .line 176
    .line 177
    move-result v3

    .line 178
    and-int/lit8 v4, v3, 0x3

    .line 179
    .line 180
    if-eq v4, v2, :cond_0

    .line 181
    .line 182
    move/from16 v2, v16

    .line 183
    .line 184
    goto :goto_0

    .line 185
    :cond_0
    const/4 v2, 0x0

    .line 186
    :goto_0
    and-int/lit8 v3, v3, 0x1

    .line 187
    .line 188
    invoke-virtual {v1, v3, v2}, Lki2;->Y(IZ)Z

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    if-eqz v2, :cond_2

    .line 193
    .line 194
    iget-boolean v2, v0, Llr4;->i:Z

    .line 195
    .line 196
    if-nez v2, :cond_1

    .line 197
    .line 198
    const v2, 0x1b411189

    .line 199
    .line 200
    .line 201
    invoke-virtual {v1, v2}, Lki2;->h0(I)V

    .line 202
    .line 203
    .line 204
    new-instance v18, Lb66;

    .line 205
    .line 206
    iget-boolean v2, v0, Llr4;->m:Z

    .line 207
    .line 208
    iget-boolean v0, v0, Llr4;->p:Z

    .line 209
    .line 210
    move/from16 v28, v0

    .line 211
    .line 212
    move/from16 v21, v2

    .line 213
    .line 214
    invoke-direct/range {v18 .. v31}, Lb66;-><init>(Ltm3;Ld52;ZLwg2;Lq21;Lo21;Lwg2;Lwg2;Lwg2;ZLt66;Ll66;Ljava/util/List;)V

    .line 215
    .line 216
    .line 217
    move-object/from16 v0, v18

    .line 218
    .line 219
    const v2, -0x21d751d2

    .line 220
    .line 221
    .line 222
    invoke-static {v2, v0, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 223
    .line 224
    .line 225
    move-result-object v43

    .line 226
    const/high16 v45, 0xc00000

    .line 227
    .line 228
    const/16 v46, 0x3c

    .line 229
    .line 230
    const/16 v37, 0x0

    .line 231
    .line 232
    const/16 v38, 0x0

    .line 233
    .line 234
    const/16 v39, 0x0

    .line 235
    .line 236
    const-wide/16 v40, 0x0

    .line 237
    .line 238
    move-object/from16 v44, v1

    .line 239
    .line 240
    move-object/from16 v42, v19

    .line 241
    .line 242
    move-object/from16 v36, v20

    .line 243
    .line 244
    invoke-static/range {v35 .. v46}, Lr94;->j(Lg00;Ld52;Lha4;ZLwg2;JLtm3;Lq21;Lki2;II)V

    .line 245
    .line 246
    .line 247
    move-object/from16 v0, v44

    .line 248
    .line 249
    const/4 v1, 0x0

    .line 250
    invoke-virtual {v0, v1}, Lki2;->r(Z)V

    .line 251
    .line 252
    .line 253
    goto :goto_1

    .line 254
    :cond_1
    move-object v0, v1

    .line 255
    const/4 v1, 0x0

    .line 256
    const v2, 0x4d2bce3e    # 1.80151264E8f

    .line 257
    .line 258
    .line 259
    invoke-virtual {v0, v2}, Lki2;->h0(I)V

    .line 260
    .line 261
    .line 262
    invoke-virtual {v0, v1}, Lki2;->r(Z)V

    .line 263
    .line 264
    .line 265
    goto :goto_1

    .line 266
    :cond_2
    move-object v0, v1

    .line 267
    invoke-virtual {v0}, Lki2;->b0()V

    .line 268
    .line 269
    .line 270
    :goto_1
    return-object v5

    .line 271
    :pswitch_1
    const/4 v1, 0x0

    .line 272
    check-cast v4, Ltm3;

    .line 273
    .line 274
    check-cast v3, Ltm3;

    .line 275
    .line 276
    check-cast v15, Ltm3;

    .line 277
    .line 278
    move-object/from16 v21, v14

    .line 279
    .line 280
    check-cast v21, Lwh3;

    .line 281
    .line 282
    move-object/from16 v18, v13

    .line 283
    .line 284
    check-cast v18, Ld52;

    .line 285
    .line 286
    move-object v13, v12

    .line 287
    check-cast v13, Lwg2;

    .line 288
    .line 289
    move-object v14, v10

    .line 290
    check-cast v14, Lzd4;

    .line 291
    .line 292
    check-cast v8, Lqk4;

    .line 293
    .line 294
    move-object/from16 v17, v11

    .line 295
    .line 296
    check-cast v17, Lwg2;

    .line 297
    .line 298
    check-cast v7, Lc75;

    .line 299
    .line 300
    move-object/from16 v19, v9

    .line 301
    .line 302
    check-cast v19, Lzd4;

    .line 303
    .line 304
    move-object/from16 v20, v6

    .line 305
    .line 306
    check-cast v20, Lzb3;

    .line 307
    .line 308
    move-object/from16 v6, p1

    .line 309
    .line 310
    check-cast v6, Lki2;

    .line 311
    .line 312
    move-object/from16 v9, p2

    .line 313
    .line 314
    check-cast v9, Ljava/lang/Integer;

    .line 315
    .line 316
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 317
    .line 318
    .line 319
    move-result v9

    .line 320
    and-int/lit8 v10, v9, 0x3

    .line 321
    .line 322
    if-eq v10, v2, :cond_3

    .line 323
    .line 324
    move/from16 v1, v16

    .line 325
    .line 326
    :cond_3
    and-int/lit8 v9, v9, 0x1

    .line 327
    .line 328
    invoke-virtual {v6, v9, v1}, Lki2;->Y(IZ)Z

    .line 329
    .line 330
    .line 331
    move-result v1

    .line 332
    if-eqz v1, :cond_6

    .line 333
    .line 334
    move-object/from16 v12, v18

    .line 335
    .line 336
    move-object/from16 v18, v7

    .line 337
    .line 338
    iget-boolean v7, v0, Llr4;->i:Z

    .line 339
    .line 340
    iget-boolean v9, v0, Llr4;->m:Z

    .line 341
    .line 342
    if-eqz v7, :cond_4

    .line 343
    .line 344
    move-object/from16 v24, v4

    .line 345
    .line 346
    :goto_2
    move-object/from16 v26, v6

    .line 347
    .line 348
    goto :goto_3

    .line 349
    :cond_4
    if-eqz v9, :cond_5

    .line 350
    .line 351
    move-object/from16 v24, v3

    .line 352
    .line 353
    goto :goto_2

    .line 354
    :cond_5
    move-object/from16 v26, v6

    .line 355
    .line 356
    move-object/from16 v24, v15

    .line 357
    .line 358
    :goto_3
    new-instance v6, Lcr4;

    .line 359
    .line 360
    iget-boolean v0, v0, Llr4;->p:Z

    .line 361
    .line 362
    move/from16 v16, v0

    .line 363
    .line 364
    move-object v10, v3

    .line 365
    move-object v11, v15

    .line 366
    move-object/from16 v0, v26

    .line 367
    .line 368
    move-object v15, v8

    .line 369
    move-object v8, v4

    .line 370
    invoke-direct/range {v6 .. v20}, Lcr4;-><init>(ZLtm3;ZLtm3;Ltm3;Ld52;Lwg2;Lzd4;Lqk4;ZLwg2;Lc75;Lzd4;Lzb3;)V

    .line 371
    .line 372
    .line 373
    const v1, -0x4c793e2f

    .line 374
    .line 375
    .line 376
    invoke-static {v1, v6, v0}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 377
    .line 378
    .line 379
    move-result-object v25

    .line 380
    const/high16 v27, 0xc00000

    .line 381
    .line 382
    const/16 v28, 0x3c

    .line 383
    .line 384
    const/16 v19, 0x0

    .line 385
    .line 386
    const/16 v20, 0x0

    .line 387
    .line 388
    move-object/from16 v17, v21

    .line 389
    .line 390
    const/16 v21, 0x0

    .line 391
    .line 392
    const-wide/16 v22, 0x0

    .line 393
    .line 394
    move-object/from16 v18, v12

    .line 395
    .line 396
    invoke-static/range {v17 .. v28}, Lr94;->j(Lg00;Ld52;Lha4;ZLwg2;JLtm3;Lq21;Lki2;II)V

    .line 397
    .line 398
    .line 399
    goto :goto_4

    .line 400
    :cond_6
    move-object/from16 v26, v6

    .line 401
    .line 402
    invoke-virtual/range {v26 .. v26}, Lki2;->b0()V

    .line 403
    .line 404
    .line 405
    :goto_4
    return-object v5

    .line 406
    nop

    .line 407
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
