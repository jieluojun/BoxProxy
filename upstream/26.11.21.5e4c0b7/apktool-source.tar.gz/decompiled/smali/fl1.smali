.class public final Lfl1;
.super Lf57;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic l:B

.field public synthetic m:Ljava/lang/Object;

.field public final synthetic n:F

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;FLfd1;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lfl1;->l:B

    .line 2
    .line 3
    iput-object p1, p0, Lfl1;->o:Ljava/lang/Object;

    .line 4
    .line 5
    iput p2, p0, Lfl1;->n:F

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, Lf57;-><init>(ILfd1;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lfl1;->l:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lwf6;

    .line 9
    .line 10
    check-cast p2, Lfd1;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lfl1;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lfl1;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lfl1;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    check-cast p1, Lri1;

    .line 23
    .line 24
    check-cast p2, Lfd1;

    .line 25
    .line 26
    invoke-virtual {p0, p2, p1}, Lfl1;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Lfl1;

    .line 31
    .line 32
    invoke-virtual {p0, v1}, Lfl1;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    return-object v1

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final s(Lfd1;Ljava/lang/Object;)Lfd1;
    .locals 3

    .line 1
    iget-byte v0, p0, Lfl1;->l:B

    .line 2
    .line 3
    iget v1, p0, Lfl1;->n:F

    .line 4
    .line 5
    iget-object p0, p0, Lfl1;->o:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    new-instance v0, Lfl1;

    .line 11
    .line 12
    check-cast p0, Lxu5;

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    invoke-direct {v0, p0, v1, p1, v2}, Lfl1;-><init>(Ljava/lang/Object;FLfd1;B)V

    .line 16
    .line 17
    .line 18
    iput-object p2, v0, Lfl1;->m:Ljava/lang/Object;

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_0
    new-instance v0, Lfl1;

    .line 22
    .line 23
    check-cast p0, Lgl1;

    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    invoke-direct {v0, p0, v1, p1, v2}, Lfl1;-><init>(Ljava/lang/Object;FLfd1;B)V

    .line 27
    .line 28
    .line 29
    iput-object p2, v0, Lfl1;->m:Ljava/lang/Object;

    .line 30
    .line 31
    return-object v0

    .line 32
    nop

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lfl1;->l:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    iget v2, p0, Lfl1;->n:F

    .line 6
    .line 7
    iget-object v3, p0, Lfl1;->o:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object p0, p0, Lfl1;->m:Ljava/lang/Object;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    check-cast p0, Lwf6;

    .line 15
    .line 16
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    check-cast v3, Lxu5;

    .line 20
    .line 21
    invoke-interface {p0, v2}, Lwf6;->a(F)F

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    iput p0, v3, Lxu5;->h:F

    .line 26
    .line 27
    return-object v1

    .line 28
    :pswitch_0
    check-cast p0, Lri1;

    .line 29
    .line 30
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    new-instance p1, Lvk1;

    .line 34
    .line 35
    check-cast v3, Lgl1;

    .line 36
    .line 37
    const/4 v0, 0x1

    .line 38
    const/4 v4, 0x0

    .line 39
    invoke-direct {p1, v3, v2, v4, v0}, Lvk1;-><init>(Lgl1;FLfd1;B)V

    .line 40
    .line 41
    .line 42
    const/4 v0, 0x3

    .line 43
    invoke-static {p0, v4, v4, p1, v0}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 44
    .line 45
    .line 46
    return-object v1

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
