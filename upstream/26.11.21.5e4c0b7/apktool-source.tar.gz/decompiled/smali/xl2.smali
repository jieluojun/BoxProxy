.class public final synthetic Lxl2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lwg2;

.field public final synthetic j:F

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lwg2;Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p6, p0, Lxl2;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lxl2;->i:Lwg2;

    .line 4
    .line 5
    iput-object p2, p0, Lxl2;->k:Ljava/lang/Object;

    .line 6
    .line 7
    iput p3, p0, Lxl2;->j:F

    .line 8
    .line 9
    iput-object p4, p0, Lxl2;->l:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p5, p0, Lxl2;->m:Ljava/lang/Object;

    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lxl2;->h:B

    .line 4
    .line 5
    sget-object v2, Lx12;->h:Lx12;

    .line 6
    .line 7
    const-string v3, ") must be >= 0"

    .line 8
    .line 9
    const-string v4, ") and height("

    .line 10
    .line 11
    const-string v5, "width("

    .line 12
    .line 13
    const/4 v7, 0x0

    .line 14
    iget-object v8, v0, Lxl2;->m:Ljava/lang/Object;

    .line 15
    .line 16
    iget-object v9, v0, Lxl2;->l:Ljava/lang/Object;

    .line 17
    .line 18
    iget v10, v0, Lxl2;->j:F

    .line 19
    .line 20
    iget-object v11, v0, Lxl2;->k:Ljava/lang/Object;

    .line 21
    .line 22
    iget-object v0, v0, Lxl2;->i:Lwg2;

    .line 23
    .line 24
    packed-switch v1, :pswitch_data_0

    .line 25
    .line 26
    .line 27
    check-cast v11, Lwg2;

    .line 28
    .line 29
    check-cast v9, Lti4;

    .line 30
    .line 31
    check-cast v8, Lwg2;

    .line 32
    .line 33
    move-object/from16 v1, p1

    .line 34
    .line 35
    check-cast v1, Lh14;

    .line 36
    .line 37
    move-object/from16 v14, p2

    .line 38
    .line 39
    check-cast v14, Ly04;

    .line 40
    .line 41
    move-object/from16 v15, p3

    .line 42
    .line 43
    check-cast v15, Lra1;

    .line 44
    .line 45
    const/high16 v16, 0x3f800000    # 1.0f

    .line 46
    .line 47
    sget v6, Lpm2;->m:F

    .line 48
    .line 49
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    invoke-interface {v0}, Lwg2;->a()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, Ljava/lang/Number;

    .line 60
    .line 61
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    cmpg-float v17, v0, v7

    .line 66
    .line 67
    if-gez v17, :cond_0

    .line 68
    .line 69
    move v0, v7

    .line 70
    :cond_0
    cmpl-float v17, v0, v16

    .line 71
    .line 72
    if-lez v17, :cond_1

    .line 73
    .line 74
    move/from16 v0, v16

    .line 75
    .line 76
    :cond_1
    invoke-interface {v11}, Lwg2;->a()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v11

    .line 80
    check-cast v11, Ljava/lang/Number;

    .line 81
    .line 82
    invoke-virtual {v11}, Ljava/lang/Number;->floatValue()F

    .line 83
    .line 84
    .line 85
    move-result v11

    .line 86
    cmpg-float v16, v0, v16

    .line 87
    .line 88
    if-nez v16, :cond_3

    .line 89
    .line 90
    invoke-interface {v1, v10}, Lso1;->s0(F)I

    .line 91
    .line 92
    .line 93
    move-result v8

    .line 94
    if-gez v8, :cond_2

    .line 95
    .line 96
    const/4 v8, 0x0

    .line 97
    :cond_2
    invoke-interface {v1, v6}, Lso1;->L(F)F

    .line 98
    .line 99
    .line 100
    move-result v6

    .line 101
    move/from16 v17, v7

    .line 102
    .line 103
    const/16 p0, 0x1

    .line 104
    .line 105
    goto :goto_0

    .line 106
    :cond_3
    const/16 p0, 0x1

    .line 107
    .line 108
    iget-object v12, v9, Lti4;->h:Lug;

    .line 109
    .line 110
    invoke-virtual {v12}, Lug;->e()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v12

    .line 114
    check-cast v12, Ljava/lang/Number;

    .line 115
    .line 116
    invoke-virtual {v12}, Ljava/lang/Number;->floatValue()F

    .line 117
    .line 118
    .line 119
    move-result v12

    .line 120
    move/from16 v17, v7

    .line 121
    .line 122
    iget-object v7, v9, Lti4;->i:Lug;

    .line 123
    .line 124
    invoke-virtual {v7}, Lug;->e()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v7

    .line 128
    check-cast v7, Ljava/lang/Number;

    .line 129
    .line 130
    invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F

    .line 131
    .line 132
    .line 133
    move-result v7

    .line 134
    iget-object v13, v9, Lti4;->g:[F

    .line 135
    .line 136
    move-object/from16 v18, v8

    .line 137
    .line 138
    array-length v8, v13

    .line 139
    if-eqz v8, :cond_8

    .line 140
    .line 141
    array-length v8, v13

    .line 142
    add-int/lit8 v8, v8, -0x1

    .line 143
    .line 144
    aget v8, v13, v8

    .line 145
    .line 146
    iget v13, v9, Lti4;->b:F

    .line 147
    .line 148
    add-float/2addr v8, v13

    .line 149
    iget v9, v9, Lti4;->a:F

    .line 150
    .line 151
    invoke-static {v12, v7, v8, v9, v13}, Lx43;->I(FFFFF)J

    .line 152
    .line 153
    .line 154
    move-result-wide v7

    .line 155
    const-wide v12, 0xffffffffL

    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    and-long/2addr v12, v7

    .line 161
    long-to-int v9, v12

    .line 162
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 163
    .line 164
    .line 165
    move-result v9

    .line 166
    const/16 v12, 0x20

    .line 167
    .line 168
    shr-long/2addr v7, v12

    .line 169
    long-to-int v7, v7

    .line 170
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 171
    .line 172
    .line 173
    move-result v8

    .line 174
    sub-float/2addr v9, v8

    .line 175
    invoke-interface {v1, v10}, Lso1;->L(F)F

    .line 176
    .line 177
    .line 178
    move-result v8

    .line 179
    invoke-static {v9, v8, v0}, Lug6;->H(FFF)F

    .line 180
    .line 181
    .line 182
    move-result v8

    .line 183
    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    .line 184
    .line 185
    .line 186
    move-result v8

    .line 187
    if-gez v8, :cond_4

    .line 188
    .line 189
    const/4 v8, 0x0

    .line 190
    :cond_4
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 191
    .line 192
    .line 193
    move-result v7

    .line 194
    invoke-interface {v1, v6}, Lso1;->L(F)F

    .line 195
    .line 196
    .line 197
    move-result v6

    .line 198
    invoke-static {v7, v6, v0}, Lug6;->H(FFF)F

    .line 199
    .line 200
    .line 201
    move-result v6

    .line 202
    sget v7, Lpm2;->s:F

    .line 203
    .line 204
    invoke-interface {v1, v7}, Lso1;->L(F)F

    .line 205
    .line 206
    .line 207
    move-result v7

    .line 208
    invoke-interface/range {v18 .. v18}, Lwg2;->a()Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v9

    .line 212
    check-cast v9, Ljava/lang/Number;

    .line 213
    .line 214
    invoke-virtual {v9}, Ljava/lang/Number;->floatValue()F

    .line 215
    .line 216
    .line 217
    move-result v9

    .line 218
    add-float/2addr v9, v7

    .line 219
    invoke-static {v9, v11, v0}, Lug6;->H(FFF)F

    .line 220
    .line 221
    .line 222
    move-result v11

    .line 223
    :goto_0
    sget v7, Lpm2;->n:F

    .line 224
    .line 225
    sget v9, Lpm2;->o:F

    .line 226
    .line 227
    mul-float/2addr v9, v0

    .line 228
    add-float v9, v9, v17

    .line 229
    .line 230
    add-float/2addr v9, v7

    .line 231
    add-float v9, v9, v17

    .line 232
    .line 233
    invoke-interface {v1, v9}, Lso1;->s0(F)I

    .line 234
    .line 235
    .line 236
    move-result v0

    .line 237
    if-ltz v8, :cond_5

    .line 238
    .line 239
    move/from16 v7, p0

    .line 240
    .line 241
    goto :goto_1

    .line 242
    :cond_5
    const/4 v7, 0x0

    .line 243
    :goto_1
    if-ltz v0, :cond_6

    .line 244
    .line 245
    move/from16 v12, p0

    .line 246
    .line 247
    goto :goto_2

    .line 248
    :cond_6
    const/4 v12, 0x0

    .line 249
    :goto_2
    and-int/2addr v7, v12

    .line 250
    if-nez v7, :cond_7

    .line 251
    .line 252
    new-instance v7, Ljava/lang/StringBuilder;

    .line 253
    .line 254
    invoke-direct {v7, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 258
    .line 259
    .line 260
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 261
    .line 262
    .line 263
    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 264
    .line 265
    .line 266
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 267
    .line 268
    .line 269
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 270
    .line 271
    .line 272
    move-result-object v3

    .line 273
    invoke-static {v3}, Lo73;->a(Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    :cond_7
    invoke-static {v8, v8, v0, v0}, Lsa1;->h(IIII)J

    .line 277
    .line 278
    .line 279
    move-result-wide v3

    .line 280
    invoke-interface {v14, v3, v4}, Ly04;->e(J)Lla5;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    iget-wide v3, v15, Lra1;->a:J

    .line 285
    .line 286
    invoke-static {v3, v4}, Lra1;->i(J)I

    .line 287
    .line 288
    .line 289
    move-result v3

    .line 290
    iget-wide v4, v15, Lra1;->a:J

    .line 291
    .line 292
    invoke-static {v4, v5}, Lra1;->h(J)I

    .line 293
    .line 294
    .line 295
    move-result v4

    .line 296
    new-instance v5, Lhm2;

    .line 297
    .line 298
    const/4 v7, 0x0

    .line 299
    invoke-direct {v5, v0, v6, v11, v7}, Lhm2;-><init>(Ljava/lang/Object;FFB)V

    .line 300
    .line 301
    .line 302
    invoke-interface {v1, v3, v4, v2, v5}, Lh14;->P0(IILjava/util/Map;Lhh2;)Le14;

    .line 303
    .line 304
    .line 305
    move-result-object v0

    .line 306
    goto :goto_3

    .line 307
    :cond_8
    const-string v0, "Array is empty."

    .line 308
    .line 309
    invoke-static {v0}, Lqs5;->o(Ljava/lang/String;)V

    .line 310
    .line 311
    .line 312
    const/4 v0, 0x0

    .line 313
    :goto_3
    return-object v0

    .line 314
    :pswitch_0
    move/from16 v17, v7

    .line 315
    .line 316
    const/16 p0, 0x1

    .line 317
    .line 318
    const/4 v7, 0x0

    .line 319
    const/high16 v16, 0x3f800000    # 1.0f

    .line 320
    .line 321
    check-cast v11, Lvg;

    .line 322
    .line 323
    check-cast v9, Lvg;

    .line 324
    .line 325
    check-cast v8, Lvg;

    .line 326
    .line 327
    move-object/from16 v1, p1

    .line 328
    .line 329
    check-cast v1, Lh14;

    .line 330
    .line 331
    move-object/from16 v6, p2

    .line 332
    .line 333
    check-cast v6, Ly04;

    .line 334
    .line 335
    move-object/from16 v12, p3

    .line 336
    .line 337
    check-cast v12, Lra1;

    .line 338
    .line 339
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 340
    .line 341
    .line 342
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 343
    .line 344
    .line 345
    invoke-interface {v0}, Lwg2;->a()Ljava/lang/Object;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    check-cast v0, Ljava/lang/Number;

    .line 350
    .line 351
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 352
    .line 353
    .line 354
    move-result v0

    .line 355
    cmpg-float v13, v0, v17

    .line 356
    .line 357
    if-gez v13, :cond_9

    .line 358
    .line 359
    move/from16 v0, v17

    .line 360
    .line 361
    :cond_9
    cmpl-float v13, v0, v16

    .line 362
    .line 363
    if-lez v13, :cond_a

    .line 364
    .line 365
    move/from16 v0, v16

    .line 366
    .line 367
    :cond_a
    invoke-virtual {v11}, Lvg;->getValue()Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v11

    .line 371
    check-cast v11, Ljava/lang/Number;

    .line 372
    .line 373
    invoke-virtual {v11}, Ljava/lang/Number;->floatValue()F

    .line 374
    .line 375
    .line 376
    move-result v11

    .line 377
    invoke-interface {v1, v10}, Lso1;->L(F)F

    .line 378
    .line 379
    .line 380
    move-result v10

    .line 381
    invoke-static {v11, v10, v0}, Lug6;->H(FFF)F

    .line 382
    .line 383
    .line 384
    move-result v10

    .line 385
    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    .line 386
    .line 387
    .line 388
    move-result v10

    .line 389
    if-gez v10, :cond_b

    .line 390
    .line 391
    move v10, v7

    .line 392
    :cond_b
    iget-wide v11, v12, Lra1;->a:J

    .line 393
    .line 394
    invoke-static {v11, v12}, Lra1;->h(J)I

    .line 395
    .line 396
    .line 397
    move-result v13

    .line 398
    if-ltz v10, :cond_c

    .line 399
    .line 400
    move/from16 v14, p0

    .line 401
    .line 402
    goto :goto_4

    .line 403
    :cond_c
    move v14, v7

    .line 404
    :goto_4
    if-ltz v13, :cond_d

    .line 405
    .line 406
    move/from16 v7, p0

    .line 407
    .line 408
    :cond_d
    and-int/2addr v14, v7

    .line 409
    if-nez v14, :cond_e

    .line 410
    .line 411
    new-instance v7, Ljava/lang/StringBuilder;

    .line 412
    .line 413
    invoke-direct {v7, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 414
    .line 415
    .line 416
    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 417
    .line 418
    .line 419
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 420
    .line 421
    .line 422
    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 423
    .line 424
    .line 425
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 426
    .line 427
    .line 428
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v3

    .line 432
    invoke-static {v3}, Lo73;->a(Ljava/lang/String;)V

    .line 433
    .line 434
    .line 435
    :cond_e
    invoke-static {v10, v10, v13, v13}, Lsa1;->h(IIII)J

    .line 436
    .line 437
    .line 438
    move-result-wide v3

    .line 439
    invoke-interface {v6, v3, v4}, Ly04;->e(J)Lla5;

    .line 440
    .line 441
    .line 442
    move-result-object v3

    .line 443
    invoke-virtual {v9}, Lvg;->getValue()Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v4

    .line 447
    check-cast v4, Ljava/lang/Number;

    .line 448
    .line 449
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 450
    .line 451
    .line 452
    move-result v4

    .line 453
    invoke-virtual {v8}, Lvg;->getValue()Ljava/lang/Object;

    .line 454
    .line 455
    .line 456
    move-result-object v5

    .line 457
    check-cast v5, Ljava/lang/Number;

    .line 458
    .line 459
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 460
    .line 461
    .line 462
    move-result v5

    .line 463
    sub-float/2addr v4, v5

    .line 464
    move/from16 v5, v17

    .line 465
    .line 466
    invoke-static {v4, v5, v0}, Lug6;->H(FFF)F

    .line 467
    .line 468
    .line 469
    move-result v0

    .line 470
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 471
    .line 472
    .line 473
    move-result v0

    .line 474
    invoke-static {v11, v12}, Lra1;->i(J)I

    .line 475
    .line 476
    .line 477
    move-result v4

    .line 478
    invoke-static {v11, v12}, Lra1;->h(J)I

    .line 479
    .line 480
    .line 481
    move-result v5

    .line 482
    new-instance v6, Lp5;

    .line 483
    .line 484
    const/4 v7, 0x4

    .line 485
    invoke-direct {v6, v3, v0, v7}, Lp5;-><init>(Lla5;IB)V

    .line 486
    .line 487
    .line 488
    invoke-interface {v1, v4, v5, v2, v6}, Lh14;->P0(IILjava/util/Map;Lhh2;)Le14;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    return-object v0

    .line 493
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
