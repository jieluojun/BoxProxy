.class public final synthetic Lb25;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:Lwg2;

.field public final synthetic i:Ldy0;

.field public final synthetic j:F

.field public final synthetic k:F

.field public final synthetic l:Lha4;

.field public final synthetic m:F

.field public final synthetic n:Lha4;

.field public final synthetic o:Lwg2;

.field public final synthetic p:Z

.field public final synthetic q:Lwg2;

.field public final synthetic r:Lwg2;

.field public final synthetic s:Lwg2;

.field public final synthetic t:Lhh2;


# direct methods
.method public synthetic constructor <init>(Lwg2;Ldy0;FFLha4;FLha4;Lwg2;ZLwg2;Lwg2;Lwg2;Lhh2;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb25;->h:Lwg2;

    .line 5
    .line 6
    iput-object p2, p0, Lb25;->i:Ldy0;

    .line 7
    .line 8
    iput p3, p0, Lb25;->j:F

    .line 9
    .line 10
    iput p4, p0, Lb25;->k:F

    .line 11
    .line 12
    iput-object p5, p0, Lb25;->l:Lha4;

    .line 13
    .line 14
    iput p6, p0, Lb25;->m:F

    .line 15
    .line 16
    iput-object p7, p0, Lb25;->n:Lha4;

    .line 17
    .line 18
    iput-object p8, p0, Lb25;->o:Lwg2;

    .line 19
    .line 20
    iput-boolean p9, p0, Lb25;->p:Z

    .line 21
    .line 22
    iput-object p10, p0, Lb25;->q:Lwg2;

    .line 23
    .line 24
    iput-object p11, p0, Lb25;->r:Lwg2;

    .line 25
    .line 26
    iput-object p12, p0, Lb25;->s:Lwg2;

    .line 27
    .line 28
    iput-object p13, p0, Lb25;->t:Lhh2;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v13, p1

    .line 4
    .line 5
    check-cast v13, Lki2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const v1, 0x301801b1

    .line 15
    .line 16
    .line 17
    invoke-static {v1}, Ld43;->P(I)I

    .line 18
    .line 19
    .line 20
    move-result v14

    .line 21
    iget-object v1, v0, Lb25;->h:Lwg2;

    .line 22
    .line 23
    move-object v2, v1

    .line 24
    iget-object v1, v0, Lb25;->i:Ldy0;

    .line 25
    .line 26
    move-object v3, v2

    .line 27
    iget v2, v0, Lb25;->j:F

    .line 28
    .line 29
    move-object v4, v3

    .line 30
    iget v3, v0, Lb25;->k:F

    .line 31
    .line 32
    move-object v5, v4

    .line 33
    iget-object v4, v0, Lb25;->l:Lha4;

    .line 34
    .line 35
    move-object v6, v5

    .line 36
    iget v5, v0, Lb25;->m:F

    .line 37
    .line 38
    move-object v7, v6

    .line 39
    iget-object v6, v0, Lb25;->n:Lha4;

    .line 40
    .line 41
    move-object v8, v7

    .line 42
    iget-object v7, v0, Lb25;->o:Lwg2;

    .line 43
    .line 44
    move-object v9, v8

    .line 45
    iget-boolean v8, v0, Lb25;->p:Z

    .line 46
    .line 47
    move-object v10, v9

    .line 48
    iget-object v9, v0, Lb25;->q:Lwg2;

    .line 49
    .line 50
    move-object v11, v10

    .line 51
    iget-object v10, v0, Lb25;->r:Lwg2;

    .line 52
    .line 53
    move-object v12, v11

    .line 54
    iget-object v11, v0, Lb25;->s:Lwg2;

    .line 55
    .line 56
    iget-object v0, v0, Lb25;->t:Lhh2;

    .line 57
    .line 58
    move-object v15, v12

    .line 59
    move-object v12, v0

    .line 60
    move-object v0, v15

    .line 61
    invoke-static/range {v0 .. v14}, Ll63;->o(Lwg2;Ldy0;FFLha4;FLha4;Lwg2;ZLwg2;Lwg2;Lwg2;Lhh2;Lki2;I)V

    .line 62
    .line 63
    .line 64
    sget-object v0, Los7;->a:Los7;

    .line 65
    .line 66
    return-object v0
.end method
