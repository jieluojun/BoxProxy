.class public final Lvr6;
.super Lpa4;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lpa4;"
    }
.end annotation


# instance fields
.field public final h:Lkn6;

.field public final i:Len6;


# direct methods
.method public constructor <init>(Lkn6;Len6;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvr6;->h:Lkn6;

    .line 5
    .line 6
    iput-object p2, p0, Lvr6;->i:Len6;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Lga4;
    .locals 2

    .line 1
    new-instance v0, Lwr6;

    .line 2
    .line 3
    invoke-direct {v0}, Lga4;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lvr6;->h:Lkn6;

    .line 7
    .line 8
    iput-object v1, v0, Lwr6;->v:Lkn6;

    .line 9
    .line 10
    iget-object p0, p0, Lvr6;->i:Len6;

    .line 11
    .line 12
    iput-object p0, v0, Lwr6;->w:Len6;

    .line 13
    .line 14
    return-object v0
.end method

.method public final b(Lga4;)V
    .locals 2

    .line 1
    check-cast p1, Lwr6;

    .line 2
    .line 3
    iget-object v0, p1, Lwr6;->v:Lkn6;

    .line 4
    .line 5
    iget-object v1, p0, Lvr6;->h:Lkn6;

    .line 6
    .line 7
    invoke-static {v0, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iget-object p0, p0, Lvr6;->i:Len6;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    iget-object v0, p1, Lwr6;->w:Len6;

    .line 16
    .line 17
    invoke-static {v0, p0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    iput-object v0, p1, Lwr6;->x:Ldw1;

    .line 25
    .line 26
    :cond_1
    iput-object v1, p1, Lwr6;->v:Lkn6;

    .line 27
    .line 28
    iput-object p0, p1, Lwr6;->w:Len6;

    .line 29
    .line 30
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lvr6;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, Lvr6;

    .line 8
    .line 9
    iget-object v0, p0, Lvr6;->h:Lkn6;

    .line 10
    .line 11
    iget-object v1, p1, Lvr6;->h:Lkn6;

    .line 12
    .line 13
    invoke-static {v0, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object p0, p0, Lvr6;->i:Len6;

    .line 20
    .line 21
    iget-object p1, p1, Lvr6;->i:Len6;

    .line 22
    .line 23
    invoke-virtual {p0, p1}, Len6;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    if-nez p0, :cond_1

    .line 28
    .line 29
    :cond_0
    const/4 p0, 0x0

    .line 30
    return p0

    .line 31
    :cond_1
    const/4 p0, 0x1

    .line 32
    return p0
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, Lvr6;->h:Lkn6;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object p0, p0, Lvr6;->i:Len6;

    .line 10
    .line 11
    invoke-virtual {p0}, Len6;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    add-int/2addr p0, v0

    .line 16
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "SimpleDropShadowElement(shape="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lvr6;->h:Lkn6;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", shadow="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object p0, p0, Lvr6;->i:Len6;

    .line 19
    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p0, ")"

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0
.end method
