.class public final synthetic Li97;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lk97;


# direct methods
.method public synthetic constructor <init>(Lk97;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Li97;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Li97;->i:Lk97;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Li97;->h:B

    .line 4
    .line 5
    iget-object v0, v0, Li97;->i:Lk97;

    .line 6
    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    move-object/from16 v1, p1

    .line 11
    .line 12
    check-cast v1, Ljava/lang/Boolean;

    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    iget-object v4, v0, Lk97;->M:Lj97;

    .line 19
    .line 20
    if-eqz v4, :cond_6

    .line 21
    .line 22
    iget-object v3, v0, Lk97;->I:Lhh2;

    .line 23
    .line 24
    if-eqz v3, :cond_0

    .line 25
    .line 26
    invoke-interface {v3, v4}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v3, v0, Lk97;->M:Lj97;

    .line 30
    .line 31
    if-eqz v3, :cond_1

    .line 32
    .line 33
    iput-boolean v1, v3, Lj97;->c:Z

    .line 34
    .line 35
    :cond_1
    invoke-static {v0}, Lck6;->m(Lbk6;)V

    .line 36
    .line 37
    .line 38
    invoke-static {v0}, Lu53;->s(Loi3;)V

    .line 39
    .line 40
    .line 41
    invoke-static {v0}, Loo0;->L(Lkv1;)V

    .line 42
    .line 43
    .line 44
    goto/16 :goto_3

    .line 45
    .line 46
    :pswitch_0
    move-object/from16 v2, p1

    .line 47
    .line 48
    check-cast v2, Lqj;

    .line 49
    .line 50
    iget-object v1, v0, Lk97;->M:Lj97;

    .line 51
    .line 52
    sget-object v10, Lw12;->h:Lw12;

    .line 53
    .line 54
    if-eqz v1, :cond_2

    .line 55
    .line 56
    iget-object v3, v1, Lj97;->b:Lqj;

    .line 57
    .line 58
    invoke-static {v2, v3}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    if-nez v3, :cond_3

    .line 63
    .line 64
    iput-object v2, v1, Lj97;->b:Lqj;

    .line 65
    .line 66
    iget-object v1, v1, Lj97;->d:Lxb4;

    .line 67
    .line 68
    if-eqz v1, :cond_3

    .line 69
    .line 70
    iget-object v3, v0, Lk97;->w:Lwg7;

    .line 71
    .line 72
    iget-object v4, v0, Lk97;->x:Lqe2;

    .line 73
    .line 74
    iget-object v5, v0, Lk97;->y:Lpt3;

    .line 75
    .line 76
    iget v6, v0, Lk97;->A:I

    .line 77
    .line 78
    iget-boolean v7, v0, Lk97;->B:Z

    .line 79
    .line 80
    iget v8, v0, Lk97;->C:I

    .line 81
    .line 82
    iget v9, v0, Lk97;->D:I

    .line 83
    .line 84
    invoke-virtual/range {v1 .. v10}, Lxb4;->g(Lqj;Lwg7;Lqe2;Lpt3;IZIILjava/util/List;)V

    .line 85
    .line 86
    .line 87
    goto :goto_0

    .line 88
    :cond_2
    new-instance v11, Lj97;

    .line 89
    .line 90
    iget-object v1, v0, Lk97;->v:Lqj;

    .line 91
    .line 92
    invoke-direct {v11, v1, v2}, Lj97;-><init>(Lqj;Lqj;)V

    .line 93
    .line 94
    .line 95
    new-instance v1, Lxb4;

    .line 96
    .line 97
    iget-object v3, v0, Lk97;->w:Lwg7;

    .line 98
    .line 99
    iget-object v4, v0, Lk97;->x:Lqe2;

    .line 100
    .line 101
    iget-object v5, v0, Lk97;->y:Lpt3;

    .line 102
    .line 103
    iget v6, v0, Lk97;->A:I

    .line 104
    .line 105
    iget-boolean v7, v0, Lk97;->B:Z

    .line 106
    .line 107
    iget v8, v0, Lk97;->C:I

    .line 108
    .line 109
    iget v9, v0, Lk97;->D:I

    .line 110
    .line 111
    invoke-direct/range {v1 .. v10}, Lxb4;-><init>(Lqj;Lwg7;Lqe2;Lpt3;IZIILjava/util/List;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v0}, Lk97;->H1()Lxb4;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    iget-object v2, v2, Lxb4;->k:Lso1;

    .line 119
    .line 120
    invoke-virtual {v1, v2}, Lxb4;->d(Lso1;)V

    .line 121
    .line 122
    .line 123
    iput-object v1, v11, Lj97;->d:Lxb4;

    .line 124
    .line 125
    iput-object v11, v0, Lk97;->M:Lj97;

    .line 126
    .line 127
    :cond_3
    :goto_0
    invoke-static {v0}, Lck6;->m(Lbk6;)V

    .line 128
    .line 129
    .line 130
    invoke-static {v0}, Lu53;->s(Loi3;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v0}, Loo0;->L(Lkv1;)V

    .line 134
    .line 135
    .line 136
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 137
    .line 138
    return-object v0

    .line 139
    :pswitch_1
    move-object/from16 v1, p1

    .line 140
    .line 141
    check-cast v1, Ljava/util/List;

    .line 142
    .line 143
    invoke-virtual {v0}, Lk97;->H1()Lxb4;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    iget-object v4, v4, Lxb4;->o:Lse7;

    .line 148
    .line 149
    if-eqz v4, :cond_5

    .line 150
    .line 151
    iget-object v5, v4, Lse7;->a:Lre7;

    .line 152
    .line 153
    new-instance v6, Lre7;

    .line 154
    .line 155
    iget-object v7, v5, Lre7;->a:Lqj;

    .line 156
    .line 157
    iget-object v8, v0, Lk97;->w:Lwg7;

    .line 158
    .line 159
    iget-object v0, v0, Lk97;->H:Lhy0;

    .line 160
    .line 161
    if-eqz v0, :cond_4

    .line 162
    .line 163
    invoke-interface {v0}, Lhy0;->a()J

    .line 164
    .line 165
    .line 166
    move-result-wide v9

    .line 167
    goto :goto_1

    .line 168
    :cond_4
    const/4 v0, 0x0

    .line 169
    sget-object v9, Lqy0;->u:Lcz5;

    .line 170
    .line 171
    invoke-static {v0, v0, v0, v0, v9}, Loo0;->g(FFFFLoy0;)J

    .line 172
    .line 173
    .line 174
    move-result-wide v9

    .line 175
    :goto_1
    const-wide/16 v18, 0x0

    .line 176
    .line 177
    const v20, 0xfffffe

    .line 178
    .line 179
    .line 180
    const-wide/16 v11, 0x0

    .line 181
    .line 182
    const/4 v13, 0x0

    .line 183
    const/4 v14, 0x0

    .line 184
    const-wide/16 v15, 0x0

    .line 185
    .line 186
    const/16 v17, 0x0

    .line 187
    .line 188
    invoke-static/range {v8 .. v20}, Lwg7;->e(Lwg7;JJLsf2;Lre2;JIJI)Lwg7;

    .line 189
    .line 190
    .line 191
    move-result-object v8

    .line 192
    iget-object v9, v5, Lre7;->c:Ljava/util/List;

    .line 193
    .line 194
    iget v10, v5, Lre7;->d:I

    .line 195
    .line 196
    iget-boolean v11, v5, Lre7;->e:Z

    .line 197
    .line 198
    iget v12, v5, Lre7;->f:I

    .line 199
    .line 200
    iget-object v13, v5, Lre7;->g:Lso1;

    .line 201
    .line 202
    iget-object v14, v5, Lre7;->h:Lgi3;

    .line 203
    .line 204
    iget-object v15, v5, Lre7;->i:Lqe2;

    .line 205
    .line 206
    iget-object v0, v5, Lre7;->j:Lpt3;

    .line 207
    .line 208
    iget-wide v2, v5, Lre7;->k:J

    .line 209
    .line 210
    move-object/from16 v16, v0

    .line 211
    .line 212
    move-wide/from16 v17, v2

    .line 213
    .line 214
    invoke-direct/range {v6 .. v18}, Lre7;-><init>(Lqj;Lwg7;Ljava/util/List;IZILso1;Lgi3;Lqe2;Lpt3;J)V

    .line 215
    .line 216
    .line 217
    iget-wide v2, v4, Lse7;->c:J

    .line 218
    .line 219
    new-instance v0, Lse7;

    .line 220
    .line 221
    iget-object v4, v4, Lse7;->b:Lvb4;

    .line 222
    .line 223
    invoke-direct {v0, v6, v4, v2, v3}, Lse7;-><init>(Lre7;Lvb4;J)V

    .line 224
    .line 225
    .line 226
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    goto :goto_2

    .line 230
    :cond_5
    const/4 v0, 0x0

    .line 231
    :goto_2
    if-eqz v0, :cond_6

    .line 232
    .line 233
    :goto_3
    const/4 v2, 0x1

    .line 234
    goto :goto_4

    .line 235
    :cond_6
    const/4 v2, 0x0

    .line 236
    :goto_4
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 237
    .line 238
    .line 239
    move-result-object v0

    .line 240
    return-object v0

    .line 241
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
