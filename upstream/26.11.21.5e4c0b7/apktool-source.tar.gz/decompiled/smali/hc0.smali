.class public final synthetic Lhc0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 23
    iput-byte p8, p0, Lhc0;->h:B

    iput-object p1, p0, Lhc0;->i:Ljava/lang/Object;

    iput-object p2, p0, Lhc0;->j:Ljava/lang/Object;

    iput-object p3, p0, Lhc0;->k:Ljava/lang/Object;

    iput-object p4, p0, Lhc0;->l:Ljava/lang/Object;

    iput-object p5, p0, Lhc0;->m:Ljava/lang/Object;

    iput-object p6, p0, Lhc0;->n:Ljava/lang/Object;

    iput-object p7, p0, Lhc0;->o:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkr6;Lir6;Lhh2;Lkr2;Landroid/content/Context;Ljava/lang/String;Lqx3;)V
    .locals 1

    .line 22
    const/4 v0, 0x2

    iput-byte v0, p0, Lhc0;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lhc0;->i:Ljava/lang/Object;

    iput-object p2, p0, Lhc0;->j:Ljava/lang/Object;

    iput-object p3, p0, Lhc0;->l:Ljava/lang/Object;

    iput-object p4, p0, Lhc0;->n:Ljava/lang/Object;

    iput-object p5, p0, Lhc0;->k:Ljava/lang/Object;

    iput-object p6, p0, Lhc0;->m:Ljava/lang/Object;

    iput-object p7, p0, Lhc0;->o:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lri1;Lzd4;Lzd4;Landroid/content/Context;Lhh2;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x3

    .line 2
    iput-byte v0, p0, Lhc0;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lhc0;->j:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lhc0;->i:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lhc0;->l:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lhc0;->k:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Lhc0;->o:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Lhc0;->m:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object p7, p0, Lhc0;->n:Ljava/lang/Object;

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lhc0;->h:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    sget-object v3, Los7;->a:Los7;

    .line 7
    .line 8
    const/4 v4, 0x3

    .line 9
    iget-object v5, v0, Lhc0;->n:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v6, v0, Lhc0;->m:Ljava/lang/Object;

    .line 12
    .line 13
    iget-object v7, v0, Lhc0;->o:Ljava/lang/Object;

    .line 14
    .line 15
    iget-object v8, v0, Lhc0;->k:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v9, v0, Lhc0;->l:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v10, v0, Lhc0;->i:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v0, v0, Lhc0;->j:Ljava/lang/Object;

    .line 22
    .line 23
    packed-switch v1, :pswitch_data_0

    .line 24
    .line 25
    .line 26
    check-cast v0, Lri1;

    .line 27
    .line 28
    check-cast v10, Lzd4;

    .line 29
    .line 30
    check-cast v9, Lzd4;

    .line 31
    .line 32
    move-object v12, v8

    .line 33
    check-cast v12, Landroid/content/Context;

    .line 34
    .line 35
    move-object v15, v7

    .line 36
    check-cast v15, Lhh2;

    .line 37
    .line 38
    move-object/from16 v16, v6

    .line 39
    .line 40
    check-cast v16, Ljava/lang/String;

    .line 41
    .line 42
    check-cast v5, Ljava/lang/String;

    .line 43
    .line 44
    move-object/from16 v1, p1

    .line 45
    .line 46
    check-cast v1, Lt6;

    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    iget-object v1, v1, Lt6;->i:Landroid/content/Intent;

    .line 52
    .line 53
    if-eqz v1, :cond_0

    .line 54
    .line 55
    invoke-virtual {v1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    move-object v14, v1

    .line 60
    goto :goto_0

    .line 61
    :cond_0
    move-object v14, v2

    .line 62
    :goto_0
    invoke-interface {v10}, Lxy6;->getValue()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    check-cast v1, Ln95;

    .line 67
    .line 68
    invoke-interface {v9}, Lxy6;->getValue()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    move-object v13, v6

    .line 73
    check-cast v13, Lm95;

    .line 74
    .line 75
    invoke-interface {v10, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    invoke-interface {v9, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    if-eqz v14, :cond_2

    .line 82
    .line 83
    if-eqz v13, :cond_1

    .line 84
    .line 85
    new-instance v11, Lkc0;

    .line 86
    .line 87
    const/16 v17, 0x0

    .line 88
    .line 89
    invoke-direct/range {v11 .. v17}, Lkc0;-><init>(Landroid/content/Context;Lm95;Landroid/net/Uri;Lhh2;Ljava/lang/String;Lfd1;)V

    .line 90
    .line 91
    .line 92
    invoke-static {v0, v2, v2, v11, v4}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 93
    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_1
    if-eqz v1, :cond_2

    .line 97
    .line 98
    new-instance v11, Lkc0;

    .line 99
    .line 100
    const/16 v17, 0x0

    .line 101
    .line 102
    move-object/from16 v16, v5

    .line 103
    .line 104
    move-object v13, v14

    .line 105
    move-object v14, v1

    .line 106
    invoke-direct/range {v11 .. v17}, Lkc0;-><init>(Landroid/content/Context;Landroid/net/Uri;Ln95;Lhh2;Ljava/lang/String;Lfd1;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v0, v2, v2, v11, v4}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 110
    .line 111
    .line 112
    :cond_2
    :goto_1
    return-object v3

    .line 113
    :pswitch_0
    move-object v13, v10

    .line 114
    check-cast v13, Lkr6;

    .line 115
    .line 116
    move-object v14, v0

    .line 117
    check-cast v14, Lir6;

    .line 118
    .line 119
    move-object v15, v9

    .line 120
    check-cast v15, Lhh2;

    .line 121
    .line 122
    move-object/from16 v16, v5

    .line 123
    .line 124
    check-cast v16, Lkr2;

    .line 125
    .line 126
    move-object/from16 v17, v8

    .line 127
    .line 128
    check-cast v17, Landroid/content/Context;

    .line 129
    .line 130
    move-object/from16 v18, v6

    .line 131
    .line 132
    check-cast v18, Ljava/lang/String;

    .line 133
    .line 134
    move-object/from16 v19, v7

    .line 135
    .line 136
    check-cast v19, Lqx3;

    .line 137
    .line 138
    move-object/from16 v0, p1

    .line 139
    .line 140
    check-cast v0, Lhm3;

    .line 141
    .line 142
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 143
    .line 144
    .line 145
    new-instance v12, Lvq6;

    .line 146
    .line 147
    invoke-direct/range {v12 .. v19}, Lvq6;-><init>(Lkr6;Lir6;Lhh2;Lkr2;Landroid/content/Context;Ljava/lang/String;Lqx3;)V

    .line 148
    .line 149
    .line 150
    new-instance v1, Lq21;

    .line 151
    .line 152
    const v5, 0x17b37c1c

    .line 153
    .line 154
    .line 155
    const/4 v6, 0x1

    .line 156
    invoke-direct {v1, v5, v6, v12}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    invoke-static {v0, v2, v1, v4}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 160
    .line 161
    .line 162
    return-object v3

    .line 163
    :pswitch_1
    move-object v14, v10

    .line 164
    check-cast v14, Lpn7;

    .line 165
    .line 166
    move-object v15, v0

    .line 167
    check-cast v15, Lpn7;

    .line 168
    .line 169
    move-object/from16 v16, v8

    .line 170
    .line 171
    check-cast v16, Lpn7;

    .line 172
    .line 173
    move-object/from16 v17, v9

    .line 174
    .line 175
    check-cast v17, Lpn7;

    .line 176
    .line 177
    move-object/from16 v18, v6

    .line 178
    .line 179
    check-cast v18, Lpn7;

    .line 180
    .line 181
    move-object/from16 v19, v5

    .line 182
    .line 183
    check-cast v19, Lpn7;

    .line 184
    .line 185
    move-object/from16 v20, v7

    .line 186
    .line 187
    check-cast v20, Lgd;

    .line 188
    .line 189
    move-object/from16 v0, p1

    .line 190
    .line 191
    check-cast v0, Lek0;

    .line 192
    .line 193
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    iget-object v1, v0, Lek0;->h:Lvg0;

    .line 197
    .line 198
    invoke-interface {v1}, Lvg0;->b()J

    .line 199
    .line 200
    .line 201
    move-result-wide v1

    .line 202
    const/16 v3, 0x20

    .line 203
    .line 204
    shr-long/2addr v1, v3

    .line 205
    long-to-int v1, v1

    .line 206
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    const v2, 0x3db851ec    # 0.09f

    .line 211
    .line 212
    .line 213
    mul-float v5, v1, v2

    .line 214
    .line 215
    iget-object v1, v0, Lek0;->h:Lvg0;

    .line 216
    .line 217
    invoke-interface {v1}, Lvg0;->b()J

    .line 218
    .line 219
    .line 220
    move-result-wide v1

    .line 221
    shr-long/2addr v1, v3

    .line 222
    long-to-int v1, v1

    .line 223
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    const/high16 v2, 0x40000000    # 2.0f

    .line 228
    .line 229
    div-float v11, v1, v2

    .line 230
    .line 231
    iget-object v1, v0, Lek0;->h:Lvg0;

    .line 232
    .line 233
    invoke-interface {v1}, Lvg0;->b()J

    .line 234
    .line 235
    .line 236
    move-result-wide v6

    .line 237
    const-wide v8, 0xffffffffL

    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    and-long/2addr v6, v8

    .line 243
    long-to-int v1, v6

    .line 244
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 245
    .line 246
    .line 247
    move-result v1

    .line 248
    div-float v12, v1, v2

    .line 249
    .line 250
    iget-object v1, v0, Lek0;->h:Lvg0;

    .line 251
    .line 252
    invoke-interface {v1}, Lvg0;->b()J

    .line 253
    .line 254
    .line 255
    move-result-wide v1

    .line 256
    shr-long/2addr v1, v3

    .line 257
    long-to-int v1, v1

    .line 258
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 259
    .line 260
    .line 261
    move-result v1

    .line 262
    const v2, -0x416f4dea

    .line 263
    .line 264
    .line 265
    mul-float/2addr v1, v2

    .line 266
    add-float/2addr v1, v11

    .line 267
    iget-object v2, v0, Lek0;->h:Lvg0;

    .line 268
    .line 269
    invoke-interface {v2}, Lvg0;->b()J

    .line 270
    .line 271
    .line 272
    move-result-wide v6

    .line 273
    and-long/2addr v6, v8

    .line 274
    long-to-int v2, v6

    .line 275
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 276
    .line 277
    .line 278
    move-result v2

    .line 279
    const v4, -0x42450238

    .line 280
    .line 281
    .line 282
    mul-float/2addr v2, v4

    .line 283
    add-float/2addr v2, v12

    .line 284
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 285
    .line 286
    .line 287
    move-result v1

    .line 288
    int-to-long v6, v1

    .line 289
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 290
    .line 291
    .line 292
    move-result v1

    .line 293
    int-to-long v1, v1

    .line 294
    shl-long/2addr v6, v3

    .line 295
    and-long/2addr v1, v8

    .line 296
    or-long/2addr v6, v1

    .line 297
    iget-object v1, v0, Lek0;->h:Lvg0;

    .line 298
    .line 299
    invoke-interface {v1}, Lvg0;->b()J

    .line 300
    .line 301
    .line 302
    move-result-wide v1

    .line 303
    shr-long/2addr v1, v3

    .line 304
    long-to-int v1, v1

    .line 305
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 306
    .line 307
    .line 308
    move-result v1

    .line 309
    const v2, -0x42aa4bb2

    .line 310
    .line 311
    .line 312
    mul-float/2addr v1, v2

    .line 313
    add-float/2addr v1, v11

    .line 314
    iget-object v2, v0, Lek0;->h:Lvg0;

    .line 315
    .line 316
    invoke-interface {v2}, Lvg0;->b()J

    .line 317
    .line 318
    .line 319
    move-result-wide v21

    .line 320
    move/from16 p0, v3

    .line 321
    .line 322
    and-long v3, v21, v8

    .line 323
    .line 324
    long-to-int v2, v3

    .line 325
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 326
    .line 327
    .line 328
    move-result v2

    .line 329
    const v3, 0x3e175fb8

    .line 330
    .line 331
    .line 332
    mul-float/2addr v2, v3

    .line 333
    add-float/2addr v2, v12

    .line 334
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 335
    .line 336
    .line 337
    move-result v1

    .line 338
    int-to-long v3, v1

    .line 339
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 340
    .line 341
    .line 342
    move-result v1

    .line 343
    int-to-long v1, v1

    .line 344
    shl-long v3, v3, p0

    .line 345
    .line 346
    and-long/2addr v1, v8

    .line 347
    or-long/2addr v3, v1

    .line 348
    iget-object v1, v0, Lek0;->h:Lvg0;

    .line 349
    .line 350
    invoke-interface {v1}, Lvg0;->b()J

    .line 351
    .line 352
    .line 353
    move-result-wide v1

    .line 354
    shr-long v1, v1, p0

    .line 355
    .line 356
    long-to-int v1, v1

    .line 357
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 358
    .line 359
    .line 360
    move-result v1

    .line 361
    const v2, 0x3e8e7835

    .line 362
    .line 363
    .line 364
    mul-float/2addr v1, v2

    .line 365
    add-float/2addr v1, v11

    .line 366
    iget-object v2, v0, Lek0;->h:Lvg0;

    .line 367
    .line 368
    invoke-interface {v2}, Lvg0;->b()J

    .line 369
    .line 370
    .line 371
    move-result-wide v21

    .line 372
    move-wide/from16 v23, v8

    .line 373
    .line 374
    and-long v8, v21, v23

    .line 375
    .line 376
    long-to-int v2, v8

    .line 377
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 378
    .line 379
    .line 380
    move-result v2

    .line 381
    const v8, -0x417187ca

    .line 382
    .line 383
    .line 384
    mul-float/2addr v2, v8

    .line 385
    add-float/2addr v2, v12

    .line 386
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 387
    .line 388
    .line 389
    move-result v1

    .line 390
    int-to-long v8, v1

    .line 391
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 392
    .line 393
    .line 394
    move-result v1

    .line 395
    int-to-long v1, v1

    .line 396
    shl-long v8, v8, p0

    .line 397
    .line 398
    and-long v1, v1, v23

    .line 399
    .line 400
    or-long v9, v8, v1

    .line 401
    .line 402
    new-instance v21, Lgq0;

    .line 403
    .line 404
    move v13, v5

    .line 405
    move-wide v5, v6

    .line 406
    move-wide v7, v3

    .line 407
    move-object/from16 v4, v21

    .line 408
    .line 409
    invoke-direct/range {v4 .. v13}, Lgq0;-><init>(JJJFFF)V

    .line 410
    .line 411
    .line 412
    move v5, v13

    .line 413
    new-instance v4, Ly07;

    .line 414
    .line 415
    const/high16 v6, 0x41200000    # 10.0f

    .line 416
    .line 417
    const/16 v9, 0x10

    .line 418
    .line 419
    const/4 v7, 0x1

    .line 420
    const/4 v8, 0x1

    .line 421
    invoke-direct/range {v4 .. v9}, Ly07;-><init>(FFIII)V

    .line 422
    .line 423
    .line 424
    new-instance v13, Llm0;

    .line 425
    .line 426
    const/16 v23, 0x1

    .line 427
    .line 428
    move-object/from16 v22, v4

    .line 429
    .line 430
    invoke-direct/range {v13 .. v23}, Llm0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {v0, v13}, Lek0;->c(Lhh2;)Lux7;

    .line 434
    .line 435
    .line 436
    move-result-object v0

    .line 437
    return-object v0

    .line 438
    :pswitch_2
    check-cast v10, Lfc0;

    .line 439
    .line 440
    check-cast v0, Lri1;

    .line 441
    .line 442
    check-cast v8, Landroid/content/Context;

    .line 443
    .line 444
    check-cast v9, Llw;

    .line 445
    .line 446
    check-cast v6, Ljava/lang/String;

    .line 447
    .line 448
    move-object v11, v5

    .line 449
    check-cast v11, Ljava/lang/String;

    .line 450
    .line 451
    move-object v13, v7

    .line 452
    check-cast v13, Ljava/lang/String;

    .line 453
    .line 454
    move-object/from16 v12, p1

    .line 455
    .line 456
    check-cast v12, Ljava/util/Set;

    .line 457
    .line 458
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 459
    .line 460
    .line 461
    iget-object v7, v10, Lfc0;->c:Landroid/net/Uri;

    .line 462
    .line 463
    iget-object v1, v10, Lfc0;->b:Lf75;

    .line 464
    .line 465
    invoke-virtual {v1, v2}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 466
    .line 467
    .line 468
    iput-object v2, v10, Lfc0;->c:Landroid/net/Uri;

    .line 469
    .line 470
    if-eqz v7, :cond_3

    .line 471
    .line 472
    move-object v1, v12

    .line 473
    check-cast v1, Ljava/util/Collection;

    .line 474
    .line 475
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 476
    .line 477
    .line 478
    move-result v1

    .line 479
    if-nez v1, :cond_3

    .line 480
    .line 481
    new-instance v5, Ljc0;

    .line 482
    .line 483
    const/4 v14, 0x0

    .line 484
    move-object/from16 v25, v10

    .line 485
    .line 486
    move-object v10, v6

    .line 487
    move-object v6, v8

    .line 488
    move-object v8, v9

    .line 489
    move-object/from16 v9, v25

    .line 490
    .line 491
    invoke-direct/range {v5 .. v14}, Ljc0;-><init>(Landroid/content/Context;Landroid/net/Uri;Llw;Lfc0;Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;Ljava/lang/String;Lfd1;)V

    .line 492
    .line 493
    .line 494
    invoke-static {v0, v2, v2, v5, v4}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 495
    .line 496
    .line 497
    :cond_3
    return-object v3

    .line 498
    nop

    .line 499
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
