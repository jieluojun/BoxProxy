.class public final Lx52;
.super Lw92;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final d:Lw52;

.field public final e:Ljava/lang/String;

.field public final f:Landroid/graphics/Paint;

.field public final g:Lm5;

.field public final h:Lm5;

.field public final i:Lm5;


# direct methods
.method public constructor <init>(Lv52;Lw52;Ljava/lang/String;Landroid/graphics/Paint;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lw92;-><init>(Lv92;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lx52;->d:Lw52;

    .line 5
    .line 6
    iput-object p3, p0, Lx52;->e:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p4, p0, Lx52;->f:Landroid/graphics/Paint;

    .line 9
    .line 10
    new-instance p1, Lm5;

    .line 11
    .line 12
    const/16 p2, 0x10

    .line 13
    .line 14
    const/4 p3, 0x0

    .line 15
    invoke-direct {p1, p2, p3}, Lm5;-><init>(BZ)V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, Lx52;->g:Lm5;

    .line 19
    .line 20
    new-instance p1, Lm5;

    .line 21
    .line 22
    invoke-direct {p1, p2, p3}, Lm5;-><init>(BZ)V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, Lx52;->h:Lm5;

    .line 26
    .line 27
    new-instance p1, Lm5;

    .line 28
    .line 29
    invoke-direct {p1, p2, p3}, Lm5;-><init>(BZ)V

    .line 30
    .line 31
    .line 32
    iput-object p1, p0, Lx52;->i:Lm5;

    .line 33
    .line 34
    return-void
.end method
