.class public final Lh63;
.super Ll63;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public g:Lg63;

.field public h:Z

.field public i:Z
