.class public abstract Lsb0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lcx1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lra0;

    .line 2
    .line 3
    const/16 v1, 0xe

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lra0;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lcx1;

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Lsb0;->a:Lcx1;

    .line 15
    .line 16
    return-void
.end method
