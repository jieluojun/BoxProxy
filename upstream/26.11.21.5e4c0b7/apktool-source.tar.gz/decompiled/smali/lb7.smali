.class public final synthetic Llb7;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lrb7;


# direct methods
.method public synthetic constructor <init>(Lrb7;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Llb7;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Llb7;->i:Lrb7;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, Llb7;->h:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    sget-object v3, Los7;->a:Los7;

    .line 6
    .line 7
    iget-object p0, p0, Llb7;->i:Lrb7;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast p1, Ljava/lang/Boolean;

    .line 13
    .line 14
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 15
    .line 16
    .line 17
    iget-object p0, p0, Lrb7;->z:Lod7;

    .line 18
    .line 19
    iget-object p0, p0, Lod7;->k:Lf75;

    .line 20
    .line 21
    invoke-virtual {p0, p1}, Lf75;->setValue(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-object v3

    .line 25
    :pswitch_0
    check-cast p1, Ljava/util/List;

    .line 26
    .line 27
    iget-object p0, p0, Lrb7;->y:Lte7;

    .line 28
    .line 29
    invoke-virtual {p0}, Lte7;->c()Lse7;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    if-eqz p0, :cond_0

    .line 34
    .line 35
    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    :cond_0
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0

    .line 44
    :pswitch_1
    check-cast p1, Lbt1;

    .line 45
    .line 46
    invoke-virtual {p0}, Lrb7;->L1()V

    .line 47
    .line 48
    .line 49
    return-object v3

    .line 50
    :pswitch_2
    check-cast p1, Lbt1;

    .line 51
    .line 52
    invoke-virtual {p0}, Lrb7;->L1()V

    .line 53
    .line 54
    .line 55
    iget-object p1, p0, Lrb7;->z:Lod7;

    .line 56
    .line 57
    invoke-virtual {p1}, Lod7;->b()V

    .line 58
    .line 59
    .line 60
    invoke-static {p0}, Lha1;->C(Lna4;)V

    .line 61
    .line 62
    .line 63
    return-object v3

    .line 64
    :pswitch_3
    check-cast p1, Lhv4;

    .line 65
    .line 66
    iget-object v0, p0, Lrb7;->y:Lte7;

    .line 67
    .line 68
    iget-wide v4, p1, Lhv4;->a:J

    .line 69
    .line 70
    invoke-virtual {v0}, Lte7;->b()Lfi3;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    if-eqz p1, :cond_1

    .line 75
    .line 76
    invoke-interface {p1}, Lfi3;->B()Z

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    if-eqz v0, :cond_1

    .line 81
    .line 82
    invoke-interface {p1, v4, v5}, Lfi3;->g(J)J

    .line 83
    .line 84
    .line 85
    move-result-wide v4

    .line 86
    :cond_1
    iget-object p1, p0, Lrb7;->y:Lte7;

    .line 87
    .line 88
    invoke-virtual {p1, v4, v5, v2}, Lte7;->d(JZ)I

    .line 89
    .line 90
    .line 91
    move-result p1

    .line 92
    if-ltz p1, :cond_2

    .line 93
    .line 94
    iget-object v0, p0, Lrb7;->x:Lhn7;

    .line 95
    .line 96
    invoke-static {p1, p1}, Lki6;->o(II)J

    .line 97
    .line 98
    .line 99
    move-result-wide v1

    .line 100
    invoke-virtual {v0, v1, v2}, Lhn7;->m(J)V

    .line 101
    .line 102
    .line 103
    :cond_2
    iget-object p0, p0, Lrb7;->z:Lod7;

    .line 104
    .line 105
    sget-object p1, Lar2;->h:Lar2;

    .line 106
    .line 107
    invoke-virtual {p0, p1, v4, v5}, Lod7;->C(Lar2;J)V

    .line 108
    .line 109
    .line 110
    return-object v3

    .line 111
    :pswitch_4
    check-cast p1, Lbt1;

    .line 112
    .line 113
    new-instance p1, Lct1;

    .line 114
    .line 115
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 116
    .line 117
    .line 118
    iget-object v0, p0, Lrb7;->E:Lzc4;

    .line 119
    .line 120
    invoke-virtual {v0, p1}, Lzc4;->c(Lga3;)V

    .line 121
    .line 122
    .line 123
    iput-object p1, p0, Lrb7;->I:Lct1;

    .line 124
    .line 125
    invoke-static {p0}, Lha1;->C(Lna4;)V

    .line 126
    .line 127
    .line 128
    return-object v3

    .line 129
    :pswitch_5
    check-cast p1, Lbt1;

    .line 130
    .line 131
    invoke-static {p0}, Lha1;->C(Lna4;)V

    .line 132
    .line 133
    .line 134
    return-object v3

    .line 135
    :pswitch_6
    check-cast p1, Ljava/lang/Boolean;

    .line 136
    .line 137
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 138
    .line 139
    .line 140
    move-result p1

    .line 141
    if-eqz p1, :cond_3

    .line 142
    .line 143
    sget-object p1, Lw51;->h:Lx51;

    .line 144
    .line 145
    invoke-static {p0, p1}, Lxj;->N(Lr51;Lch5;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    check-cast p1, Lc83;

    .line 150
    .line 151
    check-cast p1, Ld83;

    .line 152
    .line 153
    iget-object p1, p1, Ld83;->a:Lf75;

    .line 154
    .line 155
    invoke-virtual {p1}, Lf75;->getValue()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    check-cast p1, Lb83;

    .line 160
    .line 161
    iget-byte p1, p1, Lb83;->a:B

    .line 162
    .line 163
    if-eq p1, v2, :cond_4

    .line 164
    .line 165
    iget-object p1, p0, Lrb7;->z:Lod7;

    .line 166
    .line 167
    invoke-virtual {p1, v1}, Lod7;->x(Z)V

    .line 168
    .line 169
    .line 170
    goto :goto_0

    .line 171
    :cond_3
    invoke-virtual {p0}, Lrb7;->K1()V

    .line 172
    .line 173
    .line 174
    iget-object p1, p0, Lrb7;->x:Lhn7;

    .line 175
    .line 176
    iget-object v0, p1, Lhn7;->a:Lvd7;

    .line 177
    .line 178
    iget-object v1, p1, Lhn7;->b:Lt32;

    .line 179
    .line 180
    iget-object v4, v0, Lvd7;->b:Lya7;

    .line 181
    .line 182
    invoke-virtual {v4}, Lya7;->a()Lor;

    .line 183
    .line 184
    .line 185
    move-result-object v4

    .line 186
    invoke-virtual {v4}, Lor;->p()V

    .line 187
    .line 188
    .line 189
    iget-object v4, v0, Lvd7;->b:Lya7;

    .line 190
    .line 191
    const/4 v5, 0x0

    .line 192
    invoke-virtual {v4, v5}, Lya7;->f(Lwf7;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {p1, v4}, Lhn7;->o(Lya7;)V

    .line 196
    .line 197
    .line 198
    sget-object p1, Lwb7;->h:Lwb7;

    .line 199
    .line 200
    invoke-virtual {v0, v1, v2, p1}, Lvd7;->b(Lt32;ZLwb7;)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v0, v2}, Lvd7;->f(Z)V

    .line 204
    .line 205
    .line 206
    iget-object p1, v0, Lvd7;->b:Lya7;

    .line 207
    .line 208
    iget-boolean p1, p1, Lya7;->k:Z

    .line 209
    .line 210
    invoke-virtual {v0, p1}, Lvd7;->e(Z)V

    .line 211
    .line 212
    .line 213
    iget-object p1, p0, Lrb7;->x:Lhn7;

    .line 214
    .line 215
    invoke-virtual {p1}, Lhn7;->a()V

    .line 216
    .line 217
    .line 218
    :cond_4
    :goto_0
    new-instance p1, Lkb7;

    .line 219
    .line 220
    invoke-direct {p1, p0, v2}, Lkb7;-><init>(Lrb7;B)V

    .line 221
    .line 222
    .line 223
    invoke-static {p0, p1}, Ls33;->e0(Lga4;Lwg2;)V

    .line 224
    .line 225
    .line 226
    return-object v3

    .line 227
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
