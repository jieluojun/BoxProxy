.class public final synthetic Ljw2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lnh2;


# instance fields
.field public final synthetic h:J

.field public final synthetic i:J

.field public final synthetic j:Lsf2;


# direct methods
.method public synthetic constructor <init>(JJLsf2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Ljw2;->h:J

    .line 5
    .line 6
    iput-wide p3, p0, Ljw2;->i:J

    .line 7
    .line 8
    iput-object p5, p0, Ljw2;->j:Lsf2;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final r(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Luh;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Ljava/lang/String;

    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    check-cast v3, Lki2;

    .line 14
    .line 15
    move-object/from16 v4, p4

    .line 16
    .line 17
    check-cast v4, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    and-int/lit8 v1, v4, 0x30

    .line 30
    .line 31
    if-nez v1, :cond_1

    .line 32
    .line 33
    invoke-virtual {v3, v2}, Lki2;->g(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_0

    .line 38
    .line 39
    const/16 v1, 0x20

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    const/16 v1, 0x10

    .line 43
    .line 44
    :goto_0
    or-int/2addr v4, v1

    .line 45
    :cond_1
    and-int/lit16 v1, v4, 0x91

    .line 46
    .line 47
    const/16 v5, 0x90

    .line 48
    .line 49
    const/4 v6, 0x0

    .line 50
    if-eq v1, v5, :cond_2

    .line 51
    .line 52
    const/4 v1, 0x1

    .line 53
    goto :goto_1

    .line 54
    :cond_2
    move v1, v6

    .line 55
    :goto_1
    and-int/lit8 v5, v4, 0x1

    .line 56
    .line 57
    invoke-virtual {v3, v5, v1}, Lki2;->Y(IZ)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_4

    .line 62
    .line 63
    invoke-static {v2}, Lq07;->W(Ljava/lang/CharSequence;)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-nez v1, :cond_3

    .line 68
    .line 69
    const v1, -0xc577748

    .line 70
    .line 71
    .line 72
    invoke-virtual {v3, v1}, Lki2;->h0(I)V

    .line 73
    .line 74
    .line 75
    shr-int/lit8 v4, v4, 0x3

    .line 76
    .line 77
    and-int/lit8 v22, v4, 0xe

    .line 78
    .line 79
    const/16 v23, 0x6180

    .line 80
    .line 81
    const v24, 0x3afaa

    .line 82
    .line 83
    .line 84
    move-object/from16 v21, v3

    .line 85
    .line 86
    const/4 v3, 0x0

    .line 87
    iget-wide v4, v0, Ljw2;->h:J

    .line 88
    .line 89
    move v1, v6

    .line 90
    iget-wide v6, v0, Ljw2;->i:J

    .line 91
    .line 92
    iget-object v8, v0, Ljw2;->j:Lsf2;

    .line 93
    .line 94
    const/4 v9, 0x0

    .line 95
    const-wide/16 v10, 0x0

    .line 96
    .line 97
    const/4 v12, 0x0

    .line 98
    const-wide/16 v13, 0x0

    .line 99
    .line 100
    const/4 v15, 0x2

    .line 101
    const/16 v16, 0x0

    .line 102
    .line 103
    const/16 v17, 0x1

    .line 104
    .line 105
    const/16 v18, 0x0

    .line 106
    .line 107
    const/16 v19, 0x0

    .line 108
    .line 109
    const/16 v20, 0x0

    .line 110
    .line 111
    invoke-static/range {v2 .. v24}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 112
    .line 113
    .line 114
    move-object/from16 v0, v21

    .line 115
    .line 116
    invoke-virtual {v0, v1}, Lki2;->r(Z)V

    .line 117
    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_3
    move-object v0, v3

    .line 121
    move v1, v6

    .line 122
    const v2, -0xc532b44

    .line 123
    .line 124
    .line 125
    invoke-virtual {v0, v2}, Lki2;->h0(I)V

    .line 126
    .line 127
    .line 128
    sget-object v2, Lea4;->h:Lea4;

    .line 129
    .line 130
    const/high16 v3, 0x3f800000    # 1.0f

    .line 131
    .line 132
    invoke-static {v2, v3}, Lit6;->e(Lha4;F)Lha4;

    .line 133
    .line 134
    .line 135
    move-result-object v2

    .line 136
    invoke-static {v0, v2}, Lck6;->b(Lki2;Lha4;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v0, v1}, Lki2;->r(Z)V

    .line 140
    .line 141
    .line 142
    goto :goto_2

    .line 143
    :cond_4
    move-object v0, v3

    .line 144
    invoke-virtual {v0}, Lki2;->b0()V

    .line 145
    .line 146
    .line 147
    :goto_2
    sget-object v0, Los7;->a:Los7;

    .line 148
    .line 149
    return-object v0
.end method
