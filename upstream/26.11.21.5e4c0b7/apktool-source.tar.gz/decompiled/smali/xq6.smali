.class public final synthetic Lxq6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lkr6;


# direct methods
.method public synthetic constructor <init>(Lkr6;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lxq6;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lxq6;->i:Lkr6;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lxq6;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    iget-object p0, p0, Lxq6;->i:Lkr6;

    .line 6
    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p1}, Lkr6;->e(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-object v1

    .line 16
    :pswitch_0
    invoke-virtual {p0, p1}, Lkr6;->f(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-object v1

    .line 20
    nop

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
