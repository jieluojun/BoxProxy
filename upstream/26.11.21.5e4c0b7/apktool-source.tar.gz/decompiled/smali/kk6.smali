.class public abstract Lkk6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final A:Lmk6;

.field public static final B:Lmk6;

.field public static final C:Lmk6;

.field public static final D:Lmk6;

.field public static final E:Lmk6;

.field public static final F:Lmk6;

.field public static final G:Lmk6;

.field public static final H:Lmk6;

.field public static final I:Lmk6;

.field public static final J:Lmk6;

.field public static final K:Lmk6;

.field public static final L:Lmk6;

.field public static final M:Lmk6;

.field public static final N:Lmk6;

.field public static final O:Lmk6;

.field public static final P:Lmk6;

.field public static final Q:Lmk6;

.field public static final R:Lmk6;

.field public static final S:Lmk6;

.field public static final T:Lmk6;

.field public static final U:Lmk6;

.field public static final V:Lmk6;

.field public static final a:Lmk6;

.field public static final b:Lmk6;

.field public static final c:Lmk6;

.field public static final d:Lmk6;

.field public static final e:Lmk6;

.field public static final f:Lmk6;

.field public static final g:Lmk6;

.field public static final h:Lmk6;

.field public static final i:Lmk6;

.field public static final j:Lmk6;

.field public static final k:Lmk6;

.field public static final l:Lmk6;

.field public static final m:Lmk6;

.field public static final n:Lmk6;

.field public static final o:Lmk6;

.field public static final p:Lmk6;

.field public static final q:Lmk6;

.field public static final r:Lmk6;

.field public static final s:Lmk6;

.field public static final t:Lmk6;

.field public static final u:Lmk6;

.field public static final v:Lmk6;

.field public static final w:Lmk6;

.field public static final x:Lmk6;

.field public static final y:Lmk6;

.field public static final z:Lmk6;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Lhd6;

    .line 2
    .line 3
    const/16 v1, 0x17

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lhd6;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lmk6;

    .line 9
    .line 10
    const-string v2, "ContentDescription"

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-direct {v1, v2, v3, v0}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 14
    .line 15
    .line 16
    sput-object v1, Lkk6;->a:Lmk6;

    .line 17
    .line 18
    new-instance v0, Lmk6;

    .line 19
    .line 20
    const-string v1, "StateDescription"

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 24
    .line 25
    .line 26
    sput-object v0, Lkk6;->b:Lmk6;

    .line 27
    .line 28
    new-instance v0, Lmk6;

    .line 29
    .line 30
    const-string v1, "ProgressBarRangeInfo"

    .line 31
    .line 32
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 33
    .line 34
    .line 35
    sput-object v0, Lkk6;->c:Lmk6;

    .line 36
    .line 37
    new-instance v0, Ljk6;

    .line 38
    .line 39
    const/4 v1, 0x4

    .line 40
    invoke-direct {v0, v1}, Ljk6;-><init>(B)V

    .line 41
    .line 42
    .line 43
    new-instance v1, Lmk6;

    .line 44
    .line 45
    const-string v4, "PaneTitle"

    .line 46
    .line 47
    invoke-direct {v1, v4, v3, v0}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 48
    .line 49
    .line 50
    sput-object v1, Lkk6;->d:Lmk6;

    .line 51
    .line 52
    new-instance v0, Lmk6;

    .line 53
    .line 54
    const-string v1, "SelectableGroup"

    .line 55
    .line 56
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 57
    .line 58
    .line 59
    sput-object v0, Lkk6;->e:Lmk6;

    .line 60
    .line 61
    new-instance v0, Lmk6;

    .line 62
    .line 63
    const-string v1, "CollectionInfo"

    .line 64
    .line 65
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 66
    .line 67
    .line 68
    sput-object v0, Lkk6;->f:Lmk6;

    .line 69
    .line 70
    new-instance v0, Lmk6;

    .line 71
    .line 72
    const-string v1, "CollectionItemInfo"

    .line 73
    .line 74
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 75
    .line 76
    .line 77
    sput-object v0, Lkk6;->g:Lmk6;

    .line 78
    .line 79
    new-instance v0, Lmk6;

    .line 80
    .line 81
    const-string v1, "Heading"

    .line 82
    .line 83
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 84
    .line 85
    .line 86
    sput-object v0, Lkk6;->h:Lmk6;

    .line 87
    .line 88
    new-instance v0, Lmk6;

    .line 89
    .line 90
    const-string v1, "TextEntryKey"

    .line 91
    .line 92
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 93
    .line 94
    .line 95
    sput-object v0, Lkk6;->i:Lmk6;

    .line 96
    .line 97
    new-instance v0, Lmk6;

    .line 98
    .line 99
    const-string v1, "Disabled"

    .line 100
    .line 101
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 102
    .line 103
    .line 104
    sput-object v0, Lkk6;->j:Lmk6;

    .line 105
    .line 106
    new-instance v0, Lmk6;

    .line 107
    .line 108
    const-string v1, "LiveRegion"

    .line 109
    .line 110
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 111
    .line 112
    .line 113
    sput-object v0, Lkk6;->k:Lmk6;

    .line 114
    .line 115
    new-instance v0, Lmk6;

    .line 116
    .line 117
    const-string v1, "Focused"

    .line 118
    .line 119
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 120
    .line 121
    .line 122
    sput-object v0, Lkk6;->l:Lmk6;

    .line 123
    .line 124
    new-instance v0, Lmk6;

    .line 125
    .line 126
    const-string v1, "IsContainer"

    .line 127
    .line 128
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 129
    .line 130
    .line 131
    sput-object v0, Lkk6;->m:Lmk6;

    .line 132
    .line 133
    new-instance v0, Lmk6;

    .line 134
    .line 135
    const-string v1, "IsTraversalGroup"

    .line 136
    .line 137
    invoke-direct {v0, v1}, Lmk6;-><init>(Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    sput-object v0, Lkk6;->n:Lmk6;

    .line 141
    .line 142
    new-instance v0, Lmk6;

    .line 143
    .line 144
    const-string v1, "IsSensitiveData"

    .line 145
    .line 146
    invoke-direct {v0, v1}, Lmk6;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    sput-object v0, Lkk6;->o:Lmk6;

    .line 150
    .line 151
    new-instance v0, Lmk6;

    .line 152
    .line 153
    new-instance v1, Ljk6;

    .line 154
    .line 155
    const/4 v4, 0x0

    .line 156
    invoke-direct {v1, v4}, Ljk6;-><init>(B)V

    .line 157
    .line 158
    .line 159
    const-string v4, "InvisibleToUser"

    .line 160
    .line 161
    invoke-direct {v0, v4, v1}, Lmk6;-><init>(Ljava/lang/String;Llh2;)V

    .line 162
    .line 163
    .line 164
    sput-object v0, Lkk6;->p:Lmk6;

    .line 165
    .line 166
    new-instance v0, Lmk6;

    .line 167
    .line 168
    new-instance v1, Ljk6;

    .line 169
    .line 170
    const/4 v4, 0x0

    .line 171
    invoke-direct {v1, v4}, Ljk6;-><init>(B)V

    .line 172
    .line 173
    .line 174
    const-string v4, "HideFromAccessibility"

    .line 175
    .line 176
    invoke-direct {v0, v4, v1}, Lmk6;-><init>(Ljava/lang/String;Llh2;)V

    .line 177
    .line 178
    .line 179
    sput-object v0, Lkk6;->q:Lmk6;

    .line 180
    .line 181
    new-instance v0, Lmk6;

    .line 182
    .line 183
    new-instance v1, Ljk6;

    .line 184
    .line 185
    const/4 v4, 0x5

    .line 186
    invoke-direct {v1, v4}, Ljk6;-><init>(B)V

    .line 187
    .line 188
    .line 189
    const-string v4, "ContentType"

    .line 190
    .line 191
    invoke-direct {v0, v4, v1}, Lmk6;-><init>(Ljava/lang/String;Llh2;)V

    .line 192
    .line 193
    .line 194
    sput-object v0, Lkk6;->r:Lmk6;

    .line 195
    .line 196
    new-instance v0, Lmk6;

    .line 197
    .line 198
    new-instance v1, Ljk6;

    .line 199
    .line 200
    const/4 v4, 0x6

    .line 201
    invoke-direct {v1, v4}, Ljk6;-><init>(B)V

    .line 202
    .line 203
    .line 204
    const-string v4, "ContentDataType"

    .line 205
    .line 206
    invoke-direct {v0, v4, v1}, Lmk6;-><init>(Ljava/lang/String;Llh2;)V

    .line 207
    .line 208
    .line 209
    sput-object v0, Lkk6;->s:Lmk6;

    .line 210
    .line 211
    new-instance v0, Lmk6;

    .line 212
    .line 213
    new-instance v1, Lhd6;

    .line 214
    .line 215
    const/16 v4, 0x18

    .line 216
    .line 217
    invoke-direct {v1, v4}, Lhd6;-><init>(B)V

    .line 218
    .line 219
    .line 220
    const-string v4, "FillableData"

    .line 221
    .line 222
    invoke-direct {v0, v4, v1}, Lmk6;-><init>(Ljava/lang/String;Llh2;)V

    .line 223
    .line 224
    .line 225
    sput-object v0, Lkk6;->t:Lmk6;

    .line 226
    .line 227
    new-instance v0, Lmk6;

    .line 228
    .line 229
    new-instance v1, Lhd6;

    .line 230
    .line 231
    const/16 v4, 0x19

    .line 232
    .line 233
    invoke-direct {v1, v4}, Lhd6;-><init>(B)V

    .line 234
    .line 235
    .line 236
    const-string v4, "TraversalIndex"

    .line 237
    .line 238
    invoke-direct {v0, v4, v1}, Lmk6;-><init>(Ljava/lang/String;Llh2;)V

    .line 239
    .line 240
    .line 241
    sput-object v0, Lkk6;->u:Lmk6;

    .line 242
    .line 243
    new-instance v0, Lmk6;

    .line 244
    .line 245
    const-string v1, "HintText"

    .line 246
    .line 247
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 248
    .line 249
    .line 250
    sput-object v0, Lkk6;->v:Lmk6;

    .line 251
    .line 252
    new-instance v0, Lmk6;

    .line 253
    .line 254
    const-string v1, "HorizontalScrollAxisRange"

    .line 255
    .line 256
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 257
    .line 258
    .line 259
    sput-object v0, Lkk6;->w:Lmk6;

    .line 260
    .line 261
    new-instance v0, Lmk6;

    .line 262
    .line 263
    const-string v1, "VerticalScrollAxisRange"

    .line 264
    .line 265
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 266
    .line 267
    .line 268
    sput-object v0, Lkk6;->x:Lmk6;

    .line 269
    .line 270
    new-instance v0, Lhd6;

    .line 271
    .line 272
    const/16 v1, 0x1a

    .line 273
    .line 274
    invoke-direct {v0, v1}, Lhd6;-><init>(B)V

    .line 275
    .line 276
    .line 277
    new-instance v1, Lmk6;

    .line 278
    .line 279
    const-string v4, "IsPopup"

    .line 280
    .line 281
    invoke-direct {v1, v4, v3, v0}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 282
    .line 283
    .line 284
    sput-object v1, Lkk6;->y:Lmk6;

    .line 285
    .line 286
    new-instance v0, Lhd6;

    .line 287
    .line 288
    const/16 v1, 0x1b

    .line 289
    .line 290
    invoke-direct {v0, v1}, Lhd6;-><init>(B)V

    .line 291
    .line 292
    .line 293
    new-instance v1, Lmk6;

    .line 294
    .line 295
    const-string v4, "IsDialog"

    .line 296
    .line 297
    invoke-direct {v1, v4, v3, v0}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 298
    .line 299
    .line 300
    sput-object v1, Lkk6;->z:Lmk6;

    .line 301
    .line 302
    new-instance v0, Lhd6;

    .line 303
    .line 304
    const/16 v1, 0x1c

    .line 305
    .line 306
    invoke-direct {v0, v1}, Lhd6;-><init>(B)V

    .line 307
    .line 308
    .line 309
    new-instance v1, Lmk6;

    .line 310
    .line 311
    const-string v4, "Role"

    .line 312
    .line 313
    invoke-direct {v1, v4, v3, v0}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 314
    .line 315
    .line 316
    sput-object v1, Lkk6;->A:Lmk6;

    .line 317
    .line 318
    new-instance v0, Lmk6;

    .line 319
    .line 320
    new-instance v1, Lhd6;

    .line 321
    .line 322
    const/16 v4, 0x1d

    .line 323
    .line 324
    invoke-direct {v1, v4}, Lhd6;-><init>(B)V

    .line 325
    .line 326
    .line 327
    const-string v4, "TestTag"

    .line 328
    .line 329
    invoke-direct {v0, v4, v2, v1}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 330
    .line 331
    .line 332
    sput-object v0, Lkk6;->B:Lmk6;

    .line 333
    .line 334
    new-instance v0, Lmk6;

    .line 335
    .line 336
    new-instance v1, Ljk6;

    .line 337
    .line 338
    const/4 v4, 0x0

    .line 339
    invoke-direct {v1, v4}, Ljk6;-><init>(B)V

    .line 340
    .line 341
    .line 342
    const-string v4, "LinkTestMarker"

    .line 343
    .line 344
    invoke-direct {v0, v4, v2, v1}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 345
    .line 346
    .line 347
    sput-object v0, Lkk6;->C:Lmk6;

    .line 348
    .line 349
    new-instance v0, Ljk6;

    .line 350
    .line 351
    const/4 v1, 0x1

    .line 352
    invoke-direct {v0, v1}, Ljk6;-><init>(B)V

    .line 353
    .line 354
    .line 355
    new-instance v1, Lmk6;

    .line 356
    .line 357
    const-string v4, "Text"

    .line 358
    .line 359
    invoke-direct {v1, v4, v3, v0}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 360
    .line 361
    .line 362
    sput-object v1, Lkk6;->D:Lmk6;

    .line 363
    .line 364
    new-instance v0, Lmk6;

    .line 365
    .line 366
    const-string v1, "TextSubstitution"

    .line 367
    .line 368
    invoke-direct {v0, v1}, Lmk6;-><init>(Ljava/lang/String;)V

    .line 369
    .line 370
    .line 371
    sput-object v0, Lkk6;->E:Lmk6;

    .line 372
    .line 373
    new-instance v0, Lmk6;

    .line 374
    .line 375
    const-string v1, "IsShowingTextSubstitution"

    .line 376
    .line 377
    invoke-direct {v0, v1}, Lmk6;-><init>(Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    sput-object v0, Lkk6;->F:Lmk6;

    .line 381
    .line 382
    new-instance v0, Lmk6;

    .line 383
    .line 384
    const-string v1, "InputText"

    .line 385
    .line 386
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 387
    .line 388
    .line 389
    sput-object v0, Lkk6;->G:Lmk6;

    .line 390
    .line 391
    new-instance v0, Lmk6;

    .line 392
    .line 393
    const-string v1, "EditableText"

    .line 394
    .line 395
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 396
    .line 397
    .line 398
    sput-object v0, Lkk6;->H:Lmk6;

    .line 399
    .line 400
    new-instance v0, Lmk6;

    .line 401
    .line 402
    const-string v1, "TextSelectionRange"

    .line 403
    .line 404
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 405
    .line 406
    .line 407
    sput-object v0, Lkk6;->I:Lmk6;

    .line 408
    .line 409
    new-instance v0, Lmk6;

    .line 410
    .line 411
    const-string v1, "TextCompositionRange"

    .line 412
    .line 413
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 414
    .line 415
    .line 416
    sput-object v0, Lkk6;->J:Lmk6;

    .line 417
    .line 418
    new-instance v0, Lmk6;

    .line 419
    .line 420
    const-string v1, "ImeAction"

    .line 421
    .line 422
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 423
    .line 424
    .line 425
    sput-object v0, Lkk6;->K:Lmk6;

    .line 426
    .line 427
    new-instance v0, Lmk6;

    .line 428
    .line 429
    const-string v1, "Selected"

    .line 430
    .line 431
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 432
    .line 433
    .line 434
    sput-object v0, Lkk6;->L:Lmk6;

    .line 435
    .line 436
    new-instance v0, Lmk6;

    .line 437
    .line 438
    const-string v1, "ToggleableState"

    .line 439
    .line 440
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 441
    .line 442
    .line 443
    sput-object v0, Lkk6;->M:Lmk6;

    .line 444
    .line 445
    new-instance v0, Lmk6;

    .line 446
    .line 447
    const-string v1, "InputTextSuggestionState"

    .line 448
    .line 449
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 450
    .line 451
    .line 452
    sput-object v0, Lkk6;->N:Lmk6;

    .line 453
    .line 454
    new-instance v0, Lmk6;

    .line 455
    .line 456
    const-string v1, "Password"

    .line 457
    .line 458
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 459
    .line 460
    .line 461
    sput-object v0, Lkk6;->O:Lmk6;

    .line 462
    .line 463
    new-instance v0, Lmk6;

    .line 464
    .line 465
    const-string v1, "IsPasswordObfuscated"

    .line 466
    .line 467
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 468
    .line 469
    .line 470
    sput-object v0, Lkk6;->P:Lmk6;

    .line 471
    .line 472
    new-instance v0, Lmk6;

    .line 473
    .line 474
    const-string v1, "Error"

    .line 475
    .line 476
    invoke-direct {v0, v1, v2}, Lmk6;-><init>(Ljava/lang/String;I)V

    .line 477
    .line 478
    .line 479
    sput-object v0, Lkk6;->Q:Lmk6;

    .line 480
    .line 481
    new-instance v0, Lmk6;

    .line 482
    .line 483
    const-string v1, "IndexForKey"

    .line 484
    .line 485
    invoke-direct {v0, v1}, Lmk6;-><init>(Ljava/lang/String;)V

    .line 486
    .line 487
    .line 488
    sput-object v0, Lkk6;->R:Lmk6;

    .line 489
    .line 490
    new-instance v0, Lmk6;

    .line 491
    .line 492
    const-string v1, "IsEditable"

    .line 493
    .line 494
    invoke-direct {v0, v1}, Lmk6;-><init>(Ljava/lang/String;)V

    .line 495
    .line 496
    .line 497
    sput-object v0, Lkk6;->S:Lmk6;

    .line 498
    .line 499
    new-instance v0, Lmk6;

    .line 500
    .line 501
    const-string v1, "MaxTextLength"

    .line 502
    .line 503
    invoke-direct {v0, v1}, Lmk6;-><init>(Ljava/lang/String;)V

    .line 504
    .line 505
    .line 506
    sput-object v0, Lkk6;->T:Lmk6;

    .line 507
    .line 508
    new-instance v0, Lmk6;

    .line 509
    .line 510
    new-instance v1, Ljk6;

    .line 511
    .line 512
    const/4 v3, 0x2

    .line 513
    invoke-direct {v1, v3}, Ljk6;-><init>(B)V

    .line 514
    .line 515
    .line 516
    const-string v3, "BackgroundColor"

    .line 517
    .line 518
    invoke-direct {v0, v3, v1}, Lmk6;-><init>(Ljava/lang/String;Llh2;)V

    .line 519
    .line 520
    .line 521
    sput-object v0, Lkk6;->U:Lmk6;

    .line 522
    .line 523
    new-instance v0, Lmk6;

    .line 524
    .line 525
    new-instance v1, Ljk6;

    .line 526
    .line 527
    const/4 v3, 0x3

    .line 528
    invoke-direct {v1, v3}, Ljk6;-><init>(B)V

    .line 529
    .line 530
    .line 531
    const-string v3, "Shape"

    .line 532
    .line 533
    invoke-direct {v0, v3, v2, v1}, Lmk6;-><init>(Ljava/lang/String;ZLlh2;)V

    .line 534
    .line 535
    .line 536
    sput-object v0, Lkk6;->V:Lmk6;

    .line 537
    .line 538
    return-void
.end method
