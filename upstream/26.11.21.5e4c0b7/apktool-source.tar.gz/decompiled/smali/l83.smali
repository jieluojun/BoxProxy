.class public abstract Ll83;
.super Lga4;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lxn7;


# instance fields
.field public v:Lt08;

.field public w:Lt08;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lga4;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lxp7;->c0:Lea2;

    .line 5
    .line 6
    iput-object v0, p0, Ll83;->v:Lt08;

    .line 7
    .line 8
    iput-object v0, p0, Ll83;->w:Lt08;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final A1()V
    .locals 1

    .line 1
    sget-object v0, Lxp7;->c0:Lea2;

    .line 2
    .line 3
    iput-object v0, p0, Ll83;->v:Lt08;

    .line 4
    .line 5
    return-void
.end method

.method public abstract G1(Lt08;)Lt08;
.end method

.method public H1()V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lga4;->u:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Ll83;->v:Lt08;

    .line 6
    .line 7
    invoke-virtual {p0, v0}, Ll83;->G1(Lt08;)Lt08;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Ll83;->w:Lt08;

    .line 12
    .line 13
    new-instance v0, Lk83;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-direct {v0, p0, v1}, Lk83;-><init>(Ll83;B)V

    .line 17
    .line 18
    .line 19
    const-string v1, "androidx.compose.foundation.layout.ConsumedInsetsProvider"

    .line 20
    .line 21
    invoke-static {p0, v1, v0}, Lhk6;->x(Lio1;Ljava/lang/Object;Lhh2;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void
.end method

.method public final f()Ljava/lang/Object;
    .locals 0

    .line 1
    const-string p0, "androidx.compose.foundation.layout.ConsumedInsetsProvider"

    .line 2
    .line 3
    return-object p0
.end method

.method public y1()V
    .locals 2

    .line 1
    new-instance v0, Lk83;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, p0, v1}, Lk83;-><init>(Ll83;B)V

    .line 5
    .line 6
    .line 7
    const-string v1, "androidx.compose.foundation.layout.ConsumedInsetsProvider"

    .line 8
    .line 9
    invoke-static {p0, v1, v0}, Lhk6;->v(Lio1;Ljava/lang/Object;Lhh2;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Ll83;->H1()V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public z1()V
    .locals 2

    .line 1
    iget-object v0, p0, Ll83;->v:Lt08;

    .line 2
    .line 3
    iput-object v0, p0, Ll83;->w:Lt08;

    .line 4
    .line 5
    new-instance v0, Lk83;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {v0, p0, v1}, Lk83;-><init>(Ll83;B)V

    .line 9
    .line 10
    .line 11
    const-string v1, "androidx.compose.foundation.layout.ConsumedInsetsProvider"

    .line 12
    .line 13
    invoke-static {p0, v1, v0}, Lhk6;->x(Lio1;Ljava/lang/Object;Lhh2;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method
