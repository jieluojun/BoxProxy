.class public final synthetic Lkv0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Luu0;


# direct methods
.method public synthetic constructor <init>(Luu0;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lkv0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lkv0;->i:Luu0;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lkv0;->h:B

    .line 4
    .line 5
    const v2, 0x7f0f00d6

    .line 6
    .line 7
    .line 8
    sget-object v3, Los7;->a:Los7;

    .line 9
    .line 10
    const/4 v4, 0x2

    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v6, 0x1

    .line 13
    iget-object v0, v0, Lkv0;->i:Luu0;

    .line 14
    .line 15
    packed-switch v1, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    move-object/from16 v12, p1

    .line 19
    .line 20
    check-cast v12, Lki2;

    .line 21
    .line 22
    move-object/from16 v1, p2

    .line 23
    .line 24
    check-cast v1, Ljava/lang/Integer;

    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    and-int/lit8 v7, v1, 0x3

    .line 31
    .line 32
    if-eq v7, v4, :cond_0

    .line 33
    .line 34
    move v4, v6

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    move v4, v5

    .line 37
    :goto_0
    and-int/2addr v1, v6

    .line 38
    invoke-virtual {v12, v1, v4}, Lki2;->Y(IZ)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-eqz v1, :cond_2

    .line 43
    .line 44
    invoke-static {}, Lx43;->E()La53;

    .line 45
    .line 46
    .line 47
    move-result-object v7

    .line 48
    invoke-static {v2, v12}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v8

    .line 52
    invoke-virtual {v0}, Luu0;->a()Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_1

    .line 57
    .line 58
    const v0, 0x4111767a

    .line 59
    .line 60
    .line 61
    invoke-virtual {v12, v0}, Lki2;->h0(I)V

    .line 62
    .line 63
    .line 64
    sget-object v0, Lsz0;->a:Lcx1;

    .line 65
    .line 66
    invoke-virtual {v12, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    check-cast v0, Lrz0;

    .line 71
    .line 72
    invoke-virtual {v0}, Lrz0;->o()J

    .line 73
    .line 74
    .line 75
    move-result-wide v0

    .line 76
    invoke-virtual {v12, v5}, Lki2;->r(Z)V

    .line 77
    .line 78
    .line 79
    :goto_1
    move-wide v10, v0

    .line 80
    goto :goto_2

    .line 81
    :cond_1
    const v0, 0x4112bc38

    .line 82
    .line 83
    .line 84
    invoke-virtual {v12, v0}, Lki2;->h0(I)V

    .line 85
    .line 86
    .line 87
    sget-object v0, Lsz0;->a:Lcx1;

    .line 88
    .line 89
    invoke-virtual {v12, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    check-cast v0, Lrz0;

    .line 94
    .line 95
    invoke-virtual {v0}, Lrz0;->i()J

    .line 96
    .line 97
    .line 98
    move-result-wide v0

    .line 99
    invoke-virtual {v12, v5}, Lki2;->r(Z)V

    .line 100
    .line 101
    .line 102
    goto :goto_1

    .line 103
    :goto_2
    const/4 v13, 0x0

    .line 104
    const/4 v14, 0x4

    .line 105
    const/4 v9, 0x0

    .line 106
    invoke-static/range {v7 .. v14}, Lr94;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 107
    .line 108
    .line 109
    goto :goto_3

    .line 110
    :cond_2
    invoke-virtual {v12}, Lki2;->b0()V

    .line 111
    .line 112
    .line 113
    :goto_3
    return-object v3

    .line 114
    :pswitch_0
    move-object/from16 v1, p1

    .line 115
    .line 116
    check-cast v1, Lki2;

    .line 117
    .line 118
    move-object/from16 v2, p2

    .line 119
    .line 120
    check-cast v2, Ljava/lang/Integer;

    .line 121
    .line 122
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    and-int/lit8 v7, v2, 0x3

    .line 127
    .line 128
    if-eq v7, v4, :cond_3

    .line 129
    .line 130
    move v7, v6

    .line 131
    goto :goto_4

    .line 132
    :cond_3
    move v7, v5

    .line 133
    :goto_4
    and-int/2addr v2, v6

    .line 134
    invoke-virtual {v1, v2, v7}, Lki2;->Y(IZ)Z

    .line 135
    .line 136
    .line 137
    move-result v2

    .line 138
    if-eqz v2, :cond_4

    .line 139
    .line 140
    invoke-virtual {v0}, Luu0;->a()Z

    .line 141
    .line 142
    .line 143
    move-result v13

    .line 144
    sget-object v2, Lbd0;->b:Lmj1;

    .line 145
    .line 146
    const/16 v6, 0xfa

    .line 147
    .line 148
    invoke-static {v6, v5, v2, v4}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 149
    .line 150
    .line 151
    move-result-object v7

    .line 152
    const/16 v8, 0xe

    .line 153
    .line 154
    invoke-static {v7, v8}, La32;->c(Lmo7;I)Lg32;

    .line 155
    .line 156
    .line 157
    move-result-object v7

    .line 158
    invoke-static {v6, v5, v2, v4}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    const/4 v6, 0x0

    .line 163
    invoke-static {v2, v6, v4}, La32;->d(Lca2;FI)Lg32;

    .line 164
    .line 165
    .line 166
    move-result-object v2

    .line 167
    invoke-virtual {v7, v2}, Lg32;->a(Lg32;)Lg32;

    .line 168
    .line 169
    .line 170
    move-result-object v15

    .line 171
    sget-object v2, Lbd0;->c:Lmj1;

    .line 172
    .line 173
    const/16 v7, 0x78

    .line 174
    .line 175
    invoke-static {v7, v5, v2, v4}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 176
    .line 177
    .line 178
    move-result-object v9

    .line 179
    invoke-static {v9, v8}, La32;->i(Lmo7;I)Lz42;

    .line 180
    .line 181
    .line 182
    move-result-object v8

    .line 183
    invoke-static {v7, v5, v2, v4}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    invoke-static {v2, v6, v4}, La32;->e(Lca2;FI)Lz42;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    invoke-virtual {v8, v2}, Lz42;->a(Lz42;)Lz42;

    .line 192
    .line 193
    .line 194
    move-result-object v16

    .line 195
    new-instance v2, Lmv0;

    .line 196
    .line 197
    const/4 v4, 0x3

    .line 198
    invoke-direct {v2, v0, v4}, Lmv0;-><init>(Luu0;B)V

    .line 199
    .line 200
    .line 201
    const v0, 0x615f667f

    .line 202
    .line 203
    .line 204
    invoke-static {v0, v2, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 205
    .line 206
    .line 207
    move-result-object v18

    .line 208
    const/high16 v20, 0x30000

    .line 209
    .line 210
    const/16 v21, 0x12

    .line 211
    .line 212
    const/4 v14, 0x0

    .line 213
    const/16 v17, 0x0

    .line 214
    .line 215
    move-object/from16 v19, v1

    .line 216
    .line 217
    invoke-static/range {v13 .. v21}, Lkb;->f(ZLha4;Lg32;Lz42;Ljava/lang/String;Lq21;Lki2;II)V

    .line 218
    .line 219
    .line 220
    goto :goto_5

    .line 221
    :cond_4
    move-object/from16 v19, v1

    .line 222
    .line 223
    invoke-virtual/range {v19 .. v19}, Lki2;->b0()V

    .line 224
    .line 225
    .line 226
    :goto_5
    return-object v3

    .line 227
    :pswitch_1
    move-object/from16 v12, p1

    .line 228
    .line 229
    check-cast v12, Lki2;

    .line 230
    .line 231
    move-object/from16 v1, p2

    .line 232
    .line 233
    check-cast v1, Ljava/lang/Integer;

    .line 234
    .line 235
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 236
    .line 237
    .line 238
    move-result v1

    .line 239
    and-int/lit8 v2, v1, 0x3

    .line 240
    .line 241
    if-eq v2, v4, :cond_5

    .line 242
    .line 243
    move v2, v6

    .line 244
    goto :goto_6

    .line 245
    :cond_5
    move v2, v5

    .line 246
    :goto_6
    and-int/2addr v1, v6

    .line 247
    invoke-virtual {v12, v1, v2}, Lki2;->Y(IZ)Z

    .line 248
    .line 249
    .line 250
    move-result v1

    .line 251
    if-eqz v1, :cond_a

    .line 252
    .line 253
    iget-object v1, v0, Luu0;->g:Lzd4;

    .line 254
    .line 255
    invoke-interface {v1}, Lxy6;->getValue()Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    move-result-object v1

    .line 259
    check-cast v1, Ljava/lang/String;

    .line 260
    .line 261
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 262
    .line 263
    .line 264
    move-result v1

    .line 265
    if-lez v1, :cond_9

    .line 266
    .line 267
    const v1, -0x6374213d

    .line 268
    .line 269
    .line 270
    invoke-virtual {v12, v1}, Lki2;->h0(I)V

    .line 271
    .line 272
    .line 273
    const/16 v17, 0x0

    .line 274
    .line 275
    const/16 v18, 0xa

    .line 276
    .line 277
    sget-object v13, Lea4;->h:Lea4;

    .line 278
    .line 279
    const/high16 v14, 0x40c00000    # 6.0f

    .line 280
    .line 281
    const/4 v15, 0x0

    .line 282
    const/high16 v16, 0x41000000    # 8.0f

    .line 283
    .line 284
    invoke-static/range {v13 .. v18}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 285
    .line 286
    .line 287
    move-result-object v1

    .line 288
    sget-object v2, Ly6;->m:La40;

    .line 289
    .line 290
    invoke-static {v2, v5}, Lxc0;->c(La40;Z)Ld14;

    .line 291
    .line 292
    .line 293
    move-result-object v2

    .line 294
    iget-wide v7, v12, Lki2;->U:J

    .line 295
    .line 296
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 297
    .line 298
    .line 299
    move-result v4

    .line 300
    invoke-virtual {v12}, Lki2;->m()Lr95;

    .line 301
    .line 302
    .line 303
    move-result-object v7

    .line 304
    invoke-static {v12, v1}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 305
    .line 306
    .line 307
    move-result-object v1

    .line 308
    sget-object v8, Lp41;->d:Ly6;

    .line 309
    .line 310
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 311
    .line 312
    .line 313
    invoke-virtual {v12}, Lki2;->k0()V

    .line 314
    .line 315
    .line 316
    iget-boolean v8, v12, Lki2;->T:Z

    .line 317
    .line 318
    if-eqz v8, :cond_6

    .line 319
    .line 320
    sget-object v8, Lwi3;->Z:Lj43;

    .line 321
    .line 322
    invoke-virtual {v12, v8}, Lki2;->l(Lwg2;)V

    .line 323
    .line 324
    .line 325
    goto :goto_7

    .line 326
    :cond_6
    invoke-virtual {v12}, Lki2;->t0()V

    .line 327
    .line 328
    .line 329
    :goto_7
    sget-object v8, Ly6;->T:Lu31;

    .line 330
    .line 331
    invoke-static {v8, v12, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 332
    .line 333
    .line 334
    sget-object v2, Ly6;->S:Lu31;

    .line 335
    .line 336
    invoke-static {v2, v12, v7}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 337
    .line 338
    .line 339
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 340
    .line 341
    .line 342
    move-result-object v2

    .line 343
    sget-object v4, Ly6;->U:Lu31;

    .line 344
    .line 345
    invoke-static {v4, v12, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 346
    .line 347
    .line 348
    invoke-static {v12}, Lml6;->p(Lki2;)V

    .line 349
    .line 350
    .line 351
    sget-object v2, Ly6;->R:Lu31;

    .line 352
    .line 353
    invoke-static {v2, v12, v1}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 354
    .line 355
    .line 356
    sget-object v1, Lv06;->a:Lt06;

    .line 357
    .line 358
    invoke-static {v13, v1}, Lof;->r(Lha4;Lkn6;)Lha4;

    .line 359
    .line 360
    .line 361
    move-result-object v14

    .line 362
    invoke-virtual {v12, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 363
    .line 364
    .line 365
    move-result v1

    .line 366
    invoke-virtual {v12}, Lki2;->T()Ljava/lang/Object;

    .line 367
    .line 368
    .line 369
    move-result-object v2

    .line 370
    if-nez v1, :cond_7

    .line 371
    .line 372
    sget-object v1, Lz41;->a:Lql0;

    .line 373
    .line 374
    if-ne v2, v1, :cond_8

    .line 375
    .line 376
    :cond_7
    new-instance v2, Ln7;

    .line 377
    .line 378
    const/16 v1, 0x11

    .line 379
    .line 380
    invoke-direct {v2, v0, v1}, Ln7;-><init>(Ljava/lang/Object;B)V

    .line 381
    .line 382
    .line 383
    invoke-virtual {v12, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 384
    .line 385
    .line 386
    :cond_8
    move-object/from16 v19, v2

    .line 387
    .line 388
    check-cast v19, Lwg2;

    .line 389
    .line 390
    const/16 v20, 0xf

    .line 391
    .line 392
    const/4 v15, 0x0

    .line 393
    const/16 v16, 0x0

    .line 394
    .line 395
    const/16 v17, 0x0

    .line 396
    .line 397
    const/16 v18, 0x0

    .line 398
    .line 399
    invoke-static/range {v14 .. v20}, Lix;->U(Lha4;ZLjava/lang/String;Lxz5;Lzc4;Lwg2;I)Lha4;

    .line 400
    .line 401
    .line 402
    move-result-object v9

    .line 403
    invoke-static {}, Lel;->C()La53;

    .line 404
    .line 405
    .line 406
    move-result-object v7

    .line 407
    sget-object v0, Lsz0;->a:Lcx1;

    .line 408
    .line 409
    invoke-virtual {v12, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    check-cast v0, Lrz0;

    .line 414
    .line 415
    iget-object v0, v0, Lrz0;->U:Lf75;

    .line 416
    .line 417
    invoke-virtual {v0}, Lf75;->getValue()Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    move-result-object v0

    .line 421
    check-cast v0, Ldy0;

    .line 422
    .line 423
    iget-wide v10, v0, Ldy0;->a:J

    .line 424
    .line 425
    const/16 v13, 0x30

    .line 426
    .line 427
    const/4 v14, 0x0

    .line 428
    const/4 v8, 0x0

    .line 429
    invoke-static/range {v7 .. v14}, Lr94;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 430
    .line 431
    .line 432
    invoke-virtual {v12, v6}, Lki2;->r(Z)V

    .line 433
    .line 434
    .line 435
    invoke-virtual {v12, v5}, Lki2;->r(Z)V

    .line 436
    .line 437
    .line 438
    goto :goto_8

    .line 439
    :cond_9
    const v0, -0x6368ad70

    .line 440
    .line 441
    .line 442
    invoke-virtual {v12, v0}, Lki2;->h0(I)V

    .line 443
    .line 444
    .line 445
    invoke-virtual {v12, v5}, Lki2;->r(Z)V

    .line 446
    .line 447
    .line 448
    goto :goto_8

    .line 449
    :cond_a
    invoke-virtual {v12}, Lki2;->b0()V

    .line 450
    .line 451
    .line 452
    :goto_8
    return-object v3

    .line 453
    :pswitch_2
    move-object/from16 v1, p1

    .line 454
    .line 455
    check-cast v1, Lki2;

    .line 456
    .line 457
    move-object/from16 v7, p2

    .line 458
    .line 459
    check-cast v7, Ljava/lang/Integer;

    .line 460
    .line 461
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 462
    .line 463
    .line 464
    move-result v7

    .line 465
    and-int/lit8 v8, v7, 0x3

    .line 466
    .line 467
    if-eq v8, v4, :cond_b

    .line 468
    .line 469
    move v4, v6

    .line 470
    goto :goto_9

    .line 471
    :cond_b
    move v4, v5

    .line 472
    :goto_9
    and-int/2addr v7, v6

    .line 473
    invoke-virtual {v1, v7, v4}, Lki2;->Y(IZ)Z

    .line 474
    .line 475
    .line 476
    move-result v4

    .line 477
    if-eqz v4, :cond_d

    .line 478
    .line 479
    invoke-static {}, Le53;->v()La53;

    .line 480
    .line 481
    .line 482
    move-result-object v13

    .line 483
    invoke-static {v2, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 484
    .line 485
    .line 486
    move-result-object v14

    .line 487
    invoke-virtual {v0}, Luu0;->a()Z

    .line 488
    .line 489
    .line 490
    move-result v0

    .line 491
    if-eqz v0, :cond_c

    .line 492
    .line 493
    const v0, -0x68d0e7a2

    .line 494
    .line 495
    .line 496
    invoke-virtual {v1, v0}, Lki2;->h0(I)V

    .line 497
    .line 498
    .line 499
    sget-object v0, Lq04;->b:Lcx1;

    .line 500
    .line 501
    invoke-virtual {v1, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 502
    .line 503
    .line 504
    move-result-object v0

    .line 505
    check-cast v0, Ln04;

    .line 506
    .line 507
    iget-object v0, v0, Ln04;->a:Lky0;

    .line 508
    .line 509
    iget-wide v6, v0, Lky0;->a:J

    .line 510
    .line 511
    invoke-virtual {v1, v5}, Lki2;->r(Z)V

    .line 512
    .line 513
    .line 514
    :goto_a
    move-wide/from16 v16, v6

    .line 515
    .line 516
    goto :goto_b

    .line 517
    :cond_c
    const v0, -0x68cf7744

    .line 518
    .line 519
    .line 520
    invoke-virtual {v1, v0}, Lki2;->h0(I)V

    .line 521
    .line 522
    .line 523
    sget-object v0, Lq04;->b:Lcx1;

    .line 524
    .line 525
    invoke-virtual {v1, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 526
    .line 527
    .line 528
    move-result-object v0

    .line 529
    check-cast v0, Ln04;

    .line 530
    .line 531
    iget-object v0, v0, Ln04;->a:Lky0;

    .line 532
    .line 533
    iget-wide v6, v0, Lky0;->q:J

    .line 534
    .line 535
    invoke-virtual {v1, v5}, Lki2;->r(Z)V

    .line 536
    .line 537
    .line 538
    goto :goto_a

    .line 539
    :goto_b
    const/16 v19, 0x0

    .line 540
    .line 541
    const/16 v20, 0x4

    .line 542
    .line 543
    const/4 v15, 0x0

    .line 544
    move-object/from16 v18, v1

    .line 545
    .line 546
    invoke-static/range {v13 .. v20}, Lw33;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 547
    .line 548
    .line 549
    goto :goto_c

    .line 550
    :cond_d
    move-object/from16 v18, v1

    .line 551
    .line 552
    invoke-virtual/range {v18 .. v18}, Lki2;->b0()V

    .line 553
    .line 554
    .line 555
    :goto_c
    return-object v3

    .line 556
    nop

    .line 557
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
