.class public final synthetic Lpn;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic A:Z

.field public final synthetic B:Lt66;

.field public final synthetic h:Lec6;

.field public final synthetic i:Lrk;

.field public final synthetic j:Lor7;

.field public final synthetic k:Lwg2;

.field public final synthetic l:Ldy0;

.field public final synthetic m:F

.field public final synthetic n:F

.field public final synthetic o:Lha4;

.field public final synthetic p:F

.field public final synthetic q:Lwg2;

.field public final synthetic r:Lwg2;

.field public final synthetic s:Lwg2;

.field public final synthetic t:Lwg2;

.field public final synthetic u:Llh2;

.field public final synthetic v:Z

.field public final synthetic w:Llh2;

.field public final synthetic x:Lhh2;

.field public final synthetic y:Lhh2;

.field public final synthetic z:Lwg2;


# direct methods
.method public synthetic constructor <init>(Lec6;Lrk;Lor7;Lwg2;Ldy0;FFLha4;FLwg2;Lwg2;Lwg2;Lwg2;Llh2;ZLlh2;Lhh2;Lhh2;Lwg2;ZLt66;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lpn;->h:Lec6;

    .line 5
    .line 6
    iput-object p2, p0, Lpn;->i:Lrk;

    .line 7
    .line 8
    iput-object p3, p0, Lpn;->j:Lor7;

    .line 9
    .line 10
    iput-object p4, p0, Lpn;->k:Lwg2;

    .line 11
    .line 12
    iput-object p5, p0, Lpn;->l:Ldy0;

    .line 13
    .line 14
    iput p6, p0, Lpn;->m:F

    .line 15
    .line 16
    iput p7, p0, Lpn;->n:F

    .line 17
    .line 18
    iput-object p8, p0, Lpn;->o:Lha4;

    .line 19
    .line 20
    iput p9, p0, Lpn;->p:F

    .line 21
    .line 22
    iput-object p10, p0, Lpn;->q:Lwg2;

    .line 23
    .line 24
    iput-object p11, p0, Lpn;->r:Lwg2;

    .line 25
    .line 26
    iput-object p12, p0, Lpn;->s:Lwg2;

    .line 27
    .line 28
    iput-object p13, p0, Lpn;->t:Lwg2;

    .line 29
    .line 30
    iput-object p14, p0, Lpn;->u:Llh2;

    .line 31
    .line 32
    iput-boolean p15, p0, Lpn;->v:Z

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lpn;->w:Llh2;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Lpn;->x:Lhh2;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lpn;->y:Lhh2;

    .line 45
    .line 46
    move-object/from16 p1, p19

    .line 47
    .line 48
    iput-object p1, p0, Lpn;->z:Lwg2;

    .line 49
    .line 50
    move/from16 p1, p20

    .line 51
    .line 52
    iput-boolean p1, p0, Lpn;->A:Z

    .line 53
    .line 54
    move-object/from16 p1, p21

    .line 55
    .line 56
    iput-object p1, p0, Lpn;->B:Lt66;

    .line 57
    .line 58
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lki2;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    and-int/lit8 v3, v2, 0x3

    .line 16
    .line 17
    const/4 v4, 0x2

    .line 18
    const/4 v5, 0x1

    .line 19
    if-eq v3, v4, :cond_0

    .line 20
    .line 21
    move v3, v5

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v3, 0x0

    .line 24
    :goto_0
    and-int/2addr v2, v5

    .line 25
    invoke-virtual {v1, v2, v3}, Lki2;->Y(IZ)Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_1

    .line 30
    .line 31
    new-instance v3, Lrn;

    .line 32
    .line 33
    iget-object v4, v0, Lpn;->i:Lrk;

    .line 34
    .line 35
    iget-object v5, v0, Lpn;->j:Lor7;

    .line 36
    .line 37
    iget-object v6, v0, Lpn;->k:Lwg2;

    .line 38
    .line 39
    iget-object v7, v0, Lpn;->l:Ldy0;

    .line 40
    .line 41
    iget v8, v0, Lpn;->m:F

    .line 42
    .line 43
    iget v9, v0, Lpn;->n:F

    .line 44
    .line 45
    iget-object v10, v0, Lpn;->o:Lha4;

    .line 46
    .line 47
    iget v11, v0, Lpn;->p:F

    .line 48
    .line 49
    iget-object v12, v0, Lpn;->q:Lwg2;

    .line 50
    .line 51
    iget-object v13, v0, Lpn;->r:Lwg2;

    .line 52
    .line 53
    iget-object v14, v0, Lpn;->s:Lwg2;

    .line 54
    .line 55
    iget-object v15, v0, Lpn;->t:Lwg2;

    .line 56
    .line 57
    iget-object v2, v0, Lpn;->u:Llh2;

    .line 58
    .line 59
    move-object/from16 v16, v2

    .line 60
    .line 61
    iget-boolean v2, v0, Lpn;->v:Z

    .line 62
    .line 63
    move/from16 v17, v2

    .line 64
    .line 65
    iget-object v2, v0, Lpn;->w:Llh2;

    .line 66
    .line 67
    move-object/from16 v18, v2

    .line 68
    .line 69
    iget-object v2, v0, Lpn;->x:Lhh2;

    .line 70
    .line 71
    move-object/from16 v19, v2

    .line 72
    .line 73
    iget-object v2, v0, Lpn;->y:Lhh2;

    .line 74
    .line 75
    move-object/from16 v20, v2

    .line 76
    .line 77
    iget-object v2, v0, Lpn;->z:Lwg2;

    .line 78
    .line 79
    move-object/from16 v21, v2

    .line 80
    .line 81
    iget-boolean v2, v0, Lpn;->A:Z

    .line 82
    .line 83
    move/from16 v22, v2

    .line 84
    .line 85
    iget-object v2, v0, Lpn;->B:Lt66;

    .line 86
    .line 87
    move-object/from16 v23, v2

    .line 88
    .line 89
    invoke-direct/range {v3 .. v23}, Lrn;-><init>(Lrk;Lor7;Lwg2;Ldy0;FFLha4;FLwg2;Lwg2;Lwg2;Lwg2;Llh2;ZLlh2;Lhh2;Lhh2;Lwg2;ZLt66;)V

    .line 90
    .line 91
    .line 92
    const v2, -0x119f1ba2

    .line 93
    .line 94
    .line 95
    invoke-static {v2, v3, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    const/16 v3, 0x30

    .line 100
    .line 101
    iget-object v0, v0, Lpn;->h:Lec6;

    .line 102
    .line 103
    invoke-virtual {v0, v4, v2, v1, v3}, Lec6;->b(Ljava/lang/Object;Lq21;Lki2;I)V

    .line 104
    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_1
    invoke-virtual {v1}, Lki2;->b0()V

    .line 108
    .line 109
    .line 110
    :goto_1
    sget-object v0, Los7;->a:Los7;

    .line 111
    .line 112
    return-object v0
.end method
