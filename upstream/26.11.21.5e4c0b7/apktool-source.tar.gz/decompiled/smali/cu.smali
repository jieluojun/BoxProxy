.class public final synthetic Lcu;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lqv;


# direct methods
.method public synthetic constructor <init>(Lqv;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lcu;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lcu;->i:Lqv;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 34

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lcu;->h:B

    .line 4
    .line 5
    const/16 v2, 0xf

    .line 6
    .line 7
    const/high16 v3, 0x3f800000    # 1.0f

    .line 8
    .line 9
    sget-object v4, Lea4;->h:Lea4;

    .line 10
    .line 11
    sget-object v5, Los7;->a:Los7;

    .line 12
    .line 13
    sget-object v6, Lz41;->a:Lql0;

    .line 14
    .line 15
    const/4 v7, 0x0

    .line 16
    const/16 v8, 0x10

    .line 17
    .line 18
    iget-object v0, v0, Lcu;->i:Lqv;

    .line 19
    .line 20
    const/4 v9, 0x1

    .line 21
    packed-switch v1, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    move-object/from16 v1, p1

    .line 25
    .line 26
    check-cast v1, Lj16;

    .line 27
    .line 28
    move-object/from16 v15, p2

    .line 29
    .line 30
    check-cast v15, Lki2;

    .line 31
    .line 32
    move-object/from16 v2, p3

    .line 33
    .line 34
    check-cast v2, Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    and-int/lit8 v1, v2, 0x11

    .line 44
    .line 45
    if-eq v1, v8, :cond_0

    .line 46
    .line 47
    move v7, v9

    .line 48
    :cond_0
    and-int/2addr v2, v9

    .line 49
    invoke-virtual {v15, v2, v7}, Lki2;->Y(IZ)Z

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    if-eqz v1, :cond_3

    .line 54
    .line 55
    iget-object v1, v0, Lqv;->d:Lzd4;

    .line 56
    .line 57
    invoke-interface {v1}, Lxy6;->getValue()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    check-cast v1, Ljava/lang/Boolean;

    .line 62
    .line 63
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 64
    .line 65
    .line 66
    move-result v10

    .line 67
    invoke-virtual {v15, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    invoke-virtual {v15}, Lki2;->T()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    if-nez v1, :cond_1

    .line 76
    .line 77
    if-ne v2, v6, :cond_2

    .line 78
    .line 79
    :cond_1
    new-instance v2, Lku;

    .line 80
    .line 81
    const/16 v1, 0x8

    .line 82
    .line 83
    invoke-direct {v2, v0, v1}, Lku;-><init>(Lqv;B)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v15, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    :cond_2
    move-object v11, v2

    .line 90
    check-cast v11, Lhh2;

    .line 91
    .line 92
    const/16 v16, 0x0

    .line 93
    .line 94
    const/16 v17, 0x1c

    .line 95
    .line 96
    const/4 v12, 0x0

    .line 97
    const/4 v13, 0x0

    .line 98
    const/4 v14, 0x0

    .line 99
    invoke-static/range {v10 .. v17}, Lpk6;->c(ZLhh2;Lha4;Lv57;ZLki2;II)V

    .line 100
    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_3
    invoke-virtual {v15}, Lki2;->b0()V

    .line 104
    .line 105
    .line 106
    :goto_0
    return-object v5

    .line 107
    :pswitch_0
    move-object/from16 v1, p1

    .line 108
    .line 109
    check-cast v1, Lm01;

    .line 110
    .line 111
    move-object/from16 v2, p2

    .line 112
    .line 113
    check-cast v2, Lki2;

    .line 114
    .line 115
    move-object/from16 v3, p3

    .line 116
    .line 117
    check-cast v3, Ljava/lang/Integer;

    .line 118
    .line 119
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 120
    .line 121
    .line 122
    move-result v3

    .line 123
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 124
    .line 125
    .line 126
    and-int/lit8 v1, v3, 0x11

    .line 127
    .line 128
    if-eq v1, v8, :cond_4

    .line 129
    .line 130
    move v7, v9

    .line 131
    :cond_4
    and-int/2addr v3, v9

    .line 132
    invoke-virtual {v2, v3, v7}, Lki2;->Y(IZ)Z

    .line 133
    .line 134
    .line 135
    move-result v1

    .line 136
    if-eqz v1, :cond_7

    .line 137
    .line 138
    const v1, 0x7f0f0049

    .line 139
    .line 140
    .line 141
    invoke-static {v1, v2}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v11

    .line 145
    new-instance v1, Lcu;

    .line 146
    .line 147
    const/4 v3, 0x3

    .line 148
    invoke-direct {v1, v0, v3}, Lcu;-><init>(Lqv;B)V

    .line 149
    .line 150
    .line 151
    const v3, -0x7f59fd5a

    .line 152
    .line 153
    .line 154
    invoke-static {v3, v1, v2}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 155
    .line 156
    .line 157
    move-result-object v16

    .line 158
    invoke-virtual {v2, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    move-result v1

    .line 162
    invoke-virtual {v2}, Lki2;->T()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v3

    .line 166
    if-nez v1, :cond_5

    .line 167
    .line 168
    if-ne v3, v6, :cond_6

    .line 169
    .line 170
    :cond_5
    new-instance v3, Lfu;

    .line 171
    .line 172
    const/16 v1, 0xc

    .line 173
    .line 174
    invoke-direct {v3, v0, v1}, Lfu;-><init>(Lqv;B)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v2, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    :cond_6
    move-object/from16 v19, v3

    .line 181
    .line 182
    check-cast v19, Lwg2;

    .line 183
    .line 184
    const/16 v26, 0x0

    .line 185
    .line 186
    const/16 v27, 0x7dbd

    .line 187
    .line 188
    const/4 v10, 0x0

    .line 189
    const/4 v12, 0x0

    .line 190
    const/4 v13, 0x0

    .line 191
    const/4 v14, 0x0

    .line 192
    const/4 v15, 0x0

    .line 193
    const/16 v17, 0x0

    .line 194
    .line 195
    const/16 v18, 0x0

    .line 196
    .line 197
    const/16 v20, 0x0

    .line 198
    .line 199
    const/16 v21, 0x0

    .line 200
    .line 201
    const/16 v22, 0x0

    .line 202
    .line 203
    const/16 v23, 0x0

    .line 204
    .line 205
    const/high16 v25, 0x180000

    .line 206
    .line 207
    move-object/from16 v24, v2

    .line 208
    .line 209
    invoke-static/range {v10 .. v27}, Lof;->d(Lha4;Ljava/lang/String;Lp10;Ljava/lang/String;Lp10;Llh2;Lmh2;Lq21;Lu35;Lwg2;Lxz5;ZZLzc4;Lki2;III)V

    .line 210
    .line 211
    .line 212
    goto :goto_1

    .line 213
    :cond_7
    move-object/from16 v24, v2

    .line 214
    .line 215
    invoke-virtual/range {v24 .. v24}, Lki2;->b0()V

    .line 216
    .line 217
    .line 218
    :goto_1
    return-object v5

    .line 219
    :pswitch_1
    move-object/from16 v1, p1

    .line 220
    .line 221
    check-cast v1, Lpi;

    .line 222
    .line 223
    move-object/from16 v10, p2

    .line 224
    .line 225
    check-cast v10, Lki2;

    .line 226
    .line 227
    move-object/from16 v11, p3

    .line 228
    .line 229
    check-cast v11, Ljava/lang/Integer;

    .line 230
    .line 231
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 232
    .line 233
    .line 234
    move-result v11

    .line 235
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 236
    .line 237
    .line 238
    and-int/lit8 v1, v11, 0x11

    .line 239
    .line 240
    if-eq v1, v8, :cond_8

    .line 241
    .line 242
    move v7, v9

    .line 243
    :cond_8
    and-int/2addr v11, v9

    .line 244
    invoke-virtual {v10, v11, v7}, Lki2;->Y(IZ)Z

    .line 245
    .line 246
    .line 247
    move-result v1

    .line 248
    if-eqz v1, :cond_e

    .line 249
    .line 250
    iget-object v1, v0, Lqv;->b:Lzd4;

    .line 251
    .line 252
    invoke-interface {v1}, Lxy6;->getValue()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v1

    .line 256
    check-cast v1, Ljava/lang/String;

    .line 257
    .line 258
    invoke-virtual {v10, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v7

    .line 262
    invoke-virtual {v10}, Lki2;->T()Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object v8

    .line 266
    if-nez v7, :cond_9

    .line 267
    .line 268
    if-ne v8, v6, :cond_a

    .line 269
    .line 270
    :cond_9
    new-instance v8, Lku;

    .line 271
    .line 272
    const/4 v7, 0x6

    .line 273
    invoke-direct {v8, v0, v7}, Lku;-><init>(Lqv;B)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v10, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 277
    .line 278
    .line 279
    :cond_a
    move-object v11, v8

    .line 280
    check-cast v11, Lhh2;

    .line 281
    .line 282
    invoke-virtual {v10}, Lki2;->T()Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v7

    .line 286
    if-ne v7, v6, :cond_b

    .line 287
    .line 288
    new-instance v7, Lli;

    .line 289
    .line 290
    const/16 v8, 0xa

    .line 291
    .line 292
    invoke-direct {v7, v8}, Lli;-><init>(B)V

    .line 293
    .line 294
    .line 295
    invoke-virtual {v10, v7}, Lki2;->q0(Ljava/lang/Object;)V

    .line 296
    .line 297
    .line 298
    :cond_b
    move-object v12, v7

    .line 299
    check-cast v12, Lhh2;

    .line 300
    .line 301
    invoke-virtual {v0}, Lqv;->f()Z

    .line 302
    .line 303
    .line 304
    move-result v13

    .line 305
    invoke-virtual {v10, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 306
    .line 307
    .line 308
    move-result v7

    .line 309
    invoke-virtual {v10}, Lki2;->T()Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v8

    .line 313
    if-nez v7, :cond_c

    .line 314
    .line 315
    if-ne v8, v6, :cond_d

    .line 316
    .line 317
    :cond_c
    new-instance v8, Lku;

    .line 318
    .line 319
    const/4 v6, 0x7

    .line 320
    invoke-direct {v8, v0, v6}, Lku;-><init>(Lqv;B)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v10, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 324
    .line 325
    .line 326
    :cond_d
    move-object v14, v8

    .line 327
    check-cast v14, Lhh2;

    .line 328
    .line 329
    invoke-static {v4, v3}, Lit6;->e(Lha4;F)Lha4;

    .line 330
    .line 331
    .line 332
    move-result-object v0

    .line 333
    sget-object v3, La28;->w:Ljava/util/WeakHashMap;

    .line 334
    .line 335
    invoke-static {v10}, Lzi6;->i(Lki2;)La28;

    .line 336
    .line 337
    .line 338
    move-result-object v3

    .line 339
    iget-object v3, v3, La28;->g:Lpg;

    .line 340
    .line 341
    invoke-static {v10}, Lzi6;->i(Lki2;)La28;

    .line 342
    .line 343
    .line 344
    move-result-object v4

    .line 345
    iget-object v4, v4, La28;->b:Lpg;

    .line 346
    .line 347
    new-instance v6, Lp7;

    .line 348
    .line 349
    invoke-direct {v6, v3, v4}, Lp7;-><init>(Lt08;Lt08;)V

    .line 350
    .line 351
    .line 352
    new-instance v3, Lro3;

    .line 353
    .line 354
    invoke-direct {v3, v6, v2}, Lro3;-><init>(Lt08;I)V

    .line 355
    .line 356
    .line 357
    invoke-static {v0, v3}, Lnt7;->d0(Lha4;Lt08;)Lha4;

    .line 358
    .line 359
    .line 360
    move-result-object v15

    .line 361
    const/high16 v19, 0x41000000    # 8.0f

    .line 362
    .line 363
    const/16 v20, 0x2

    .line 364
    .line 365
    const/high16 v16, 0x41400000    # 12.0f

    .line 366
    .line 367
    const/16 v17, 0x0

    .line 368
    .line 369
    move/from16 v18, v16

    .line 370
    .line 371
    invoke-static/range {v15 .. v20}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 372
    .line 373
    .line 374
    move-result-object v15

    .line 375
    const v0, 0x7f0f004a

    .line 376
    .line 377
    .line 378
    invoke-static {v0, v10}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v16

    .line 382
    const/16 v24, 0x0

    .line 383
    .line 384
    const/16 v25, 0x3f80

    .line 385
    .line 386
    const/16 v17, 0x0

    .line 387
    .line 388
    const-wide/16 v18, 0x0

    .line 389
    .line 390
    const/16 v20, 0x0

    .line 391
    .line 392
    const/16 v21, 0x0

    .line 393
    .line 394
    const/16 v23, 0x180

    .line 395
    .line 396
    move-object/from16 v22, v10

    .line 397
    .line 398
    move-object v10, v1

    .line 399
    invoke-static/range {v10 .. v25}, Le53;->f(Ljava/lang/String;Lhh2;Lhh2;ZLhh2;Lha4;Ljava/lang/String;ZJLzc4;Lt32;Lki2;III)V

    .line 400
    .line 401
    .line 402
    goto :goto_2

    .line 403
    :cond_e
    move-object/from16 v22, v10

    .line 404
    .line 405
    invoke-virtual/range {v22 .. v22}, Lki2;->b0()V

    .line 406
    .line 407
    .line 408
    :goto_2
    return-object v5

    .line 409
    :pswitch_2
    move-object/from16 v1, p1

    .line 410
    .line 411
    check-cast v1, Lpi;

    .line 412
    .line 413
    move-object/from16 v10, p2

    .line 414
    .line 415
    check-cast v10, Lki2;

    .line 416
    .line 417
    move-object/from16 v11, p3

    .line 418
    .line 419
    check-cast v11, Ljava/lang/Integer;

    .line 420
    .line 421
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 422
    .line 423
    .line 424
    move-result v11

    .line 425
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 426
    .line 427
    .line 428
    and-int/lit8 v1, v11, 0x11

    .line 429
    .line 430
    if-eq v1, v8, :cond_f

    .line 431
    .line 432
    move v7, v9

    .line 433
    :cond_f
    and-int/2addr v11, v9

    .line 434
    invoke-virtual {v10, v11, v7}, Lki2;->Y(IZ)Z

    .line 435
    .line 436
    .line 437
    move-result v1

    .line 438
    if-eqz v1, :cond_12

    .line 439
    .line 440
    iget-object v1, v0, Lqv;->b:Lzd4;

    .line 441
    .line 442
    invoke-interface {v1}, Lxy6;->getValue()Ljava/lang/Object;

    .line 443
    .line 444
    .line 445
    move-result-object v1

    .line 446
    check-cast v1, Ljava/lang/String;

    .line 447
    .line 448
    invoke-static {v4, v3}, Lit6;->e(Lha4;F)Lha4;

    .line 449
    .line 450
    .line 451
    move-result-object v3

    .line 452
    sget-object v4, La28;->w:Ljava/util/WeakHashMap;

    .line 453
    .line 454
    invoke-static {v10}, Lzi6;->i(Lki2;)La28;

    .line 455
    .line 456
    .line 457
    move-result-object v4

    .line 458
    iget-object v4, v4, La28;->l:Lls7;

    .line 459
    .line 460
    invoke-static {v4, v2, v3}, Lx82;->h(Lls7;ILha4;)Lha4;

    .line 461
    .line 462
    .line 463
    move-result-object v11

    .line 464
    const/high16 v15, 0x41000000    # 8.0f

    .line 465
    .line 466
    const/16 v16, 0x2

    .line 467
    .line 468
    const/high16 v12, 0x41800000    # 16.0f

    .line 469
    .line 470
    const/4 v13, 0x0

    .line 471
    move v14, v12

    .line 472
    invoke-static/range {v11 .. v16}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 473
    .line 474
    .line 475
    move-result-object v12

    .line 476
    const/high16 v2, 0x41e00000    # 28.0f

    .line 477
    .line 478
    invoke-static {v2}, Lv06;->a(F)Lt06;

    .line 479
    .line 480
    .line 481
    move-result-object v28

    .line 482
    invoke-virtual {v10, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 483
    .line 484
    .line 485
    move-result v2

    .line 486
    invoke-virtual {v10}, Lki2;->T()Ljava/lang/Object;

    .line 487
    .line 488
    .line 489
    move-result-object v3

    .line 490
    if-nez v2, :cond_10

    .line 491
    .line 492
    if-ne v3, v6, :cond_11

    .line 493
    .line 494
    :cond_10
    new-instance v3, Lku;

    .line 495
    .line 496
    invoke-direct {v3, v0, v9}, Lku;-><init>(Lqv;B)V

    .line 497
    .line 498
    .line 499
    invoke-virtual {v10, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 500
    .line 501
    .line 502
    :cond_11
    move-object v11, v3

    .line 503
    check-cast v11, Lhh2;

    .line 504
    .line 505
    sget-object v17, Ljb3;->j:Lq21;

    .line 506
    .line 507
    new-instance v2, Ldu;

    .line 508
    .line 509
    invoke-direct {v2, v0, v9}, Ldu;-><init>(Lqv;B)V

    .line 510
    .line 511
    .line 512
    const v0, 0x7deefa4c

    .line 513
    .line 514
    .line 515
    invoke-static {v0, v2, v10}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 516
    .line 517
    .line 518
    move-result-object v18

    .line 519
    const/16 v32, 0x6000

    .line 520
    .line 521
    const v33, 0x17bcf8    # 2.180006E-39f

    .line 522
    .line 523
    .line 524
    const/4 v13, 0x0

    .line 525
    const/4 v14, 0x0

    .line 526
    const/4 v15, 0x0

    .line 527
    const/16 v16, 0x0

    .line 528
    .line 529
    const/16 v19, 0x0

    .line 530
    .line 531
    const/16 v20, 0x0

    .line 532
    .line 533
    const/16 v21, 0x0

    .line 534
    .line 535
    const/16 v22, 0x0

    .line 536
    .line 537
    const/16 v23, 0x1

    .line 538
    .line 539
    const/16 v24, 0x0

    .line 540
    .line 541
    const/16 v25, 0x0

    .line 542
    .line 543
    const/16 v26, 0x0

    .line 544
    .line 545
    const/16 v27, 0x0

    .line 546
    .line 547
    const/16 v29, 0x0

    .line 548
    .line 549
    const/high16 v31, 0x36000000

    .line 550
    .line 551
    move-object/from16 v30, v10

    .line 552
    .line 553
    move-object v10, v1

    .line 554
    invoke-static/range {v10 .. v33}, Lz33;->d(Ljava/lang/String;Lhh2;Lha4;ZLwg7;Llh2;Llh2;Llh2;Lq21;Lq21;ZLrg3;Lpg3;ZIILt32;Lt32;Lkn6;Lbb7;Lki2;III)V

    .line 555
    .line 556
    .line 557
    goto :goto_3

    .line 558
    :cond_12
    move-object/from16 v30, v10

    .line 559
    .line 560
    invoke-virtual/range {v30 .. v30}, Lki2;->b0()V

    .line 561
    .line 562
    .line 563
    :goto_3
    return-object v5

    .line 564
    nop

    .line 565
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
