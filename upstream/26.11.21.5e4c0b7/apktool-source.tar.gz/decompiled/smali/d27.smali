.class public final synthetic Ld27;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/util/List;

.field public final synthetic j:Lay7;

.field public final synthetic k:Lzd4;

.field public final synthetic l:Lzd4;

.field public final synthetic m:Ljava/util/ArrayList;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lay7;Lzd4;Lzd4;Ljava/util/ArrayList;B)V
    .locals 0

    .line 1
    iput-byte p6, p0, Ld27;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Ld27;->i:Ljava/util/List;

    .line 4
    .line 5
    iput-object p2, p0, Ld27;->j:Lay7;

    .line 6
    .line 7
    iput-object p3, p0, Ld27;->k:Lzd4;

    .line 8
    .line 9
    iput-object p4, p0, Ld27;->l:Lzd4;

    .line 10
    .line 11
    iput-object p5, p0, Ld27;->m:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-byte v0, p0, Ld27;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x0

    .line 7
    iget-object v4, p0, Ld27;->i:Ljava/util/List;

    .line 8
    .line 9
    const/4 v5, 0x1

    .line 10
    check-cast p1, Lhm3;

    .line 11
    .line 12
    packed-switch v0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    new-instance v0, Lq17;

    .line 19
    .line 20
    iget-object v10, p0, Ld27;->j:Lay7;

    .line 21
    .line 22
    iget-object v7, p0, Ld27;->k:Lzd4;

    .line 23
    .line 24
    invoke-direct {v0, v4, v10, v7, v5}, Lq17;-><init>(Ljava/util/List;Lay7;Lzd4;B)V

    .line 25
    .line 26
    .line 27
    new-instance v4, Lq21;

    .line 28
    .line 29
    const v6, -0x2494f0d9

    .line 30
    .line 31
    .line 32
    invoke-direct {v4, v6, v5, v0}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    invoke-static {p1, v3, v4, v2}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 36
    .line 37
    .line 38
    new-instance v6, Lr17;

    .line 39
    .line 40
    const/4 v11, 0x1

    .line 41
    iget-object v8, p0, Ld27;->l:Lzd4;

    .line 42
    .line 43
    iget-object v9, p0, Ld27;->m:Ljava/util/ArrayList;

    .line 44
    .line 45
    invoke-direct/range {v6 .. v11}, Lr17;-><init>(Lzd4;Lzd4;Ljava/util/ArrayList;Lay7;B)V

    .line 46
    .line 47
    .line 48
    new-instance p0, Lq21;

    .line 49
    .line 50
    const v0, -0x7bb796b0

    .line 51
    .line 52
    .line 53
    invoke-direct {p0, v0, v5, v6}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-static {p1, v3, p0, v2}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 57
    .line 58
    .line 59
    return-object v1

    .line 60
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    new-instance v0, Lq17;

    .line 64
    .line 65
    const/4 v6, 0x0

    .line 66
    iget-object v11, p0, Ld27;->j:Lay7;

    .line 67
    .line 68
    iget-object v8, p0, Ld27;->k:Lzd4;

    .line 69
    .line 70
    invoke-direct {v0, v4, v11, v8, v6}, Lq17;-><init>(Ljava/util/List;Lay7;Lzd4;B)V

    .line 71
    .line 72
    .line 73
    new-instance v4, Lq21;

    .line 74
    .line 75
    const v6, -0x7657101f

    .line 76
    .line 77
    .line 78
    invoke-direct {v4, v6, v5, v0}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    invoke-static {p1, v3, v4, v2}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 82
    .line 83
    .line 84
    new-instance v7, Lr17;

    .line 85
    .line 86
    const/4 v12, 0x0

    .line 87
    iget-object v9, p0, Ld27;->l:Lzd4;

    .line 88
    .line 89
    iget-object v10, p0, Ld27;->m:Ljava/util/ArrayList;

    .line 90
    .line 91
    invoke-direct/range {v7 .. v12}, Lr17;-><init>(Lzd4;Lzd4;Ljava/util/ArrayList;Lay7;B)V

    .line 92
    .line 93
    .line 94
    new-instance p0, Lq21;

    .line 95
    .line 96
    const v0, -0x3d85b8b6

    .line 97
    .line 98
    .line 99
    invoke-direct {p0, v0, v5, v7}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    invoke-static {p1, v3, p0, v2}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 103
    .line 104
    .line 105
    return-object v1

    .line 106
    nop

    .line 107
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
