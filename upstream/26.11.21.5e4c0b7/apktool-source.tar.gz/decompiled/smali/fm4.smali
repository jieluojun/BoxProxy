.class public final synthetic Lfm4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lfp4;

.field public final synthetic j:I

.field public final synthetic k:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lfp4;ILzd4;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lfm4;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lfm4;->i:Lfp4;

    .line 4
    .line 5
    iput p2, p0, Lfm4;->j:I

    .line 6
    .line 7
    iput-object p3, p0, Lfm4;->k:Lzd4;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 7

    .line 1
    iget-byte v0, p0, Lfm4;->h:B

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    const/4 v2, 0x0

    .line 5
    sget-object v3, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    iget-object v5, p0, Lfm4;->k:Lzd4;

    .line 9
    .line 10
    iget v6, p0, Lfm4;->j:I

    .line 11
    .line 12
    iget-object p0, p0, Lfm4;->i:Lfp4;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0, v6}, Lfp4;->c(I)V

    .line 18
    .line 19
    .line 20
    invoke-interface {v5, v4}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    return-object v3

    .line 24
    :pswitch_0
    new-instance v0, Liw;

    .line 25
    .line 26
    invoke-direct {v0, v6, v1}, Liw;-><init>(IB)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0, v2, v0}, Lfp4;->e(ILhh2;)V

    .line 30
    .line 31
    .line 32
    invoke-interface {v5, v4}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    return-object v3

    .line 36
    :pswitch_1
    new-instance v0, Liw;

    .line 37
    .line 38
    invoke-direct {v0, v6, v1}, Liw;-><init>(IB)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0, v2, v0}, Lfp4;->e(ILhh2;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {v5, v4}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    return-object v3

    .line 48
    nop

    .line 49
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
