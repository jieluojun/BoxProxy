.class final Lnr1;
.super Lpa4;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lpa4;"
    }
.end annotation


# instance fields
.field public final h:Lo50;


# direct methods
.method public constructor <init>(Lo50;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lnr1;->h:Lo50;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lga4;
    .locals 1

    .line 1
    new-instance v0, Lor1;

    .line 2
    .line 3
    invoke-direct {v0}, Lga4;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lnr1;->h:Lo50;

    .line 7
    .line 8
    iput-object p0, v0, Lor1;->v:Lo50;

    .line 9
    .line 10
    return-object v0
.end method

.method public final b(Lga4;)V
    .locals 2

    .line 1
    check-cast p1, Lor1;

    .line 2
    .line 3
    iget-object v0, p1, Lor1;->v:Lo50;

    .line 4
    .line 5
    iget-object p0, p0, Lnr1;->h:Lo50;

    .line 6
    .line 7
    invoke-static {v0, p0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iget-object v0, p1, Lga4;->h:Lga4;

    .line 14
    .line 15
    iget-boolean v0, v0, Lga4;->u:Z

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object v0, p1, Lor1;->v:Lo50;

    .line 20
    .line 21
    invoke-virtual {v0}, Lo50;->g()V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x0

    .line 25
    iput-object v1, v0, Lo50;->b:Ljava/lang/Object;

    .line 26
    .line 27
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    iput-object p0, p1, Lor1;->v:Lo50;

    .line 31
    .line 32
    :cond_0
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lnr1;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lnr1;

    .line 12
    .line 13
    iget-object p0, p0, Lnr1;->h:Lo50;

    .line 14
    .line 15
    iget-object p1, p1, Lnr1;->h:Lo50;

    .line 16
    .line 17
    invoke-static {p0, p1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-nez p0, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    return v0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lnr1;->h:Lo50;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "DisplayingDisappearingItemsElement(animator="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Lnr1;->h:Lo50;

    .line 9
    .line 10
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string p0, ")"

    .line 14
    .line 15
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0
.end method
