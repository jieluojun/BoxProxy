.class public final Llw;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final g:Ln28;

.field public static final h:Lcd1;

.field public static volatile i:Llw;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lor;

.field public final c:Laz6;

.field public final d:Loe4;

.field public final e:Ljava/util/concurrent/atomic/AtomicLong;

.field public final f:Ldt5;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ln28;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ln28;-><init>(B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Llw;->g:Ln28;

    .line 9
    .line 10
    sget-object v0, Lss;->a:Lcd1;

    .line 11
    .line 12
    sput-object v0, Llw;->h:Lcd1;

    .line 13
    .line 14
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, Llw;->a:Landroid/content/Context;

    .line 9
    .line 10
    new-instance v0, Lor;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lor;-><init>(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Llw;->b:Lor;

    .line 16
    .line 17
    invoke-virtual {v0}, Lor;->v()Lgw;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-static {p1}, Lkb;->k(Ljava/lang/Object;)Laz6;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iput-object p1, p0, Llw;->c:Laz6;

    .line 26
    .line 27
    new-instance v0, Loe4;

    .line 28
    .line 29
    invoke-direct {v0}, Loe4;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Llw;->d:Loe4;

    .line 33
    .line 34
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 35
    .line 36
    const-wide/16 v1, 0x0

    .line 37
    .line 38
    invoke-direct {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    .line 39
    .line 40
    .line 41
    iput-object v0, p0, Llw;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 42
    .line 43
    invoke-static {p1}, Lwi;->n(Laz6;)Ldt5;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iput-object v0, p0, Llw;->f:Ldt5;

    .line 48
    .line 49
    invoke-virtual {p1}, Laz6;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    check-cast p1, Lgw;

    .line 54
    .line 55
    iget-object p1, p1, Lgw;->b:Lct;

    .line 56
    .line 57
    invoke-virtual {p0, p1}, Llw;->a(Lct;)V

    .line 58
    .line 59
    .line 60
    return-void
.end method


# virtual methods
.method public final a(Lct;)V
    .locals 6

    .line 1
    iget-object p1, p1, Lct;->i:Ljava/lang/String;

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    sget-object p1, Lct;->j:Ln28;

    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-static {}, Ln28;->r()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    :cond_0
    move-object v4, p1

    .line 15
    iget-object p1, p0, Llw;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 18
    .line 19
    .line 20
    move-result-wide v2

    .line 21
    new-instance v0, Lkw;

    .line 22
    .line 23
    const/4 v5, 0x0

    .line 24
    move-object v1, p0

    .line 25
    invoke-direct/range {v0 .. v5}, Lkw;-><init>(Llw;JLjava/lang/String;Lfd1;)V

    .line 26
    .line 27
    .line 28
    const/4 p0, 0x3

    .line 29
    sget-object p1, Llw;->h:Lcd1;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    invoke-static {p1, v1, v1, v0, p0}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final b(Lqx2;)V
    .locals 2

    .line 1
    new-instance v0, Lx2;

    .line 2
    .line 3
    const/16 v1, 0x12

    .line 4
    .line 5
    invoke-direct {v0, p1, v1}, Lx2;-><init>(Ljava/lang/Object;B)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, v0}, Llw;->c(Lhh2;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final declared-synchronized c(Lhh2;)V
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Llw;->c:Laz6;

    .line 3
    .line 4
    invoke-virtual {v0}, Laz6;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lgw;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lgw;

    .line 15
    .line 16
    invoke-static {p1, v0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    monitor-exit p0

    .line 23
    return-void

    .line 24
    :cond_0
    :try_start_1
    iget-object v1, p0, Llw;->c:Laz6;

    .line 25
    .line 26
    invoke-virtual {v1, p1}, Laz6;->i(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object v1, p0, Llw;->b:Lor;

    .line 30
    .line 31
    invoke-virtual {v1, v0, p1}, Lor;->G(Lgw;Lgw;)V

    .line 32
    .line 33
    .line 34
    iget-object v1, p1, Lgw;->j:Let4;

    .line 35
    .line 36
    iget-object v2, v0, Lgw;->j:Let4;

    .line 37
    .line 38
    if-eq v1, v2, :cond_1

    .line 39
    .line 40
    sget-object v1, Ly6;->L:Ly6;

    .line 41
    .line 42
    iget-object v2, p0, Llw;->a:Landroid/content/Context;

    .line 43
    .line 44
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    iget-object v3, p1, Lgw;->j:Let4;

    .line 48
    .line 49
    invoke-virtual {v1, v2, v3}, Ly6;->F(Landroid/content/Context;Let4;)V

    .line 50
    .line 51
    .line 52
    :cond_1
    iget-object p1, p1, Lgw;->b:Lct;

    .line 53
    .line 54
    iget-object v0, v0, Lgw;->b:Lct;

    .line 55
    .line 56
    if-eq p1, v0, :cond_2

    .line 57
    .line 58
    invoke-virtual {p0, p1}, Llw;->a(Lct;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 59
    .line 60
    .line 61
    :cond_2
    monitor-exit p0

    .line 62
    return-void

    .line 63
    :goto_0
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 64
    throw p1

    .line 65
    :catchall_0
    move-exception p1

    .line 66
    goto :goto_0
.end method
