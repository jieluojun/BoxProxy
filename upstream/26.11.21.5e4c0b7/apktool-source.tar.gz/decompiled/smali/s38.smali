.class public Ls38;
.super Ljava/lang/RuntimeException;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"
