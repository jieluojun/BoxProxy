.class public Lv12;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lch3;


# static fields
.field public static final a:Lic6;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lic6;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lic6;-><init>(Lf67;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lv12;->a:Lic6;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public a()Lz4;
    .locals 0

    .line 1
    sget-object p0, Lu12;->c:Lu12;

    .line 2
    .line 3
    return-object p0
.end method

.method public final b()I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public c(Lpc1;Lmp0;Lo11;Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method

.method public d()[Lsr4;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    new-array p0, p0, [Lsr4;

    .line 3
    .line 4
    return-object p0
.end method

.method public destroy()V
    .locals 0

    .line 1
    return-void
.end method

.method public final e(Lpc1;II)I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final f()Lp12;
    .locals 0

    .line 1
    sget-object p0, Lp12;->l:Lp12;

    .line 2
    .line 3
    return-object p0
.end method

.method public g()Lic6;
    .locals 0

    .line 1
    sget-object p0, Lv12;->a:Lic6;

    .line 2
    .line 3
    return-object p0
.end method

.method public h()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
