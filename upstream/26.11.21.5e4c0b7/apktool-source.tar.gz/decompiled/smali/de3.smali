.class public final Lde3;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# virtual methods
.method public final serializer()Ldg3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ldg3;"
        }
    .end annotation

    .line 1
    sget-object p0, Lje3;->a:Lje3;

    .line 2
    .line 3
    return-object p0
.end method
