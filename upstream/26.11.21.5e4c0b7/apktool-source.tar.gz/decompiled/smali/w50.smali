.class public final synthetic Lw50;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Z

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/util/List;Z)V
    .locals 0

    .line 1
    const/4 p1, 0x3

    .line 2
    iput-byte p1, p0, Lw50;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-boolean p3, p0, Lw50;->i:Z

    .line 8
    .line 9
    iput-object p2, p0, Lw50;->j:Ljava/lang/Object;

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ZB)V
    .locals 0

    .line 13
    iput-byte p3, p0, Lw50;->h:B

    iput-object p1, p0, Lw50;->j:Ljava/lang/Object;

    iput-boolean p2, p0, Lw50;->i:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lz06;ZI)V
    .locals 0

    .line 12
    const/4 p3, 0x6

    iput-byte p3, p0, Lw50;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lw50;->j:Ljava/lang/Object;

    iput-boolean p2, p0, Lw50;->i:Z

    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/Object;B)V
    .locals 0

    .line 14
    iput-byte p3, p0, Lw50;->h:B

    iput-boolean p1, p0, Lw50;->i:Z

    iput-object p2, p0, Lw50;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 42

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lw50;->h:B

    .line 4
    .line 5
    const/high16 v5, 0x3f800000    # 1.0f

    .line 6
    .line 7
    const/high16 v6, 0x41500000    # 13.0f

    .line 8
    .line 9
    const v7, 0x3fa51eb8    # 1.29f

    .line 10
    .line 11
    .line 12
    const/high16 v8, 0x40400000    # 3.0f

    .line 13
    .line 14
    sget-object v9, Lz41;->a:Lql0;

    .line 15
    .line 16
    const/high16 v10, 0x41400000    # 12.0f

    .line 17
    .line 18
    const-wide/high16 v11, -0x100000000000000L

    .line 19
    .line 20
    iget-boolean v13, v0, Lw50;->i:Z

    .line 21
    .line 22
    sget-object v14, Los7;->a:Los7;

    .line 23
    .line 24
    const/4 v15, 0x2

    .line 25
    const/16 v16, 0x6

    .line 26
    .line 27
    const/16 v17, 0x3

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    iget-object v3, v0, Lw50;->j:Ljava/lang/Object;

    .line 31
    .line 32
    const/4 v4, 0x1

    .line 33
    packed-switch v1, :pswitch_data_0

    .line 34
    .line 35
    .line 36
    check-cast v3, Lho6;

    .line 37
    .line 38
    move-object/from16 v1, p1

    .line 39
    .line 40
    check-cast v1, Lki2;

    .line 41
    .line 42
    move-object/from16 v5, p2

    .line 43
    .line 44
    check-cast v5, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 47
    .line 48
    .line 49
    move-result v5

    .line 50
    and-int/lit8 v6, v5, 0x3

    .line 51
    .line 52
    if-eq v6, v15, :cond_0

    .line 53
    .line 54
    move v6, v4

    .line 55
    goto :goto_0

    .line 56
    :cond_0
    move v6, v2

    .line 57
    :goto_0
    and-int/2addr v5, v4

    .line 58
    invoke-virtual {v1, v5, v6}, Lki2;->Y(IZ)Z

    .line 59
    .line 60
    .line 61
    move-result v4

    .line 62
    if-eqz v4, :cond_3

    .line 63
    .line 64
    const v4, 0x7f0f048f

    .line 65
    .line 66
    .line 67
    invoke-static {v4, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v16

    .line 71
    invoke-virtual {v3}, Lho6;->a()Z

    .line 72
    .line 73
    .line 74
    move-result v18

    .line 75
    iget-boolean v0, v0, Lw50;->i:Z

    .line 76
    .line 77
    invoke-virtual {v1, v0}, Lki2;->h(Z)Z

    .line 78
    .line 79
    .line 80
    move-result v4

    .line 81
    invoke-virtual {v1, v3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v5

    .line 85
    or-int/2addr v4, v5

    .line 86
    invoke-virtual {v1}, Lki2;->T()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    if-nez v4, :cond_1

    .line 91
    .line 92
    if-ne v5, v9, :cond_2

    .line 93
    .line 94
    :cond_1
    new-instance v5, Lmo6;

    .line 95
    .line 96
    invoke-direct {v5, v2, v3, v0}, Lmo6;-><init>(BLho6;Z)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v1, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    :cond_2
    move-object/from16 v20, v5

    .line 103
    .line 104
    check-cast v20, Lhh2;

    .line 105
    .line 106
    const/16 v22, 0x0

    .line 107
    .line 108
    const/16 v23, 0xe

    .line 109
    .line 110
    const/16 v17, 0x0

    .line 111
    .line 112
    move/from16 v19, v0

    .line 113
    .line 114
    move-object/from16 v21, v1

    .line 115
    .line 116
    invoke-static/range {v16 .. v23}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 117
    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_3
    move-object/from16 v21, v1

    .line 121
    .line 122
    invoke-virtual/range {v21 .. v21}, Lki2;->b0()V

    .line 123
    .line 124
    .line 125
    :goto_1
    return-object v14

    .line 126
    :pswitch_0
    check-cast v3, Lgc0;

    .line 127
    .line 128
    move-object/from16 v5, p1

    .line 129
    .line 130
    check-cast v5, Lki2;

    .line 131
    .line 132
    move-object/from16 v1, p2

    .line 133
    .line 134
    check-cast v1, Ljava/lang/Integer;

    .line 135
    .line 136
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 137
    .line 138
    .line 139
    move-result v1

    .line 140
    and-int/lit8 v9, v1, 0x3

    .line 141
    .line 142
    if-eq v9, v15, :cond_4

    .line 143
    .line 144
    move v2, v4

    .line 145
    :cond_4
    and-int/2addr v1, v4

    .line 146
    invoke-virtual {v5, v1, v2}, Lki2;->Y(IZ)Z

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    if-eqz v1, :cond_6

    .line 151
    .line 152
    const v1, 0x7f0f0480

    .line 153
    .line 154
    .line 155
    invoke-static {v1, v5}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    sget-object v2, Lo63;->a:La53;

    .line 160
    .line 161
    if-nez v2, :cond_5

    .line 162
    .line 163
    new-instance v15, Lz43;

    .line 164
    .line 165
    const/16 v23, 0x0

    .line 166
    .line 167
    const/16 v25, 0x60

    .line 168
    .line 169
    const/16 v24, 0x0

    .line 170
    .line 171
    const/high16 v17, 0x41c00000    # 24.0f

    .line 172
    .line 173
    const/high16 v18, 0x41c00000    # 24.0f

    .line 174
    .line 175
    const/high16 v19, 0x41c00000    # 24.0f

    .line 176
    .line 177
    const/high16 v20, 0x41c00000    # 24.0f

    .line 178
    .line 179
    const-wide/16 v21, 0x0

    .line 180
    .line 181
    const-string v16, "Rounded.Key"

    .line 182
    .line 183
    invoke-direct/range {v15 .. v25}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 184
    .line 185
    .line 186
    new-instance v2, Lnw6;

    .line 187
    .line 188
    invoke-direct {v2, v11, v12}, Lnw6;-><init>(J)V

    .line 189
    .line 190
    .line 191
    new-instance v4, Ly75;

    .line 192
    .line 193
    invoke-direct {v4}, Ly75;-><init>()V

    .line 194
    .line 195
    .line 196
    const v9, 0x41a4b852    # 20.59f

    .line 197
    .line 198
    .line 199
    const/high16 v10, 0x41200000    # 10.0f

    .line 200
    .line 201
    invoke-virtual {v4, v9, v10}, Ly75;->h(FF)V

    .line 202
    .line 203
    .line 204
    const v9, -0x3f01eb85    # -7.94f

    .line 205
    .line 206
    .line 207
    invoke-virtual {v4, v9}, Ly75;->e(F)V

    .line 208
    .line 209
    .line 210
    const v21, 0x40b8a3d7    # 5.77f

    .line 211
    .line 212
    .line 213
    const v22, 0x40c3d70a    # 6.12f

    .line 214
    .line 215
    .line 216
    const v17, 0x413b3333    # 11.7f

    .line 217
    .line 218
    .line 219
    const v18, 0x40e9eb85    # 7.31f

    .line 220
    .line 221
    .line 222
    const v19, 0x410e3d71    # 8.89f

    .line 223
    .line 224
    .line 225
    const/high16 v20, 0x40b00000    # 5.5f

    .line 226
    .line 227
    move-object/from16 v16, v4

    .line 228
    .line 229
    invoke-virtual/range {v16 .. v22}, Ly75;->b(FFFFFF)V

    .line 230
    .line 231
    .line 232
    const v21, -0x3f6bd70a    # -4.63f

    .line 233
    .line 234
    .line 235
    const v22, 0x40928f5c    # 4.58f

    .line 236
    .line 237
    .line 238
    const v17, -0x3fed70a4    # -2.29f

    .line 239
    .line 240
    .line 241
    const v18, 0x3eeb851f    # 0.46f

    .line 242
    .line 243
    .line 244
    const v19, -0x3f7b3333    # -4.15f

    .line 245
    .line 246
    .line 247
    const v20, 0x40133333    # 2.3f

    .line 248
    .line 249
    .line 250
    invoke-virtual/range {v16 .. v22}, Ly75;->c(FFFFFF)V

    .line 251
    .line 252
    .line 253
    const/high16 v21, 0x40e00000    # 7.0f

    .line 254
    .line 255
    const/high16 v22, 0x41900000    # 18.0f

    .line 256
    .line 257
    const v17, 0x3ea3d70a    # 0.32f

    .line 258
    .line 259
    .line 260
    const v18, 0x416947ae    # 14.58f

    .line 261
    .line 262
    .line 263
    const v19, 0x4050a3d7    # 3.26f

    .line 264
    .line 265
    .line 266
    const/high16 v20, 0x41900000    # 18.0f

    .line 267
    .line 268
    invoke-virtual/range {v16 .. v22}, Ly75;->b(FFFFFF)V

    .line 269
    .line 270
    .line 271
    const v21, 0x40b4cccd    # 5.65f

    .line 272
    .line 273
    .line 274
    const/high16 v22, -0x3f800000    # -4.0f

    .line 275
    .line 276
    const v17, 0x40270a3d    # 2.61f

    .line 277
    .line 278
    .line 279
    const/16 v18, 0x0

    .line 280
    .line 281
    const v19, 0x409a8f5c    # 4.83f

    .line 282
    .line 283
    .line 284
    const v20, -0x402a3d71    # -1.67f

    .line 285
    .line 286
    .line 287
    invoke-virtual/range {v16 .. v22}, Ly75;->c(FFFFFF)V

    .line 288
    .line 289
    .line 290
    invoke-virtual {v4, v6}, Ly75;->d(F)V

    .line 291
    .line 292
    .line 293
    invoke-virtual {v4, v7, v7}, Ly75;->g(FF)V

    .line 294
    .line 295
    .line 296
    const v21, 0x3fb47ae1    # 1.41f

    .line 297
    .line 298
    .line 299
    const/16 v22, 0x0

    .line 300
    .line 301
    const v17, 0x3ec7ae14    # 0.39f

    .line 302
    .line 303
    .line 304
    const v18, 0x3ec7ae14    # 0.39f

    .line 305
    .line 306
    .line 307
    const v19, 0x3f828f5c    # 1.02f

    .line 308
    .line 309
    .line 310
    const v20, 0x3ec7ae14    # 0.39f

    .line 311
    .line 312
    .line 313
    invoke-virtual/range {v16 .. v22}, Ly75;->c(FFFFFF)V

    .line 314
    .line 315
    .line 316
    const/high16 v6, 0x41880000    # 17.0f

    .line 317
    .line 318
    const/high16 v9, 0x41600000    # 14.0f

    .line 319
    .line 320
    invoke-virtual {v4, v6, v9}, Ly75;->f(FF)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v4, v7, v7}, Ly75;->g(FF)V

    .line 324
    .line 325
    .line 326
    const v21, 0x3fb5c28f    # 1.42f

    .line 327
    .line 328
    .line 329
    const v19, 0x3f83d70a    # 1.03f

    .line 330
    .line 331
    .line 332
    invoke-virtual/range {v16 .. v22}, Ly75;->c(FFFFFF)V

    .line 333
    .line 334
    .line 335
    const v6, 0x4025c28f    # 2.59f

    .line 336
    .line 337
    .line 338
    const v7, -0x3fd8f5c3    # -2.61f

    .line 339
    .line 340
    .line 341
    invoke-virtual {v4, v6, v7}, Ly75;->g(FF)V

    .line 342
    .line 343
    .line 344
    const v21, -0x43dc28f6    # -0.01f

    .line 345
    .line 346
    .line 347
    const v22, -0x404a3d71    # -1.42f

    .line 348
    .line 349
    .line 350
    const v18, -0x413851ec    # -0.39f

    .line 351
    .line 352
    .line 353
    const v19, 0x3ec7ae14    # 0.39f

    .line 354
    .line 355
    .line 356
    const v20, -0x407c28f6    # -1.03f

    .line 357
    .line 358
    .line 359
    invoke-virtual/range {v16 .. v22}, Ly75;->c(FFFFFF)V

    .line 360
    .line 361
    .line 362
    const v6, -0x40828f5c    # -0.99f

    .line 363
    .line 364
    .line 365
    const v7, -0x4087ae14    # -0.97f

    .line 366
    .line 367
    .line 368
    invoke-virtual {v4, v6, v7}, Ly75;->g(FF)V

    .line 369
    .line 370
    .line 371
    const v21, 0x41a4b852    # 20.59f

    .line 372
    .line 373
    .line 374
    const/high16 v22, 0x41200000    # 10.0f

    .line 375
    .line 376
    const v17, 0x41a8cccd    # 21.1f

    .line 377
    .line 378
    .line 379
    const v18, 0x4121999a    # 10.1f

    .line 380
    .line 381
    .line 382
    const v19, 0x41a6cccd    # 20.85f

    .line 383
    .line 384
    .line 385
    const/high16 v20, 0x41200000    # 10.0f

    .line 386
    .line 387
    invoke-virtual/range {v16 .. v22}, Ly75;->b(FFFFFF)V

    .line 388
    .line 389
    .line 390
    invoke-virtual {v4}, Ly75;->a()V

    .line 391
    .line 392
    .line 393
    const/high16 v6, 0x40e00000    # 7.0f

    .line 394
    .line 395
    const/high16 v7, 0x41700000    # 15.0f

    .line 396
    .line 397
    invoke-virtual {v4, v6, v7}, Ly75;->h(FF)V

    .line 398
    .line 399
    .line 400
    const/high16 v21, -0x3fc00000    # -3.0f

    .line 401
    .line 402
    const/high16 v22, -0x3fc00000    # -3.0f

    .line 403
    .line 404
    const v17, -0x402ccccd    # -1.65f

    .line 405
    .line 406
    .line 407
    const/16 v18, 0x0

    .line 408
    .line 409
    const/high16 v19, -0x3fc00000    # -3.0f

    .line 410
    .line 411
    const v20, -0x40533333    # -1.35f

    .line 412
    .line 413
    .line 414
    invoke-virtual/range {v16 .. v22}, Ly75;->c(FFFFFF)V

    .line 415
    .line 416
    .line 417
    const/high16 v21, 0x40400000    # 3.0f

    .line 418
    .line 419
    const/16 v17, 0x0

    .line 420
    .line 421
    const v18, -0x402ccccd    # -1.65f

    .line 422
    .line 423
    .line 424
    const v19, 0x3faccccd    # 1.35f

    .line 425
    .line 426
    .line 427
    const/high16 v20, -0x3fc00000    # -3.0f

    .line 428
    .line 429
    invoke-virtual/range {v16 .. v22}, Ly75;->c(FFFFFF)V

    .line 430
    .line 431
    .line 432
    const v6, 0x3faccccd    # 1.35f

    .line 433
    .line 434
    .line 435
    invoke-virtual {v4, v8, v6, v8, v8}, Ly75;->k(FFFF)V

    .line 436
    .line 437
    .line 438
    const/high16 v21, 0x40e00000    # 7.0f

    .line 439
    .line 440
    const/high16 v22, 0x41700000    # 15.0f

    .line 441
    .line 442
    const/high16 v17, 0x41200000    # 10.0f

    .line 443
    .line 444
    const v18, 0x415a6666    # 13.65f

    .line 445
    .line 446
    .line 447
    const v19, 0x410a6666    # 8.65f

    .line 448
    .line 449
    .line 450
    const/high16 v20, 0x41700000    # 15.0f

    .line 451
    .line 452
    invoke-virtual/range {v16 .. v22}, Ly75;->b(FFFFFF)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {v4}, Ly75;->a()V

    .line 456
    .line 457
    .line 458
    iget-object v4, v4, Ly75;->a:Ljava/util/ArrayList;

    .line 459
    .line 460
    const/16 v24, 0x3800

    .line 461
    .line 462
    const/16 v17, 0x0

    .line 463
    .line 464
    const/16 v19, 0x0

    .line 465
    .line 466
    const/high16 v20, 0x3f800000    # 1.0f

    .line 467
    .line 468
    const/16 v21, 0x0

    .line 469
    .line 470
    const/16 v22, 0x2

    .line 471
    .line 472
    const/high16 v23, 0x3f800000    # 1.0f

    .line 473
    .line 474
    move-object/from16 v18, v2

    .line 475
    .line 476
    move-object/from16 v16, v4

    .line 477
    .line 478
    invoke-static/range {v15 .. v24}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 479
    .line 480
    .line 481
    invoke-virtual {v15}, Lz43;->c()La53;

    .line 482
    .line 483
    .line 484
    move-result-object v2

    .line 485
    sput-object v2, Lo63;->a:La53;

    .line 486
    .line 487
    :cond_5
    const/4 v6, 0x0

    .line 488
    const/16 v7, 0x2a

    .line 489
    .line 490
    move-object v4, v1

    .line 491
    move-object v1, v2

    .line 492
    iget-boolean v2, v0, Lw50;->i:Z

    .line 493
    .line 494
    move-object v0, v4

    .line 495
    move-object v4, v3

    .line 496
    const/4 v3, 0x0

    .line 497
    invoke-static/range {v0 .. v7}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 498
    .line 499
    .line 500
    goto :goto_2

    .line 501
    :cond_6
    invoke-virtual {v5}, Lki2;->b0()V

    .line 502
    .line 503
    .line 504
    :goto_2
    return-object v14

    .line 505
    :pswitch_1
    move-object v10, v3

    .line 506
    check-cast v10, Lgc0;

    .line 507
    .line 508
    move-object/from16 v11, p1

    .line 509
    .line 510
    check-cast v11, Lki2;

    .line 511
    .line 512
    move-object/from16 v1, p2

    .line 513
    .line 514
    check-cast v1, Ljava/lang/Integer;

    .line 515
    .line 516
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 517
    .line 518
    .line 519
    move-result v1

    .line 520
    and-int/lit8 v3, v1, 0x3

    .line 521
    .line 522
    if-eq v3, v15, :cond_7

    .line 523
    .line 524
    move v2, v4

    .line 525
    :cond_7
    and-int/2addr v1, v4

    .line 526
    invoke-virtual {v11, v1, v2}, Lki2;->Y(IZ)Z

    .line 527
    .line 528
    .line 529
    move-result v1

    .line 530
    if-eqz v1, :cond_8

    .line 531
    .line 532
    invoke-static {}, Lel;->F()La53;

    .line 533
    .line 534
    .line 535
    move-result-object v7

    .line 536
    const v1, 0x7f0f046a

    .line 537
    .line 538
    .line 539
    invoke-static {v1, v11}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 540
    .line 541
    .line 542
    move-result-object v6

    .line 543
    const/4 v12, 0x0

    .line 544
    const/16 v13, 0x2a

    .line 545
    .line 546
    iget-boolean v8, v0, Lw50;->i:Z

    .line 547
    .line 548
    const/4 v9, 0x0

    .line 549
    invoke-static/range {v6 .. v13}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 550
    .line 551
    .line 552
    goto :goto_3

    .line 553
    :cond_8
    invoke-virtual {v11}, Lki2;->b0()V

    .line 554
    .line 555
    .line 556
    :goto_3
    return-object v14

    .line 557
    :pswitch_2
    check-cast v3, Lf7;

    .line 558
    .line 559
    move-object/from16 v1, p1

    .line 560
    .line 561
    check-cast v1, Lki2;

    .line 562
    .line 563
    move-object/from16 v7, p2

    .line 564
    .line 565
    check-cast v7, Ljava/lang/Integer;

    .line 566
    .line 567
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 568
    .line 569
    .line 570
    move-result v7

    .line 571
    and-int/lit8 v9, v7, 0x3

    .line 572
    .line 573
    if-eq v9, v15, :cond_9

    .line 574
    .line 575
    move v2, v4

    .line 576
    :cond_9
    and-int/2addr v7, v4

    .line 577
    invoke-virtual {v1, v7, v2}, Lki2;->Y(IZ)Z

    .line 578
    .line 579
    .line 580
    move-result v2

    .line 581
    if-eqz v2, :cond_b

    .line 582
    .line 583
    sget-object v2, Lz33;->d:La53;

    .line 584
    .line 585
    if-nez v2, :cond_a

    .line 586
    .line 587
    new-instance v20, Lz43;

    .line 588
    .line 589
    const/16 v28, 0x0

    .line 590
    .line 591
    const/16 v30, 0x60

    .line 592
    .line 593
    const/16 v29, 0x0

    .line 594
    .line 595
    const/high16 v22, 0x41c00000    # 24.0f

    .line 596
    .line 597
    const/high16 v23, 0x41c00000    # 24.0f

    .line 598
    .line 599
    const/high16 v24, 0x41c00000    # 24.0f

    .line 600
    .line 601
    const/high16 v25, 0x41c00000    # 24.0f

    .line 602
    .line 603
    const-wide/16 v26, 0x0

    .line 604
    .line 605
    const-string v21, "Rounded.PowerSettingsNew"

    .line 606
    .line 607
    invoke-direct/range {v20 .. v30}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 608
    .line 609
    .line 610
    new-instance v2, Lnw6;

    .line 611
    .line 612
    invoke-direct {v2, v11, v12}, Lnw6;-><init>(J)V

    .line 613
    .line 614
    .line 615
    invoke-static {v10, v8}, Lx82;->j(FF)Ly75;

    .line 616
    .line 617
    .line 618
    move-result-object v21

    .line 619
    const/high16 v26, -0x40800000    # -1.0f

    .line 620
    .line 621
    const/high16 v27, 0x3f800000    # 1.0f

    .line 622
    .line 623
    const v22, -0x40f33333    # -0.55f

    .line 624
    .line 625
    .line 626
    const/16 v23, 0x0

    .line 627
    .line 628
    const/high16 v24, -0x40800000    # -1.0f

    .line 629
    .line 630
    const v25, 0x3ee66666    # 0.45f

    .line 631
    .line 632
    .line 633
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 634
    .line 635
    .line 636
    move-object/from16 v4, v21

    .line 637
    .line 638
    const/high16 v7, 0x41000000    # 8.0f

    .line 639
    .line 640
    invoke-virtual {v4, v7}, Ly75;->m(F)V

    .line 641
    .line 642
    .line 643
    const/high16 v26, 0x3f800000    # 1.0f

    .line 644
    .line 645
    const/16 v22, 0x0

    .line 646
    .line 647
    const v23, 0x3f0ccccd    # 0.55f

    .line 648
    .line 649
    .line 650
    const v24, 0x3ee66666    # 0.45f

    .line 651
    .line 652
    .line 653
    const/high16 v25, 0x3f800000    # 1.0f

    .line 654
    .line 655
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 656
    .line 657
    .line 658
    const v7, -0x4119999a    # -0.45f

    .line 659
    .line 660
    .line 661
    const/high16 v8, -0x40800000    # -1.0f

    .line 662
    .line 663
    invoke-virtual {v4, v5, v7, v5, v8}, Ly75;->k(FFFF)V

    .line 664
    .line 665
    .line 666
    const/high16 v5, 0x40800000    # 4.0f

    .line 667
    .line 668
    invoke-virtual {v4, v6, v5}, Ly75;->f(FF)V

    .line 669
    .line 670
    .line 671
    const/high16 v26, -0x40800000    # -1.0f

    .line 672
    .line 673
    const/high16 v27, -0x40800000    # -1.0f

    .line 674
    .line 675
    const v23, -0x40f33333    # -0.55f

    .line 676
    .line 677
    .line 678
    const v24, -0x4119999a    # -0.45f

    .line 679
    .line 680
    .line 681
    const/high16 v25, -0x40800000    # -1.0f

    .line 682
    .line 683
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 684
    .line 685
    .line 686
    invoke-virtual {v4}, Ly75;->a()V

    .line 687
    .line 688
    .line 689
    const v5, 0x41891eb8    # 17.14f

    .line 690
    .line 691
    .line 692
    const v6, 0x40bb851f    # 5.86f

    .line 693
    .line 694
    .line 695
    invoke-virtual {v4, v5, v6}, Ly75;->h(FF)V

    .line 696
    .line 697
    .line 698
    const v26, -0x43dc28f6    # -0.01f

    .line 699
    .line 700
    .line 701
    const v27, 0x3fb1eb85    # 1.39f

    .line 702
    .line 703
    .line 704
    const v22, -0x413851ec    # -0.39f

    .line 705
    .line 706
    .line 707
    const v23, 0x3ec7ae14    # 0.39f

    .line 708
    .line 709
    .line 710
    const v24, -0x413d70a4    # -0.38f

    .line 711
    .line 712
    .line 713
    const/high16 v25, 0x3f800000    # 1.0f

    .line 714
    .line 715
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 716
    .line 717
    .line 718
    const v26, 0x3fef5c29    # 1.87f

    .line 719
    .line 720
    .line 721
    const v27, 0x40923d71    # 4.57f

    .line 722
    .line 723
    .line 724
    const v22, 0x3f90a3d7    # 1.13f

    .line 725
    .line 726
    .line 727
    const v23, 0x3f99999a    # 1.2f

    .line 728
    .line 729
    .line 730
    const v24, 0x3fea3d71    # 1.83f

    .line 731
    .line 732
    .line 733
    const v25, 0x40333333    # 2.8f

    .line 734
    .line 735
    .line 736
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 737
    .line 738
    .line 739
    const v26, -0x3f22e148    # -6.91f

    .line 740
    .line 741
    .line 742
    const v27, 0x40e570a4    # 7.17f

    .line 743
    .line 744
    .line 745
    const v22, 0x3db851ec    # 0.09f

    .line 746
    .line 747
    .line 748
    const v23, 0x40751eb8    # 3.83f

    .line 749
    .line 750
    .line 751
    const v24, -0x3fbae148    # -3.08f

    .line 752
    .line 753
    .line 754
    const v25, 0x40e428f6    # 7.13f

    .line 755
    .line 756
    .line 757
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 758
    .line 759
    .line 760
    const/high16 v26, 0x40a00000    # 5.0f

    .line 761
    .line 762
    const/high16 v27, 0x41400000    # 12.0f

    .line 763
    .line 764
    const v22, 0x4102e148    # 8.18f

    .line 765
    .line 766
    .line 767
    const v23, 0x41986666    # 19.05f

    .line 768
    .line 769
    .line 770
    const/high16 v24, 0x40a00000    # 5.0f

    .line 771
    .line 772
    const v25, 0x417e6666    # 15.9f

    .line 773
    .line 774
    .line 775
    invoke-virtual/range {v21 .. v27}, Ly75;->b(FFFFFF)V

    .line 776
    .line 777
    .line 778
    const v26, 0x3fef5c29    # 1.87f

    .line 779
    .line 780
    .line 781
    const v27, -0x3f67ae14    # -4.76f

    .line 782
    .line 783
    .line 784
    const/16 v22, 0x0

    .line 785
    .line 786
    const v23, -0x40147ae1    # -1.84f

    .line 787
    .line 788
    .line 789
    const v24, 0x3f35c28f    # 0.71f

    .line 790
    .line 791
    .line 792
    const v25, -0x3f9f5c29    # -3.51f

    .line 793
    .line 794
    .line 795
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 796
    .line 797
    .line 798
    const v26, -0x43dc28f6    # -0.01f

    .line 799
    .line 800
    .line 801
    const v27, -0x404f5c29    # -1.38f

    .line 802
    .line 803
    .line 804
    const v22, 0x3ebd70a4    # 0.37f

    .line 805
    .line 806
    .line 807
    const v23, -0x413851ec    # -0.39f

    .line 808
    .line 809
    .line 810
    const v24, 0x3ebd70a4    # 0.37f

    .line 811
    .line 812
    .line 813
    const/high16 v25, -0x40800000    # -1.0f

    .line 814
    .line 815
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 816
    .line 817
    .line 818
    const v26, -0x4048f5c3    # -1.43f

    .line 819
    .line 820
    .line 821
    const v27, 0x3ca3d70a    # 0.02f

    .line 822
    .line 823
    .line 824
    const v22, -0x41333333    # -0.4f

    .line 825
    .line 826
    .line 827
    const v23, -0x41333333    # -0.4f

    .line 828
    .line 829
    .line 830
    const v24, -0x4079999a    # -1.05f

    .line 831
    .line 832
    .line 833
    const v25, -0x413851ec    # -0.39f

    .line 834
    .line 835
    .line 836
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 837
    .line 838
    .line 839
    const/high16 v26, 0x40400000    # 3.0f

    .line 840
    .line 841
    const v27, 0x413bd70a    # 11.74f

    .line 842
    .line 843
    .line 844
    const v22, 0x407eb852    # 3.98f

    .line 845
    .line 846
    .line 847
    const v23, 0x40ed70a4    # 7.42f

    .line 848
    .line 849
    .line 850
    const v24, 0x40447ae1    # 3.07f

    .line 851
    .line 852
    .line 853
    const v25, 0x4117851f    # 9.47f

    .line 854
    .line 855
    .line 856
    invoke-virtual/range {v21 .. v27}, Ly75;->b(FFFFFF)V

    .line 857
    .line 858
    .line 859
    const v26, 0x410b5c29    # 8.71f

    .line 860
    .line 861
    .line 862
    const/high16 v27, 0x41140000    # 9.25f

    .line 863
    .line 864
    const v22, -0x41f0a3d7    # -0.14f

    .line 865
    .line 866
    .line 867
    const v23, 0x409c28f6    # 4.88f

    .line 868
    .line 869
    .line 870
    const v24, 0x40751eb8    # 3.83f

    .line 871
    .line 872
    .line 873
    const v25, 0x4111999a    # 9.1f

    .line 874
    .line 875
    .line 876
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 877
    .line 878
    .line 879
    const v26, 0x4114a3d7    # 9.29f

    .line 880
    .line 881
    .line 882
    const/high16 v27, -0x3ef00000    # -9.0f

    .line 883
    .line 884
    const v22, 0x40a33333    # 5.1f

    .line 885
    .line 886
    .line 887
    const v23, 0x3e23d70a    # 0.16f

    .line 888
    .line 889
    .line 890
    const v24, 0x4114a3d7    # 9.29f

    .line 891
    .line 892
    .line 893
    const v25, -0x3f847ae1    # -3.93f

    .line 894
    .line 895
    .line 896
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 897
    .line 898
    .line 899
    const v26, -0x3fe51eb8    # -2.42f

    .line 900
    .line 901
    .line 902
    const v27, -0x3f3c7ae1    # -6.11f

    .line 903
    .line 904
    .line 905
    const/16 v22, 0x0

    .line 906
    .line 907
    const v23, -0x3fe851ec    # -2.37f

    .line 908
    .line 909
    .line 910
    const v24, -0x40947ae1    # -0.92f

    .line 911
    .line 912
    .line 913
    const v25, -0x3f6fae14    # -4.51f

    .line 914
    .line 915
    .line 916
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 917
    .line 918
    .line 919
    const v26, -0x4047ae14    # -1.44f

    .line 920
    .line 921
    .line 922
    const v27, -0x435c28f6    # -0.02f

    .line 923
    .line 924
    .line 925
    const v22, -0x413d70a4    # -0.38f

    .line 926
    .line 927
    .line 928
    const v23, -0x412e147b    # -0.41f

    .line 929
    .line 930
    .line 931
    const v24, -0x407ae148    # -1.04f

    .line 932
    .line 933
    .line 934
    const v25, -0x4128f5c3    # -0.42f

    .line 935
    .line 936
    .line 937
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 938
    .line 939
    .line 940
    invoke-virtual {v4}, Ly75;->a()V

    .line 941
    .line 942
    .line 943
    iget-object v4, v4, Ly75;->a:Ljava/util/ArrayList;

    .line 944
    .line 945
    const/16 v29, 0x3800

    .line 946
    .line 947
    const/16 v22, 0x0

    .line 948
    .line 949
    const/16 v24, 0x0

    .line 950
    .line 951
    const/high16 v25, 0x3f800000    # 1.0f

    .line 952
    .line 953
    const/16 v26, 0x0

    .line 954
    .line 955
    const/16 v27, 0x2

    .line 956
    .line 957
    const/high16 v28, 0x3f800000    # 1.0f

    .line 958
    .line 959
    move-object/from16 v23, v2

    .line 960
    .line 961
    move-object/from16 v21, v4

    .line 962
    .line 963
    invoke-static/range {v20 .. v29}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 964
    .line 965
    .line 966
    invoke-virtual/range {v20 .. v20}, Lz43;->c()La53;

    .line 967
    .line 968
    .line 969
    move-result-object v2

    .line 970
    sput-object v2, Lz33;->d:La53;

    .line 971
    .line 972
    :cond_a
    const v4, 0x7f0f046b

    .line 973
    .line 974
    .line 975
    invoke-static {v4, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 976
    .line 977
    .line 978
    move-result-object v4

    .line 979
    const/4 v6, 0x0

    .line 980
    const/16 v7, 0x2a

    .line 981
    .line 982
    move-object v5, v1

    .line 983
    move-object v1, v2

    .line 984
    iget-boolean v2, v0, Lw50;->i:Z

    .line 985
    .line 986
    move-object v0, v4

    .line 987
    move-object v4, v3

    .line 988
    const/4 v3, 0x0

    .line 989
    invoke-static/range {v0 .. v7}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 990
    .line 991
    .line 992
    goto :goto_4

    .line 993
    :cond_b
    move-object v5, v1

    .line 994
    invoke-virtual {v5}, Lki2;->b0()V

    .line 995
    .line 996
    .line 997
    :goto_4
    return-object v14

    .line 998
    :pswitch_3
    move-object v10, v3

    .line 999
    check-cast v10, Le2;

    .line 1000
    .line 1001
    move-object/from16 v11, p1

    .line 1002
    .line 1003
    check-cast v11, Lki2;

    .line 1004
    .line 1005
    move-object/from16 v1, p2

    .line 1006
    .line 1007
    check-cast v1, Ljava/lang/Integer;

    .line 1008
    .line 1009
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1010
    .line 1011
    .line 1012
    move-result v1

    .line 1013
    and-int/lit8 v3, v1, 0x3

    .line 1014
    .line 1015
    if-eq v3, v15, :cond_c

    .line 1016
    .line 1017
    move v2, v4

    .line 1018
    :cond_c
    and-int/2addr v1, v4

    .line 1019
    invoke-virtual {v11, v1, v2}, Lki2;->Y(IZ)Z

    .line 1020
    .line 1021
    .line 1022
    move-result v1

    .line 1023
    if-eqz v1, :cond_d

    .line 1024
    .line 1025
    invoke-static {}, Le43;->B()La53;

    .line 1026
    .line 1027
    .line 1028
    move-result-object v7

    .line 1029
    const v1, 0x7f0f048b

    .line 1030
    .line 1031
    .line 1032
    invoke-static {v1, v11}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 1033
    .line 1034
    .line 1035
    move-result-object v6

    .line 1036
    const/4 v12, 0x0

    .line 1037
    const/16 v13, 0x2a

    .line 1038
    .line 1039
    iget-boolean v8, v0, Lw50;->i:Z

    .line 1040
    .line 1041
    const/4 v9, 0x0

    .line 1042
    invoke-static/range {v6 .. v13}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 1043
    .line 1044
    .line 1045
    goto :goto_5

    .line 1046
    :cond_d
    invoke-virtual {v11}, Lki2;->b0()V

    .line 1047
    .line 1048
    .line 1049
    :goto_5
    return-object v14

    .line 1050
    :pswitch_4
    check-cast v3, Lbg;

    .line 1051
    .line 1052
    move-object/from16 v5, p1

    .line 1053
    .line 1054
    check-cast v5, Lki2;

    .line 1055
    .line 1056
    move-object/from16 v1, p2

    .line 1057
    .line 1058
    check-cast v1, Ljava/lang/Integer;

    .line 1059
    .line 1060
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1061
    .line 1062
    .line 1063
    move-result v1

    .line 1064
    and-int/lit8 v6, v1, 0x3

    .line 1065
    .line 1066
    if-eq v6, v15, :cond_e

    .line 1067
    .line 1068
    move v2, v4

    .line 1069
    :cond_e
    and-int/2addr v1, v4

    .line 1070
    invoke-virtual {v5, v1, v2}, Lki2;->Y(IZ)Z

    .line 1071
    .line 1072
    .line 1073
    move-result v1

    .line 1074
    if-eqz v1, :cond_10

    .line 1075
    .line 1076
    sget-object v1, Lu53;->c:La53;

    .line 1077
    .line 1078
    if-nez v1, :cond_f

    .line 1079
    .line 1080
    new-instance v20, Lz43;

    .line 1081
    .line 1082
    const/16 v28, 0x0

    .line 1083
    .line 1084
    const/16 v30, 0x60

    .line 1085
    .line 1086
    const-string v21, "Rounded.Notifications"

    .line 1087
    .line 1088
    const/high16 v22, 0x41c00000    # 24.0f

    .line 1089
    .line 1090
    const/high16 v23, 0x41c00000    # 24.0f

    .line 1091
    .line 1092
    const/high16 v24, 0x41c00000    # 24.0f

    .line 1093
    .line 1094
    const/high16 v25, 0x41c00000    # 24.0f

    .line 1095
    .line 1096
    const-wide/16 v26, 0x0

    .line 1097
    .line 1098
    const/16 v29, 0x0

    .line 1099
    .line 1100
    invoke-direct/range {v20 .. v30}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 1101
    .line 1102
    .line 1103
    new-instance v1, Lnw6;

    .line 1104
    .line 1105
    invoke-direct {v1, v11, v12}, Lnw6;-><init>(J)V

    .line 1106
    .line 1107
    .line 1108
    const/high16 v2, 0x41b00000    # 22.0f

    .line 1109
    .line 1110
    invoke-static {v10, v2}, Lx82;->j(FF)Ly75;

    .line 1111
    .line 1112
    .line 1113
    move-result-object v21

    .line 1114
    const/high16 v26, 0x40000000    # 2.0f

    .line 1115
    .line 1116
    const/high16 v27, -0x40000000    # -2.0f

    .line 1117
    .line 1118
    const v22, 0x3f8ccccd    # 1.1f

    .line 1119
    .line 1120
    .line 1121
    const/16 v23, 0x0

    .line 1122
    .line 1123
    const/high16 v24, 0x40000000    # 2.0f

    .line 1124
    .line 1125
    const v25, -0x4099999a    # -0.9f

    .line 1126
    .line 1127
    .line 1128
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 1129
    .line 1130
    .line 1131
    move-object/from16 v2, v21

    .line 1132
    .line 1133
    const/high16 v4, -0x3f800000    # -4.0f

    .line 1134
    .line 1135
    invoke-virtual {v2, v4}, Ly75;->e(F)V

    .line 1136
    .line 1137
    .line 1138
    const/high16 v27, 0x40000000    # 2.0f

    .line 1139
    .line 1140
    const/16 v22, 0x0

    .line 1141
    .line 1142
    const v23, 0x3f8ccccd    # 1.1f

    .line 1143
    .line 1144
    .line 1145
    const v24, 0x3f63d70a    # 0.89f

    .line 1146
    .line 1147
    .line 1148
    const/high16 v25, 0x40000000    # 2.0f

    .line 1149
    .line 1150
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 1151
    .line 1152
    .line 1153
    invoke-virtual {v2}, Ly75;->a()V

    .line 1154
    .line 1155
    .line 1156
    const/high16 v4, 0x41900000    # 18.0f

    .line 1157
    .line 1158
    const/high16 v6, 0x41800000    # 16.0f

    .line 1159
    .line 1160
    invoke-virtual {v2, v4, v6}, Ly75;->h(FF)V

    .line 1161
    .line 1162
    .line 1163
    const/high16 v8, -0x3f600000    # -5.0f

    .line 1164
    .line 1165
    invoke-virtual {v2, v8}, Ly75;->m(F)V

    .line 1166
    .line 1167
    .line 1168
    const/high16 v26, -0x3f700000    # -4.5f

    .line 1169
    .line 1170
    const v27, -0x3f35c28f    # -6.32f

    .line 1171
    .line 1172
    .line 1173
    const v23, -0x3fbb851f    # -3.07f

    .line 1174
    .line 1175
    .line 1176
    const v24, -0x402e147b    # -1.64f

    .line 1177
    .line 1178
    .line 1179
    const v25, -0x3f4b851f    # -5.64f

    .line 1180
    .line 1181
    .line 1182
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 1183
    .line 1184
    .line 1185
    const/high16 v8, 0x41580000    # 13.5f

    .line 1186
    .line 1187
    const/high16 v9, 0x40800000    # 4.0f

    .line 1188
    .line 1189
    invoke-virtual {v2, v8, v9}, Ly75;->f(FF)V

    .line 1190
    .line 1191
    .line 1192
    const/high16 v26, -0x40400000    # -1.5f

    .line 1193
    .line 1194
    const/high16 v27, -0x40400000    # -1.5f

    .line 1195
    .line 1196
    const v23, -0x40ab851f    # -0.83f

    .line 1197
    .line 1198
    .line 1199
    const v24, -0x40d47ae1    # -0.67f

    .line 1200
    .line 1201
    .line 1202
    const/high16 v25, -0x40400000    # -1.5f

    .line 1203
    .line 1204
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 1205
    .line 1206
    .line 1207
    const v8, 0x3f2b851f    # 0.67f

    .line 1208
    .line 1209
    .line 1210
    const/high16 v9, 0x3fc00000    # 1.5f

    .line 1211
    .line 1212
    const/high16 v10, -0x40400000    # -1.5f

    .line 1213
    .line 1214
    invoke-virtual {v2, v10, v8, v10, v9}, Ly75;->k(FFFF)V

    .line 1215
    .line 1216
    .line 1217
    const v8, 0x3f2e147b    # 0.68f

    .line 1218
    .line 1219
    .line 1220
    invoke-virtual {v2, v8}, Ly75;->m(F)V

    .line 1221
    .line 1222
    .line 1223
    const/high16 v26, 0x40c00000    # 6.0f

    .line 1224
    .line 1225
    const/high16 v27, 0x41300000    # 11.0f

    .line 1226
    .line 1227
    const v22, 0x40f428f6    # 7.63f

    .line 1228
    .line 1229
    .line 1230
    const v23, 0x40ab851f    # 5.36f

    .line 1231
    .line 1232
    .line 1233
    const/high16 v24, 0x40c00000    # 6.0f

    .line 1234
    .line 1235
    const v25, 0x40fd70a4    # 7.92f

    .line 1236
    .line 1237
    .line 1238
    invoke-virtual/range {v21 .. v27}, Ly75;->b(FFFFFF)V

    .line 1239
    .line 1240
    .line 1241
    const/high16 v8, 0x40a00000    # 5.0f

    .line 1242
    .line 1243
    invoke-virtual {v2, v8}, Ly75;->m(F)V

    .line 1244
    .line 1245
    .line 1246
    const v8, -0x405ae148    # -1.29f

    .line 1247
    .line 1248
    .line 1249
    invoke-virtual {v2, v8, v7}, Ly75;->g(FF)V

    .line 1250
    .line 1251
    .line 1252
    const v26, 0x3f333333    # 0.7f

    .line 1253
    .line 1254
    .line 1255
    const v27, 0x3fdae148    # 1.71f

    .line 1256
    .line 1257
    .line 1258
    const v22, -0x40deb852    # -0.63f

    .line 1259
    .line 1260
    .line 1261
    const v23, 0x3f2147ae    # 0.63f

    .line 1262
    .line 1263
    .line 1264
    const v24, -0x41bd70a4    # -0.19f

    .line 1265
    .line 1266
    .line 1267
    const v25, 0x3fdae148    # 1.71f

    .line 1268
    .line 1269
    .line 1270
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 1271
    .line 1272
    .line 1273
    const v7, 0x4152b852    # 13.17f

    .line 1274
    .line 1275
    .line 1276
    invoke-virtual {v2, v7}, Ly75;->e(F)V

    .line 1277
    .line 1278
    .line 1279
    const v26, 0x3f35c28f    # 0.71f

    .line 1280
    .line 1281
    .line 1282
    const v27, -0x40251eb8    # -1.71f

    .line 1283
    .line 1284
    .line 1285
    const v22, 0x3f63d70a    # 0.89f

    .line 1286
    .line 1287
    .line 1288
    const/16 v23, 0x0

    .line 1289
    .line 1290
    const v24, 0x3fab851f    # 1.34f

    .line 1291
    .line 1292
    .line 1293
    const v25, -0x4075c28f    # -1.08f

    .line 1294
    .line 1295
    .line 1296
    invoke-virtual/range {v21 .. v27}, Ly75;->c(FFFFFF)V

    .line 1297
    .line 1298
    .line 1299
    invoke-virtual {v2, v4, v6}, Ly75;->f(FF)V

    .line 1300
    .line 1301
    .line 1302
    invoke-virtual {v2}, Ly75;->a()V

    .line 1303
    .line 1304
    .line 1305
    iget-object v2, v2, Ly75;->a:Ljava/util/ArrayList;

    .line 1306
    .line 1307
    const/16 v29, 0x3800

    .line 1308
    .line 1309
    const/16 v22, 0x0

    .line 1310
    .line 1311
    const/16 v24, 0x0

    .line 1312
    .line 1313
    const/high16 v25, 0x3f800000    # 1.0f

    .line 1314
    .line 1315
    const/16 v26, 0x0

    .line 1316
    .line 1317
    const/16 v27, 0x2

    .line 1318
    .line 1319
    const/high16 v28, 0x3f800000    # 1.0f

    .line 1320
    .line 1321
    move-object/from16 v23, v1

    .line 1322
    .line 1323
    move-object/from16 v21, v2

    .line 1324
    .line 1325
    invoke-static/range {v20 .. v29}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 1326
    .line 1327
    .line 1328
    invoke-virtual/range {v20 .. v20}, Lz43;->c()La53;

    .line 1329
    .line 1330
    .line 1331
    move-result-object v1

    .line 1332
    sput-object v1, Lu53;->c:La53;

    .line 1333
    .line 1334
    :cond_f
    const v2, 0x7f0f0485

    .line 1335
    .line 1336
    .line 1337
    invoke-static {v2, v5}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 1338
    .line 1339
    .line 1340
    move-result-object v2

    .line 1341
    const/4 v6, 0x0

    .line 1342
    const/16 v7, 0x2a

    .line 1343
    .line 1344
    move-object v4, v2

    .line 1345
    iget-boolean v2, v0, Lw50;->i:Z

    .line 1346
    .line 1347
    move-object v0, v4

    .line 1348
    move-object v4, v3

    .line 1349
    const/4 v3, 0x0

    .line 1350
    invoke-static/range {v0 .. v7}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 1351
    .line 1352
    .line 1353
    goto :goto_6

    .line 1354
    :cond_10
    invoke-virtual {v5}, Lki2;->b0()V

    .line 1355
    .line 1356
    .line 1357
    :goto_6
    return-object v14

    .line 1358
    :pswitch_5
    check-cast v3, Lt66;

    .line 1359
    .line 1360
    move-object/from16 v0, p1

    .line 1361
    .line 1362
    check-cast v0, Lki2;

    .line 1363
    .line 1364
    move-object/from16 v1, p2

    .line 1365
    .line 1366
    check-cast v1, Ljava/lang/Integer;

    .line 1367
    .line 1368
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1369
    .line 1370
    .line 1371
    move-result v1

    .line 1372
    and-int/lit8 v5, v1, 0x3

    .line 1373
    .line 1374
    if-eq v5, v15, :cond_11

    .line 1375
    .line 1376
    move v5, v4

    .line 1377
    goto :goto_7

    .line 1378
    :cond_11
    move v5, v2

    .line 1379
    :goto_7
    and-int/2addr v1, v4

    .line 1380
    invoke-virtual {v0, v1, v5}, Lki2;->Y(IZ)Z

    .line 1381
    .line 1382
    .line 1383
    move-result v1

    .line 1384
    if-eqz v1, :cond_12

    .line 1385
    .line 1386
    iget-object v1, v3, Lt66;->d:Lo21;

    .line 1387
    .line 1388
    invoke-virtual {v1}, Lo21;->v()Z

    .line 1389
    .line 1390
    .line 1391
    move-result v19

    .line 1392
    sget-object v1, Lbd0;->b:Lmj1;

    .line 1393
    .line 1394
    const/16 v4, 0xfa

    .line 1395
    .line 1396
    invoke-static {v4, v2, v1, v15}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 1397
    .line 1398
    .line 1399
    move-result-object v5

    .line 1400
    const/16 v6, 0xe

    .line 1401
    .line 1402
    invoke-static {v5, v6}, La32;->c(Lmo7;I)Lg32;

    .line 1403
    .line 1404
    .line 1405
    move-result-object v5

    .line 1406
    invoke-static {v4, v2, v1, v15}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 1407
    .line 1408
    .line 1409
    move-result-object v1

    .line 1410
    const/4 v4, 0x0

    .line 1411
    invoke-static {v1, v4, v15}, La32;->d(Lca2;FI)Lg32;

    .line 1412
    .line 1413
    .line 1414
    move-result-object v1

    .line 1415
    invoke-virtual {v5, v1}, Lg32;->a(Lg32;)Lg32;

    .line 1416
    .line 1417
    .line 1418
    move-result-object v21

    .line 1419
    sget-object v1, Lbd0;->c:Lmj1;

    .line 1420
    .line 1421
    const/16 v5, 0x78

    .line 1422
    .line 1423
    invoke-static {v5, v2, v1, v15}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 1424
    .line 1425
    .line 1426
    move-result-object v7

    .line 1427
    invoke-static {v7, v6}, La32;->i(Lmo7;I)Lz42;

    .line 1428
    .line 1429
    .line 1430
    move-result-object v6

    .line 1431
    invoke-static {v5, v2, v1, v15}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 1432
    .line 1433
    .line 1434
    move-result-object v1

    .line 1435
    invoke-static {v1, v4, v15}, La32;->e(Lca2;FI)Lz42;

    .line 1436
    .line 1437
    .line 1438
    move-result-object v1

    .line 1439
    invoke-virtual {v6, v1}, Lz42;->a(Lz42;)Lz42;

    .line 1440
    .line 1441
    .line 1442
    move-result-object v22

    .line 1443
    new-instance v1, Lm66;

    .line 1444
    .line 1445
    invoke-direct {v1, v3, v13}, Lm66;-><init>(Lt66;Z)V

    .line 1446
    .line 1447
    .line 1448
    const v2, -0x6b008376

    .line 1449
    .line 1450
    .line 1451
    invoke-static {v2, v1, v0}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 1452
    .line 1453
    .line 1454
    move-result-object v24

    .line 1455
    const/high16 v26, 0x30000

    .line 1456
    .line 1457
    const/16 v27, 0x12

    .line 1458
    .line 1459
    const/16 v20, 0x0

    .line 1460
    .line 1461
    const/16 v23, 0x0

    .line 1462
    .line 1463
    move-object/from16 v25, v0

    .line 1464
    .line 1465
    invoke-static/range {v19 .. v27}, Lkb;->f(ZLha4;Lg32;Lz42;Ljava/lang/String;Lq21;Lki2;II)V

    .line 1466
    .line 1467
    .line 1468
    goto :goto_8

    .line 1469
    :cond_12
    move-object/from16 v25, v0

    .line 1470
    .line 1471
    invoke-virtual/range {v25 .. v25}, Lki2;->b0()V

    .line 1472
    .line 1473
    .line 1474
    :goto_8
    return-object v14

    .line 1475
    :pswitch_6
    check-cast v3, Lz06;

    .line 1476
    .line 1477
    move-object/from16 v0, p1

    .line 1478
    .line 1479
    check-cast v0, Lki2;

    .line 1480
    .line 1481
    move-object/from16 v1, p2

    .line 1482
    .line 1483
    check-cast v1, Ljava/lang/Integer;

    .line 1484
    .line 1485
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1486
    .line 1487
    .line 1488
    invoke-static {v4}, Ld43;->P(I)I

    .line 1489
    .line 1490
    .line 1491
    move-result v1

    .line 1492
    invoke-static {v3, v13, v0, v1}, Ls33;->s(Lz06;ZLki2;I)V

    .line 1493
    .line 1494
    .line 1495
    return-object v14

    .line 1496
    :pswitch_7
    check-cast v3, Lro4;

    .line 1497
    .line 1498
    move-object/from16 v10, p1

    .line 1499
    .line 1500
    check-cast v10, Lki2;

    .line 1501
    .line 1502
    move-object/from16 v0, p2

    .line 1503
    .line 1504
    check-cast v0, Ljava/lang/Integer;

    .line 1505
    .line 1506
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1507
    .line 1508
    .line 1509
    move-result v0

    .line 1510
    and-int/lit8 v1, v0, 0x3

    .line 1511
    .line 1512
    if-eq v1, v15, :cond_13

    .line 1513
    .line 1514
    move v1, v4

    .line 1515
    goto :goto_9

    .line 1516
    :cond_13
    move v1, v2

    .line 1517
    :goto_9
    and-int/2addr v0, v4

    .line 1518
    invoke-virtual {v10, v0, v1}, Lki2;->Y(IZ)Z

    .line 1519
    .line 1520
    .line 1521
    move-result v0

    .line 1522
    if-eqz v0, :cond_16

    .line 1523
    .line 1524
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 1525
    .line 1526
    .line 1527
    move-result v0

    .line 1528
    packed-switch v0, :pswitch_data_1

    .line 1529
    .line 1530
    .line 1531
    invoke-static {}, Lfb1;->a()V

    .line 1532
    .line 1533
    .line 1534
    const/4 v14, 0x0

    .line 1535
    goto/16 :goto_e

    .line 1536
    .line 1537
    :pswitch_8
    sget-object v0, Lx33;->f:La53;

    .line 1538
    .line 1539
    if-eqz v0, :cond_14

    .line 1540
    .line 1541
    move-object v5, v0

    .line 1542
    move/from16 v21, v2

    .line 1543
    .line 1544
    goto/16 :goto_b

    .line 1545
    .line 1546
    :cond_14
    new-instance v0, Lh85;

    .line 1547
    .line 1548
    const/high16 v1, 0x43fb0000    # 502.0f

    .line 1549
    .line 1550
    const/high16 v3, 0x44590000    # 868.0f

    .line 1551
    .line 1552
    invoke-direct {v0, v1, v3}, Lh85;-><init>(FF)V

    .line 1553
    .line 1554
    .line 1555
    new-instance v5, Lf85;

    .line 1556
    .line 1557
    const v6, 0x43dd8000    # 443.0f

    .line 1558
    .line 1559
    .line 1560
    invoke-direct {v5, v6}, Lf85;-><init>(F)V

    .line 1561
    .line 1562
    .line 1563
    new-instance v6, Li85;

    .line 1564
    .line 1565
    const v7, 0x43d68000    # 429.0f

    .line 1566
    .line 1567
    .line 1568
    const v8, 0x43d28000    # 421.0f

    .line 1569
    .line 1570
    .line 1571
    const/high16 v9, 0x44570000    # 860.0f

    .line 1572
    .line 1573
    invoke-direct {v6, v7, v3, v8, v9}, Li85;-><init>(FFFF)V

    .line 1574
    .line 1575
    .line 1576
    new-instance v7, Li85;

    .line 1577
    .line 1578
    const v8, 0x43ce8000    # 413.0f

    .line 1579
    .line 1580
    .line 1581
    const/high16 v11, 0x44550000    # 852.0f

    .line 1582
    .line 1583
    const v12, 0x44518000    # 838.0f

    .line 1584
    .line 1585
    .line 1586
    invoke-direct {v7, v8, v11, v8, v12}, Li85;-><init>(FFFF)V

    .line 1587
    .line 1588
    .line 1589
    new-instance v8, Lu85;

    .line 1590
    .line 1591
    move/from16 v19, v4

    .line 1592
    .line 1593
    const/high16 v4, 0x42d80000    # 108.0f

    .line 1594
    .line 1595
    invoke-direct {v8, v4}, Lu85;-><init>(F)V

    .line 1596
    .line 1597
    .line 1598
    move/from16 v20, v15

    .line 1599
    .line 1600
    new-instance v15, Lf85;

    .line 1601
    .line 1602
    move/from16 v21, v2

    .line 1603
    .line 1604
    const/high16 v2, 0x438d0000    # 282.0f

    .line 1605
    .line 1606
    invoke-direct {v15, v2}, Lf85;-><init>(F)V

    .line 1607
    .line 1608
    .line 1609
    new-instance v2, Li85;

    .line 1610
    .line 1611
    const/high16 v3, 0x43750000    # 245.0f

    .line 1612
    .line 1613
    const/high16 v9, 0x42b60000    # 91.0f

    .line 1614
    .line 1615
    const/high16 v11, 0x437c0000    # 252.0f

    .line 1616
    .line 1617
    invoke-direct {v2, v11, v4, v3, v9}, Li85;-><init>(FFFF)V

    .line 1618
    .line 1619
    .line 1620
    new-instance v3, Li85;

    .line 1621
    .line 1622
    const v4, 0x43818000    # 259.0f

    .line 1623
    .line 1624
    .line 1625
    const/high16 v9, 0x42540000    # 53.0f

    .line 1626
    .line 1627
    const/high16 v11, 0x436e0000    # 238.0f

    .line 1628
    .line 1629
    const/high16 v12, 0x42940000    # 74.0f

    .line 1630
    .line 1631
    invoke-direct {v3, v11, v12, v4, v9}, Li85;-><init>(FFFF)V

    .line 1632
    .line 1633
    .line 1634
    new-instance v4, Lg85;

    .line 1635
    .line 1636
    const/high16 v9, 0x43d20000    # 420.0f

    .line 1637
    .line 1638
    const/high16 v11, -0x3d280000    # -108.0f

    .line 1639
    .line 1640
    invoke-direct {v4, v9, v11}, Lg85;-><init>(FF)V

    .line 1641
    .line 1642
    .line 1643
    new-instance v9, Li85;

    .line 1644
    .line 1645
    const/high16 v11, 0x43d70000    # 430.0f

    .line 1646
    .line 1647
    const/high16 v12, 0x43de0000    # 444.0f

    .line 1648
    .line 1649
    const/high16 v1, -0x3d140000    # -118.0f

    .line 1650
    .line 1651
    invoke-direct {v9, v11, v1, v12, v1}, Li85;-><init>(FFFF)V

    .line 1652
    .line 1653
    .line 1654
    new-instance v11, Lf85;

    .line 1655
    .line 1656
    const/high16 v12, 0x43fb0000    # 502.0f

    .line 1657
    .line 1658
    invoke-direct {v11, v12}, Lf85;-><init>(F)V

    .line 1659
    .line 1660
    .line 1661
    new-instance v12, Li85;

    .line 1662
    .line 1663
    const/high16 v1, 0x44010000    # 516.0f

    .line 1664
    .line 1665
    move-object/from16 v25, v0

    .line 1666
    .line 1667
    const/high16 v0, 0x44030000    # 524.0f

    .line 1668
    .line 1669
    move-object/from16 v26, v2

    .line 1670
    .line 1671
    const/high16 v2, -0x3d240000    # -110.0f

    .line 1672
    .line 1673
    move-object/from16 v27, v3

    .line 1674
    .line 1675
    const/high16 v3, -0x3d140000    # -118.0f

    .line 1676
    .line 1677
    invoke-direct {v12, v1, v3, v0, v2}, Li85;-><init>(FFFF)V

    .line 1678
    .line 1679
    .line 1680
    new-instance v3, Li85;

    .line 1681
    .line 1682
    const/high16 v2, 0x44050000    # 532.0f

    .line 1683
    .line 1684
    const/high16 v1, -0x3d340000    # -102.0f

    .line 1685
    .line 1686
    const/high16 v0, -0x3d500000    # -88.0f

    .line 1687
    .line 1688
    invoke-direct {v3, v2, v1, v2, v0}, Li85;-><init>(FFFF)V

    .line 1689
    .line 1690
    .line 1691
    new-instance v1, Lu85;

    .line 1692
    .line 1693
    const v0, 0x44518000    # 838.0f

    .line 1694
    .line 1695
    .line 1696
    invoke-direct {v1, v0}, Lu85;-><init>(F)V

    .line 1697
    .line 1698
    .line 1699
    new-instance v0, Li85;

    .line 1700
    .line 1701
    move-object/from16 v33, v1

    .line 1702
    .line 1703
    move-object/from16 v30, v3

    .line 1704
    .line 1705
    move-object/from16 v34, v4

    .line 1706
    .line 1707
    const/high16 v1, 0x44030000    # 524.0f

    .line 1708
    .line 1709
    const/high16 v3, 0x44550000    # 852.0f

    .line 1710
    .line 1711
    const/high16 v4, 0x44570000    # 860.0f

    .line 1712
    .line 1713
    invoke-direct {v0, v2, v3, v1, v4}, Li85;-><init>(FFFF)V

    .line 1714
    .line 1715
    .line 1716
    new-instance v1, Li85;

    .line 1717
    .line 1718
    const/high16 v2, 0x44010000    # 516.0f

    .line 1719
    .line 1720
    const/high16 v3, 0x43fb0000    # 502.0f

    .line 1721
    .line 1722
    const/high16 v4, 0x44590000    # 868.0f

    .line 1723
    .line 1724
    invoke-direct {v1, v2, v4, v3, v4}, Li85;-><init>(FFFF)V

    .line 1725
    .line 1726
    .line 1727
    new-instance v2, Lh85;

    .line 1728
    .line 1729
    const v3, 0x445d8000    # 886.0f

    .line 1730
    .line 1731
    .line 1732
    invoke-direct {v2, v3, v4}, Lh85;-><init>(FF)V

    .line 1733
    .line 1734
    .line 1735
    new-instance v3, Lf85;

    .line 1736
    .line 1737
    const/high16 v4, 0x444f0000    # 828.0f

    .line 1738
    .line 1739
    invoke-direct {v3, v4}, Lf85;-><init>(F)V

    .line 1740
    .line 1741
    .line 1742
    new-instance v4, Li85;

    .line 1743
    .line 1744
    move-object/from16 v35, v0

    .line 1745
    .line 1746
    const v0, 0x444b8000    # 814.0f

    .line 1747
    .line 1748
    .line 1749
    move-object/from16 v36, v1

    .line 1750
    .line 1751
    const v1, 0x44498000    # 806.0f

    .line 1752
    .line 1753
    .line 1754
    move-object/from16 v37, v2

    .line 1755
    .line 1756
    move-object/from16 p1, v3

    .line 1757
    .line 1758
    const/high16 v2, 0x44570000    # 860.0f

    .line 1759
    .line 1760
    const/high16 v3, 0x44590000    # 868.0f

    .line 1761
    .line 1762
    invoke-direct {v4, v0, v3, v1, v2}, Li85;-><init>(FFFF)V

    .line 1763
    .line 1764
    .line 1765
    new-instance v2, Li85;

    .line 1766
    .line 1767
    const v3, 0x44478000    # 798.0f

    .line 1768
    .line 1769
    .line 1770
    const v0, 0x44518000    # 838.0f

    .line 1771
    .line 1772
    .line 1773
    const/high16 v1, 0x44550000    # 852.0f

    .line 1774
    .line 1775
    invoke-direct {v2, v3, v1, v3, v0}, Li85;-><init>(FFFF)V

    .line 1776
    .line 1777
    .line 1778
    new-instance v0, Lu85;

    .line 1779
    .line 1780
    const/high16 v1, -0x3d500000    # -88.0f

    .line 1781
    .line 1782
    invoke-direct {v0, v1}, Lu85;-><init>(F)V

    .line 1783
    .line 1784
    .line 1785
    new-instance v1, Li85;

    .line 1786
    .line 1787
    move-object/from16 v22, v0

    .line 1788
    .line 1789
    move-object/from16 p2, v2

    .line 1790
    .line 1791
    move-object/from16 v28, v4

    .line 1792
    .line 1793
    const v0, 0x44498000    # 806.0f

    .line 1794
    .line 1795
    .line 1796
    const/high16 v2, -0x3d340000    # -102.0f

    .line 1797
    .line 1798
    const/high16 v4, -0x3d240000    # -110.0f

    .line 1799
    .line 1800
    invoke-direct {v1, v3, v2, v0, v4}, Li85;-><init>(FFFF)V

    .line 1801
    .line 1802
    .line 1803
    new-instance v0, Li85;

    .line 1804
    .line 1805
    const v2, 0x444b8000    # 814.0f

    .line 1806
    .line 1807
    .line 1808
    const/high16 v3, 0x444f0000    # 828.0f

    .line 1809
    .line 1810
    const/high16 v4, -0x3d140000    # -118.0f

    .line 1811
    .line 1812
    invoke-direct {v0, v2, v4, v3, v4}, Li85;-><init>(FFFF)V

    .line 1813
    .line 1814
    .line 1815
    new-instance v2, Lf85;

    .line 1816
    .line 1817
    const v3, 0x445dc000    # 887.0f

    .line 1818
    .line 1819
    .line 1820
    invoke-direct {v2, v3}, Lf85;-><init>(F)V

    .line 1821
    .line 1822
    .line 1823
    new-instance v3, Li85;

    .line 1824
    .line 1825
    move-object/from16 v29, v0

    .line 1826
    .line 1827
    const v0, 0x44614000    # 901.0f

    .line 1828
    .line 1829
    .line 1830
    move-object/from16 v38, v1

    .line 1831
    .line 1832
    const v1, 0x44634000    # 909.0f

    .line 1833
    .line 1834
    .line 1835
    move-object/from16 v39, v2

    .line 1836
    .line 1837
    const/high16 v2, -0x3d240000    # -110.0f

    .line 1838
    .line 1839
    invoke-direct {v3, v0, v4, v1, v2}, Li85;-><init>(FFFF)V

    .line 1840
    .line 1841
    .line 1842
    new-instance v0, Li85;

    .line 1843
    .line 1844
    const v1, 0x44654000    # 917.0f

    .line 1845
    .line 1846
    .line 1847
    const/high16 v2, -0x3d500000    # -88.0f

    .line 1848
    .line 1849
    const/high16 v4, -0x3d340000    # -102.0f

    .line 1850
    .line 1851
    invoke-direct {v0, v1, v4, v1, v2}, Li85;-><init>(FFFF)V

    .line 1852
    .line 1853
    .line 1854
    new-instance v1, Lu85;

    .line 1855
    .line 1856
    const v2, 0x44208000    # 642.0f

    .line 1857
    .line 1858
    .line 1859
    invoke-direct {v1, v2}, Lu85;-><init>(F)V

    .line 1860
    .line 1861
    .line 1862
    new-instance v4, Lf85;

    .line 1863
    .line 1864
    const/high16 v2, 0x44830000    # 1048.0f

    .line 1865
    .line 1866
    invoke-direct {v4, v2}, Lf85;-><init>(F)V

    .line 1867
    .line 1868
    .line 1869
    new-instance v2, Li85;

    .line 1870
    .line 1871
    move-object/from16 v31, v0

    .line 1872
    .line 1873
    const v0, 0x4487a000    # 1085.0f

    .line 1874
    .line 1875
    .line 1876
    move-object/from16 v32, v1

    .line 1877
    .line 1878
    const v1, 0x4424c000    # 659.0f

    .line 1879
    .line 1880
    .line 1881
    move-object/from16 v40, v3

    .line 1882
    .line 1883
    const v3, 0x4486c000    # 1078.0f

    .line 1884
    .line 1885
    .line 1886
    move-object/from16 v41, v4

    .line 1887
    .line 1888
    const v4, 0x44208000    # 642.0f

    .line 1889
    .line 1890
    .line 1891
    invoke-direct {v2, v3, v4, v0, v1}, Li85;-><init>(FFFF)V

    .line 1892
    .line 1893
    .line 1894
    new-instance v0, Li85;

    .line 1895
    .line 1896
    const v1, 0x4485e000    # 1071.0f

    .line 1897
    .line 1898
    .line 1899
    const v3, 0x442e4000    # 697.0f

    .line 1900
    .line 1901
    .line 1902
    const v4, 0x44888000    # 1092.0f

    .line 1903
    .line 1904
    .line 1905
    move-object/from16 v24, v2

    .line 1906
    .line 1907
    const/high16 v2, 0x44290000    # 676.0f

    .line 1908
    .line 1909
    invoke-direct {v0, v4, v2, v1, v3}, Li85;-><init>(FFFF)V

    .line 1910
    .line 1911
    .line 1912
    new-instance v1, Lg85;

    .line 1913
    .line 1914
    const v2, 0x44638000    # 910.0f

    .line 1915
    .line 1916
    .line 1917
    const v3, 0x44568000    # 858.0f

    .line 1918
    .line 1919
    .line 1920
    invoke-direct {v1, v2, v3}, Lg85;-><init>(FF)V

    .line 1921
    .line 1922
    .line 1923
    new-instance v2, Li85;

    .line 1924
    .line 1925
    const/high16 v3, 0x44610000    # 900.0f

    .line 1926
    .line 1927
    move-object/from16 p0, v0

    .line 1928
    .line 1929
    const/high16 v0, 0x44590000    # 868.0f

    .line 1930
    .line 1931
    const v4, 0x445d8000    # 886.0f

    .line 1932
    .line 1933
    .line 1934
    invoke-direct {v2, v3, v0, v4, v0}, Li85;-><init>(FFFF)V

    .line 1935
    .line 1936
    .line 1937
    const/16 v0, 0x22

    .line 1938
    .line 1939
    new-array v0, v0, [Lv85;

    .line 1940
    .line 1941
    aput-object v25, v0, v21

    .line 1942
    .line 1943
    aput-object v5, v0, v19

    .line 1944
    .line 1945
    aput-object v6, v0, v20

    .line 1946
    .line 1947
    aput-object v7, v0, v17

    .line 1948
    .line 1949
    const/4 v3, 0x4

    .line 1950
    aput-object v8, v0, v3

    .line 1951
    .line 1952
    const/4 v3, 0x5

    .line 1953
    aput-object v15, v0, v3

    .line 1954
    .line 1955
    aput-object v26, v0, v16

    .line 1956
    .line 1957
    const/4 v3, 0x7

    .line 1958
    aput-object v27, v0, v3

    .line 1959
    .line 1960
    const/16 v3, 0x8

    .line 1961
    .line 1962
    aput-object v34, v0, v3

    .line 1963
    .line 1964
    const/16 v3, 0x9

    .line 1965
    .line 1966
    aput-object v9, v0, v3

    .line 1967
    .line 1968
    const/16 v3, 0xa

    .line 1969
    .line 1970
    aput-object v11, v0, v3

    .line 1971
    .line 1972
    const/16 v3, 0xb

    .line 1973
    .line 1974
    aput-object v12, v0, v3

    .line 1975
    .line 1976
    const/16 v3, 0xc

    .line 1977
    .line 1978
    aput-object v30, v0, v3

    .line 1979
    .line 1980
    const/16 v3, 0xd

    .line 1981
    .line 1982
    aput-object v33, v0, v3

    .line 1983
    .line 1984
    const/16 v18, 0xe

    .line 1985
    .line 1986
    aput-object v35, v0, v18

    .line 1987
    .line 1988
    const/16 v3, 0xf

    .line 1989
    .line 1990
    aput-object v36, v0, v3

    .line 1991
    .line 1992
    sget-object v3, Ld85;->c:Ld85;

    .line 1993
    .line 1994
    const/16 v4, 0x10

    .line 1995
    .line 1996
    aput-object v3, v0, v4

    .line 1997
    .line 1998
    const/16 v4, 0x11

    .line 1999
    .line 2000
    aput-object v37, v0, v4

    .line 2001
    .line 2002
    const/16 v4, 0x12

    .line 2003
    .line 2004
    aput-object p1, v0, v4

    .line 2005
    .line 2006
    const/16 v4, 0x13

    .line 2007
    .line 2008
    aput-object v28, v0, v4

    .line 2009
    .line 2010
    const/16 v4, 0x14

    .line 2011
    .line 2012
    aput-object p2, v0, v4

    .line 2013
    .line 2014
    const/16 v4, 0x15

    .line 2015
    .line 2016
    aput-object v22, v0, v4

    .line 2017
    .line 2018
    const/16 v4, 0x16

    .line 2019
    .line 2020
    aput-object v38, v0, v4

    .line 2021
    .line 2022
    const/16 v4, 0x17

    .line 2023
    .line 2024
    aput-object v29, v0, v4

    .line 2025
    .line 2026
    const/16 v4, 0x18

    .line 2027
    .line 2028
    aput-object v39, v0, v4

    .line 2029
    .line 2030
    const/16 v4, 0x19

    .line 2031
    .line 2032
    aput-object v40, v0, v4

    .line 2033
    .line 2034
    const/16 v4, 0x1a

    .line 2035
    .line 2036
    aput-object v31, v0, v4

    .line 2037
    .line 2038
    const/16 v4, 0x1b

    .line 2039
    .line 2040
    aput-object v32, v0, v4

    .line 2041
    .line 2042
    const/16 v4, 0x1c

    .line 2043
    .line 2044
    aput-object v41, v0, v4

    .line 2045
    .line 2046
    const/16 v4, 0x1d

    .line 2047
    .line 2048
    aput-object v24, v0, v4

    .line 2049
    .line 2050
    const/16 v4, 0x1e

    .line 2051
    .line 2052
    aput-object p0, v0, v4

    .line 2053
    .line 2054
    const/16 v4, 0x1f

    .line 2055
    .line 2056
    aput-object v1, v0, v4

    .line 2057
    .line 2058
    const/16 v1, 0x20

    .line 2059
    .line 2060
    aput-object v2, v0, v1

    .line 2061
    .line 2062
    const/16 v1, 0x21

    .line 2063
    .line 2064
    aput-object v3, v0, v1

    .line 2065
    .line 2066
    invoke-static {v0}, Lqf;->Y([Ljava/lang/Object;)Ljava/util/List;

    .line 2067
    .line 2068
    .line 2069
    move-result-object v0

    .line 2070
    const v1, 0x3fd5566d    # 1.6667f

    .line 2071
    .line 2072
    .line 2073
    const v2, 0x44823556

    .line 2074
    .line 2075
    .line 2076
    const-string v3, "MobileNetwork.Glass.Regular"

    .line 2077
    .line 2078
    invoke-static {v3, v0, v1, v2}, Lnk;->y(Ljava/lang/String;Ljava/util/List;FF)La53;

    .line 2079
    .line 2080
    .line 2081
    move-result-object v0

    .line 2082
    sput-object v0, Lx33;->f:La53;

    .line 2083
    .line 2084
    :goto_a
    move-object v5, v0

    .line 2085
    goto :goto_b

    .line 2086
    :pswitch_9
    move/from16 v21, v2

    .line 2087
    .line 2088
    invoke-static {}, Lcj6;->h()La53;

    .line 2089
    .line 2090
    .line 2091
    move-result-object v0

    .line 2092
    goto :goto_a

    .line 2093
    :goto_b
    const v0, 0x7f0f02a0

    .line 2094
    .line 2095
    .line 2096
    invoke-static {v0, v10}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 2097
    .line 2098
    .line 2099
    move-result-object v6

    .line 2100
    if-eqz v13, :cond_15

    .line 2101
    .line 2102
    const v0, -0x4463e719

    .line 2103
    .line 2104
    .line 2105
    invoke-virtual {v10, v0}, Lki2;->h0(I)V

    .line 2106
    .line 2107
    .line 2108
    sget-object v0, Lsz0;->a:Lcx1;

    .line 2109
    .line 2110
    invoke-virtual {v10, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 2111
    .line 2112
    .line 2113
    move-result-object v0

    .line 2114
    check-cast v0, Lrz0;

    .line 2115
    .line 2116
    invoke-virtual {v0}, Lrz0;->i()J

    .line 2117
    .line 2118
    .line 2119
    move-result-wide v0

    .line 2120
    move/from16 v2, v21

    .line 2121
    .line 2122
    invoke-virtual {v10, v2}, Lki2;->r(Z)V

    .line 2123
    .line 2124
    .line 2125
    :goto_c
    move-wide v8, v0

    .line 2126
    goto :goto_d

    .line 2127
    :cond_15
    move/from16 v2, v21

    .line 2128
    .line 2129
    const v0, -0x4463de48

    .line 2130
    .line 2131
    .line 2132
    invoke-virtual {v10, v0}, Lki2;->h0(I)V

    .line 2133
    .line 2134
    .line 2135
    sget-object v0, Lsz0;->a:Lcx1;

    .line 2136
    .line 2137
    invoke-virtual {v10, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 2138
    .line 2139
    .line 2140
    move-result-object v0

    .line 2141
    check-cast v0, Lrz0;

    .line 2142
    .line 2143
    invoke-virtual {v0}, Lrz0;->d()J

    .line 2144
    .line 2145
    .line 2146
    move-result-wide v0

    .line 2147
    invoke-virtual {v10, v2}, Lki2;->r(Z)V

    .line 2148
    .line 2149
    .line 2150
    goto :goto_c

    .line 2151
    :goto_d
    const/4 v11, 0x0

    .line 2152
    const/4 v12, 0x4

    .line 2153
    const/4 v7, 0x0

    .line 2154
    invoke-static/range {v5 .. v12}, Lr94;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 2155
    .line 2156
    .line 2157
    goto :goto_e

    .line 2158
    :cond_16
    invoke-virtual {v10}, Lki2;->b0()V

    .line 2159
    .line 2160
    .line 2161
    :goto_e
    return-object v14

    .line 2162
    :pswitch_a
    move/from16 v19, v4

    .line 2163
    .line 2164
    move/from16 v20, v15

    .line 2165
    .line 2166
    check-cast v3, Ljava/util/ArrayList;

    .line 2167
    .line 2168
    move-object/from16 v0, p1

    .line 2169
    .line 2170
    check-cast v0, Lki2;

    .line 2171
    .line 2172
    move-object/from16 v1, p2

    .line 2173
    .line 2174
    check-cast v1, Ljava/lang/Integer;

    .line 2175
    .line 2176
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2177
    .line 2178
    .line 2179
    move-result v1

    .line 2180
    and-int/lit8 v2, v1, 0x3

    .line 2181
    .line 2182
    move/from16 v4, v20

    .line 2183
    .line 2184
    if-eq v2, v4, :cond_17

    .line 2185
    .line 2186
    move/from16 v2, v19

    .line 2187
    .line 2188
    goto :goto_f

    .line 2189
    :cond_17
    const/4 v2, 0x0

    .line 2190
    :goto_f
    and-int/lit8 v1, v1, 0x1

    .line 2191
    .line 2192
    invoke-virtual {v0, v1, v2}, Lki2;->Y(IZ)Z

    .line 2193
    .line 2194
    .line 2195
    move-result v1

    .line 2196
    if-eqz v1, :cond_1a

    .line 2197
    .line 2198
    sget-object v1, Lea4;->h:Lea4;

    .line 2199
    .line 2200
    invoke-static {v1, v5}, Lit6;->e(Lha4;F)Lha4;

    .line 2201
    .line 2202
    .line 2203
    move-result-object v1

    .line 2204
    new-instance v2, Luw;

    .line 2205
    .line 2206
    new-instance v4, Lt32;

    .line 2207
    .line 2208
    move/from16 v6, v17

    .line 2209
    .line 2210
    invoke-direct {v4, v6}, Lt32;-><init>(B)V

    .line 2211
    .line 2212
    .line 2213
    move/from16 v6, v19

    .line 2214
    .line 2215
    invoke-direct {v2, v10, v6, v4}, Luw;-><init>(FZLt32;)V

    .line 2216
    .line 2217
    .line 2218
    sget-object v4, Ly6;->s:Lz30;

    .line 2219
    .line 2220
    move/from16 v6, v16

    .line 2221
    .line 2222
    invoke-static {v2, v4, v0, v6}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 2223
    .line 2224
    .line 2225
    move-result-object v2

    .line 2226
    iget-wide v6, v0, Lki2;->U:J

    .line 2227
    .line 2228
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 2229
    .line 2230
    .line 2231
    move-result v4

    .line 2232
    invoke-virtual {v0}, Lki2;->m()Lr95;

    .line 2233
    .line 2234
    .line 2235
    move-result-object v6

    .line 2236
    invoke-static {v0, v1}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 2237
    .line 2238
    .line 2239
    move-result-object v1

    .line 2240
    sget-object v7, Lp41;->d:Ly6;

    .line 2241
    .line 2242
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2243
    .line 2244
    .line 2245
    invoke-virtual {v0}, Lki2;->k0()V

    .line 2246
    .line 2247
    .line 2248
    iget-boolean v7, v0, Lki2;->T:Z

    .line 2249
    .line 2250
    if-eqz v7, :cond_18

    .line 2251
    .line 2252
    sget-object v7, Lwi3;->Z:Lj43;

    .line 2253
    .line 2254
    invoke-virtual {v0, v7}, Lki2;->l(Lwg2;)V

    .line 2255
    .line 2256
    .line 2257
    goto :goto_10

    .line 2258
    :cond_18
    invoke-virtual {v0}, Lki2;->t0()V

    .line 2259
    .line 2260
    .line 2261
    :goto_10
    sget-object v7, Ly6;->T:Lu31;

    .line 2262
    .line 2263
    invoke-static {v7, v0, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 2264
    .line 2265
    .line 2266
    sget-object v2, Ly6;->S:Lu31;

    .line 2267
    .line 2268
    invoke-static {v2, v0, v6}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 2269
    .line 2270
    .line 2271
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2272
    .line 2273
    .line 2274
    move-result-object v2

    .line 2275
    sget-object v4, Ly6;->U:Lu31;

    .line 2276
    .line 2277
    invoke-static {v4, v0, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 2278
    .line 2279
    .line 2280
    invoke-static {v0}, Lml6;->p(Lki2;)V

    .line 2281
    .line 2282
    .line 2283
    sget-object v2, Ly6;->R:Lu31;

    .line 2284
    .line 2285
    invoke-static {v2, v0, v1}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 2286
    .line 2287
    .line 2288
    const v1, -0x5f06c006

    .line 2289
    .line 2290
    .line 2291
    invoke-virtual {v0, v1}, Lki2;->h0(I)V

    .line 2292
    .line 2293
    .line 2294
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2295
    .line 2296
    .line 2297
    move-result-object v1

    .line 2298
    :goto_11
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 2299
    .line 2300
    .line 2301
    move-result v2

    .line 2302
    if-eqz v2, :cond_19

    .line 2303
    .line 2304
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2305
    .line 2306
    .line 2307
    move-result-object v2

    .line 2308
    check-cast v2, Lik4;

    .line 2309
    .line 2310
    new-instance v3, Lmj3;

    .line 2311
    .line 2312
    const/4 v6, 0x1

    .line 2313
    invoke-direct {v3, v5, v6}, Lmj3;-><init>(FZ)V

    .line 2314
    .line 2315
    .line 2316
    const/4 v4, 0x0

    .line 2317
    invoke-static {v2, v3, v13, v0, v4}, Lz33;->i(Lik4;Lha4;ZLki2;I)V

    .line 2318
    .line 2319
    .line 2320
    goto :goto_11

    .line 2321
    :cond_19
    const/4 v4, 0x0

    .line 2322
    const/4 v6, 0x1

    .line 2323
    invoke-virtual {v0, v4}, Lki2;->r(Z)V

    .line 2324
    .line 2325
    .line 2326
    invoke-virtual {v0, v6}, Lki2;->r(Z)V

    .line 2327
    .line 2328
    .line 2329
    goto :goto_12

    .line 2330
    :cond_1a
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2331
    .line 2332
    .line 2333
    :goto_12
    return-object v14

    .line 2334
    :pswitch_b
    move v6, v4

    .line 2335
    check-cast v3, Ljava/util/List;

    .line 2336
    .line 2337
    move-object/from16 v0, p1

    .line 2338
    .line 2339
    check-cast v0, Lki2;

    .line 2340
    .line 2341
    move-object/from16 v1, p2

    .line 2342
    .line 2343
    check-cast v1, Ljava/lang/Integer;

    .line 2344
    .line 2345
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2346
    .line 2347
    .line 2348
    invoke-static {v6}, Ld43;->P(I)I

    .line 2349
    .line 2350
    .line 2351
    move-result v1

    .line 2352
    invoke-static {v13, v3, v0, v1}, Lel;->q(ZLjava/util/List;Lki2;I)V

    .line 2353
    .line 2354
    .line 2355
    return-object v14

    .line 2356
    :pswitch_c
    check-cast v3, Lcv0;

    .line 2357
    .line 2358
    move-object/from16 v1, p1

    .line 2359
    .line 2360
    check-cast v1, Lki2;

    .line 2361
    .line 2362
    move-object/from16 v2, p2

    .line 2363
    .line 2364
    check-cast v2, Ljava/lang/Integer;

    .line 2365
    .line 2366
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 2367
    .line 2368
    .line 2369
    move-result v2

    .line 2370
    and-int/lit8 v4, v2, 0x3

    .line 2371
    .line 2372
    const/4 v5, 0x2

    .line 2373
    if-eq v4, v5, :cond_1b

    .line 2374
    .line 2375
    const/4 v4, 0x1

    .line 2376
    :goto_13
    const/16 v19, 0x1

    .line 2377
    .line 2378
    goto :goto_14

    .line 2379
    :cond_1b
    const/4 v4, 0x0

    .line 2380
    goto :goto_13

    .line 2381
    :goto_14
    and-int/lit8 v2, v2, 0x1

    .line 2382
    .line 2383
    invoke-virtual {v1, v2, v4}, Lki2;->Y(IZ)Z

    .line 2384
    .line 2385
    .line 2386
    move-result v2

    .line 2387
    if-eqz v2, :cond_1e

    .line 2388
    .line 2389
    const v2, 0x7f0f051f

    .line 2390
    .line 2391
    .line 2392
    invoke-static {v2, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 2393
    .line 2394
    .line 2395
    move-result-object v22

    .line 2396
    invoke-virtual {v3}, Lcv0;->a()Z

    .line 2397
    .line 2398
    .line 2399
    move-result v24

    .line 2400
    invoke-virtual {v1, v3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 2401
    .line 2402
    .line 2403
    move-result v2

    .line 2404
    invoke-virtual {v1}, Lki2;->T()Ljava/lang/Object;

    .line 2405
    .line 2406
    .line 2407
    move-result-object v4

    .line 2408
    if-nez v2, :cond_1c

    .line 2409
    .line 2410
    if-ne v4, v9, :cond_1d

    .line 2411
    .line 2412
    :cond_1c
    new-instance v4, Lsv0;

    .line 2413
    .line 2414
    const/4 v5, 0x2

    .line 2415
    invoke-direct {v4, v3, v5}, Lsv0;-><init>(Lcv0;B)V

    .line 2416
    .line 2417
    .line 2418
    invoke-virtual {v1, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 2419
    .line 2420
    .line 2421
    :cond_1d
    move-object/from16 v26, v4

    .line 2422
    .line 2423
    check-cast v26, Lhh2;

    .line 2424
    .line 2425
    const/16 v28, 0x0

    .line 2426
    .line 2427
    const/16 v29, 0xe

    .line 2428
    .line 2429
    const/16 v23, 0x0

    .line 2430
    .line 2431
    iget-boolean v0, v0, Lw50;->i:Z

    .line 2432
    .line 2433
    move/from16 v25, v0

    .line 2434
    .line 2435
    move-object/from16 v27, v1

    .line 2436
    .line 2437
    invoke-static/range {v22 .. v29}, Lk04;->h(Ljava/lang/String;La53;ZZLhh2;Lki2;II)V

    .line 2438
    .line 2439
    .line 2440
    goto :goto_15

    .line 2441
    :cond_1e
    move-object/from16 v27, v1

    .line 2442
    .line 2443
    invoke-virtual/range {v27 .. v27}, Lki2;->b0()V

    .line 2444
    .line 2445
    .line 2446
    :goto_15
    return-object v14

    .line 2447
    :pswitch_d
    check-cast v3, Ldw;

    .line 2448
    .line 2449
    move-object/from16 v0, p1

    .line 2450
    .line 2451
    check-cast v0, Lki2;

    .line 2452
    .line 2453
    move-object/from16 v1, p2

    .line 2454
    .line 2455
    check-cast v1, Ljava/lang/Integer;

    .line 2456
    .line 2457
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2458
    .line 2459
    .line 2460
    move-result v1

    .line 2461
    and-int/lit8 v2, v1, 0x3

    .line 2462
    .line 2463
    const/4 v5, 0x2

    .line 2464
    if-eq v2, v5, :cond_1f

    .line 2465
    .line 2466
    const/4 v2, 0x1

    .line 2467
    :goto_16
    const/16 v19, 0x1

    .line 2468
    .line 2469
    goto :goto_17

    .line 2470
    :cond_1f
    const/4 v2, 0x0

    .line 2471
    goto :goto_16

    .line 2472
    :goto_17
    and-int/lit8 v1, v1, 0x1

    .line 2473
    .line 2474
    invoke-virtual {v0, v1, v2}, Lki2;->Y(IZ)Z

    .line 2475
    .line 2476
    .line 2477
    move-result v1

    .line 2478
    if-eqz v1, :cond_20

    .line 2479
    .line 2480
    iget-object v1, v3, Ldw;->a:Ljava/lang/String;

    .line 2481
    .line 2482
    const/4 v2, 0x0

    .line 2483
    invoke-static {v1, v13, v0, v2}, Ljj;->g(Ljava/lang/String;ZLki2;I)V

    .line 2484
    .line 2485
    .line 2486
    goto :goto_18

    .line 2487
    :cond_20
    invoke-virtual {v0}, Lki2;->b0()V

    .line 2488
    .line 2489
    .line 2490
    :goto_18
    return-object v14

    .line 2491
    :pswitch_e
    check-cast v3, Ls50;

    .line 2492
    .line 2493
    move-object/from16 v9, p1

    .line 2494
    .line 2495
    check-cast v9, Lki2;

    .line 2496
    .line 2497
    move-object/from16 v0, p2

    .line 2498
    .line 2499
    check-cast v0, Ljava/lang/Integer;

    .line 2500
    .line 2501
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 2502
    .line 2503
    .line 2504
    move-result v0

    .line 2505
    and-int/lit8 v1, v0, 0x3

    .line 2506
    .line 2507
    const/4 v5, 0x2

    .line 2508
    if-eq v1, v5, :cond_21

    .line 2509
    .line 2510
    const/4 v2, 0x1

    .line 2511
    :cond_21
    const/16 v19, 0x1

    .line 2512
    .line 2513
    and-int/lit8 v0, v0, 0x1

    .line 2514
    .line 2515
    invoke-virtual {v9, v0, v2}, Lki2;->Y(IZ)Z

    .line 2516
    .line 2517
    .line 2518
    move-result v0

    .line 2519
    if-eqz v0, :cond_23

    .line 2520
    .line 2521
    if-eqz v13, :cond_22

    .line 2522
    .line 2523
    iget-object v0, v3, Ls50;->i:La53;

    .line 2524
    .line 2525
    :goto_19
    move-object v4, v0

    .line 2526
    goto :goto_1a

    .line 2527
    :cond_22
    iget-object v0, v3, Ls50;->j:La53;

    .line 2528
    .line 2529
    goto :goto_19

    .line 2530
    :goto_1a
    iget v0, v3, Ls50;->h:I

    .line 2531
    .line 2532
    invoke-static {v0, v9}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 2533
    .line 2534
    .line 2535
    move-result-object v5

    .line 2536
    const/4 v10, 0x0

    .line 2537
    const/16 v11, 0xc

    .line 2538
    .line 2539
    const/4 v6, 0x0

    .line 2540
    const-wide/16 v7, 0x0

    .line 2541
    .line 2542
    invoke-static/range {v4 .. v11}, Lw33;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 2543
    .line 2544
    .line 2545
    goto :goto_1b

    .line 2546
    :cond_23
    invoke-virtual {v9}, Lki2;->b0()V

    .line 2547
    .line 2548
    .line 2549
    :goto_1b
    return-object v14

    .line 2550
    nop

    .line 2551
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 2552
    .line 2553
    .line 2554
    .line 2555
    .line 2556
    .line 2557
    .line 2558
    .line 2559
    .line 2560
    .line 2561
    .line 2562
    .line 2563
    .line 2564
    .line 2565
    .line 2566
    .line 2567
    .line 2568
    .line 2569
    .line 2570
    .line 2571
    .line 2572
    .line 2573
    .line 2574
    .line 2575
    .line 2576
    .line 2577
    .line 2578
    .line 2579
    .line 2580
    .line 2581
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_9
        :pswitch_9
        :pswitch_9
        :pswitch_8
        :pswitch_8
        :pswitch_8
        :pswitch_8
    .end packed-switch
.end method
