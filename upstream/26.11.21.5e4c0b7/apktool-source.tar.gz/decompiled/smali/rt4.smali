.class public final synthetic Lrt4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ldt4;

.field public final synthetic j:Lhh2;

.field public final synthetic k:Lzd4;


# direct methods
.method public synthetic constructor <init>(Ldt4;Lhh2;Lzd4;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lrt4;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lrt4;->i:Ldt4;

    .line 4
    .line 5
    iput-object p2, p0, Lrt4;->j:Lhh2;

    .line 6
    .line 7
    iput-object p3, p0, Lrt4;->k:Lzd4;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lrt4;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    iget-object v4, v0, Lrt4;->k:Lzd4;

    .line 9
    .line 10
    iget-object v5, v0, Lrt4;->j:Lhh2;

    .line 11
    .line 12
    iget-object v0, v0, Lrt4;->i:Ldt4;

    .line 13
    .line 14
    const/16 v6, 0x10

    .line 15
    .line 16
    const/4 v7, 0x1

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, Lm01;

    .line 23
    .line 24
    move-object/from16 v8, p2

    .line 25
    .line 26
    check-cast v8, Lki2;

    .line 27
    .line 28
    move-object/from16 v9, p3

    .line 29
    .line 30
    check-cast v9, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result v9

    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    and-int/lit8 v1, v9, 0x11

    .line 40
    .line 41
    if-eq v1, v6, :cond_0

    .line 42
    .line 43
    move v1, v7

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move v1, v3

    .line 46
    :goto_0
    and-int/2addr v9, v7

    .line 47
    invoke-virtual {v8, v9, v1}, Lki2;->Y(IZ)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_5

    .line 52
    .line 53
    sget-object v1, Ldt4;->p:Lk32;

    .line 54
    .line 55
    invoke-virtual {v1}, Lq3;->iterator()Ljava/util/Iterator;

    .line 56
    .line 57
    .line 58
    move-result-object v20

    .line 59
    move v13, v3

    .line 60
    :goto_1
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    .line 61
    .line 62
    .line 63
    move-result v9

    .line 64
    if-eqz v9, :cond_6

    .line 65
    .line 66
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v9

    .line 70
    add-int/lit8 v21, v13, 0x1

    .line 71
    .line 72
    if-ltz v13, :cond_4

    .line 73
    .line 74
    check-cast v9, Ldt4;

    .line 75
    .line 76
    if-ne v0, v9, :cond_1

    .line 77
    .line 78
    move v10, v7

    .line 79
    goto :goto_2

    .line 80
    :cond_1
    move v10, v3

    .line 81
    :goto_2
    invoke-virtual {v1}, Ly2;->a()I

    .line 82
    .line 83
    .line 84
    move-result v14

    .line 85
    new-instance v11, Lh04;

    .line 86
    .line 87
    invoke-direct {v11, v9, v6}, Lh04;-><init>(Ljava/lang/Object;B)V

    .line 88
    .line 89
    .line 90
    const v12, 0x5812e1a1

    .line 91
    .line 92
    .line 93
    invoke-static {v12, v11, v8}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 94
    .line 95
    .line 96
    move-result-object v11

    .line 97
    invoke-virtual {v8, v5}, Lki2;->g(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v12

    .line 101
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    .line 102
    .line 103
    .line 104
    move-result v15

    .line 105
    invoke-virtual {v8, v15}, Lki2;->e(I)Z

    .line 106
    .line 107
    .line 108
    move-result v15

    .line 109
    or-int/2addr v12, v15

    .line 110
    invoke-virtual {v8}, Lki2;->T()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v15

    .line 114
    if-nez v12, :cond_2

    .line 115
    .line 116
    sget-object v12, Lz41;->a:Lql0;

    .line 117
    .line 118
    if-ne v15, v12, :cond_3

    .line 119
    .line 120
    :cond_2
    new-instance v15, Les4;

    .line 121
    .line 122
    invoke-direct {v15, v5, v9, v4, v7}, Les4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v8, v15}, Lki2;->q0(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    :cond_3
    check-cast v15, Lwg2;

    .line 129
    .line 130
    const/16 v18, 0x30

    .line 131
    .line 132
    const/16 v19, 0x678

    .line 133
    .line 134
    move-object v9, v11

    .line 135
    const/4 v11, 0x0

    .line 136
    const/4 v12, 0x0

    .line 137
    move-object/from16 v17, v8

    .line 138
    .line 139
    move v8, v10

    .line 140
    move-object v10, v15

    .line 141
    const/4 v15, 0x0

    .line 142
    const/16 v16, 0x0

    .line 143
    .line 144
    invoke-static/range {v8 .. v19}, La04;->e(ZLq21;Lwg2;Lha4;ZIILuh6;Lu35;Lki2;II)V

    .line 145
    .line 146
    .line 147
    move-object/from16 v8, v17

    .line 148
    .line 149
    move/from16 v13, v21

    .line 150
    .line 151
    goto :goto_1

    .line 152
    :cond_4
    invoke-static {}, Lqf;->z0()V

    .line 153
    .line 154
    .line 155
    const/4 v0, 0x0

    .line 156
    throw v0

    .line 157
    :cond_5
    move-object/from16 v17, v8

    .line 158
    .line 159
    invoke-virtual/range {v17 .. v17}, Lki2;->b0()V

    .line 160
    .line 161
    .line 162
    :cond_6
    return-object v2

    .line 163
    :pswitch_0
    move-object/from16 v1, p1

    .line 164
    .line 165
    check-cast v1, Lm01;

    .line 166
    .line 167
    move-object/from16 v15, p2

    .line 168
    .line 169
    check-cast v15, Lki2;

    .line 170
    .line 171
    move-object/from16 v8, p3

    .line 172
    .line 173
    check-cast v8, Ljava/lang/Integer;

    .line 174
    .line 175
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 176
    .line 177
    .line 178
    move-result v8

    .line 179
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 180
    .line 181
    .line 182
    and-int/lit8 v1, v8, 0x11

    .line 183
    .line 184
    if-eq v1, v6, :cond_7

    .line 185
    .line 186
    move v3, v7

    .line 187
    :cond_7
    and-int/2addr v8, v7

    .line 188
    invoke-virtual {v15, v8, v3}, Lki2;->Y(IZ)Z

    .line 189
    .line 190
    .line 191
    move-result v1

    .line 192
    if-eqz v1, :cond_8

    .line 193
    .line 194
    new-instance v1, Lrt4;

    .line 195
    .line 196
    invoke-direct {v1, v0, v5, v4, v7}, Lrt4;-><init>(Ldt4;Lhh2;Lzd4;B)V

    .line 197
    .line 198
    .line 199
    const v0, -0x75b4e959

    .line 200
    .line 201
    .line 202
    invoke-static {v0, v1, v15}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 203
    .line 204
    .line 205
    move-result-object v14

    .line 206
    const/high16 v16, 0x30000

    .line 207
    .line 208
    const/16 v17, 0x1f

    .line 209
    .line 210
    const/4 v8, 0x0

    .line 211
    const/4 v9, 0x0

    .line 212
    const/4 v10, 0x0

    .line 213
    const/4 v11, 0x0

    .line 214
    const-wide/16 v12, 0x0

    .line 215
    .line 216
    invoke-static/range {v8 .. v17}, La04;->c(IILha4;Lc24;JLq21;Lki2;II)V

    .line 217
    .line 218
    .line 219
    goto :goto_3

    .line 220
    :cond_8
    invoke-virtual {v15}, Lki2;->b0()V

    .line 221
    .line 222
    .line 223
    :goto_3
    return-object v2

    .line 224
    nop

    .line 225
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
