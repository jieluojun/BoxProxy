.class public final synthetic Lie1;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lie1;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lie1;->i:Ljava/util/List;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 34

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lie1;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    iget-object v0, v0, Lie1;->i:Ljava/util/List;

    .line 11
    .line 12
    packed-switch v1, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    move-object/from16 v1, p1

    .line 16
    .line 17
    check-cast v1, Lm01;

    .line 18
    .line 19
    move-object/from16 v15, p2

    .line 20
    .line 21
    check-cast v15, Lki2;

    .line 22
    .line 23
    move-object/from16 v6, p3

    .line 24
    .line 25
    check-cast v6, Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 28
    .line 29
    .line 30
    move-result v6

    .line 31
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    and-int/lit8 v1, v6, 0x11

    .line 35
    .line 36
    if-eq v1, v3, :cond_0

    .line 37
    .line 38
    move v1, v4

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    const/4 v1, 0x0

    .line 41
    :goto_0
    and-int/2addr v6, v4

    .line 42
    invoke-virtual {v15, v6, v1}, Lki2;->Y(IZ)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_2

    .line 47
    .line 48
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    const/4 v8, 0x0

    .line 53
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 54
    .line 55
    .line 56
    move-result v3

    .line 57
    if-eqz v3, :cond_3

    .line 58
    .line 59
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    add-int/lit8 v5, v8, 0x1

    .line 64
    .line 65
    if-ltz v8, :cond_1

    .line 66
    .line 67
    check-cast v3, Lj65;

    .line 68
    .line 69
    iget-object v4, v3, Lj65;->h:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v4, Ljava/lang/String;

    .line 72
    .line 73
    iget-object v3, v3, Lj65;->i:Ljava/lang/Object;

    .line 74
    .line 75
    move-object v7, v3

    .line 76
    check-cast v7, Lwg2;

    .line 77
    .line 78
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 79
    .line 80
    .line 81
    move-result v9

    .line 82
    new-instance v3, Lf25;

    .line 83
    .line 84
    const/16 v6, 0xa

    .line 85
    .line 86
    invoke-direct {v3, v4, v6}, Lf25;-><init>(Ljava/lang/String;B)V

    .line 87
    .line 88
    .line 89
    const v4, -0x3ea1e952

    .line 90
    .line 91
    .line 92
    invoke-static {v4, v3, v15}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    const/16 v16, 0x6

    .line 97
    .line 98
    const/16 v17, 0x3f0

    .line 99
    .line 100
    const/4 v10, 0x0

    .line 101
    const/4 v11, 0x0

    .line 102
    const/4 v12, 0x0

    .line 103
    const/4 v13, 0x0

    .line 104
    const/4 v14, 0x0

    .line 105
    invoke-static/range {v6 .. v17}, La04;->a(Lq21;Lwg2;IILha4;Lq21;ZLd24;Lu35;Lki2;II)V

    .line 106
    .line 107
    .line 108
    move v8, v5

    .line 109
    goto :goto_1

    .line 110
    :cond_1
    invoke-static {}, Lqf;->z0()V

    .line 111
    .line 112
    .line 113
    const/4 v0, 0x0

    .line 114
    throw v0

    .line 115
    :cond_2
    invoke-virtual {v15}, Lki2;->b0()V

    .line 116
    .line 117
    .line 118
    :cond_3
    return-object v2

    .line 119
    :pswitch_0
    sget-object v1, Ly6;->R:Lu31;

    .line 120
    .line 121
    sget-object v6, Ly6;->U:Lu31;

    .line 122
    .line 123
    sget-object v7, Ly6;->S:Lu31;

    .line 124
    .line 125
    sget-object v8, Ly6;->T:Lu31;

    .line 126
    .line 127
    move-object/from16 v9, p1

    .line 128
    .line 129
    check-cast v9, Lm01;

    .line 130
    .line 131
    move-object/from16 v10, p2

    .line 132
    .line 133
    check-cast v10, Lki2;

    .line 134
    .line 135
    move-object/from16 v11, p3

    .line 136
    .line 137
    check-cast v11, Ljava/lang/Integer;

    .line 138
    .line 139
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 140
    .line 141
    .line 142
    move-result v11

    .line 143
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 144
    .line 145
    .line 146
    and-int/lit8 v9, v11, 0x11

    .line 147
    .line 148
    if-eq v9, v3, :cond_4

    .line 149
    .line 150
    move v3, v4

    .line 151
    goto :goto_2

    .line 152
    :cond_4
    const/4 v3, 0x0

    .line 153
    :goto_2
    and-int/2addr v11, v4

    .line 154
    invoke-virtual {v10, v11, v3}, Lki2;->Y(IZ)Z

    .line 155
    .line 156
    .line 157
    move-result v3

    .line 158
    if-eqz v3, :cond_8

    .line 159
    .line 160
    sget-object v3, Lea4;->h:Lea4;

    .line 161
    .line 162
    const/high16 v9, 0x41800000    # 16.0f

    .line 163
    .line 164
    const/high16 v11, 0x41400000    # 12.0f

    .line 165
    .line 166
    invoke-static {v3, v9, v11}, Ljb3;->y(Lha4;FF)Lha4;

    .line 167
    .line 168
    .line 169
    move-result-object v9

    .line 170
    new-instance v12, Luw;

    .line 171
    .line 172
    new-instance v13, Lt32;

    .line 173
    .line 174
    const/4 v14, 0x3

    .line 175
    invoke-direct {v13, v14}, Lt32;-><init>(B)V

    .line 176
    .line 177
    .line 178
    const/high16 v14, 0x41000000    # 8.0f

    .line 179
    .line 180
    invoke-direct {v12, v14, v4, v13}, Luw;-><init>(FZLt32;)V

    .line 181
    .line 182
    .line 183
    sget-object v13, Ly6;->v:Ly30;

    .line 184
    .line 185
    const/4 v14, 0x6

    .line 186
    invoke-static {v12, v13, v10, v14}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 187
    .line 188
    .line 189
    move-result-object v12

    .line 190
    iget-wide v14, v10, Lki2;->U:J

    .line 191
    .line 192
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 193
    .line 194
    .line 195
    move-result v13

    .line 196
    invoke-virtual {v10}, Lki2;->m()Lr95;

    .line 197
    .line 198
    .line 199
    move-result-object v14

    .line 200
    invoke-static {v10, v9}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 201
    .line 202
    .line 203
    move-result-object v9

    .line 204
    sget-object v15, Lp41;->d:Ly6;

    .line 205
    .line 206
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 207
    .line 208
    .line 209
    invoke-virtual {v10}, Lki2;->k0()V

    .line 210
    .line 211
    .line 212
    iget-boolean v15, v10, Lki2;->T:Z

    .line 213
    .line 214
    sget-object v5, Lwi3;->Z:Lj43;

    .line 215
    .line 216
    if-eqz v15, :cond_5

    .line 217
    .line 218
    invoke-virtual {v10, v5}, Lki2;->l(Lwg2;)V

    .line 219
    .line 220
    .line 221
    goto :goto_3

    .line 222
    :cond_5
    invoke-virtual {v10}, Lki2;->t0()V

    .line 223
    .line 224
    .line 225
    :goto_3
    invoke-static {v8, v10, v12}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    invoke-static {v7, v10, v14}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    invoke-static {v13, v10, v6, v10}, Lx82;->w(ILki2;Lu31;Lki2;)V

    .line 232
    .line 233
    .line 234
    const v12, 0x4c4be316    # 5.3447768E7f

    .line 235
    .line 236
    .line 237
    invoke-static {v10, v9, v1, v12, v0}, Lv22;->t(Lki2;Lha4;Lu31;ILjava/util/List;)Ljava/util/Iterator;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 242
    .line 243
    .line 244
    move-result v9

    .line 245
    if-eqz v9, :cond_7

    .line 246
    .line 247
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v9

    .line 251
    check-cast v9, Lj65;

    .line 252
    .line 253
    iget-object v12, v9, Lj65;->h:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v12, Ljava/lang/String;

    .line 256
    .line 257
    iget-object v9, v9, Lj65;->i:Ljava/lang/Object;

    .line 258
    .line 259
    check-cast v9, Ljava/lang/String;

    .line 260
    .line 261
    const/high16 v13, 0x3f800000    # 1.0f

    .line 262
    .line 263
    invoke-static {v3, v13}, Lit6;->e(Lha4;F)Lha4;

    .line 264
    .line 265
    .line 266
    move-result-object v14

    .line 267
    sget-object v15, Ly6;->s:Lz30;

    .line 268
    .line 269
    sget-object v11, Lx87;->c:Lrw;

    .line 270
    .line 271
    const/16 v13, 0x30

    .line 272
    .line 273
    invoke-static {v11, v15, v10, v13}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 274
    .line 275
    .line 276
    move-result-object v11

    .line 277
    move-object/from16 p3, v5

    .line 278
    .line 279
    iget-wide v4, v10, Lki2;->U:J

    .line 280
    .line 281
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 282
    .line 283
    .line 284
    move-result v4

    .line 285
    invoke-virtual {v10}, Lki2;->m()Lr95;

    .line 286
    .line 287
    .line 288
    move-result-object v5

    .line 289
    invoke-static {v10, v14}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 290
    .line 291
    .line 292
    move-result-object v13

    .line 293
    sget-object v14, Lp41;->d:Ly6;

    .line 294
    .line 295
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 296
    .line 297
    .line 298
    invoke-virtual {v10}, Lki2;->k0()V

    .line 299
    .line 300
    .line 301
    iget-boolean v14, v10, Lki2;->T:Z

    .line 302
    .line 303
    if-eqz v14, :cond_6

    .line 304
    .line 305
    move-object/from16 v14, p3

    .line 306
    .line 307
    invoke-virtual {v10, v14}, Lki2;->l(Lwg2;)V

    .line 308
    .line 309
    .line 310
    goto :goto_5

    .line 311
    :cond_6
    move-object/from16 v14, p3

    .line 312
    .line 313
    invoke-virtual {v10}, Lki2;->t0()V

    .line 314
    .line 315
    .line 316
    :goto_5
    invoke-static {v8, v10, v11}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 317
    .line 318
    .line 319
    invoke-static {v7, v10, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 320
    .line 321
    .line 322
    invoke-static {v4, v10, v6, v10}, Lx82;->w(ILki2;Lu31;Lki2;)V

    .line 323
    .line 324
    .line 325
    invoke-static {v1, v10, v13}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 326
    .line 327
    .line 328
    sget-object v4, Lsz0;->a:Lcx1;

    .line 329
    .line 330
    invoke-virtual {v10, v4}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v5

    .line 334
    check-cast v5, Lrz0;

    .line 335
    .line 336
    invoke-virtual {v5}, Lrz0;->n()J

    .line 337
    .line 338
    .line 339
    move-result-wide v15

    .line 340
    sget-object v5, Lah7;->a:Lcx1;

    .line 341
    .line 342
    invoke-virtual {v10, v5}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v11

    .line 346
    check-cast v11, Lzg7;

    .line 347
    .line 348
    invoke-virtual {v11}, Lzg7;->c()Lwg7;

    .line 349
    .line 350
    .line 351
    move-result-object v28

    .line 352
    const/16 v31, 0x0

    .line 353
    .line 354
    const v32, 0x1fffa

    .line 355
    .line 356
    .line 357
    const/4 v11, 0x0

    .line 358
    move-object/from16 v29, v10

    .line 359
    .line 360
    move-object v10, v12

    .line 361
    move-wide v12, v15

    .line 362
    move-object/from16 v16, v14

    .line 363
    .line 364
    const-wide/16 v14, 0x0

    .line 365
    .line 366
    move-object/from16 v17, v16

    .line 367
    .line 368
    const/16 v16, 0x0

    .line 369
    .line 370
    move-object/from16 v18, v17

    .line 371
    .line 372
    const/16 v17, 0x0

    .line 373
    .line 374
    move-object/from16 v20, v18

    .line 375
    .line 376
    const-wide/16 v18, 0x0

    .line 377
    .line 378
    move-object/from16 v21, v20

    .line 379
    .line 380
    const/16 v20, 0x0

    .line 381
    .line 382
    move-object/from16 v23, v21

    .line 383
    .line 384
    const-wide/16 v21, 0x0

    .line 385
    .line 386
    move-object/from16 v24, v23

    .line 387
    .line 388
    const/16 v23, 0x0

    .line 389
    .line 390
    move-object/from16 v25, v24

    .line 391
    .line 392
    const/16 v24, 0x0

    .line 393
    .line 394
    move-object/from16 v26, v25

    .line 395
    .line 396
    const/16 v25, 0x0

    .line 397
    .line 398
    move-object/from16 v27, v26

    .line 399
    .line 400
    const/16 v26, 0x0

    .line 401
    .line 402
    move-object/from16 v30, v27

    .line 403
    .line 404
    const/16 v27, 0x0

    .line 405
    .line 406
    move-object/from16 v33, v30

    .line 407
    .line 408
    const/16 v30, 0x0

    .line 409
    .line 410
    move-object/from16 p3, v0

    .line 411
    .line 412
    const/high16 v0, 0x41400000    # 12.0f

    .line 413
    .line 414
    invoke-static/range {v10 .. v32}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 415
    .line 416
    .line 417
    move-object/from16 v10, v29

    .line 418
    .line 419
    invoke-static {v3, v0}, Lit6;->q(Lha4;F)Lha4;

    .line 420
    .line 421
    .line 422
    move-result-object v11

    .line 423
    invoke-static {v10, v11}, Lck6;->b(Lki2;Lha4;)V

    .line 424
    .line 425
    .line 426
    invoke-virtual {v10, v4}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 427
    .line 428
    .line 429
    move-result-object v4

    .line 430
    check-cast v4, Lrz0;

    .line 431
    .line 432
    invoke-virtual {v4}, Lrz0;->i()J

    .line 433
    .line 434
    .line 435
    move-result-wide v12

    .line 436
    invoke-virtual {v10, v5}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 437
    .line 438
    .line 439
    move-result-object v4

    .line 440
    check-cast v4, Lzg7;

    .line 441
    .line 442
    invoke-virtual {v4}, Lzg7;->c()Lwg7;

    .line 443
    .line 444
    .line 445
    move-result-object v28

    .line 446
    const/high16 v4, 0x3f800000    # 1.0f

    .line 447
    .line 448
    invoke-static {v3, v4}, Lit6;->e(Lha4;F)Lha4;

    .line 449
    .line 450
    .line 451
    move-result-object v11

    .line 452
    new-instance v4, Ld97;

    .line 453
    .line 454
    const/4 v5, 0x6

    .line 455
    invoke-direct {v4, v5}, Ld97;-><init>(I)V

    .line 456
    .line 457
    .line 458
    const v32, 0x1fbf8

    .line 459
    .line 460
    .line 461
    const/16 v30, 0x30

    .line 462
    .line 463
    move-object/from16 v20, v4

    .line 464
    .line 465
    move-object v10, v9

    .line 466
    invoke-static/range {v10 .. v32}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 467
    .line 468
    .line 469
    move-object/from16 v10, v29

    .line 470
    .line 471
    const/4 v4, 0x1

    .line 472
    invoke-virtual {v10, v4}, Lki2;->r(Z)V

    .line 473
    .line 474
    .line 475
    move-object/from16 v5, v33

    .line 476
    .line 477
    move-object/from16 v0, p3

    .line 478
    .line 479
    goto/16 :goto_4

    .line 480
    .line 481
    :cond_7
    const/4 v9, 0x0

    .line 482
    invoke-virtual {v10, v9}, Lki2;->r(Z)V

    .line 483
    .line 484
    .line 485
    invoke-virtual {v10, v4}, Lki2;->r(Z)V

    .line 486
    .line 487
    .line 488
    goto :goto_6

    .line 489
    :cond_8
    invoke-virtual {v10}, Lki2;->b0()V

    .line 490
    .line 491
    .line 492
    :goto_6
    return-object v2

    .line 493
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
