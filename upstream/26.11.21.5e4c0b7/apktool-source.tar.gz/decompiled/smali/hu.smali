.class public final synthetic Lhu;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:I

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lhu;->h:B

    .line 2
    .line 3
    iput p1, p0, Lhu;->i:I

    .line 4
    .line 5
    iput-object p2, p0, Lhu;->j:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;IB)V
    .locals 0

    .line 11
    iput-byte p3, p0, Lhu;->h:B

    iput-object p1, p0, Lhu;->j:Ljava/lang/Object;

    iput p2, p0, Lhu;->i:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 8

    .line 1
    iget-byte v0, p0, Lhu;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget v3, p0, Lhu;->i:I

    .line 7
    .line 8
    iget-object p0, p0, Lhu;->j:Ljava/lang/Object;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    check-cast p0, Lsh6;

    .line 14
    .line 15
    iget-object p0, p0, Lsh6;->f:Lse7;

    .line 16
    .line 17
    iget-object p0, p0, Lse7;->b:Lvb4;

    .line 18
    .line 19
    invoke-virtual {p0, v3}, Lvb4;->c(I)I

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0

    .line 28
    :pswitch_0
    check-cast p0, Lbd5;

    .line 29
    .line 30
    iget-object v0, p0, Lbd5;->a:Lzd4;

    .line 31
    .line 32
    invoke-interface {v0}, Lxy6;->getValue()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Ljava/util/List;

    .line 37
    .line 38
    new-instance v4, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 41
    .line 42
    .line 43
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 48
    .line 49
    .line 50
    move-result v5

    .line 51
    if-eqz v5, :cond_2

    .line 52
    .line 53
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v5

    .line 57
    add-int/lit8 v6, v2, 0x1

    .line 58
    .line 59
    if-ltz v2, :cond_1

    .line 60
    .line 61
    move-object v7, v5

    .line 62
    check-cast v7, Ljava/lang/String;

    .line 63
    .line 64
    if-eq v2, v3, :cond_0

    .line 65
    .line 66
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    :cond_0
    move v2, v6

    .line 70
    goto :goto_0

    .line 71
    :cond_1
    invoke-static {}, Lqf;->z0()V

    .line 72
    .line 73
    .line 74
    const/4 p0, 0x0

    .line 75
    throw p0

    .line 76
    :cond_2
    iget-object p0, p0, Lbd5;->a:Lzd4;

    .line 77
    .line 78
    invoke-interface {p0, v4}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    return-object v1

    .line 82
    :pswitch_1
    check-cast p0, Lwg2;

    .line 83
    .line 84
    new-instance v0, Lgn1;

    .line 85
    .line 86
    const/4 v1, 0x0

    .line 87
    invoke-direct {v0, v3, v1, p0}, Lgn1;-><init>(IFLwg2;)V

    .line 88
    .line 89
    .line 90
    return-object v0

    .line 91
    :pswitch_2
    check-cast p0, Lgn1;

    .line 92
    .line 93
    invoke-virtual {p0}, Lu55;->k()I

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    sub-int/2addr v3, v0

    .line 98
    int-to-float v0, v3

    .line 99
    invoke-virtual {p0}, Lu55;->l()F

    .line 100
    .line 101
    .line 102
    move-result p0

    .line 103
    sub-float/2addr v0, p0

    .line 104
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 105
    .line 106
    .line 107
    move-result p0

    .line 108
    const/high16 v0, 0x3f800000    # 1.0f

    .line 109
    .line 110
    cmpl-float p0, p0, v0

    .line 111
    .line 112
    if-ltz p0, :cond_3

    .line 113
    .line 114
    const/4 v2, 0x1

    .line 115
    :cond_3
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    return-object p0

    .line 120
    :pswitch_3
    check-cast p0, Lqv;

    .line 121
    .line 122
    iget-object p0, p0, Lqv;->e:Lzd4;

    .line 123
    .line 124
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-interface {p0, v0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    return-object v1

    .line 132
    nop

    .line 133
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
