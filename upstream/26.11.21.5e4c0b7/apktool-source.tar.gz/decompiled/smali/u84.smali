.class public abstract Lu84;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lcx1;

.field public static final b:Lcx1;

.field public static final c:Lcx1;

.field public static final d:Lcx1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lxu3;

    .line 2
    .line 3
    const/16 v1, 0x14

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lxu3;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lcx1;

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Lu84;->a:Lcx1;

    .line 15
    .line 16
    new-instance v0, Lxu3;

    .line 17
    .line 18
    const/16 v1, 0x15

    .line 19
    .line 20
    invoke-direct {v0, v1}, Lxu3;-><init>(B)V

    .line 21
    .line 22
    .line 23
    new-instance v1, Lcx1;

    .line 24
    .line 25
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 26
    .line 27
    .line 28
    sput-object v1, Lu84;->b:Lcx1;

    .line 29
    .line 30
    new-instance v0, Lxu3;

    .line 31
    .line 32
    const/16 v1, 0x16

    .line 33
    .line 34
    invoke-direct {v0, v1}, Lxu3;-><init>(B)V

    .line 35
    .line 36
    .line 37
    new-instance v1, Lcx1;

    .line 38
    .line 39
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 40
    .line 41
    .line 42
    sput-object v1, Lu84;->c:Lcx1;

    .line 43
    .line 44
    new-instance v0, Lxu3;

    .line 45
    .line 46
    const/16 v1, 0x17

    .line 47
    .line 48
    invoke-direct {v0, v1}, Lxu3;-><init>(B)V

    .line 49
    .line 50
    .line 51
    new-instance v1, Lcx1;

    .line 52
    .line 53
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 54
    .line 55
    .line 56
    sput-object v1, Lu84;->d:Lcx1;

    .line 57
    .line 58
    return-void
.end method
