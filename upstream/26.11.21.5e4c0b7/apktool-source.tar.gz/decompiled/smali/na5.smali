.class public final Lna5;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:J

.field public final b:J


# direct methods
.method public constructor <init>(JJ)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lna5;->a:J

    .line 5
    .line 6
    iput-wide p3, p0, Lna5;->b:J

    .line 7
    .line 8
    const-wide v0, 0xff00000000L

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    and-long/2addr p1, v0

    .line 14
    const-wide/16 v2, 0x0

    .line 15
    .line 16
    cmp-long p0, p1, v2

    .line 17
    .line 18
    if-nez p0, :cond_0

    .line 19
    .line 20
    const-string p0, "width cannot be TextUnit.Unspecified"

    .line 21
    .line 22
    invoke-static {p0}, Ln73;->a(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    and-long/2addr p3, v0

    .line 26
    cmp-long p0, p3, v2

    .line 27
    .line 28
    if-nez p0, :cond_1

    .line 29
    .line 30
    const-string p0, "height cannot be TextUnit.Unspecified"

    .line 31
    .line 32
    invoke-static {p0}, Ln73;->a(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    :cond_1
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lna5;

    .line 6
    .line 7
    if-eqz v1, :cond_1

    .line 8
    .line 9
    check-cast p1, Lna5;

    .line 10
    .line 11
    iget-wide v1, p1, Lna5;->a:J

    .line 12
    .line 13
    iget-wide v3, p0, Lna5;->a:J

    .line 14
    .line 15
    invoke-static {v3, v4, v1, v2}, Lgh7;->a(JJ)Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_1

    .line 20
    .line 21
    iget-wide v1, p0, Lna5;->b:J

    .line 22
    .line 23
    iget-wide p0, p1, Lna5;->b:J

    .line 24
    .line 25
    invoke-static {v1, v2, p0, p1}, Lgh7;->a(JJ)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-nez p0, :cond_2

    .line 30
    .line 31
    :cond_1
    const/4 p0, 0x0

    .line 32
    return p0

    .line 33
    :cond_2
    return v0
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    iget-wide v0, p0, Lna5;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-wide v1, p0, Lna5;->b:J

    .line 10
    .line 11
    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    add-int/2addr p0, v0

    .line 16
    mul-int/lit8 p0, p0, 0x1f

    .line 17
    .line 18
    add-int/lit8 p0, p0, 0x7

    .line 19
    .line 20
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    iget-wide v0, p0, Lna5;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Lgh7;->d(J)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-wide v1, p0, Lna5;->b:J

    .line 8
    .line 9
    invoke-static {v1, v2}, Lgh7;->d(J)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    const-string v1, ", height="

    .line 14
    .line 15
    const-string v2, ", placeholderVerticalAlign=TextCenter)"

    .line 16
    .line 17
    const-string v3, "Placeholder(width="

    .line 18
    .line 19
    invoke-static {v3, v0, v1, p0, v2}, Liv4;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method
