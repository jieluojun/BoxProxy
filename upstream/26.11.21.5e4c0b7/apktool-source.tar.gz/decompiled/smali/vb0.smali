.class public final synthetic Lvb0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lkb0;


# direct methods
.method public synthetic constructor <init>(Lkb0;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lvb0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lvb0;->i:Lkb0;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lvb0;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v3, 0x6

    .line 8
    sget-object v4, Lz41;->a:Lql0;

    .line 9
    .line 10
    const/16 v5, 0x10

    .line 11
    .line 12
    const/4 v6, 0x1

    .line 13
    const/4 v7, 0x0

    .line 14
    iget-object v0, v0, Lvb0;->i:Lkb0;

    .line 15
    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object/from16 v1, p1

    .line 20
    .line 21
    check-cast v1, Lja0;

    .line 22
    .line 23
    move-object/from16 v8, p2

    .line 24
    .line 25
    check-cast v8, Lki2;

    .line 26
    .line 27
    move-object/from16 v9, p3

    .line 28
    .line 29
    check-cast v9, Ljava/lang/Integer;

    .line 30
    .line 31
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 32
    .line 33
    .line 34
    move-result v9

    .line 35
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    and-int/lit8 v1, v9, 0x11

    .line 39
    .line 40
    if-eq v1, v5, :cond_0

    .line 41
    .line 42
    move v1, v6

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    move v1, v7

    .line 45
    :goto_0
    and-int/2addr v9, v6

    .line 46
    invoke-virtual {v8, v9, v1}, Lki2;->Y(IZ)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_5

    .line 51
    .line 52
    iget-object v1, v0, Lkb0;->c:Lor7;

    .line 53
    .line 54
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    if-eqz v1, :cond_4

    .line 59
    .line 60
    if-ne v1, v6, :cond_3

    .line 61
    .line 62
    const v1, 0x5da3437b

    .line 63
    .line 64
    .line 65
    invoke-virtual {v8, v1}, Lki2;->h0(I)V

    .line 66
    .line 67
    .line 68
    iget-object v11, v0, Lkb0;->e:Lhj4;

    .line 69
    .line 70
    invoke-virtual {v8, v11}, Lki2;->i(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    invoke-virtual {v8}, Lki2;->T()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    if-nez v0, :cond_1

    .line 79
    .line 80
    if-ne v1, v4, :cond_2

    .line 81
    .line 82
    :cond_1
    new-instance v9, Lwb0;

    .line 83
    .line 84
    const/4 v15, 0x0

    .line 85
    const/16 v16, 0x5

    .line 86
    .line 87
    const/4 v10, 0x0

    .line 88
    const-class v12, Lhj4;

    .line 89
    .line 90
    const-string v13, "pop"

    .line 91
    .line 92
    const-string v14, "pop()V"

    .line 93
    .line 94
    invoke-direct/range {v9 .. v16}, Lwb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v8, v9}, Lki2;->q0(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    move-object v1, v9

    .line 101
    :cond_2
    check-cast v1, Lwh2;

    .line 102
    .line 103
    check-cast v1, Lwg2;

    .line 104
    .line 105
    sget-object v0, Lit6;->c:Lk92;

    .line 106
    .line 107
    const/16 v3, 0x30

    .line 108
    .line 109
    invoke-static {v1, v0, v8, v3}, Lha1;->j(Lwg2;Lha4;Lki2;I)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v8, v7}, Lki2;->r(Z)V

    .line 113
    .line 114
    .line 115
    goto :goto_1

    .line 116
    :cond_3
    const v0, 0x5da31f54

    .line 117
    .line 118
    .line 119
    invoke-static {v0, v8, v7}, Lx82;->f(ILki2;Z)Ll11;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    throw v0

    .line 124
    :cond_4
    const v1, 0x5da324c7

    .line 125
    .line 126
    .line 127
    invoke-virtual {v8, v1}, Lki2;->h0(I)V

    .line 128
    .line 129
    .line 130
    sget-object v1, Lx87;->m:Lq21;

    .line 131
    .line 132
    new-instance v4, Lnb0;

    .line 133
    .line 134
    const/16 v5, 0x16

    .line 135
    .line 136
    invoke-direct {v4, v0, v5}, Lnb0;-><init>(Lkb0;B)V

    .line 137
    .line 138
    .line 139
    const v0, 0x18cee714

    .line 140
    .line 141
    .line 142
    invoke-static {v0, v4, v8}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-static {v3, v1, v0, v8, v7}, Lx82;->v(ILq21;Lq21;Lki2;Z)V

    .line 147
    .line 148
    .line 149
    goto :goto_1

    .line 150
    :cond_5
    invoke-virtual {v8}, Lki2;->b0()V

    .line 151
    .line 152
    .line 153
    :goto_1
    return-object v2

    .line 154
    :pswitch_0
    iget-object v1, v0, Lkb0;->c:Lor7;

    .line 155
    .line 156
    move-object/from16 v8, p1

    .line 157
    .line 158
    check-cast v8, Lga0;

    .line 159
    .line 160
    move-object/from16 v9, p2

    .line 161
    .line 162
    check-cast v9, Lki2;

    .line 163
    .line 164
    move-object/from16 v10, p3

    .line 165
    .line 166
    check-cast v10, Ljava/lang/Integer;

    .line 167
    .line 168
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 169
    .line 170
    .line 171
    move-result v10

    .line 172
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 173
    .line 174
    .line 175
    and-int/lit8 v8, v10, 0x11

    .line 176
    .line 177
    if-eq v8, v5, :cond_6

    .line 178
    .line 179
    move v5, v6

    .line 180
    goto :goto_2

    .line 181
    :cond_6
    move v5, v7

    .line 182
    :goto_2
    and-int/2addr v10, v6

    .line 183
    invoke-virtual {v9, v10, v5}, Lki2;->Y(IZ)Z

    .line 184
    .line 185
    .line 186
    move-result v5

    .line 187
    if-eqz v5, :cond_b

    .line 188
    .line 189
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 190
    .line 191
    .line 192
    move-result v5

    .line 193
    if-eqz v5, :cond_a

    .line 194
    .line 195
    if-ne v5, v6, :cond_9

    .line 196
    .line 197
    const v3, 0x4803a778    # 134813.88f

    .line 198
    .line 199
    .line 200
    invoke-virtual {v9, v3}, Lki2;->h0(I)V

    .line 201
    .line 202
    .line 203
    iget-object v12, v0, Lkb0;->e:Lhj4;

    .line 204
    .line 205
    invoke-virtual {v9, v12}, Lki2;->i(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result v0

    .line 209
    invoke-virtual {v9}, Lki2;->T()Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object v3

    .line 213
    if-nez v0, :cond_7

    .line 214
    .line 215
    if-ne v3, v4, :cond_8

    .line 216
    .line 217
    :cond_7
    new-instance v10, Ltb0;

    .line 218
    .line 219
    const/16 v16, 0x0

    .line 220
    .line 221
    const/16 v17, 0x1b

    .line 222
    .line 223
    const/4 v11, 0x0

    .line 224
    const-class v13, Lhj4;

    .line 225
    .line 226
    const-string v14, "pop"

    .line 227
    .line 228
    const-string v15, "pop()V"

    .line 229
    .line 230
    invoke-direct/range {v10 .. v17}, Ltb0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v9, v10}, Lki2;->q0(Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    move-object v3, v10

    .line 237
    :cond_8
    check-cast v3, Lwh2;

    .line 238
    .line 239
    check-cast v3, Lwg2;

    .line 240
    .line 241
    invoke-static {v1, v3, v9, v7}, Lf48;->d(Lor7;Lwg2;Lki2;I)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v9, v7}, Lki2;->r(Z)V

    .line 245
    .line 246
    .line 247
    goto :goto_3

    .line 248
    :cond_9
    const v0, 0x4803880a

    .line 249
    .line 250
    .line 251
    invoke-static {v0, v9, v7}, Lx82;->f(ILki2;Z)Ll11;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    throw v0

    .line 256
    :cond_a
    const v1, 0x48038db1

    .line 257
    .line 258
    .line 259
    invoke-virtual {v9, v1}, Lki2;->h0(I)V

    .line 260
    .line 261
    .line 262
    sget-object v1, Lx87;->m:Lq21;

    .line 263
    .line 264
    new-instance v4, Lnb0;

    .line 265
    .line 266
    const/16 v5, 0x17

    .line 267
    .line 268
    invoke-direct {v4, v0, v5}, Lnb0;-><init>(Lkb0;B)V

    .line 269
    .line 270
    .line 271
    const v0, -0xc31e300

    .line 272
    .line 273
    .line 274
    invoke-static {v0, v4, v9}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    invoke-static {v3, v1, v0, v9, v7}, Lx82;->v(ILq21;Lq21;Lki2;Z)V

    .line 279
    .line 280
    .line 281
    goto :goto_3

    .line 282
    :cond_b
    invoke-virtual {v9}, Lki2;->b0()V

    .line 283
    .line 284
    .line 285
    :goto_3
    return-object v2

    .line 286
    nop

    .line 287
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
