.class public interface abstract Lcn1;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lbo3;


# virtual methods
.method public onCreate(Lco3;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onDestroy(Lco3;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onPause(Lco3;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onResume(Lco3;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onStart(Lco3;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onStop(Lco3;)V
    .locals 0

    .line 1
    return-void
.end method
