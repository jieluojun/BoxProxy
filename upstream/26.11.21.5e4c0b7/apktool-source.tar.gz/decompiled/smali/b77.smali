.class public final Lb77;
.super Lrf7;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final synthetic F:B

.field public G:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lsb6;Lkb1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lb77;->F:B

    .line 2
    .line 3
    invoke-direct {p0, p1, p2}, Le02;-><init>(Lsb6;Lkb1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c(Lorg/xml/sax/Attributes;ILrb6;Ljava/lang/String;)Z
    .locals 3

    .line 1
    iget-byte v0, p0, Lb77;->F:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    sget-object v0, Lb97;->a:[I

    .line 8
    .line 9
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    aget v0, v0, v2

    .line 14
    .line 15
    if-ne v0, v1, :cond_0

    .line 16
    .line 17
    invoke-static {p4}, Lzi6;->u(Ljava/lang/String;)Landroid/graphics/Matrix;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iput-object p1, p0, Lb77;->G:Ljava/lang/Object;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-super {p0, p1, p2, p3, p4}, Lrf7;->c(Lorg/xml/sax/Attributes;ILrb6;Ljava/lang/String;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    :goto_0
    return v1

    .line 29
    :pswitch_0
    sget-object v0, La77;->a:[I

    .line 30
    .line 31
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    aget v0, v0, v2

    .line 36
    .line 37
    if-ne v0, v1, :cond_2

    .line 38
    .line 39
    invoke-interface {p1, p2}, Lorg/xml/sax/Attributes;->getURI(I)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    const-string p2, ""

    .line 44
    .line 45
    invoke-static {p1, p2}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result p2

    .line 49
    if-nez p2, :cond_1

    .line 50
    .line 51
    const-string p2, "http://www.w3.org/1999/xlink"

    .line 52
    .line 53
    invoke-static {p1, p2}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    if-eqz p1, :cond_3

    .line 58
    .line 59
    :cond_1
    iput-object p4, p0, Lb77;->G:Ljava/lang/Object;

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    invoke-super {p0, p1, p2, p3, p4}, Lrf7;->c(Lorg/xml/sax/Attributes;ILrb6;Ljava/lang/String;)Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    :cond_3
    :goto_1
    return v1

    .line 67
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
