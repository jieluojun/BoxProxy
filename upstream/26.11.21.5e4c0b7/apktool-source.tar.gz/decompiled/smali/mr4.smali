.class public final synthetic Lmr4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:Lwh3;

.field public final synthetic i:Lc75;

.field public final synthetic j:Ld52;

.field public final synthetic k:Z

.field public final synthetic l:Ltm3;

.field public final synthetic m:Ljava/util/ArrayList;

.field public final synthetic n:Lqk4;

.field public final synthetic o:Z

.field public final synthetic p:Z

.field public final synthetic q:Lwg2;

.field public final synthetic r:Lzd4;

.field public final synthetic s:Ltm3;

.field public final synthetic t:Lzb3;

.field public final synthetic u:Ltm3;

.field public final synthetic v:Lhh2;

.field public final synthetic w:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lwh3;Lc75;Ld52;ZLtm3;Ljava/util/ArrayList;Lqk4;ZZLwg2;Lzd4;Ltm3;Lzb3;Ltm3;Lhh2;Lzd4;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lmr4;->h:Lwh3;

    .line 5
    .line 6
    iput-object p2, p0, Lmr4;->i:Lc75;

    .line 7
    .line 8
    iput-object p3, p0, Lmr4;->j:Ld52;

    .line 9
    .line 10
    iput-boolean p4, p0, Lmr4;->k:Z

    .line 11
    .line 12
    iput-object p5, p0, Lmr4;->l:Ltm3;

    .line 13
    .line 14
    iput-object p6, p0, Lmr4;->m:Ljava/util/ArrayList;

    .line 15
    .line 16
    iput-object p7, p0, Lmr4;->n:Lqk4;

    .line 17
    .line 18
    iput-boolean p8, p0, Lmr4;->o:Z

    .line 19
    .line 20
    iput-boolean p9, p0, Lmr4;->p:Z

    .line 21
    .line 22
    iput-object p10, p0, Lmr4;->q:Lwg2;

    .line 23
    .line 24
    iput-object p11, p0, Lmr4;->r:Lzd4;

    .line 25
    .line 26
    iput-object p12, p0, Lmr4;->s:Ltm3;

    .line 27
    .line 28
    iput-object p13, p0, Lmr4;->t:Lzb3;

    .line 29
    .line 30
    iput-object p14, p0, Lmr4;->u:Ltm3;

    .line 31
    .line 32
    iput-object p15, p0, Lmr4;->v:Lhh2;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lmr4;->w:Lzd4;

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v4, p1

    .line 4
    .line 5
    check-cast v4, Ls35;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Lki2;

    .line 10
    .line 11
    move-object/from16 v2, p3

    .line 12
    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 23
    .line 24
    if-nez v3, :cond_1

    .line 25
    .line 26
    invoke-virtual {v1, v4}, Lki2;->g(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_0

    .line 31
    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const/4 v3, 0x2

    .line 35
    :goto_0
    or-int/2addr v2, v3

    .line 36
    :cond_1
    and-int/lit8 v3, v2, 0x13

    .line 37
    .line 38
    const/16 v5, 0x12

    .line 39
    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x1

    .line 42
    if-eq v3, v5, :cond_2

    .line 43
    .line 44
    move v3, v7

    .line 45
    goto :goto_1

    .line 46
    :cond_2
    move v3, v6

    .line 47
    :goto_1
    and-int/2addr v2, v7

    .line 48
    invoke-virtual {v1, v2, v3}, Lki2;->Y(IZ)Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_6

    .line 53
    .line 54
    sget-object v2, Lit6;->c:Lk92;

    .line 55
    .line 56
    iget-object v3, v0, Lmr4;->h:Lwh3;

    .line 57
    .line 58
    invoke-static {v2, v3, v7}, Lb64;->b(Lha4;Lwh3;Z)Lha4;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    sget-object v3, Ly6;->j:La40;

    .line 63
    .line 64
    invoke-static {v3, v6}, Lxc0;->c(La40;Z)Ld14;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    iget-wide v5, v1, Lki2;->U:J

    .line 69
    .line 70
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 71
    .line 72
    .line 73
    move-result v5

    .line 74
    invoke-virtual {v1}, Lki2;->m()Lr95;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    invoke-static {v1, v2}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    sget-object v8, Lp41;->d:Ly6;

    .line 83
    .line 84
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v1}, Lki2;->k0()V

    .line 88
    .line 89
    .line 90
    iget-boolean v8, v1, Lki2;->T:Z

    .line 91
    .line 92
    if-eqz v8, :cond_3

    .line 93
    .line 94
    sget-object v8, Lwi3;->Z:Lj43;

    .line 95
    .line 96
    invoke-virtual {v1, v8}, Lki2;->l(Lwg2;)V

    .line 97
    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_3
    invoke-virtual {v1}, Lki2;->t0()V

    .line 101
    .line 102
    .line 103
    :goto_2
    sget-object v8, Ly6;->T:Lu31;

    .line 104
    .line 105
    invoke-static {v8, v1, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    sget-object v3, Ly6;->S:Lu31;

    .line 109
    .line 110
    invoke-static {v3, v1, v6}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    sget-object v5, Ly6;->U:Lu31;

    .line 118
    .line 119
    invoke-static {v5, v1, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-static {v1}, Lml6;->p(Lki2;)V

    .line 123
    .line 124
    .line 125
    sget-object v3, Ly6;->R:Lu31;

    .line 126
    .line 127
    invoke-static {v3, v1, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    sget-object v2, Lpr4;->a:Lk32;

    .line 131
    .line 132
    iget-object v3, v0, Lmr4;->i:Lc75;

    .line 133
    .line 134
    invoke-virtual {v3}, Lc75;->h()I

    .line 135
    .line 136
    .line 137
    move-result v3

    .line 138
    invoke-static {v3, v2}, Lxx0;->X0(ILjava/util/List;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    check-cast v2, Lqr4;

    .line 143
    .line 144
    if-nez v2, :cond_4

    .line 145
    .line 146
    sget-object v2, Lqr4;->i:Lqr4;

    .line 147
    .line 148
    :cond_4
    move-object/from16 v16, v2

    .line 149
    .line 150
    invoke-virtual {v1}, Lki2;->T()Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    sget-object v3, Lz41;->a:Lql0;

    .line 155
    .line 156
    if-ne v2, v3, :cond_5

    .line 157
    .line 158
    new-instance v2, Lsk4;

    .line 159
    .line 160
    const/16 v3, 0x18

    .line 161
    .line 162
    invoke-direct {v2, v3}, Lsk4;-><init>(B)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v1, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    :cond_5
    move-object/from16 v17, v2

    .line 169
    .line 170
    check-cast v17, Lhh2;

    .line 171
    .line 172
    new-instance v2, Lkr4;

    .line 173
    .line 174
    move-object v12, v1

    .line 175
    iget-object v1, v0, Lmr4;->j:Ld52;

    .line 176
    .line 177
    move-object v3, v2

    .line 178
    iget-boolean v2, v0, Lmr4;->k:Z

    .line 179
    .line 180
    move-object v5, v3

    .line 181
    iget-object v3, v0, Lmr4;->l:Ltm3;

    .line 182
    .line 183
    move-object v6, v5

    .line 184
    iget-object v5, v0, Lmr4;->m:Ljava/util/ArrayList;

    .line 185
    .line 186
    move-object v8, v6

    .line 187
    iget-object v6, v0, Lmr4;->n:Lqk4;

    .line 188
    .line 189
    iget-boolean v7, v0, Lmr4;->o:Z

    .line 190
    .line 191
    move-object v10, v8

    .line 192
    iget-boolean v8, v0, Lmr4;->p:Z

    .line 193
    .line 194
    iget-object v9, v0, Lmr4;->q:Lwg2;

    .line 195
    .line 196
    move-object v13, v10

    .line 197
    iget-object v10, v0, Lmr4;->r:Lzd4;

    .line 198
    .line 199
    iget-object v11, v0, Lmr4;->s:Ltm3;

    .line 200
    .line 201
    move-object v15, v12

    .line 202
    iget-object v12, v0, Lmr4;->t:Lzb3;

    .line 203
    .line 204
    move-object/from16 v18, v13

    .line 205
    .line 206
    iget-object v13, v0, Lmr4;->u:Ltm3;

    .line 207
    .line 208
    iget-object v14, v0, Lmr4;->v:Lhh2;

    .line 209
    .line 210
    iget-object v0, v0, Lmr4;->w:Lzd4;

    .line 211
    .line 212
    move-object/from16 v20, v15

    .line 213
    .line 214
    move-object v15, v0

    .line 215
    move-object/from16 v0, v18

    .line 216
    .line 217
    invoke-direct/range {v0 .. v15}, Lkr4;-><init>(Ld52;ZLtm3;Ls35;Ljava/util/ArrayList;Lqk4;ZZLwg2;Lzd4;Ltm3;Lzb3;Ltm3;Lhh2;Lzd4;)V

    .line 218
    .line 219
    .line 220
    move-object v13, v0

    .line 221
    const v0, -0x319d0502    # -9.5202496E8f

    .line 222
    .line 223
    .line 224
    move-object/from16 v12, v20

    .line 225
    .line 226
    invoke-static {v0, v13, v12}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 227
    .line 228
    .line 229
    move-result-object v11

    .line 230
    const v13, 0x186180

    .line 231
    .line 232
    .line 233
    const/16 v14, 0x2a

    .line 234
    .line 235
    const/4 v6, 0x0

    .line 236
    const/4 v8, 0x0

    .line 237
    const-string v9, "network-test-tab-content"

    .line 238
    .line 239
    const/4 v10, 0x0

    .line 240
    move-object/from16 v5, v16

    .line 241
    .line 242
    move-object/from16 v7, v17

    .line 243
    .line 244
    invoke-static/range {v5 .. v14}, Lf48;->b(Ljava/lang/Object;Lha4;Lhh2;La40;Ljava/lang/String;Lhh2;Lq21;Lki2;II)V

    .line 245
    .line 246
    .line 247
    const/4 v14, 0x1

    .line 248
    invoke-virtual {v12, v14}, Lki2;->r(Z)V

    .line 249
    .line 250
    .line 251
    goto :goto_3

    .line 252
    :cond_6
    move-object v12, v1

    .line 253
    invoke-virtual {v12}, Lki2;->b0()V

    .line 254
    .line 255
    .line 256
    :goto_3
    sget-object v0, Los7;->a:Los7;

    .line 257
    .line 258
    return-object v0
.end method
