.class public final synthetic Lgt2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:Ld52;

.field public final synthetic i:Z

.field public final synthetic j:Lha4;

.field public final synthetic k:F

.field public final synthetic l:F

.field public final synthetic m:Ls35;

.field public final synthetic n:F

.field public final synthetic o:Lgi3;

.field public final synthetic p:Lws1;

.field public final synthetic q:Ltm3;

.field public final synthetic r:Lhh2;

.field public final synthetic s:Lq21;


# direct methods
.method public synthetic constructor <init>(Ld52;ZLha4;FFLs35;FLgi3;Lws1;Ltm3;Lhh2;Lq21;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgt2;->h:Ld52;

    .line 5
    .line 6
    iput-boolean p2, p0, Lgt2;->i:Z

    .line 7
    .line 8
    iput-object p3, p0, Lgt2;->j:Lha4;

    .line 9
    .line 10
    iput p4, p0, Lgt2;->k:F

    .line 11
    .line 12
    iput p5, p0, Lgt2;->l:F

    .line 13
    .line 14
    iput-object p6, p0, Lgt2;->m:Ls35;

    .line 15
    .line 16
    iput p7, p0, Lgt2;->n:F

    .line 17
    .line 18
    iput-object p8, p0, Lgt2;->o:Lgi3;

    .line 19
    .line 20
    iput-object p9, p0, Lgt2;->p:Lws1;

    .line 21
    .line 22
    iput-object p10, p0, Lgt2;->q:Ltm3;

    .line 23
    .line 24
    iput-object p11, p0, Lgt2;->r:Lhh2;

    .line 25
    .line 26
    iput-object p12, p0, Lgt2;->s:Lq21;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    move-object v3, p1

    .line 2
    check-cast v3, Lki2;

    .line 3
    .line 4
    move-object/from16 v0, p2

    .line 5
    .line 6
    check-cast v0, Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    and-int/lit8 v1, v0, 0x3

    .line 13
    .line 14
    const/4 v6, 0x1

    .line 15
    const/4 v7, 0x2

    .line 16
    if-eq v1, v7, :cond_0

    .line 17
    .line 18
    move v1, v6

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    and-int/2addr v0, v6

    .line 22
    invoke-virtual {v3, v0, v1}, Lki2;->Y(IZ)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_7

    .line 27
    .line 28
    const/high16 v0, 0x3f800000    # 1.0f

    .line 29
    .line 30
    sget-object v8, Lea4;->h:Lea4;

    .line 31
    .line 32
    invoke-static {v8, v0}, Lit6;->c(Lha4;F)Lha4;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-static {v0}, Lha1;->K(Lha4;)Lha4;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    const/4 v4, 0x0

    .line 41
    const/4 v5, 0x2

    .line 42
    iget-object v1, p0, Lgt2;->h:Ld52;

    .line 43
    .line 44
    const/4 v2, 0x0

    .line 45
    invoke-static/range {v0 .. v5}, Ld43;->E(Lha4;Ld52;ZLki2;II)Lha4;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    iget-boolean v2, p0, Lgt2;->i:Z

    .line 50
    .line 51
    if-eqz v2, :cond_1

    .line 52
    .line 53
    iget-object v1, p0, Lgt2;->j:Lha4;

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_1
    iget-object v1, v1, Ld52;->h:Lc52;

    .line 57
    .line 58
    const/4 v4, 0x0

    .line 59
    invoke-static {v8, v1, v4}, Lf48;->I(Lha4;Llj4;Loj4;)Lha4;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    :goto_1
    invoke-interface {v0, v1}, Lha4;->b0(Lha4;)Lha4;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    sget-object v1, Lf48;->T:Lxg7;

    .line 68
    .line 69
    invoke-static {v0, v1}, Lf48;->R(Lha4;Lhh2;)Lha4;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    const/high16 v1, 0x41400000    # 12.0f

    .line 74
    .line 75
    if-eqz v2, :cond_2

    .line 76
    .line 77
    iget v4, p0, Lgt2;->k:F

    .line 78
    .line 79
    goto :goto_2

    .line 80
    :cond_2
    move v4, v1

    .line 81
    :goto_2
    const/4 v5, 0x0

    .line 82
    invoke-static {v0, v4, v5, v7}, Ljb3;->z(Lha4;FFI)Lha4;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    iget-object v4, p0, Lgt2;->m:Ls35;

    .line 87
    .line 88
    if-eqz v2, :cond_3

    .line 89
    .line 90
    iget v2, p0, Lgt2;->l:F

    .line 91
    .line 92
    add-float/2addr v2, v1

    .line 93
    add-float/2addr v2, v5

    .line 94
    iget v7, p0, Lgt2;->n:F

    .line 95
    .line 96
    invoke-static {v4, v7, v5}, Lx82;->d(Ls35;FF)F

    .line 97
    .line 98
    .line 99
    move-result v4

    .line 100
    const/4 v7, 0x5

    .line 101
    invoke-static {v5, v2, v5, v4, v7}, Ljb3;->j(FFFFI)Lu35;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    goto :goto_3

    .line 106
    :cond_3
    iget-object v2, p0, Lgt2;->o:Lgi3;

    .line 107
    .line 108
    invoke-static {v4, v2}, Ljb3;->o(Ls35;Lgi3;)F

    .line 109
    .line 110
    .line 111
    move-result v7

    .line 112
    invoke-static {v4, v1, v5}, Lx82;->A(Ls35;FF)F

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    invoke-static {v4, v2}, Ljb3;->n(Ls35;Lgi3;)F

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    invoke-interface {v4}, Ls35;->c()F

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    new-instance v8, Lu35;

    .line 125
    .line 126
    invoke-direct {v8, v7, v5, v2, v4}, Lu35;-><init>(FFFF)V

    .line 127
    .line 128
    .line 129
    move-object v2, v8

    .line 130
    :goto_3
    iget-object v4, p0, Lgt2;->p:Lws1;

    .line 131
    .line 132
    if-eqz v4, :cond_4

    .line 133
    .line 134
    iget v1, v4, Lws1;->h:F

    .line 135
    .line 136
    :cond_4
    new-instance v4, Luw;

    .line 137
    .line 138
    new-instance v5, Lt32;

    .line 139
    .line 140
    const/4 v7, 0x3

    .line 141
    invoke-direct {v5, v7}, Lt32;-><init>(B)V

    .line 142
    .line 143
    .line 144
    invoke-direct {v4, v1, v6, v5}, Luw;-><init>(FZLt32;)V

    .line 145
    .line 146
    .line 147
    iget-object v1, p0, Lgt2;->r:Lhh2;

    .line 148
    .line 149
    invoke-virtual {v3, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 150
    .line 151
    .line 152
    move-result v5

    .line 153
    iget-object v7, p0, Lgt2;->s:Lq21;

    .line 154
    .line 155
    invoke-virtual {v3, v7}, Lki2;->g(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    move-result v8

    .line 159
    or-int/2addr v5, v8

    .line 160
    invoke-virtual {v3}, Lki2;->T()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v8

    .line 164
    if-nez v5, :cond_5

    .line 165
    .line 166
    sget-object v5, Lz41;->a:Lql0;

    .line 167
    .line 168
    if-ne v8, v5, :cond_6

    .line 169
    .line 170
    :cond_5
    new-instance v8, Let2;

    .line 171
    .line 172
    invoke-direct {v8, v1, v7, v6}, Let2;-><init>(Lhh2;Lq21;B)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v3, v8}, Lki2;->q0(Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    :cond_6
    move-object v9, v8

    .line 179
    check-cast v9, Lhh2;

    .line 180
    .line 181
    const/4 v12, 0x0

    .line 182
    const/16 v13, 0x2e8

    .line 183
    .line 184
    iget-object v1, p0, Lgt2;->q:Ltm3;

    .line 185
    .line 186
    move-object v10, v3

    .line 187
    move-object v3, v4

    .line 188
    const/4 v4, 0x0

    .line 189
    const/4 v5, 0x0

    .line 190
    const/4 v6, 0x0

    .line 191
    const/4 v7, 0x0

    .line 192
    const/4 v8, 0x0

    .line 193
    const/high16 v11, 0x6000000

    .line 194
    .line 195
    invoke-static/range {v0 .. v13}, Ls33;->e(Lha4;Ltm3;Ls35;Lvw;Ly30;Lum1;ZLa15;Lbn1;Lhh2;Lki2;III)V

    .line 196
    .line 197
    .line 198
    goto :goto_4

    .line 199
    :cond_7
    invoke-virtual {v3}, Lki2;->b0()V

    .line 200
    .line 201
    .line 202
    :goto_4
    sget-object p0, Los7;->a:Los7;

    .line 203
    .line 204
    return-object p0
.end method
