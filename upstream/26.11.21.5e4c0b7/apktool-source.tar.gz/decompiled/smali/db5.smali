.class public final Ldb5;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lii1;

.field public final b:Landroid/content/Context;

.field public final c:Lzh6;

.field public final d:Lpt3;

.field public final e:Loe4;

.field public f:Landroid/view/textclassifier/TextClassifier;

.field public final g:Lf75;

.field public final h:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lii1;Landroid/content/Context;Lzh6;Lpt3;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldb5;->a:Lii1;

    .line 5
    .line 6
    iput-object p2, p0, Ldb5;->b:Landroid/content/Context;

    .line 7
    .line 8
    iput-object p3, p0, Ldb5;->c:Lzh6;

    .line 9
    .line 10
    iput-object p4, p0, Ldb5;->d:Lpt3;

    .line 11
    .line 12
    new-instance p1, Loe4;

    .line 13
    .line 14
    invoke-direct {p1}, Loe4;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, Ldb5;->e:Loe4;

    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    invoke-static {p1}, Lzi6;->s(Ljava/lang/Object;)Lf75;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, Ldb5;->g:Lf75;

    .line 25
    .line 26
    new-instance p1, Ljava/lang/Object;

    .line 27
    .line 28
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object p1, p0, Ldb5;->h:Ljava/lang/Object;

    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassifier;Lgd1;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p5

    .line 4
    .line 5
    instance-of v2, v1, Lab5;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    move-object v2, v1

    .line 10
    check-cast v2, Lab5;

    .line 11
    .line 12
    iget v3, v2, Lab5;->s:I

    .line 13
    .line 14
    const/high16 v4, -0x80000000

    .line 15
    .line 16
    and-int v5, v3, v4

    .line 17
    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    sub-int/2addr v3, v4

    .line 21
    iput v3, v2, Lab5;->s:I

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v2, Lab5;

    .line 25
    .line 26
    invoke-direct {v2, v0, v1}, Lab5;-><init>(Ldb5;Lgd1;)V

    .line 27
    .line 28
    .line 29
    :goto_0
    iget-object v1, v2, Lab5;->q:Ljava/lang/Object;

    .line 30
    .line 31
    iget v3, v2, Lab5;->s:I

    .line 32
    .line 33
    iget-object v4, v0, Ldb5;->g:Lf75;

    .line 34
    .line 35
    sget-object v5, Los7;->a:Los7;

    .line 36
    .line 37
    iget-object v6, v0, Ldb5;->e:Loe4;

    .line 38
    .line 39
    const/4 v7, 0x2

    .line 40
    const/4 v8, 0x1

    .line 41
    const/4 v9, 0x0

    .line 42
    sget-object v10, Lsi1;->h:Lsi1;

    .line 43
    .line 44
    if-eqz v3, :cond_3

    .line 45
    .line 46
    if-eq v3, v8, :cond_2

    .line 47
    .line 48
    if-ne v3, v7, :cond_1

    .line 49
    .line 50
    iget-object v6, v2, Lab5;->o:Loe4;

    .line 51
    .line 52
    iget-object v0, v2, Lab5;->n:Ls97;

    .line 53
    .line 54
    iget-object v2, v2, Lab5;->m:Loe4;

    .line 55
    .line 56
    check-cast v2, Landroid/view/textclassifier/TextClassification$Request;

    .line 57
    .line 58
    invoke-static {v1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    goto/16 :goto_6

    .line 62
    .line 63
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 64
    .line 65
    invoke-static {v0}, Lt32;->d(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    return-object v9

    .line 69
    :cond_2
    iget-wide v11, v2, Lab5;->p:J

    .line 70
    .line 71
    iget-object v3, v2, Lab5;->m:Loe4;

    .line 72
    .line 73
    iget-object v13, v2, Lab5;->l:Landroid/view/textclassifier/TextClassifier;

    .line 74
    .line 75
    iget-object v14, v2, Lab5;->k:Ljava/lang/CharSequence;

    .line 76
    .line 77
    invoke-static {v1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_3
    invoke-static {v1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    move-object/from16 v1, p1

    .line 85
    .line 86
    iput-object v1, v2, Lab5;->k:Ljava/lang/CharSequence;

    .line 87
    .line 88
    move-object/from16 v3, p4

    .line 89
    .line 90
    iput-object v3, v2, Lab5;->l:Landroid/view/textclassifier/TextClassifier;

    .line 91
    .line 92
    iput-object v6, v2, Lab5;->m:Loe4;

    .line 93
    .line 94
    move-wide/from16 v11, p2

    .line 95
    .line 96
    iput-wide v11, v2, Lab5;->p:J

    .line 97
    .line 98
    iput v8, v2, Lab5;->s:I

    .line 99
    .line 100
    invoke-virtual {v6, v2}, Loe4;->e(Lfd1;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v13

    .line 104
    if-ne v13, v10, :cond_4

    .line 105
    .line 106
    move-object v15, v10

    .line 107
    goto/16 :goto_5

    .line 108
    .line 109
    :cond_4
    move-object v14, v1

    .line 110
    move-object v13, v3

    .line 111
    move-object v3, v6

    .line 112
    :goto_1
    :try_start_0
    invoke-virtual {v4}, Lf75;->getValue()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    check-cast v1, Ls97;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 117
    .line 118
    if-eqz v1, :cond_7

    .line 119
    .line 120
    move-object v15, v10

    .line 121
    :try_start_1
    iget-wide v9, v1, Ls97;->b:J

    .line 122
    .line 123
    invoke-static {v11, v12, v9, v10}, Lwf7;->a(JJ)Z

    .line 124
    .line 125
    .line 126
    move-result v9

    .line 127
    if-eqz v9, :cond_5

    .line 128
    .line 129
    iget-object v1, v1, Ls97;->a:Ljava/lang/CharSequence;

    .line 130
    .line 131
    invoke-static {v14, v1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 135
    if-eqz v1, :cond_5

    .line 136
    .line 137
    move v1, v8

    .line 138
    goto :goto_3

    .line 139
    :goto_2
    const/4 v1, 0x0

    .line 140
    goto :goto_7

    .line 141
    :cond_5
    const/4 v1, 0x0

    .line 142
    :goto_3
    if-ne v1, v8, :cond_6

    .line 143
    .line 144
    const/4 v1, 0x0

    .line 145
    invoke-virtual {v3, v1}, Loe4;->g(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    return-object v5

    .line 149
    :cond_6
    const/4 v1, 0x0

    .line 150
    goto :goto_4

    .line 151
    :catchall_0
    move-exception v0

    .line 152
    goto :goto_2

    .line 153
    :cond_7
    move-object v1, v9

    .line 154
    move-object v15, v10

    .line 155
    :goto_4
    invoke-virtual {v3, v1}, Loe4;->g(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    new-instance v3, Landroid/view/textclassifier/TextClassification$Request$Builder;

    .line 159
    .line 160
    invoke-static {v11, v12}, Lwf7;->d(J)I

    .line 161
    .line 162
    .line 163
    move-result v8

    .line 164
    invoke-static {v11, v12}, Lwf7;->c(J)I

    .line 165
    .line 166
    .line 167
    move-result v9

    .line 168
    invoke-direct {v3, v14, v8, v9}, Landroid/view/textclassifier/TextClassification$Request$Builder;-><init>(Ljava/lang/CharSequence;II)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v0}, Ldb5;->c()Landroid/os/LocaleList;

    .line 172
    .line 173
    .line 174
    move-result-object v8

    .line 175
    invoke-virtual {v3, v8}, Landroid/view/textclassifier/TextClassification$Request$Builder;->setDefaultLocales(Landroid/os/LocaleList;)Landroid/view/textclassifier/TextClassification$Request$Builder;

    .line 176
    .line 177
    .line 178
    move-result-object v3

    .line 179
    invoke-virtual {v3}, Landroid/view/textclassifier/TextClassification$Request$Builder;->build()Landroid/view/textclassifier/TextClassification$Request;

    .line 180
    .line 181
    .line 182
    move-result-object v3

    .line 183
    invoke-interface {v13, v3}, Landroid/view/textclassifier/TextClassifier;->classifyText(Landroid/view/textclassifier/TextClassification$Request;)Landroid/view/textclassifier/TextClassification;

    .line 184
    .line 185
    .line 186
    move-result-object v3

    .line 187
    invoke-virtual {v0, v14, v11, v12, v3}, Ldb5;->b(Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassification;)Ls97;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    iput-object v1, v2, Lab5;->k:Ljava/lang/CharSequence;

    .line 192
    .line 193
    iput-object v1, v2, Lab5;->l:Landroid/view/textclassifier/TextClassifier;

    .line 194
    .line 195
    iput-object v1, v2, Lab5;->m:Loe4;

    .line 196
    .line 197
    iput-object v0, v2, Lab5;->n:Ls97;

    .line 198
    .line 199
    iput-object v6, v2, Lab5;->o:Loe4;

    .line 200
    .line 201
    iput-wide v11, v2, Lab5;->p:J

    .line 202
    .line 203
    iput v7, v2, Lab5;->s:I

    .line 204
    .line 205
    invoke-virtual {v6, v2}, Loe4;->e(Lfd1;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v1

    .line 209
    if-ne v1, v15, :cond_8

    .line 210
    .line 211
    :goto_5
    return-object v15

    .line 212
    :cond_8
    :goto_6
    :try_start_2
    invoke-virtual {v4, v0}, Lf75;->setValue(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 213
    .line 214
    .line 215
    const/4 v1, 0x0

    .line 216
    invoke-virtual {v6, v1}, Loe4;->g(Ljava/lang/Object;)V

    .line 217
    .line 218
    .line 219
    return-object v5

    .line 220
    :catchall_1
    move-exception v0

    .line 221
    const/4 v1, 0x0

    .line 222
    invoke-virtual {v6, v1}, Loe4;->g(Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    throw v0

    .line 226
    :catchall_2
    move-exception v0

    .line 227
    move-object v1, v9

    .line 228
    :goto_7
    invoke-virtual {v3, v1}, Loe4;->g(Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    throw v0
.end method

.method public final b(Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassification;)Ls97;
    .locals 7

    .line 1
    invoke-virtual {p4}, Landroid/view/textclassifier/TextClassification;->getActions()Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    new-instance v6, Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-direct {v6, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 12
    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    :goto_0
    if-ge v1, v0, :cond_2

    .line 16
    .line 17
    invoke-virtual {p4}, Landroid/view/textclassifier/TextClassification;->getActions()Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    move-object v3, v2

    .line 26
    check-cast v3, Landroid/app/RemoteAction;

    .line 27
    .line 28
    const/4 v4, 0x0

    .line 29
    if-eqz v1, :cond_0

    .line 30
    .line 31
    invoke-virtual {v3}, Landroid/app/RemoteAction;->shouldShowIcon()Z

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    if-nez v3, :cond_0

    .line 36
    .line 37
    move-object v2, v4

    .line 38
    :cond_0
    check-cast v2, Landroid/app/RemoteAction;

    .line 39
    .line 40
    if-eqz v2, :cond_1

    .line 41
    .line 42
    invoke-virtual {v2}, Landroid/app/RemoteAction;->getIcon()Landroid/graphics/drawable/Icon;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    if-eqz v2, :cond_1

    .line 47
    .line 48
    iget-object v3, p0, Ldb5;->b:Landroid/content/Context;

    .line 49
    .line 50
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Icon;->loadDrawable(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    :cond_1
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    add-int/lit8 v1, v1, 0x1

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_2
    new-instance v1, Ls97;

    .line 61
    .line 62
    move-object v2, p1

    .line 63
    move-wide v3, p2

    .line 64
    move-object v5, p4

    .line 65
    invoke-direct/range {v1 .. v6}, Ls97;-><init>(Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassification;Ljava/util/ArrayList;)V

    .line 66
    .line 67
    .line 68
    return-object v1
.end method

.method public final c()Landroid/os/LocaleList;
    .locals 2

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    const/16 v1, 0xa

    .line 4
    .line 5
    iget-object p0, p0, Ldb5;->d:Lpt3;

    .line 6
    .line 7
    invoke-static {p0, v1}, Lyx0;->F0(Ljava/lang/Iterable;I)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 12
    .line 13
    .line 14
    iget-object p0, p0, Lpt3;->h:Ljava/util/List;

    .line 15
    .line 16
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Lot3;

    .line 31
    .line 32
    iget-object v1, v1, Lot3;->a:Ljava/util/Locale;

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const/4 p0, 0x0

    .line 39
    new-array p0, p0, [Ljava/util/Locale;

    .line 40
    .line 41
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    check-cast p0, [Ljava/util/Locale;

    .line 46
    .line 47
    array-length v0, p0

    .line 48
    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    check-cast p0, [Ljava/util/Locale;

    .line 53
    .line 54
    new-instance v0, Landroid/os/LocaleList;

    .line 55
    .line 56
    invoke-direct {v0, p0}, Landroid/os/LocaleList;-><init>([Ljava/util/Locale;)V

    .line 57
    .line 58
    .line 59
    return-object v0
.end method

.method public final d(Ljava/lang/CharSequence;JLgd1;)Ljava/lang/Object;
    .locals 11

    .line 1
    instance-of v0, p4, Lbb5;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p4

    .line 6
    check-cast v0, Lbb5;

    .line 7
    .line 8
    iget v1, v0, Lbb5;->m:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lbb5;->m:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lbb5;

    .line 21
    .line 22
    invoke-direct {v0, p0, p4}, Lbb5;-><init>(Ldb5;Lgd1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p4, v0, Lbb5;->k:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lbb5;->m:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    sget-object v3, Los7;->a:Los7;

    .line 31
    .line 32
    const/4 v4, 0x1

    .line 33
    if-eqz v1, :cond_2

    .line 34
    .line 35
    if-ne v1, v4, :cond_1

    .line 36
    .line 37
    invoke-static {p4}, Ls33;->p0(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    return-object v3

    .line 41
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 42
    .line 43
    invoke-static {p0}, Lt32;->d(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    return-object v2

    .line 47
    :cond_2
    invoke-static {p4}, Ls33;->p0(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 51
    .line 52
    .line 53
    move-result p4

    .line 54
    if-eqz p4, :cond_3

    .line 55
    .line 56
    invoke-static {p2, p3}, Lwf7;->b(J)Z

    .line 57
    .line 58
    .line 59
    move-result p4

    .line 60
    if-nez p4, :cond_3

    .line 61
    .line 62
    new-instance v5, Lvs0;

    .line 63
    .line 64
    const/4 v8, 0x0

    .line 65
    move-object v9, p0

    .line 66
    move-object v10, p1

    .line 67
    move-wide v6, p2

    .line 68
    invoke-direct/range {v5 .. v10}, Lvs0;-><init>(JLfd1;Ldb5;Ljava/lang/CharSequence;)V

    .line 69
    .line 70
    .line 71
    iput v4, v0, Lbb5;->m:I

    .line 72
    .line 73
    new-instance p0, Ljx0;

    .line 74
    .line 75
    const/16 p1, 0x9

    .line 76
    .line 77
    invoke-direct {p0, v9, v5, v2, p1}, Ljx0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lfd1;B)V

    .line 78
    .line 79
    .line 80
    iget-object p1, v9, Ldb5;->a:Lii1;

    .line 81
    .line 82
    invoke-static {p1, p0, v0}, Ljj;->u0(Lii1;Llh2;Lfd1;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    sget-object p1, Lsi1;->h:Lsi1;

    .line 87
    .line 88
    if-ne p0, p1, :cond_3

    .line 89
    .line 90
    return-object p1

    .line 91
    :cond_3
    return-object v3
.end method
