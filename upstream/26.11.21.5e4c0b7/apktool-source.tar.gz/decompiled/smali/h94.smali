.class public final synthetic Lh94;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:Lha4;

.field public final synthetic i:F

.field public final synthetic j:Lq21;

.field public final synthetic k:S

.field public final synthetic l:B


# direct methods
.method public synthetic constructor <init>(Lha4;FLq21;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lh94;->h:Lha4;

    .line 5
    .line 6
    iput p2, p0, Lh94;->i:F

    .line 7
    .line 8
    iput-object p3, p0, Lh94;->j:Lq21;

    .line 9
    .line 10
    iput-short p4, p0, Lh94;->k:S

    .line 11
    .line 12
    iput-byte p5, p0, Lh94;->l:B

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    move-object v3, p1

    .line 2
    check-cast v3, Lki2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-short p1, p0, Lh94;->k:S

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Ld43;->P(I)I

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    iget-object v0, p0, Lh94;->h:Lha4;

    .line 18
    .line 19
    iget v1, p0, Lh94;->i:F

    .line 20
    .line 21
    iget-object v2, p0, Lh94;->j:Lq21;

    .line 22
    .line 23
    iget-byte v5, p0, Lh94;->l:B

    .line 24
    .line 25
    invoke-static/range {v0 .. v5}, Lr94;->i(Lha4;FLq21;Lki2;II)V

    .line 26
    .line 27
    .line 28
    sget-object p0, Los7;->a:Los7;

    .line 29
    .line 30
    return-object p0
.end method
