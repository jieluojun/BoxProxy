.class public final synthetic Lkp4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lnh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lkp4;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lkp4;->i:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Lkp4;->j:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final r(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lkp4;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/16 v4, 0x90

    .line 9
    .line 10
    const/16 v5, 0x10

    .line 11
    .line 12
    const/16 v6, 0x20

    .line 13
    .line 14
    const/4 v7, 0x1

    .line 15
    iget-object v8, v0, Lkp4;->j:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v0, v0, Lkp4;->i:Ljava/lang/Object;

    .line 18
    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    check-cast v0, Lq37;

    .line 23
    .line 24
    check-cast v8, Lzd4;

    .line 25
    .line 26
    move-object/from16 v1, p1

    .line 27
    .line 28
    check-cast v1, Lvk3;

    .line 29
    .line 30
    move-object/from16 v9, p2

    .line 31
    .line 32
    check-cast v9, Ljava/lang/Integer;

    .line 33
    .line 34
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 35
    .line 36
    .line 37
    move-result v9

    .line 38
    move-object/from16 v14, p3

    .line 39
    .line 40
    check-cast v14, Lki2;

    .line 41
    .line 42
    move-object/from16 v10, p4

    .line 43
    .line 44
    check-cast v10, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 47
    .line 48
    .line 49
    move-result v10

    .line 50
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    and-int/lit8 v1, v10, 0x30

    .line 54
    .line 55
    if-nez v1, :cond_1

    .line 56
    .line 57
    invoke-virtual {v14, v9}, Lki2;->e(I)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_0

    .line 62
    .line 63
    move v5, v6

    .line 64
    :cond_0
    or-int/2addr v10, v5

    .line 65
    :cond_1
    and-int/lit16 v1, v10, 0x91

    .line 66
    .line 67
    if-eq v1, v4, :cond_2

    .line 68
    .line 69
    move v3, v7

    .line 70
    :cond_2
    and-int/2addr v10, v7

    .line 71
    invoke-virtual {v14, v10, v3}, Lki2;->Y(IZ)Z

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    if-eqz v1, :cond_3

    .line 76
    .line 77
    invoke-virtual {v0}, Lq37;->d()Ljava/util/List;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    invoke-interface {v1, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    check-cast v1, Lo54;

    .line 86
    .line 87
    sget-object v3, Lea4;->h:Lea4;

    .line 88
    .line 89
    const/high16 v4, 0x3f800000    # 1.0f

    .line 90
    .line 91
    invoke-static {v3, v4}, Lit6;->e(Lha4;F)Lha4;

    .line 92
    .line 93
    .line 94
    move-result-object v10

    .line 95
    new-instance v3, Lof4;

    .line 96
    .line 97
    const/16 v4, 0x1b

    .line 98
    .line 99
    invoke-direct {v3, v0, v1, v8, v4}, Lof4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 100
    .line 101
    .line 102
    const v0, -0xa23c274

    .line 103
    .line 104
    .line 105
    invoke-static {v0, v3, v14}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-static {v0}, Lqf;->X(Ljava/lang/Object;)Ljava/util/List;

    .line 110
    .line 111
    .line 112
    move-result-object v13

    .line 113
    const/16 v15, 0xc06

    .line 114
    .line 115
    const/16 v16, 0x16

    .line 116
    .line 117
    const/4 v11, 0x0

    .line 118
    const/4 v12, 0x0

    .line 119
    invoke-static/range {v10 .. v16}, Lk04;->d(Lha4;Ljava/lang/String;Lq21;Ljava/util/List;Lki2;II)V

    .line 120
    .line 121
    .line 122
    goto :goto_0

    .line 123
    :cond_3
    invoke-virtual {v14}, Lki2;->b0()V

    .line 124
    .line 125
    .line 126
    :goto_0
    return-object v2

    .line 127
    :pswitch_0
    check-cast v0, Lq21;

    .line 128
    .line 129
    check-cast v8, Ljava/lang/String;

    .line 130
    .line 131
    move-object/from16 v1, p1

    .line 132
    .line 133
    check-cast v1, Luh;

    .line 134
    .line 135
    move-object/from16 v9, p2

    .line 136
    .line 137
    check-cast v9, Lj65;

    .line 138
    .line 139
    move-object/from16 v10, p3

    .line 140
    .line 141
    check-cast v10, Lki2;

    .line 142
    .line 143
    move-object/from16 v11, p4

    .line 144
    .line 145
    check-cast v11, Ljava/lang/Integer;

    .line 146
    .line 147
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 148
    .line 149
    .line 150
    move-result v11

    .line 151
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 152
    .line 153
    .line 154
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 155
    .line 156
    .line 157
    and-int/lit8 v1, v11, 0x30

    .line 158
    .line 159
    if-nez v1, :cond_5

    .line 160
    .line 161
    invoke-virtual {v10, v9}, Lki2;->g(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v1

    .line 165
    if-eqz v1, :cond_4

    .line 166
    .line 167
    move v5, v6

    .line 168
    :cond_4
    or-int/2addr v11, v5

    .line 169
    :cond_5
    and-int/lit16 v1, v11, 0x91

    .line 170
    .line 171
    if-eq v1, v4, :cond_6

    .line 172
    .line 173
    move v1, v7

    .line 174
    goto :goto_1

    .line 175
    :cond_6
    move v1, v3

    .line 176
    :goto_1
    and-int/2addr v11, v7

    .line 177
    invoke-virtual {v10, v11, v1}, Lki2;->Y(IZ)Z

    .line 178
    .line 179
    .line 180
    move-result v1

    .line 181
    if-eqz v1, :cond_7

    .line 182
    .line 183
    iget-object v1, v9, Lj65;->h:Ljava/lang/Object;

    .line 184
    .line 185
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 186
    .line 187
    .line 188
    move-result-object v3

    .line 189
    invoke-virtual {v0, v8, v1, v10, v3}, Lq21;->r(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    goto :goto_2

    .line 193
    :cond_7
    invoke-virtual {v10}, Lki2;->b0()V

    .line 194
    .line 195
    .line 196
    :goto_2
    return-object v2

    .line 197
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
