.class public final Ln07;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Ldg3;


# static fields
.field public static final a:Ln07;

.field public static final b:Lsf5;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ln07;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Ln07;->a:Ln07;

    .line 7
    .line 8
    new-instance v0, Lsf5;

    .line 9
    .line 10
    const-string v1, "kotlin.String"

    .line 11
    .line 12
    sget-object v2, Lrf5;->m:Lrf5;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, Lsf5;-><init>(Ljava/lang/String;Lrf5;)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Ln07;->b:Lsf5;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final b(Lsl1;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1}, Lsl1;->A()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final c()Lgl6;
    .locals 0

    .line 1
    sget-object p0, Ln07;->b:Lsf5;

    .line 2
    .line 3
    return-object p0
.end method

.method public final d(Lh07;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1, p2}, Lh07;->q(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
