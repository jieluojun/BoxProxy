.class public abstract Lm65;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lcx1;

.field public static final b:Lcx1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lwm4;

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lwm4;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lcx1;

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Lm65;->a:Lcx1;

    .line 15
    .line 16
    new-instance v0, Ll65;

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    invoke-direct {v0, v1}, Ll65;-><init>(B)V

    .line 20
    .line 21
    .line 22
    new-instance v1, Lcx1;

    .line 23
    .line 24
    invoke-direct {v1, v0, v2}, Lcx1;-><init>(Lwg2;B)V

    .line 25
    .line 26
    .line 27
    sput-object v1, Lm65;->b:Lcx1;

    .line 28
    .line 29
    return-void
.end method

.method public static final a(Ltm3;ZLki2;I)V
    .locals 8

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const v0, -0x4f4bd083

    .line 5
    .line 6
    .line 7
    invoke-virtual {p2, v0}, Lki2;->i0(I)Lki2;

    .line 8
    .line 9
    .line 10
    and-int/lit8 v0, p3, 0x6

    .line 11
    .line 12
    const/4 v1, 0x4

    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    invoke-virtual {p2, p0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    move v0, v1

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v0, 0x2

    .line 24
    :goto_0
    or-int/2addr v0, p3

    .line 25
    goto :goto_1

    .line 26
    :cond_1
    move v0, p3

    .line 27
    :goto_1
    and-int/lit8 v2, p3, 0x30

    .line 28
    .line 29
    if-nez v2, :cond_3

    .line 30
    .line 31
    invoke-virtual {p2, p1}, Lki2;->h(Z)Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-eqz v2, :cond_2

    .line 36
    .line 37
    const/16 v2, 0x20

    .line 38
    .line 39
    goto :goto_2

    .line 40
    :cond_2
    const/16 v2, 0x10

    .line 41
    .line 42
    :goto_2
    or-int/2addr v0, v2

    .line 43
    :cond_3
    and-int/lit8 v2, v0, 0x13

    .line 44
    .line 45
    const/16 v3, 0x12

    .line 46
    .line 47
    const/4 v4, 0x1

    .line 48
    const/4 v5, 0x0

    .line 49
    if-eq v2, v3, :cond_4

    .line 50
    .line 51
    move v2, v4

    .line 52
    goto :goto_3

    .line 53
    :cond_4
    move v2, v5

    .line 54
    :goto_3
    and-int/lit8 v3, v0, 0x1

    .line 55
    .line 56
    invoke-virtual {p2, v3, v2}, Lki2;->Y(IZ)Z

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    if-eqz v2, :cond_9

    .line 61
    .line 62
    sget-object v2, Lm65;->a:Lcx1;

    .line 63
    .line 64
    invoke-virtual {p2, v2}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    check-cast v2, Lk65;

    .line 69
    .line 70
    sget-object v3, Lm65;->b:Lcx1;

    .line 71
    .line 72
    invoke-virtual {p2, v3}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    check-cast v3, Lrk;

    .line 77
    .line 78
    if-eqz p1, :cond_8

    .line 79
    .line 80
    if-eqz v2, :cond_8

    .line 81
    .line 82
    if-eqz v3, :cond_8

    .line 83
    .line 84
    const v6, 0x3865c646

    .line 85
    .line 86
    .line 87
    invoke-virtual {p2, v6}, Lki2;->h0(I)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {p2, v2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v6

    .line 94
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 95
    .line 96
    .line 97
    move-result v7

    .line 98
    invoke-virtual {p2, v7}, Lki2;->e(I)Z

    .line 99
    .line 100
    .line 101
    move-result v7

    .line 102
    or-int/2addr v6, v7

    .line 103
    and-int/lit8 v0, v0, 0xe

    .line 104
    .line 105
    if-ne v0, v1, :cond_5

    .line 106
    .line 107
    move v0, v4

    .line 108
    goto :goto_4

    .line 109
    :cond_5
    move v0, v5

    .line 110
    :goto_4
    or-int/2addr v6, v0

    .line 111
    invoke-virtual {p2}, Lki2;->T()Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    if-nez v6, :cond_6

    .line 116
    .line 117
    sget-object v1, Lz41;->a:Lql0;

    .line 118
    .line 119
    if-ne v0, v1, :cond_7

    .line 120
    .line 121
    :cond_6
    new-instance v0, Lpr3;

    .line 122
    .line 123
    const/16 v1, 0x9

    .line 124
    .line 125
    invoke-direct {v0, v2, v3, p0, v1}, Lpr3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {p2, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    :cond_7
    check-cast v0, Lhh2;

    .line 132
    .line 133
    invoke-static {v2, v3, p0, v0, p2}, Lnt7;->e(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhh2;Lki2;)V

    .line 134
    .line 135
    .line 136
    invoke-virtual {p2, v5}, Lki2;->r(Z)V

    .line 137
    .line 138
    .line 139
    goto :goto_5

    .line 140
    :cond_8
    const v0, 0x38681b25

    .line 141
    .line 142
    .line 143
    invoke-virtual {p2, v0}, Lki2;->h0(I)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p2, v5}, Lki2;->r(Z)V

    .line 147
    .line 148
    .line 149
    goto :goto_5

    .line 150
    :cond_9
    invoke-virtual {p2}, Lki2;->b0()V

    .line 151
    .line 152
    .line 153
    :goto_5
    invoke-virtual {p2}, Lki2;->w()Lhu5;

    .line 154
    .line 155
    .line 156
    move-result-object p2

    .line 157
    if-eqz p2, :cond_a

    .line 158
    .line 159
    new-instance v0, Lj84;

    .line 160
    .line 161
    invoke-direct {v0, p0, p1, p3, v4}, Lj84;-><init>(Ltm3;ZIB)V

    .line 162
    .line 163
    .line 164
    iput-object v0, p2, Lhu5;->d:Llh2;

    .line 165
    .line 166
    :cond_a
    return-void
.end method
