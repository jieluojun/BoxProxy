.class public final Lrh5;
.super Lf57;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public l:Ltp5;

.field public m:B

.field public final synthetic n:Lhh2;

.field public final synthetic o:Lhh2;

.field public final synthetic p:Ljava/lang/Object;

.field public final synthetic q:Z

.field public final synthetic r:Lsh5;

.field public final synthetic s:Lhh2;


# direct methods
.method public constructor <init>(Lhh2;Lhh2;Ljava/lang/Object;ZLsh5;Lhh2;Lfd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lrh5;->n:Lhh2;

    .line 2
    .line 3
    iput-object p2, p0, Lrh5;->o:Lhh2;

    .line 4
    .line 5
    iput-object p3, p0, Lrh5;->p:Ljava/lang/Object;

    .line 6
    .line 7
    iput-boolean p4, p0, Lrh5;->q:Z

    .line 8
    .line 9
    iput-object p5, p0, Lrh5;->r:Lsh5;

    .line 10
    .line 11
    iput-object p6, p0, Lrh5;->s:Lhh2;

    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    invoke-direct {p0, p1, p7}, Lf57;-><init>(ILfd1;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    move-object v7, p1

    .line 2
    check-cast v7, Lfd1;

    .line 3
    .line 4
    new-instance v0, Lrh5;

    .line 5
    .line 6
    iget-object v5, p0, Lrh5;->r:Lsh5;

    .line 7
    .line 8
    iget-object v6, p0, Lrh5;->s:Lhh2;

    .line 9
    .line 10
    iget-object v1, p0, Lrh5;->n:Lhh2;

    .line 11
    .line 12
    iget-object v2, p0, Lrh5;->o:Lhh2;

    .line 13
    .line 14
    iget-object v3, p0, Lrh5;->p:Ljava/lang/Object;

    .line 15
    .line 16
    iget-boolean v4, p0, Lrh5;->q:Z

    .line 17
    .line 18
    invoke-direct/range {v0 .. v7}, Lrh5;-><init>(Lhh2;Lhh2;Ljava/lang/Object;ZLsh5;Lhh2;Lfd1;)V

    .line 19
    .line 20
    .line 21
    sget-object p0, Los7;->a:Los7;

    .line 22
    .line 23
    invoke-virtual {v0, p0}, Lrh5;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-byte v0, p0, Lrh5;->m:B

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    sget-object v3, Lsi1;->h:Lsi1;

    .line 6
    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    if-eq v0, v2, :cond_1

    .line 10
    .line 11
    if-ne v0, v1, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Lrh5;->l:Ltp5;

    .line 14
    .line 15
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    goto :goto_1

    .line 19
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 20
    .line 21
    invoke-static {p0}, Lt32;->d(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const/4 p0, 0x0

    .line 25
    return-object p0

    .line 26
    :cond_1
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_2
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iput-byte v2, p0, Lrh5;->m:B

    .line 34
    .line 35
    iget-object p1, p0, Lrh5;->n:Lhh2;

    .line 36
    .line 37
    invoke-interface {p1, p0}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    if-eq p1, v3, :cond_4

    .line 42
    .line 43
    :goto_0
    move-object v0, p1

    .line 44
    check-cast v0, Ltp5;

    .line 45
    .line 46
    iget-object p1, v0, Ltp5;->a:Ljava/lang/Object;

    .line 47
    .line 48
    if-nez p1, :cond_3

    .line 49
    .line 50
    iget-object p1, p0, Lrh5;->o:Lhh2;

    .line 51
    .line 52
    iget-object v1, p0, Lrh5;->p:Ljava/lang/Object;

    .line 53
    .line 54
    invoke-interface {p1, v1}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_3
    iget-boolean p1, p0, Lrh5;->q:Z

    .line 59
    .line 60
    if-eqz p1, :cond_5

    .line 61
    .line 62
    iput-object v0, p0, Lrh5;->l:Ltp5;

    .line 63
    .line 64
    iput-byte v1, p0, Lrh5;->m:B

    .line 65
    .line 66
    iget-object p1, p0, Lrh5;->r:Lsh5;

    .line 67
    .line 68
    invoke-virtual {p1, p0}, Lsh5;->k(Lgd1;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    if-ne p1, v3, :cond_5

    .line 73
    .line 74
    :cond_4
    return-object v3

    .line 75
    :cond_5
    :goto_1
    iget-object p0, p0, Lrh5;->s:Lhh2;

    .line 76
    .line 77
    iget-object p1, v0, Ltp5;->b:Ljava/lang/String;

    .line 78
    .line 79
    invoke-interface {p0, p1}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    sget-object p0, Los7;->a:Los7;

    .line 83
    .line 84
    return-object p0
.end method
