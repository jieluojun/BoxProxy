.class public final Lae0;
.super Lgd1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Lee0;

.field public m:I


# direct methods
.method public constructor <init>(Lee0;Lgd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lae0;->l:Lee0;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lgd1;-><init>(Lfd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iput-object p1, p0, Lae0;->k:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lae0;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lae0;->m:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    const-wide/16 v0, 0x0

    .line 12
    .line 13
    iget-object v2, p0, Lae0;->l:Lee0;

    .line 14
    .line 15
    invoke-virtual {v2, p1, v0, v1, p0}, Lee0;->p(Ljava/lang/String;JLgd1;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method
