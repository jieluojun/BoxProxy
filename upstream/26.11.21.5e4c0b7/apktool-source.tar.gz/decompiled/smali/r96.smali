.class public final synthetic Lr96;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lmb6;

.field public final synthetic j:Lqx3;


# direct methods
.method public synthetic constructor <init>(Lmb6;Lqx3;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lr96;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lr96;->i:Lmb6;

    .line 4
    .line 5
    iput-object p2, p0, Lr96;->j:Lqx3;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lr96;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    iget-object v5, v0, Lr96;->j:Lqx3;

    .line 11
    .line 12
    iget-object v0, v0, Lr96;->i:Lmb6;

    .line 13
    .line 14
    const/4 v6, 0x1

    .line 15
    packed-switch v1, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    move-object/from16 v1, p1

    .line 19
    .line 20
    check-cast v1, Lm01;

    .line 21
    .line 22
    move-object/from16 v7, p2

    .line 23
    .line 24
    check-cast v7, Lki2;

    .line 25
    .line 26
    move-object/from16 v8, p3

    .line 27
    .line 28
    check-cast v8, Ljava/lang/Integer;

    .line 29
    .line 30
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result v8

    .line 34
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    and-int/lit8 v1, v8, 0x11

    .line 38
    .line 39
    if-eq v1, v3, :cond_0

    .line 40
    .line 41
    move v1, v6

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    move v1, v4

    .line 44
    :goto_0
    and-int/2addr v8, v6

    .line 45
    invoke-virtual {v7, v8, v1}, Lki2;->Y(IZ)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-eqz v1, :cond_a

    .line 50
    .line 51
    const v1, 0x7f0f0443

    .line 52
    .line 53
    .line 54
    invoke-static {v1, v7}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    invoke-virtual {v7, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    invoke-virtual {v7, v5}, Lki2;->i(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v6

    .line 66
    or-int/2addr v3, v6

    .line 67
    invoke-virtual {v7}, Lki2;->T()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v6

    .line 71
    sget-object v8, Lz41;->a:Lql0;

    .line 72
    .line 73
    if-nez v3, :cond_1

    .line 74
    .line 75
    if-ne v6, v8, :cond_2

    .line 76
    .line 77
    :cond_1
    new-instance v6, Lir4;

    .line 78
    .line 79
    const/16 v3, 0x13

    .line 80
    .line 81
    invoke-direct {v6, v0, v5, v3}, Lir4;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v7, v6}, Lki2;->q0(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    :cond_2
    check-cast v6, Lwg2;

    .line 88
    .line 89
    new-instance v3, Lj65;

    .line 90
    .line 91
    invoke-direct {v3, v1, v6}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    const v1, 0x7f0f0438

    .line 95
    .line 96
    .line 97
    invoke-static {v1, v7}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    invoke-virtual {v7, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v5

    .line 105
    invoke-virtual {v7}, Lki2;->T()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v6

    .line 109
    if-nez v5, :cond_3

    .line 110
    .line 111
    if-ne v6, v8, :cond_4

    .line 112
    .line 113
    :cond_3
    new-instance v6, Li96;

    .line 114
    .line 115
    const/16 v5, 0x8

    .line 116
    .line 117
    invoke-direct {v6, v0, v5}, Li96;-><init>(Lmb6;B)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v7, v6}, Lki2;->q0(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    :cond_4
    check-cast v6, Lwg2;

    .line 124
    .line 125
    new-instance v5, Lj65;

    .line 126
    .line 127
    invoke-direct {v5, v1, v6}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    const v1, 0x7f0f044c

    .line 131
    .line 132
    .line 133
    invoke-static {v1, v7}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    invoke-virtual {v7, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v6

    .line 141
    invoke-virtual {v7}, Lki2;->T()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v9

    .line 145
    if-nez v6, :cond_5

    .line 146
    .line 147
    if-ne v9, v8, :cond_6

    .line 148
    .line 149
    :cond_5
    new-instance v9, Li96;

    .line 150
    .line 151
    const/16 v6, 0x9

    .line 152
    .line 153
    invoke-direct {v9, v0, v6}, Li96;-><init>(Lmb6;B)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v7, v9}, Lki2;->q0(Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    :cond_6
    check-cast v9, Lwg2;

    .line 160
    .line 161
    new-instance v6, Lj65;

    .line 162
    .line 163
    invoke-direct {v6, v1, v9}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    const v1, 0x7f0f044d

    .line 167
    .line 168
    .line 169
    invoke-static {v1, v7}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    invoke-virtual {v7, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v9

    .line 177
    invoke-virtual {v7}, Lki2;->T()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v10

    .line 181
    if-nez v9, :cond_7

    .line 182
    .line 183
    if-ne v10, v8, :cond_8

    .line 184
    .line 185
    :cond_7
    new-instance v10, Li96;

    .line 186
    .line 187
    const/16 v8, 0xa

    .line 188
    .line 189
    invoke-direct {v10, v0, v8}, Li96;-><init>(Lmb6;B)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v7, v10}, Lki2;->q0(Ljava/lang/Object;)V

    .line 193
    .line 194
    .line 195
    :cond_8
    check-cast v10, Lwg2;

    .line 196
    .line 197
    new-instance v0, Lj65;

    .line 198
    .line 199
    invoke-direct {v0, v1, v10}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    filled-new-array {v3, v5, v6, v0}, [Lj65;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    invoke-static {v0}, Lqf;->Y([Ljava/lang/Object;)Ljava/util/List;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 211
    .line 212
    .line 213
    move-result-object v1

    .line 214
    :goto_1
    move v9, v4

    .line 215
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 216
    .line 217
    .line 218
    move-result v3

    .line 219
    if-eqz v3, :cond_b

    .line 220
    .line 221
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v3

    .line 225
    add-int/lit8 v4, v9, 0x1

    .line 226
    .line 227
    if-ltz v9, :cond_9

    .line 228
    .line 229
    check-cast v3, Lj65;

    .line 230
    .line 231
    iget-object v5, v3, Lj65;->h:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast v5, Ljava/lang/String;

    .line 234
    .line 235
    iget-object v3, v3, Lj65;->i:Ljava/lang/Object;

    .line 236
    .line 237
    move-object v8, v3

    .line 238
    check-cast v8, Lwg2;

    .line 239
    .line 240
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 241
    .line 242
    .line 243
    move-result v10

    .line 244
    new-instance v3, Lf25;

    .line 245
    .line 246
    const/16 v6, 0x1a

    .line 247
    .line 248
    invoke-direct {v3, v5, v6}, Lf25;-><init>(Ljava/lang/String;B)V

    .line 249
    .line 250
    .line 251
    const v5, 0x3bc9d6b1

    .line 252
    .line 253
    .line 254
    invoke-static {v5, v3, v7}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 255
    .line 256
    .line 257
    move-result-object v3

    .line 258
    const/16 v17, 0x6

    .line 259
    .line 260
    const/16 v18, 0x3f0

    .line 261
    .line 262
    const/4 v11, 0x0

    .line 263
    const/4 v12, 0x0

    .line 264
    const/4 v13, 0x0

    .line 265
    const/4 v14, 0x0

    .line 266
    const/4 v15, 0x0

    .line 267
    move-object/from16 v16, v7

    .line 268
    .line 269
    move-object v7, v3

    .line 270
    invoke-static/range {v7 .. v18}, La04;->a(Lq21;Lwg2;IILha4;Lq21;ZLd24;Lu35;Lki2;II)V

    .line 271
    .line 272
    .line 273
    move-object/from16 v7, v16

    .line 274
    .line 275
    goto :goto_1

    .line 276
    :cond_9
    invoke-static {}, Lqf;->z0()V

    .line 277
    .line 278
    .line 279
    const/4 v0, 0x0

    .line 280
    throw v0

    .line 281
    :cond_a
    move-object/from16 v16, v7

    .line 282
    .line 283
    invoke-virtual/range {v16 .. v16}, Lki2;->b0()V

    .line 284
    .line 285
    .line 286
    :cond_b
    return-object v2

    .line 287
    :pswitch_0
    move-object/from16 v1, p1

    .line 288
    .line 289
    check-cast v1, Lm01;

    .line 290
    .line 291
    move-object/from16 v14, p2

    .line 292
    .line 293
    check-cast v14, Lki2;

    .line 294
    .line 295
    move-object/from16 v7, p3

    .line 296
    .line 297
    check-cast v7, Ljava/lang/Integer;

    .line 298
    .line 299
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 300
    .line 301
    .line 302
    move-result v7

    .line 303
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 304
    .line 305
    .line 306
    and-int/lit8 v1, v7, 0x11

    .line 307
    .line 308
    if-eq v1, v3, :cond_c

    .line 309
    .line 310
    move v4, v6

    .line 311
    :cond_c
    and-int/2addr v7, v6

    .line 312
    invoke-virtual {v14, v7, v4}, Lki2;->Y(IZ)Z

    .line 313
    .line 314
    .line 315
    move-result v1

    .line 316
    if-eqz v1, :cond_d

    .line 317
    .line 318
    new-instance v1, Lr96;

    .line 319
    .line 320
    invoke-direct {v1, v0, v5, v6}, Lr96;-><init>(Lmb6;Lqx3;B)V

    .line 321
    .line 322
    .line 323
    const v0, -0x3320d8c1    # -1.169966E8f

    .line 324
    .line 325
    .line 326
    invoke-static {v0, v1, v14}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 327
    .line 328
    .line 329
    move-result-object v13

    .line 330
    const/high16 v15, 0x30000

    .line 331
    .line 332
    const/16 v16, 0x1f

    .line 333
    .line 334
    const/4 v7, 0x0

    .line 335
    const/4 v8, 0x0

    .line 336
    const/4 v9, 0x0

    .line 337
    const/4 v10, 0x0

    .line 338
    const-wide/16 v11, 0x0

    .line 339
    .line 340
    invoke-static/range {v7 .. v16}, La04;->c(IILha4;Lc24;JLq21;Lki2;II)V

    .line 341
    .line 342
    .line 343
    goto :goto_2

    .line 344
    :cond_d
    invoke-virtual {v14}, Lki2;->b0()V

    .line 345
    .line 346
    .line 347
    :goto_2
    return-object v2

    .line 348
    nop

    .line 349
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
