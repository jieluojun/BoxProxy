.class public final Lxj3;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lil3;


# instance fields
.field public final a:Lrk3;

.field public final b:Lwj3;

.field public final c:Lq53;


# direct methods
.method public constructor <init>(Lrk3;Lwj3;Lq53;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lxj3;->a:Lrk3;

    .line 5
    .line 6
    iput-object p2, p0, Lxj3;->b:Lwj3;

    .line 7
    .line 8
    iput-object p3, p0, Lxj3;->c:Lq53;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()I
    .locals 0

    .line 1
    iget-object p0, p0, Lxj3;->b:Lwj3;

    .line 2
    .line 3
    invoke-virtual {p0}, Lwj3;->A()Lq53;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    iget p0, p0, Lq53;->i:I

    .line 8
    .line 9
    return p0
.end method

.method public final b(I)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lxj3;->c:Lq53;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lq53;->g(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object p0, p0, Lxj3;->b:Lwj3;

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Lx43;->B(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    :cond_0
    return-object v0
.end method

.method public final c(I)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Lxj3;->b:Lwj3;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lx43;->z(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final d(ILjava/lang/Object;Lki2;I)V
    .locals 10

    .line 1
    const v0, 0x5905c824

    .line 2
    .line 3
    .line 4
    invoke-virtual {p3, v0}, Lki2;->i0(I)Lki2;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p3, p1}, Lki2;->e(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x4

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v0, 0x2

    .line 16
    :goto_0
    or-int/2addr v0, p4

    .line 17
    invoke-virtual {p3, p2}, Lki2;->i(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    const/16 v1, 0x20

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_1
    const/16 v1, 0x10

    .line 27
    .line 28
    :goto_1
    or-int/2addr v0, v1

    .line 29
    invoke-virtual {p3, p0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_2

    .line 34
    .line 35
    const/16 v1, 0x100

    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_2
    const/16 v1, 0x80

    .line 39
    .line 40
    :goto_2
    or-int/2addr v0, v1

    .line 41
    and-int/lit16 v1, v0, 0x93

    .line 42
    .line 43
    const/16 v2, 0x92

    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    if-eq v1, v2, :cond_3

    .line 47
    .line 48
    move v1, v3

    .line 49
    goto :goto_3

    .line 50
    :cond_3
    const/4 v1, 0x0

    .line 51
    :goto_3
    and-int/lit8 v2, v0, 0x1

    .line 52
    .line 53
    invoke-virtual {p3, v2, v1}, Lki2;->Y(IZ)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-eqz v1, :cond_4

    .line 58
    .line 59
    iget-object v1, p0, Lxj3;->a:Lrk3;

    .line 60
    .line 61
    iget-object v6, v1, Lrk3;->v:Lrl3;

    .line 62
    .line 63
    new-instance v1, Li81;

    .line 64
    .line 65
    invoke-direct {v1, p0, p1, v3}, Li81;-><init>(Ljava/lang/Object;IB)V

    .line 66
    .line 67
    .line 68
    const v2, 0x2b48c518

    .line 69
    .line 70
    .line 71
    invoke-static {v2, v1, p3}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 72
    .line 73
    .line 74
    move-result-object v7

    .line 75
    shr-int/lit8 v1, v0, 0x3

    .line 76
    .line 77
    and-int/lit8 v1, v1, 0xe

    .line 78
    .line 79
    or-int/lit16 v1, v1, 0xc00

    .line 80
    .line 81
    shl-int/lit8 v0, v0, 0x3

    .line 82
    .line 83
    and-int/lit8 v0, v0, 0x70

    .line 84
    .line 85
    or-int/2addr v1, v0

    .line 86
    or-int/lit16 v9, v1, 0x200

    .line 87
    .line 88
    move v5, p1

    .line 89
    move-object v4, p2

    .line 90
    move-object v8, p3

    .line 91
    invoke-static/range {v4 .. v9}, Ll63;->b(Ljava/lang/Object;ILrl3;Lq21;Lki2;I)V

    .line 92
    .line 93
    .line 94
    move-object v3, v4

    .line 95
    move v2, v5

    .line 96
    goto :goto_4

    .line 97
    :cond_4
    move v2, p1

    .line 98
    move-object v3, p2

    .line 99
    move-object v8, p3

    .line 100
    invoke-virtual {v8}, Lki2;->b0()V

    .line 101
    .line 102
    .line 103
    :goto_4
    invoke-virtual {v8}, Lki2;->w()Lhu5;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    if-eqz p1, :cond_5

    .line 108
    .line 109
    new-instance v0, Lsj;

    .line 110
    .line 111
    const/4 v5, 0x7

    .line 112
    move-object v1, p0

    .line 113
    move v4, p4

    .line 114
    invoke-direct/range {v0 .. v5}, Lsj;-><init>(Lil3;ILjava/lang/Object;IB)V

    .line 115
    .line 116
    .line 117
    iput-object v0, p1, Lhu5;->d:Llh2;

    .line 118
    .line 119
    :cond_5
    return-void
.end method

.method public final e(Ljava/lang/Object;)I
    .locals 0

    .line 1
    iget-object p0, p0, Lxj3;->c:Lq53;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lq53;->f(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    const/4 p0, 0x1

    .line 4
    return p0

    .line 5
    :cond_0
    instance-of v0, p1, Lxj3;

    .line 6
    .line 7
    if-nez v0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_1
    check-cast p1, Lxj3;

    .line 12
    .line 13
    iget-object p1, p1, Lxj3;->b:Lwj3;

    .line 14
    .line 15
    iget-object p0, p0, Lxj3;->b:Lwj3;

    .line 16
    .line 17
    invoke-static {p0, p1}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lxj3;->b:Lwj3;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
