.class public final synthetic Ljn;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Z

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ZB)V
    .locals 0

    .line 1
    iput-byte p3, p0, Ljn;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Ljn;->j:Ljava/lang/Object;

    .line 4
    .line 5
    iput-boolean p2, p0, Ljn;->i:Z

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/Object;B)V
    .locals 0

    .line 11
    iput-byte p3, p0, Ljn;->h:B

    iput-boolean p1, p0, Ljn;->i:Z

    iput-object p2, p0, Ljn;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 37

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Ljn;->h:B

    .line 4
    .line 5
    const/16 v2, 0xe

    .line 6
    .line 7
    const/16 v3, 0xb

    .line 8
    .line 9
    sget-object v4, Lea4;->h:Lea4;

    .line 10
    .line 11
    const/high16 v5, 0x3f800000    # 1.0f

    .line 12
    .line 13
    sget-object v6, Lz41;->a:Lql0;

    .line 14
    .line 15
    sget-object v7, Lwi3;->Z:Lj43;

    .line 16
    .line 17
    const/16 v8, 0x10

    .line 18
    .line 19
    iget-boolean v9, v0, Ljn;->i:Z

    .line 20
    .line 21
    sget-object v10, Los7;->a:Los7;

    .line 22
    .line 23
    const/4 v11, 0x0

    .line 24
    const/4 v12, 0x1

    .line 25
    iget-object v13, v0, Ljn;->j:Ljava/lang/Object;

    .line 26
    .line 27
    packed-switch v1, :pswitch_data_0

    .line 28
    .line 29
    .line 30
    check-cast v13, Lc75;

    .line 31
    .line 32
    move-object/from16 v0, p1

    .line 33
    .line 34
    check-cast v0, Lh14;

    .line 35
    .line 36
    move-object/from16 v1, p2

    .line 37
    .line 38
    check-cast v1, Ly04;

    .line 39
    .line 40
    move-object/from16 v2, p3

    .line 41
    .line 42
    check-cast v2, Lra1;

    .line 43
    .line 44
    iget-wide v2, v2, Lra1;->a:J

    .line 45
    .line 46
    invoke-interface {v1, v2, v3}, Ly04;->e(J)Lla5;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    iget v2, v1, Lla5;->h:I

    .line 51
    .line 52
    iget v3, v1, Lla5;->i:I

    .line 53
    .line 54
    new-instance v4, Lq60;

    .line 55
    .line 56
    const/4 v5, 0x7

    .line 57
    invoke-direct {v4, v13, v9, v1, v5}, Lq60;-><init>(Ljava/lang/Object;ZLjava/lang/Object;B)V

    .line 58
    .line 59
    .line 60
    sget-object v1, Lx12;->h:Lx12;

    .line 61
    .line 62
    invoke-interface {v0, v2, v3, v1, v4}, Lh14;->P0(IILjava/util/Map;Lhh2;)Le14;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    return-object v0

    .line 67
    :pswitch_0
    check-cast v13, Lzd4;

    .line 68
    .line 69
    move-object/from16 v1, p1

    .line 70
    .line 71
    check-cast v1, Lpi;

    .line 72
    .line 73
    move-object/from16 v2, p2

    .line 74
    .line 75
    check-cast v2, Lki2;

    .line 76
    .line 77
    move-object/from16 v3, p3

    .line 78
    .line 79
    check-cast v3, Ljava/lang/Integer;

    .line 80
    .line 81
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    and-int/lit8 v1, v3, 0x11

    .line 89
    .line 90
    if-eq v1, v8, :cond_0

    .line 91
    .line 92
    move v11, v12

    .line 93
    :cond_0
    and-int/2addr v3, v12

    .line 94
    invoke-virtual {v2, v3, v11}, Lki2;->Y(IZ)Z

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    if-eqz v1, :cond_3

    .line 99
    .line 100
    const/16 v18, 0x0

    .line 101
    .line 102
    const/16 v19, 0xb

    .line 103
    .line 104
    sget-object v14, Lea4;->h:Lea4;

    .line 105
    .line 106
    const/4 v15, 0x0

    .line 107
    const/16 v16, 0x0

    .line 108
    .line 109
    const/high16 v17, 0x40800000    # 4.0f

    .line 110
    .line 111
    invoke-static/range {v14 .. v19}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 112
    .line 113
    .line 114
    move-result-object v15

    .line 115
    invoke-virtual {v2, v13}, Lki2;->g(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    invoke-virtual {v2}, Lki2;->T()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v3

    .line 123
    if-nez v1, :cond_1

    .line 124
    .line 125
    if-ne v3, v6, :cond_2

    .line 126
    .line 127
    :cond_1
    new-instance v3, Lw44;

    .line 128
    .line 129
    const/16 v1, 0xa

    .line 130
    .line 131
    invoke-direct {v3, v13, v1}, Lw44;-><init>(Lzd4;B)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v2, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    :cond_2
    move-object v14, v3

    .line 138
    check-cast v14, Lwg2;

    .line 139
    .line 140
    sget-object v23, Lxp7;->G:Lq21;

    .line 141
    .line 142
    const v25, 0x6000030

    .line 143
    .line 144
    .line 145
    const/16 v26, 0xf8

    .line 146
    .line 147
    iget-boolean v0, v0, Ljn;->i:Z

    .line 148
    .line 149
    const/16 v17, 0x0

    .line 150
    .line 151
    const-wide/16 v18, 0x0

    .line 152
    .line 153
    const/16 v20, 0x0

    .line 154
    .line 155
    const/16 v21, 0x0

    .line 156
    .line 157
    const/16 v22, 0x0

    .line 158
    .line 159
    move/from16 v16, v0

    .line 160
    .line 161
    move-object/from16 v24, v2

    .line 162
    .line 163
    invoke-static/range {v14 .. v26}, Lr94;->b(Lwg2;Lha4;ZZJFFFLlh2;Lki2;II)V

    .line 164
    .line 165
    .line 166
    goto :goto_0

    .line 167
    :cond_3
    move-object/from16 v24, v2

    .line 168
    .line 169
    invoke-virtual/range {v24 .. v24}, Lki2;->b0()V

    .line 170
    .line 171
    .line 172
    :goto_0
    return-object v10

    .line 173
    :pswitch_1
    check-cast v13, Lcv0;

    .line 174
    .line 175
    move-object/from16 v1, p1

    .line 176
    .line 177
    check-cast v1, Lm01;

    .line 178
    .line 179
    move-object/from16 v2, p2

    .line 180
    .line 181
    check-cast v2, Lki2;

    .line 182
    .line 183
    move-object/from16 v9, p3

    .line 184
    .line 185
    check-cast v9, Ljava/lang/Integer;

    .line 186
    .line 187
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 188
    .line 189
    .line 190
    move-result v9

    .line 191
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 192
    .line 193
    .line 194
    and-int/lit8 v1, v9, 0x11

    .line 195
    .line 196
    if-eq v1, v8, :cond_4

    .line 197
    .line 198
    move v11, v12

    .line 199
    :cond_4
    and-int/2addr v9, v12

    .line 200
    invoke-virtual {v2, v9, v11}, Lki2;->Y(IZ)Z

    .line 201
    .line 202
    .line 203
    move-result v1

    .line 204
    if-eqz v1, :cond_8

    .line 205
    .line 206
    invoke-static {v4, v5}, Lit6;->e(Lha4;F)Lha4;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    const/high16 v4, 0x41900000    # 18.0f

    .line 211
    .line 212
    const/high16 v8, 0x41800000    # 16.0f

    .line 213
    .line 214
    invoke-static {v1, v4, v8}, Ljb3;->y(Lha4;FF)Lha4;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    sget-object v4, Ly6;->t:Lz30;

    .line 219
    .line 220
    sget-object v8, Lx87;->c:Lrw;

    .line 221
    .line 222
    const/16 v9, 0x30

    .line 223
    .line 224
    invoke-static {v8, v4, v2, v9}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 225
    .line 226
    .line 227
    move-result-object v4

    .line 228
    iget-wide v8, v2, Lki2;->U:J

    .line 229
    .line 230
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 231
    .line 232
    .line 233
    move-result v8

    .line 234
    invoke-virtual {v2}, Lki2;->m()Lr95;

    .line 235
    .line 236
    .line 237
    move-result-object v9

    .line 238
    invoke-static {v2, v1}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 239
    .line 240
    .line 241
    move-result-object v1

    .line 242
    sget-object v11, Lp41;->d:Ly6;

    .line 243
    .line 244
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 245
    .line 246
    .line 247
    invoke-virtual {v2}, Lki2;->k0()V

    .line 248
    .line 249
    .line 250
    iget-boolean v11, v2, Lki2;->T:Z

    .line 251
    .line 252
    if-eqz v11, :cond_5

    .line 253
    .line 254
    invoke-virtual {v2, v7}, Lki2;->l(Lwg2;)V

    .line 255
    .line 256
    .line 257
    goto :goto_1

    .line 258
    :cond_5
    invoke-virtual {v2}, Lki2;->t0()V

    .line 259
    .line 260
    .line 261
    :goto_1
    sget-object v7, Ly6;->T:Lu31;

    .line 262
    .line 263
    invoke-static {v7, v2, v4}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 264
    .line 265
    .line 266
    sget-object v4, Ly6;->S:Lu31;

    .line 267
    .line 268
    invoke-static {v4, v2, v9}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 269
    .line 270
    .line 271
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 272
    .line 273
    .line 274
    move-result-object v4

    .line 275
    sget-object v7, Ly6;->U:Lu31;

    .line 276
    .line 277
    invoke-static {v7, v2, v4}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 278
    .line 279
    .line 280
    invoke-static {v2}, Lml6;->p(Lki2;)V

    .line 281
    .line 282
    .line 283
    sget-object v4, Ly6;->R:Lu31;

    .line 284
    .line 285
    invoke-static {v4, v2, v1}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 286
    .line 287
    .line 288
    const v1, 0x7f0f051f

    .line 289
    .line 290
    .line 291
    invoke-static {v1, v2}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 292
    .line 293
    .line 294
    move-result-object v14

    .line 295
    new-instance v15, Lmj3;

    .line 296
    .line 297
    invoke-direct {v15, v5, v12}, Lmj3;-><init>(FZ)V

    .line 298
    .line 299
    .line 300
    sget-object v1, Lsz0;->a:Lcx1;

    .line 301
    .line 302
    invoke-virtual {v2, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v1

    .line 306
    check-cast v1, Lrz0;

    .line 307
    .line 308
    invoke-virtual {v1}, Lrz0;->i()J

    .line 309
    .line 310
    .line 311
    move-result-wide v16

    .line 312
    const/16 v35, 0x0

    .line 313
    .line 314
    const v36, 0x3fff8

    .line 315
    .line 316
    .line 317
    const-wide/16 v18, 0x0

    .line 318
    .line 319
    const/16 v20, 0x0

    .line 320
    .line 321
    const/16 v21, 0x0

    .line 322
    .line 323
    const-wide/16 v22, 0x0

    .line 324
    .line 325
    const/16 v24, 0x0

    .line 326
    .line 327
    const-wide/16 v25, 0x0

    .line 328
    .line 329
    const/16 v27, 0x0

    .line 330
    .line 331
    const/16 v28, 0x0

    .line 332
    .line 333
    const/16 v29, 0x0

    .line 334
    .line 335
    const/16 v30, 0x0

    .line 336
    .line 337
    const/16 v31, 0x0

    .line 338
    .line 339
    const/16 v32, 0x0

    .line 340
    .line 341
    const/16 v34, 0x0

    .line 342
    .line 343
    move-object/from16 v33, v2

    .line 344
    .line 345
    invoke-static/range {v14 .. v36}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 346
    .line 347
    .line 348
    move-object/from16 v1, v33

    .line 349
    .line 350
    invoke-virtual {v13}, Lcv0;->a()Z

    .line 351
    .line 352
    .line 353
    move-result v14

    .line 354
    invoke-virtual {v1, v13}, Lki2;->g(Ljava/lang/Object;)Z

    .line 355
    .line 356
    .line 357
    move-result v2

    .line 358
    invoke-virtual {v1}, Lki2;->T()Ljava/lang/Object;

    .line 359
    .line 360
    .line 361
    move-result-object v4

    .line 362
    if-nez v2, :cond_6

    .line 363
    .line 364
    if-ne v4, v6, :cond_7

    .line 365
    .line 366
    :cond_6
    new-instance v4, Lsv0;

    .line 367
    .line 368
    invoke-direct {v4, v13, v3}, Lsv0;-><init>(Lcv0;B)V

    .line 369
    .line 370
    .line 371
    invoke-virtual {v1, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 372
    .line 373
    .line 374
    :cond_7
    move-object v15, v4

    .line 375
    check-cast v15, Lhh2;

    .line 376
    .line 377
    const/16 v20, 0x0

    .line 378
    .line 379
    const/16 v21, 0xc

    .line 380
    .line 381
    const/16 v16, 0x0

    .line 382
    .line 383
    const/16 v17, 0x0

    .line 384
    .line 385
    iget-boolean v0, v0, Ljn;->i:Z

    .line 386
    .line 387
    move/from16 v18, v0

    .line 388
    .line 389
    move-object/from16 v19, v1

    .line 390
    .line 391
    invoke-static/range {v14 .. v21}, Lpk6;->c(ZLhh2;Lha4;Lv57;ZLki2;II)V

    .line 392
    .line 393
    .line 394
    invoke-virtual {v1, v12}, Lki2;->r(Z)V

    .line 395
    .line 396
    .line 397
    goto :goto_2

    .line 398
    :cond_8
    move-object v1, v2

    .line 399
    invoke-virtual {v1}, Lki2;->b0()V

    .line 400
    .line 401
    .line 402
    :goto_2
    return-object v10

    .line 403
    :pswitch_2
    check-cast v13, Ls50;

    .line 404
    .line 405
    move-object/from16 v0, p1

    .line 406
    .line 407
    check-cast v0, Lm01;

    .line 408
    .line 409
    move-object/from16 v1, p2

    .line 410
    .line 411
    check-cast v1, Lki2;

    .line 412
    .line 413
    move-object/from16 v4, p3

    .line 414
    .line 415
    check-cast v4, Ljava/lang/Integer;

    .line 416
    .line 417
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 418
    .line 419
    .line 420
    move-result v4

    .line 421
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 422
    .line 423
    .line 424
    and-int/lit8 v0, v4, 0x11

    .line 425
    .line 426
    if-eq v0, v8, :cond_9

    .line 427
    .line 428
    move v11, v12

    .line 429
    :cond_9
    and-int/2addr v4, v12

    .line 430
    invoke-virtual {v1, v4, v11}, Lki2;->Y(IZ)Z

    .line 431
    .line 432
    .line 433
    move-result v0

    .line 434
    if-eqz v0, :cond_b

    .line 435
    .line 436
    sget-object v0, Lxb1;->a:Lcx1;

    .line 437
    .line 438
    invoke-virtual {v1, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 439
    .line 440
    .line 441
    move-result-object v0

    .line 442
    check-cast v0, Ldy0;

    .line 443
    .line 444
    iget-wide v4, v0, Ldy0;->a:J

    .line 445
    .line 446
    if-eqz v9, :cond_a

    .line 447
    .line 448
    iget-object v0, v13, Ls50;->i:La53;

    .line 449
    .line 450
    :goto_3
    move-object v14, v0

    .line 451
    goto :goto_4

    .line 452
    :cond_a
    iget-object v0, v13, Ls50;->j:La53;

    .line 453
    .line 454
    goto :goto_3

    .line 455
    :goto_4
    iget v0, v13, Ls50;->h:I

    .line 456
    .line 457
    invoke-static {v0, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 458
    .line 459
    .line 460
    move-result-object v15

    .line 461
    const/16 v20, 0x0

    .line 462
    .line 463
    const/16 v21, 0x4

    .line 464
    .line 465
    const/16 v16, 0x0

    .line 466
    .line 467
    move-object/from16 v19, v1

    .line 468
    .line 469
    move-wide/from16 v17, v4

    .line 470
    .line 471
    invoke-static/range {v14 .. v21}, Lw33;->a(La53;Ljava/lang/String;Lha4;JLki2;II)V

    .line 472
    .line 473
    .line 474
    move-wide/from16 v16, v17

    .line 475
    .line 476
    move-object/from16 v0, v19

    .line 477
    .line 478
    iget v1, v13, Ls50;->h:I

    .line 479
    .line 480
    invoke-static {v1, v0}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 481
    .line 482
    .line 483
    move-result-object v14

    .line 484
    invoke-static {v3}, Lpk6;->o(I)J

    .line 485
    .line 486
    .line 487
    move-result-wide v18

    .line 488
    invoke-static {v2}, Lpk6;->o(I)J

    .line 489
    .line 490
    .line 491
    move-result-wide v25

    .line 492
    const/16 v34, 0x6db0

    .line 493
    .line 494
    const v35, 0x387ea

    .line 495
    .line 496
    .line 497
    const/4 v15, 0x0

    .line 498
    const/16 v20, 0x0

    .line 499
    .line 500
    const/16 v21, 0x0

    .line 501
    .line 502
    const-wide/16 v22, 0x0

    .line 503
    .line 504
    const/16 v24, 0x0

    .line 505
    .line 506
    const/16 v27, 0x3

    .line 507
    .line 508
    const/16 v28, 0x0

    .line 509
    .line 510
    const/16 v29, 0x1

    .line 511
    .line 512
    const/16 v30, 0x0

    .line 513
    .line 514
    const/16 v31, 0x0

    .line 515
    .line 516
    const/16 v33, 0x6000

    .line 517
    .line 518
    move-object/from16 v32, v0

    .line 519
    .line 520
    invoke-static/range {v14 .. v35}, Loe7;->b(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILwg7;Lki2;III)V

    .line 521
    .line 522
    .line 523
    goto :goto_5

    .line 524
    :cond_b
    move-object v0, v1

    .line 525
    invoke-virtual {v0}, Lki2;->b0()V

    .line 526
    .line 527
    .line 528
    :goto_5
    return-object v10

    .line 529
    :pswitch_3
    check-cast v13, Lmh2;

    .line 530
    .line 531
    move-object/from16 v0, p1

    .line 532
    .line 533
    check-cast v0, Lj16;

    .line 534
    .line 535
    move-object/from16 v1, p2

    .line 536
    .line 537
    check-cast v1, Lki2;

    .line 538
    .line 539
    move-object/from16 v3, p3

    .line 540
    .line 541
    check-cast v3, Ljava/lang/Integer;

    .line 542
    .line 543
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 544
    .line 545
    .line 546
    move-result v3

    .line 547
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 548
    .line 549
    .line 550
    and-int/lit8 v4, v3, 0x6

    .line 551
    .line 552
    if-nez v4, :cond_d

    .line 553
    .line 554
    invoke-virtual {v1, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 555
    .line 556
    .line 557
    move-result v4

    .line 558
    if-eqz v4, :cond_c

    .line 559
    .line 560
    const/4 v4, 0x4

    .line 561
    goto :goto_6

    .line 562
    :cond_c
    const/4 v4, 0x2

    .line 563
    :goto_6
    or-int/2addr v3, v4

    .line 564
    :cond_d
    and-int/lit8 v4, v3, 0x13

    .line 565
    .line 566
    const/16 v5, 0x12

    .line 567
    .line 568
    if-eq v4, v5, :cond_e

    .line 569
    .line 570
    move v4, v12

    .line 571
    goto :goto_7

    .line 572
    :cond_e
    move v4, v11

    .line 573
    :goto_7
    and-int/lit8 v5, v3, 0x1

    .line 574
    .line 575
    invoke-virtual {v1, v5, v4}, Lki2;->Y(IZ)Z

    .line 576
    .line 577
    .line 578
    move-result v4

    .line 579
    if-eqz v4, :cond_10

    .line 580
    .line 581
    const/16 v18, 0x0

    .line 582
    .line 583
    const/16 v19, 0xb

    .line 584
    .line 585
    sget-object v14, Lea4;->h:Lea4;

    .line 586
    .line 587
    const/4 v15, 0x0

    .line 588
    const/16 v16, 0x0

    .line 589
    .line 590
    const/high16 v17, 0x41000000    # 8.0f

    .line 591
    .line 592
    invoke-static/range {v14 .. v19}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 593
    .line 594
    .line 595
    move-result-object v4

    .line 596
    invoke-interface {v0, v4}, Lj16;->b(Lha4;)Lha4;

    .line 597
    .line 598
    .line 599
    move-result-object v4

    .line 600
    invoke-interface {v0, v4, v11}, Lj16;->a(Lha4;Z)Lha4;

    .line 601
    .line 602
    .line 603
    move-result-object v4

    .line 604
    sget-object v5, Lx87;->c:Lrw;

    .line 605
    .line 606
    sget-object v6, Ly6;->s:Lz30;

    .line 607
    .line 608
    invoke-static {v5, v6, v1, v11}, Lh16;->a(Ltw;Lz30;Lki2;I)Li16;

    .line 609
    .line 610
    .line 611
    move-result-object v5

    .line 612
    iget-wide v14, v1, Lki2;->U:J

    .line 613
    .line 614
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 615
    .line 616
    .line 617
    move-result v6

    .line 618
    invoke-virtual {v1}, Lki2;->m()Lr95;

    .line 619
    .line 620
    .line 621
    move-result-object v8

    .line 622
    invoke-static {v1, v4}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 623
    .line 624
    .line 625
    move-result-object v4

    .line 626
    sget-object v11, Lp41;->d:Ly6;

    .line 627
    .line 628
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 629
    .line 630
    .line 631
    invoke-virtual {v1}, Lki2;->k0()V

    .line 632
    .line 633
    .line 634
    iget-boolean v11, v1, Lki2;->T:Z

    .line 635
    .line 636
    if-eqz v11, :cond_f

    .line 637
    .line 638
    invoke-virtual {v1, v7}, Lki2;->l(Lwg2;)V

    .line 639
    .line 640
    .line 641
    goto :goto_8

    .line 642
    :cond_f
    invoke-virtual {v1}, Lki2;->t0()V

    .line 643
    .line 644
    .line 645
    :goto_8
    sget-object v7, Ly6;->T:Lu31;

    .line 646
    .line 647
    invoke-static {v7, v1, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 648
    .line 649
    .line 650
    sget-object v5, Ly6;->S:Lu31;

    .line 651
    .line 652
    invoke-static {v5, v1, v8}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 653
    .line 654
    .line 655
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 656
    .line 657
    .line 658
    move-result-object v5

    .line 659
    sget-object v6, Ly6;->U:Lu31;

    .line 660
    .line 661
    invoke-static {v6, v1, v5}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 662
    .line 663
    .line 664
    invoke-static {v1}, Lml6;->p(Lki2;)V

    .line 665
    .line 666
    .line 667
    sget-object v5, Ly6;->R:Lu31;

    .line 668
    .line 669
    invoke-static {v5, v1, v4}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 670
    .line 671
    .line 672
    sget-object v4, Lk16;->a:Lk16;

    .line 673
    .line 674
    const/4 v5, 0x6

    .line 675
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 676
    .line 677
    .line 678
    move-result-object v5

    .line 679
    invoke-interface {v13, v4, v1, v5}, Lmh2;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    invoke-virtual {v1, v12}, Lki2;->r(Z)V

    .line 683
    .line 684
    .line 685
    and-int/2addr v3, v2

    .line 686
    invoke-static {v0, v9, v1, v3}, Lok;->g(Lj16;ZLki2;I)V

    .line 687
    .line 688
    .line 689
    goto :goto_9

    .line 690
    :cond_10
    invoke-virtual {v1}, Lki2;->b0()V

    .line 691
    .line 692
    .line 693
    :goto_9
    return-object v10

    .line 694
    :pswitch_4
    check-cast v13, Ldw;

    .line 695
    .line 696
    move-object/from16 v0, p1

    .line 697
    .line 698
    check-cast v0, Lpi;

    .line 699
    .line 700
    move-object/from16 v1, p2

    .line 701
    .line 702
    check-cast v1, Lki2;

    .line 703
    .line 704
    move-object/from16 v2, p3

    .line 705
    .line 706
    check-cast v2, Ljava/lang/Integer;

    .line 707
    .line 708
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 709
    .line 710
    .line 711
    move-result v2

    .line 712
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 713
    .line 714
    .line 715
    and-int/lit8 v0, v2, 0x11

    .line 716
    .line 717
    if-eq v0, v8, :cond_11

    .line 718
    .line 719
    move v0, v12

    .line 720
    goto :goto_a

    .line 721
    :cond_11
    move v0, v11

    .line 722
    :goto_a
    and-int/2addr v2, v12

    .line 723
    invoke-virtual {v1, v2, v0}, Lki2;->Y(IZ)Z

    .line 724
    .line 725
    .line 726
    move-result v0

    .line 727
    if-eqz v0, :cond_14

    .line 728
    .line 729
    invoke-static {v4, v5}, Lit6;->e(Lha4;F)Lha4;

    .line 730
    .line 731
    .line 732
    move-result-object v0

    .line 733
    sget-object v2, Lx87;->e:Lsw;

    .line 734
    .line 735
    sget-object v3, Ly6;->v:Ly30;

    .line 736
    .line 737
    invoke-static {v2, v3, v1, v11}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 738
    .line 739
    .line 740
    move-result-object v2

    .line 741
    iget-wide v3, v1, Lki2;->U:J

    .line 742
    .line 743
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 744
    .line 745
    .line 746
    move-result v3

    .line 747
    invoke-virtual {v1}, Lki2;->m()Lr95;

    .line 748
    .line 749
    .line 750
    move-result-object v4

    .line 751
    invoke-static {v1, v0}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 752
    .line 753
    .line 754
    move-result-object v0

    .line 755
    sget-object v5, Lp41;->d:Ly6;

    .line 756
    .line 757
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 758
    .line 759
    .line 760
    invoke-virtual {v1}, Lki2;->k0()V

    .line 761
    .line 762
    .line 763
    iget-boolean v5, v1, Lki2;->T:Z

    .line 764
    .line 765
    if-eqz v5, :cond_12

    .line 766
    .line 767
    invoke-virtual {v1, v7}, Lki2;->l(Lwg2;)V

    .line 768
    .line 769
    .line 770
    goto :goto_b

    .line 771
    :cond_12
    invoke-virtual {v1}, Lki2;->t0()V

    .line 772
    .line 773
    .line 774
    :goto_b
    sget-object v5, Ly6;->T:Lu31;

    .line 775
    .line 776
    invoke-static {v5, v1, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 777
    .line 778
    .line 779
    sget-object v2, Ly6;->S:Lu31;

    .line 780
    .line 781
    invoke-static {v2, v1, v4}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 782
    .line 783
    .line 784
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 785
    .line 786
    .line 787
    move-result-object v2

    .line 788
    sget-object v3, Ly6;->U:Lu31;

    .line 789
    .line 790
    invoke-static {v3, v1, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 791
    .line 792
    .line 793
    invoke-static {v1}, Lml6;->p(Lki2;)V

    .line 794
    .line 795
    .line 796
    sget-object v2, Ly6;->R:Lu31;

    .line 797
    .line 798
    invoke-static {v2, v1, v0}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 799
    .line 800
    .line 801
    const v0, -0x6d69e73a

    .line 802
    .line 803
    .line 804
    invoke-virtual {v1, v0}, Lki2;->h0(I)V

    .line 805
    .line 806
    .line 807
    iget-object v0, v13, Ldw;->b:Ljava/util/ArrayList;

    .line 808
    .line 809
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 810
    .line 811
    .line 812
    move-result-object v0

    .line 813
    :goto_c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 814
    .line 815
    .line 816
    move-result v2

    .line 817
    if-eqz v2, :cond_13

    .line 818
    .line 819
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 820
    .line 821
    .line 822
    move-result-object v2

    .line 823
    check-cast v2, Lcv;

    .line 824
    .line 825
    invoke-static {v2, v9, v1, v11}, Ldl;->b(Lcv;ZLki2;I)V

    .line 826
    .line 827
    .line 828
    goto :goto_c

    .line 829
    :cond_13
    invoke-virtual {v1, v11}, Lki2;->r(Z)V

    .line 830
    .line 831
    .line 832
    invoke-virtual {v1, v12}, Lki2;->r(Z)V

    .line 833
    .line 834
    .line 835
    goto :goto_d

    .line 836
    :cond_14
    invoke-virtual {v1}, Lki2;->b0()V

    .line 837
    .line 838
    .line 839
    :goto_d
    return-object v10

    .line 840
    :pswitch_5
    check-cast v13, Lxo5;

    .line 841
    .line 842
    move-object/from16 v0, p1

    .line 843
    .line 844
    check-cast v0, Lj16;

    .line 845
    .line 846
    move-object/from16 v1, p2

    .line 847
    .line 848
    check-cast v1, Lki2;

    .line 849
    .line 850
    move-object/from16 v2, p3

    .line 851
    .line 852
    check-cast v2, Ljava/lang/Integer;

    .line 853
    .line 854
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 855
    .line 856
    .line 857
    move-result v2

    .line 858
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 859
    .line 860
    .line 861
    and-int/lit8 v0, v2, 0x11

    .line 862
    .line 863
    if-eq v0, v8, :cond_15

    .line 864
    .line 865
    move v0, v12

    .line 866
    goto :goto_e

    .line 867
    :cond_15
    move v0, v11

    .line 868
    :goto_e
    and-int/2addr v2, v12

    .line 869
    invoke-virtual {v1, v2, v0}, Lki2;->Y(IZ)Z

    .line 870
    .line 871
    .line 872
    move-result v0

    .line 873
    if-eqz v0, :cond_19

    .line 874
    .line 875
    if-nez v13, :cond_16

    .line 876
    .line 877
    const v0, 0x3482e418

    .line 878
    .line 879
    .line 880
    invoke-virtual {v1, v0}, Lki2;->h0(I)V

    .line 881
    .line 882
    .line 883
    invoke-virtual {v1, v11}, Lki2;->r(Z)V

    .line 884
    .line 885
    .line 886
    const/4 v0, 0x0

    .line 887
    goto :goto_f

    .line 888
    :cond_16
    const v0, -0x71eb42f7

    .line 889
    .line 890
    .line 891
    invoke-virtual {v1, v0}, Lki2;->h0(I)V

    .line 892
    .line 893
    .line 894
    sget-object v0, Lxo5;->c:Ljava/util/List;

    .line 895
    .line 896
    iget-object v0, v13, Lxo5;->a:Ljava/lang/String;

    .line 897
    .line 898
    invoke-virtual {v1, v11}, Lki2;->r(Z)V

    .line 899
    .line 900
    .line 901
    :goto_f
    if-nez v0, :cond_17

    .line 902
    .line 903
    const-string v0, "--"

    .line 904
    .line 905
    :cond_17
    move-object v14, v0

    .line 906
    if-eqz v9, :cond_18

    .line 907
    .line 908
    const v0, 0x34840da0

    .line 909
    .line 910
    .line 911
    invoke-virtual {v1, v0}, Lki2;->h0(I)V

    .line 912
    .line 913
    .line 914
    sget-object v0, Lsz0;->a:Lcx1;

    .line 915
    .line 916
    invoke-virtual {v1, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 917
    .line 918
    .line 919
    move-result-object v0

    .line 920
    check-cast v0, Lrz0;

    .line 921
    .line 922
    invoke-virtual {v0}, Lrz0;->o()J

    .line 923
    .line 924
    .line 925
    move-result-wide v2

    .line 926
    invoke-virtual {v1, v11}, Lki2;->r(Z)V

    .line 927
    .line 928
    .line 929
    :goto_10
    move-wide/from16 v16, v2

    .line 930
    .line 931
    goto :goto_11

    .line 932
    :cond_18
    const v0, 0x34855510

    .line 933
    .line 934
    .line 935
    invoke-virtual {v1, v0}, Lki2;->h0(I)V

    .line 936
    .line 937
    .line 938
    sget-object v0, Lsz0;->a:Lcx1;

    .line 939
    .line 940
    invoke-virtual {v1, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 941
    .line 942
    .line 943
    move-result-object v0

    .line 944
    check-cast v0, Lrz0;

    .line 945
    .line 946
    invoke-virtual {v0}, Lrz0;->n()J

    .line 947
    .line 948
    .line 949
    move-result-wide v2

    .line 950
    invoke-virtual {v1, v11}, Lki2;->r(Z)V

    .line 951
    .line 952
    .line 953
    goto :goto_10

    .line 954
    :goto_11
    const/16 v0, 0xf

    .line 955
    .line 956
    invoke-static {v0}, Lpk6;->o(I)J

    .line 957
    .line 958
    .line 959
    move-result-wide v18

    .line 960
    const/16 v35, 0x6180

    .line 961
    .line 962
    const v36, 0x3afea

    .line 963
    .line 964
    .line 965
    const/4 v15, 0x0

    .line 966
    const/16 v20, 0x0

    .line 967
    .line 968
    const/16 v21, 0x0

    .line 969
    .line 970
    const-wide/16 v22, 0x0

    .line 971
    .line 972
    const/16 v24, 0x0

    .line 973
    .line 974
    const-wide/16 v25, 0x0

    .line 975
    .line 976
    const/16 v27, 0x2

    .line 977
    .line 978
    const/16 v28, 0x0

    .line 979
    .line 980
    const/16 v29, 0x1

    .line 981
    .line 982
    const/16 v30, 0x0

    .line 983
    .line 984
    const/16 v31, 0x0

    .line 985
    .line 986
    const/16 v32, 0x0

    .line 987
    .line 988
    const/16 v34, 0x6000

    .line 989
    .line 990
    move-object/from16 v33, v1

    .line 991
    .line 992
    invoke-static/range {v14 .. v36}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 993
    .line 994
    .line 995
    goto :goto_12

    .line 996
    :cond_19
    move-object/from16 v33, v1

    .line 997
    .line 998
    invoke-virtual/range {v33 .. v33}, Lki2;->b0()V

    .line 999
    .line 1000
    .line 1001
    :goto_12
    return-object v10

    .line 1002
    nop

    .line 1003
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
