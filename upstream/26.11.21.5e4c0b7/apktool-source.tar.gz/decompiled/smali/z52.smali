.class public final Lz52;
.super Lv92;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final v:Lb62;

.field public final w:[F


# direct methods
.method public constructor <init>(Ld02;Ld61;Ltj0;Ltj0;Ltj0;Ltj0;Ljava/lang/String;Ljava/lang/String;Lb62;[F)V
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p8}, Lv92;-><init>(Ld02;Lc61;Ltj0;Ltj0;Ltj0;Ltj0;Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    iput-object p9, p0, Lz52;->v:Lb62;

    .line 5
    .line 6
    iput-object p10, p0, Lz52;->w:[F

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final q()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "feColorMatrix"

    .line 2
    .line 3
    return-object p0
.end method
