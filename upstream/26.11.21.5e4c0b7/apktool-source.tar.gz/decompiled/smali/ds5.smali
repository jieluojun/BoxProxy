.class public abstract Lds5;
.super Ljava/lang/Object;


# static fields
.field public static final a:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const/16 v0, 0x19

    .line 2
    .line 3
    new-array v0, v0, [I

    .line 4
    .line 5
    fill-array-data v0, :array_0

    .line 6
    .line 7
    .line 8
    sput-object v0, Lds5;->a:[I

    .line 9
    .line 10
    return-void

    .line 11
    :array_0
    .array-data 4
        0x7f040031
        0x7f040071
        0x7f04007a
        0x7f04007d
        0x7f0400ab
        0x7f0400ac
        0x7f0400ad
        0x7f0400b0
        0x7f0400bf
        0x7f0400c1
        0x7f0400d1
        0x7f0400d2
        0x7f040152
        0x7f040162
        0x7f040163
        0x7f040164
        0x7f040165
        0x7f040166
        0x7f040167
        0x7f040193
        0x7f040194
        0x7f040196
        0x7f0401a3
        0x7f0401c1
        0x7f0401ce
    .end array-data
.end method
