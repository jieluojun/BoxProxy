.class public final Lhu2;
.super Lf57;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public l:Log0;

.field public m:Ljava/lang/Integer;

.field public n:B

.field public final synthetic o:Log0;

.field public final synthetic p:I

.field public final synthetic q:Lhh3;


# direct methods
.method public constructor <init>(Log0;ILhh3;Lfd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lhu2;->o:Log0;

    .line 2
    .line 3
    iput p2, p0, Lhu2;->p:I

    .line 4
    .line 5
    iput-object p3, p0, Lhu2;->q:Lhh3;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lf57;-><init>(ILfd1;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lri1;

    .line 2
    .line 3
    check-cast p2, Lfd1;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, Lhu2;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lhu2;

    .line 10
    .line 11
    sget-object p1, Los7;->a:Los7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lhu2;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final s(Lfd1;Ljava/lang/Object;)Lfd1;
    .locals 2

    .line 1
    new-instance p2, Lhu2;

    .line 2
    .line 3
    iget v0, p0, Lhu2;->p:I

    .line 4
    .line 5
    iget-object v1, p0, Lhu2;->q:Lhh3;

    .line 6
    .line 7
    iget-object p0, p0, Lhu2;->o:Log0;

    .line 8
    .line 9
    invoke-direct {p2, p0, v0, v1, p1}, Lhu2;-><init>(Log0;ILhh3;Lfd1;)V

    .line 10
    .line 11
    .line 12
    return-object p2
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-byte v0, p0, Lhu2;->n:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    sget-object v4, Lsi1;->h:Lsi1;

    .line 7
    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    if-eq v0, v3, :cond_1

    .line 11
    .line 12
    if-ne v0, v2, :cond_0

    .line 13
    .line 14
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    goto :goto_1

    .line 18
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-static {p0}, Lt32;->d(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-object v1

    .line 24
    :cond_1
    iget-object v0, p0, Lhu2;->m:Ljava/lang/Integer;

    .line 25
    .line 26
    iget-object v3, p0, Lhu2;->l:Log0;

    .line 27
    .line 28
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_2
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    new-instance v0, Ljava/lang/Integer;

    .line 36
    .line 37
    iget p1, p0, Lhu2;->p:I

    .line 38
    .line 39
    invoke-direct {v0, p1}, Ljava/lang/Integer;-><init>(I)V

    .line 40
    .line 41
    .line 42
    sget-object p1, Lju2;->a:Lju2;

    .line 43
    .line 44
    iget-object p1, p0, Lhu2;->q:Lhh3;

    .line 45
    .line 46
    iget-object p1, p1, Lhh3;->b:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v5, p0, Lhu2;->o:Log0;

    .line 49
    .line 50
    iput-object v5, p0, Lhu2;->l:Log0;

    .line 51
    .line 52
    iput-object v0, p0, Lhu2;->m:Ljava/lang/Integer;

    .line 53
    .line 54
    iput-byte v3, p0, Lhu2;->n:B

    .line 55
    .line 56
    sget-object v3, Lhr1;->a:Lin1;

    .line 57
    .line 58
    sget-object v3, Lzm1;->j:Lzm1;

    .line 59
    .line 60
    new-instance v6, Lig;

    .line 61
    .line 62
    invoke-direct {v6, p1, v1}, Lig;-><init>(Ljava/lang/String;Lfd1;)V

    .line 63
    .line 64
    .line 65
    invoke-static {v3, v6, p0}, Ljj;->u0(Lii1;Llh2;Lfd1;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    if-eq p1, v4, :cond_3

    .line 70
    .line 71
    move-object v3, v5

    .line 72
    :goto_0
    new-instance v5, Lj65;

    .line 73
    .line 74
    invoke-direct {v5, v0, p1}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    iput-object v1, p0, Lhu2;->l:Log0;

    .line 78
    .line 79
    iput-object v1, p0, Lhu2;->m:Ljava/lang/Integer;

    .line 80
    .line 81
    iput-byte v2, p0, Lhu2;->n:B

    .line 82
    .line 83
    invoke-interface {v3, p0, v5}, Lwk6;->a(Lfd1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    if-ne p0, v4, :cond_4

    .line 88
    .line 89
    :cond_3
    return-object v4

    .line 90
    :cond_4
    :goto_1
    sget-object p0, Los7;->a:Los7;

    .line 91
    .line 92
    return-object p0
.end method
