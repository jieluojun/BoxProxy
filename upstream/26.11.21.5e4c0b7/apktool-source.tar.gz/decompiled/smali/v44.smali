.class public final Lv44;
.super Lf57;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic l:B

.field public final synthetic m:Lv34;


# direct methods
.method public synthetic constructor <init>(Lv34;Lfd1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lv44;->l:B

    .line 2
    .line 3
    iput-object p1, p0, Lv44;->m:Lv34;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, Lf57;-><init>(ILfd1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lv44;->l:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    check-cast p1, Lri1;

    .line 6
    .line 7
    check-cast p2, Lfd1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lv44;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lv44;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lv44;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    invoke-virtual {p0, p2, p1}, Lv44;->s(Lfd1;Ljava/lang/Object;)Lfd1;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Lv44;

    .line 27
    .line 28
    invoke-virtual {p0, v1}, Lv44;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-object v1

    .line 32
    nop

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final s(Lfd1;Ljava/lang/Object;)Lfd1;
    .locals 1

    .line 1
    iget-byte p2, p0, Lv44;->l:B

    .line 2
    .line 3
    iget-object p0, p0, Lv44;->m:Lv34;

    .line 4
    .line 5
    packed-switch p2, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance p2, Lv44;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p2, p0, p1, v0}, Lv44;-><init>(Lv34;Lfd1;B)V

    .line 12
    .line 13
    .line 14
    return-object p2

    .line 15
    :pswitch_0
    new-instance p2, Lv44;

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-direct {p2, p0, p1, v0}, Lv44;-><init>(Lv34;Lfd1;B)V

    .line 19
    .line 20
    .line 21
    return-object p2

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lv44;->l:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const/4 v2, 0x4

    .line 6
    const/4 v3, 0x0

    .line 7
    const-string v4, "mihomo-scripts-load"

    .line 8
    .line 9
    iget-object p0, p0, Lv44;->m:Lv34;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iget-object p1, p0, Lv34;->b:Lip6;

    .line 18
    .line 19
    new-instance v0, Ldp;

    .line 20
    .line 21
    invoke-direct {v0, p0, v3, v2}, Ldp;-><init>(Ljava/lang/Object;Lfd1;B)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1, v0, v4}, Lip6;->e(Lhh2;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-object v1

    .line 28
    :pswitch_0
    invoke-static {p1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p0, Lv34;->b:Lip6;

    .line 32
    .line 33
    new-instance v0, Ldp;

    .line 34
    .line 35
    invoke-direct {v0, p0, v3, v2}, Ldp;-><init>(Ljava/lang/Object;Lfd1;B)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1, v0, v4}, Lip6;->e(Lhh2;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    return-object v1

    .line 42
    nop

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
