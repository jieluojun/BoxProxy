.class public final synthetic Lbu;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Lqv;

.field public final synthetic l:Lwg2;

.field public final synthetic m:Lft;

.field public final synthetic n:Ljava/lang/String;

.field public final synthetic o:Ljava/util/Set;

.field public final synthetic p:Lqv;

.field public final synthetic q:Z

.field public final synthetic r:Ljava/util/ArrayList;

.field public final synthetic s:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Ld52;Lwg2;Lqv;Lft;Ljava/lang/String;Ljava/util/Set;Lqv;ZLjava/util/ArrayList;Lwg2;Ljava/util/List;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Lbu;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lbu;->i:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lbu;->l:Lwg2;

    .line 10
    .line 11
    iput-object p3, p0, Lbu;->k:Lqv;

    .line 12
    .line 13
    iput-object p4, p0, Lbu;->m:Lft;

    .line 14
    .line 15
    iput-object p5, p0, Lbu;->n:Ljava/lang/String;

    .line 16
    .line 17
    iput-object p6, p0, Lbu;->o:Ljava/util/Set;

    .line 18
    .line 19
    iput-object p7, p0, Lbu;->p:Lqv;

    .line 20
    .line 21
    iput-boolean p8, p0, Lbu;->q:Z

    .line 22
    .line 23
    iput-object p9, p0, Lbu;->r:Ljava/util/ArrayList;

    .line 24
    .line 25
    iput-object p10, p0, Lbu;->j:Ljava/lang/Object;

    .line 26
    .line 27
    iput-object p11, p0, Lbu;->s:Ljava/util/List;

    .line 28
    .line 29
    return-void
.end method

.method public synthetic constructor <init>(Le52;Ltm3;Lqv;Lwg2;Lft;Ljava/lang/String;Ljava/util/Set;Lqv;ZLjava/util/ArrayList;Ljava/util/List;B)V
    .locals 0

    .line 30
    iput-byte p12, p0, Lbu;->h:B

    iput-object p1, p0, Lbu;->i:Ljava/lang/Object;

    iput-object p2, p0, Lbu;->j:Ljava/lang/Object;

    iput-object p3, p0, Lbu;->k:Lqv;

    iput-object p4, p0, Lbu;->l:Lwg2;

    iput-object p5, p0, Lbu;->m:Lft;

    iput-object p6, p0, Lbu;->n:Ljava/lang/String;

    iput-object p7, p0, Lbu;->o:Ljava/util/Set;

    iput-object p8, p0, Lbu;->p:Lqv;

    iput-boolean p9, p0, Lbu;->q:Z

    iput-object p10, p0, Lbu;->r:Ljava/util/ArrayList;

    iput-object p11, p0, Lbu;->s:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 38

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lbu;->h:B

    .line 4
    .line 5
    sget-object v2, Lwi3;->Z:Lj43;

    .line 6
    .line 7
    sget-object v3, Lea4;->h:Lea4;

    .line 8
    .line 9
    iget-object v4, v0, Lbu;->s:Ljava/util/List;

    .line 10
    .line 11
    iget-object v5, v0, Lbu;->l:Lwg2;

    .line 12
    .line 13
    sget-object v6, Los7;->a:Los7;

    .line 14
    .line 15
    iget-object v7, v0, Lbu;->j:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v8, v0, Lbu;->i:Ljava/lang/Object;

    .line 18
    .line 19
    const/4 v9, 0x2

    .line 20
    const/4 v10, 0x1

    .line 21
    const/4 v11, 0x0

    .line 22
    packed-switch v1, :pswitch_data_0

    .line 23
    .line 24
    .line 25
    move-object/from16 v21, v8

    .line 26
    .line 27
    check-cast v21, Ld52;

    .line 28
    .line 29
    move-object/from16 v20, v7

    .line 30
    .line 31
    check-cast v20, Lwg2;

    .line 32
    .line 33
    move-object/from16 v1, p1

    .line 34
    .line 35
    check-cast v1, Lki2;

    .line 36
    .line 37
    move-object/from16 v7, p2

    .line 38
    .line 39
    check-cast v7, Ljava/lang/Integer;

    .line 40
    .line 41
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    and-int/lit8 v8, v7, 0x3

    .line 46
    .line 47
    if-eq v8, v9, :cond_0

    .line 48
    .line 49
    move v8, v10

    .line 50
    goto :goto_0

    .line 51
    :cond_0
    move v8, v11

    .line 52
    :goto_0
    and-int/2addr v7, v10

    .line 53
    invoke-virtual {v1, v7, v8}, Lki2;->Y(IZ)Z

    .line 54
    .line 55
    .line 56
    move-result v7

    .line 57
    if-eqz v7, :cond_2

    .line 58
    .line 59
    sget-object v7, Lx87;->e:Lsw;

    .line 60
    .line 61
    sget-object v8, Ly6;->v:Ly30;

    .line 62
    .line 63
    invoke-static {v7, v8, v1, v11}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 64
    .line 65
    .line 66
    move-result-object v7

    .line 67
    iget-wide v8, v1, Lki2;->U:J

    .line 68
    .line 69
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 70
    .line 71
    .line 72
    move-result v8

    .line 73
    invoke-virtual {v1}, Lki2;->m()Lr95;

    .line 74
    .line 75
    .line 76
    move-result-object v9

    .line 77
    invoke-static {v1, v3}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    sget-object v11, Lp41;->d:Ly6;

    .line 82
    .line 83
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1}, Lki2;->k0()V

    .line 87
    .line 88
    .line 89
    iget-boolean v11, v1, Lki2;->T:Z

    .line 90
    .line 91
    if-eqz v11, :cond_1

    .line 92
    .line 93
    invoke-virtual {v1, v2}, Lki2;->l(Lwg2;)V

    .line 94
    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_1
    invoke-virtual {v1}, Lki2;->t0()V

    .line 98
    .line 99
    .line 100
    :goto_1
    sget-object v2, Ly6;->T:Lu31;

    .line 101
    .line 102
    invoke-static {v2, v1, v7}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    sget-object v2, Ly6;->S:Lu31;

    .line 106
    .line 107
    invoke-static {v2, v1, v9}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 111
    .line 112
    .line 113
    move-result-object v2

    .line 114
    sget-object v7, Ly6;->U:Lu31;

    .line 115
    .line 116
    invoke-static {v7, v1, v2}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    invoke-static {v1}, Lml6;->p(Lki2;)V

    .line 120
    .line 121
    .line 122
    sget-object v2, Ly6;->R:Lu31;

    .line 123
    .line 124
    invoke-static {v2, v1, v3}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    const v2, 0x7f0f051b

    .line 128
    .line 129
    .line 130
    invoke-static {v2, v1}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    new-instance v3, Lj;

    .line 135
    .line 136
    const/16 v7, 0xc

    .line 137
    .line 138
    invoke-direct {v3, v5, v7}, Lj;-><init>(Lwg2;B)V

    .line 139
    .line 140
    .line 141
    const v5, -0x3a8ef3d6

    .line 142
    .line 143
    .line 144
    invoke-static {v5, v3, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    new-instance v12, Lji0;

    .line 149
    .line 150
    iget-object v13, v0, Lbu;->k:Lqv;

    .line 151
    .line 152
    iget-object v14, v0, Lbu;->m:Lft;

    .line 153
    .line 154
    iget-object v15, v0, Lbu;->n:Ljava/lang/String;

    .line 155
    .line 156
    iget-object v5, v0, Lbu;->o:Ljava/util/Set;

    .line 157
    .line 158
    iget-object v7, v0, Lbu;->p:Lqv;

    .line 159
    .line 160
    iget-boolean v8, v0, Lbu;->q:Z

    .line 161
    .line 162
    iget-object v0, v0, Lbu;->r:Ljava/util/ArrayList;

    .line 163
    .line 164
    move-object/from16 v19, v0

    .line 165
    .line 166
    move-object/from16 v16, v5

    .line 167
    .line 168
    move-object/from16 v17, v7

    .line 169
    .line 170
    move/from16 v18, v8

    .line 171
    .line 172
    invoke-direct/range {v12 .. v20}, Lji0;-><init>(Lqv;Lft;Ljava/lang/String;Ljava/util/Set;Lqv;ZLjava/util/ArrayList;Lwg2;)V

    .line 173
    .line 174
    .line 175
    const v0, -0x22076e5f

    .line 176
    .line 177
    .line 178
    invoke-static {v0, v12, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 179
    .line 180
    .line 181
    move-result-object v20

    .line 182
    new-instance v0, Leu;

    .line 183
    .line 184
    invoke-direct {v0, v13, v4, v10}, Leu;-><init>(Lqv;Ljava/util/List;B)V

    .line 185
    .line 186
    .line 187
    const v4, -0x3f8b51e8

    .line 188
    .line 189
    .line 190
    invoke-static {v4, v0, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 191
    .line 192
    .line 193
    move-result-object v24

    .line 194
    const/16 v27, 0x6

    .line 195
    .line 196
    const/16 v28, 0x31e

    .line 197
    .line 198
    const/4 v13, 0x0

    .line 199
    const-wide/16 v14, 0x0

    .line 200
    .line 201
    const-wide/16 v16, 0x0

    .line 202
    .line 203
    const/16 v18, 0x0

    .line 204
    .line 205
    const/16 v22, 0x0

    .line 206
    .line 207
    const/16 v23, 0x0

    .line 208
    .line 209
    const/high16 v26, 0x1b0000

    .line 210
    .line 211
    move-object/from16 v25, v1

    .line 212
    .line 213
    move-object v12, v2

    .line 214
    move-object/from16 v19, v3

    .line 215
    .line 216
    invoke-static/range {v12 .. v28}, Lr94;->g(Ljava/lang/String;Lha4;JJLjava/lang/String;Lq21;Lq21;Ld52;ZLjava/lang/Boolean;Lq21;Lki2;III)V

    .line 217
    .line 218
    .line 219
    move-object/from16 v0, v25

    .line 220
    .line 221
    invoke-virtual {v0, v10}, Lki2;->r(Z)V

    .line 222
    .line 223
    .line 224
    goto :goto_2

    .line 225
    :cond_2
    move-object v0, v1

    .line 226
    invoke-virtual {v0}, Lki2;->b0()V

    .line 227
    .line 228
    .line 229
    :goto_2
    return-object v6

    .line 230
    :pswitch_0
    move-object v12, v8

    .line 231
    check-cast v12, Le52;

    .line 232
    .line 233
    move-object v13, v7

    .line 234
    check-cast v13, Ltm3;

    .line 235
    .line 236
    move-object/from16 v1, p1

    .line 237
    .line 238
    check-cast v1, Lki2;

    .line 239
    .line 240
    move-object/from16 v2, p2

    .line 241
    .line 242
    check-cast v2, Ljava/lang/Integer;

    .line 243
    .line 244
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 245
    .line 246
    .line 247
    move-result v2

    .line 248
    and-int/lit8 v3, v2, 0x3

    .line 249
    .line 250
    if-eq v3, v9, :cond_3

    .line 251
    .line 252
    move v11, v10

    .line 253
    :cond_3
    and-int/2addr v2, v10

    .line 254
    invoke-virtual {v1, v2, v11}, Lki2;->Y(IZ)Z

    .line 255
    .line 256
    .line 257
    move-result v2

    .line 258
    if-eqz v2, :cond_4

    .line 259
    .line 260
    invoke-static {v1}, Lh43;->T(Lki2;)Lha4;

    .line 261
    .line 262
    .line 263
    move-result-object v2

    .line 264
    invoke-static {v1}, Lh43;->V(Lki2;)J

    .line 265
    .line 266
    .line 267
    move-result-wide v3

    .line 268
    new-instance v11, Lbu;

    .line 269
    .line 270
    const/16 v23, 0x0

    .line 271
    .line 272
    iget-object v14, v0, Lbu;->k:Lqv;

    .line 273
    .line 274
    iget-object v15, v0, Lbu;->l:Lwg2;

    .line 275
    .line 276
    iget-object v5, v0, Lbu;->m:Lft;

    .line 277
    .line 278
    iget-object v7, v0, Lbu;->n:Ljava/lang/String;

    .line 279
    .line 280
    iget-object v8, v0, Lbu;->o:Ljava/util/Set;

    .line 281
    .line 282
    iget-object v9, v0, Lbu;->p:Lqv;

    .line 283
    .line 284
    iget-boolean v10, v0, Lbu;->q:Z

    .line 285
    .line 286
    move-object/from16 p1, v2

    .line 287
    .line 288
    iget-object v2, v0, Lbu;->r:Ljava/util/ArrayList;

    .line 289
    .line 290
    iget-object v0, v0, Lbu;->s:Ljava/util/List;

    .line 291
    .line 292
    move-object/from16 v22, v0

    .line 293
    .line 294
    move-object/from16 v21, v2

    .line 295
    .line 296
    move-object/from16 v16, v5

    .line 297
    .line 298
    move-object/from16 v17, v7

    .line 299
    .line 300
    move-object/from16 v18, v8

    .line 301
    .line 302
    move-object/from16 v19, v9

    .line 303
    .line 304
    move/from16 v20, v10

    .line 305
    .line 306
    invoke-direct/range {v11 .. v23}, Lbu;-><init>(Le52;Ltm3;Lqv;Lwg2;Lft;Ljava/lang/String;Ljava/util/Set;Lqv;ZLjava/util/ArrayList;Ljava/util/List;B)V

    .line 307
    .line 308
    .line 309
    const v0, -0x32544e56

    .line 310
    .line 311
    .line 312
    invoke-static {v0, v11, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 313
    .line 314
    .line 315
    move-result-object v23

    .line 316
    const/high16 v25, 0xc00000

    .line 317
    .line 318
    const/16 v26, 0x7a

    .line 319
    .line 320
    const/4 v15, 0x0

    .line 321
    const-wide/16 v18, 0x0

    .line 322
    .line 323
    const/16 v20, 0x0

    .line 324
    .line 325
    const/16 v21, 0x0

    .line 326
    .line 327
    const/16 v22, 0x0

    .line 328
    .line 329
    move-object/from16 v14, p1

    .line 330
    .line 331
    move-object/from16 v24, v1

    .line 332
    .line 333
    move-wide/from16 v16, v3

    .line 334
    .line 335
    invoke-static/range {v14 .. v26}, Ld57;->a(Lha4;Lkn6;JJFFLr50;Lq21;Lki2;II)V

    .line 336
    .line 337
    .line 338
    goto :goto_3

    .line 339
    :cond_4
    move-object/from16 v24, v1

    .line 340
    .line 341
    invoke-virtual/range {v24 .. v24}, Lki2;->b0()V

    .line 342
    .line 343
    .line 344
    :goto_3
    return-object v6

    .line 345
    :pswitch_1
    move-object/from16 v18, v8

    .line 346
    .line 347
    check-cast v18, Le52;

    .line 348
    .line 349
    check-cast v7, Ltm3;

    .line 350
    .line 351
    move-object/from16 v1, p1

    .line 352
    .line 353
    check-cast v1, Lki2;

    .line 354
    .line 355
    move-object/from16 v8, p2

    .line 356
    .line 357
    check-cast v8, Ljava/lang/Integer;

    .line 358
    .line 359
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 360
    .line 361
    .line 362
    move-result v8

    .line 363
    and-int/lit8 v12, v8, 0x3

    .line 364
    .line 365
    if-eq v12, v9, :cond_5

    .line 366
    .line 367
    move v12, v10

    .line 368
    goto :goto_4

    .line 369
    :cond_5
    move v12, v11

    .line 370
    :goto_4
    and-int/2addr v8, v10

    .line 371
    invoke-virtual {v1, v8, v12}, Lki2;->Y(IZ)Z

    .line 372
    .line 373
    .line 374
    move-result v8

    .line 375
    if-eqz v8, :cond_9

    .line 376
    .line 377
    sget-object v8, Lx87;->e:Lsw;

    .line 378
    .line 379
    sget-object v12, Ly6;->v:Ly30;

    .line 380
    .line 381
    invoke-static {v8, v12, v1, v11}, Lj01;->a(Lvw;Ly30;Lki2;I)Ll01;

    .line 382
    .line 383
    .line 384
    move-result-object v8

    .line 385
    iget-wide v12, v1, Lki2;->U:J

    .line 386
    .line 387
    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    .line 388
    .line 389
    .line 390
    move-result v12

    .line 391
    invoke-virtual {v1}, Lki2;->m()Lr95;

    .line 392
    .line 393
    .line 394
    move-result-object v13

    .line 395
    invoke-static {v1, v3}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 396
    .line 397
    .line 398
    move-result-object v14

    .line 399
    sget-object v15, Lp41;->d:Ly6;

    .line 400
    .line 401
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 402
    .line 403
    .line 404
    invoke-virtual {v1}, Lki2;->k0()V

    .line 405
    .line 406
    .line 407
    iget-boolean v15, v1, Lki2;->T:Z

    .line 408
    .line 409
    if-eqz v15, :cond_6

    .line 410
    .line 411
    invoke-virtual {v1, v2}, Lki2;->l(Lwg2;)V

    .line 412
    .line 413
    .line 414
    goto :goto_5

    .line 415
    :cond_6
    invoke-virtual {v1}, Lki2;->t0()V

    .line 416
    .line 417
    .line 418
    :goto_5
    sget-object v15, Ly6;->T:Lu31;

    .line 419
    .line 420
    invoke-static {v15, v1, v8}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 421
    .line 422
    .line 423
    sget-object v8, Ly6;->S:Lu31;

    .line 424
    .line 425
    invoke-static {v8, v1, v13}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 426
    .line 427
    .line 428
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 429
    .line 430
    .line 431
    move-result-object v12

    .line 432
    sget-object v13, Ly6;->U:Lu31;

    .line 433
    .line 434
    invoke-static {v13, v1, v12}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 435
    .line 436
    .line 437
    invoke-static {v1}, Lml6;->p(Lki2;)V

    .line 438
    .line 439
    .line 440
    sget-object v12, Ly6;->R:Lu31;

    .line 441
    .line 442
    invoke-static {v12, v1, v14}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 443
    .line 444
    .line 445
    sget-object v23, Lm01;->b:Lm01;

    .line 446
    .line 447
    invoke-static {v1}, Lh43;->U(Lki2;)Lml7;

    .line 448
    .line 449
    .line 450
    move-result-object v16

    .line 451
    sget-object v14, La28;->w:Ljava/util/WeakHashMap;

    .line 452
    .line 453
    invoke-static {v1}, Lzi6;->i(Lki2;)La28;

    .line 454
    .line 455
    .line 456
    move-result-object v14

    .line 457
    iget-object v14, v14, La28;->l:Lls7;

    .line 458
    .line 459
    new-instance v10, Lro3;

    .line 460
    .line 461
    const/16 v11, 0x1f

    .line 462
    .line 463
    invoke-direct {v10, v14, v11}, Lro3;-><init>(Lt08;I)V

    .line 464
    .line 465
    .line 466
    move-object v11, v12

    .line 467
    sget-object v12, Ljb3;->f:Lq21;

    .line 468
    .line 469
    new-instance v14, Lj;

    .line 470
    .line 471
    const/16 v9, 0xb

    .line 472
    .line 473
    invoke-direct {v14, v5, v9}, Lj;-><init>(Lwg2;B)V

    .line 474
    .line 475
    .line 476
    const v5, -0x120af9a4

    .line 477
    .line 478
    .line 479
    invoke-static {v5, v14, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 480
    .line 481
    .line 482
    move-result-object v14

    .line 483
    new-instance v30, Lou;

    .line 484
    .line 485
    iget-object v5, v0, Lbu;->k:Lqv;

    .line 486
    .line 487
    iget-object v9, v0, Lbu;->m:Lft;

    .line 488
    .line 489
    move-object/from16 v31, v5

    .line 490
    .line 491
    iget-object v5, v0, Lbu;->n:Ljava/lang/String;

    .line 492
    .line 493
    move-object/from16 v33, v5

    .line 494
    .line 495
    iget-object v5, v0, Lbu;->o:Ljava/util/Set;

    .line 496
    .line 497
    move-object/from16 v34, v5

    .line 498
    .line 499
    iget-object v5, v0, Lbu;->p:Lqv;

    .line 500
    .line 501
    move-object/from16 v35, v5

    .line 502
    .line 503
    iget-boolean v5, v0, Lbu;->q:Z

    .line 504
    .line 505
    iget-object v0, v0, Lbu;->r:Ljava/util/ArrayList;

    .line 506
    .line 507
    move-object/from16 v37, v0

    .line 508
    .line 509
    move/from16 v36, v5

    .line 510
    .line 511
    move-object/from16 v32, v9

    .line 512
    .line 513
    invoke-direct/range {v30 .. v37}, Lou;-><init>(Lqv;Lft;Ljava/lang/String;Ljava/util/Set;Lqv;ZLjava/util/ArrayList;)V

    .line 514
    .line 515
    .line 516
    move-object/from16 v0, v30

    .line 517
    .line 518
    move-object/from16 v5, v31

    .line 519
    .line 520
    const v9, -0x2e91d06d

    .line 521
    .line 522
    .line 523
    invoke-static {v9, v0, v1}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    invoke-virtual {v1, v7}, Lki2;->g(Ljava/lang/Object;)Z

    .line 528
    .line 529
    .line 530
    move-result v9

    .line 531
    move-object/from16 p0, v0

    .line 532
    .line 533
    invoke-virtual {v1}, Lki2;->T()Ljava/lang/Object;

    .line 534
    .line 535
    .line 536
    move-result-object v0

    .line 537
    if-nez v9, :cond_7

    .line 538
    .line 539
    sget-object v9, Lz41;->a:Lql0;

    .line 540
    .line 541
    if-eq v0, v9, :cond_7

    .line 542
    .line 543
    move-object/from16 p1, v13

    .line 544
    .line 545
    const/4 v13, 0x2

    .line 546
    goto :goto_6

    .line 547
    :cond_7
    new-instance v0, Li0;

    .line 548
    .line 549
    const/4 v9, 0x0

    .line 550
    move-object/from16 p1, v13

    .line 551
    .line 552
    const/4 v13, 0x2

    .line 553
    invoke-direct {v0, v7, v9, v13}, Li0;-><init>(Ltm3;Lfd1;B)V

    .line 554
    .line 555
    .line 556
    invoke-virtual {v1, v0}, Lki2;->q0(Ljava/lang/Object;)V

    .line 557
    .line 558
    .line 559
    :goto_6
    move-object/from16 v19, v0

    .line 560
    .line 561
    check-cast v19, Lhh2;

    .line 562
    .line 563
    const/16 v21, 0xd86

    .line 564
    .line 565
    const/16 v22, 0x2

    .line 566
    .line 567
    move/from16 v24, v13

    .line 568
    .line 569
    const/4 v13, 0x0

    .line 570
    move-object/from16 v20, v1

    .line 571
    .line 572
    move-object/from16 v17, v10

    .line 573
    .line 574
    move-object v0, v15

    .line 575
    move/from16 v7, v24

    .line 576
    .line 577
    move-object/from16 v15, p0

    .line 578
    .line 579
    move-object/from16 v1, p1

    .line 580
    .line 581
    invoke-static/range {v12 .. v22}, Le53;->d(Llh2;Lha4;Lq21;Lq21;Lml7;Lro3;Le52;Lhh2;Lki2;II)V

    .line 582
    .line 583
    .line 584
    move-object/from16 v9, v20

    .line 585
    .line 586
    invoke-virtual {v5}, Lqv;->f()Z

    .line 587
    .line 588
    .line 589
    move-result v20

    .line 590
    sget-object v10, Lbd0;->b:Lmj1;

    .line 591
    .line 592
    const/16 v12, 0xfa

    .line 593
    .line 594
    const/4 v13, 0x0

    .line 595
    invoke-static {v12, v13, v10, v7}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 596
    .line 597
    .line 598
    move-result-object v14

    .line 599
    const/16 v15, 0xe

    .line 600
    .line 601
    invoke-static {v14, v15}, La32;->c(Lmo7;I)Lg32;

    .line 602
    .line 603
    .line 604
    move-result-object v14

    .line 605
    invoke-static {v12, v13, v10, v7}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 606
    .line 607
    .line 608
    move-result-object v10

    .line 609
    const/4 v12, 0x0

    .line 610
    invoke-static {v10, v12, v7}, La32;->d(Lca2;FI)Lg32;

    .line 611
    .line 612
    .line 613
    move-result-object v10

    .line 614
    invoke-virtual {v14, v10}, Lg32;->a(Lg32;)Lg32;

    .line 615
    .line 616
    .line 617
    move-result-object v22

    .line 618
    sget-object v10, Lbd0;->c:Lmj1;

    .line 619
    .line 620
    const/16 v14, 0x78

    .line 621
    .line 622
    invoke-static {v14, v13, v10, v7}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 623
    .line 624
    .line 625
    move-result-object v12

    .line 626
    invoke-static {v12, v15}, La32;->i(Lmo7;I)Lz42;

    .line 627
    .line 628
    .line 629
    move-result-object v12

    .line 630
    invoke-static {v14, v13, v10, v7}, Loo0;->b0(IILjx1;I)Lmo7;

    .line 631
    .line 632
    .line 633
    move-result-object v10

    .line 634
    const/4 v14, 0x0

    .line 635
    invoke-static {v10, v14, v7}, La32;->e(Lca2;FI)Lz42;

    .line 636
    .line 637
    .line 638
    move-result-object v7

    .line 639
    invoke-virtual {v12, v7}, Lz42;->a(Lz42;)Lz42;

    .line 640
    .line 641
    .line 642
    move-result-object v7

    .line 643
    new-instance v10, Lcu;

    .line 644
    .line 645
    invoke-direct {v10, v5, v13}, Lcu;-><init>(Lqv;B)V

    .line 646
    .line 647
    .line 648
    const v12, -0x79955e4

    .line 649
    .line 650
    .line 651
    invoke-static {v12, v10, v9}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 652
    .line 653
    .line 654
    move-result-object v25

    .line 655
    const v27, 0x180006

    .line 656
    .line 657
    .line 658
    const/16 v28, 0x12

    .line 659
    .line 660
    const/16 v21, 0x0

    .line 661
    .line 662
    const/16 v24, 0x0

    .line 663
    .line 664
    move-object/from16 v26, v9

    .line 665
    .line 666
    move-object/from16 v19, v23

    .line 667
    .line 668
    move-object/from16 v23, v7

    .line 669
    .line 670
    invoke-static/range {v19 .. v28}, Lkb;->b(Lm01;ZLha4;Lg32;Lz42;Ljava/lang/String;Lq21;Lki2;II)V

    .line 671
    .line 672
    .line 673
    const/high16 v7, 0x3f800000    # 1.0f

    .line 674
    .line 675
    invoke-static {v3, v7}, Lit6;->e(Lha4;F)Lha4;

    .line 676
    .line 677
    .line 678
    move-result-object v10

    .line 679
    invoke-static {v9}, Lzi6;->i(Lki2;)La28;

    .line 680
    .line 681
    .line 682
    move-result-object v12

    .line 683
    iget-object v12, v12, La28;->l:Lls7;

    .line 684
    .line 685
    const/16 v13, 0xf

    .line 686
    .line 687
    invoke-static {v12, v13, v10}, Lx82;->h(Lls7;ILha4;)Lha4;

    .line 688
    .line 689
    .line 690
    move-result-object v14

    .line 691
    const/high16 v18, 0x41000000    # 8.0f

    .line 692
    .line 693
    const/16 v19, 0x2

    .line 694
    .line 695
    const/high16 v15, 0x41800000    # 16.0f

    .line 696
    .line 697
    const/16 v16, 0x0

    .line 698
    .line 699
    move/from16 v17, v15

    .line 700
    .line 701
    invoke-static/range {v14 .. v19}, Ljb3;->B(Lha4;FFFFI)Lha4;

    .line 702
    .line 703
    .line 704
    move-result-object v10

    .line 705
    sget-object v12, Ly6;->j:La40;

    .line 706
    .line 707
    const/4 v14, 0x0

    .line 708
    invoke-static {v12, v14}, Lxc0;->c(La40;Z)Ld14;

    .line 709
    .line 710
    .line 711
    move-result-object v12

    .line 712
    iget-wide v14, v9, Lki2;->U:J

    .line 713
    .line 714
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 715
    .line 716
    .line 717
    move-result v14

    .line 718
    invoke-virtual {v9}, Lki2;->m()Lr95;

    .line 719
    .line 720
    .line 721
    move-result-object v15

    .line 722
    invoke-static {v9, v10}, Ljj;->h0(Lki2;Lha4;)Lha4;

    .line 723
    .line 724
    .line 725
    move-result-object v10

    .line 726
    invoke-virtual {v9}, Lki2;->k0()V

    .line 727
    .line 728
    .line 729
    iget-boolean v13, v9, Lki2;->T:Z

    .line 730
    .line 731
    if-eqz v13, :cond_8

    .line 732
    .line 733
    invoke-virtual {v9, v2}, Lki2;->l(Lwg2;)V

    .line 734
    .line 735
    .line 736
    goto :goto_7

    .line 737
    :cond_8
    invoke-virtual {v9}, Lki2;->t0()V

    .line 738
    .line 739
    .line 740
    :goto_7
    invoke-static {v0, v9, v12}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 741
    .line 742
    .line 743
    invoke-static {v8, v9, v15}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 744
    .line 745
    .line 746
    invoke-static {v14, v9, v1, v9}, Lx82;->w(ILki2;Lu31;Lki2;)V

    .line 747
    .line 748
    .line 749
    invoke-static {v11, v9, v10}, Lml6;->v(Llh2;Lki2;Ljava/lang/Object;)V

    .line 750
    .line 751
    .line 752
    invoke-static {v3, v7}, Lit6;->e(Lha4;F)Lha4;

    .line 753
    .line 754
    .line 755
    move-result-object v19

    .line 756
    new-instance v0, Ldu;

    .line 757
    .line 758
    const/4 v13, 0x0

    .line 759
    invoke-direct {v0, v5, v13}, Ldu;-><init>(Lqv;B)V

    .line 760
    .line 761
    .line 762
    const v1, -0xfda9cd5

    .line 763
    .line 764
    .line 765
    invoke-static {v1, v0, v9}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    invoke-static {v0}, Lqf;->X(Ljava/lang/Object;)Ljava/util/List;

    .line 770
    .line 771
    .line 772
    move-result-object v22

    .line 773
    const/16 v24, 0xc06

    .line 774
    .line 775
    const/16 v25, 0x16

    .line 776
    .line 777
    const/16 v20, 0x0

    .line 778
    .line 779
    const/16 v21, 0x0

    .line 780
    .line 781
    move-object/from16 v23, v9

    .line 782
    .line 783
    invoke-static/range {v19 .. v25}, Lk04;->d(Lha4;Ljava/lang/String;Lq21;Ljava/util/List;Lki2;II)V

    .line 784
    .line 785
    .line 786
    const/4 v0, 0x1

    .line 787
    invoke-virtual {v9, v0}, Lki2;->r(Z)V

    .line 788
    .line 789
    .line 790
    invoke-virtual {v5}, Lqv;->d()I

    .line 791
    .line 792
    .line 793
    move-result v19

    .line 794
    invoke-static {v3, v7}, Lit6;->e(Lha4;F)Lha4;

    .line 795
    .line 796
    .line 797
    move-result-object v0

    .line 798
    invoke-static {v9}, Lzi6;->i(Lki2;)La28;

    .line 799
    .line 800
    .line 801
    move-result-object v1

    .line 802
    iget-object v1, v1, La28;->l:Lls7;

    .line 803
    .line 804
    const/16 v2, 0xf

    .line 805
    .line 806
    invoke-static {v1, v2, v0}, Lx82;->h(Lls7;ILha4;)Lha4;

    .line 807
    .line 808
    .line 809
    move-result-object v20

    .line 810
    new-instance v0, Leu;

    .line 811
    .line 812
    invoke-direct {v0, v4, v5}, Leu;-><init>(Ljava/util/List;Lqv;)V

    .line 813
    .line 814
    .line 815
    const v1, 0x39c5677e

    .line 816
    .line 817
    .line 818
    invoke-static {v1, v0, v9}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 819
    .line 820
    .line 821
    move-result-object v27

    .line 822
    const v29, 0x180180

    .line 823
    .line 824
    .line 825
    const-wide/16 v21, 0x0

    .line 826
    .line 827
    const-wide/16 v23, 0x0

    .line 828
    .line 829
    const/16 v25, 0x0

    .line 830
    .line 831
    const/16 v26, 0x0

    .line 832
    .line 833
    move-object/from16 v28, v9

    .line 834
    .line 835
    invoke-static/range {v19 .. v29}, Lsi6;->g(ILha4;JJLq21;Lq21;Lq21;Lki2;I)V

    .line 836
    .line 837
    .line 838
    const/4 v0, 0x1

    .line 839
    invoke-virtual {v9, v0}, Lki2;->r(Z)V

    .line 840
    .line 841
    .line 842
    goto :goto_8

    .line 843
    :cond_9
    move-object v9, v1

    .line 844
    invoke-virtual {v9}, Lki2;->b0()V

    .line 845
    .line 846
    .line 847
    :goto_8
    return-object v6

    .line 848
    nop

    .line 849
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
