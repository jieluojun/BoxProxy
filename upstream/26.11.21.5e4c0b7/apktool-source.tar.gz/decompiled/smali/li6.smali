.class public final synthetic Lli6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lmi6;


# direct methods
.method public synthetic constructor <init>(Lmi6;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lli6;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lli6;->i:Lmi6;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-byte v0, p0, Lli6;->h:B

    .line 2
    .line 3
    iget-object p0, p0, Lli6;->i:Lmi6;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Lmi6;->d:Lvh7;

    .line 9
    .line 10
    iget-object p0, p0, Lvh7;->i:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p0, Lhs4;

    .line 13
    .line 14
    return-object p0

    .line 15
    :pswitch_0
    iget-object p0, p0, Lmi6;->d:Lvh7;

    .line 16
    .line 17
    iget-object p0, p0, Lvh7;->k:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Lql3;

    .line 20
    .line 21
    return-object p0

    .line 22
    :pswitch_1
    iget-object p0, p0, Lmi6;->d:Lvh7;

    .line 23
    .line 24
    iget-object p0, p0, Lvh7;->j:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p0, Lse7;

    .line 27
    .line 28
    return-object p0

    .line 29
    :pswitch_2
    iget-object p0, p0, Lmi6;->d:Lvh7;

    .line 30
    .line 31
    iget-object p0, p0, Lvh7;->i:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p0, Lhs4;

    .line 34
    .line 35
    return-object p0

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
