.class public final synthetic Lif1;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/String;

.field public final synthetic j:Z


# direct methods
.method public synthetic constructor <init>(BLjava/lang/String;Z)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lif1;->h:B

    .line 2
    .line 3
    iput-object p2, p0, Lif1;->i:Ljava/lang/String;

    .line 4
    .line 5
    iput-boolean p3, p0, Lif1;->j:Z

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 33

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lif1;->h:B

    .line 4
    .line 5
    const/high16 v2, 0x41800000    # 16.0f

    .line 6
    .line 7
    const/high16 v3, 0x41900000    # 18.0f

    .line 8
    .line 9
    sget-object v4, Lea4;->h:Lea4;

    .line 10
    .line 11
    sget-object v5, Los7;->a:Los7;

    .line 12
    .line 13
    const/16 v6, 0x10

    .line 14
    .line 15
    const/4 v7, 0x0

    .line 16
    const/4 v8, 0x1

    .line 17
    iget-boolean v9, v0, Lif1;->j:Z

    .line 18
    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    move-object/from16 v1, p1

    .line 23
    .line 24
    check-cast v1, Lm01;

    .line 25
    .line 26
    move-object/from16 v10, p2

    .line 27
    .line 28
    check-cast v10, Lki2;

    .line 29
    .line 30
    move-object/from16 v11, p3

    .line 31
    .line 32
    check-cast v11, Ljava/lang/Integer;

    .line 33
    .line 34
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 35
    .line 36
    .line 37
    move-result v11

    .line 38
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    and-int/lit8 v1, v11, 0x11

    .line 42
    .line 43
    if-eq v1, v6, :cond_0

    .line 44
    .line 45
    move v1, v8

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    move v1, v7

    .line 48
    :goto_0
    and-int/2addr v11, v8

    .line 49
    invoke-virtual {v10, v11, v1}, Lki2;->Y(IZ)Z

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    if-eqz v1, :cond_2

    .line 54
    .line 55
    invoke-static {v4, v3, v2}, Ljb3;->y(Lha4;FF)Lha4;

    .line 56
    .line 57
    .line 58
    move-result-object v11

    .line 59
    if-eqz v9, :cond_1

    .line 60
    .line 61
    const v1, 0x2cb8ad89

    .line 62
    .line 63
    .line 64
    invoke-virtual {v10, v1}, Lki2;->h0(I)V

    .line 65
    .line 66
    .line 67
    sget-object v1, Lsz0;->a:Lcx1;

    .line 68
    .line 69
    invoke-virtual {v10, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    check-cast v1, Lrz0;

    .line 74
    .line 75
    invoke-virtual {v1}, Lrz0;->f()J

    .line 76
    .line 77
    .line 78
    move-result-wide v1

    .line 79
    invoke-virtual {v10, v7}, Lki2;->r(Z)V

    .line 80
    .line 81
    .line 82
    :goto_1
    move-wide v12, v1

    .line 83
    goto :goto_2

    .line 84
    :cond_1
    const v1, 0x2cb9af77

    .line 85
    .line 86
    .line 87
    invoke-virtual {v10, v1}, Lki2;->h0(I)V

    .line 88
    .line 89
    .line 90
    sget-object v1, Lsz0;->a:Lcx1;

    .line 91
    .line 92
    invoke-virtual {v10, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    check-cast v1, Lrz0;

    .line 97
    .line 98
    invoke-virtual {v1}, Lrz0;->n()J

    .line 99
    .line 100
    .line 101
    move-result-wide v1

    .line 102
    invoke-virtual {v10, v7}, Lki2;->r(Z)V

    .line 103
    .line 104
    .line 105
    goto :goto_1

    .line 106
    :goto_2
    const/16 v31, 0x0

    .line 107
    .line 108
    const v32, 0x3fff8

    .line 109
    .line 110
    .line 111
    move-object/from16 v29, v10

    .line 112
    .line 113
    iget-object v10, v0, Lif1;->i:Ljava/lang/String;

    .line 114
    .line 115
    const-wide/16 v14, 0x0

    .line 116
    .line 117
    const/16 v16, 0x0

    .line 118
    .line 119
    const/16 v17, 0x0

    .line 120
    .line 121
    const-wide/16 v18, 0x0

    .line 122
    .line 123
    const/16 v20, 0x0

    .line 124
    .line 125
    const-wide/16 v21, 0x0

    .line 126
    .line 127
    const/16 v23, 0x0

    .line 128
    .line 129
    const/16 v24, 0x0

    .line 130
    .line 131
    const/16 v25, 0x0

    .line 132
    .line 133
    const/16 v26, 0x0

    .line 134
    .line 135
    const/16 v27, 0x0

    .line 136
    .line 137
    const/16 v28, 0x0

    .line 138
    .line 139
    const/16 v30, 0x30

    .line 140
    .line 141
    invoke-static/range {v10 .. v32}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 142
    .line 143
    .line 144
    goto :goto_3

    .line 145
    :cond_2
    move-object/from16 v29, v10

    .line 146
    .line 147
    invoke-virtual/range {v29 .. v29}, Lki2;->b0()V

    .line 148
    .line 149
    .line 150
    :goto_3
    return-object v5

    .line 151
    :pswitch_0
    move-object/from16 v1, p1

    .line 152
    .line 153
    check-cast v1, Lm01;

    .line 154
    .line 155
    move-object/from16 v10, p2

    .line 156
    .line 157
    check-cast v10, Lki2;

    .line 158
    .line 159
    move-object/from16 v11, p3

    .line 160
    .line 161
    check-cast v11, Ljava/lang/Integer;

    .line 162
    .line 163
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 164
    .line 165
    .line 166
    move-result v11

    .line 167
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    and-int/lit8 v1, v11, 0x11

    .line 171
    .line 172
    if-eq v1, v6, :cond_3

    .line 173
    .line 174
    move v1, v8

    .line 175
    goto :goto_4

    .line 176
    :cond_3
    move v1, v7

    .line 177
    :goto_4
    and-int/2addr v11, v8

    .line 178
    invoke-virtual {v10, v11, v1}, Lki2;->Y(IZ)Z

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    if-eqz v1, :cond_5

    .line 183
    .line 184
    invoke-static {v4, v3, v2}, Ljb3;->y(Lha4;FF)Lha4;

    .line 185
    .line 186
    .line 187
    move-result-object v11

    .line 188
    if-eqz v9, :cond_4

    .line 189
    .line 190
    const v1, 0x709858ca

    .line 191
    .line 192
    .line 193
    invoke-virtual {v10, v1}, Lki2;->h0(I)V

    .line 194
    .line 195
    .line 196
    sget-object v1, Lsz0;->a:Lcx1;

    .line 197
    .line 198
    invoke-virtual {v10, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    check-cast v1, Lrz0;

    .line 203
    .line 204
    invoke-virtual {v1}, Lrz0;->f()J

    .line 205
    .line 206
    .line 207
    move-result-wide v1

    .line 208
    invoke-virtual {v10, v7}, Lki2;->r(Z)V

    .line 209
    .line 210
    .line 211
    :goto_5
    move-wide v12, v1

    .line 212
    goto :goto_6

    .line 213
    :cond_4
    const v1, 0x70995ab8

    .line 214
    .line 215
    .line 216
    invoke-virtual {v10, v1}, Lki2;->h0(I)V

    .line 217
    .line 218
    .line 219
    sget-object v1, Lsz0;->a:Lcx1;

    .line 220
    .line 221
    invoke-virtual {v10, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v1

    .line 225
    check-cast v1, Lrz0;

    .line 226
    .line 227
    invoke-virtual {v1}, Lrz0;->n()J

    .line 228
    .line 229
    .line 230
    move-result-wide v1

    .line 231
    invoke-virtual {v10, v7}, Lki2;->r(Z)V

    .line 232
    .line 233
    .line 234
    goto :goto_5

    .line 235
    :goto_6
    const/16 v31, 0x0

    .line 236
    .line 237
    const v32, 0x3fff8

    .line 238
    .line 239
    .line 240
    move-object/from16 v29, v10

    .line 241
    .line 242
    iget-object v10, v0, Lif1;->i:Ljava/lang/String;

    .line 243
    .line 244
    const-wide/16 v14, 0x0

    .line 245
    .line 246
    const/16 v16, 0x0

    .line 247
    .line 248
    const/16 v17, 0x0

    .line 249
    .line 250
    const-wide/16 v18, 0x0

    .line 251
    .line 252
    const/16 v20, 0x0

    .line 253
    .line 254
    const-wide/16 v21, 0x0

    .line 255
    .line 256
    const/16 v23, 0x0

    .line 257
    .line 258
    const/16 v24, 0x0

    .line 259
    .line 260
    const/16 v25, 0x0

    .line 261
    .line 262
    const/16 v26, 0x0

    .line 263
    .line 264
    const/16 v27, 0x0

    .line 265
    .line 266
    const/16 v28, 0x0

    .line 267
    .line 268
    const/16 v30, 0x30

    .line 269
    .line 270
    invoke-static/range {v10 .. v32}, Lpk6;->d(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILhh2;Lwg7;Lki2;III)V

    .line 271
    .line 272
    .line 273
    goto :goto_7

    .line 274
    :cond_5
    move-object/from16 v29, v10

    .line 275
    .line 276
    invoke-virtual/range {v29 .. v29}, Lki2;->b0()V

    .line 277
    .line 278
    .line 279
    :goto_7
    return-object v5

    .line 280
    :pswitch_1
    move-object/from16 v1, p1

    .line 281
    .line 282
    check-cast v1, Lj16;

    .line 283
    .line 284
    move-object/from16 v2, p2

    .line 285
    .line 286
    check-cast v2, Lki2;

    .line 287
    .line 288
    move-object/from16 v3, p3

    .line 289
    .line 290
    check-cast v3, Ljava/lang/Integer;

    .line 291
    .line 292
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 293
    .line 294
    .line 295
    move-result v3

    .line 296
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 297
    .line 298
    .line 299
    and-int/lit8 v1, v3, 0x11

    .line 300
    .line 301
    if-eq v1, v6, :cond_6

    .line 302
    .line 303
    move v1, v8

    .line 304
    goto :goto_8

    .line 305
    :cond_6
    move v1, v7

    .line 306
    :goto_8
    and-int/2addr v3, v8

    .line 307
    invoke-virtual {v2, v3, v1}, Lki2;->Y(IZ)Z

    .line 308
    .line 309
    .line 310
    move-result v1

    .line 311
    if-eqz v1, :cond_8

    .line 312
    .line 313
    if-eqz v9, :cond_7

    .line 314
    .line 315
    const v1, -0x533a0da

    .line 316
    .line 317
    .line 318
    invoke-virtual {v2, v1}, Lki2;->h0(I)V

    .line 319
    .line 320
    .line 321
    sget-object v1, Lq04;->b:Lcx1;

    .line 322
    .line 323
    invoke-virtual {v2, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    move-result-object v1

    .line 327
    check-cast v1, Ln04;

    .line 328
    .line 329
    iget-object v1, v1, Ln04;->a:Lky0;

    .line 330
    .line 331
    iget-wide v3, v1, Lky0;->w:J

    .line 332
    .line 333
    :goto_9
    invoke-virtual {v2, v7}, Lki2;->r(Z)V

    .line 334
    .line 335
    .line 336
    move-wide v12, v3

    .line 337
    goto :goto_a

    .line 338
    :cond_7
    const v1, -0x5339c38

    .line 339
    .line 340
    .line 341
    invoke-virtual {v2, v1}, Lki2;->h0(I)V

    .line 342
    .line 343
    .line 344
    sget-object v1, Lq04;->b:Lcx1;

    .line 345
    .line 346
    invoke-virtual {v2, v1}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 347
    .line 348
    .line 349
    move-result-object v1

    .line 350
    check-cast v1, Ln04;

    .line 351
    .line 352
    iget-object v1, v1, Ln04;->a:Lky0;

    .line 353
    .line 354
    iget-wide v3, v1, Lky0;->a:J

    .line 355
    .line 356
    goto :goto_9

    .line 357
    :goto_a
    const/16 v30, 0x0

    .line 358
    .line 359
    const v31, 0x3fffa

    .line 360
    .line 361
    .line 362
    iget-object v10, v0, Lif1;->i:Ljava/lang/String;

    .line 363
    .line 364
    const/4 v11, 0x0

    .line 365
    const-wide/16 v14, 0x0

    .line 366
    .line 367
    const/16 v16, 0x0

    .line 368
    .line 369
    const/16 v17, 0x0

    .line 370
    .line 371
    const-wide/16 v18, 0x0

    .line 372
    .line 373
    const/16 v20, 0x0

    .line 374
    .line 375
    const-wide/16 v21, 0x0

    .line 376
    .line 377
    const/16 v23, 0x0

    .line 378
    .line 379
    const/16 v24, 0x0

    .line 380
    .line 381
    const/16 v25, 0x0

    .line 382
    .line 383
    const/16 v26, 0x0

    .line 384
    .line 385
    const/16 v27, 0x0

    .line 386
    .line 387
    const/16 v29, 0x0

    .line 388
    .line 389
    move-object/from16 v28, v2

    .line 390
    .line 391
    invoke-static/range {v10 .. v31}, Loe7;->b(Ljava/lang/String;Lha4;JJLsf2;Lre2;JLd97;JIZIILwg7;Lki2;III)V

    .line 392
    .line 393
    .line 394
    goto :goto_b

    .line 395
    :cond_8
    move-object/from16 v28, v2

    .line 396
    .line 397
    invoke-virtual/range {v28 .. v28}, Lki2;->b0()V

    .line 398
    .line 399
    .line 400
    :goto_b
    return-object v5

    .line 401
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
