.class public final Luo2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lsn7;


# direct methods
.method public synthetic constructor <init>(Lsn7;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Luo2;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Luo2;->i:Lsn7;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-byte v0, p0, Luo2;->h:B

    .line 2
    .line 3
    iget-object p0, p0, Luo2;->i:Lsn7;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :pswitch_0
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 14
    .line 15
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :pswitch_1
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0

    .line 25
    :pswitch_2
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 26
    .line 27
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0

    .line 32
    :pswitch_3
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    return-object p0

    .line 37
    :pswitch_4
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 38
    .line 39
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0

    .line 44
    :pswitch_5
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    return-object p0

    .line 49
    :pswitch_6
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 50
    .line 51
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    :pswitch_7
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    return-object p0

    .line 61
    :pswitch_8
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 62
    .line 63
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    return-object p0

    .line 68
    :pswitch_9
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 69
    .line 70
    .line 71
    move-result-object p0

    .line 72
    return-object p0

    .line 73
    :pswitch_a
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 74
    .line 75
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    return-object p0

    .line 80
    :pswitch_b
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 81
    .line 82
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    return-object p0

    .line 87
    :pswitch_c
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    return-object p0

    .line 92
    :pswitch_d
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 93
    .line 94
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    return-object p0

    .line 99
    :pswitch_e
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 100
    .line 101
    .line 102
    move-result-object p0

    .line 103
    return-object p0

    .line 104
    :pswitch_f
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 105
    .line 106
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    return-object p0

    .line 111
    :pswitch_10
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    return-object p0

    .line 116
    :pswitch_11
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 117
    .line 118
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    return-object p0

    .line 123
    :pswitch_12
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    return-object p0

    .line 128
    :pswitch_13
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 129
    .line 130
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object p0

    .line 134
    return-object p0

    .line 135
    :pswitch_14
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 136
    .line 137
    .line 138
    move-result-object p0

    .line 139
    return-object p0

    .line 140
    :pswitch_15
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 141
    .line 142
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object p0

    .line 146
    return-object p0

    .line 147
    :pswitch_16
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    return-object p0

    .line 152
    :pswitch_17
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 153
    .line 154
    .line 155
    move-result-object p0

    .line 156
    return-object p0

    .line 157
    :pswitch_18
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 158
    .line 159
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object p0

    .line 163
    return-object p0

    .line 164
    :pswitch_19
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 165
    .line 166
    .line 167
    move-result-object p0

    .line 168
    return-object p0

    .line 169
    :pswitch_1a
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 170
    .line 171
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object p0

    .line 175
    return-object p0

    .line 176
    :pswitch_1b
    invoke-virtual {p0}, Lrn7;->f()Lnn7;

    .line 177
    .line 178
    .line 179
    move-result-object p0

    .line 180
    return-object p0

    .line 181
    :pswitch_1c
    iget-object p0, p0, Lrn7;->c:Lf75;

    .line 182
    .line 183
    invoke-virtual {p0}, Lf75;->getValue()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    return-object p0

    .line 188
    nop

    .line 189
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
