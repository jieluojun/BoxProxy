.class public final Lvx5;
.super Lj53;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public A:F

.field public B:F

.field public C:Landroid/graphics/Shader$TileMode;

.field public D:Ljava/util/List;

.field public E:Ljava/util/List;

.field public final e:Ltp2;

.field public f:Ljj;

.field public g:[F

.field public h:[I

.field public i:Ljj;

.field public j:[I

.field public k:[F

.field public l:Landroid/graphics/Shader;

.field public m:I

.field public n:Landroid/graphics/Bitmap;

.field public o:[I

.field public final p:[F

.field public q:I

.field public r:I

.field public s:F

.field public t:F

.field public u:I

.field public v:I

.field public w:F

.field public x:F

.field public y:F

.field public z:F


# direct methods
.method public constructor <init>(Ltp2;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvx5;->e:Ltp2;

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    new-array v0, p1, [F

    .line 8
    .line 9
    iput-object v0, p0, Lvx5;->g:[F

    .line 10
    .line 11
    new-array v0, p1, [I

    .line 12
    .line 13
    iput-object v0, p0, Lvx5;->h:[I

    .line 14
    .line 15
    new-array v0, p1, [I

    .line 16
    .line 17
    iput-object v0, p0, Lvx5;->j:[I

    .line 18
    .line 19
    new-array v0, p1, [F

    .line 20
    .line 21
    iput-object v0, p0, Lvx5;->k:[F

    .line 22
    .line 23
    const/4 v0, -0x1

    .line 24
    iput v0, p0, Lvx5;->m:I

    .line 25
    .line 26
    new-array p1, p1, [I

    .line 27
    .line 28
    iput-object p1, p0, Lvx5;->o:[I

    .line 29
    .line 30
    const/16 p1, 0x9

    .line 31
    .line 32
    new-array p1, p1, [F

    .line 33
    .line 34
    iput-object p1, p0, Lvx5;->p:[F

    .line 35
    .line 36
    sget-object p1, Lw12;->h:Lw12;

    .line 37
    .line 38
    iput-object p1, p0, Lvx5;->E:Ljava/util/List;

    .line 39
    .line 40
    return-void
.end method
