.class public interface abstract Lwf6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# virtual methods
.method public abstract a(F)F
.end method
