.class public final Lo40;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lxs6;


# virtual methods
.method public final a()Ljj7;
    .locals 0

    .line 1
    sget-object p0, Ljj7;->d:Lij7;

    .line 2
    .line 3
    return-object p0
.end method

.method public final close()V
    .locals 0

    .line 1
    return-void
.end method

.method public final d(Lhg0;J)V
    .locals 0

    .line 1
    invoke-virtual {p1, p2, p3}, Lhg0;->H(J)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final flush()V
    .locals 0

    .line 1
    return-void
.end method
