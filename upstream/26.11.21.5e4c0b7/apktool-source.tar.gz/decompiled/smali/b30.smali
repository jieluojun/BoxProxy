.class public abstract Lb30;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final a:Lle4;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lle4;

    .line 2
    .line 3
    invoke-direct {v0}, Lle4;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lb30;->a:Lle4;

    .line 7
    .line 8
    return-void
.end method
