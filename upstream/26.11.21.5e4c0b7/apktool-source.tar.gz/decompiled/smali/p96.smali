.class public final synthetic Lp96;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lmb6;

.field public final synthetic j:Ls86;

.field public final synthetic k:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lmb6;Ls86;Landroid/content/Context;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lp96;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lp96;->i:Lmb6;

    .line 4
    .line 5
    iput-object p2, p0, Lp96;->j:Ls86;

    .line 6
    .line 7
    iput-object p3, p0, Lp96;->k:Landroid/content/Context;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lp96;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v3, p0, Lp96;->k:Landroid/content/Context;

    .line 7
    .line 8
    iget-object v4, p0, Lp96;->j:Ls86;

    .line 9
    .line 10
    iget-object p0, p0, Lp96;->i:Lmb6;

    .line 11
    .line 12
    check-cast p1, Lva6;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, v2}, Lmb6;->g(Lva6;)V

    .line 21
    .line 22
    .line 23
    invoke-static {v4, p1, v3}, Ls86;->b(Ls86;Lva6;Landroid/content/Context;)V

    .line 24
    .line 25
    .line 26
    return-object v1

    .line 27
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0, v2}, Lmb6;->g(Lva6;)V

    .line 31
    .line 32
    .line 33
    invoke-static {v4, p1, v3}, Ls86;->b(Ls86;Lva6;Landroid/content/Context;)V

    .line 34
    .line 35
    .line 36
    return-object v1

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
