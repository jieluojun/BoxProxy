.class public final Le11;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lix4;

.field public final b:[Lq16;


# direct methods
.method public constructor <init>(Ljava/util/List;[Lq16;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Le11;->b:[Lq16;

    .line 5
    .line 6
    sget-boolean p2, Lnx4;->a:Z

    .line 7
    .line 8
    if-eqz p2, :cond_0

    .line 9
    .line 10
    new-instance p2, Lm5;

    .line 11
    .line 12
    invoke-direct {p2, p1}, Lm5;-><init>(Ljava/util/List;)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p2, Lux7;

    .line 17
    .line 18
    const/16 v0, 0x19

    .line 19
    .line 20
    invoke-direct {p2, p1, v0}, Lux7;-><init>(Ljava/util/List;B)V

    .line 21
    .line 22
    .line 23
    :goto_0
    iput-object p2, p0, Le11;->a:Lix4;

    .line 24
    .line 25
    return-void
.end method
