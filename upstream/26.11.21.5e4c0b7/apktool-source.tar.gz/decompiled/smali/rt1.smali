.class public final Lrt1;
.super Lst1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:J

.field public final b:Z


# direct methods
.method public constructor <init>(JZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lrt1;->a:J

    .line 5
    .line 6
    iput-boolean p3, p0, Lrt1;->b:Z

    .line 7
    .line 8
    return-void
.end method
