.class public final Ljy5;
.super Lky5;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final synthetic i:Lr14;

.field public final synthetic j:J

.field public final synthetic k:Lhg0;


# direct methods
.method public constructor <init>(Lr14;JLhg0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ljy5;->i:Lr14;

    .line 5
    .line 6
    iput-wide p2, p0, Ljy5;->j:J

    .line 7
    .line 8
    iput-object p4, p0, Ljy5;->k:Lhg0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final B()Ltg0;
    .locals 0

    .line 1
    iget-object p0, p0, Ljy5;->k:Lhg0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()J
    .locals 2

    .line 1
    iget-wide v0, p0, Ljy5;->j:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final e()Lr14;
    .locals 0

    .line 1
    iget-object p0, p0, Ljy5;->i:Lr14;

    .line 2
    .line 3
    return-object p0
.end method
