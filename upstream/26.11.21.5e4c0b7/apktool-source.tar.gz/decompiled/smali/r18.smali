.class public Lr18;
.super Lq18;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final x:Lw18;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    invoke-static {}, Lz08;->f()Landroid/view/WindowInsets;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {v0, v1}, Lw18;->c(Landroid/view/WindowInsets;Landroid/view/View;)Lw18;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lr18;->x:Lw18;

    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>(Lw18;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lq18;-><init>(Lw18;Landroid/view/WindowInsets;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public constructor <init>(Lw18;Lr18;)V
    .locals 0

    .line 5
    invoke-direct {p0, p1, p2}, Lq18;-><init>(Lw18;Lq18;)V

    return-void
.end method


# virtual methods
.method public i(I)Lj83;
    .locals 0

    .line 1
    iget-object p0, p0, Ll18;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-static {p1}, Lv18;->a(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-static {p0, p1}, Lz08;->q(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    invoke-static {p0}, Lj83;->c(Landroid/graphics/Insets;)Lj83;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method

.method public j(I)Lj83;
    .locals 0

    .line 1
    iget-object p0, p0, Ll18;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-static {p1}, Lv18;->a(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-static {p0, p1}, Lz08;->d(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    invoke-static {p0}, Lj83;->c(Landroid/graphics/Insets;)Lj83;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method

.method public p(Landroid/view/View;)V
    .locals 0

    .line 1
    return-void
.end method

.method public u(I)Z
    .locals 0

    .line 1
    iget-object p0, p0, Ll18;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-static {p1}, Lv18;->a(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-static {p0, p1}, Lz08;->n(Landroid/view/WindowInsets;I)Z

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method
