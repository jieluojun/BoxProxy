.class public final synthetic Lx2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lx2;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lx2;->i:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 50

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-byte v2, v0, Lx2;->h:B

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const-string v4, "blocked_interfaces"

    .line 9
    .line 10
    const-string v5, "id = 1"

    .line 11
    .line 12
    const/4 v6, 0x3

    .line 13
    const/4 v7, 0x0

    .line 14
    const/4 v8, 0x1

    .line 15
    const/4 v9, 0x0

    .line 16
    sget-object v10, Los7;->a:Los7;

    .line 17
    .line 18
    iget-object v0, v0, Lx2;->i:Ljava/lang/Object;

    .line 19
    .line 20
    packed-switch v2, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    check-cast v0, Lyw0;

    .line 24
    .line 25
    move-object v2, v1

    .line 26
    check-cast v2, Lsd0;

    .line 27
    .line 28
    iget-boolean v0, v0, Lyw0;->a:Z

    .line 29
    .line 30
    const/16 v25, 0x0

    .line 31
    .line 32
    const v26, 0x5fffff

    .line 33
    .line 34
    .line 35
    const/4 v3, 0x0

    .line 36
    const/4 v4, 0x0

    .line 37
    const/4 v5, 0x0

    .line 38
    const/4 v6, 0x0

    .line 39
    const/4 v7, 0x0

    .line 40
    const/4 v8, 0x0

    .line 41
    const/4 v9, 0x0

    .line 42
    const/4 v10, 0x0

    .line 43
    const/4 v11, 0x0

    .line 44
    const/4 v12, 0x0

    .line 45
    const/4 v13, 0x0

    .line 46
    const/4 v14, 0x0

    .line 47
    const/4 v15, 0x0

    .line 48
    const/16 v16, 0x0

    .line 49
    .line 50
    const/16 v17, 0x0

    .line 51
    .line 52
    const/16 v18, 0x0

    .line 53
    .line 54
    const/16 v19, 0x0

    .line 55
    .line 56
    const/16 v20, 0x0

    .line 57
    .line 58
    const/16 v21, 0x0

    .line 59
    .line 60
    const/16 v22, 0x0

    .line 61
    .line 62
    const/16 v23, 0x0

    .line 63
    .line 64
    move/from16 v24, v0

    .line 65
    .line 66
    invoke-static/range {v2 .. v26}, Lsd0;->a(Lsd0;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZLjava/lang/String;ZLjava/lang/String;ZLjava/lang/String;ZLjava/lang/String;ZZI)Lsd0;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    return-object v0

    .line 71
    :pswitch_0
    check-cast v0, Lnk6;

    .line 72
    .line 73
    check-cast v1, Lxn7;

    .line 74
    .line 75
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 76
    .line 77
    .line 78
    check-cast v1, Li75;

    .line 79
    .line 80
    iput-boolean v8, v1, Li75;->w:Z

    .line 81
    .line 82
    iget-object v2, v1, Li75;->v:Lbg;

    .line 83
    .line 84
    invoke-virtual {v2, v0}, Lbg;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    invoke-static {v1}, Lck6;->m(Lbk6;)V

    .line 88
    .line 89
    .line 90
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 91
    .line 92
    return-object v0

    .line 93
    :pswitch_1
    check-cast v0, Lmf0;

    .line 94
    .line 95
    check-cast v1, Lsu5;

    .line 96
    .line 97
    iget-boolean v2, v0, Lga4;->u:Z

    .line 98
    .line 99
    if-eqz v2, :cond_0

    .line 100
    .line 101
    invoke-virtual {v0}, Lga4;->u1()Lri1;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    new-instance v3, Lo2;

    .line 106
    .line 107
    const/16 v4, 0xe

    .line 108
    .line 109
    invoke-direct {v3, v0, v1, v9, v4}, Lo2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lfd1;B)V

    .line 110
    .line 111
    .line 112
    invoke-static {v2, v9, v9, v3, v6}, Ljj;->e0(Lri1;Le3;Lui1;Llh2;I)Lky6;

    .line 113
    .line 114
    .line 115
    :cond_0
    return-object v10

    .line 116
    :pswitch_2
    check-cast v0, Lsd0;

    .line 117
    .line 118
    check-cast v1, Landroid/database/sqlite/SQLiteDatabase;

    .line 119
    .line 120
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 121
    .line 122
    .line 123
    sget-object v2, Luc0;->a:Luc0;

    .line 124
    .line 125
    invoke-static {v1}, Luc0;->e(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v2, v1}, Luc0;->d(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 132
    .line 133
    .line 134
    :try_start_0
    invoke-static {v1, v0}, Lfi;->k0(Landroid/database/sqlite/SQLiteDatabase;Lsd0;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 138
    .line 139
    .line 140
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 141
    .line 142
    .line 143
    return-object v10

    .line 144
    :catchall_0
    move-exception v0

    .line 145
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 146
    .line 147
    .line 148
    throw v0

    .line 149
    :pswitch_3
    check-cast v0, Lgp6;

    .line 150
    .line 151
    check-cast v1, Landroid/database/sqlite/SQLiteDatabase;

    .line 152
    .line 153
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 154
    .line 155
    .line 156
    sget-object v2, Luc0;->a:Luc0;

    .line 157
    .line 158
    invoke-static {v1}, Luc0;->e(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v2, v1}, Luc0;->d(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 165
    .line 166
    .line 167
    :try_start_1
    const-string v2, "shared_network_settings"

    .line 168
    .line 169
    new-instance v3, Landroid/content/ContentValues;

    .line 170
    .line 171
    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    .line 172
    .line 173
    .line 174
    const-string v6, "mac_filter"

    .line 175
    .line 176
    iget-boolean v7, v0, Lgp6;->a:Z

    .line 177
    .line 178
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 179
    .line 180
    .line 181
    move-result-object v7

    .line 182
    invoke-virtual {v3, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 183
    .line 184
    .line 185
    const-string v6, "mac_mode"

    .line 186
    .line 187
    iget-object v7, v0, Lgp6;->b:Ljava/lang/String;

    .line 188
    .line 189
    invoke-virtual {v3, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v1, v2, v3, v5, v9}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    .line 193
    .line 194
    .line 195
    const-string v2, "shared_network_interfaces"

    .line 196
    .line 197
    iget-object v3, v0, Lgp6;->c:Ljava/util/List;

    .line 198
    .line 199
    invoke-static {v1, v2, v3}, Luc0;->n(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/util/List;)V

    .line 200
    .line 201
    .line 202
    iget-object v2, v0, Lgp6;->d:Ljava/util/List;

    .line 203
    .line 204
    invoke-static {v1, v4, v2}, Luc0;->n(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/util/List;)V

    .line 205
    .line 206
    .line 207
    const-string v2, "shared_network_macs"

    .line 208
    .line 209
    iget-object v0, v0, Lgp6;->e:Ljava/util/List;

    .line 210
    .line 211
    invoke-static {v1, v2, v0}, Luc0;->n(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/util/List;)V

    .line 212
    .line 213
    .line 214
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 215
    .line 216
    .line 217
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 218
    .line 219
    .line 220
    return-object v10

    .line 221
    :catchall_1
    move-exception v0

    .line 222
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 223
    .line 224
    .line 225
    throw v0

    .line 226
    :pswitch_4
    check-cast v0, Lsi0;

    .line 227
    .line 228
    check-cast v1, Landroid/database/sqlite/SQLiteDatabase;

    .line 229
    .line 230
    const-string v2, "initialized"

    .line 231
    .line 232
    const-string v3, "id"

    .line 233
    .line 234
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 235
    .line 236
    .line 237
    move-result-object v5

    .line 238
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 239
    .line 240
    .line 241
    sget-object v6, Luc0;->a:Luc0;

    .line 242
    .line 243
    invoke-static {v1}, Luc0;->e(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {v6, v1}, Luc0;->d(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 247
    .line 248
    .line 249
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 250
    .line 251
    .line 252
    :try_start_2
    const-string v6, "intranet_bypass_settings"

    .line 253
    .line 254
    new-instance v7, Landroid/content/ContentValues;

    .line 255
    .line 256
    invoke-direct {v7}, Landroid/content/ContentValues;-><init>()V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v7, v3, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 260
    .line 261
    .line 262
    invoke-virtual {v7, v2, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 263
    .line 264
    .line 265
    const/4 v8, 0x5

    .line 266
    invoke-virtual {v1, v6, v9, v7, v8}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 267
    .line 268
    .line 269
    const-string v6, "shared_network_interface_settings"

    .line 270
    .line 271
    new-instance v7, Landroid/content/ContentValues;

    .line 272
    .line 273
    invoke-direct {v7}, Landroid/content/ContentValues;-><init>()V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v7, v3, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 277
    .line 278
    .line 279
    invoke-virtual {v7, v2, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {v1, v6, v9, v7, v8}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 283
    .line 284
    .line 285
    const-string v2, "intranet_ipv4_cidrs"

    .line 286
    .line 287
    iget-object v3, v0, Lsi0;->a:Ljava/util/List;

    .line 288
    .line 289
    invoke-static {v1, v2, v3}, Luc0;->n(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/util/List;)V

    .line 290
    .line 291
    .line 292
    const-string v2, "intranet_ipv6_cidrs"

    .line 293
    .line 294
    iget-object v3, v0, Lsi0;->b:Ljava/util/List;

    .line 295
    .line 296
    invoke-static {v1, v2, v3}, Luc0;->n(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/util/List;)V

    .line 297
    .line 298
    .line 299
    iget-object v0, v0, Lsi0;->c:Ljava/util/List;

    .line 300
    .line 301
    invoke-static {v1, v4, v0}, Luc0;->n(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/util/List;)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 305
    .line 306
    .line 307
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 308
    .line 309
    .line 310
    return-object v10

    .line 311
    :catchall_2
    move-exception v0

    .line 312
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 313
    .line 314
    .line 315
    throw v0

    .line 316
    :pswitch_5
    check-cast v0, Lvu0;

    .line 317
    .line 318
    check-cast v1, Landroid/database/sqlite/SQLiteDatabase;

    .line 319
    .line 320
    const-string v2, "cnip_force_uids"

    .line 321
    .line 322
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 323
    .line 324
    .line 325
    sget-object v3, Luc0;->a:Luc0;

    .line 326
    .line 327
    invoke-static {v1}, Luc0;->e(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 328
    .line 329
    .line 330
    invoke-virtual {v3, v1}, Luc0;->d(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 331
    .line 332
    .line 333
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    .line 334
    .line 335
    .line 336
    :try_start_3
    const-string v3, "cnip_settings"

    .line 337
    .line 338
    new-instance v4, Landroid/content/ContentValues;

    .line 339
    .line 340
    invoke-direct {v4}, Landroid/content/ContentValues;-><init>()V

    .line 341
    .line 342
    .line 343
    const-string v6, "bypass_cnip"

    .line 344
    .line 345
    iget-boolean v7, v0, Lvu0;->a:Z

    .line 346
    .line 347
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 348
    .line 349
    .line 350
    move-result-object v7

    .line 351
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 352
    .line 353
    .line 354
    const-string v6, "cnip_mode"

    .line 355
    .line 356
    iget-object v7, v0, Lvu0;->b:Ljava/lang/String;

    .line 357
    .line 358
    invoke-static {v7}, Luc0;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v7

    .line 362
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 363
    .line 364
    .line 365
    const-string v6, "bypass_ipv4"

    .line 366
    .line 367
    iget-boolean v7, v0, Lvu0;->c:Z

    .line 368
    .line 369
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 370
    .line 371
    .line 372
    move-result-object v7

    .line 373
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 374
    .line 375
    .line 376
    const-string v6, "bypass_ipv6"

    .line 377
    .line 378
    iget-boolean v7, v0, Lvu0;->d:Z

    .line 379
    .line 380
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 381
    .line 382
    .line 383
    move-result-object v7

    .line 384
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 385
    .line 386
    .line 387
    const-string v6, "ipv4_file"

    .line 388
    .line 389
    iget-object v7, v0, Lvu0;->e:Ljava/lang/String;

    .line 390
    .line 391
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 392
    .line 393
    .line 394
    const-string v6, "ipv4_url"

    .line 395
    .line 396
    iget-object v7, v0, Lvu0;->f:Ljava/lang/String;

    .line 397
    .line 398
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 399
    .line 400
    .line 401
    const-string v6, "ipv4_source"

    .line 402
    .line 403
    iget-object v7, v0, Lvu0;->g:Ljava/lang/String;

    .line 404
    .line 405
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 406
    .line 407
    .line 408
    const-string v6, "ipv6_file"

    .line 409
    .line 410
    iget-object v7, v0, Lvu0;->h:Ljava/lang/String;

    .line 411
    .line 412
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 413
    .line 414
    .line 415
    const-string v6, "ipv6_url"

    .line 416
    .line 417
    iget-object v7, v0, Lvu0;->i:Ljava/lang/String;

    .line 418
    .line 419
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 420
    .line 421
    .line 422
    const-string v6, "ipv6_source"

    .line 423
    .line 424
    iget-object v7, v0, Lvu0;->j:Ljava/lang/String;

    .line 425
    .line 426
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 427
    .line 428
    .line 429
    const-string v6, "ipv4_additions"

    .line 430
    .line 431
    iget-object v11, v0, Lvu0;->m:Ljava/util/List;

    .line 432
    .line 433
    const-string v12, "\n"

    .line 434
    .line 435
    const/4 v15, 0x0

    .line 436
    const/16 v16, 0x3e

    .line 437
    .line 438
    const/4 v13, 0x0

    .line 439
    const/4 v14, 0x0

    .line 440
    invoke-static/range {v11 .. v16}, Lxx0;->a1(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Lhh2;I)Ljava/lang/String;

    .line 441
    .line 442
    .line 443
    move-result-object v7

    .line 444
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 445
    .line 446
    .line 447
    const-string v6, "ipv6_additions"

    .line 448
    .line 449
    iget-object v11, v0, Lvu0;->n:Ljava/util/List;

    .line 450
    .line 451
    const-string v12, "\n"

    .line 452
    .line 453
    const/4 v15, 0x0

    .line 454
    const/16 v16, 0x3e

    .line 455
    .line 456
    const/4 v13, 0x0

    .line 457
    const/4 v14, 0x0

    .line 458
    invoke-static/range {v11 .. v16}, Lxx0;->a1(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Lhh2;I)Ljava/lang/String;

    .line 459
    .line 460
    .line 461
    move-result-object v7

    .line 462
    invoke-virtual {v4, v6, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 463
    .line 464
    .line 465
    invoke-virtual {v1, v3, v4, v5, v9}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    .line 466
    .line 467
    .line 468
    invoke-virtual {v1, v2, v9, v9}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 469
    .line 470
    .line 471
    iget-object v3, v0, Lvu0;->k:Ljava/util/Set;

    .line 472
    .line 473
    check-cast v3, Ljava/util/Collection;

    .line 474
    .line 475
    invoke-static {v3}, Lof;->L(Ljava/util/Collection;)Ljava/util/List;

    .line 476
    .line 477
    .line 478
    move-result-object v3

    .line 479
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 480
    .line 481
    .line 482
    move-result-object v3

    .line 483
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 484
    .line 485
    .line 486
    move-result v4

    .line 487
    if-eqz v4, :cond_1

    .line 488
    .line 489
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 490
    .line 491
    .line 492
    move-result-object v4

    .line 493
    check-cast v4, Ljava/lang/String;

    .line 494
    .line 495
    new-instance v5, Landroid/content/ContentValues;

    .line 496
    .line 497
    invoke-direct {v5}, Landroid/content/ContentValues;-><init>()V

    .line 498
    .line 499
    .line 500
    const-string v6, "uid"

    .line 501
    .line 502
    invoke-virtual {v5, v6, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 503
    .line 504
    .line 505
    invoke-virtual {v1, v2, v9, v5}, Landroid/database/sqlite/SQLiteDatabase;->insertOrThrow(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    .line 506
    .line 507
    .line 508
    goto :goto_0

    .line 509
    :cond_1
    sget-object v2, Luc0;->a:Luc0;

    .line 510
    .line 511
    const-string v2, "cnip_force_apps"

    .line 512
    .line 513
    iget-object v0, v0, Lvu0;->l:Ljava/util/List;

    .line 514
    .line 515
    invoke-static {v1, v2, v0}, Luc0;->n(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/util/List;)V

    .line 516
    .line 517
    .line 518
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 519
    .line 520
    .line 521
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 522
    .line 523
    .line 524
    return-object v10

    .line 525
    :catchall_3
    move-exception v0

    .line 526
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 527
    .line 528
    .line 529
    throw v0

    .line 530
    :pswitch_6
    check-cast v0, Lkl7;

    .line 531
    .line 532
    check-cast v1, Lsr1;

    .line 533
    .line 534
    new-instance v1, Lh7;

    .line 535
    .line 536
    const/4 v2, 0x6

    .line 537
    invoke-direct {v1, v0, v2}, Lh7;-><init>(Ljava/lang/Object;B)V

    .line 538
    .line 539
    .line 540
    return-object v1

    .line 541
    :pswitch_7
    check-cast v0, Lg20;

    .line 542
    .line 543
    check-cast v1, Lsr1;

    .line 544
    .line 545
    new-instance v1, Lh7;

    .line 546
    .line 547
    const/4 v2, 0x4

    .line 548
    invoke-direct {v1, v0, v2}, Lh7;-><init>(Ljava/lang/Object;B)V

    .line 549
    .line 550
    .line 551
    return-object v1

    .line 552
    :pswitch_8
    move-object v4, v0

    .line 553
    check-cast v4, Lor7;

    .line 554
    .line 555
    move-object v3, v1

    .line 556
    check-cast v3, Lgw;

    .line 557
    .line 558
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 559
    .line 560
    .line 561
    const/16 v48, -0x2

    .line 562
    .line 563
    const/16 v49, 0x1fff

    .line 564
    .line 565
    const/4 v5, 0x0

    .line 566
    const/4 v6, 0x0

    .line 567
    const/4 v7, 0x0

    .line 568
    const/4 v8, 0x0

    .line 569
    const/4 v9, 0x0

    .line 570
    const/4 v10, 0x0

    .line 571
    const/4 v11, 0x0

    .line 572
    const/4 v12, 0x0

    .line 573
    const/4 v13, 0x0

    .line 574
    const/4 v14, 0x0

    .line 575
    const/4 v15, 0x0

    .line 576
    const/16 v16, 0x0

    .line 577
    .line 578
    const/16 v17, 0x0

    .line 579
    .line 580
    const/16 v18, 0x0

    .line 581
    .line 582
    const/16 v19, 0x0

    .line 583
    .line 584
    const/16 v20, 0x0

    .line 585
    .line 586
    const/16 v21, 0x0

    .line 587
    .line 588
    const/16 v22, 0x0

    .line 589
    .line 590
    const/16 v23, 0x0

    .line 591
    .line 592
    const/16 v24, 0x0

    .line 593
    .line 594
    const/16 v25, 0x0

    .line 595
    .line 596
    const/16 v26, 0x0

    .line 597
    .line 598
    const/16 v27, 0x0

    .line 599
    .line 600
    const/16 v28, 0x0

    .line 601
    .line 602
    const/16 v29, 0x0

    .line 603
    .line 604
    const/16 v30, 0x0

    .line 605
    .line 606
    const/16 v31, 0x0

    .line 607
    .line 608
    const/16 v32, 0x0

    .line 609
    .line 610
    const/16 v33, 0x0

    .line 611
    .line 612
    const/16 v34, 0x0

    .line 613
    .line 614
    const/16 v35, 0x0

    .line 615
    .line 616
    const/16 v36, 0x0

    .line 617
    .line 618
    const/16 v37, 0x0

    .line 619
    .line 620
    const/16 v38, 0x0

    .line 621
    .line 622
    const/16 v39, 0x0

    .line 623
    .line 624
    const/16 v40, 0x0

    .line 625
    .line 626
    const/16 v41, 0x0

    .line 627
    .line 628
    const/16 v42, 0x0

    .line 629
    .line 630
    const/16 v43, 0x0

    .line 631
    .line 632
    const/16 v44, 0x0

    .line 633
    .line 634
    const/16 v45, 0x0

    .line 635
    .line 636
    const/16 v46, 0x0

    .line 637
    .line 638
    const/16 v47, 0x0

    .line 639
    .line 640
    invoke-static/range {v3 .. v49}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 641
    .line 642
    .line 643
    move-result-object v0

    .line 644
    return-object v0

    .line 645
    :pswitch_9
    move-object/from16 v36, v0

    .line 646
    .line 647
    check-cast v36, Lhm7;

    .line 648
    .line 649
    move-object v2, v1

    .line 650
    check-cast v2, Lgw;

    .line 651
    .line 652
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 653
    .line 654
    .line 655
    const/16 v47, -0x1

    .line 656
    .line 657
    const/16 v48, 0x1ffd

    .line 658
    .line 659
    const/4 v3, 0x0

    .line 660
    const/4 v4, 0x0

    .line 661
    const/4 v5, 0x0

    .line 662
    const/4 v6, 0x0

    .line 663
    const/4 v7, 0x0

    .line 664
    const/4 v8, 0x0

    .line 665
    const/4 v9, 0x0

    .line 666
    const/4 v10, 0x0

    .line 667
    const/4 v11, 0x0

    .line 668
    const/4 v12, 0x0

    .line 669
    const/4 v13, 0x0

    .line 670
    const/4 v14, 0x0

    .line 671
    const/4 v15, 0x0

    .line 672
    const/16 v16, 0x0

    .line 673
    .line 674
    const/16 v17, 0x0

    .line 675
    .line 676
    const/16 v18, 0x0

    .line 677
    .line 678
    const/16 v19, 0x0

    .line 679
    .line 680
    const/16 v20, 0x0

    .line 681
    .line 682
    const/16 v21, 0x0

    .line 683
    .line 684
    const/16 v22, 0x0

    .line 685
    .line 686
    const/16 v23, 0x0

    .line 687
    .line 688
    const/16 v24, 0x0

    .line 689
    .line 690
    const/16 v25, 0x0

    .line 691
    .line 692
    const/16 v26, 0x0

    .line 693
    .line 694
    const/16 v27, 0x0

    .line 695
    .line 696
    const/16 v28, 0x0

    .line 697
    .line 698
    const/16 v29, 0x0

    .line 699
    .line 700
    const/16 v30, 0x0

    .line 701
    .line 702
    const/16 v31, 0x0

    .line 703
    .line 704
    const/16 v32, 0x0

    .line 705
    .line 706
    const/16 v33, 0x0

    .line 707
    .line 708
    const/16 v34, 0x0

    .line 709
    .line 710
    const/16 v35, 0x0

    .line 711
    .line 712
    const/16 v37, 0x0

    .line 713
    .line 714
    const/16 v38, 0x0

    .line 715
    .line 716
    const/16 v39, 0x0

    .line 717
    .line 718
    const/16 v40, 0x0

    .line 719
    .line 720
    const/16 v41, 0x0

    .line 721
    .line 722
    const/16 v42, 0x0

    .line 723
    .line 724
    const/16 v43, 0x0

    .line 725
    .line 726
    const/16 v44, 0x0

    .line 727
    .line 728
    const/16 v45, 0x0

    .line 729
    .line 730
    const/16 v46, 0x0

    .line 731
    .line 732
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 733
    .line 734
    .line 735
    move-result-object v0

    .line 736
    return-object v0

    .line 737
    :pswitch_a
    move-object v5, v0

    .line 738
    check-cast v5, Lqx2;

    .line 739
    .line 740
    move-object v2, v1

    .line 741
    check-cast v2, Lgw;

    .line 742
    .line 743
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 744
    .line 745
    .line 746
    const/16 v47, -0x5

    .line 747
    .line 748
    const/16 v48, 0x1fff

    .line 749
    .line 750
    const/4 v3, 0x0

    .line 751
    const/4 v4, 0x0

    .line 752
    const/4 v6, 0x0

    .line 753
    const/4 v7, 0x0

    .line 754
    const/4 v8, 0x0

    .line 755
    const/4 v9, 0x0

    .line 756
    const/4 v10, 0x0

    .line 757
    const/4 v11, 0x0

    .line 758
    const/4 v12, 0x0

    .line 759
    const/4 v13, 0x0

    .line 760
    const/4 v14, 0x0

    .line 761
    const/4 v15, 0x0

    .line 762
    const/16 v16, 0x0

    .line 763
    .line 764
    const/16 v17, 0x0

    .line 765
    .line 766
    const/16 v18, 0x0

    .line 767
    .line 768
    const/16 v19, 0x0

    .line 769
    .line 770
    const/16 v20, 0x0

    .line 771
    .line 772
    const/16 v21, 0x0

    .line 773
    .line 774
    const/16 v22, 0x0

    .line 775
    .line 776
    const/16 v23, 0x0

    .line 777
    .line 778
    const/16 v24, 0x0

    .line 779
    .line 780
    const/16 v25, 0x0

    .line 781
    .line 782
    const/16 v26, 0x0

    .line 783
    .line 784
    const/16 v27, 0x0

    .line 785
    .line 786
    const/16 v28, 0x0

    .line 787
    .line 788
    const/16 v29, 0x0

    .line 789
    .line 790
    const/16 v30, 0x0

    .line 791
    .line 792
    const/16 v31, 0x0

    .line 793
    .line 794
    const/16 v32, 0x0

    .line 795
    .line 796
    const/16 v33, 0x0

    .line 797
    .line 798
    const/16 v34, 0x0

    .line 799
    .line 800
    const/16 v35, 0x0

    .line 801
    .line 802
    const/16 v36, 0x0

    .line 803
    .line 804
    const/16 v37, 0x0

    .line 805
    .line 806
    const/16 v38, 0x0

    .line 807
    .line 808
    const/16 v39, 0x0

    .line 809
    .line 810
    const/16 v40, 0x0

    .line 811
    .line 812
    const/16 v41, 0x0

    .line 813
    .line 814
    const/16 v42, 0x0

    .line 815
    .line 816
    const/16 v43, 0x0

    .line 817
    .line 818
    const/16 v44, 0x0

    .line 819
    .line 820
    const/16 v45, 0x0

    .line 821
    .line 822
    const/16 v46, 0x0

    .line 823
    .line 824
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 825
    .line 826
    .line 827
    move-result-object v0

    .line 828
    return-object v0

    .line 829
    :pswitch_b
    move-object/from16 v43, v0

    .line 830
    .line 831
    check-cast v43, Lnx6;

    .line 832
    .line 833
    move-object v2, v1

    .line 834
    check-cast v2, Lgw;

    .line 835
    .line 836
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 837
    .line 838
    .line 839
    const/16 v47, -0x1

    .line 840
    .line 841
    const/16 v48, 0x1eff

    .line 842
    .line 843
    const/4 v3, 0x0

    .line 844
    const/4 v4, 0x0

    .line 845
    const/4 v5, 0x0

    .line 846
    const/4 v6, 0x0

    .line 847
    const/4 v7, 0x0

    .line 848
    const/4 v8, 0x0

    .line 849
    const/4 v9, 0x0

    .line 850
    const/4 v10, 0x0

    .line 851
    const/4 v11, 0x0

    .line 852
    const/4 v12, 0x0

    .line 853
    const/4 v13, 0x0

    .line 854
    const/4 v14, 0x0

    .line 855
    const/4 v15, 0x0

    .line 856
    const/16 v16, 0x0

    .line 857
    .line 858
    const/16 v17, 0x0

    .line 859
    .line 860
    const/16 v18, 0x0

    .line 861
    .line 862
    const/16 v19, 0x0

    .line 863
    .line 864
    const/16 v20, 0x0

    .line 865
    .line 866
    const/16 v21, 0x0

    .line 867
    .line 868
    const/16 v22, 0x0

    .line 869
    .line 870
    const/16 v23, 0x0

    .line 871
    .line 872
    const/16 v24, 0x0

    .line 873
    .line 874
    const/16 v25, 0x0

    .line 875
    .line 876
    const/16 v26, 0x0

    .line 877
    .line 878
    const/16 v27, 0x0

    .line 879
    .line 880
    const/16 v28, 0x0

    .line 881
    .line 882
    const/16 v29, 0x0

    .line 883
    .line 884
    const/16 v30, 0x0

    .line 885
    .line 886
    const/16 v31, 0x0

    .line 887
    .line 888
    const/16 v32, 0x0

    .line 889
    .line 890
    const/16 v33, 0x0

    .line 891
    .line 892
    const/16 v34, 0x0

    .line 893
    .line 894
    const/16 v35, 0x0

    .line 895
    .line 896
    const/16 v36, 0x0

    .line 897
    .line 898
    const/16 v37, 0x0

    .line 899
    .line 900
    const/16 v38, 0x0

    .line 901
    .line 902
    const/16 v39, 0x0

    .line 903
    .line 904
    const/16 v40, 0x0

    .line 905
    .line 906
    const/16 v41, 0x0

    .line 907
    .line 908
    const/16 v42, 0x0

    .line 909
    .line 910
    const/16 v44, 0x0

    .line 911
    .line 912
    const/16 v45, 0x0

    .line 913
    .line 914
    const/16 v46, 0x0

    .line 915
    .line 916
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 917
    .line 918
    .line 919
    move-result-object v0

    .line 920
    return-object v0

    .line 921
    :pswitch_c
    move-object/from16 v28, v0

    .line 922
    .line 923
    check-cast v28, Lrh7;

    .line 924
    .line 925
    move-object v2, v1

    .line 926
    check-cast v2, Lgw;

    .line 927
    .line 928
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 929
    .line 930
    .line 931
    const v47, -0x2000001

    .line 932
    .line 933
    .line 934
    const/16 v48, 0x1fff

    .line 935
    .line 936
    const/4 v3, 0x0

    .line 937
    const/4 v4, 0x0

    .line 938
    const/4 v5, 0x0

    .line 939
    const/4 v6, 0x0

    .line 940
    const/4 v7, 0x0

    .line 941
    const/4 v8, 0x0

    .line 942
    const/4 v9, 0x0

    .line 943
    const/4 v10, 0x0

    .line 944
    const/4 v11, 0x0

    .line 945
    const/4 v12, 0x0

    .line 946
    const/4 v13, 0x0

    .line 947
    const/4 v14, 0x0

    .line 948
    const/4 v15, 0x0

    .line 949
    const/16 v16, 0x0

    .line 950
    .line 951
    const/16 v17, 0x0

    .line 952
    .line 953
    const/16 v18, 0x0

    .line 954
    .line 955
    const/16 v19, 0x0

    .line 956
    .line 957
    const/16 v20, 0x0

    .line 958
    .line 959
    const/16 v21, 0x0

    .line 960
    .line 961
    const/16 v22, 0x0

    .line 962
    .line 963
    const/16 v23, 0x0

    .line 964
    .line 965
    const/16 v24, 0x0

    .line 966
    .line 967
    const/16 v25, 0x0

    .line 968
    .line 969
    const/16 v26, 0x0

    .line 970
    .line 971
    const/16 v27, 0x0

    .line 972
    .line 973
    const/16 v29, 0x0

    .line 974
    .line 975
    const/16 v30, 0x0

    .line 976
    .line 977
    const/16 v31, 0x0

    .line 978
    .line 979
    const/16 v32, 0x0

    .line 980
    .line 981
    const/16 v33, 0x0

    .line 982
    .line 983
    const/16 v34, 0x0

    .line 984
    .line 985
    const/16 v35, 0x0

    .line 986
    .line 987
    const/16 v36, 0x0

    .line 988
    .line 989
    const/16 v37, 0x0

    .line 990
    .line 991
    const/16 v38, 0x0

    .line 992
    .line 993
    const/16 v39, 0x0

    .line 994
    .line 995
    const/16 v40, 0x0

    .line 996
    .line 997
    const/16 v41, 0x0

    .line 998
    .line 999
    const/16 v42, 0x0

    .line 1000
    .line 1001
    const/16 v43, 0x0

    .line 1002
    .line 1003
    const/16 v44, 0x0

    .line 1004
    .line 1005
    const/16 v45, 0x0

    .line 1006
    .line 1007
    const/16 v46, 0x0

    .line 1008
    .line 1009
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 1010
    .line 1011
    .line 1012
    move-result-object v0

    .line 1013
    return-object v0

    .line 1014
    :pswitch_d
    move-object v4, v0

    .line 1015
    check-cast v4, Lct;

    .line 1016
    .line 1017
    move-object v2, v1

    .line 1018
    check-cast v2, Lgw;

    .line 1019
    .line 1020
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1021
    .line 1022
    .line 1023
    const/16 v47, -0x3

    .line 1024
    .line 1025
    const/16 v48, 0x1fff

    .line 1026
    .line 1027
    const/4 v3, 0x0

    .line 1028
    const/4 v5, 0x0

    .line 1029
    const/4 v6, 0x0

    .line 1030
    const/4 v7, 0x0

    .line 1031
    const/4 v8, 0x0

    .line 1032
    const/4 v9, 0x0

    .line 1033
    const/4 v10, 0x0

    .line 1034
    const/4 v11, 0x0

    .line 1035
    const/4 v12, 0x0

    .line 1036
    const/4 v13, 0x0

    .line 1037
    const/4 v14, 0x0

    .line 1038
    const/4 v15, 0x0

    .line 1039
    const/16 v16, 0x0

    .line 1040
    .line 1041
    const/16 v17, 0x0

    .line 1042
    .line 1043
    const/16 v18, 0x0

    .line 1044
    .line 1045
    const/16 v19, 0x0

    .line 1046
    .line 1047
    const/16 v20, 0x0

    .line 1048
    .line 1049
    const/16 v21, 0x0

    .line 1050
    .line 1051
    const/16 v22, 0x0

    .line 1052
    .line 1053
    const/16 v23, 0x0

    .line 1054
    .line 1055
    const/16 v24, 0x0

    .line 1056
    .line 1057
    const/16 v25, 0x0

    .line 1058
    .line 1059
    const/16 v26, 0x0

    .line 1060
    .line 1061
    const/16 v27, 0x0

    .line 1062
    .line 1063
    const/16 v28, 0x0

    .line 1064
    .line 1065
    const/16 v29, 0x0

    .line 1066
    .line 1067
    const/16 v30, 0x0

    .line 1068
    .line 1069
    const/16 v31, 0x0

    .line 1070
    .line 1071
    const/16 v32, 0x0

    .line 1072
    .line 1073
    const/16 v33, 0x0

    .line 1074
    .line 1075
    const/16 v34, 0x0

    .line 1076
    .line 1077
    const/16 v35, 0x0

    .line 1078
    .line 1079
    const/16 v36, 0x0

    .line 1080
    .line 1081
    const/16 v37, 0x0

    .line 1082
    .line 1083
    const/16 v38, 0x0

    .line 1084
    .line 1085
    const/16 v39, 0x0

    .line 1086
    .line 1087
    const/16 v40, 0x0

    .line 1088
    .line 1089
    const/16 v41, 0x0

    .line 1090
    .line 1091
    const/16 v42, 0x0

    .line 1092
    .line 1093
    const/16 v43, 0x0

    .line 1094
    .line 1095
    const/16 v44, 0x0

    .line 1096
    .line 1097
    const/16 v45, 0x0

    .line 1098
    .line 1099
    const/16 v46, 0x0

    .line 1100
    .line 1101
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 1102
    .line 1103
    .line 1104
    move-result-object v0

    .line 1105
    return-object v0

    .line 1106
    :pswitch_e
    move-object/from16 v37, v0

    .line 1107
    .line 1108
    check-cast v37, Lg60;

    .line 1109
    .line 1110
    move-object v2, v1

    .line 1111
    check-cast v2, Lgw;

    .line 1112
    .line 1113
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1114
    .line 1115
    .line 1116
    const/16 v47, -0x1

    .line 1117
    .line 1118
    const/16 v48, 0x1ffb

    .line 1119
    .line 1120
    const/4 v3, 0x0

    .line 1121
    const/4 v4, 0x0

    .line 1122
    const/4 v5, 0x0

    .line 1123
    const/4 v6, 0x0

    .line 1124
    const/4 v7, 0x0

    .line 1125
    const/4 v8, 0x0

    .line 1126
    const/4 v9, 0x0

    .line 1127
    const/4 v10, 0x0

    .line 1128
    const/4 v11, 0x0

    .line 1129
    const/4 v12, 0x0

    .line 1130
    const/4 v13, 0x0

    .line 1131
    const/4 v14, 0x0

    .line 1132
    const/4 v15, 0x0

    .line 1133
    const/16 v16, 0x0

    .line 1134
    .line 1135
    const/16 v17, 0x0

    .line 1136
    .line 1137
    const/16 v18, 0x0

    .line 1138
    .line 1139
    const/16 v19, 0x0

    .line 1140
    .line 1141
    const/16 v20, 0x0

    .line 1142
    .line 1143
    const/16 v21, 0x0

    .line 1144
    .line 1145
    const/16 v22, 0x0

    .line 1146
    .line 1147
    const/16 v23, 0x0

    .line 1148
    .line 1149
    const/16 v24, 0x0

    .line 1150
    .line 1151
    const/16 v25, 0x0

    .line 1152
    .line 1153
    const/16 v26, 0x0

    .line 1154
    .line 1155
    const/16 v27, 0x0

    .line 1156
    .line 1157
    const/16 v28, 0x0

    .line 1158
    .line 1159
    const/16 v29, 0x0

    .line 1160
    .line 1161
    const/16 v30, 0x0

    .line 1162
    .line 1163
    const/16 v31, 0x0

    .line 1164
    .line 1165
    const/16 v32, 0x0

    .line 1166
    .line 1167
    const/16 v33, 0x0

    .line 1168
    .line 1169
    const/16 v34, 0x0

    .line 1170
    .line 1171
    const/16 v35, 0x0

    .line 1172
    .line 1173
    const/16 v36, 0x0

    .line 1174
    .line 1175
    const/16 v38, 0x0

    .line 1176
    .line 1177
    const/16 v39, 0x0

    .line 1178
    .line 1179
    const/16 v40, 0x0

    .line 1180
    .line 1181
    const/16 v41, 0x0

    .line 1182
    .line 1183
    const/16 v42, 0x0

    .line 1184
    .line 1185
    const/16 v43, 0x0

    .line 1186
    .line 1187
    const/16 v44, 0x0

    .line 1188
    .line 1189
    const/16 v45, 0x0

    .line 1190
    .line 1191
    const/16 v46, 0x0

    .line 1192
    .line 1193
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 1194
    .line 1195
    .line 1196
    move-result-object v0

    .line 1197
    return-object v0

    .line 1198
    :pswitch_f
    move-object/from16 v33, v0

    .line 1199
    .line 1200
    check-cast v33, Lth7;

    .line 1201
    .line 1202
    move-object v2, v1

    .line 1203
    check-cast v2, Lgw;

    .line 1204
    .line 1205
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1206
    .line 1207
    .line 1208
    const v47, -0x40000001    # -1.9999999f

    .line 1209
    .line 1210
    .line 1211
    const/16 v48, 0x1fff

    .line 1212
    .line 1213
    const/4 v3, 0x0

    .line 1214
    const/4 v4, 0x0

    .line 1215
    const/4 v5, 0x0

    .line 1216
    const/4 v6, 0x0

    .line 1217
    const/4 v7, 0x0

    .line 1218
    const/4 v8, 0x0

    .line 1219
    const/4 v9, 0x0

    .line 1220
    const/4 v10, 0x0

    .line 1221
    const/4 v11, 0x0

    .line 1222
    const/4 v12, 0x0

    .line 1223
    const/4 v13, 0x0

    .line 1224
    const/4 v14, 0x0

    .line 1225
    const/4 v15, 0x0

    .line 1226
    const/16 v16, 0x0

    .line 1227
    .line 1228
    const/16 v17, 0x0

    .line 1229
    .line 1230
    const/16 v18, 0x0

    .line 1231
    .line 1232
    const/16 v19, 0x0

    .line 1233
    .line 1234
    const/16 v20, 0x0

    .line 1235
    .line 1236
    const/16 v21, 0x0

    .line 1237
    .line 1238
    const/16 v22, 0x0

    .line 1239
    .line 1240
    const/16 v23, 0x0

    .line 1241
    .line 1242
    const/16 v24, 0x0

    .line 1243
    .line 1244
    const/16 v25, 0x0

    .line 1245
    .line 1246
    const/16 v26, 0x0

    .line 1247
    .line 1248
    const/16 v27, 0x0

    .line 1249
    .line 1250
    const/16 v28, 0x0

    .line 1251
    .line 1252
    const/16 v29, 0x0

    .line 1253
    .line 1254
    const/16 v30, 0x0

    .line 1255
    .line 1256
    const/16 v31, 0x0

    .line 1257
    .line 1258
    const/16 v32, 0x0

    .line 1259
    .line 1260
    const/16 v34, 0x0

    .line 1261
    .line 1262
    const/16 v35, 0x0

    .line 1263
    .line 1264
    const/16 v36, 0x0

    .line 1265
    .line 1266
    const/16 v37, 0x0

    .line 1267
    .line 1268
    const/16 v38, 0x0

    .line 1269
    .line 1270
    const/16 v39, 0x0

    .line 1271
    .line 1272
    const/16 v40, 0x0

    .line 1273
    .line 1274
    const/16 v41, 0x0

    .line 1275
    .line 1276
    const/16 v42, 0x0

    .line 1277
    .line 1278
    const/16 v43, 0x0

    .line 1279
    .line 1280
    const/16 v44, 0x0

    .line 1281
    .line 1282
    const/16 v45, 0x0

    .line 1283
    .line 1284
    const/16 v46, 0x0

    .line 1285
    .line 1286
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 1287
    .line 1288
    .line 1289
    move-result-object v0

    .line 1290
    return-object v0

    .line 1291
    :pswitch_10
    move-object/from16 v34, v0

    .line 1292
    .line 1293
    check-cast v34, Lnh7;

    .line 1294
    .line 1295
    move-object v2, v1

    .line 1296
    check-cast v2, Lgw;

    .line 1297
    .line 1298
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1299
    .line 1300
    .line 1301
    const v47, 0x7fffffff

    .line 1302
    .line 1303
    .line 1304
    const/16 v48, 0x1fff

    .line 1305
    .line 1306
    const/4 v3, 0x0

    .line 1307
    const/4 v4, 0x0

    .line 1308
    const/4 v5, 0x0

    .line 1309
    const/4 v6, 0x0

    .line 1310
    const/4 v7, 0x0

    .line 1311
    const/4 v8, 0x0

    .line 1312
    const/4 v9, 0x0

    .line 1313
    const/4 v10, 0x0

    .line 1314
    const/4 v11, 0x0

    .line 1315
    const/4 v12, 0x0

    .line 1316
    const/4 v13, 0x0

    .line 1317
    const/4 v14, 0x0

    .line 1318
    const/4 v15, 0x0

    .line 1319
    const/16 v16, 0x0

    .line 1320
    .line 1321
    const/16 v17, 0x0

    .line 1322
    .line 1323
    const/16 v18, 0x0

    .line 1324
    .line 1325
    const/16 v19, 0x0

    .line 1326
    .line 1327
    const/16 v20, 0x0

    .line 1328
    .line 1329
    const/16 v21, 0x0

    .line 1330
    .line 1331
    const/16 v22, 0x0

    .line 1332
    .line 1333
    const/16 v23, 0x0

    .line 1334
    .line 1335
    const/16 v24, 0x0

    .line 1336
    .line 1337
    const/16 v25, 0x0

    .line 1338
    .line 1339
    const/16 v26, 0x0

    .line 1340
    .line 1341
    const/16 v27, 0x0

    .line 1342
    .line 1343
    const/16 v28, 0x0

    .line 1344
    .line 1345
    const/16 v29, 0x0

    .line 1346
    .line 1347
    const/16 v30, 0x0

    .line 1348
    .line 1349
    const/16 v31, 0x0

    .line 1350
    .line 1351
    const/16 v32, 0x0

    .line 1352
    .line 1353
    const/16 v33, 0x0

    .line 1354
    .line 1355
    const/16 v35, 0x0

    .line 1356
    .line 1357
    const/16 v36, 0x0

    .line 1358
    .line 1359
    const/16 v37, 0x0

    .line 1360
    .line 1361
    const/16 v38, 0x0

    .line 1362
    .line 1363
    const/16 v39, 0x0

    .line 1364
    .line 1365
    const/16 v40, 0x0

    .line 1366
    .line 1367
    const/16 v41, 0x0

    .line 1368
    .line 1369
    const/16 v42, 0x0

    .line 1370
    .line 1371
    const/16 v43, 0x0

    .line 1372
    .line 1373
    const/16 v44, 0x0

    .line 1374
    .line 1375
    const/16 v45, 0x0

    .line 1376
    .line 1377
    const/16 v46, 0x0

    .line 1378
    .line 1379
    invoke-static/range {v2 .. v48}, Lgw;->a(Lgw;Lor7;Lct;Lqx2;ZZLjava/lang/String;ZLjava/lang/String;ZLet4;ILjava/lang/String;Ljava/lang/String;Let4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZLjava/lang/String;Ldt4;ZZLrh7;ZZIZLth7;Lnh7;ZLhm7;Lg60;ZZZZZLnx6;ZZFII)Lgw;

    .line 1380
    .line 1381
    .line 1382
    move-result-object v0

    .line 1383
    return-object v0

    .line 1384
    :pswitch_11
    check-cast v0, Lew;

    .line 1385
    .line 1386
    check-cast v1, Lcv;

    .line 1387
    .line 1388
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1389
    .line 1390
    .line 1391
    iget v1, v1, Lcv;->d:I

    .line 1392
    .line 1393
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 1394
    .line 1395
    .line 1396
    move-result v0

    .line 1397
    if-eqz v0, :cond_5

    .line 1398
    .line 1399
    if-eq v0, v8, :cond_4

    .line 1400
    .line 1401
    const/16 v2, 0xa

    .line 1402
    .line 1403
    if-eq v0, v3, :cond_3

    .line 1404
    .line 1405
    if-ne v0, v6, :cond_2

    .line 1406
    .line 1407
    if-eqz v1, :cond_6

    .line 1408
    .line 1409
    if-eq v1, v2, :cond_6

    .line 1410
    .line 1411
    goto :goto_1

    .line 1412
    :cond_2
    invoke-static {}, Lfb1;->a()V

    .line 1413
    .line 1414
    .line 1415
    goto :goto_2

    .line 1416
    :cond_3
    if-ne v1, v2, :cond_6

    .line 1417
    .line 1418
    goto :goto_1

    .line 1419
    :cond_4
    if-nez v1, :cond_6

    .line 1420
    .line 1421
    :cond_5
    :goto_1
    move v7, v8

    .line 1422
    :cond_6
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1423
    .line 1424
    .line 1425
    move-result-object v9

    .line 1426
    :goto_2
    return-object v9

    .line 1427
    :pswitch_12
    check-cast v0, Lgt;

    .line 1428
    .line 1429
    check-cast v1, Lcv;

    .line 1430
    .line 1431
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1432
    .line 1433
    .line 1434
    iget-boolean v1, v1, Lcv;->c:Z

    .line 1435
    .line 1436
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 1437
    .line 1438
    .line 1439
    move-result v0

    .line 1440
    if-eqz v0, :cond_9

    .line 1441
    .line 1442
    if-eq v0, v8, :cond_8

    .line 1443
    .line 1444
    if-ne v0, v3, :cond_7

    .line 1445
    .line 1446
    move v7, v1

    .line 1447
    goto :goto_3

    .line 1448
    :cond_7
    invoke-static {}, Lfb1;->a()V

    .line 1449
    .line 1450
    .line 1451
    goto :goto_4

    .line 1452
    :cond_8
    if-nez v1, :cond_a

    .line 1453
    .line 1454
    :cond_9
    move v7, v8

    .line 1455
    :cond_a
    :goto_3
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1456
    .line 1457
    .line 1458
    move-result-object v9

    .line 1459
    :goto_4
    return-object v9

    .line 1460
    :pswitch_13
    check-cast v0, Le52;

    .line 1461
    .line 1462
    check-cast v1, Ljava/lang/Float;

    .line 1463
    .line 1464
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 1465
    .line 1466
    .line 1467
    move-result v1

    .line 1468
    iget-object v0, v0, Le52;->a:Lfm7;

    .line 1469
    .line 1470
    iget-object v2, v0, Lfm7;->c:Lb75;

    .line 1471
    .line 1472
    invoke-virtual {v2}, Lb75;->h()F

    .line 1473
    .line 1474
    .line 1475
    move-result v2

    .line 1476
    add-float/2addr v2, v1

    .line 1477
    invoke-virtual {v0, v2}, Lfm7;->b(F)V

    .line 1478
    .line 1479
    .line 1480
    return-object v10

    .line 1481
    :pswitch_14
    check-cast v0, Lwi3;

    .line 1482
    .line 1483
    check-cast v1, Lso1;

    .line 1484
    .line 1485
    invoke-virtual {v0, v1}, Lwi3;->a0(Lso1;)V

    .line 1486
    .line 1487
    .line 1488
    return-object v10

    .line 1489
    :pswitch_15
    check-cast v0, Ljava/util/LinkedHashMap;

    .line 1490
    .line 1491
    check-cast v1, Lorg/json/JSONObject;

    .line 1492
    .line 1493
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1494
    .line 1495
    .line 1496
    const-string v2, "licenses"

    .line 1497
    .line 1498
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 1499
    .line 1500
    .line 1501
    move-result-object v2

    .line 1502
    sget-object v3, Lw12;->h:Lw12;

    .line 1503
    .line 1504
    if-nez v2, :cond_b

    .line 1505
    .line 1506
    move-object v4, v3

    .line 1507
    goto :goto_6

    .line 1508
    :cond_b
    new-instance v4, Ljava/util/ArrayList;

    .line 1509
    .line 1510
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 1511
    .line 1512
    .line 1513
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    .line 1514
    .line 1515
    .line 1516
    move-result v5

    .line 1517
    move v6, v7

    .line 1518
    :goto_5
    if-ge v6, v5, :cond_c

    .line 1519
    .line 1520
    invoke-virtual {v2, v6}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    .line 1521
    .line 1522
    .line 1523
    move-result-object v8

    .line 1524
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1525
    .line 1526
    .line 1527
    invoke-virtual {v0, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1528
    .line 1529
    .line 1530
    move-result-object v8

    .line 1531
    check-cast v8, Lrn3;

    .line 1532
    .line 1533
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1534
    .line 1535
    .line 1536
    add-int/lit8 v6, v6, 0x1

    .line 1537
    .line 1538
    goto :goto_5

    .line 1539
    :cond_c
    :goto_6
    new-instance v0, Ljava/util/ArrayList;

    .line 1540
    .line 1541
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1542
    .line 1543
    .line 1544
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1545
    .line 1546
    .line 1547
    move-result-object v2

    .line 1548
    :cond_d
    :goto_7
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1549
    .line 1550
    .line 1551
    move-result v4

    .line 1552
    if-eqz v4, :cond_e

    .line 1553
    .line 1554
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1555
    .line 1556
    .line 1557
    move-result-object v4

    .line 1558
    check-cast v4, Lrn3;

    .line 1559
    .line 1560
    if-eqz v4, :cond_d

    .line 1561
    .line 1562
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1563
    .line 1564
    .line 1565
    goto :goto_7

    .line 1566
    :cond_e
    new-instance v2, Ljava/util/HashSet;

    .line 1567
    .line 1568
    const/16 v4, 0xc

    .line 1569
    .line 1570
    invoke-static {v0, v4}, Lyx0;->F0(Ljava/lang/Iterable;I)I

    .line 1571
    .line 1572
    .line 1573
    move-result v4

    .line 1574
    invoke-static {v4}, Lhy3;->c0(I)I

    .line 1575
    .line 1576
    .line 1577
    move-result v4

    .line 1578
    invoke-direct {v2, v4}, Ljava/util/HashSet;-><init>(I)V

    .line 1579
    .line 1580
    .line 1581
    invoke-static {v0, v2}, Lxx0;->p1(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V

    .line 1582
    .line 1583
    .line 1584
    const-string v0, "developers"

    .line 1585
    .line 1586
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 1587
    .line 1588
    .line 1589
    move-result-object v0

    .line 1590
    const-string v4, "name"

    .line 1591
    .line 1592
    if-eqz v0, :cond_10

    .line 1593
    .line 1594
    new-instance v5, Ljava/util/ArrayList;

    .line 1595
    .line 1596
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 1597
    .line 1598
    .line 1599
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 1600
    .line 1601
    .line 1602
    move-result v6

    .line 1603
    move v8, v7

    .line 1604
    :goto_8
    if-ge v8, v6, :cond_f

    .line 1605
    .line 1606
    invoke-virtual {v0, v8}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    .line 1607
    .line 1608
    .line 1609
    move-result-object v10

    .line 1610
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1611
    .line 1612
    .line 1613
    new-instance v11, Lep1;

    .line 1614
    .line 1615
    invoke-static {v4, v10}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1616
    .line 1617
    .line 1618
    move-result-object v12

    .line 1619
    const-string v13, "organisationUrl"

    .line 1620
    .line 1621
    invoke-static {v13, v10}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1622
    .line 1623
    .line 1624
    move-result-object v10

    .line 1625
    invoke-direct {v11, v12, v10}, Lep1;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 1626
    .line 1627
    .line 1628
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1629
    .line 1630
    .line 1631
    add-int/lit8 v8, v8, 0x1

    .line 1632
    .line 1633
    goto :goto_8

    .line 1634
    :cond_f
    move-object/from16 v16, v5

    .line 1635
    .line 1636
    goto :goto_9

    .line 1637
    :cond_10
    move-object/from16 v16, v3

    .line 1638
    .line 1639
    :goto_9
    const-string v0, "organization"

    .line 1640
    .line 1641
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1642
    .line 1643
    .line 1644
    move-result-object v0

    .line 1645
    const-string v5, "url"

    .line 1646
    .line 1647
    if-eqz v0, :cond_12

    .line 1648
    .line 1649
    new-instance v6, Lhz4;

    .line 1650
    .line 1651
    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1652
    .line 1653
    .line 1654
    move-result-object v8

    .line 1655
    if-nez v8, :cond_11

    .line 1656
    .line 1657
    const-string v8, ""

    .line 1658
    .line 1659
    :cond_11
    invoke-static {v5, v0}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1660
    .line 1661
    .line 1662
    move-result-object v0

    .line 1663
    invoke-direct {v6, v8, v0}, Lhz4;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 1664
    .line 1665
    .line 1666
    move-object/from16 v17, v6

    .line 1667
    .line 1668
    goto :goto_a

    .line 1669
    :cond_12
    move-object/from16 v17, v9

    .line 1670
    .line 1671
    :goto_a
    const-string v0, "scm"

    .line 1672
    .line 1673
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1674
    .line 1675
    .line 1676
    move-result-object v0

    .line 1677
    if-eqz v0, :cond_13

    .line 1678
    .line 1679
    new-instance v9, Lwe6;

    .line 1680
    .line 1681
    const-string v6, "connection"

    .line 1682
    .line 1683
    invoke-static {v6, v0}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1684
    .line 1685
    .line 1686
    move-result-object v6

    .line 1687
    const-string v8, "developerConnection"

    .line 1688
    .line 1689
    invoke-static {v8, v0}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1690
    .line 1691
    .line 1692
    move-result-object v8

    .line 1693
    invoke-static {v5, v0}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1694
    .line 1695
    .line 1696
    move-result-object v0

    .line 1697
    invoke-direct {v9, v6, v8, v0}, Lwe6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1698
    .line 1699
    .line 1700
    :cond_13
    move-object/from16 v18, v9

    .line 1701
    .line 1702
    const-string v0, "funding"

    .line 1703
    .line 1704
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 1705
    .line 1706
    .line 1707
    move-result-object v0

    .line 1708
    if-nez v0, :cond_14

    .line 1709
    .line 1710
    move-object v6, v3

    .line 1711
    goto :goto_c

    .line 1712
    :cond_14
    new-instance v6, Ljava/util/ArrayList;

    .line 1713
    .line 1714
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 1715
    .line 1716
    .line 1717
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 1718
    .line 1719
    .line 1720
    move-result v8

    .line 1721
    move v9, v7

    .line 1722
    :goto_b
    if-ge v9, v8, :cond_15

    .line 1723
    .line 1724
    invoke-virtual {v0, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    .line 1725
    .line 1726
    .line 1727
    move-result-object v10

    .line 1728
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1729
    .line 1730
    .line 1731
    new-instance v11, Lzh2;

    .line 1732
    .line 1733
    const-string v12, "platform"

    .line 1734
    .line 1735
    invoke-virtual {v10, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1736
    .line 1737
    .line 1738
    move-result-object v12

    .line 1739
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1740
    .line 1741
    .line 1742
    invoke-virtual {v10, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1743
    .line 1744
    .line 1745
    move-result-object v10

    .line 1746
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1747
    .line 1748
    .line 1749
    invoke-direct {v11, v12, v10}, Lzh2;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 1750
    .line 1751
    .line 1752
    invoke-virtual {v6, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1753
    .line 1754
    .line 1755
    add-int/lit8 v9, v9, 0x1

    .line 1756
    .line 1757
    goto :goto_b

    .line 1758
    :cond_15
    :goto_c
    invoke-static {v6}, Lxx0;->w1(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 1759
    .line 1760
    .line 1761
    move-result-object v20

    .line 1762
    const-string v0, "targets"

    .line 1763
    .line 1764
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 1765
    .line 1766
    .line 1767
    move-result-object v0

    .line 1768
    if-eqz v0, :cond_16

    .line 1769
    .line 1770
    new-instance v3, Ljava/util/ArrayList;

    .line 1771
    .line 1772
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1773
    .line 1774
    .line 1775
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 1776
    .line 1777
    .line 1778
    move-result v5

    .line 1779
    :goto_d
    if-ge v7, v5, :cond_16

    .line 1780
    .line 1781
    invoke-virtual {v0, v7}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    .line 1782
    .line 1783
    .line 1784
    move-result-object v6

    .line 1785
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1786
    .line 1787
    .line 1788
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1789
    .line 1790
    .line 1791
    add-int/lit8 v7, v7, 0x1

    .line 1792
    .line 1793
    goto :goto_d

    .line 1794
    :cond_16
    invoke-static {v3}, Lxx0;->w1(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 1795
    .line 1796
    .line 1797
    move-result-object v22

    .line 1798
    const-string v0, "uniqueId"

    .line 1799
    .line 1800
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1801
    .line 1802
    .line 1803
    move-result-object v11

    .line 1804
    new-instance v10, Lln3;

    .line 1805
    .line 1806
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1807
    .line 1808
    .line 1809
    const-string v0, "artifactVersion"

    .line 1810
    .line 1811
    invoke-static {v0, v1}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1812
    .line 1813
    .line 1814
    move-result-object v12

    .line 1815
    invoke-virtual {v1, v4, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1816
    .line 1817
    .line 1818
    move-result-object v13

    .line 1819
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1820
    .line 1821
    .line 1822
    const-string v0, "description"

    .line 1823
    .line 1824
    invoke-static {v0, v1}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1825
    .line 1826
    .line 1827
    move-result-object v14

    .line 1828
    const-string v0, "website"

    .line 1829
    .line 1830
    invoke-static {v0, v1}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1831
    .line 1832
    .line 1833
    move-result-object v15

    .line 1834
    const-string v0, "tag"

    .line 1835
    .line 1836
    invoke-static {v0, v1}, Lx87;->A(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 1837
    .line 1838
    .line 1839
    move-result-object v21

    .line 1840
    move-object/from16 v19, v2

    .line 1841
    .line 1842
    invoke-direct/range {v10 .. v22}, Lln3;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lhz4;Lwe6;Ljava/util/HashSet;Ljava/util/Set;Ljava/lang/String;Ljava/util/Set;)V

    .line 1843
    .line 1844
    .line 1845
    return-object v10

    .line 1846
    :pswitch_16
    check-cast v0, Llv4;

    .line 1847
    .line 1848
    check-cast v1, Lnk6;

    .line 1849
    .line 1850
    sget-object v2, Lyi6;->a:Lmk6;

    .line 1851
    .line 1852
    new-instance v3, Lvi6;

    .line 1853
    .line 1854
    invoke-interface {v0}, Llv4;->a()J

    .line 1855
    .line 1856
    .line 1857
    move-result-wide v5

    .line 1858
    sget-object v7, Lui6;->i:Lui6;

    .line 1859
    .line 1860
    const/4 v8, 0x1

    .line 1861
    sget-object v4, Lar2;->h:Lar2;

    .line 1862
    .line 1863
    invoke-direct/range {v3 .. v8}, Lvi6;-><init>(Lar2;JLui6;Z)V

    .line 1864
    .line 1865
    .line 1866
    invoke-interface {v1, v2, v3}, Lnk6;->a(Lmk6;Ljava/lang/Object;)V

    .line 1867
    .line 1868
    .line 1869
    return-object v10

    .line 1870
    :pswitch_17
    check-cast v0, Lk93;

    .line 1871
    .line 1872
    check-cast v1, Lek6;

    .line 1873
    .line 1874
    iget v1, v1, Lek6;->f:I

    .line 1875
    .line 1876
    invoke-virtual {v0, v1}, Lk93;->a(I)Z

    .line 1877
    .line 1878
    .line 1879
    move-result v0

    .line 1880
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1881
    .line 1882
    .line 1883
    move-result-object v0

    .line 1884
    return-object v0

    .line 1885
    :pswitch_18
    check-cast v0, Led2;

    .line 1886
    .line 1887
    check-cast v1, Lje2;

    .line 1888
    .line 1889
    iget-byte v0, v0, Led2;->a:B

    .line 1890
    .line 1891
    invoke-virtual {v1, v0}, Lje2;->N1(I)Z

    .line 1892
    .line 1893
    .line 1894
    move-result v0

    .line 1895
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1896
    .line 1897
    .line 1898
    move-result-object v0

    .line 1899
    return-object v0

    .line 1900
    :pswitch_19
    check-cast v0, Lxi3;

    .line 1901
    .line 1902
    check-cast v1, Lt8;

    .line 1903
    .line 1904
    invoke-interface {v1}, Lt8;->b0()I

    .line 1905
    .line 1906
    .line 1907
    move-result v2

    .line 1908
    const v3, 0x7fffffff

    .line 1909
    .line 1910
    .line 1911
    if-eq v2, v3, :cond_1b

    .line 1912
    .line 1913
    invoke-interface {v1}, Lt8;->c()Lxi3;

    .line 1914
    .line 1915
    .line 1916
    move-result-object v2

    .line 1917
    iget-boolean v2, v2, Lxi3;->b:Z

    .line 1918
    .line 1919
    if-eqz v2, :cond_18

    .line 1920
    .line 1921
    iget-object v2, v0, Lxi3;->a:Lt8;

    .line 1922
    .line 1923
    invoke-interface {v2}, Lt8;->n()Z

    .line 1924
    .line 1925
    .line 1926
    move-result v2

    .line 1927
    if-eqz v2, :cond_17

    .line 1928
    .line 1929
    invoke-interface {v1}, Lt8;->n()Z

    .line 1930
    .line 1931
    .line 1932
    move-result v2

    .line 1933
    invoke-interface {v1, v8}, Lt8;->m(Z)V

    .line 1934
    .line 1935
    .line 1936
    invoke-interface {v1}, Lt8;->v()V

    .line 1937
    .line 1938
    .line 1939
    invoke-interface {v1, v2}, Lt8;->m(Z)V

    .line 1940
    .line 1941
    .line 1942
    goto :goto_e

    .line 1943
    :cond_17
    invoke-interface {v1}, Lt8;->v()V

    .line 1944
    .line 1945
    .line 1946
    :cond_18
    :goto_e
    invoke-interface {v1}, Lt8;->c()Lxi3;

    .line 1947
    .line 1948
    .line 1949
    move-result-object v2

    .line 1950
    iget-object v2, v2, Lxi3;->i:Ljava/util/HashMap;

    .line 1951
    .line 1952
    invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 1953
    .line 1954
    .line 1955
    move-result-object v2

    .line 1956
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 1957
    .line 1958
    .line 1959
    move-result-object v2

    .line 1960
    :goto_f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1961
    .line 1962
    .line 1963
    move-result v3

    .line 1964
    if-eqz v3, :cond_19

    .line 1965
    .line 1966
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1967
    .line 1968
    .line 1969
    move-result-object v3

    .line 1970
    check-cast v3, Ljava/util/Map$Entry;

    .line 1971
    .line 1972
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1973
    .line 1974
    .line 1975
    move-result-object v4

    .line 1976
    check-cast v4, Lp8;

    .line 1977
    .line 1978
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1979
    .line 1980
    .line 1981
    move-result-object v3

    .line 1982
    check-cast v3, Ljava/lang/Number;

    .line 1983
    .line 1984
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 1985
    .line 1986
    .line 1987
    move-result v3

    .line 1988
    invoke-interface {v1}, Lt8;->t()Ls73;

    .line 1989
    .line 1990
    .line 1991
    move-result-object v5

    .line 1992
    invoke-virtual {v0, v4, v3, v5}, Lxi3;->a(Lp8;ILhs4;)V

    .line 1993
    .line 1994
    .line 1995
    goto :goto_f

    .line 1996
    :cond_19
    invoke-interface {v1}, Lt8;->t()Ls73;

    .line 1997
    .line 1998
    .line 1999
    move-result-object v1

    .line 2000
    iget-object v1, v1, Lhs4;->D:Lhs4;

    .line 2001
    .line 2002
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2003
    .line 2004
    .line 2005
    :goto_10
    iget-object v2, v0, Lxi3;->a:Lt8;

    .line 2006
    .line 2007
    invoke-interface {v2}, Lt8;->t()Ls73;

    .line 2008
    .line 2009
    .line 2010
    move-result-object v2

    .line 2011
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 2012
    .line 2013
    .line 2014
    move-result v2

    .line 2015
    if-nez v2, :cond_1b

    .line 2016
    .line 2017
    invoke-virtual {v0, v1}, Lxi3;->b(Lhs4;)Ljava/util/Map;

    .line 2018
    .line 2019
    .line 2020
    move-result-object v2

    .line 2021
    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 2022
    .line 2023
    .line 2024
    move-result-object v2

    .line 2025
    check-cast v2, Ljava/lang/Iterable;

    .line 2026
    .line 2027
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 2028
    .line 2029
    .line 2030
    move-result-object v2

    .line 2031
    :goto_11
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 2032
    .line 2033
    .line 2034
    move-result v3

    .line 2035
    if-eqz v3, :cond_1a

    .line 2036
    .line 2037
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2038
    .line 2039
    .line 2040
    move-result-object v3

    .line 2041
    check-cast v3, Lp8;

    .line 2042
    .line 2043
    invoke-virtual {v0, v1, v3}, Lxi3;->c(Lhs4;Lp8;)I

    .line 2044
    .line 2045
    .line 2046
    move-result v4

    .line 2047
    invoke-virtual {v0, v3, v4, v1}, Lxi3;->a(Lp8;ILhs4;)V

    .line 2048
    .line 2049
    .line 2050
    goto :goto_11

    .line 2051
    :cond_1a
    iget-object v1, v1, Lhs4;->D:Lhs4;

    .line 2052
    .line 2053
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2054
    .line 2055
    .line 2056
    goto :goto_10

    .line 2057
    :cond_1b
    return-object v10

    .line 2058
    :pswitch_1a
    check-cast v0, Lo7;

    .line 2059
    .line 2060
    check-cast v1, Lx97;

    .line 2061
    .line 2062
    iget-object v2, v0, Lo7;->y:Lf75;

    .line 2063
    .line 2064
    invoke-virtual {v2}, Lf75;->getValue()Ljava/lang/Object;

    .line 2065
    .line 2066
    .line 2067
    move-result-object v2

    .line 2068
    check-cast v2, Landroid/content/res/Configuration;

    .line 2069
    .line 2070
    iget-object v2, v0, Lo7;->x:Llh2;

    .line 2071
    .line 2072
    iget-object v3, v0, Lo7;->z:Lf75;

    .line 2073
    .line 2074
    invoke-virtual {v3}, Lf75;->getValue()Ljava/lang/Object;

    .line 2075
    .line 2076
    .line 2077
    move-result-object v3

    .line 2078
    check-cast v3, Landroid/content/Context;

    .line 2079
    .line 2080
    if-nez v3, :cond_1c

    .line 2081
    .line 2082
    sget-object v3, Llb;->b:Lx51;

    .line 2083
    .line 2084
    invoke-static {v0, v3}, Lxj;->N(Lr51;Lch5;)Ljava/lang/Object;

    .line 2085
    .line 2086
    .line 2087
    move-result-object v0

    .line 2088
    move-object v3, v0

    .line 2089
    check-cast v3, Landroid/content/Context;

    .line 2090
    .line 2091
    :cond_1c
    invoke-interface {v2, v1, v3}, Llh2;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2092
    .line 2093
    .line 2094
    return-object v10

    .line 2095
    :pswitch_1b
    check-cast v0, Ls95;

    .line 2096
    .line 2097
    check-cast v1, Ljava/util/Map$Entry;

    .line 2098
    .line 2099
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2100
    .line 2101
    .line 2102
    new-instance v2, Ljava/lang/StringBuilder;

    .line 2103
    .line 2104
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 2105
    .line 2106
    .line 2107
    move-result-object v3

    .line 2108
    const-string v4, "(this Map)"

    .line 2109
    .line 2110
    if-ne v3, v0, :cond_1d

    .line 2111
    .line 2112
    move-object v3, v4

    .line 2113
    goto :goto_12

    .line 2114
    :cond_1d
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 2115
    .line 2116
    .line 2117
    move-result-object v3

    .line 2118
    :goto_12
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 2119
    .line 2120
    .line 2121
    const/16 v3, 0x3d

    .line 2122
    .line 2123
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 2124
    .line 2125
    .line 2126
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 2127
    .line 2128
    .line 2129
    move-result-object v1

    .line 2130
    if-eq v1, v0, :cond_1e

    .line 2131
    .line 2132
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 2133
    .line 2134
    .line 2135
    move-result-object v4

    .line 2136
    :cond_1e
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2137
    .line 2138
    .line 2139
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2140
    .line 2141
    .line 2142
    move-result-object v0

    .line 2143
    return-object v0

    .line 2144
    :pswitch_1c
    check-cast v0, Ly2;

    .line 2145
    .line 2146
    if-ne v1, v0, :cond_1f

    .line 2147
    .line 2148
    const-string v0, "(this Collection)"

    .line 2149
    .line 2150
    goto :goto_13

    .line 2151
    :cond_1f
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 2152
    .line 2153
    .line 2154
    move-result-object v0

    .line 2155
    :goto_13
    return-object v0

    .line 2156
    nop

    .line 2157
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
