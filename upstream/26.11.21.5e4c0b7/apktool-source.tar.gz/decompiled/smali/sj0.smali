.class public final Lsj0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# static fields
.field public static final e:Lsj0;

.field public static final f:Ljava/lang/ThreadLocal;


# instance fields
.field public final a:F

.field public final b:F

.field public final c:F

.field public final d:F


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lsj0;

    .line 2
    .line 3
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 4
    .line 5
    invoke-direct {v0, v1, v1, v1, v1}, Lsj0;-><init>(FFFF)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lsj0;->e:Lsj0;

    .line 9
    .line 10
    new-instance v0, Lj8;

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    invoke-direct {v0, v1}, Lj8;-><init>(B)V

    .line 14
    .line 15
    .line 16
    invoke-static {v0}, Ljava/lang/ThreadLocal;->withInitial(Ljava/util/function/Supplier;)Ljava/lang/ThreadLocal;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lsj0;->f:Ljava/lang/ThreadLocal;

    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>(FFFF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lsj0;->a:F

    .line 5
    .line 6
    iput p2, p0, Lsj0;->b:F

    .line 7
    .line 8
    iput p3, p0, Lsj0;->c:F

    .line 9
    .line 10
    iput p4, p0, Lsj0;->d:F

    .line 11
    .line 12
    return-void
.end method

.method public static a(Ljava/lang/StringBuilder;Ljava/lang/String;F)V
    .locals 2

    .line 1
    invoke-static {p2}, Ljava/lang/Float;->isNaN(F)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-lez v0, :cond_1

    .line 13
    .line 14
    const/16 v0, 0x2c

    .line 15
    .line 16
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    :cond_1
    const/16 v0, 0x27

    .line 20
    .line 21
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string p1, "\' "

    .line 28
    .line 29
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    sget-object p1, Lsj0;->f:Ljava/lang/ThreadLocal;

    .line 33
    .line 34
    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    check-cast p1, Ljava/text/DecimalFormat;

    .line 42
    .line 43
    float-to-double v0, p2

    .line 44
    invoke-virtual {p1, v0, v1}, Ljava/text/NumberFormat;->format(D)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    return-void
.end method


# virtual methods
.method public final b()Lrj0;
    .locals 2

    .line 1
    new-instance v0, Lrj0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 7
    .line 8
    iput v1, v0, Lrj0;->b:F

    .line 9
    .line 10
    iput v1, v0, Lrj0;->c:F

    .line 11
    .line 12
    iput v1, v0, Lrj0;->d:F

    .line 13
    .line 14
    iput v1, v0, Lrj0;->e:F

    .line 15
    .line 16
    invoke-virtual {v0, p0}, Lrj0;->e(Lsj0;)V

    .line 17
    .line 18
    .line 19
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lsj0;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lsj0;

    .line 12
    .line 13
    iget v1, p0, Lsj0;->a:F

    .line 14
    .line 15
    iget v3, p1, Lsj0;->a:F

    .line 16
    .line 17
    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget v1, p0, Lsj0;->b:F

    .line 25
    .line 26
    iget v3, p1, Lsj0;->b:F

    .line 27
    .line 28
    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    iget v1, p0, Lsj0;->c:F

    .line 36
    .line 37
    iget v3, p1, Lsj0;->c:F

    .line 38
    .line 39
    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_4

    .line 44
    .line 45
    return v2

    .line 46
    :cond_4
    iget p0, p0, Lsj0;->d:F

    .line 47
    .line 48
    iget p1, p1, Lsj0;->d:F

    .line 49
    .line 50
    invoke-static {p0, p1}, Ljava/lang/Float;->compare(FF)I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    if-eqz p0, :cond_5

    .line 55
    .line 56
    return v2

    .line 57
    :cond_5
    return v0
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    iget v0, p0, Lsj0;->a:F

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, Lsj0;->b:F

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, Lv22;->c(FII)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget v2, p0, Lsj0;->c:F

    .line 17
    .line 18
    invoke-static {v2, v0, v1}, Lv22;->c(FII)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget p0, p0, Lsj0;->d:F

    .line 23
    .line 24
    invoke-static {p0}, Ljava/lang/Float;->hashCode(F)I

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    add-int/2addr p0, v0

    .line 29
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "wght"

    .line 7
    .line 8
    iget v2, p0, Lsj0;->a:F

    .line 9
    .line 10
    invoke-static {v0, v1, v2}, Lsj0;->a(Ljava/lang/StringBuilder;Ljava/lang/String;F)V

    .line 11
    .line 12
    .line 13
    const-string v1, "ital"

    .line 14
    .line 15
    iget v2, p0, Lsj0;->b:F

    .line 16
    .line 17
    invoke-static {v0, v1, v2}, Lsj0;->a(Ljava/lang/StringBuilder;Ljava/lang/String;F)V

    .line 18
    .line 19
    .line 20
    const-string v1, "slnt"

    .line 21
    .line 22
    iget v2, p0, Lsj0;->c:F

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, Lsj0;->a(Ljava/lang/StringBuilder;Ljava/lang/String;F)V

    .line 25
    .line 26
    .line 27
    const-string v1, "wdth"

    .line 28
    .line 29
    iget p0, p0, Lsj0;->d:F

    .line 30
    .line 31
    invoke-static {v0, v1, p0}, Lsj0;->a(Ljava/lang/StringBuilder;Ljava/lang/String;F)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    return-object p0
.end method
