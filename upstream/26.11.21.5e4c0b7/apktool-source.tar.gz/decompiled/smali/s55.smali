.class public final Ls55;
.super Lgd1;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public k:I

.field public l:Ltx6;

.field public synthetic m:Ljava/lang/Object;

.field public final synthetic n:Lu55;

.field public o:I


# direct methods
.method public constructor <init>(Lu55;Lfd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ls55;->n:Lu55;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lgd1;-><init>(Lfd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iput-object p1, p0, Ls55;->m:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Ls55;->o:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Ls55;->o:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    const/4 v0, 0x0

    .line 12
    iget-object v1, p0, Ls55;->n:Lu55;

    .line 13
    .line 14
    invoke-virtual {v1, p1, v0, p0}, Lu55;->d(ILtx6;Lfd1;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    return-object p0
.end method
