.class public final Lhj3;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lm27;


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    return-void
.end method
