.class public abstract Lvl6;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhx7;


# static fields
.field public static a:La53;

.field public static b:La53;


# direct methods
.method public static final A(Lki2;)Ldy7;
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v1, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-virtual {p0}, Lki2;->T()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    sget-object v3, Lz41;->a:Lql0;

    .line 9
    .line 10
    if-ne v2, v3, :cond_0

    .line 11
    .line 12
    new-instance v2, Lpt7;

    .line 13
    .line 14
    const/16 v4, 0xf

    .line 15
    .line 16
    invoke-direct {v2, v4}, Lpt7;-><init>(B)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0, v2}, Lki2;->q0(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    check-cast v2, Lwg2;

    .line 23
    .line 24
    const/16 v4, 0x30

    .line 25
    .line 26
    invoke-static {v1, v2, p0, v4}, Le43;->P([Ljava/lang/Object;Lwg2;Lki2;I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Lzd4;

    .line 31
    .line 32
    new-array v2, v0, [Ljava/lang/Object;

    .line 33
    .line 34
    invoke-virtual {p0}, Lki2;->T()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    if-ne v5, v3, :cond_1

    .line 39
    .line 40
    new-instance v5, Lpt7;

    .line 41
    .line 42
    const/16 v6, 0x10

    .line 43
    .line 44
    invoke-direct {v5, v6}, Lpt7;-><init>(B)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    :cond_1
    check-cast v5, Lwg2;

    .line 51
    .line 52
    invoke-static {v2, v5, p0, v4}, Le43;->P([Ljava/lang/Object;Lwg2;Lki2;I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    check-cast v2, Lzd4;

    .line 57
    .line 58
    new-array v0, v0, [Ljava/lang/Object;

    .line 59
    .line 60
    invoke-virtual {p0}, Lki2;->T()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v5

    .line 64
    if-ne v5, v3, :cond_2

    .line 65
    .line 66
    new-instance v5, Lpt7;

    .line 67
    .line 68
    const/16 v6, 0x11

    .line 69
    .line 70
    invoke-direct {v5, v6}, Lpt7;-><init>(B)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p0, v5}, Lki2;->q0(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_2
    check-cast v5, Lwg2;

    .line 77
    .line 78
    invoke-static {v0, v5, p0, v4}, Le43;->P([Ljava/lang/Object;Lwg2;Lki2;I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Lzd4;

    .line 83
    .line 84
    invoke-virtual {p0}, Lki2;->T()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    if-ne v4, v3, :cond_3

    .line 89
    .line 90
    new-instance v4, Ldy7;

    .line 91
    .line 92
    invoke-direct {v4, v1, v2, v0}, Ldy7;-><init>(Lzd4;Lzd4;Lzd4;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    :cond_3
    check-cast v4, Ldy7;

    .line 99
    .line 100
    return-object v4
.end method

.method public static B(Landroid/widget/TextView;I)V
    .locals 2

    .line 1
    if-ltz p1, :cond_1

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->getFontMetricsInt(Landroid/graphics/Paint$FontMetricsInt;)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eq p1, v0, :cond_0

    .line 13
    .line 14
    sub-int/2addr p1, v0

    .line 15
    int-to-float p1, p1

    .line 16
    const/high16 v0, 0x3f800000    # 1.0f

    .line 17
    .line 18
    invoke-virtual {p0, p1, v0}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void

    .line 22
    :cond_1
    invoke-static {}, Lqs5;->b()V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public static C(Ljava/lang/Object;)Ljava/util/Set;
    .locals 0

    .line 1
    invoke-static {p0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    return-object p0
.end method

.method public static D(Ljava/lang/String;)Lht7;
    .locals 15

    .line 1
    sget-object v2, Lx75;->i:Ljava/lang/String;

    .line 2
    .line 3
    const-string v0, "/"

    .line 4
    .line 5
    invoke-static {v2, v0}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v3, 0x0

    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    invoke-static {p0, v2, v0, v3}, Lx07;->D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    move-object v1, v0

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v1, p0

    .line 19
    :goto_0
    const/4 v0, 0x1

    .line 20
    const/4 v4, -0x1

    .line 21
    move v8, v0

    .line 22
    move v5, v3

    .line 23
    move v6, v4

    .line 24
    move v7, v6

    .line 25
    move v9, v7

    .line 26
    move v10, v9

    .line 27
    move v11, v10

    .line 28
    :goto_1
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 29
    .line 30
    .line 31
    move-result v12

    .line 32
    if-ge v5, v12, :cond_7

    .line 33
    .line 34
    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    .line 35
    .line 36
    .line 37
    move-result v12

    .line 38
    const/16 v13, 0x23

    .line 39
    .line 40
    if-eq v12, v13, :cond_5

    .line 41
    .line 42
    const/16 v13, 0x2f

    .line 43
    .line 44
    if-eq v12, v13, :cond_3

    .line 45
    .line 46
    const/16 v14, 0x3a

    .line 47
    .line 48
    if-eq v12, v14, :cond_1

    .line 49
    .line 50
    const/16 v13, 0x3f

    .line 51
    .line 52
    if-ne v12, v13, :cond_6

    .line 53
    .line 54
    if-ne v9, v4, :cond_6

    .line 55
    .line 56
    if-ne v6, v4, :cond_6

    .line 57
    .line 58
    add-int/lit8 v9, v5, 0x1

    .line 59
    .line 60
    goto :goto_3

    .line 61
    :cond_1
    if-eqz v8, :cond_6

    .line 62
    .line 63
    if-ne v9, v4, :cond_6

    .line 64
    .line 65
    if-ne v6, v4, :cond_6

    .line 66
    .line 67
    add-int/lit8 v12, v5, 0x2

    .line 68
    .line 69
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 70
    .line 71
    .line 72
    move-result v14

    .line 73
    if-ge v12, v14, :cond_2

    .line 74
    .line 75
    add-int/lit8 v14, v5, 0x1

    .line 76
    .line 77
    invoke-virtual {p0, v14}, Ljava/lang/String;->charAt(I)C

    .line 78
    .line 79
    .line 80
    move-result v14

    .line 81
    if-ne v14, v13, :cond_2

    .line 82
    .line 83
    invoke-virtual {p0, v12}, Ljava/lang/String;->charAt(I)C

    .line 84
    .line 85
    .line 86
    move-result v14

    .line 87
    if-ne v14, v13, :cond_2

    .line 88
    .line 89
    if-ne v7, v4, :cond_2

    .line 90
    .line 91
    add-int/lit8 v10, v5, 0x3

    .line 92
    .line 93
    move v8, v3

    .line 94
    move v11, v5

    .line 95
    move v5, v12

    .line 96
    goto :goto_3

    .line 97
    :cond_2
    invoke-virtual {v1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v12

    .line 101
    if-eqz v12, :cond_6

    .line 102
    .line 103
    add-int/lit8 v7, v5, 0x1

    .line 104
    .line 105
    move v11, v5

    .line 106
    move v5, v7

    .line 107
    move v10, v5

    .line 108
    goto :goto_3

    .line 109
    :cond_3
    if-ne v7, v4, :cond_6

    .line 110
    .line 111
    if-ne v9, v4, :cond_6

    .line 112
    .line 113
    if-ne v6, v4, :cond_6

    .line 114
    .line 115
    if-ne v10, v4, :cond_4

    .line 116
    .line 117
    move v7, v3

    .line 118
    goto :goto_2

    .line 119
    :cond_4
    move v7, v5

    .line 120
    :goto_2
    move v8, v3

    .line 121
    goto :goto_3

    .line 122
    :cond_5
    if-ne v6, v4, :cond_6

    .line 123
    .line 124
    add-int/lit8 v6, v5, 0x1

    .line 125
    .line 126
    :cond_6
    :goto_3
    add-int/2addr v5, v0

    .line 127
    goto :goto_1

    .line 128
    :cond_7
    const p0, 0x7fffffff

    .line 129
    .line 130
    .line 131
    if-ne v6, v4, :cond_8

    .line 132
    .line 133
    move v0, p0

    .line 134
    goto :goto_4

    .line 135
    :cond_8
    add-int/lit8 v0, v6, -0x1

    .line 136
    .line 137
    :goto_4
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 138
    .line 139
    .line 140
    move-result v5

    .line 141
    invoke-static {v0, v5}, Ljava/lang/Math;->min(II)I

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-ne v9, v4, :cond_9

    .line 146
    .line 147
    move v5, p0

    .line 148
    goto :goto_5

    .line 149
    :cond_9
    add-int/lit8 v5, v9, -0x1

    .line 150
    .line 151
    :goto_5
    invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I

    .line 152
    .line 153
    .line 154
    move-result v5

    .line 155
    const/4 v8, 0x0

    .line 156
    if-eq v10, v4, :cond_b

    .line 157
    .line 158
    invoke-virtual {v1, v3, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v11

    .line 162
    if-eq v7, v4, :cond_a

    .line 163
    .line 164
    move p0, v7

    .line 165
    :cond_a
    invoke-static {p0, v5}, Ljava/lang/Math;->min(II)I

    .line 166
    .line 167
    .line 168
    move-result p0

    .line 169
    invoke-virtual {v1, v10, p0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object p0

    .line 173
    goto :goto_6

    .line 174
    :cond_b
    move-object p0, v8

    .line 175
    move-object v11, p0

    .line 176
    :goto_6
    if-eq v7, v4, :cond_c

    .line 177
    .line 178
    invoke-virtual {v1, v7, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v5

    .line 182
    goto :goto_7

    .line 183
    :cond_c
    move-object v5, v8

    .line 184
    :goto_7
    if-eq v9, v4, :cond_d

    .line 185
    .line 186
    invoke-virtual {v1, v9, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    goto :goto_8

    .line 191
    :cond_d
    move-object v0, v8

    .line 192
    :goto_8
    if-eq v6, v4, :cond_e

    .line 193
    .line 194
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 195
    .line 196
    .line 197
    move-result v4

    .line 198
    invoke-virtual {v1, v6, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 199
    .line 200
    .line 201
    move-result-object v4

    .line 202
    goto :goto_9

    .line 203
    :cond_e
    move-object v4, v8

    .line 204
    :goto_9
    if-eqz v11, :cond_f

    .line 205
    .line 206
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    .line 207
    .line 208
    .line 209
    move-result v6

    .line 210
    goto :goto_a

    .line 211
    :cond_f
    move v6, v3

    .line 212
    :goto_a
    if-eqz p0, :cond_10

    .line 213
    .line 214
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 215
    .line 216
    .line 217
    move-result v7

    .line 218
    goto :goto_b

    .line 219
    :cond_10
    move v7, v3

    .line 220
    :goto_b
    if-eqz v5, :cond_11

    .line 221
    .line 222
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 223
    .line 224
    .line 225
    move-result v9

    .line 226
    goto :goto_c

    .line 227
    :cond_11
    move v9, v3

    .line 228
    :goto_c
    if-eqz v0, :cond_12

    .line 229
    .line 230
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 231
    .line 232
    .line 233
    move-result v10

    .line 234
    goto :goto_d

    .line 235
    :cond_12
    move v10, v3

    .line 236
    :goto_d
    if-eqz v4, :cond_13

    .line 237
    .line 238
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 239
    .line 240
    .line 241
    move-result v12

    .line 242
    goto :goto_e

    .line 243
    :cond_13
    move v12, v3

    .line 244
    :goto_e
    invoke-static {v10, v12}, Ljava/lang/Math;->max(II)I

    .line 245
    .line 246
    .line 247
    move-result v10

    .line 248
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 249
    .line 250
    .line 251
    move-result v9

    .line 252
    invoke-static {v7, v9}, Ljava/lang/Math;->max(II)I

    .line 253
    .line 254
    .line 255
    move-result v7

    .line 256
    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    .line 257
    .line 258
    .line 259
    move-result v6

    .line 260
    add-int/lit8 v6, v6, -0x2

    .line 261
    .line 262
    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    .line 263
    .line 264
    .line 265
    move-result v3

    .line 266
    new-array v3, v3, [B

    .line 267
    .line 268
    move-object v6, v0

    .line 269
    new-instance v0, Lht7;

    .line 270
    .line 271
    if-eqz v11, :cond_14

    .line 272
    .line 273
    invoke-static {v11, v3}, Lvl6;->y(Ljava/lang/String;[B)Ljava/lang/String;

    .line 274
    .line 275
    .line 276
    move-result-object v7

    .line 277
    goto :goto_f

    .line 278
    :cond_14
    move-object v7, v8

    .line 279
    :goto_f
    if-eqz p0, :cond_15

    .line 280
    .line 281
    invoke-static {p0, v3}, Lvl6;->y(Ljava/lang/String;[B)Ljava/lang/String;

    .line 282
    .line 283
    .line 284
    move-result-object p0

    .line 285
    goto :goto_10

    .line 286
    :cond_15
    move-object p0, v8

    .line 287
    :goto_10
    if-eqz v5, :cond_16

    .line 288
    .line 289
    invoke-static {v5, v3}, Lvl6;->y(Ljava/lang/String;[B)Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v8

    .line 293
    :cond_16
    move-object v5, v8

    .line 294
    if-eqz v6, :cond_17

    .line 295
    .line 296
    invoke-static {v6, v3}, Lvl6;->y(Ljava/lang/String;[B)Ljava/lang/String;

    .line 297
    .line 298
    .line 299
    :cond_17
    if-eqz v4, :cond_18

    .line 300
    .line 301
    invoke-static {v4, v3}, Lvl6;->y(Ljava/lang/String;[B)Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    :cond_18
    move-object v4, p0

    .line 305
    move-object v3, v7

    .line 306
    invoke-direct/range {v0 .. v5}, Lht7;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 307
    .line 308
    .line 309
    return-object v0
.end method

.method public static d(Ljava/lang/String;)Lht7;
    .locals 6

    .line 1
    sget-object v2, Lx75;->i:Ljava/lang/String;

    .line 2
    .line 3
    new-instance v0, Lht7;

    .line 4
    .line 5
    new-instance v1, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    const-string v3, "file:"

    .line 11
    .line 12
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    if-eqz p0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    :cond_0
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const-string v3, "file"

    .line 25
    .line 26
    const/4 v4, 0x0

    .line 27
    move-object v5, p0

    .line 28
    invoke-direct/range {v0 .. v5}, Lht7;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-object v0
.end method

.method public static final e(Lgd;FFFFZ)V
    .locals 14

    .line 1
    move/from16 v4, p2

    .line 2
    .line 3
    move/from16 v1, p3

    .line 4
    .line 5
    iget-object v7, p0, Lgd;->a:Landroid/graphics/Path;

    .line 6
    .line 7
    const/4 v8, 0x0

    .line 8
    cmpg-float v2, p1, v8

    .line 9
    .line 10
    if-lez v2, :cond_b

    .line 11
    .line 12
    cmpg-float v2, v4, v8

    .line 13
    .line 14
    if-lez v2, :cond_b

    .line 15
    .line 16
    const-string v2, "Invalid rectangle, make sure no value is NaN"

    .line 17
    .line 18
    const/high16 v5, 0x3f000000    # 0.5f

    .line 19
    .line 20
    if-nez p5, :cond_5

    .line 21
    .line 22
    invoke-static {v8, v1}, Ljava/lang/Math;->max(FF)F

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-static/range {p1 .. p2}, Ljava/lang/Math;->min(FF)F

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    mul-float/2addr v6, v5

    .line 31
    cmpl-float v5, v1, v6

    .line 32
    .line 33
    if-lez v5, :cond_0

    .line 34
    .line 35
    move v1, v6

    .line 36
    :cond_0
    cmpg-float v5, v1, v8

    .line 37
    .line 38
    if-gtz v5, :cond_4

    .line 39
    .line 40
    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-nez v1, :cond_1

    .line 45
    .line 46
    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_2

    .line 51
    .line 52
    :cond_1
    invoke-static {v2}, Lid;->b(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    :cond_2
    iget-object v1, p0, Lgd;->b:Landroid/graphics/RectF;

    .line 56
    .line 57
    if-nez v1, :cond_3

    .line 58
    .line 59
    new-instance v1, Landroid/graphics/RectF;

    .line 60
    .line 61
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 62
    .line 63
    .line 64
    iput-object v1, p0, Lgd;->b:Landroid/graphics/RectF;

    .line 65
    .line 66
    :cond_3
    invoke-virtual {v1, v8, v8, p1, v4}, Landroid/graphics/RectF;->set(FFFF)V

    .line 67
    .line 68
    .line 69
    iget-object v0, p0, Lgd;->b:Landroid/graphics/RectF;

    .line 70
    .line 71
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 72
    .line 73
    .line 74
    sget-object v1, Landroid/graphics/Path$Direction;->CCW:Landroid/graphics/Path$Direction;

    .line 75
    .line 76
    invoke-virtual {v7, v0, v1}, Landroid/graphics/Path;->addRect(Landroid/graphics/RectF;Landroid/graphics/Path$Direction;)V

    .line 77
    .line 78
    .line 79
    return-void

    .line 80
    :cond_4
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    int-to-long v5, v2

    .line 85
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 86
    .line 87
    .line 88
    move-result v1

    .line 89
    int-to-long v1, v1

    .line 90
    const/16 v7, 0x20

    .line 91
    .line 92
    shl-long/2addr v5, v7

    .line 93
    const-wide v7, 0xffffffffL

    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    and-long/2addr v1, v7

    .line 99
    or-long/2addr v5, v1

    .line 100
    const/4 v1, 0x0

    .line 101
    const/4 v2, 0x0

    .line 102
    move v3, p1

    .line 103
    invoke-static/range {v1 .. v6}, Le43;->p(FFFFJ)Lq06;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-static {p0, v1}, Lgd;->c(Lgd;Lq06;)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :cond_5
    move v9, v4

    .line 112
    const/high16 v4, 0x3f800000    # 1.0f

    .line 113
    .line 114
    const/high16 v6, 0x40000000    # 2.0f

    .line 115
    .line 116
    move/from16 v10, p4

    .line 117
    .line 118
    invoke-static {v10, v4, v6}, Ls33;->D(FFF)F

    .line 119
    .line 120
    .line 121
    move-result v4

    .line 122
    invoke-static/range {p1 .. p2}, Ljava/lang/Math;->min(FF)F

    .line 123
    .line 124
    .line 125
    move-result v6

    .line 126
    mul-float/2addr v6, v5

    .line 127
    mul-float/2addr v1, v4

    .line 128
    invoke-static {v8, v1}, Ljava/lang/Math;->max(FF)F

    .line 129
    .line 130
    .line 131
    move-result v1

    .line 132
    cmpl-float v4, v1, v6

    .line 133
    .line 134
    if-lez v4, :cond_6

    .line 135
    .line 136
    move v5, v6

    .line 137
    goto :goto_0

    .line 138
    :cond_6
    move v5, v1

    .line 139
    :goto_0
    cmpg-float v1, v5, v8

    .line 140
    .line 141
    if-gtz v1, :cond_a

    .line 142
    .line 143
    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    if-nez v1, :cond_7

    .line 148
    .line 149
    invoke-static {v9}, Ljava/lang/Float;->isNaN(F)Z

    .line 150
    .line 151
    .line 152
    move-result v1

    .line 153
    if-eqz v1, :cond_8

    .line 154
    .line 155
    :cond_7
    invoke-static {v2}, Lid;->b(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    :cond_8
    iget-object v1, p0, Lgd;->b:Landroid/graphics/RectF;

    .line 159
    .line 160
    if-nez v1, :cond_9

    .line 161
    .line 162
    new-instance v1, Landroid/graphics/RectF;

    .line 163
    .line 164
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 165
    .line 166
    .line 167
    iput-object v1, p0, Lgd;->b:Landroid/graphics/RectF;

    .line 168
    .line 169
    :cond_9
    invoke-virtual {v1, v8, v8, p1, v9}, Landroid/graphics/RectF;->set(FFFF)V

    .line 170
    .line 171
    .line 172
    iget-object v0, p0, Lgd;->b:Landroid/graphics/RectF;

    .line 173
    .line 174
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 175
    .line 176
    .line 177
    sget-object v1, Landroid/graphics/Path$Direction;->CCW:Landroid/graphics/Path$Direction;

    .line 178
    .line 179
    invoke-virtual {v7, v0, v1}, Landroid/graphics/Path;->addRect(Landroid/graphics/RectF;Landroid/graphics/Path$Direction;)V

    .line 180
    .line 181
    .line 182
    return-void

    .line 183
    :cond_a
    const v1, 0x3eb6c8b4    # 0.357f

    .line 184
    .line 185
    .line 186
    mul-float/2addr v1, v5

    .line 187
    invoke-virtual {p0, v5, v8}, Lgd;->g(FF)V

    .line 188
    .line 189
    .line 190
    sub-float v10, p1, v5

    .line 191
    .line 192
    invoke-virtual {p0, v10, v8}, Lgd;->f(FF)V

    .line 193
    .line 194
    .line 195
    move v2, v1

    .line 196
    sub-float v1, p1, v2

    .line 197
    .line 198
    move v4, v2

    .line 199
    const/4 v2, 0x0

    .line 200
    move v6, v5

    .line 201
    move v5, p1

    .line 202
    move-object v0, p0

    .line 203
    move v3, p1

    .line 204
    invoke-virtual/range {v0 .. v6}, Lgd;->d(FFFFFF)V

    .line 205
    .line 206
    .line 207
    move v12, v4

    .line 208
    move v11, v6

    .line 209
    sub-float v13, v9, v11

    .line 210
    .line 211
    invoke-virtual {p0, p1, v13}, Lgd;->f(FF)V

    .line 212
    .line 213
    .line 214
    sub-float v2, v9, v12

    .line 215
    .line 216
    move/from16 v6, p2

    .line 217
    .line 218
    move v3, v1

    .line 219
    move v4, v9

    .line 220
    move v5, v10

    .line 221
    move v1, p1

    .line 222
    invoke-virtual/range {v0 .. v6}, Lgd;->d(FFFFFF)V

    .line 223
    .line 224
    .line 225
    invoke-virtual {p0, v11, v4}, Lgd;->f(FF)V

    .line 226
    .line 227
    .line 228
    const/4 v3, 0x0

    .line 229
    const/4 v5, 0x0

    .line 230
    move v0, v4

    .line 231
    move v4, v2

    .line 232
    move v2, v0

    .line 233
    move-object v0, p0

    .line 234
    move v1, v12

    .line 235
    move v6, v13

    .line 236
    invoke-virtual/range {v0 .. v6}, Lgd;->d(FFFFFF)V

    .line 237
    .line 238
    .line 239
    move v2, v1

    .line 240
    invoke-virtual {p0, v8, v11}, Lgd;->f(FF)V

    .line 241
    .line 242
    .line 243
    const/4 v4, 0x0

    .line 244
    const/4 v6, 0x0

    .line 245
    const/4 v1, 0x0

    .line 246
    move v3, v2

    .line 247
    move v5, v11

    .line 248
    invoke-virtual/range {v0 .. v6}, Lgd;->d(FFFFFF)V

    .line 249
    .line 250
    .line 251
    invoke-virtual {v7}, Landroid/graphics/Path;->close()V

    .line 252
    .line 253
    .line 254
    :cond_b
    return-void
.end method

.method public static final f(Lwf6;FLbj;Lpl1;Lvu6;Lgd1;)Ljava/lang/Object;
    .locals 9

    .line 1
    instance-of v0, p5, Lav6;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p5

    .line 6
    check-cast v0, Lav6;

    .line 7
    .line 8
    iget v1, v0, Lav6;->o:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lav6;->o:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lav6;

    .line 21
    .line 22
    invoke-direct {v0, p5}, Lgd1;-><init>(Lfd1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p5, v0, Lav6;->n:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lav6;->o:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    iget p1, v0, Lav6;->m:F

    .line 35
    .line 36
    iget-object p0, v0, Lav6;->l:Lxu5;

    .line 37
    .line 38
    iget-object p2, v0, Lav6;->k:Lbj;

    .line 39
    .line 40
    invoke-static {p5}, Ls33;->p0(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_2

    .line 44
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p0}, Lt32;->d(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    const/4 p0, 0x0

    .line 50
    return-object p0

    .line 51
    :cond_2
    invoke-static {p5}, Ls33;->p0(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    new-instance v5, Lxu5;

    .line 55
    .line 56
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p2}, Lbj;->a()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p5

    .line 63
    check-cast p5, Ljava/lang/Number;

    .line 64
    .line 65
    invoke-virtual {p5}, Ljava/lang/Number;->floatValue()F

    .line 66
    .line 67
    .line 68
    move-result p5

    .line 69
    const/4 v1, 0x0

    .line 70
    cmpg-float p5, p5, v1

    .line 71
    .line 72
    if-nez p5, :cond_3

    .line 73
    .line 74
    move p5, v2

    .line 75
    goto :goto_1

    .line 76
    :cond_3
    const/4 p5, 0x0

    .line 77
    :goto_1
    xor-int/2addr p5, v2

    .line 78
    new-instance v3, Lnm0;

    .line 79
    .line 80
    const/4 v8, 0x3

    .line 81
    move-object v6, p0

    .line 82
    move v4, p1

    .line 83
    move-object v7, p4

    .line 84
    invoke-direct/range {v3 .. v8}, Lnm0;-><init>(FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 85
    .line 86
    .line 87
    iput-object p2, v0, Lav6;->k:Lbj;

    .line 88
    .line 89
    iput-object v5, v0, Lav6;->l:Lxu5;

    .line 90
    .line 91
    iput v4, v0, Lav6;->m:F

    .line 92
    .line 93
    iput v2, v0, Lav6;->o:I

    .line 94
    .line 95
    invoke-static {p2, p3, p5, v3, v0}, Lgk6;->f(Lbj;Lpl1;ZLhh2;Lgd1;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    sget-object p1, Lsi1;->h:Lsi1;

    .line 100
    .line 101
    if-ne p0, p1, :cond_4

    .line 102
    .line 103
    return-object p1

    .line 104
    :cond_4
    move p1, v4

    .line 105
    move-object p0, v5

    .line 106
    :goto_2
    new-instance p3, Lxi;

    .line 107
    .line 108
    iget p0, p0, Lxu5;->h:F

    .line 109
    .line 110
    sub-float/2addr p1, p0

    .line 111
    new-instance p0, Ljava/lang/Float;

    .line 112
    .line 113
    invoke-direct {p0, p1}, Ljava/lang/Float;-><init>(F)V

    .line 114
    .line 115
    .line 116
    invoke-direct {p3, p0, p2}, Lxi;-><init>(Ljava/lang/Float;Lbj;)V

    .line 117
    .line 118
    .line 119
    return-object p3
.end method

.method public static final g(Lzi;Lwf6;Lvu6;F)V
    .locals 1

    .line 1
    :try_start_0
    invoke-interface {p1, p3}, Lwf6;->a(F)F

    .line 2
    .line 3
    .line 4
    move-result p1
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 5
    goto :goto_0

    .line 6
    :catch_0
    invoke-virtual {p0}, Lzi;->a()V

    .line 7
    .line 8
    .line 9
    const/4 p1, 0x0

    .line 10
    :goto_0
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {p2, v0}, Lvu6;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    sub-float/2addr p3, p1

    .line 18
    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    const/high16 p2, 0x3f000000    # 0.5f

    .line 23
    .line 24
    cmpl-float p1, p1, p2

    .line 25
    .line 26
    if-lez p1, :cond_0

    .line 27
    .line 28
    invoke-virtual {p0}, Lzi;->a()V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void
.end method

.method public static final h(Lwf6;FFLbj;Laj;Lhh2;Lgd1;)Ljava/lang/Object;
    .locals 16

    .line 1
    move/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p6

    .line 4
    .line 5
    instance-of v2, v1, Lbv6;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    move-object v2, v1

    .line 10
    check-cast v2, Lbv6;

    .line 11
    .line 12
    iget v3, v2, Lbv6;->p:I

    .line 13
    .line 14
    const/high16 v4, -0x80000000

    .line 15
    .line 16
    and-int v5, v3, v4

    .line 17
    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    sub-int/2addr v3, v4

    .line 21
    iput v3, v2, Lbv6;->p:I

    .line 22
    .line 23
    :goto_0
    move-object v8, v2

    .line 24
    goto :goto_1

    .line 25
    :cond_0
    new-instance v2, Lbv6;

    .line 26
    .line 27
    invoke-direct {v2, v1}, Lgd1;-><init>(Lfd1;)V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :goto_1
    iget-object v1, v8, Lbv6;->o:Ljava/lang/Object;

    .line 32
    .line 33
    iget v2, v8, Lbv6;->p:I

    .line 34
    .line 35
    const/4 v9, 0x0

    .line 36
    const/4 v3, 0x1

    .line 37
    if-eqz v2, :cond_2

    .line 38
    .line 39
    if-ne v2, v3, :cond_1

    .line 40
    .line 41
    iget v0, v8, Lbv6;->n:F

    .line 42
    .line 43
    iget v2, v8, Lbv6;->m:F

    .line 44
    .line 45
    iget-object v3, v8, Lbv6;->l:Lxu5;

    .line 46
    .line 47
    iget-object v4, v8, Lbv6;->k:Lbj;

    .line 48
    .line 49
    invoke-static {v1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    move v1, v0

    .line 53
    move v0, v2

    .line 54
    goto :goto_3

    .line 55
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 56
    .line 57
    invoke-static {v0}, Lt32;->d(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    const/4 v0, 0x0

    .line 61
    return-object v0

    .line 62
    :cond_2
    invoke-static {v1}, Ls33;->p0(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    new-instance v12, Lxu5;

    .line 66
    .line 67
    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    .line 68
    .line 69
    .line 70
    invoke-virtual/range {p3 .. p3}, Lbj;->a()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    check-cast v1, Ljava/lang/Number;

    .line 75
    .line 76
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    new-instance v4, Ljava/lang/Float;

    .line 81
    .line 82
    invoke-direct {v4, v0}, Ljava/lang/Float;-><init>(F)V

    .line 83
    .line 84
    .line 85
    invoke-virtual/range {p3 .. p3}, Lbj;->a()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    check-cast v2, Ljava/lang/Number;

    .line 90
    .line 91
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    cmpg-float v2, v2, v9

    .line 96
    .line 97
    if-nez v2, :cond_3

    .line 98
    .line 99
    move v2, v3

    .line 100
    goto :goto_2

    .line 101
    :cond_3
    const/4 v2, 0x0

    .line 102
    :goto_2
    xor-int/lit8 v6, v2, 0x1

    .line 103
    .line 104
    new-instance v10, Lnm0;

    .line 105
    .line 106
    const/4 v15, 0x4

    .line 107
    move-object/from16 v13, p0

    .line 108
    .line 109
    move/from16 v11, p2

    .line 110
    .line 111
    move-object/from16 v14, p5

    .line 112
    .line 113
    invoke-direct/range {v10 .. v15}, Lnm0;-><init>(FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 114
    .line 115
    .line 116
    move-object/from16 v2, p3

    .line 117
    .line 118
    iput-object v2, v8, Lbv6;->k:Lbj;

    .line 119
    .line 120
    iput-object v12, v8, Lbv6;->l:Lxu5;

    .line 121
    .line 122
    iput v0, v8, Lbv6;->m:F

    .line 123
    .line 124
    iput v1, v8, Lbv6;->n:F

    .line 125
    .line 126
    iput v3, v8, Lbv6;->p:I

    .line 127
    .line 128
    move-object/from16 v5, p4

    .line 129
    .line 130
    move-object v3, v2

    .line 131
    move-object v7, v10

    .line 132
    invoke-static/range {v3 .. v8}, Lgk6;->g(Lbj;Ljava/lang/Object;Laj;ZLhh2;Lgd1;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v2

    .line 136
    sget-object v3, Lsi1;->h:Lsi1;

    .line 137
    .line 138
    if-ne v2, v3, :cond_4

    .line 139
    .line 140
    return-object v3

    .line 141
    :cond_4
    move-object/from16 v4, p3

    .line 142
    .line 143
    move-object v3, v12

    .line 144
    :goto_3
    invoke-virtual {v4}, Lbj;->a()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v2

    .line 148
    check-cast v2, Ljava/lang/Number;

    .line 149
    .line 150
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 151
    .line 152
    .line 153
    move-result v2

    .line 154
    invoke-static {v2, v1}, Lvl6;->m(FF)F

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    new-instance v2, Lxi;

    .line 159
    .line 160
    iget v3, v3, Lxu5;->h:F

    .line 161
    .line 162
    sub-float/2addr v0, v3

    .line 163
    new-instance v3, Ljava/lang/Float;

    .line 164
    .line 165
    invoke-direct {v3, v0}, Ljava/lang/Float;-><init>(F)V

    .line 166
    .line 167
    .line 168
    const/16 v0, 0x1d

    .line 169
    .line 170
    invoke-static {v4, v9, v1, v0}, Lcj;->E(Lbj;FFI)Lbj;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-direct {v2, v3, v0}, Lxi;-><init>(Ljava/lang/Float;Lbj;)V

    .line 175
    .line 176
    .line 177
    return-object v2
.end method

.method public static final i(Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x7f

    .line 6
    .line 7
    if-le v0, v1, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    :cond_0
    invoke-static {p0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public static j(Ltl6;)Ltl6;
    .locals 1

    .line 1
    iget-object v0, p0, Ltl6;->h:Lvx3;

    .line 2
    .line 3
    invoke-virtual {v0}, Lvx3;->b()Lvx3;

    .line 4
    .line 5
    .line 6
    iget v0, v0, Lvx3;->p:I

    .line 7
    .line 8
    if-lez v0, :cond_0

    .line 9
    .line 10
    return-object p0

    .line 11
    :cond_0
    sget-object p0, Ltl6;->i:Ltl6;

    .line 12
    .line 13
    return-object p0
.end method

.method public static final k(F)I
    .locals 2

    .line 1
    float-to-double v0, p0

    .line 2
    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    .line 3
    .line 4
    .line 5
    move-result-wide v0

    .line 6
    double-to-float p0, v0

    .line 7
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method

.method public static l(Ljava/io/InputStream;)V
    .locals 2

    .line 1
    :goto_0
    :try_start_0
    invoke-virtual {p0}, Ljava/io/InputStream;->available()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/io/InputStream;->available()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    int-to-long v0, v0

    .line 12
    invoke-virtual {p0, v0, v1}, Ljava/io/InputStream;->skip(J)J
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :catch_0
    :cond_0
    return-void
.end method

.method public static final m(FF)F
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    cmpg-float v1, p1, v0

    .line 3
    .line 4
    if-nez v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    cmpl-float v0, p1, v0

    .line 8
    .line 9
    if-lez v0, :cond_1

    .line 10
    .line 11
    cmpl-float v0, p0, p1

    .line 12
    .line 13
    if-lez v0, :cond_2

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_1
    cmpg-float v0, p0, p1

    .line 17
    .line 18
    if-gez v0, :cond_2

    .line 19
    .line 20
    :goto_0
    return p1

    .line 21
    :cond_2
    return p0
.end method

.method public static final n(Lkx;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lkx;->b:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    invoke-static {p2}, Lq07;->v0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public static final o(Lkx;)Lbs2;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, Lbs2;

    .line 5
    .line 6
    iget-object p0, p0, Lkx;->b:Ljava/util/ArrayList;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    new-array v1, v1, [Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    check-cast p0, [Ljava/lang/String;

    .line 16
    .line 17
    invoke-direct {v0, p0}, Lbs2;-><init>([Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method public static final p(Lbs2;I)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lbs2;->h:[Ljava/lang/String;

    .line 5
    .line 6
    shl-int/lit8 v0, p1, 0x1

    .line 7
    .line 8
    invoke-static {v0, p0}, Lnx;->T0(I[Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Ljava/lang/String;

    .line 13
    .line 14
    if-eqz p0, :cond_0

    .line 15
    .line 16
    return-object p0

    .line 17
    :cond_0
    new-instance p0, Ljava/lang/IndexOutOfBoundsException;

    .line 18
    .line 19
    new-instance v0, Ljava/lang/StringBuilder;

    .line 20
    .line 21
    const-string v1, "name["

    .line 22
    .line 23
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    const/16 p1, 0x5d

    .line 30
    .line 31
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-direct {p0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw p0
.end method

.method public static final q(Lbs2;)Lkx;
    .locals 2

    .line 1
    new-instance v0, Lkx;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, Lkx;-><init>(B)V

    .line 5
    .line 6
    .line 7
    iget-object v1, v0, Lkx;->b:Ljava/util/ArrayList;

    .line 8
    .line 9
    iget-object p0, p0, Lbs2;->h:[Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 22
    .line 23
    .line 24
    return-object v0
.end method

.method public static final r(Lbs2;I)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lbs2;->h:[Ljava/lang/String;

    .line 5
    .line 6
    shl-int/lit8 v0, p1, 0x1

    .line 7
    .line 8
    add-int/lit8 v0, v0, 0x1

    .line 9
    .line 10
    invoke-static {v0, p0}, Lnx;->T0(I[Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    check-cast p0, Ljava/lang/String;

    .line 15
    .line 16
    if-eqz p0, :cond_0

    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_0
    new-instance p0, Ljava/lang/IndexOutOfBoundsException;

    .line 20
    .line 21
    new-instance v0, Ljava/lang/StringBuilder;

    .line 22
    .line 23
    const-string v1, "value["

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const/16 p1, 0x5d

    .line 32
    .line 33
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    invoke-direct {p0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    throw p0
.end method

.method public static final s(Lht7;)Ljava/lang/String;
    .locals 6

    .line 1
    invoke-static {p0}, Lvl6;->t(Lht7;)Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lht7;->b:Ljava/lang/String;

    .line 6
    .line 7
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-eqz v2, :cond_0

    .line 12
    .line 13
    const/4 p0, 0x0

    .line 14
    return-object p0

    .line 15
    :cond_0
    iget-object v2, p0, Lht7;->e:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    invoke-static {v2, v1, v3}, Lx07;->G(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_1

    .line 26
    .line 27
    :goto_0
    move-object v2, v1

    .line 28
    goto :goto_1

    .line 29
    :cond_1
    const-string v1, ""

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :goto_1
    iget-object v1, p0, Lht7;->b:Ljava/lang/String;

    .line 33
    .line 34
    const/4 v4, 0x0

    .line 35
    const/16 v5, 0x3c

    .line 36
    .line 37
    const/4 v3, 0x0

    .line 38
    invoke-static/range {v0 .. v5}, Lxx0;->a1(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Lhh2;I)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0
.end method

.method public static final t(Lht7;)Ljava/util/List;
    .locals 5

    .line 1
    iget-object p0, p0, Lht7;->e:Ljava/lang/String;

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    sget-object p0, Lw12;->h:Lw12;

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 11
    .line 12
    .line 13
    const/4 v1, -0x1

    .line 14
    move v2, v1

    .line 15
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    if-ge v2, v3, :cond_3

    .line 20
    .line 21
    add-int/lit8 v2, v2, 0x1

    .line 22
    .line 23
    const/16 v3, 0x2f

    .line 24
    .line 25
    const/4 v4, 0x4

    .line 26
    invoke-static {p0, v3, v2, v4}, Lq07;->T(Ljava/lang/CharSequence;CII)I

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-ne v3, v1, :cond_1

    .line 31
    .line 32
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    :cond_1
    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    if-lez v4, :cond_2

    .line 45
    .line 46
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    :cond_2
    move v2, v3

    .line 50
    goto :goto_0

    .line 51
    :cond_3
    return-object v0
.end method

.method public static u(Ld17;Lmp0;I)Lxw6;
    .locals 8

    .line 1
    const-string v0, "failed to close "

    .line 2
    .line 3
    const-string v1, "StylesUtils"

    .line 4
    .line 5
    iget v2, p1, Lmp0;->b:I

    .line 6
    .line 7
    iget v3, p1, Lmp0;->c:I

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    if-eqz p0, :cond_4

    .line 11
    .line 12
    iget-object p0, p0, Ld17;->a:Lor;

    .line 13
    .line 14
    if-eqz p0, :cond_4

    .line 15
    .line 16
    new-instance v5, Lor;

    .line 17
    .line 18
    const/16 v6, 0x9

    .line 19
    .line 20
    const/4 v7, 0x0

    .line 21
    invoke-direct {v5, p0, v7, v6}, Lor;-><init>(Ljava/lang/Object;ZB)V

    .line 22
    .line 23
    .line 24
    const/4 p0, -0x1

    .line 25
    :try_start_0
    invoke-virtual {v5, v2}, Lor;->c(I)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v5}, Lor;->h()I

    .line 29
    .line 30
    .line 31
    move-result v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 32
    add-int/lit8 v2, v2, -0x1

    .line 33
    .line 34
    if-ne v2, p0, :cond_0

    .line 35
    .line 36
    :try_start_1
    invoke-virtual {v5, p0}, Lor;->c(I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 37
    .line 38
    .line 39
    return-object v4

    .line 40
    :catch_0
    move-exception p0

    .line 41
    new-instance p1, Ljava/lang/StringBuilder;

    .line 42
    .line 43
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-static {v1, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 54
    .line 55
    .line 56
    return-object v4

    .line 57
    :cond_0
    :goto_0
    :try_start_2
    invoke-virtual {v5}, Lor;->h()I

    .line 58
    .line 59
    .line 60
    move-result v6

    .line 61
    if-ge v7, v6, :cond_2

    .line 62
    .line 63
    invoke-virtual {v5, v7}, Lor;->t(I)Lxw6;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    invoke-interface {v6}, Lxw6;->h()I

    .line 68
    .line 69
    .line 70
    move-result v6

    .line 71
    if-le v6, v3, :cond_1

    .line 72
    .line 73
    add-int/lit8 v2, v7, -0x1

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_1
    add-int/lit8 v7, v7, 0x1

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_2
    :goto_1
    add-int/2addr v2, p2

    .line 80
    if-ltz v2, :cond_3

    .line 81
    .line 82
    invoke-virtual {v5}, Lor;->h()I

    .line 83
    .line 84
    .line 85
    move-result p2

    .line 86
    if-ge v2, p2, :cond_3

    .line 87
    .line 88
    invoke-virtual {v5, v2}, Lor;->t(I)Lxw6;

    .line 89
    .line 90
    .line 91
    move-result-object p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 92
    :try_start_3
    invoke-virtual {v5, p0}, Lor;->c(I)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 93
    .line 94
    .line 95
    return-object p1

    .line 96
    :catch_1
    move-exception p0

    .line 97
    new-instance p2, Ljava/lang/StringBuilder;

    .line 98
    .line 99
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object p2

    .line 109
    invoke-static {v1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 110
    .line 111
    .line 112
    return-object p1

    .line 113
    :cond_3
    :try_start_4
    invoke-virtual {v5, p0}, Lor;->c(I)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    .line 114
    .line 115
    .line 116
    return-object v4

    .line 117
    :catch_2
    move-exception p0

    .line 118
    new-instance p1, Ljava/lang/StringBuilder;

    .line 119
    .line 120
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    invoke-static {v1, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 131
    .line 132
    .line 133
    return-object v4

    .line 134
    :catchall_0
    move-exception p1

    .line 135
    :try_start_5
    invoke-virtual {v5, p0}, Lor;->c(I)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    .line 136
    .line 137
    .line 138
    goto :goto_2

    .line 139
    :catch_3
    move-exception p0

    .line 140
    new-instance p2, Ljava/lang/StringBuilder;

    .line 141
    .line 142
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object p2

    .line 152
    invoke-static {v1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 153
    .line 154
    .line 155
    :goto_2
    throw p1

    .line 156
    :catch_4
    move-exception p2

    .line 157
    :try_start_6
    invoke-virtual {v5, p0}, Lor;->c(I)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_5

    .line 158
    .line 159
    .line 160
    goto :goto_3

    .line 161
    :catch_5
    move-exception p0

    .line 162
    invoke-virtual {p2, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 163
    .line 164
    .line 165
    :goto_3
    new-instance p0, Ljava/lang/StringBuilder;

    .line 166
    .line 167
    const-string v0, "failed to get spans from "

    .line 168
    .line 169
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {p0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    const-string v0, " at "

    .line 176
    .line 177
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    invoke-static {v1, p0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 188
    .line 189
    .line 190
    :cond_4
    return-object v4
.end method

.method public static final v()La53;
    .locals 12

    .line 1
    sget-object v0, Lvl6;->b:La53;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v1, Lz43;

    .line 7
    .line 8
    const/4 v9, 0x0

    .line 9
    const/16 v11, 0x60

    .line 10
    .line 11
    const/4 v10, 0x0

    .line 12
    const/high16 v3, 0x41c00000    # 24.0f

    .line 13
    .line 14
    const/high16 v4, 0x41c00000    # 24.0f

    .line 15
    .line 16
    const/high16 v5, 0x41c00000    # 24.0f

    .line 17
    .line 18
    const/high16 v6, 0x41c00000    # 24.0f

    .line 19
    .line 20
    const-wide/16 v7, 0x0

    .line 21
    .line 22
    const-string v2, "Rounded.WifiTethering"

    .line 23
    .line 24
    invoke-direct/range {v1 .. v11}, Lz43;-><init>(Ljava/lang/String;FFFFJIZI)V

    .line 25
    .line 26
    .line 27
    new-instance v4, Lnw6;

    .line 28
    .line 29
    const-wide/high16 v2, -0x100000000000000L

    .line 30
    .line 31
    invoke-direct {v4, v2, v3}, Lnw6;-><init>(J)V

    .line 32
    .line 33
    .line 34
    const/high16 v0, 0x41400000    # 12.0f

    .line 35
    .line 36
    const/high16 v2, 0x41300000    # 11.0f

    .line 37
    .line 38
    invoke-static {v0, v2}, Lx82;->j(FF)Ly75;

    .line 39
    .line 40
    .line 41
    move-result-object v5

    .line 42
    const/high16 v10, -0x40000000    # -2.0f

    .line 43
    .line 44
    const/high16 v11, 0x40000000    # 2.0f

    .line 45
    .line 46
    const v6, -0x40733333    # -1.1f

    .line 47
    .line 48
    .line 49
    const/4 v7, 0x0

    .line 50
    const/high16 v8, -0x40000000    # -2.0f

    .line 51
    .line 52
    const v9, 0x3f666666    # 0.9f

    .line 53
    .line 54
    .line 55
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 56
    .line 57
    .line 58
    const v0, 0x3f666666    # 0.9f

    .line 59
    .line 60
    .line 61
    const/high16 v2, 0x40000000    # 2.0f

    .line 62
    .line 63
    invoke-virtual {v5, v0, v2, v2, v2}, Ly75;->k(FFFF)V

    .line 64
    .line 65
    .line 66
    const v0, -0x4099999a    # -0.9f

    .line 67
    .line 68
    .line 69
    const/high16 v2, -0x40000000    # -2.0f

    .line 70
    .line 71
    const/high16 v3, 0x40000000    # 2.0f

    .line 72
    .line 73
    invoke-virtual {v5, v3, v0, v3, v2}, Ly75;->k(FFFF)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v5, v0, v2, v2, v2}, Ly75;->k(FFFF)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v5}, Ly75;->a()V

    .line 80
    .line 81
    .line 82
    const/high16 v0, 0x41900000    # 18.0f

    .line 83
    .line 84
    const/high16 v2, 0x41500000    # 13.0f

    .line 85
    .line 86
    invoke-virtual {v5, v0, v2}, Ly75;->h(FF)V

    .line 87
    .line 88
    .line 89
    const/high16 v10, -0x3f280000    # -6.75f

    .line 90
    .line 91
    const v11, -0x3f41999a    # -5.95f

    .line 92
    .line 93
    .line 94
    const/4 v6, 0x0

    .line 95
    const v7, -0x3f9c28f6    # -3.56f

    .line 96
    .line 97
    .line 98
    const v8, -0x3fb8f5c3    # -3.11f

    .line 99
    .line 100
    .line 101
    const v9, -0x3f333333    # -6.4f

    .line 102
    .line 103
    .line 104
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 105
    .line 106
    .line 107
    const v10, -0x3f5a3d71    # -5.18f

    .line 108
    .line 109
    .line 110
    const v11, 0x40a0a3d7    # 5.02f

    .line 111
    .line 112
    .line 113
    const v6, -0x3fd851ec    # -2.62f

    .line 114
    .line 115
    .line 116
    const v7, 0x3ea3d70a    # 0.32f

    .line 117
    .line 118
    .line 119
    const v8, -0x3f670a3d    # -4.78f

    .line 120
    .line 121
    .line 122
    const v9, 0x401a3d71    # 2.41f

    .line 123
    .line 124
    .line 125
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 126
    .line 127
    .line 128
    const v10, 0x3ff70a3d    # 1.93f

    .line 129
    .line 130
    .line 131
    const v11, 0x40accccd    # 5.4f

    .line 132
    .line 133
    .line 134
    const v6, -0x41570a3d    # -0.33f

    .line 135
    .line 136
    .line 137
    const v7, 0x4009999a    # 2.15f

    .line 138
    .line 139
    .line 140
    const v8, 0x3efae148    # 0.49f

    .line 141
    .line 142
    .line 143
    const v9, 0x4083851f    # 4.11f

    .line 144
    .line 145
    .line 146
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 147
    .line 148
    .line 149
    const v10, 0x3fc7ae14    # 1.56f

    .line 150
    .line 151
    .line 152
    const v11, -0x41947ae1    # -0.23f

    .line 153
    .line 154
    .line 155
    const v6, 0x3ef5c28f    # 0.48f

    .line 156
    .line 157
    .line 158
    const v7, 0x3edc28f6    # 0.43f

    .line 159
    .line 160
    .line 161
    const v8, 0x3f9d70a4    # 1.23f

    .line 162
    .line 163
    .line 164
    const v9, 0x3ea8f5c3    # 0.33f

    .line 165
    .line 166
    .line 167
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 168
    .line 169
    .line 170
    const v0, -0x43dc28f6    # -0.01f

    .line 171
    .line 172
    .line 173
    const v2, 0x3c23d70a    # 0.01f

    .line 174
    .line 175
    .line 176
    invoke-virtual {v5, v2, v0}, Ly75;->g(FF)V

    .line 177
    .line 178
    .line 179
    const v10, -0x419eb852    # -0.22f

    .line 180
    .line 181
    .line 182
    const v11, -0x405eb852    # -1.26f

    .line 183
    .line 184
    .line 185
    const v6, 0x3e75c28f    # 0.24f

    .line 186
    .line 187
    .line 188
    const v7, -0x4128f5c3    # -0.42f

    .line 189
    .line 190
    .line 191
    const v8, 0x3e0f5c29    # 0.14f

    .line 192
    .line 193
    .line 194
    const v9, -0x4091eb85    # -0.93f

    .line 195
    .line 196
    .line 197
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 198
    .line 199
    .line 200
    const v10, -0x4063d70a    # -1.22f

    .line 201
    .line 202
    .line 203
    const v11, -0x3f83d70a    # -3.94f

    .line 204
    .line 205
    .line 206
    const v6, -0x407c28f6    # -1.03f

    .line 207
    .line 208
    .line 209
    const v7, -0x4091eb85    # -0.93f

    .line 210
    .line 211
    .line 212
    const v8, -0x40347ae1    # -1.59f

    .line 213
    .line 214
    .line 215
    const v9, -0x3fe851ec    # -2.37f

    .line 216
    .line 217
    .line 218
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 219
    .line 220
    .line 221
    const v10, 0x4039999a    # 2.9f

    .line 222
    .line 223
    .line 224
    const v11, -0x3fc5c28f    # -2.91f

    .line 225
    .line 226
    .line 227
    const v6, 0x3ea8f5c3    # 0.33f

    .line 228
    .line 229
    .line 230
    const v7, -0x404a3d71    # -1.42f

    .line 231
    .line 232
    .line 233
    const v8, 0x3fbd70a4    # 1.48f

    .line 234
    .line 235
    .line 236
    const v9, -0x3fdb851f    # -2.57f

    .line 237
    .line 238
    .line 239
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 240
    .line 241
    .line 242
    const/high16 v10, 0x41800000    # 16.0f

    .line 243
    .line 244
    const/high16 v11, 0x41500000    # 13.0f

    .line 245
    .line 246
    const v6, 0x415a6666    # 13.65f

    .line 247
    .line 248
    .line 249
    const v7, 0x4107d70a    # 8.49f

    .line 250
    .line 251
    .line 252
    const/high16 v8, 0x41800000    # 16.0f

    .line 253
    .line 254
    const v9, 0x4127851f    # 10.47f

    .line 255
    .line 256
    .line 257
    invoke-virtual/range {v5 .. v11}, Ly75;->b(FFFFFF)V

    .line 258
    .line 259
    .line 260
    const v10, -0x4055c28f    # -1.33f

    .line 261
    .line 262
    .line 263
    const v11, 0x403d70a4    # 2.96f

    .line 264
    .line 265
    .line 266
    const/4 v6, 0x0

    .line 267
    const v7, 0x3f970a3d    # 1.18f

    .line 268
    .line 269
    .line 270
    const v8, -0x40fae148    # -0.52f

    .line 271
    .line 272
    .line 273
    const v9, 0x400eb852    # 2.23f

    .line 274
    .line 275
    .line 276
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 277
    .line 278
    .line 279
    const v10, -0x41947ae1    # -0.23f

    .line 280
    .line 281
    .line 282
    const v11, 0x3fa147ae    # 1.26f

    .line 283
    .line 284
    .line 285
    const v6, -0x4147ae14    # -0.36f

    .line 286
    .line 287
    .line 288
    const v7, 0x3ea3d70a    # 0.32f

    .line 289
    .line 290
    .line 291
    const v8, -0x410f5c29    # -0.47f

    .line 292
    .line 293
    .line 294
    const v9, 0x3f570a3d    # 0.84f

    .line 295
    .line 296
    .line 297
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 298
    .line 299
    .line 300
    const v0, 0x3c23d70a    # 0.01f

    .line 301
    .line 302
    .line 303
    invoke-virtual {v5, v0, v0}, Ly75;->g(FF)V

    .line 304
    .line 305
    .line 306
    const/high16 v10, 0x3fc00000    # 1.5f

    .line 307
    .line 308
    const v11, 0x3e8f5c29    # 0.28f

    .line 309
    .line 310
    .line 311
    const v6, 0x3e9eb852    # 0.31f

    .line 312
    .line 313
    .line 314
    const v7, 0x3f07ae14    # 0.53f

    .line 315
    .line 316
    .line 317
    const v8, 0x3f83d70a    # 1.03f

    .line 318
    .line 319
    .line 320
    const v9, 0x3f30a3d7    # 0.69f

    .line 321
    .line 322
    .line 323
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 324
    .line 325
    .line 326
    const/high16 v10, 0x41900000    # 18.0f

    .line 327
    .line 328
    const/high16 v11, 0x41500000    # 13.0f

    .line 329
    .line 330
    const v6, 0x4189999a    # 17.2f

    .line 331
    .line 332
    .line 333
    const v7, 0x418347ae    # 16.41f

    .line 334
    .line 335
    .line 336
    const/high16 v8, 0x41900000    # 18.0f

    .line 337
    .line 338
    const v9, 0x416ccccd    # 14.8f

    .line 339
    .line 340
    .line 341
    invoke-virtual/range {v5 .. v11}, Ly75;->b(FFFFFF)V

    .line 342
    .line 343
    .line 344
    invoke-virtual {v5}, Ly75;->a()V

    .line 345
    .line 346
    .line 347
    const v0, 0x412d47ae    # 10.83f

    .line 348
    .line 349
    .line 350
    const v2, 0x40447ae1    # 3.07f

    .line 351
    .line 352
    .line 353
    invoke-virtual {v5, v0, v2}, Ly75;->h(FF)V

    .line 354
    .line 355
    .line 356
    const v10, -0x3ef3851f    # -8.78f

    .line 357
    .line 358
    .line 359
    const v11, 0x410f5c29    # 8.96f

    .line 360
    .line 361
    .line 362
    const v6, -0x3f6c28f6    # -4.62f

    .line 363
    .line 364
    .line 365
    const v7, 0x3f051eb8    # 0.52f

    .line 366
    .line 367
    .line 368
    const v8, -0x3efa6666    # -8.35f

    .line 369
    .line 370
    .line 371
    const v9, 0x408a8f5c    # 4.33f

    .line 372
    .line 373
    .line 374
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 375
    .line 376
    .line 377
    const v10, 0x4080a3d7    # 4.02f

    .line 378
    .line 379
    .line 380
    const v11, 0x411028f6    # 9.01f

    .line 381
    .line 382
    .line 383
    const v6, -0x414ccccd    # -0.35f

    .line 384
    .line 385
    .line 386
    const v7, 0x406ccccd    # 3.7f

    .line 387
    .line 388
    .line 389
    const v8, 0x3fa8f5c3    # 1.32f

    .line 390
    .line 391
    .line 392
    const v9, 0x40e0a3d7    # 7.02f

    .line 393
    .line 394
    .line 395
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 396
    .line 397
    .line 398
    const v10, 0x3fbae148    # 1.46f

    .line 399
    .line 400
    .line 401
    const v11, -0x416147ae    # -0.31f

    .line 402
    .line 403
    .line 404
    const v6, 0x3ef5c28f    # 0.48f

    .line 405
    .line 406
    .line 407
    const v7, 0x3eb33333    # 0.35f

    .line 408
    .line 409
    .line 410
    const v8, 0x3f947ae1    # 1.16f

    .line 411
    .line 412
    .line 413
    const v9, 0x3e4ccccd    # 0.2f

    .line 414
    .line 415
    .line 416
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 417
    .line 418
    .line 419
    const v10, -0x417ae148    # -0.26f

    .line 420
    .line 421
    .line 422
    const v11, -0x405ae148    # -1.29f

    .line 423
    .line 424
    .line 425
    const/high16 v6, 0x3e800000    # 0.25f

    .line 426
    .line 427
    const v7, -0x4123d70a    # -0.43f

    .line 428
    .line 429
    .line 430
    const v8, 0x3e0f5c29    # 0.14f

    .line 431
    .line 432
    .line 433
    const v9, -0x40828f5c    # -0.99f

    .line 434
    .line 435
    .line 436
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 437
    .line 438
    .line 439
    const v10, -0x3fb5c28f    # -3.16f

    .line 440
    .line 441
    .line 442
    const v11, -0x3f09999a    # -7.7f

    .line 443
    .line 444
    .line 445
    const v6, -0x3fee147b    # -2.28f

    .line 446
    .line 447
    .line 448
    const v7, -0x4027ae14    # -1.69f

    .line 449
    .line 450
    .line 451
    const v8, -0x3f966666    # -3.65f

    .line 452
    .line 453
    .line 454
    const v9, -0x3f6e6666    # -4.55f

    .line 455
    .line 456
    .line 457
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 458
    .line 459
    .line 460
    const v10, 0x40df5c29    # 6.98f

    .line 461
    .line 462
    .line 463
    const v11, -0x3f2a3d71    # -6.68f

    .line 464
    .line 465
    .line 466
    const v6, 0x3f0a3d71    # 0.54f

    .line 467
    .line 468
    .line 469
    const/high16 v7, -0x3fa00000    # -3.5f

    .line 470
    .line 471
    const v8, 0x405d70a4    # 3.46f

    .line 472
    .line 473
    .line 474
    const v9, -0x3f36b852    # -6.29f

    .line 475
    .line 476
    .line 477
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 478
    .line 479
    .line 480
    const/high16 v10, 0x41a00000    # 20.0f

    .line 481
    .line 482
    const/high16 v11, 0x41500000    # 13.0f

    .line 483
    .line 484
    const v6, 0x417e8f5c    # 15.91f

    .line 485
    .line 486
    .line 487
    const v7, 0x409051ec    # 4.51f

    .line 488
    .line 489
    .line 490
    const/high16 v8, 0x41a00000    # 20.0f

    .line 491
    .line 492
    const v9, 0x41047ae1    # 8.28f

    .line 493
    .line 494
    .line 495
    invoke-virtual/range {v5 .. v11}, Ly75;->b(FFFFFF)V

    .line 496
    .line 497
    .line 498
    const v10, -0x3faeb852    # -3.27f

    .line 499
    .line 500
    .line 501
    const v11, 0x40ce147b    # 6.44f

    .line 502
    .line 503
    .line 504
    const/4 v6, 0x0

    .line 505
    const v7, 0x4029999a    # 2.65f

    .line 506
    .line 507
    .line 508
    const v8, -0x405ae148    # -1.29f

    .line 509
    .line 510
    .line 511
    const v9, 0x409f5c29    # 4.98f

    .line 512
    .line 513
    .line 514
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 515
    .line 516
    .line 517
    const v10, -0x417ae148    # -0.26f

    .line 518
    .line 519
    .line 520
    const v11, 0x3fa51eb8    # 1.29f

    .line 521
    .line 522
    .line 523
    const v6, -0x41333333    # -0.4f

    .line 524
    .line 525
    .line 526
    const v7, 0x3e99999a    # 0.3f

    .line 527
    .line 528
    .line 529
    const v8, -0x40fd70a4    # -0.51f

    .line 530
    .line 531
    .line 532
    const v9, 0x3f59999a    # 0.85f

    .line 533
    .line 534
    .line 535
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 536
    .line 537
    .line 538
    const v10, 0x3fbae148    # 1.46f

    .line 539
    .line 540
    .line 541
    const v11, 0x3e9eb852    # 0.31f

    .line 542
    .line 543
    .line 544
    const v6, 0x3e99999a    # 0.3f

    .line 545
    .line 546
    .line 547
    const v7, 0x3f051eb8    # 0.52f

    .line 548
    .line 549
    .line 550
    const v8, 0x3f7ae148    # 0.98f

    .line 551
    .line 552
    .line 553
    const v9, 0x3f28f5c3    # 0.66f

    .line 554
    .line 555
    .line 556
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 557
    .line 558
    .line 559
    const/high16 v10, 0x41b00000    # 22.0f

    .line 560
    .line 561
    const/high16 v11, 0x41500000    # 13.0f

    .line 562
    .line 563
    const v6, 0x41a33333    # 20.4f

    .line 564
    .line 565
    .line 566
    const v7, 0x4199c28f    # 19.22f

    .line 567
    .line 568
    .line 569
    const/high16 v8, 0x41b00000    # 22.0f

    .line 570
    .line 571
    const v9, 0x41826666    # 16.3f

    .line 572
    .line 573
    .line 574
    invoke-virtual/range {v5 .. v11}, Ly75;->b(FFFFFF)V

    .line 575
    .line 576
    .line 577
    const v10, -0x3ecd47ae    # -11.17f

    .line 578
    .line 579
    .line 580
    const v11, -0x3ee11eb8    # -9.93f

    .line 581
    .line 582
    .line 583
    const/4 v6, 0x0

    .line 584
    const v7, -0x3f42e148    # -5.91f

    .line 585
    .line 586
    .line 587
    const v8, -0x3f5bd70a    # -5.13f

    .line 588
    .line 589
    .line 590
    const v9, -0x3ed6147b    # -10.62f

    .line 591
    .line 592
    .line 593
    invoke-virtual/range {v5 .. v11}, Ly75;->c(FFFFFF)V

    .line 594
    .line 595
    .line 596
    invoke-virtual {v5}, Ly75;->a()V

    .line 597
    .line 598
    .line 599
    iget-object v2, v5, Ly75;->a:Ljava/util/ArrayList;

    .line 600
    .line 601
    const/16 v10, 0x3800

    .line 602
    .line 603
    const/4 v3, 0x0

    .line 604
    const/4 v5, 0x0

    .line 605
    const/high16 v6, 0x3f800000    # 1.0f

    .line 606
    .line 607
    const/4 v7, 0x0

    .line 608
    const/4 v8, 0x2

    .line 609
    const/high16 v9, 0x3f800000    # 1.0f

    .line 610
    .line 611
    invoke-static/range {v1 .. v10}, Lz43;->b(Lz43;Ljava/util/List;ILnw6;Lnw6;FIIFI)V

    .line 612
    .line 613
    .line 614
    invoke-virtual {v1}, Lz43;->c()La53;

    .line 615
    .line 616
    .line 617
    move-result-object v0

    .line 618
    sput-object v0, Lvl6;->b:La53;

    .line 619
    .line 620
    return-object v0
.end method

.method public static final w(Ljava/lang/String;)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-lez v0, :cond_3

    .line 9
    .line 10
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v1, 0x0

    .line 15
    :goto_0
    if-ge v1, v0, :cond_2

    .line 16
    .line 17
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    const/16 v3, 0x21

    .line 22
    .line 23
    if-gt v3, v2, :cond_0

    .line 24
    .line 25
    const/16 v3, 0x7f

    .line 26
    .line 27
    if-ge v2, v3, :cond_0

    .line 28
    .line 29
    add-int/lit8 v1, v1, 0x1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 33
    .line 34
    const-string v3, "Unexpected char 0x"

    .line 35
    .line 36
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    const/16 v3, 0x10

    .line 40
    .line 41
    invoke-static {v3}, Lnk;->C(I)V

    .line 42
    .line 43
    .line 44
    invoke-static {v2, v3}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    const/4 v4, 0x2

    .line 56
    if-ge v3, v4, :cond_1

    .line 57
    .line 58
    const-string v3, "0"

    .line 59
    .line 60
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    :cond_1
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    const-string v2, " at "

    .line 68
    .line 69
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    const-string v1, " in header name: "

    .line 76
    .line 77
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 88
    .line 89
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    throw v0

    .line 97
    :cond_2
    return-void

    .line 98
    :cond_3
    const-string p0, "name is empty"

    .line 99
    .line 100
    invoke-static {p0}, Lt32;->g(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    return-void
.end method

.method public static final x(Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x0

    .line 9
    :goto_0
    if-ge v1, v0, :cond_4

    .line 10
    .line 11
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/16 v3, 0x9

    .line 16
    .line 17
    if-eq v2, v3, :cond_3

    .line 18
    .line 19
    const/16 v3, 0x20

    .line 20
    .line 21
    if-gt v3, v2, :cond_0

    .line 22
    .line 23
    const/16 v3, 0x7f

    .line 24
    .line 25
    if-lt v2, v3, :cond_3

    .line 26
    .line 27
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 28
    .line 29
    const-string v3, "Unexpected char 0x"

    .line 30
    .line 31
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    const/16 v3, 0x10

    .line 35
    .line 36
    invoke-static {v3}, Lnk;->C(I)V

    .line 37
    .line 38
    .line 39
    invoke-static {v2, v3}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    const/4 v4, 0x2

    .line 51
    if-ge v3, v4, :cond_1

    .line 52
    .line 53
    const-string v3, "0"

    .line 54
    .line 55
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    :cond_1
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    const-string v2, " at "

    .line 63
    .line 64
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    const-string v1, " in "

    .line 71
    .line 72
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    const-string v1, " value"

    .line 79
    .line 80
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-static {p1}, Li48;->k(Ljava/lang/String;)Z

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    if-eqz p1, :cond_2

    .line 88
    .line 89
    const-string p0, ""

    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_2
    const-string p1, ": "

    .line 93
    .line 94
    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    :goto_1
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 106
    .line 107
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object p0

    .line 111
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    throw p1

    .line 115
    :cond_3
    add-int/lit8 v1, v1, 0x1

    .line 116
    .line 117
    goto :goto_0

    .line 118
    :cond_4
    return-void
.end method

.method public static final y(Ljava/lang/String;[B)Ljava/lang/String;
    .locals 8

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    add-int/lit8 v1, v0, -0x2

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    move v3, v2

    .line 13
    move v4, v3

    .line 14
    :goto_0
    if-lt v3, v1, :cond_1

    .line 15
    .line 16
    if-ne v3, v4, :cond_0

    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_0
    if-lt v3, v0, :cond_2

    .line 20
    .line 21
    array-length p0, p1

    .line 22
    invoke-static {v2, v4, p0}, Lkb3;->q(III)V

    .line 23
    .line 24
    .line 25
    new-instance p0, Ljava/lang/String;

    .line 26
    .line 27
    sget-object v0, Lrp0;->a:Ljava/nio/charset/Charset;

    .line 28
    .line 29
    invoke-direct {p0, p1, v2, v4, v0}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 30
    .line 31
    .line 32
    return-object p0

    .line 33
    :cond_1
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    const/16 v6, 0x25

    .line 38
    .line 39
    if-ne v5, v6, :cond_2

    .line 40
    .line 41
    add-int/lit8 v5, v3, 0x1

    .line 42
    .line 43
    add-int/lit8 v6, v3, 0x3

    .line 44
    .line 45
    :try_start_0
    invoke-virtual {p0, v5, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    const/16 v7, 0x10

    .line 50
    .line 51
    invoke-static {v7}, Lnk;->C(I)V

    .line 52
    .line 53
    .line 54
    invoke-static {v5, v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    .line 55
    .line 56
    .line 57
    move-result v5

    .line 58
    int-to-byte v5, v5

    .line 59
    aput-byte v5, p1, v4
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 60
    .line 61
    add-int/lit8 v4, v4, 0x1

    .line 62
    .line 63
    move v3, v6

    .line 64
    goto :goto_0

    .line 65
    :catch_0
    :cond_2
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    .line 66
    .line 67
    .line 68
    move-result v5

    .line 69
    int-to-byte v5, v5

    .line 70
    aput-byte v5, p1, v4

    .line 71
    .line 72
    add-int/lit8 v4, v4, 0x1

    .line 73
    .line 74
    add-int/lit8 v3, v3, 0x1

    .line 75
    .line 76
    goto :goto_0
.end method

.method public static final z(Lki2;)Lff7;
    .locals 7

    .line 1
    sget-object v0, Lw51;->f:Lx51;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Lqe2;

    .line 9
    .line 10
    sget-object v0, Lw51;->j:Lx51;

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    move-object v3, v0

    .line 17
    check-cast v3, Lpt3;

    .line 18
    .line 19
    sget-object v0, Lw51;->d:Lx51;

    .line 20
    .line 21
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    move-object v4, v0

    .line 26
    check-cast v4, Lso1;

    .line 27
    .line 28
    sget-object v0, Lw51;->i:Lx51;

    .line 29
    .line 30
    invoke-virtual {p0, v0}, Lki2;->k(Lch5;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    move-object v5, v0

    .line 35
    check-cast v5, Lgi3;

    .line 36
    .line 37
    invoke-virtual {p0, v2}, Lki2;->g(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-virtual {p0, v3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    or-int/2addr v0, v1

    .line 46
    invoke-virtual {p0, v4}, Lki2;->g(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    or-int/2addr v0, v1

    .line 51
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    invoke-virtual {p0, v1}, Lki2;->e(I)Z

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    or-int/2addr v0, v1

    .line 60
    const/16 v6, 0x8

    .line 61
    .line 62
    invoke-virtual {p0, v6}, Lki2;->e(I)Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    or-int/2addr v0, v1

    .line 67
    invoke-virtual {p0}, Lki2;->T()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    if-nez v0, :cond_0

    .line 72
    .line 73
    sget-object v0, Lz41;->a:Lql0;

    .line 74
    .line 75
    if-ne v1, v0, :cond_1

    .line 76
    .line 77
    :cond_0
    new-instance v1, Lff7;

    .line 78
    .line 79
    invoke-direct/range {v1 .. v6}, Lff7;-><init>(Lqe2;Lpt3;Lso1;Lgi3;I)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0, v1}, Lki2;->q0(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    :cond_1
    check-cast v1, Lff7;

    .line 86
    .line 87
    return-object v1
.end method


# virtual methods
.method public b()V
    .locals 0

    .line 1
    return-void
.end method

.method public c()V
    .locals 0

    .line 1
    return-void
.end method
