.class public final synthetic Lkl5;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lvo5;

.field public final synthetic j:Lkk5;

.field public final synthetic k:Z

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:Ljo5;

.field public final synthetic n:Lwg2;

.field public final synthetic o:Lq21;

.field public final synthetic p:Lak5;

.field public final synthetic q:Lkc5;


# direct methods
.method public synthetic constructor <init>(Lvo5;Lkk5;ZLjava/lang/String;Ljo5;Lwg2;Lq21;Lak5;Lkc5;IB)V
    .locals 0

    .line 1
    iput-byte p11, p0, Lkl5;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lkl5;->i:Lvo5;

    .line 4
    .line 5
    iput-object p2, p0, Lkl5;->j:Lkk5;

    .line 6
    .line 7
    iput-boolean p3, p0, Lkl5;->k:Z

    .line 8
    .line 9
    iput-object p4, p0, Lkl5;->l:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p5, p0, Lkl5;->m:Ljo5;

    .line 12
    .line 13
    iput-object p6, p0, Lkl5;->n:Lwg2;

    .line 14
    .line 15
    iput-object p7, p0, Lkl5;->o:Lq21;

    .line 16
    .line 17
    iput-object p8, p0, Lkl5;->p:Lak5;

    .line 18
    .line 19
    iput-object p9, p0, Lkl5;->q:Lkc5;

    .line 20
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lkl5;->h:B

    .line 4
    .line 5
    sget-object v2, Los7;->a:Los7;

    .line 6
    .line 7
    const v3, 0x180001

    .line 8
    .line 9
    .line 10
    packed-switch v1, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    move-object/from16 v13, p1

    .line 14
    .line 15
    check-cast v13, Lki2;

    .line 16
    .line 17
    move-object/from16 v1, p2

    .line 18
    .line 19
    check-cast v1, Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-static {v3}, Ld43;->P(I)I

    .line 25
    .line 26
    .line 27
    move-result v14

    .line 28
    iget-object v4, v0, Lkl5;->i:Lvo5;

    .line 29
    .line 30
    iget-object v5, v0, Lkl5;->j:Lkk5;

    .line 31
    .line 32
    iget-boolean v6, v0, Lkl5;->k:Z

    .line 33
    .line 34
    iget-object v7, v0, Lkl5;->l:Ljava/lang/String;

    .line 35
    .line 36
    iget-object v8, v0, Lkl5;->m:Ljo5;

    .line 37
    .line 38
    iget-object v9, v0, Lkl5;->n:Lwg2;

    .line 39
    .line 40
    iget-object v10, v0, Lkl5;->o:Lq21;

    .line 41
    .line 42
    iget-object v11, v0, Lkl5;->p:Lak5;

    .line 43
    .line 44
    iget-object v12, v0, Lkl5;->q:Lkc5;

    .line 45
    .line 46
    invoke-static/range {v4 .. v14}, Lnx3;->v(Lvo5;Lkk5;ZLjava/lang/String;Ljo5;Lwg2;Lq21;Lak5;Lkc5;Lki2;I)V

    .line 47
    .line 48
    .line 49
    return-object v2

    .line 50
    :pswitch_0
    move-object/from16 v24, p1

    .line 51
    .line 52
    check-cast v24, Lki2;

    .line 53
    .line 54
    move-object/from16 v1, p2

    .line 55
    .line 56
    check-cast v1, Ljava/lang/Integer;

    .line 57
    .line 58
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    invoke-static {v3}, Ld43;->P(I)I

    .line 62
    .line 63
    .line 64
    move-result v25

    .line 65
    iget-object v15, v0, Lkl5;->i:Lvo5;

    .line 66
    .line 67
    iget-object v1, v0, Lkl5;->j:Lkk5;

    .line 68
    .line 69
    iget-boolean v3, v0, Lkl5;->k:Z

    .line 70
    .line 71
    iget-object v4, v0, Lkl5;->l:Ljava/lang/String;

    .line 72
    .line 73
    iget-object v5, v0, Lkl5;->m:Ljo5;

    .line 74
    .line 75
    iget-object v6, v0, Lkl5;->n:Lwg2;

    .line 76
    .line 77
    iget-object v7, v0, Lkl5;->o:Lq21;

    .line 78
    .line 79
    iget-object v8, v0, Lkl5;->p:Lak5;

    .line 80
    .line 81
    iget-object v0, v0, Lkl5;->q:Lkc5;

    .line 82
    .line 83
    move-object/from16 v23, v0

    .line 84
    .line 85
    move-object/from16 v16, v1

    .line 86
    .line 87
    move/from16 v17, v3

    .line 88
    .line 89
    move-object/from16 v18, v4

    .line 90
    .line 91
    move-object/from16 v19, v5

    .line 92
    .line 93
    move-object/from16 v20, v6

    .line 94
    .line 95
    move-object/from16 v21, v7

    .line 96
    .line 97
    move-object/from16 v22, v8

    .line 98
    .line 99
    invoke-static/range {v15 .. v25}, Lnt7;->u(Lvo5;Lkk5;ZLjava/lang/String;Ljo5;Lwg2;Lq21;Lak5;Lkc5;Lki2;I)V

    .line 100
    .line 101
    .line 102
    return-object v2

    .line 103
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
