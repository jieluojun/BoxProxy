.class public final synthetic Ls1;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lhh2;


# instance fields
.field public final synthetic h:F

.field public final synthetic i:Lu35;

.field public final synthetic j:Lzd4;

.field public final synthetic k:Lzd4;

.field public final synthetic l:F

.field public final synthetic m:Lwh3;

.field public final synthetic n:F

.field public final synthetic o:Ld50;

.field public final synthetic p:Z

.field public final synthetic q:Lwg2;

.field public final synthetic r:Ljava/util/List;

.field public final synthetic s:Ljt7;

.field public final synthetic t:Ljava/util/List;

.field public final synthetic u:Lwg2;


# direct methods
.method public synthetic constructor <init>(FLu35;Lzd4;Lzd4;FLwh3;FLd50;ZLwg2;Ljava/util/List;Ljt7;Ljava/util/List;Lwg2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Ls1;->h:F

    .line 5
    .line 6
    iput-object p2, p0, Ls1;->i:Lu35;

    .line 7
    .line 8
    iput-object p3, p0, Ls1;->j:Lzd4;

    .line 9
    .line 10
    iput-object p4, p0, Ls1;->k:Lzd4;

    .line 11
    .line 12
    iput p5, p0, Ls1;->l:F

    .line 13
    .line 14
    iput-object p6, p0, Ls1;->m:Lwh3;

    .line 15
    .line 16
    iput p7, p0, Ls1;->n:F

    .line 17
    .line 18
    iput-object p8, p0, Ls1;->o:Ld50;

    .line 19
    .line 20
    iput-boolean p9, p0, Ls1;->p:Z

    .line 21
    .line 22
    iput-object p10, p0, Ls1;->q:Lwg2;

    .line 23
    .line 24
    iput-object p11, p0, Ls1;->r:Ljava/util/List;

    .line 25
    .line 26
    iput-object p12, p0, Ls1;->s:Ljt7;

    .line 27
    .line 28
    iput-object p13, p0, Ls1;->t:Ljava/util/List;

    .line 29
    .line 30
    iput-object p14, p0, Ls1;->u:Lwg2;

    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lhm3;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    new-instance v2, Lt1;

    .line 11
    .line 12
    iget v3, v0, Ls1;->h:F

    .line 13
    .line 14
    iget-object v4, v0, Ls1;->i:Lu35;

    .line 15
    .line 16
    iget-object v5, v0, Ls1;->j:Lzd4;

    .line 17
    .line 18
    iget-object v6, v0, Ls1;->k:Lzd4;

    .line 19
    .line 20
    invoke-direct {v2, v3, v4, v5, v6}, Lt1;-><init>(FLu35;Lzd4;Lzd4;)V

    .line 21
    .line 22
    .line 23
    new-instance v3, Lq21;

    .line 24
    .line 25
    const v4, 0x2cc732ac

    .line 26
    .line 27
    .line 28
    const/4 v5, 0x1

    .line 29
    invoke-direct {v3, v4, v5, v2}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    const/4 v2, 0x2

    .line 33
    const-string v4, "logoSpacer"

    .line 34
    .line 35
    invoke-static {v1, v4, v3, v2}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 36
    .line 37
    .line 38
    new-instance v6, Lu1;

    .line 39
    .line 40
    iget v7, v0, Ls1;->l:F

    .line 41
    .line 42
    iget-object v8, v0, Ls1;->m:Lwh3;

    .line 43
    .line 44
    iget v9, v0, Ls1;->n:F

    .line 45
    .line 46
    iget-object v10, v0, Ls1;->o:Ld50;

    .line 47
    .line 48
    iget-boolean v11, v0, Ls1;->p:Z

    .line 49
    .line 50
    iget-object v12, v0, Ls1;->q:Lwg2;

    .line 51
    .line 52
    iget-object v13, v0, Ls1;->r:Ljava/util/List;

    .line 53
    .line 54
    iget-object v14, v0, Ls1;->s:Ljt7;

    .line 55
    .line 56
    iget-object v15, v0, Ls1;->t:Ljava/util/List;

    .line 57
    .line 58
    iget-object v0, v0, Ls1;->u:Lwg2;

    .line 59
    .line 60
    move-object/from16 v16, v0

    .line 61
    .line 62
    invoke-direct/range {v6 .. v16}, Lu1;-><init>(FLwh3;FLd50;ZLwg2;Ljava/util/List;Ljt7;Ljava/util/List;Lwg2;)V

    .line 63
    .line 64
    .line 65
    new-instance v0, Lq21;

    .line 66
    .line 67
    const v2, 0x51f1fa55

    .line 68
    .line 69
    .line 70
    invoke-direct {v0, v2, v5, v6}, Lq21;-><init>(IZLjava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    const/4 v2, 0x3

    .line 74
    const/4 v3, 0x0

    .line 75
    invoke-static {v1, v3, v0, v2}, Lhm3;->b0(Lhm3;Ljava/lang/String;Lmh2;I)V

    .line 76
    .line 77
    .line 78
    sget-object v0, Los7;->a:Los7;

    .line 79
    .line 80
    return-object v0
.end method
