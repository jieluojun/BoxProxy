.class public final Lff7;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lqe2;

.field public final b:Lpt3;

.field public final c:Lso1;

.field public final d:Lgi3;

.field public final e:Lic6;


# direct methods
.method public constructor <init>(Lqe2;Lpt3;Lso1;Lgi3;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lff7;->a:Lqe2;

    .line 5
    .line 6
    iput-object p2, p0, Lff7;->b:Lpt3;

    .line 7
    .line 8
    iput-object p3, p0, Lff7;->c:Lso1;

    .line 9
    .line 10
    iput-object p4, p0, Lff7;->d:Lgi3;

    .line 11
    .line 12
    if-lez p5, :cond_0

    .line 13
    .line 14
    new-instance p1, Lic6;

    .line 15
    .line 16
    invoke-direct {p1, p5}, Lic6;-><init>(I)V

    .line 17
    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 p1, 0x0

    .line 21
    :goto_0
    iput-object p1, p0, Lff7;->e:Lic6;

    .line 22
    .line 23
    return-void
.end method

.method public static a(Lff7;Ljava/lang/String;Lwg7;IIJLgi3;Lso1;Lqe2;I)Lse7;
    .locals 14

    .line 1
    move/from16 v1, p10

    .line 2
    .line 3
    and-int/lit8 v2, v1, 0x4

    .line 4
    .line 5
    if-eqz v2, :cond_0

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    move v3, v2

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move/from16 v3, p3

    .line 11
    .line 12
    :goto_0
    and-int/lit8 v2, v1, 0x10

    .line 13
    .line 14
    if-eqz v2, :cond_1

    .line 15
    .line 16
    const v2, 0x7fffffff

    .line 17
    .line 18
    .line 19
    move v5, v2

    .line 20
    goto :goto_1

    .line 21
    :cond_1
    move/from16 v5, p4

    .line 22
    .line 23
    :goto_1
    and-int/lit8 v2, v1, 0x20

    .line 24
    .line 25
    if-eqz v2, :cond_2

    .line 26
    .line 27
    const/16 v2, 0xf

    .line 28
    .line 29
    const/4 v4, 0x0

    .line 30
    invoke-static {v4, v4, v4, v4, v2}, Lsa1;->b(IIIII)J

    .line 31
    .line 32
    .line 33
    move-result-wide v6

    .line 34
    goto :goto_2

    .line 35
    :cond_2
    move-wide/from16 v6, p5

    .line 36
    .line 37
    :goto_2
    and-int/lit8 v2, v1, 0x40

    .line 38
    .line 39
    if-eqz v2, :cond_3

    .line 40
    .line 41
    iget-object v2, p0, Lff7;->d:Lgi3;

    .line 42
    .line 43
    move-object v8, v2

    .line 44
    goto :goto_3

    .line 45
    :cond_3
    move-object/from16 v8, p7

    .line 46
    .line 47
    :goto_3
    and-int/lit16 v2, v1, 0x80

    .line 48
    .line 49
    if-eqz v2, :cond_4

    .line 50
    .line 51
    iget-object v2, p0, Lff7;->c:Lso1;

    .line 52
    .line 53
    move-object v9, v2

    .line 54
    goto :goto_4

    .line 55
    :cond_4
    move-object/from16 v9, p8

    .line 56
    .line 57
    :goto_4
    and-int/lit16 v1, v1, 0x100

    .line 58
    .line 59
    if-eqz v1, :cond_5

    .line 60
    .line 61
    iget-object v1, p0, Lff7;->a:Lqe2;

    .line 62
    .line 63
    move-object v10, v1

    .line 64
    goto :goto_5

    .line 65
    :cond_5
    move-object/from16 v10, p9

    .line 66
    .line 67
    :goto_5
    iget-object v12, p0, Lff7;->b:Lpt3;

    .line 68
    .line 69
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    new-instance v1, Lqj;

    .line 73
    .line 74
    invoke-direct {v1, p1}, Lqj;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const/16 v13, 0x20

    .line 78
    .line 79
    const/4 v4, 0x1

    .line 80
    const/4 v11, 0x0

    .line 81
    move-object v0, p0

    .line 82
    move-object/from16 v2, p2

    .line 83
    .line 84
    invoke-static/range {v0 .. v13}, Lff7;->b(Lff7;Lqj;Lwg7;IZIJLgi3;Lso1;Lqe2;ZLpt3;I)Lse7;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    return-object v0
.end method

.method public static b(Lff7;Lqj;Lwg7;IZIJLgi3;Lso1;Lqe2;ZLpt3;I)Lse7;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p13

    .line 4
    .line 5
    and-int/lit8 v2, v1, 0x4

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    if-eqz v2, :cond_0

    .line 9
    .line 10
    move v10, v3

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    move/from16 v10, p3

    .line 13
    .line 14
    :goto_0
    and-int/lit8 v2, v1, 0x8

    .line 15
    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    move v9, v3

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    move/from16 v9, p4

    .line 21
    .line 22
    :goto_1
    and-int/lit8 v2, v1, 0x40

    .line 23
    .line 24
    const/4 v4, 0x0

    .line 25
    if-eqz v2, :cond_2

    .line 26
    .line 27
    const/16 v2, 0xf

    .line 28
    .line 29
    invoke-static {v4, v4, v4, v4, v2}, Lsa1;->b(IIIII)J

    .line 30
    .line 31
    .line 32
    move-result-wide v5

    .line 33
    move-wide v15, v5

    .line 34
    goto :goto_2

    .line 35
    :cond_2
    move-wide/from16 v15, p6

    .line 36
    .line 37
    :goto_2
    and-int/lit16 v2, v1, 0x80

    .line 38
    .line 39
    if-eqz v2, :cond_3

    .line 40
    .line 41
    iget-object v2, v0, Lff7;->d:Lgi3;

    .line 42
    .line 43
    move-object v12, v2

    .line 44
    goto :goto_3

    .line 45
    :cond_3
    move-object/from16 v12, p8

    .line 46
    .line 47
    :goto_3
    and-int/lit16 v2, v1, 0x100

    .line 48
    .line 49
    if-eqz v2, :cond_4

    .line 50
    .line 51
    iget-object v2, v0, Lff7;->c:Lso1;

    .line 52
    .line 53
    move-object v11, v2

    .line 54
    goto :goto_4

    .line 55
    :cond_4
    move-object/from16 v11, p9

    .line 56
    .line 57
    :goto_4
    and-int/lit16 v2, v1, 0x200

    .line 58
    .line 59
    if-eqz v2, :cond_5

    .line 60
    .line 61
    iget-object v2, v0, Lff7;->a:Lqe2;

    .line 62
    .line 63
    move-object v13, v2

    .line 64
    goto :goto_5

    .line 65
    :cond_5
    move-object/from16 v13, p10

    .line 66
    .line 67
    :goto_5
    and-int/lit16 v2, v1, 0x400

    .line 68
    .line 69
    if-eqz v2, :cond_6

    .line 70
    .line 71
    move v2, v4

    .line 72
    goto :goto_6

    .line 73
    :cond_6
    move/from16 v2, p11

    .line 74
    .line 75
    :goto_6
    and-int/lit16 v1, v1, 0x800

    .line 76
    .line 77
    if-eqz v1, :cond_7

    .line 78
    .line 79
    iget-object v1, v0, Lff7;->b:Lpt3;

    .line 80
    .line 81
    move-object v14, v1

    .line 82
    goto :goto_7

    .line 83
    :cond_7
    move-object/from16 v14, p12

    .line 84
    .line 85
    :goto_7
    iget-object v0, v0, Lff7;->e:Lic6;

    .line 86
    .line 87
    move v1, v4

    .line 88
    new-instance v4, Lre7;

    .line 89
    .line 90
    sget-object v7, Lw12;->h:Lw12;

    .line 91
    .line 92
    move-object/from16 v5, p1

    .line 93
    .line 94
    move-object/from16 v6, p2

    .line 95
    .line 96
    move/from16 v8, p5

    .line 97
    .line 98
    invoke-direct/range {v4 .. v16}, Lre7;-><init>(Lqj;Lwg7;Ljava/util/List;IZILso1;Lgi3;Lqe2;Lpt3;J)V

    .line 99
    .line 100
    .line 101
    move-wide v5, v15

    .line 102
    const/4 v8, 0x0

    .line 103
    if-nez v2, :cond_9

    .line 104
    .line 105
    if-eqz v0, :cond_9

    .line 106
    .line 107
    new-instance v2, Lkk0;

    .line 108
    .line 109
    invoke-direct {v2, v4}, Lkk0;-><init>(Lre7;)V

    .line 110
    .line 111
    .line 112
    iget-object v15, v0, Lic6;->h:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast v15, Lxw3;

    .line 115
    .line 116
    if-eqz v15, :cond_8

    .line 117
    .line 118
    invoke-virtual {v15, v2}, Lxw3;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v2

    .line 122
    check-cast v2, Lse7;

    .line 123
    .line 124
    goto :goto_8

    .line 125
    :cond_8
    iget-object v15, v0, Lic6;->i:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v15, Lkk0;

    .line 128
    .line 129
    invoke-static {v15, v2}, Lkb3;->o(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v2

    .line 133
    if-eqz v2, :cond_9

    .line 134
    .line 135
    iget-object v2, v0, Lic6;->j:Ljava/lang/Object;

    .line 136
    .line 137
    check-cast v2, Lse7;

    .line 138
    .line 139
    :goto_8
    if-eqz v2, :cond_9

    .line 140
    .line 141
    iget-object v15, v2, Lse7;->b:Lvb4;

    .line 142
    .line 143
    iget-object v15, v15, Lvb4;->a:Lyp2;

    .line 144
    .line 145
    invoke-virtual {v15}, Lyp2;->j()Z

    .line 146
    .line 147
    .line 148
    move-result v15

    .line 149
    if-nez v15, :cond_9

    .line 150
    .line 151
    move-object v8, v2

    .line 152
    :cond_9
    const/16 v2, 0x20

    .line 153
    .line 154
    const-wide v15, 0xffffffffL

    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    if-eqz v8, :cond_a

    .line 160
    .line 161
    iget-object v0, v8, Lse7;->b:Lvb4;

    .line 162
    .line 163
    iget v1, v0, Lvb4;->d:F

    .line 164
    .line 165
    float-to-double v7, v1

    .line 166
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    .line 167
    .line 168
    .line 169
    move-result-wide v7

    .line 170
    double-to-float v1, v7

    .line 171
    float-to-int v1, v1

    .line 172
    iget v3, v0, Lvb4;->e:F

    .line 173
    .line 174
    float-to-double v7, v3

    .line 175
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    .line 176
    .line 177
    .line 178
    move-result-wide v7

    .line 179
    double-to-float v3, v7

    .line 180
    float-to-int v3, v3

    .line 181
    int-to-long v7, v1

    .line 182
    shl-long/2addr v7, v2

    .line 183
    int-to-long v1, v3

    .line 184
    and-long/2addr v1, v15

    .line 185
    or-long/2addr v7, v1

    .line 186
    invoke-static {v5, v6, v7, v8}, Lsa1;->d(JJ)J

    .line 187
    .line 188
    .line 189
    move-result-wide v1

    .line 190
    new-instance v3, Lse7;

    .line 191
    .line 192
    invoke-direct {v3, v4, v0, v1, v2}, Lse7;-><init>(Lre7;Lvb4;J)V

    .line 193
    .line 194
    .line 195
    return-object v3

    .line 196
    :cond_a
    move-object/from16 v8, p2

    .line 197
    .line 198
    invoke-static {v8, v12}, Lck6;->p(Lwg7;Lgi3;)Lwg7;

    .line 199
    .line 200
    .line 201
    move-result-object v8

    .line 202
    new-instance v12, Lyp2;

    .line 203
    .line 204
    move-object/from16 p7, p1

    .line 205
    .line 206
    move-object/from16 p9, v7

    .line 207
    .line 208
    move-object/from16 p8, v8

    .line 209
    .line 210
    move/from16 p12, v9

    .line 211
    .line 212
    move-object/from16 p10, v11

    .line 213
    .line 214
    move-object/from16 p6, v12

    .line 215
    .line 216
    move-object/from16 p11, v13

    .line 217
    .line 218
    move-object/from16 p13, v14

    .line 219
    .line 220
    invoke-direct/range {p6 .. p13}, Lyp2;-><init>(Lqj;Lwg7;Ljava/util/List;Lso1;Lqe2;ZLpt3;)V

    .line 221
    .line 222
    .line 223
    move-object/from16 v7, p6

    .line 224
    .line 225
    invoke-static {v5, v6}, Lra1;->k(J)I

    .line 226
    .line 227
    .line 228
    move-result v8

    .line 229
    const/4 v11, 0x5

    .line 230
    const/4 v12, 0x2

    .line 231
    const/4 v13, 0x4

    .line 232
    if-nez v9, :cond_b

    .line 233
    .line 234
    if-eq v10, v12, :cond_b

    .line 235
    .line 236
    if-eq v10, v13, :cond_b

    .line 237
    .line 238
    if-ne v10, v11, :cond_c

    .line 239
    .line 240
    :cond_b
    invoke-static {v5, v6}, Lra1;->e(J)Z

    .line 241
    .line 242
    .line 243
    move-result v14

    .line 244
    if-eqz v14, :cond_c

    .line 245
    .line 246
    invoke-static {v5, v6}, Lra1;->i(J)I

    .line 247
    .line 248
    .line 249
    move-result v14

    .line 250
    goto :goto_9

    .line 251
    :cond_c
    const v14, 0x7fffffff

    .line 252
    .line 253
    .line 254
    :goto_9
    if-nez v9, :cond_d

    .line 255
    .line 256
    if-eq v10, v12, :cond_e

    .line 257
    .line 258
    if-eq v10, v13, :cond_e

    .line 259
    .line 260
    if-eq v10, v11, :cond_e

    .line 261
    .line 262
    :cond_d
    move/from16 v3, p5

    .line 263
    .line 264
    :cond_e
    if-eq v8, v14, :cond_f

    .line 265
    .line 266
    invoke-virtual {v7}, Lyp2;->m()F

    .line 267
    .line 268
    .line 269
    move-result v9

    .line 270
    float-to-double v11, v9

    .line 271
    invoke-static {v11, v12}, Ljava/lang/Math;->ceil(D)D

    .line 272
    .line 273
    .line 274
    move-result-wide v11

    .line 275
    double-to-float v9, v11

    .line 276
    float-to-int v9, v9

    .line 277
    invoke-static {v9, v8, v14}, Ls33;->E(III)I

    .line 278
    .line 279
    .line 280
    move-result v14

    .line 281
    :cond_f
    new-instance v8, Lvb4;

    .line 282
    .line 283
    invoke-static {v5, v6}, Lra1;->h(J)I

    .line 284
    .line 285
    .line 286
    move-result v9

    .line 287
    invoke-static {v1, v14, v1, v9}, Lok;->F(IIII)J

    .line 288
    .line 289
    .line 290
    move-result-wide v11

    .line 291
    move/from16 p4, v3

    .line 292
    .line 293
    move-object/from16 p1, v7

    .line 294
    .line 295
    move-object/from16 p0, v8

    .line 296
    .line 297
    move/from16 p5, v10

    .line 298
    .line 299
    move-wide/from16 p2, v11

    .line 300
    .line 301
    invoke-direct/range {p0 .. p5}, Lvb4;-><init>(Lyp2;JII)V

    .line 302
    .line 303
    .line 304
    move-object/from16 v1, p0

    .line 305
    .line 306
    new-instance v3, Lse7;

    .line 307
    .line 308
    iget v7, v1, Lvb4;->d:F

    .line 309
    .line 310
    float-to-double v7, v7

    .line 311
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    .line 312
    .line 313
    .line 314
    move-result-wide v7

    .line 315
    double-to-float v7, v7

    .line 316
    float-to-int v7, v7

    .line 317
    iget v8, v1, Lvb4;->e:F

    .line 318
    .line 319
    float-to-double v8, v8

    .line 320
    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    .line 321
    .line 322
    .line 323
    move-result-wide v8

    .line 324
    double-to-float v8, v8

    .line 325
    float-to-int v8, v8

    .line 326
    int-to-long v9, v7

    .line 327
    shl-long/2addr v9, v2

    .line 328
    int-to-long v7, v8

    .line 329
    and-long/2addr v7, v15

    .line 330
    or-long/2addr v9, v7

    .line 331
    invoke-static {v5, v6, v9, v10}, Lsa1;->d(JJ)J

    .line 332
    .line 333
    .line 334
    move-result-wide v5

    .line 335
    invoke-direct {v3, v4, v1, v5, v6}, Lse7;-><init>(Lre7;Lvb4;J)V

    .line 336
    .line 337
    .line 338
    if-eqz v0, :cond_11

    .line 339
    .line 340
    iget-object v1, v0, Lic6;->h:Ljava/lang/Object;

    .line 341
    .line 342
    check-cast v1, Lxw3;

    .line 343
    .line 344
    if-eqz v1, :cond_10

    .line 345
    .line 346
    new-instance v0, Lkk0;

    .line 347
    .line 348
    invoke-direct {v0, v4}, Lkk0;-><init>(Lre7;)V

    .line 349
    .line 350
    .line 351
    invoke-virtual {v1, v0, v3}, Lxw3;->b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 352
    .line 353
    .line 354
    return-object v3

    .line 355
    :cond_10
    new-instance v1, Lkk0;

    .line 356
    .line 357
    invoke-direct {v1, v4}, Lkk0;-><init>(Lre7;)V

    .line 358
    .line 359
    .line 360
    iput-object v1, v0, Lic6;->i:Ljava/lang/Object;

    .line 361
    .line 362
    iput-object v3, v0, Lic6;->j:Ljava/lang/Object;

    .line 363
    .line 364
    :cond_11
    return-object v3
.end method
