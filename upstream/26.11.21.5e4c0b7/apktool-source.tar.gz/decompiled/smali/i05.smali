.class public final synthetic Li05;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic A:Lu35;

.field public final synthetic B:I

.field public final synthetic C:I

.field public final synthetic D:I

.field public final synthetic h:Lvd7;

.field public final synthetic i:Lha4;

.field public final synthetic j:Z

.field public final synthetic k:Lwg7;

.field public final synthetic l:Lnc7;

.field public final synthetic m:Lq21;

.field public final synthetic n:Llh2;

.field public final synthetic o:Llh2;

.field public final synthetic p:Llh2;

.field public final synthetic q:Lq21;

.field public final synthetic r:Z

.field public final synthetic s:Lt32;

.field public final synthetic t:Lt32;

.field public final synthetic u:Lrg3;

.field public final synthetic v:Lpg3;

.field public final synthetic w:Ltc7;

.field public final synthetic x:Lyf6;

.field public final synthetic y:Lkn6;

.field public final synthetic z:Lbb7;


# direct methods
.method public synthetic constructor <init>(Lvd7;Lha4;ZLwg7;Lnc7;Lq21;Llh2;Llh2;Llh2;Lq21;ZLt32;Lt32;Lrg3;Lpg3;Ltc7;Lyf6;Lkn6;Lbb7;Lu35;III)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li05;->h:Lvd7;

    .line 5
    .line 6
    iput-object p2, p0, Li05;->i:Lha4;

    .line 7
    .line 8
    iput-boolean p3, p0, Li05;->j:Z

    .line 9
    .line 10
    iput-object p4, p0, Li05;->k:Lwg7;

    .line 11
    .line 12
    iput-object p5, p0, Li05;->l:Lnc7;

    .line 13
    .line 14
    iput-object p6, p0, Li05;->m:Lq21;

    .line 15
    .line 16
    iput-object p7, p0, Li05;->n:Llh2;

    .line 17
    .line 18
    iput-object p8, p0, Li05;->o:Llh2;

    .line 19
    .line 20
    iput-object p9, p0, Li05;->p:Llh2;

    .line 21
    .line 22
    iput-object p10, p0, Li05;->q:Lq21;

    .line 23
    .line 24
    iput-boolean p11, p0, Li05;->r:Z

    .line 25
    .line 26
    iput-object p12, p0, Li05;->s:Lt32;

    .line 27
    .line 28
    iput-object p13, p0, Li05;->t:Lt32;

    .line 29
    .line 30
    iput-object p14, p0, Li05;->u:Lrg3;

    .line 31
    .line 32
    iput-object p15, p0, Li05;->v:Lpg3;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Li05;->w:Ltc7;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Li05;->x:Lyf6;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Li05;->y:Lkn6;

    .line 45
    .line 46
    move-object/from16 p1, p19

    .line 47
    .line 48
    iput-object p1, p0, Li05;->z:Lbb7;

    .line 49
    .line 50
    move-object/from16 p1, p20

    .line 51
    .line 52
    iput-object p1, p0, Li05;->A:Lu35;

    .line 53
    .line 54
    move/from16 p1, p21

    .line 55
    .line 56
    iput p1, p0, Li05;->B:I

    .line 57
    .line 58
    move/from16 p1, p22

    .line 59
    .line 60
    iput p1, p0, Li05;->C:I

    .line 61
    .line 62
    move/from16 p1, p23

    .line 63
    .line 64
    iput p1, p0, Li05;->D:I

    .line 65
    .line 66
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v20, p1

    .line 4
    .line 5
    check-cast v20, Lki2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget v1, v0, Li05;->B:I

    .line 15
    .line 16
    or-int/lit8 v1, v1, 0x1

    .line 17
    .line 18
    invoke-static {v1}, Ld43;->P(I)I

    .line 19
    .line 20
    .line 21
    move-result v21

    .line 22
    iget v1, v0, Li05;->C:I

    .line 23
    .line 24
    invoke-static {v1}, Ld43;->P(I)I

    .line 25
    .line 26
    .line 27
    move-result v22

    .line 28
    iget v1, v0, Li05;->D:I

    .line 29
    .line 30
    invoke-static {v1}, Ld43;->P(I)I

    .line 31
    .line 32
    .line 33
    move-result v23

    .line 34
    iget-object v1, v0, Li05;->h:Lvd7;

    .line 35
    .line 36
    move-object v2, v1

    .line 37
    iget-object v1, v0, Li05;->i:Lha4;

    .line 38
    .line 39
    move-object v3, v2

    .line 40
    iget-boolean v2, v0, Li05;->j:Z

    .line 41
    .line 42
    move-object v4, v3

    .line 43
    iget-object v3, v0, Li05;->k:Lwg7;

    .line 44
    .line 45
    move-object v5, v4

    .line 46
    iget-object v4, v0, Li05;->l:Lnc7;

    .line 47
    .line 48
    move-object v6, v5

    .line 49
    iget-object v5, v0, Li05;->m:Lq21;

    .line 50
    .line 51
    move-object v7, v6

    .line 52
    iget-object v6, v0, Li05;->n:Llh2;

    .line 53
    .line 54
    move-object v8, v7

    .line 55
    iget-object v7, v0, Li05;->o:Llh2;

    .line 56
    .line 57
    move-object v9, v8

    .line 58
    iget-object v8, v0, Li05;->p:Llh2;

    .line 59
    .line 60
    move-object v10, v9

    .line 61
    iget-object v9, v0, Li05;->q:Lq21;

    .line 62
    .line 63
    move-object v11, v10

    .line 64
    iget-boolean v10, v0, Li05;->r:Z

    .line 65
    .line 66
    move-object v12, v11

    .line 67
    iget-object v11, v0, Li05;->s:Lt32;

    .line 68
    .line 69
    move-object v13, v12

    .line 70
    iget-object v12, v0, Li05;->t:Lt32;

    .line 71
    .line 72
    move-object v14, v13

    .line 73
    iget-object v13, v0, Li05;->u:Lrg3;

    .line 74
    .line 75
    move-object v15, v14

    .line 76
    iget-object v14, v0, Li05;->v:Lpg3;

    .line 77
    .line 78
    move-object/from16 v16, v15

    .line 79
    .line 80
    iget-object v15, v0, Li05;->w:Ltc7;

    .line 81
    .line 82
    move-object/from16 v17, v1

    .line 83
    .line 84
    iget-object v1, v0, Li05;->x:Lyf6;

    .line 85
    .line 86
    move-object/from16 v18, v1

    .line 87
    .line 88
    iget-object v1, v0, Li05;->y:Lkn6;

    .line 89
    .line 90
    move-object/from16 v19, v1

    .line 91
    .line 92
    iget-object v1, v0, Li05;->z:Lbb7;

    .line 93
    .line 94
    iget-object v0, v0, Li05;->A:Lu35;

    .line 95
    .line 96
    move-object/from16 v24, v19

    .line 97
    .line 98
    move-object/from16 v19, v0

    .line 99
    .line 100
    move-object/from16 v0, v16

    .line 101
    .line 102
    move-object/from16 v16, v18

    .line 103
    .line 104
    move-object/from16 v18, v1

    .line 105
    .line 106
    move-object/from16 v1, v17

    .line 107
    .line 108
    move-object/from16 v17, v24

    .line 109
    .line 110
    invoke-static/range {v0 .. v23}, Lz33;->l(Lvd7;Lha4;ZLwg7;Lnc7;Lq21;Llh2;Llh2;Llh2;Lq21;ZLt32;Lt32;Lrg3;Lpg3;Ltc7;Lyf6;Lkn6;Lbb7;Lu35;Lki2;III)V

    .line 111
    .line 112
    .line 113
    sget-object v0, Los7;->a:Los7;

    .line 114
    .line 115
    return-object v0
.end method
