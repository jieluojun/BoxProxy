.class public final Lqp4;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lmp4;

.field public final synthetic j:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lmp4;Lzd4;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lqp4;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lqp4;->i:Lmp4;

    .line 4
    .line 5
    iput-object p2, p0, Lqp4;->j:Lzd4;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lqp4;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    iget-object v2, p0, Lqp4;->i:Lmp4;

    .line 6
    .line 7
    iget-object p0, p0, Lqp4;->j:Lzd4;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-interface {p0, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    return-object v1

    .line 16
    :pswitch_0
    invoke-interface {p0, v2}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-object v1

    .line 20
    nop

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
