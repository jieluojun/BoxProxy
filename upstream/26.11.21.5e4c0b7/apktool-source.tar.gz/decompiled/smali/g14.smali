.class public final Lg14;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Le14;


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Lsa;

.field public final d:Lv;

.field public final synthetic e:I

.field public final synthetic f:Lh14;

.field public final synthetic g:Lc3;


# direct methods
.method public constructor <init>(IILsa;Lv;Lh14;Lc3;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lg14;->e:I

    .line 5
    .line 6
    iput-object p5, p0, Lg14;->f:Lh14;

    .line 7
    .line 8
    iput-object p6, p0, Lg14;->g:Lc3;

    .line 9
    .line 10
    iput p1, p0, Lg14;->a:I

    .line 11
    .line 12
    iput p2, p0, Lg14;->b:I

    .line 13
    .line 14
    iput-object p3, p0, Lg14;->c:Lsa;

    .line 15
    .line 16
    iput-object p4, p0, Lg14;->d:Lv;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a()I
    .locals 0

    .line 1
    iget p0, p0, Lg14;->b:I

    .line 2
    .line 3
    return p0
.end method

.method public final b()I
    .locals 0

    .line 1
    iget p0, p0, Lg14;->a:I

    .line 2
    .line 3
    return p0
.end method

.method public final c()Ljava/util/Map;
    .locals 0

    .line 1
    sget-object p0, Lx12;->h:Lx12;

    .line 2
    .line 3
    return-object p0
.end method

.method public final d()V
    .locals 5

    .line 1
    iget-object v0, p0, Lg14;->f:Lh14;

    .line 2
    .line 3
    instance-of v1, v0, Lmw3;

    .line 4
    .line 5
    iget-object v2, p0, Lg14;->g:Lc3;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast v0, Lmw3;

    .line 10
    .line 11
    iget-object p0, v0, Lmw3;->w:Lnw3;

    .line 12
    .line 13
    invoke-virtual {v2, p0}, Lc3;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    new-instance v1, Lzr6;

    .line 18
    .line 19
    invoke-interface {v0}, Lcb3;->getLayoutDirection()Lgi3;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    invoke-interface {v0}, Lso1;->a()F

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    invoke-interface {v0}, Lso1;->A()F

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    iget p0, p0, Lg14;->e:I

    .line 32
    .line 33
    invoke-direct {v1, p0, v3, v4, v0}, Lzr6;-><init>(ILgi3;FF)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2, v1}, Lc3;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final e()Llh2;
    .locals 0

    .line 1
    iget-object p0, p0, Lg14;->d:Lv;

    .line 2
    .line 3
    return-object p0
.end method

.method public final g()Lhh2;
    .locals 0

    .line 1
    iget-object p0, p0, Lg14;->c:Lsa;

    .line 2
    .line 3
    return-object p0
.end method
