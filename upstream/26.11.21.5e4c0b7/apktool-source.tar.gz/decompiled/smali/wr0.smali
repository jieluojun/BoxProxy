.class public final synthetic Lwr0;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lmh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lzd4;

.field public final synthetic j:Lwg2;

.field public final synthetic k:Lzd4;


# direct methods
.method public synthetic constructor <init>(Lwg2;Lzd4;Lzd4;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lwr0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lwr0;->j:Lwg2;

    .line 4
    .line 5
    iput-object p2, p0, Lwr0;->i:Lzd4;

    .line 6
    .line 7
    iput-object p3, p0, Lwr0;->k:Lzd4;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Lzd4;Lwg2;Lzd4;B)V
    .locals 0

    .line 13
    iput-byte p4, p0, Lwr0;->h:B

    iput-object p1, p0, Lwr0;->i:Lzd4;

    iput-object p2, p0, Lwr0;->j:Lwg2;

    iput-object p3, p0, Lwr0;->k:Lzd4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lwr0;->h:B

    .line 4
    .line 5
    const-string v2, "WARNING"

    .line 6
    .line 7
    sget-object v3, Lxt3;->j:Lxt3;

    .line 8
    .line 9
    const/16 v4, 0xa

    .line 10
    .line 11
    sget-object v5, Lxt3;->m:Lk32;

    .line 12
    .line 13
    const/4 v6, 0x3

    .line 14
    const/4 v7, 0x0

    .line 15
    const/4 v8, 0x2

    .line 16
    sget-object v9, Lz41;->a:Lql0;

    .line 17
    .line 18
    sget-object v10, Los7;->a:Los7;

    .line 19
    .line 20
    const/16 v11, 0x10

    .line 21
    .line 22
    iget-object v12, v0, Lwr0;->k:Lzd4;

    .line 23
    .line 24
    iget-object v13, v0, Lwr0;->i:Lzd4;

    .line 25
    .line 26
    iget-object v0, v0, Lwr0;->j:Lwg2;

    .line 27
    .line 28
    const/4 v14, 0x0

    .line 29
    const/4 v15, 0x1

    .line 30
    packed-switch v1, :pswitch_data_0

    .line 31
    .line 32
    .line 33
    move-object/from16 v1, p1

    .line 34
    .line 35
    check-cast v1, Lm01;

    .line 36
    .line 37
    move-object/from16 v2, p2

    .line 38
    .line 39
    check-cast v2, Lki2;

    .line 40
    .line 41
    move-object/from16 v3, p3

    .line 42
    .line 43
    check-cast v3, Ljava/lang/Integer;

    .line 44
    .line 45
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    and-int/lit8 v1, v3, 0x11

    .line 53
    .line 54
    if-eq v1, v11, :cond_0

    .line 55
    .line 56
    move v1, v15

    .line 57
    goto :goto_0

    .line 58
    :cond_0
    move v1, v14

    .line 59
    :goto_0
    and-int/2addr v3, v15

    .line 60
    invoke-virtual {v2, v3, v1}, Lki2;->Y(IZ)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_5

    .line 65
    .line 66
    const v1, 0x7f0f0099

    .line 67
    .line 68
    .line 69
    invoke-static {v1, v2}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    invoke-virtual {v2, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v3

    .line 77
    invoke-virtual {v2}, Lki2;->T()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v4

    .line 81
    if-nez v3, :cond_1

    .line 82
    .line 83
    if-ne v4, v9, :cond_2

    .line 84
    .line 85
    :cond_1
    new-instance v4, Lur0;

    .line 86
    .line 87
    invoke-direct {v4, v0, v13, v6}, Lur0;-><init>(Lwg2;Lzd4;B)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v2, v4}, Lki2;->q0(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    :cond_2
    check-cast v4, Lwg2;

    .line 94
    .line 95
    new-instance v0, Lj65;

    .line 96
    .line 97
    invoke-direct {v0, v1, v4}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    const v1, 0x7f0f00be

    .line 101
    .line 102
    .line 103
    invoke-static {v1, v2}, Lhk6;->s(ILki2;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-virtual {v2}, Lki2;->T()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    if-ne v3, v9, :cond_3

    .line 112
    .line 113
    new-instance v3, Lcs0;

    .line 114
    .line 115
    invoke-direct {v3, v13, v12, v8}, Lcs0;-><init>(Lzd4;Lzd4;B)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v2, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    :cond_3
    check-cast v3, Lwg2;

    .line 122
    .line 123
    new-instance v4, Lj65;

    .line 124
    .line 125
    invoke-direct {v4, v1, v3}, Lj65;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    filled-new-array {v0, v4}, [Lj65;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-static {v0}, Lqf;->Y([Ljava/lang/Object;)Ljava/util/List;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    :goto_1
    move/from16 v18, v14

    .line 141
    .line 142
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    if-eqz v1, :cond_6

    .line 147
    .line 148
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    add-int/lit8 v14, v18, 0x1

    .line 153
    .line 154
    if-ltz v18, :cond_4

    .line 155
    .line 156
    check-cast v1, Lj65;

    .line 157
    .line 158
    iget-object v3, v1, Lj65;->h:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v3, Ljava/lang/String;

    .line 161
    .line 162
    iget-object v1, v1, Lj65;->i:Ljava/lang/Object;

    .line 163
    .line 164
    move-object/from16 v17, v1

    .line 165
    .line 166
    check-cast v17, Lwg2;

    .line 167
    .line 168
    new-instance v1, Ls;

    .line 169
    .line 170
    const/16 v4, 0xf

    .line 171
    .line 172
    invoke-direct {v1, v3, v4}, Ls;-><init>(Ljava/lang/String;B)V

    .line 173
    .line 174
    .line 175
    const v3, -0x183234cc

    .line 176
    .line 177
    .line 178
    invoke-static {v3, v1, v2}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 179
    .line 180
    .line 181
    move-result-object v16

    .line 182
    const/16 v26, 0xc06

    .line 183
    .line 184
    const/16 v27, 0x3f0

    .line 185
    .line 186
    const/16 v19, 0x2

    .line 187
    .line 188
    const/16 v20, 0x0

    .line 189
    .line 190
    const/16 v21, 0x0

    .line 191
    .line 192
    const/16 v22, 0x0

    .line 193
    .line 194
    const/16 v23, 0x0

    .line 195
    .line 196
    const/16 v24, 0x0

    .line 197
    .line 198
    move-object/from16 v25, v2

    .line 199
    .line 200
    invoke-static/range {v16 .. v27}, La04;->a(Lq21;Lwg2;IILha4;Lq21;ZLd24;Lu35;Lki2;II)V

    .line 201
    .line 202
    .line 203
    goto :goto_1

    .line 204
    :cond_4
    invoke-static {}, Lqf;->z0()V

    .line 205
    .line 206
    .line 207
    throw v7

    .line 208
    :cond_5
    move-object/from16 v25, v2

    .line 209
    .line 210
    invoke-virtual/range {v25 .. v25}, Lki2;->b0()V

    .line 211
    .line 212
    .line 213
    :cond_6
    return-object v10

    .line 214
    :pswitch_0
    move-object/from16 v1, p1

    .line 215
    .line 216
    check-cast v1, Lm01;

    .line 217
    .line 218
    move-object/from16 v2, p2

    .line 219
    .line 220
    check-cast v2, Lki2;

    .line 221
    .line 222
    move-object/from16 v3, p3

    .line 223
    .line 224
    check-cast v3, Ljava/lang/Integer;

    .line 225
    .line 226
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 227
    .line 228
    .line 229
    move-result v3

    .line 230
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 231
    .line 232
    .line 233
    and-int/lit8 v1, v3, 0x11

    .line 234
    .line 235
    if-eq v1, v11, :cond_7

    .line 236
    .line 237
    move v14, v15

    .line 238
    :cond_7
    and-int/2addr v3, v15

    .line 239
    invoke-virtual {v2, v3, v14}, Lki2;->Y(IZ)Z

    .line 240
    .line 241
    .line 242
    move-result v1

    .line 243
    if-eqz v1, :cond_8

    .line 244
    .line 245
    new-instance v1, Lwr0;

    .line 246
    .line 247
    invoke-direct {v1, v0, v13, v12, v6}, Lwr0;-><init>(Lwg2;Lzd4;Lzd4;B)V

    .line 248
    .line 249
    .line 250
    const v0, 0x7128f66

    .line 251
    .line 252
    .line 253
    invoke-static {v0, v1, v2}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 254
    .line 255
    .line 256
    move-result-object v22

    .line 257
    const/high16 v24, 0x30000

    .line 258
    .line 259
    const/16 v25, 0x1f

    .line 260
    .line 261
    const/16 v16, 0x0

    .line 262
    .line 263
    const/16 v17, 0x0

    .line 264
    .line 265
    const/16 v18, 0x0

    .line 266
    .line 267
    const/16 v19, 0x0

    .line 268
    .line 269
    const-wide/16 v20, 0x0

    .line 270
    .line 271
    move-object/from16 v23, v2

    .line 272
    .line 273
    invoke-static/range {v16 .. v25}, La04;->c(IILha4;Lc24;JLq21;Lki2;II)V

    .line 274
    .line 275
    .line 276
    goto :goto_2

    .line 277
    :cond_8
    move-object/from16 v23, v2

    .line 278
    .line 279
    invoke-virtual/range {v23 .. v23}, Lki2;->b0()V

    .line 280
    .line 281
    .line 282
    :goto_2
    return-object v10

    .line 283
    :pswitch_1
    move-object/from16 v1, p1

    .line 284
    .line 285
    check-cast v1, Lj16;

    .line 286
    .line 287
    move-object/from16 v6, p2

    .line 288
    .line 289
    check-cast v6, Lki2;

    .line 290
    .line 291
    move-object/from16 v16, p3

    .line 292
    .line 293
    check-cast v16, Ljava/lang/Integer;

    .line 294
    .line 295
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Integer;->intValue()I

    .line 296
    .line 297
    .line 298
    move-result v16

    .line 299
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 300
    .line 301
    .line 302
    and-int/lit8 v1, v16, 0x11

    .line 303
    .line 304
    if-eq v1, v11, :cond_9

    .line 305
    .line 306
    move v1, v15

    .line 307
    goto :goto_3

    .line 308
    :cond_9
    move v1, v14

    .line 309
    :goto_3
    and-int/lit8 v11, v16, 0x1

    .line 310
    .line 311
    invoke-virtual {v6, v11, v1}, Lki2;->Y(IZ)Z

    .line 312
    .line 313
    .line 314
    move-result v1

    .line 315
    if-eqz v1, :cond_11

    .line 316
    .line 317
    invoke-virtual {v6, v13}, Lki2;->g(Ljava/lang/Object;)Z

    .line 318
    .line 319
    .line 320
    move-result v1

    .line 321
    invoke-virtual {v6, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 322
    .line 323
    .line 324
    move-result v11

    .line 325
    or-int/2addr v1, v11

    .line 326
    invoke-virtual {v6}, Lki2;->T()Ljava/lang/Object;

    .line 327
    .line 328
    .line 329
    move-result-object v11

    .line 330
    if-nez v1, :cond_a

    .line 331
    .line 332
    if-ne v11, v9, :cond_b

    .line 333
    .line 334
    :cond_a
    new-instance v11, Lur0;

    .line 335
    .line 336
    invoke-direct {v11, v0, v13, v15}, Lur0;-><init>(Lwg2;Lzd4;B)V

    .line 337
    .line 338
    .line 339
    invoke-virtual {v6, v11}, Lki2;->q0(Ljava/lang/Object;)V

    .line 340
    .line 341
    .line 342
    :cond_b
    move-object/from16 v16, v11

    .line 343
    .line 344
    check-cast v16, Lwg2;

    .line 345
    .line 346
    new-instance v0, Lzb;

    .line 347
    .line 348
    invoke-direct {v0, v13, v15}, Lzb;-><init>(Lzd4;B)V

    .line 349
    .line 350
    .line 351
    const v1, -0x13ac3d2e

    .line 352
    .line 353
    .line 354
    invoke-static {v1, v0, v6}, Lfi;->Z(ILth2;Lki2;)Lq21;

    .line 355
    .line 356
    .line 357
    move-result-object v25

    .line 358
    const/high16 v27, 0x6000000

    .line 359
    .line 360
    const/16 v28, 0xfe

    .line 361
    .line 362
    const/16 v17, 0x0

    .line 363
    .line 364
    const/16 v18, 0x0

    .line 365
    .line 366
    const/16 v19, 0x0

    .line 367
    .line 368
    const-wide/16 v20, 0x0

    .line 369
    .line 370
    const/16 v22, 0x0

    .line 371
    .line 372
    const/16 v23, 0x0

    .line 373
    .line 374
    const/16 v24, 0x0

    .line 375
    .line 376
    move-object/from16 v26, v6

    .line 377
    .line 378
    invoke-static/range {v16 .. v28}, Lr94;->b(Lwg2;Lha4;ZZJFFFLlh2;Lki2;II)V

    .line 379
    .line 380
    .line 381
    move-object/from16 v0, v26

    .line 382
    .line 383
    const v1, 0x442383ca

    .line 384
    .line 385
    .line 386
    invoke-virtual {v0, v1}, Lki2;->h0(I)V

    .line 387
    .line 388
    .line 389
    new-instance v1, Ljava/util/ArrayList;

    .line 390
    .line 391
    invoke-static {v5, v4}, Lyx0;->F0(Ljava/lang/Iterable;I)I

    .line 392
    .line 393
    .line 394
    move-result v4

    .line 395
    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 396
    .line 397
    .line 398
    invoke-virtual {v5}, Lq3;->iterator()Ljava/util/Iterator;

    .line 399
    .line 400
    .line 401
    move-result-object v4

    .line 402
    :goto_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 403
    .line 404
    .line 405
    move-result v5

    .line 406
    if-eqz v5, :cond_10

    .line 407
    .line 408
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 409
    .line 410
    .line 411
    move-result-object v5

    .line 412
    check-cast v5, Lxt3;

    .line 413
    .line 414
    if-ne v5, v3, :cond_c

    .line 415
    .line 416
    move-object/from16 v17, v2

    .line 417
    .line 418
    goto :goto_5

    .line 419
    :cond_c
    invoke-virtual {v5}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 420
    .line 421
    .line 422
    move-result-object v6

    .line 423
    move-object/from16 v17, v6

    .line 424
    .line 425
    :goto_5
    invoke-interface {v12}, Lxy6;->getValue()Ljava/lang/Object;

    .line 426
    .line 427
    .line 428
    move-result-object v6

    .line 429
    check-cast v6, Lxt3;

    .line 430
    .line 431
    if-ne v6, v5, :cond_d

    .line 432
    .line 433
    move/from16 v19, v15

    .line 434
    .line 435
    goto :goto_6

    .line 436
    :cond_d
    move/from16 v19, v14

    .line 437
    .line 438
    :goto_6
    invoke-virtual {v0, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 439
    .line 440
    .line 441
    move-result v6

    .line 442
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 443
    .line 444
    .line 445
    move-result v11

    .line 446
    invoke-virtual {v0, v11}, Lki2;->e(I)Z

    .line 447
    .line 448
    .line 449
    move-result v11

    .line 450
    or-int/2addr v6, v11

    .line 451
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 452
    .line 453
    .line 454
    move-result-object v11

    .line 455
    if-nez v6, :cond_e

    .line 456
    .line 457
    if-ne v11, v9, :cond_f

    .line 458
    .line 459
    :cond_e
    new-instance v11, Lvr0;

    .line 460
    .line 461
    invoke-direct {v11, v5, v12, v15}, Lvr0;-><init>(Lxt3;Lzd4;B)V

    .line 462
    .line 463
    .line 464
    invoke-virtual {v0, v11}, Lki2;->q0(Ljava/lang/Object;)V

    .line 465
    .line 466
    .line 467
    :cond_f
    move-object/from16 v20, v11

    .line 468
    .line 469
    check-cast v20, Lwg2;

    .line 470
    .line 471
    new-instance v16, Llw1;

    .line 472
    .line 473
    const/16 v18, 0x0

    .line 474
    .line 475
    const/16 v21, 0x0

    .line 476
    .line 477
    const/16 v22, 0x72

    .line 478
    .line 479
    invoke-direct/range {v16 .. v22}, Llw1;-><init>(Ljava/lang/String;ZZLwg2;Ljava/util/List;I)V

    .line 480
    .line 481
    .line 482
    move-object/from16 v5, v16

    .line 483
    .line 484
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 485
    .line 486
    .line 487
    goto :goto_4

    .line 488
    :cond_10
    invoke-virtual {v0, v14}, Lki2;->r(Z)V

    .line 489
    .line 490
    .line 491
    new-instance v2, Lkw1;

    .line 492
    .line 493
    invoke-direct {v2, v1}, Lkw1;-><init>(Ljava/util/List;)V

    .line 494
    .line 495
    .line 496
    invoke-static {v2}, Lqf;->X(Ljava/lang/Object;)Ljava/util/List;

    .line 497
    .line 498
    .line 499
    move-result-object v1

    .line 500
    invoke-static {v1, v7, v0, v14, v8}, Ll63;->g(Ljava/util/List;Lwg2;Lki2;II)V

    .line 501
    .line 502
    .line 503
    goto :goto_7

    .line 504
    :cond_11
    move-object v0, v6

    .line 505
    invoke-virtual {v0}, Lki2;->b0()V

    .line 506
    .line 507
    .line 508
    :goto_7
    return-object v10

    .line 509
    :pswitch_2
    move-object/from16 v1, p1

    .line 510
    .line 511
    check-cast v1, Lj16;

    .line 512
    .line 513
    move-object/from16 v6, p2

    .line 514
    .line 515
    check-cast v6, Lki2;

    .line 516
    .line 517
    move-object/from16 v16, p3

    .line 518
    .line 519
    check-cast v16, Ljava/lang/Integer;

    .line 520
    .line 521
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Integer;->intValue()I

    .line 522
    .line 523
    .line 524
    move-result v16

    .line 525
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 526
    .line 527
    .line 528
    and-int/lit8 v1, v16, 0x11

    .line 529
    .line 530
    if-eq v1, v11, :cond_12

    .line 531
    .line 532
    move v1, v15

    .line 533
    goto :goto_8

    .line 534
    :cond_12
    move v1, v14

    .line 535
    :goto_8
    and-int/lit8 v11, v16, 0x1

    .line 536
    .line 537
    invoke-virtual {v6, v11, v1}, Lki2;->Y(IZ)Z

    .line 538
    .line 539
    .line 540
    move-result v1

    .line 541
    if-eqz v1, :cond_1a

    .line 542
    .line 543
    invoke-virtual {v6, v13}, Lki2;->g(Ljava/lang/Object;)Z

    .line 544
    .line 545
    .line 546
    move-result v1

    .line 547
    invoke-virtual {v6, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 548
    .line 549
    .line 550
    move-result v11

    .line 551
    or-int/2addr v1, v11

    .line 552
    invoke-virtual {v6}, Lki2;->T()Ljava/lang/Object;

    .line 553
    .line 554
    .line 555
    move-result-object v11

    .line 556
    if-nez v1, :cond_13

    .line 557
    .line 558
    if-ne v11, v9, :cond_14

    .line 559
    .line 560
    :cond_13
    new-instance v11, Lur0;

    .line 561
    .line 562
    invoke-direct {v11, v0, v13, v14}, Lur0;-><init>(Lwg2;Lzd4;B)V

    .line 563
    .line 564
    .line 565
    invoke-virtual {v6, v11}, Lki2;->q0(Ljava/lang/Object;)V

    .line 566
    .line 567
    .line 568
    :cond_14
    move-object/from16 v16, v11

    .line 569
    .line 570
    check-cast v16, Lwg2;

    .line 571
    .line 572
    invoke-interface {v13}, Lxy6;->getValue()Ljava/lang/Object;

    .line 573
    .line 574
    .line 575
    move-result-object v0

    .line 576
    check-cast v0, Ljava/lang/Boolean;

    .line 577
    .line 578
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 579
    .line 580
    .line 581
    move-result v18

    .line 582
    sget-object v20, Lkb;->l:Lq21;

    .line 583
    .line 584
    const/16 v22, 0x6000

    .line 585
    .line 586
    const/16 v23, 0xa

    .line 587
    .line 588
    const/16 v17, 0x0

    .line 589
    .line 590
    const/16 v19, 0x0

    .line 591
    .line 592
    move-object/from16 v21, v6

    .line 593
    .line 594
    invoke-static/range {v16 .. v23}, Lx33;->c(Lwg2;Lha4;ZZLlh2;Lki2;II)V

    .line 595
    .line 596
    .line 597
    move-object/from16 v0, v21

    .line 598
    .line 599
    const v1, 0x4b670ca7    # 1.5142055E7f

    .line 600
    .line 601
    .line 602
    invoke-virtual {v0, v1}, Lki2;->h0(I)V

    .line 603
    .line 604
    .line 605
    new-instance v1, Ljava/util/ArrayList;

    .line 606
    .line 607
    invoke-static {v5, v4}, Lyx0;->F0(Ljava/lang/Iterable;I)I

    .line 608
    .line 609
    .line 610
    move-result v4

    .line 611
    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 612
    .line 613
    .line 614
    invoke-virtual {v5}, Lq3;->iterator()Ljava/util/Iterator;

    .line 615
    .line 616
    .line 617
    move-result-object v4

    .line 618
    :goto_9
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 619
    .line 620
    .line 621
    move-result v5

    .line 622
    if-eqz v5, :cond_19

    .line 623
    .line 624
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 625
    .line 626
    .line 627
    move-result-object v5

    .line 628
    check-cast v5, Lxt3;

    .line 629
    .line 630
    if-ne v5, v3, :cond_15

    .line 631
    .line 632
    move-object/from16 v17, v2

    .line 633
    .line 634
    goto :goto_a

    .line 635
    :cond_15
    invoke-virtual {v5}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 636
    .line 637
    .line 638
    move-result-object v6

    .line 639
    move-object/from16 v17, v6

    .line 640
    .line 641
    :goto_a
    invoke-interface {v12}, Lxy6;->getValue()Ljava/lang/Object;

    .line 642
    .line 643
    .line 644
    move-result-object v6

    .line 645
    check-cast v6, Lxt3;

    .line 646
    .line 647
    if-ne v6, v5, :cond_16

    .line 648
    .line 649
    move/from16 v19, v15

    .line 650
    .line 651
    goto :goto_b

    .line 652
    :cond_16
    move/from16 v19, v14

    .line 653
    .line 654
    :goto_b
    invoke-virtual {v0, v12}, Lki2;->g(Ljava/lang/Object;)Z

    .line 655
    .line 656
    .line 657
    move-result v6

    .line 658
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 659
    .line 660
    .line 661
    move-result v11

    .line 662
    invoke-virtual {v0, v11}, Lki2;->e(I)Z

    .line 663
    .line 664
    .line 665
    move-result v11

    .line 666
    or-int/2addr v6, v11

    .line 667
    invoke-virtual {v0}, Lki2;->T()Ljava/lang/Object;

    .line 668
    .line 669
    .line 670
    move-result-object v11

    .line 671
    if-nez v6, :cond_17

    .line 672
    .line 673
    if-ne v11, v9, :cond_18

    .line 674
    .line 675
    :cond_17
    new-instance v11, Lvr0;

    .line 676
    .line 677
    invoke-direct {v11, v5, v12, v14}, Lvr0;-><init>(Lxt3;Lzd4;B)V

    .line 678
    .line 679
    .line 680
    invoke-virtual {v0, v11}, Lki2;->q0(Ljava/lang/Object;)V

    .line 681
    .line 682
    .line 683
    :cond_18
    move-object/from16 v20, v11

    .line 684
    .line 685
    check-cast v20, Lwg2;

    .line 686
    .line 687
    new-instance v16, Llw1;

    .line 688
    .line 689
    const/16 v18, 0x0

    .line 690
    .line 691
    const/16 v21, 0x0

    .line 692
    .line 693
    const/16 v22, 0x72

    .line 694
    .line 695
    invoke-direct/range {v16 .. v22}, Llw1;-><init>(Ljava/lang/String;ZZLwg2;Ljava/util/List;I)V

    .line 696
    .line 697
    .line 698
    move-object/from16 v5, v16

    .line 699
    .line 700
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 701
    .line 702
    .line 703
    goto :goto_9

    .line 704
    :cond_19
    invoke-virtual {v0, v14}, Lki2;->r(Z)V

    .line 705
    .line 706
    .line 707
    new-instance v2, Lkw1;

    .line 708
    .line 709
    invoke-direct {v2, v1}, Lkw1;-><init>(Ljava/util/List;)V

    .line 710
    .line 711
    .line 712
    invoke-static {v2}, Lqf;->X(Ljava/lang/Object;)Ljava/util/List;

    .line 713
    .line 714
    .line 715
    move-result-object v1

    .line 716
    invoke-static {v1, v7, v0, v14, v8}, Le43;->b(Ljava/util/List;Lwg2;Lki2;II)V

    .line 717
    .line 718
    .line 719
    goto :goto_c

    .line 720
    :cond_1a
    move-object v0, v6

    .line 721
    invoke-virtual {v0}, Lki2;->b0()V

    .line 722
    .line 723
    .line 724
    :goto_c
    return-object v10

    .line 725
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
