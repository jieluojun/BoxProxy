.class public final synthetic Lbl5;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lwg2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Z

.field public final synthetic j:Z

.field public final synthetic k:Lzd4;


# direct methods
.method public synthetic constructor <init>(ZZLzd4;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lbl5;->h:B

    .line 2
    .line 3
    iput-boolean p1, p0, Lbl5;->i:Z

    .line 4
    .line 5
    iput-boolean p2, p0, Lbl5;->j:Z

    .line 6
    .line 7
    iput-object p3, p0, Lbl5;->k:Lzd4;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-byte v0, p0, Lbl5;->h:B

    .line 2
    .line 3
    sget-object v1, Los7;->a:Los7;

    .line 4
    .line 5
    iget-object v2, p0, Lbl5;->k:Lzd4;

    .line 6
    .line 7
    iget-boolean v3, p0, Lbl5;->j:Z

    .line 8
    .line 9
    iget-boolean p0, p0, Lbl5;->i:Z

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    if-eqz p0, :cond_0

    .line 15
    .line 16
    if-nez v3, :cond_0

    .line 17
    .line 18
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 19
    .line 20
    invoke-interface {v2, p0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-object v1

    .line 24
    :pswitch_0
    if-eqz p0, :cond_1

    .line 25
    .line 26
    if-nez v3, :cond_1

    .line 27
    .line 28
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 29
    .line 30
    invoke-interface {v2, p0}, Lzd4;->setValue(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_1
    return-object v1

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
