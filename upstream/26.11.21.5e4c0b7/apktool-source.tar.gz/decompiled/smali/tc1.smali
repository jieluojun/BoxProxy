.class public final Ltc1;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final a:Lg32;

.field public final b:Lz42;

.field public final c:Lb75;

.field public d:Llt6;


# direct methods
.method public constructor <init>(Lg32;Lz42;)V
    .locals 1

    .line 1
    sget-object v0, Llh;->a:Ltx6;

    .line 2
    .line 3
    sget-object v0, Llh;->b:Llt6;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Ltc1;->a:Lg32;

    .line 9
    .line 10
    iput-object p2, p0, Ltc1;->b:Lz42;

    .line 11
    .line 12
    new-instance p1, Lb75;

    .line 13
    .line 14
    const/4 p2, 0x0

    .line 15
    invoke-direct {p1, p2}, Lb75;-><init>(F)V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, Ltc1;->c:Lb75;

    .line 19
    .line 20
    iput-object v0, p0, Ltc1;->d:Llt6;

    .line 21
    .line 22
    return-void
.end method
