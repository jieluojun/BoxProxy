.class public final synthetic Lto2;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Lnh2;


# instance fields
.field public final synthetic h:Lij2;

.field public final synthetic i:Lgn2;

.field public final synthetic j:Lg00;

.field public final synthetic k:Lgn2;

.field public final synthetic l:Lxy6;

.field public final synthetic m:Lxy6;

.field public final synthetic n:Lxy6;


# direct methods
.method public synthetic constructor <init>(Lij2;Lgn2;Lg00;Lgn2;Lxy6;Lxy6;Lxy6;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lto2;->h:Lij2;

    .line 5
    .line 6
    iput-object p2, p0, Lto2;->i:Lgn2;

    .line 7
    .line 8
    iput-object p3, p0, Lto2;->j:Lg00;

    .line 9
    .line 10
    iput-object p4, p0, Lto2;->k:Lgn2;

    .line 11
    .line 12
    iput-object p5, p0, Lto2;->l:Lxy6;

    .line 13
    .line 14
    iput-object p6, p0, Lto2;->m:Lxy6;

    .line 15
    .line 16
    iput-object p7, p0, Lto2;->n:Lxy6;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final r(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    move-object v0, p1

    .line 2
    check-cast v0, Lfe0;

    .line 3
    .line 4
    move-object v2, p2

    .line 5
    check-cast v2, Lqn2;

    .line 6
    .line 7
    move-object v6, p3

    .line 8
    check-cast v6, Lki2;

    .line 9
    .line 10
    check-cast p4, Ljava/lang/Integer;

    .line 11
    .line 12
    invoke-virtual {p4}, Ljava/lang/Integer;->intValue()I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 p2, p1, 0x6

    .line 23
    .line 24
    if-nez p2, :cond_1

    .line 25
    .line 26
    invoke-virtual {v6, v0}, Lki2;->g(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result p2

    .line 30
    if-eqz p2, :cond_0

    .line 31
    .line 32
    const/4 p2, 0x4

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const/4 p2, 0x2

    .line 35
    :goto_0
    or-int/2addr p2, p1

    .line 36
    goto :goto_1

    .line 37
    :cond_1
    move p2, p1

    .line 38
    :goto_1
    and-int/lit8 p1, p1, 0x30

    .line 39
    .line 40
    if-nez p1, :cond_3

    .line 41
    .line 42
    invoke-virtual {v6, v2}, Lki2;->g(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    if-eqz p1, :cond_2

    .line 47
    .line 48
    const/16 p1, 0x20

    .line 49
    .line 50
    goto :goto_2

    .line 51
    :cond_2
    const/16 p1, 0x10

    .line 52
    .line 53
    :goto_2
    or-int/2addr p2, p1

    .line 54
    :cond_3
    and-int/lit16 p1, p2, 0x93

    .line 55
    .line 56
    const/16 p3, 0x92

    .line 57
    .line 58
    const/4 p4, 0x0

    .line 59
    if-eq p1, p3, :cond_4

    .line 60
    .line 61
    const/4 p1, 0x1

    .line 62
    goto :goto_3

    .line 63
    :cond_4
    move p1, p4

    .line 64
    :goto_3
    and-int/lit8 p3, p2, 0x1

    .line 65
    .line 66
    invoke-virtual {v6, p3, p1}, Lki2;->Y(IZ)Z

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-eqz p1, :cond_9

    .line 71
    .line 72
    iget-object p1, p0, Lto2;->m:Lxy6;

    .line 73
    .line 74
    invoke-interface {p1}, Lxy6;->getValue()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    check-cast p1, Ljava/lang/Boolean;

    .line 79
    .line 80
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    iget-object p3, p0, Lto2;->h:Lij2;

    .line 85
    .line 86
    if-eqz p1, :cond_5

    .line 87
    .line 88
    if-eqz p3, :cond_5

    .line 89
    .line 90
    iget-object v3, p0, Lto2;->i:Lgn2;

    .line 91
    .line 92
    if-eqz v3, :cond_5

    .line 93
    .line 94
    const p1, -0x42e9825e

    .line 95
    .line 96
    .line 97
    invoke-virtual {v6, p1}, Lki2;->h0(I)V

    .line 98
    .line 99
    .line 100
    iget-object v1, p3, Lij2;->a:Lg00;

    .line 101
    .line 102
    iget-object v5, p3, Lij2;->d:Ltk2;

    .line 103
    .line 104
    and-int/lit8 p1, p2, 0xe

    .line 105
    .line 106
    shl-int/lit8 v4, p2, 0x3

    .line 107
    .line 108
    and-int/lit16 v4, v4, 0x380

    .line 109
    .line 110
    or-int v7, p1, v4

    .line 111
    .line 112
    const/16 v8, 0x8

    .line 113
    .line 114
    const/4 v4, 0x0

    .line 115
    invoke-static/range {v0 .. v8}, Lxp7;->b(Lfe0;Lg00;Lqn2;Lgn2;Lha4;Ltk2;Lki2;II)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v6, p4}, Lki2;->r(Z)V

    .line 119
    .line 120
    .line 121
    goto :goto_4

    .line 122
    :cond_5
    const p1, -0x42e57289

    .line 123
    .line 124
    .line 125
    invoke-virtual {v6, p1}, Lki2;->h0(I)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v6, p4}, Lki2;->r(Z)V

    .line 129
    .line 130
    .line 131
    :goto_4
    iget-object p1, p0, Lto2;->n:Lxy6;

    .line 132
    .line 133
    invoke-interface {p1}, Lxy6;->getValue()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    check-cast p1, Ljava/lang/Boolean;

    .line 138
    .line 139
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 140
    .line 141
    .line 142
    move-result p1

    .line 143
    if-eqz p1, :cond_8

    .line 144
    .line 145
    const p1, -0x42e4c350

    .line 146
    .line 147
    .line 148
    invoke-virtual {v6, p1}, Lki2;->h0(I)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v6, p3}, Lki2;->g(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result p1

    .line 155
    iget-object v1, p0, Lto2;->l:Lxy6;

    .line 156
    .line 157
    invoke-virtual {v6, v1}, Lki2;->g(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v3

    .line 161
    or-int/2addr p1, v3

    .line 162
    invoke-virtual {v6}, Lki2;->T()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v3

    .line 166
    if-nez p1, :cond_6

    .line 167
    .line 168
    sget-object p1, Lz41;->a:Lql0;

    .line 169
    .line 170
    if-ne v3, p1, :cond_7

    .line 171
    .line 172
    :cond_6
    new-instance v3, Ln2;

    .line 173
    .line 174
    const/16 p1, 0x1c

    .line 175
    .line 176
    invoke-direct {v3, p3, v1, p1}, Ln2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v6, v3}, Lki2;->q0(Ljava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    :cond_7
    check-cast v3, Lhh2;

    .line 183
    .line 184
    sget-object p1, Lea4;->h:Lea4;

    .line 185
    .line 186
    invoke-static {p1, v3}, Lnt7;->Q(Lha4;Lhh2;)Lha4;

    .line 187
    .line 188
    .line 189
    move-result-object v4

    .line 190
    and-int/lit8 p1, p2, 0xe

    .line 191
    .line 192
    shl-int/lit8 p2, p2, 0x3

    .line 193
    .line 194
    and-int/lit16 p2, p2, 0x380

    .line 195
    .line 196
    or-int v7, p1, p2

    .line 197
    .line 198
    const/16 v8, 0x10

    .line 199
    .line 200
    iget-object v1, p0, Lto2;->j:Lg00;

    .line 201
    .line 202
    iget-object v3, p0, Lto2;->k:Lgn2;

    .line 203
    .line 204
    const/4 v5, 0x0

    .line 205
    invoke-static/range {v0 .. v8}, Lxp7;->b(Lfe0;Lg00;Lqn2;Lgn2;Lha4;Ltk2;Lki2;II)V

    .line 206
    .line 207
    .line 208
    invoke-virtual {v6, p4}, Lki2;->r(Z)V

    .line 209
    .line 210
    .line 211
    goto :goto_5

    .line 212
    :cond_8
    const p0, -0x42df7fa9

    .line 213
    .line 214
    .line 215
    invoke-virtual {v6, p0}, Lki2;->h0(I)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v6, p4}, Lki2;->r(Z)V

    .line 219
    .line 220
    .line 221
    goto :goto_5

    .line 222
    :cond_9
    invoke-virtual {v6}, Lki2;->b0()V

    .line 223
    .line 224
    .line 225
    :goto_5
    sget-object p0, Los7;->a:Los7;

    .line 226
    .line 227
    return-object p0
.end method
