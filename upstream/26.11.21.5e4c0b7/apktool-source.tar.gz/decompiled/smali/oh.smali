.class public final synthetic Loh;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Lha4;

.field public final synthetic j:Lhh2;

.field public final synthetic k:La40;

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:Lhh2;

.field public final synthetic n:Lq21;

.field public final synthetic o:I

.field public final synthetic p:B


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Lha4;Lhh2;La40;Ljava/lang/String;Lhh2;Lq21;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Loh;->h:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Loh;->i:Lha4;

    .line 7
    .line 8
    iput-object p3, p0, Loh;->j:Lhh2;

    .line 9
    .line 10
    iput-object p4, p0, Loh;->k:La40;

    .line 11
    .line 12
    iput-object p5, p0, Loh;->l:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p6, p0, Loh;->m:Lhh2;

    .line 15
    .line 16
    iput-object p7, p0, Loh;->n:Lq21;

    .line 17
    .line 18
    iput p8, p0, Loh;->o:I

    .line 19
    .line 20
    iput-byte p9, p0, Loh;->p:B

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    move-object v7, p1

    .line 2
    check-cast v7, Lki2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Loh;->o:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Ld43;->P(I)I

    .line 14
    .line 15
    .line 16
    move-result v8

    .line 17
    iget-object v0, p0, Loh;->h:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v1, p0, Loh;->i:Lha4;

    .line 20
    .line 21
    iget-object v2, p0, Loh;->j:Lhh2;

    .line 22
    .line 23
    iget-object v3, p0, Loh;->k:La40;

    .line 24
    .line 25
    iget-object v4, p0, Loh;->l:Ljava/lang/String;

    .line 26
    .line 27
    iget-object v5, p0, Loh;->m:Lhh2;

    .line 28
    .line 29
    iget-object v6, p0, Loh;->n:Lq21;

    .line 30
    .line 31
    iget-byte v9, p0, Loh;->p:B

    .line 32
    .line 33
    invoke-static/range {v0 .. v9}, Lf48;->b(Ljava/lang/Object;Lha4;Lhh2;La40;Ljava/lang/String;Lhh2;Lq21;Lki2;II)V

    .line 34
    .line 35
    .line 36
    sget-object p0, Los7;->a:Los7;

    .line 37
    .line 38
    return-object p0
.end method
