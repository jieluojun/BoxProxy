.class public final Lwb3;
.super Lxc3;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# instance fields
.field public final l:Lhh2;


# direct methods
.method public constructor <init>(Lhh2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ltt3;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lwb3;->l:Lhh2;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final m()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final n(Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lwb3;->l:Lhh2;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lhh2;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method
