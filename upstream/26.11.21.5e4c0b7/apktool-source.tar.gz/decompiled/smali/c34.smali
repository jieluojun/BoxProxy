.class public interface abstract Lc34;
.super Ljava/lang/Object;
.source "r8-map-id-52ddb47da1d456594aaa21dedae79070cebde06bfb25ac921653bf5eec8896f3"


# virtual methods
.method public abstract b(Lz14;Z)V
.end method

.method public abstract d(Lf24;)Z
.end method

.method public abstract e(Lb34;)V
.end method

.method public abstract f(Lf24;)Z
.end method

.method public abstract g()V
.end method

.method public abstract i(Landroid/content/Context;Lz14;)V
.end method

.method public abstract j(Ll17;)Z
.end method

.method public abstract k()Z
.end method
