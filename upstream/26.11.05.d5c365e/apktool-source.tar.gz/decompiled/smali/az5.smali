.class public Laz5;
.super Ljava/lang/IllegalArgumentException;
.source "r8-map-id-20ba21aa719a118f6636b4195284472d40e9653eb9bd33ff7cbddda1dfd1d123"
