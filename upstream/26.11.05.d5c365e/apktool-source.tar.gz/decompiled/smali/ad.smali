.class public final Lad;
.super Ljava/lang/Object;
.source "r8-map-id-20ba21aa719a118f6636b4195284472d40e9653eb9bd33ff7cbddda1dfd1d123"

# interfaces
.implements Lkm4;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Lls6;

.field public final c:Ljava/util/List;

.field public final d:Ljava/util/List;

.field public final e:Lc42;

.field public final f:Lyh1;

.field public final g:Ldf;

.field public final h:Ljava/lang/CharSequence;

.field public final i:Ly03;

.field public j:Luq6;

.field public final k:Z

.field public final l:I

.field public final m:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Lls6;Ljava/util/List;Ljava/util/List;Lc42;Lyh1;Z)V
    .locals 41

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    move-object/from16 v3, p6

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    move-object/from16 v4, p1

    .line 13
    .line 14
    iput-object v4, v0, Lad;->a:Ljava/lang/String;

    .line 15
    .line 16
    iput-object v1, v0, Lad;->b:Lls6;

    .line 17
    .line 18
    iput-object v2, v0, Lad;->c:Ljava/util/List;

    .line 19
    .line 20
    move-object/from16 v4, p4

    .line 21
    .line 22
    iput-object v4, v0, Lad;->d:Ljava/util/List;

    .line 23
    .line 24
    move-object/from16 v4, p5

    .line 25
    .line 26
    iput-object v4, v0, Lad;->e:Lc42;

    .line 27
    .line 28
    iput-object v3, v0, Lad;->f:Lyh1;

    .line 29
    .line 30
    new-instance v4, Ldf;

    .line 31
    .line 32
    invoke-interface {v3}, Lyh1;->a()F

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    const/4 v6, 0x1

    .line 37
    invoke-direct {v4, v6}, Landroid/text/TextPaint;-><init>(I)V

    .line 38
    .line 39
    .line 40
    iput v5, v4, Landroid/text/TextPaint;->density:F

    .line 41
    .line 42
    sget-object v5, Lgm6;->b:Lgm6;

    .line 43
    .line 44
    iput-object v5, v4, Ldf;->b:Lgm6;

    .line 45
    .line 46
    const/4 v5, 0x3

    .line 47
    iput-byte v5, v4, Ldf;->c:B

    .line 48
    .line 49
    sget-object v7, Lk06;->d:Lk06;

    .line 50
    .line 51
    iput-object v7, v4, Ldf;->d:Lk06;

    .line 52
    .line 53
    iput-object v4, v0, Lad;->g:Ldf;

    .line 54
    .line 55
    invoke-static {v1}, Lfh3;->B(Lls6;)Z

    .line 56
    .line 57
    .line 58
    move-result v7

    .line 59
    iget-object v8, v1, Lls6;->a:Lr96;

    .line 60
    .line 61
    iget-object v1, v1, Lls6;->b:Lmm4;

    .line 62
    .line 63
    const/4 v9, 0x0

    .line 64
    if-nez v7, :cond_0

    .line 65
    .line 66
    move v7, v9

    .line 67
    goto :goto_1

    .line 68
    :cond_0
    sget-object v7, Lrt1;->a:Le6;

    .line 69
    .line 70
    sget-object v7, Lrt1;->a:Le6;

    .line 71
    .line 72
    iget-object v10, v7, Le6;->k:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v10, Lmb6;

    .line 75
    .line 76
    if-eqz v10, :cond_1

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_1
    invoke-static {}, Lot1;->d()Z

    .line 80
    .line 81
    .line 82
    move-result v10

    .line 83
    if-eqz v10, :cond_2

    .line 84
    .line 85
    invoke-virtual {v7}, Le6;->y()Lmb6;

    .line 86
    .line 87
    .line 88
    move-result-object v10

    .line 89
    iput-object v10, v7, Le6;->k:Ljava/lang/Object;

    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_2
    sget-object v10, Lyt2;->m0:Lgo2;

    .line 93
    .line 94
    :goto_0
    invoke-interface {v10}, Lmb6;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v7

    .line 98
    check-cast v7, Ljava/lang/Boolean;

    .line 99
    .line 100
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 101
    .line 102
    .line 103
    move-result v7

    .line 104
    :goto_1
    iput-boolean v7, v0, Lad;->k:Z

    .line 105
    .line 106
    iget v7, v1, Lmm4;->c:I

    .line 107
    .line 108
    iget-object v10, v8, Lr96;->l:Llc3;

    .line 109
    .line 110
    const/4 v11, 0x4

    .line 111
    const/4 v12, 0x2

    .line 112
    if-ne v7, v11, :cond_3

    .line 113
    .line 114
    goto :goto_4

    .line 115
    :cond_3
    const/4 v11, 0x5

    .line 116
    if-ne v7, v11, :cond_4

    .line 117
    .line 118
    goto :goto_3

    .line 119
    :cond_4
    if-ne v7, v6, :cond_5

    .line 120
    .line 121
    move v7, v9

    .line 122
    goto :goto_5

    .line 123
    :cond_5
    if-ne v7, v12, :cond_6

    .line 124
    .line 125
    move v7, v6

    .line 126
    goto :goto_5

    .line 127
    :cond_6
    if-ne v7, v5, :cond_7

    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_7
    if-nez v7, :cond_7e

    .line 131
    .line 132
    :goto_2
    if-eqz v10, :cond_8

    .line 133
    .line 134
    iget-object v7, v10, Llc3;->j:Ljava/util/List;

    .line 135
    .line 136
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v7

    .line 140
    check-cast v7, Lkc3;

    .line 141
    .line 142
    iget-object v7, v7, Lkc3;->a:Ljava/util/Locale;

    .line 143
    .line 144
    if-nez v7, :cond_9

    .line 145
    .line 146
    :cond_8
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 147
    .line 148
    .line 149
    move-result-object v7

    .line 150
    :cond_9
    invoke-static {v7}, Landroid/text/TextUtils;->getLayoutDirectionFromLocale(Ljava/util/Locale;)I

    .line 151
    .line 152
    .line 153
    move-result v7

    .line 154
    if-eqz v7, :cond_b

    .line 155
    .line 156
    if-eq v7, v6, :cond_a

    .line 157
    .line 158
    goto :goto_4

    .line 159
    :cond_a
    :goto_3
    move v7, v5

    .line 160
    goto :goto_5

    .line 161
    :cond_b
    :goto_4
    move v7, v12

    .line 162
    :goto_5
    iput v7, v0, Lad;->l:I

    .line 163
    .line 164
    const/4 v7, -0x1

    .line 165
    iput v7, v0, Lad;->m:I

    .line 166
    .line 167
    new-instance v10, Lzc;

    .line 168
    .line 169
    invoke-direct {v10, v0, v9}, Lzc;-><init>(Ljava/lang/Object;B)V

    .line 170
    .line 171
    .line 172
    iget-object v1, v1, Lmm4;->j:Lmr6;

    .line 173
    .line 174
    if-nez v1, :cond_c

    .line 175
    .line 176
    sget-object v1, Lmr6;->c:Lmr6;

    .line 177
    .line 178
    :cond_c
    iget-boolean v11, v1, Lmr6;->b:Z

    .line 179
    .line 180
    if-eqz v11, :cond_d

    .line 181
    .line 182
    invoke-virtual {v4}, Landroid/graphics/Paint;->getFlags()I

    .line 183
    .line 184
    .line 185
    move-result v11

    .line 186
    or-int/lit16 v11, v11, 0x80

    .line 187
    .line 188
    goto :goto_6

    .line 189
    :cond_d
    invoke-virtual {v4}, Landroid/graphics/Paint;->getFlags()I

    .line 190
    .line 191
    .line 192
    move-result v11

    .line 193
    and-int/lit16 v11, v11, -0x81

    .line 194
    .line 195
    :goto_6
    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->setFlags(I)V

    .line 196
    .line 197
    .line 198
    iget v1, v1, Lmr6;->a:I

    .line 199
    .line 200
    if-ne v1, v6, :cond_e

    .line 201
    .line 202
    invoke-virtual {v4}, Landroid/graphics/Paint;->getFlags()I

    .line 203
    .line 204
    .line 205
    move-result v1

    .line 206
    or-int/lit8 v1, v1, 0x40

    .line 207
    .line 208
    invoke-virtual {v4, v1}, Landroid/graphics/Paint;->setFlags(I)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v4, v9}, Landroid/graphics/Paint;->setHinting(I)V

    .line 212
    .line 213
    .line 214
    goto :goto_7

    .line 215
    :cond_e
    if-ne v1, v12, :cond_f

    .line 216
    .line 217
    invoke-virtual {v4}, Landroid/graphics/Paint;->getFlags()I

    .line 218
    .line 219
    .line 220
    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setHinting(I)V

    .line 221
    .line 222
    .line 223
    goto :goto_7

    .line 224
    :cond_f
    if-ne v1, v5, :cond_10

    .line 225
    .line 226
    invoke-virtual {v4}, Landroid/graphics/Paint;->getFlags()I

    .line 227
    .line 228
    .line 229
    invoke-virtual {v4, v9}, Landroid/graphics/Paint;->setHinting(I)V

    .line 230
    .line 231
    .line 232
    goto :goto_7

    .line 233
    :cond_10
    invoke-virtual {v4}, Landroid/graphics/Paint;->getFlags()I

    .line 234
    .line 235
    .line 236
    :goto_7
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 237
    .line 238
    .line 239
    move-result v1

    .line 240
    move v5, v9

    .line 241
    :goto_8
    if-ge v5, v1, :cond_12

    .line 242
    .line 243
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v11

    .line 247
    move-object v14, v11

    .line 248
    check-cast v14, Ldi;

    .line 249
    .line 250
    iget-object v14, v14, Ldi;->a:Ljava/lang/Object;

    .line 251
    .line 252
    instance-of v14, v14, Lr96;

    .line 253
    .line 254
    if-eqz v14, :cond_11

    .line 255
    .line 256
    goto :goto_9

    .line 257
    :cond_11
    add-int/lit8 v5, v5, 0x1

    .line 258
    .line 259
    goto :goto_8

    .line 260
    :cond_12
    const/4 v11, 0x0

    .line 261
    :goto_9
    if-eqz v11, :cond_13

    .line 262
    .line 263
    move v1, v6

    .line 264
    goto :goto_a

    .line 265
    :cond_13
    move v1, v9

    .line 266
    :goto_a
    iget-wide v14, v8, Lr96;->c:J

    .line 267
    .line 268
    iget-object v2, v8, Lr96;->d:Lb52;

    .line 269
    .line 270
    iget-object v5, v8, Lr96;->e:Lz42;

    .line 271
    .line 272
    iget-object v11, v8, Lr96;->h:Ljava/lang/String;

    .line 273
    .line 274
    const/16 p1, 0x0

    .line 275
    .line 276
    iget-object v13, v8, Lr96;->l:Llc3;

    .line 277
    .line 278
    move/from16 p4, v6

    .line 279
    .line 280
    iget-object v6, v8, Lr96;->b:Lgq6;

    .line 281
    .line 282
    iget-object v12, v8, Lr96;->k:Lhq6;

    .line 283
    .line 284
    move-object/from16 p7, v10

    .line 285
    .line 286
    iget-wide v9, v8, Lr96;->i:J

    .line 287
    .line 288
    move-object/from16 v16, v8

    .line 289
    .line 290
    invoke-static {v14, v15}, Lts6;->b(J)J

    .line 291
    .line 292
    .line 293
    move-result-wide v7

    .line 294
    move/from16 p3, v1

    .line 295
    .line 296
    move-object/from16 v18, v2

    .line 297
    .line 298
    const-wide v1, 0x100000000L

    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    invoke-static {v7, v8, v1, v2}, Lus6;->a(JJ)Z

    .line 304
    .line 305
    .line 306
    move-result v19

    .line 307
    const-wide v1, 0x200000000L

    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    if-eqz v19, :cond_15

    .line 313
    .line 314
    invoke-interface {v3, v14, v15}, Lyh1;->N0(J)F

    .line 315
    .line 316
    .line 317
    move-result v7

    .line 318
    invoke-virtual {v4, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 319
    .line 320
    .line 321
    :cond_14
    :goto_b
    move-object/from16 v7, v16

    .line 322
    .line 323
    goto :goto_c

    .line 324
    :cond_15
    invoke-static {v7, v8, v1, v2}, Lus6;->a(JJ)Z

    .line 325
    .line 326
    .line 327
    move-result v7

    .line 328
    if-eqz v7, :cond_14

    .line 329
    .line 330
    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSize()F

    .line 331
    .line 332
    .line 333
    move-result v7

    .line 334
    invoke-static {v14, v15}, Lts6;->c(J)F

    .line 335
    .line 336
    .line 337
    move-result v8

    .line 338
    mul-float/2addr v8, v7

    .line 339
    invoke-virtual {v4, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 340
    .line 341
    .line 342
    goto :goto_b

    .line 343
    :goto_c
    iget-object v8, v7, Lr96;->g:Ld42;

    .line 344
    .line 345
    if-nez v8, :cond_17

    .line 346
    .line 347
    if-nez v5, :cond_17

    .line 348
    .line 349
    if-eqz v18, :cond_16

    .line 350
    .line 351
    goto :goto_d

    .line 352
    :cond_16
    move-object/from16 v1, p7

    .line 353
    .line 354
    move-object/from16 v16, v6

    .line 355
    .line 356
    goto :goto_13

    .line 357
    :cond_17
    :goto_d
    if-nez v18, :cond_18

    .line 358
    .line 359
    sget-object v14, Lb52;->l:Lb52;

    .line 360
    .line 361
    goto :goto_e

    .line 362
    :cond_18
    move-object/from16 v14, v18

    .line 363
    .line 364
    :goto_e
    if-eqz v5, :cond_19

    .line 365
    .line 366
    iget v5, v5, Lz42;->a:I

    .line 367
    .line 368
    goto :goto_f

    .line 369
    :cond_19
    const/4 v5, 0x0

    .line 370
    :goto_f
    iget-object v15, v7, Lr96;->f:La52;

    .line 371
    .line 372
    if-eqz v15, :cond_1a

    .line 373
    .line 374
    iget v15, v15, La52;->a:I

    .line 375
    .line 376
    :goto_10
    move-object/from16 v1, p7

    .line 377
    .line 378
    goto :goto_11

    .line 379
    :cond_1a
    const v15, 0xffff

    .line 380
    .line 381
    .line 382
    goto :goto_10

    .line 383
    :goto_11
    iget-object v2, v1, Lzc;->k:Ljava/lang/Object;

    .line 384
    .line 385
    check-cast v2, Lad;

    .line 386
    .line 387
    move-object/from16 v16, v6

    .line 388
    .line 389
    iget-object v6, v2, Lad;->e:Lc42;

    .line 390
    .line 391
    check-cast v6, Le42;

    .line 392
    .line 393
    invoke-virtual {v6, v8, v14, v5, v15}, Le42;->b(Ld42;Lb52;II)Lp17;

    .line 394
    .line 395
    .line 396
    move-result-object v5

    .line 397
    instance-of v6, v5, Lp17;

    .line 398
    .line 399
    if-nez v6, :cond_1b

    .line 400
    .line 401
    new-instance v6, Luq6;

    .line 402
    .line 403
    iget-object v8, v2, Lad;->j:Luq6;

    .line 404
    .line 405
    invoke-direct {v6, v5, v8}, Luq6;-><init>(Lp17;Luq6;)V

    .line 406
    .line 407
    .line 408
    iput-object v6, v2, Lad;->j:Luq6;

    .line 409
    .line 410
    iget-object v2, v6, Luq6;->c:Ljava/lang/Object;

    .line 411
    .line 412
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 413
    .line 414
    .line 415
    check-cast v2, Landroid/graphics/Typeface;

    .line 416
    .line 417
    goto :goto_12

    .line 418
    :cond_1b
    iget-object v2, v5, Lp17;->j:Ljava/lang/Object;

    .line 419
    .line 420
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 421
    .line 422
    .line 423
    check-cast v2, Landroid/graphics/Typeface;

    .line 424
    .line 425
    :goto_12
    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 426
    .line 427
    .line 428
    :goto_13
    const/16 v2, 0xa

    .line 429
    .line 430
    if-eqz v13, :cond_1d

    .line 431
    .line 432
    sget-object v5, Llc3;->l:Llc3;

    .line 433
    .line 434
    sget-object v5, Lsp4;->a:Lit6;

    .line 435
    .line 436
    invoke-virtual {v5}, Lit6;->K()Llc3;

    .line 437
    .line 438
    .line 439
    move-result-object v5

    .line 440
    invoke-virtual {v13, v5}, Llc3;->equals(Ljava/lang/Object;)Z

    .line 441
    .line 442
    .line 443
    move-result v5

    .line 444
    if-nez v5, :cond_1d

    .line 445
    .line 446
    new-instance v5, Ljava/util/ArrayList;

    .line 447
    .line 448
    invoke-static {v13, v2}, Ldv0;->j0(Ljava/lang/Iterable;I)I

    .line 449
    .line 450
    .line 451
    move-result v6

    .line 452
    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 453
    .line 454
    .line 455
    iget-object v6, v13, Llc3;->j:Ljava/util/List;

    .line 456
    .line 457
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 458
    .line 459
    .line 460
    move-result-object v6

    .line 461
    :goto_14
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 462
    .line 463
    .line 464
    move-result v8

    .line 465
    if-eqz v8, :cond_1c

    .line 466
    .line 467
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 468
    .line 469
    .line 470
    move-result-object v8

    .line 471
    check-cast v8, Lkc3;

    .line 472
    .line 473
    iget-object v8, v8, Lkc3;->a:Ljava/util/Locale;

    .line 474
    .line 475
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 476
    .line 477
    .line 478
    goto :goto_14

    .line 479
    :cond_1c
    const/4 v8, 0x0

    .line 480
    new-array v6, v8, [Ljava/util/Locale;

    .line 481
    .line 482
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 483
    .line 484
    .line 485
    move-result-object v5

    .line 486
    check-cast v5, [Ljava/util/Locale;

    .line 487
    .line 488
    array-length v6, v5

    .line 489
    invoke-static {v5, v6}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 490
    .line 491
    .line 492
    move-result-object v5

    .line 493
    check-cast v5, [Ljava/util/Locale;

    .line 494
    .line 495
    new-instance v6, Landroid/os/LocaleList;

    .line 496
    .line 497
    invoke-direct {v6, v5}, Landroid/os/LocaleList;-><init>([Ljava/util/Locale;)V

    .line 498
    .line 499
    .line 500
    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setTextLocales(Landroid/os/LocaleList;)V

    .line 501
    .line 502
    .line 503
    :cond_1d
    if-eqz v11, :cond_1e

    .line 504
    .line 505
    const-string v5, ""

    .line 506
    .line 507
    invoke-virtual {v11, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 508
    .line 509
    .line 510
    move-result v5

    .line 511
    if-nez v5, :cond_1e

    .line 512
    .line 513
    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->setFontFeatureSettings(Ljava/lang/String;)V

    .line 514
    .line 515
    .line 516
    :cond_1e
    if-eqz v12, :cond_1f

    .line 517
    .line 518
    sget-object v5, Lhq6;->c:Lhq6;

    .line 519
    .line 520
    invoke-virtual {v12, v5}, Lhq6;->equals(Ljava/lang/Object;)Z

    .line 521
    .line 522
    .line 523
    move-result v5

    .line 524
    if-nez v5, :cond_1f

    .line 525
    .line 526
    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 527
    .line 528
    .line 529
    move-result v5

    .line 530
    iget v6, v12, Lhq6;->a:F

    .line 531
    .line 532
    mul-float/2addr v5, v6

    .line 533
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextScaleX(F)V

    .line 534
    .line 535
    .line 536
    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSkewX()F

    .line 537
    .line 538
    .line 539
    move-result v5

    .line 540
    iget v6, v12, Lhq6;->b:F

    .line 541
    .line 542
    add-float/2addr v5, v6

    .line 543
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextSkewX(F)V

    .line 544
    .line 545
    .line 546
    :cond_1f
    invoke-interface/range {v16 .. v16}, Lgq6;->a()J

    .line 547
    .line 548
    .line 549
    move-result-wide v5

    .line 550
    invoke-virtual {v4, v5, v6}, Ldf;->d(J)V

    .line 551
    .line 552
    .line 553
    invoke-interface/range {v16 .. v16}, Lgq6;->b()Lde0;

    .line 554
    .line 555
    .line 556
    move-result-object v5

    .line 557
    const-wide v11, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    invoke-interface/range {v16 .. v16}, Lgq6;->c()F

    .line 563
    .line 564
    .line 565
    move-result v6

    .line 566
    invoke-virtual {v4, v5, v11, v12, v6}, Ldf;->c(Lde0;JF)V

    .line 567
    .line 568
    .line 569
    iget-object v5, v7, Lr96;->o:Lk06;

    .line 570
    .line 571
    invoke-virtual {v4, v5}, Ldf;->f(Lk06;)V

    .line 572
    .line 573
    .line 574
    iget-object v5, v7, Lr96;->n:Lgm6;

    .line 575
    .line 576
    invoke-virtual {v4, v5}, Ldf;->g(Lgm6;)V

    .line 577
    .line 578
    .line 579
    iget-object v5, v7, Lr96;->q:Lio1;

    .line 580
    .line 581
    invoke-virtual {v4, v5}, Ldf;->e(Lio1;)V

    .line 582
    .line 583
    .line 584
    invoke-static {v9, v10}, Lts6;->b(J)J

    .line 585
    .line 586
    .line 587
    move-result-wide v5

    .line 588
    const-wide v11, 0x100000000L

    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    invoke-static {v5, v6, v11, v12}, Lus6;->a(JJ)Z

    .line 594
    .line 595
    .line 596
    move-result v5

    .line 597
    const/4 v6, 0x0

    .line 598
    if-eqz v5, :cond_22

    .line 599
    .line 600
    invoke-static {v9, v10}, Lts6;->c(J)F

    .line 601
    .line 602
    .line 603
    move-result v5

    .line 604
    cmpg-float v5, v5, v6

    .line 605
    .line 606
    if-nez v5, :cond_20

    .line 607
    .line 608
    goto :goto_15

    .line 609
    :cond_20
    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSize()F

    .line 610
    .line 611
    .line 612
    move-result v5

    .line 613
    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 614
    .line 615
    .line 616
    move-result v8

    .line 617
    mul-float/2addr v8, v5

    .line 618
    invoke-interface {v3, v9, v10}, Lyh1;->N0(J)F

    .line 619
    .line 620
    .line 621
    move-result v3

    .line 622
    cmpg-float v5, v8, v6

    .line 623
    .line 624
    if-nez v5, :cond_21

    .line 625
    .line 626
    goto :goto_16

    .line 627
    :cond_21
    div-float/2addr v3, v8

    .line 628
    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 629
    .line 630
    .line 631
    goto :goto_16

    .line 632
    :cond_22
    :goto_15
    invoke-static {v9, v10}, Lts6;->b(J)J

    .line 633
    .line 634
    .line 635
    move-result-wide v11

    .line 636
    const-wide v13, 0x200000000L

    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    invoke-static {v11, v12, v13, v14}, Lus6;->a(JJ)Z

    .line 642
    .line 643
    .line 644
    move-result v3

    .line 645
    if-eqz v3, :cond_23

    .line 646
    .line 647
    invoke-static {v9, v10}, Lts6;->c(J)F

    .line 648
    .line 649
    .line 650
    move-result v3

    .line 651
    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 652
    .line 653
    .line 654
    :cond_23
    :goto_16
    iget-wide v3, v7, Lr96;->m:J

    .line 655
    .line 656
    iget-object v5, v7, Lr96;->j:Li00;

    .line 657
    .line 658
    if-eqz p3, :cond_25

    .line 659
    .line 660
    invoke-static {v9, v10}, Lts6;->b(J)J

    .line 661
    .line 662
    .line 663
    move-result-wide v7

    .line 664
    const-wide v11, 0x100000000L

    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    invoke-static {v7, v8, v11, v12}, Lus6;->a(JJ)Z

    .line 670
    .line 671
    .line 672
    move-result v7

    .line 673
    if-eqz v7, :cond_25

    .line 674
    .line 675
    invoke-static {v9, v10}, Lts6;->c(J)F

    .line 676
    .line 677
    .line 678
    move-result v7

    .line 679
    cmpg-float v7, v7, v6

    .line 680
    .line 681
    if-nez v7, :cond_24

    .line 682
    .line 683
    goto :goto_17

    .line 684
    :cond_24
    move/from16 v7, p4

    .line 685
    .line 686
    goto :goto_18

    .line 687
    :cond_25
    :goto_17
    const/4 v7, 0x0

    .line 688
    :goto_18
    sget-object v8, Law0;->u:Lwd5;

    .line 689
    .line 690
    invoke-static {v6, v6, v6, v6, v8}, Lzm;->a(FFFFLxv0;)J

    .line 691
    .line 692
    .line 693
    move-result-wide v11

    .line 694
    invoke-static {v3, v4, v11, v12}, Lc27;->a(JJ)Z

    .line 695
    .line 696
    .line 697
    move-result v11

    .line 698
    const-wide/16 v12, 0x0

    .line 699
    .line 700
    if-nez v11, :cond_26

    .line 701
    .line 702
    invoke-static {v3, v4, v12, v13}, Lc27;->a(JJ)Z

    .line 703
    .line 704
    .line 705
    move-result v11

    .line 706
    if-nez v11, :cond_26

    .line 707
    .line 708
    move/from16 v11, p4

    .line 709
    .line 710
    goto :goto_19

    .line 711
    :cond_26
    const/4 v11, 0x0

    .line 712
    :goto_19
    const v14, 0x7f7fffff    # Float.MAX_VALUE

    .line 713
    .line 714
    .line 715
    if-eqz v5, :cond_28

    .line 716
    .line 717
    iget v15, v5, Li00;->a:F

    .line 718
    .line 719
    invoke-static {v15}, Ljava/lang/Math;->abs(F)F

    .line 720
    .line 721
    .line 722
    move-result v16

    .line 723
    cmpg-float v16, v16, v14

    .line 724
    .line 725
    if-gtz v16, :cond_28

    .line 726
    .line 727
    cmpg-float v15, v15, v6

    .line 728
    .line 729
    if-nez v15, :cond_27

    .line 730
    .line 731
    goto :goto_1a

    .line 732
    :cond_27
    move/from16 v15, p4

    .line 733
    .line 734
    goto :goto_1b

    .line 735
    :cond_28
    :goto_1a
    const/4 v15, 0x0

    .line 736
    :goto_1b
    if-nez v7, :cond_29

    .line 737
    .line 738
    if-nez v11, :cond_29

    .line 739
    .line 740
    if-nez v15, :cond_29

    .line 741
    .line 742
    move-object/from16 v3, p1

    .line 743
    .line 744
    goto :goto_21

    .line 745
    :cond_29
    if-eqz v7, :cond_2a

    .line 746
    .line 747
    :goto_1c
    move-wide/from16 v31, v9

    .line 748
    .line 749
    goto :goto_1d

    .line 750
    :cond_2a
    const/high16 v7, 0x7fc00000    # Float.NaN

    .line 751
    .line 752
    invoke-static {v12, v13, v7}, Lru5;->I(JF)J

    .line 753
    .line 754
    .line 755
    move-result-wide v9

    .line 756
    goto :goto_1c

    .line 757
    :goto_1d
    if-eqz v11, :cond_2b

    .line 758
    .line 759
    :goto_1e
    move-wide/from16 v36, v3

    .line 760
    .line 761
    goto :goto_1f

    .line 762
    :cond_2b
    invoke-static {v6, v6, v6, v6, v8}, Lzm;->a(FFFFLxv0;)J

    .line 763
    .line 764
    .line 765
    move-result-wide v3

    .line 766
    goto :goto_1e

    .line 767
    :goto_1f
    if-eqz v15, :cond_2c

    .line 768
    .line 769
    move-object/from16 v33, v5

    .line 770
    .line 771
    goto :goto_20

    .line 772
    :cond_2c
    move-object/from16 v33, p1

    .line 773
    .line 774
    :goto_20
    new-instance v21, Lr96;

    .line 775
    .line 776
    const/16 v39, 0x0

    .line 777
    .line 778
    const v40, 0xf67f

    .line 779
    .line 780
    .line 781
    const-wide/16 v22, 0x0

    .line 782
    .line 783
    const-wide/16 v24, 0x0

    .line 784
    .line 785
    const/16 v26, 0x0

    .line 786
    .line 787
    const/16 v27, 0x0

    .line 788
    .line 789
    const/16 v28, 0x0

    .line 790
    .line 791
    const/16 v29, 0x0

    .line 792
    .line 793
    const/16 v30, 0x0

    .line 794
    .line 795
    const/16 v34, 0x0

    .line 796
    .line 797
    const/16 v35, 0x0

    .line 798
    .line 799
    const/16 v38, 0x0

    .line 800
    .line 801
    invoke-direct/range {v21 .. v40}, Lr96;-><init>(JJLb52;Lz42;La52;Ld42;Ljava/lang/String;JLi00;Lhq6;Llc3;JLgm6;Lk06;I)V

    .line 802
    .line 803
    .line 804
    move-object/from16 v3, v21

    .line 805
    .line 806
    :goto_21
    iget-object v4, v0, Lad;->c:Ljava/util/List;

    .line 807
    .line 808
    if-eqz v3, :cond_2f

    .line 809
    .line 810
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 811
    .line 812
    .line 813
    move-result v4

    .line 814
    add-int/lit8 v4, v4, 0x1

    .line 815
    .line 816
    new-instance v5, Ljava/util/ArrayList;

    .line 817
    .line 818
    invoke-direct {v5, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 819
    .line 820
    .line 821
    const/4 v7, 0x0

    .line 822
    :goto_22
    if-ge v7, v4, :cond_2e

    .line 823
    .line 824
    if-nez v7, :cond_2d

    .line 825
    .line 826
    new-instance v8, Ldi;

    .line 827
    .line 828
    iget-object v9, v0, Lad;->a:Ljava/lang/String;

    .line 829
    .line 830
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 831
    .line 832
    .line 833
    move-result v9

    .line 834
    const/4 v10, 0x0

    .line 835
    invoke-direct {v8, v10, v9, v3}, Ldi;-><init>(IILjava/lang/Object;)V

    .line 836
    .line 837
    .line 838
    goto :goto_23

    .line 839
    :cond_2d
    iget-object v8, v0, Lad;->c:Ljava/util/List;

    .line 840
    .line 841
    add-int/lit8 v9, v7, -0x1

    .line 842
    .line 843
    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 844
    .line 845
    .line 846
    move-result-object v8

    .line 847
    check-cast v8, Ldi;

    .line 848
    .line 849
    :goto_23
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 850
    .line 851
    .line 852
    add-int/lit8 v7, v7, 0x1

    .line 853
    .line 854
    goto :goto_22

    .line 855
    :cond_2e
    move-object v4, v5

    .line 856
    :cond_2f
    iget-object v3, v0, Lad;->a:Ljava/lang/String;

    .line 857
    .line 858
    iget-object v5, v0, Lad;->g:Ldf;

    .line 859
    .line 860
    invoke-virtual {v5}, Landroid/graphics/Paint;->getTextSize()F

    .line 861
    .line 862
    .line 863
    move-result v5

    .line 864
    iget-object v7, v0, Lad;->b:Lls6;

    .line 865
    .line 866
    iget-object v8, v0, Lad;->d:Ljava/util/List;

    .line 867
    .line 868
    iget-object v9, v0, Lad;->f:Lyh1;

    .line 869
    .line 870
    iget-boolean v10, v0, Lad;->k:Z

    .line 871
    .line 872
    iget-object v11, v0, Lad;->a:Ljava/lang/String;

    .line 873
    .line 874
    iget v15, v0, Lad;->m:I

    .line 875
    .line 876
    move/from16 p3, v6

    .line 877
    .line 878
    const/4 v6, -0x1

    .line 879
    if-ne v15, v6, :cond_32

    .line 880
    .line 881
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    .line 882
    .line 883
    .line 884
    move-result v6

    .line 885
    const/16 v15, 0x200

    .line 886
    .line 887
    if-gt v6, v15, :cond_31

    .line 888
    .line 889
    invoke-static {v11, v2}, Lad6;->n0(Ljava/lang/CharSequence;C)Z

    .line 890
    .line 891
    .line 892
    move-result v6

    .line 893
    if-eqz v6, :cond_30

    .line 894
    .line 895
    goto :goto_24

    .line 896
    :cond_30
    const/4 v6, 0x0

    .line 897
    goto :goto_25

    .line 898
    :cond_31
    :goto_24
    move/from16 v6, p4

    .line 899
    .line 900
    :goto_25
    iput v6, v0, Lad;->m:I

    .line 901
    .line 902
    :cond_32
    sget-object v6, Lyc;->a:Lxc;

    .line 903
    .line 904
    if-eqz v10, :cond_36

    .line 905
    .line 906
    invoke-static {}, Lot1;->d()Z

    .line 907
    .line 908
    .line 909
    move-result v6

    .line 910
    if-eqz v6, :cond_36

    .line 911
    .line 912
    iget-object v6, v7, Lls6;->c:Liq4;

    .line 913
    .line 914
    if-eqz v6, :cond_33

    .line 915
    .line 916
    iget-object v6, v6, Liq4;->b:Lup4;

    .line 917
    .line 918
    if-eqz v6, :cond_33

    .line 919
    .line 920
    iget v6, v6, Lup4;->b:I

    .line 921
    .line 922
    new-instance v10, Lcu1;

    .line 923
    .line 924
    invoke-direct {v10, v6}, Lcu1;-><init>(I)V

    .line 925
    .line 926
    .line 927
    goto :goto_26

    .line 928
    :cond_33
    move-object/from16 v10, p1

    .line 929
    .line 930
    :goto_26
    if-nez v10, :cond_34

    .line 931
    .line 932
    const/4 v6, 0x0

    .line 933
    const/4 v10, 0x2

    .line 934
    goto :goto_27

    .line 935
    :cond_34
    iget v6, v10, Lcu1;->a:I

    .line 936
    .line 937
    const/4 v10, 0x2

    .line 938
    if-ne v6, v10, :cond_35

    .line 939
    .line 940
    move/from16 v6, p4

    .line 941
    .line 942
    goto :goto_27

    .line 943
    :cond_35
    const/4 v6, 0x0

    .line 944
    :goto_27
    invoke-static {}, Lot1;->a()Lot1;

    .line 945
    .line 946
    .line 947
    move-result-object v11

    .line 948
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 949
    .line 950
    .line 951
    move-result v15

    .line 952
    const/4 v10, 0x0

    .line 953
    invoke-virtual {v11, v10, v15, v6, v3}, Lot1;->g(IIILjava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 954
    .line 955
    .line 956
    move-result-object v6

    .line 957
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 958
    .line 959
    .line 960
    goto :goto_28

    .line 961
    :cond_36
    move-object v6, v3

    .line 962
    :goto_28
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 963
    .line 964
    .line 965
    move-result v10

    .line 966
    const-wide v15, 0xff00000000L

    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    if-eqz v10, :cond_37

    .line 972
    .line 973
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    .line 974
    .line 975
    .line 976
    move-result v10

    .line 977
    if-eqz v10, :cond_37

    .line 978
    .line 979
    iget-object v10, v7, Lls6;->b:Lmm4;

    .line 980
    .line 981
    iget-object v10, v10, Lmm4;->e:Ljq6;

    .line 982
    .line 983
    sget-object v11, Ljq6;->c:Ljq6;

    .line 984
    .line 985
    invoke-static {v10, v11}, Lyt2;->e0(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 986
    .line 987
    .line 988
    move-result v10

    .line 989
    if-eqz v10, :cond_37

    .line 990
    .line 991
    iget-object v10, v7, Lls6;->b:Lmm4;

    .line 992
    .line 993
    iget-wide v10, v10, Lmm4;->d:J

    .line 994
    .line 995
    and-long/2addr v10, v15

    .line 996
    cmp-long v10, v10, v12

    .line 997
    .line 998
    if-nez v10, :cond_37

    .line 999
    .line 1000
    goto/16 :goto_55

    .line 1001
    .line 1002
    :cond_37
    instance-of v10, v6, Landroid/text/Spannable;

    .line 1003
    .line 1004
    if-eqz v10, :cond_38

    .line 1005
    .line 1006
    check-cast v6, Landroid/text/Spannable;

    .line 1007
    .line 1008
    goto :goto_29

    .line 1009
    :cond_38
    new-instance v10, Landroid/text/SpannableString;

    .line 1010
    .line 1011
    invoke-direct {v10, v6}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 1012
    .line 1013
    .line 1014
    move-object v6, v10

    .line 1015
    :goto_29
    iget-object v10, v7, Lls6;->a:Lr96;

    .line 1016
    .line 1017
    iget-object v11, v7, Lls6;->b:Lmm4;

    .line 1018
    .line 1019
    iget-object v10, v10, Lr96;->n:Lgm6;

    .line 1020
    .line 1021
    move-wide/from16 p6, v12

    .line 1022
    .line 1023
    sget-object v12, Lgm6;->c:Lgm6;

    .line 1024
    .line 1025
    invoke-static {v10, v12}, Lyt2;->e0(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1026
    .line 1027
    .line 1028
    move-result v10

    .line 1029
    const/16 v12, 0x21

    .line 1030
    .line 1031
    if-eqz v10, :cond_39

    .line 1032
    .line 1033
    sget-object v10, Lyc;->a:Lxc;

    .line 1034
    .line 1035
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 1036
    .line 1037
    .line 1038
    move-result v3

    .line 1039
    const/4 v13, 0x0

    .line 1040
    invoke-interface {v6, v10, v13, v3, v12}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1041
    .line 1042
    .line 1043
    :cond_39
    iget-object v3, v7, Lls6;->c:Liq4;

    .line 1044
    .line 1045
    if-eqz v3, :cond_3a

    .line 1046
    .line 1047
    iget-object v3, v3, Liq4;->b:Lup4;

    .line 1048
    .line 1049
    if-eqz v3, :cond_3a

    .line 1050
    .line 1051
    iget-boolean v3, v3, Lup4;->a:Z

    .line 1052
    .line 1053
    goto :goto_2a

    .line 1054
    :cond_3a
    const/4 v3, 0x0

    .line 1055
    :goto_2a
    if-eqz v3, :cond_3d

    .line 1056
    .line 1057
    iget-object v3, v11, Lmm4;->g:Ls83;

    .line 1058
    .line 1059
    if-nez v3, :cond_3d

    .line 1060
    .line 1061
    iget-wide v2, v11, Lmm4;->d:J

    .line 1062
    .line 1063
    invoke-static {v2, v3, v5, v9}, Lqu5;->Z(JFLyh1;)F

    .line 1064
    .line 1065
    .line 1066
    move-result v2

    .line 1067
    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    .line 1068
    .line 1069
    .line 1070
    move-result v3

    .line 1071
    if-nez v3, :cond_3b

    .line 1072
    .line 1073
    new-instance v3, Lo83;

    .line 1074
    .line 1075
    invoke-direct {v3, v2}, Lo83;-><init>(F)V

    .line 1076
    .line 1077
    .line 1078
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1079
    .line 1080
    .line 1081
    move-result v2

    .line 1082
    const/4 v10, 0x0

    .line 1083
    invoke-interface {v6, v3, v10, v2, v12}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1084
    .line 1085
    .line 1086
    :cond_3b
    move v10, v14

    .line 1087
    move-wide/from16 v21, v15

    .line 1088
    .line 1089
    :cond_3c
    const/4 v13, 0x0

    .line 1090
    goto :goto_30

    .line 1091
    :cond_3d
    iget-object v3, v11, Lmm4;->g:Ls83;

    .line 1092
    .line 1093
    if-nez v3, :cond_3e

    .line 1094
    .line 1095
    sget-object v3, Ls83;->d:Ls83;

    .line 1096
    .line 1097
    :cond_3e
    move v10, v14

    .line 1098
    move-wide/from16 v21, v15

    .line 1099
    .line 1100
    iget-wide v14, v11, Lmm4;->d:J

    .line 1101
    .line 1102
    invoke-static {v14, v15, v5, v9}, Lqu5;->Z(JFLyh1;)F

    .line 1103
    .line 1104
    .line 1105
    move-result v24

    .line 1106
    invoke-static/range {v24 .. v24}, Ljava/lang/Float;->isNaN(F)Z

    .line 1107
    .line 1108
    .line 1109
    move-result v13

    .line 1110
    if-nez v13, :cond_3c

    .line 1111
    .line 1112
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1113
    .line 1114
    .line 1115
    move-result v13

    .line 1116
    if-nez v13, :cond_3f

    .line 1117
    .line 1118
    goto :goto_2b

    .line 1119
    :cond_3f
    invoke-static {v6}, Lad6;->z0(Ljava/lang/CharSequence;)C

    .line 1120
    .line 1121
    .line 1122
    move-result v13

    .line 1123
    if-ne v13, v2, :cond_40

    .line 1124
    .line 1125
    :goto_2b
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1126
    .line 1127
    .line 1128
    move-result v2

    .line 1129
    add-int/lit8 v2, v2, 0x1

    .line 1130
    .line 1131
    :goto_2c
    move/from16 v25, v2

    .line 1132
    .line 1133
    goto :goto_2d

    .line 1134
    :cond_40
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1135
    .line 1136
    .line 1137
    move-result v2

    .line 1138
    goto :goto_2c

    .line 1139
    :goto_2d
    new-instance v23, Lt83;

    .line 1140
    .line 1141
    iget v2, v3, Ls83;->b:I

    .line 1142
    .line 1143
    and-int/lit8 v13, v2, 0x1

    .line 1144
    .line 1145
    if-lez v13, :cond_41

    .line 1146
    .line 1147
    move/from16 v26, p4

    .line 1148
    .line 1149
    goto :goto_2e

    .line 1150
    :cond_41
    const/16 v26, 0x0

    .line 1151
    .line 1152
    :goto_2e
    and-int/lit8 v2, v2, 0x10

    .line 1153
    .line 1154
    if-lez v2, :cond_42

    .line 1155
    .line 1156
    move/from16 v27, p4

    .line 1157
    .line 1158
    goto :goto_2f

    .line 1159
    :cond_42
    const/16 v27, 0x0

    .line 1160
    .line 1161
    :goto_2f
    iget v2, v3, Ls83;->a:F

    .line 1162
    .line 1163
    iget v3, v3, Ls83;->c:I

    .line 1164
    .line 1165
    move/from16 v28, v2

    .line 1166
    .line 1167
    move/from16 v29, v3

    .line 1168
    .line 1169
    invoke-direct/range {v23 .. v29}, Lt83;-><init>(FIZZFI)V

    .line 1170
    .line 1171
    .line 1172
    move-object/from16 v2, v23

    .line 1173
    .line 1174
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1175
    .line 1176
    .line 1177
    move-result v3

    .line 1178
    const/4 v13, 0x0

    .line 1179
    invoke-interface {v6, v2, v13, v3, v12}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1180
    .line 1181
    .line 1182
    :goto_30
    iget-object v2, v11, Lmm4;->e:Ljq6;

    .line 1183
    .line 1184
    if-eqz v2, :cond_4a

    .line 1185
    .line 1186
    iget-wide v14, v2, Ljq6;->a:J

    .line 1187
    .line 1188
    iget-wide v2, v2, Ljq6;->b:J

    .line 1189
    .line 1190
    move/from16 v17, v10

    .line 1191
    .line 1192
    move-object/from16 v16, v11

    .line 1193
    .line 1194
    invoke-static {v13}, Lru5;->z(I)J

    .line 1195
    .line 1196
    .line 1197
    move-result-wide v10

    .line 1198
    invoke-static {v14, v15, v10, v11}, Lts6;->a(JJ)Z

    .line 1199
    .line 1200
    .line 1201
    move-result v10

    .line 1202
    if-eqz v10, :cond_43

    .line 1203
    .line 1204
    invoke-static {v13}, Lru5;->z(I)J

    .line 1205
    .line 1206
    .line 1207
    move-result-wide v10

    .line 1208
    invoke-static {v2, v3, v10, v11}, Lts6;->a(JJ)Z

    .line 1209
    .line 1210
    .line 1211
    move-result v10

    .line 1212
    if-nez v10, :cond_4b

    .line 1213
    .line 1214
    :cond_43
    and-long v10, v14, v21

    .line 1215
    .line 1216
    cmp-long v10, v10, p6

    .line 1217
    .line 1218
    if-nez v10, :cond_44

    .line 1219
    .line 1220
    goto/16 :goto_33

    .line 1221
    .line 1222
    :cond_44
    and-long v10, v2, v21

    .line 1223
    .line 1224
    cmp-long v10, v10, p6

    .line 1225
    .line 1226
    if-nez v10, :cond_45

    .line 1227
    .line 1228
    goto/16 :goto_33

    .line 1229
    .line 1230
    :cond_45
    invoke-static {v14, v15}, Lts6;->b(J)J

    .line 1231
    .line 1232
    .line 1233
    move-result-wide v10

    .line 1234
    const-wide v12, 0x100000000L

    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    invoke-static {v10, v11, v12, v13}, Lus6;->a(JJ)Z

    .line 1240
    .line 1241
    .line 1242
    move-result v20

    .line 1243
    if-eqz v20, :cond_46

    .line 1244
    .line 1245
    invoke-interface {v9, v14, v15}, Lyh1;->N0(J)F

    .line 1246
    .line 1247
    .line 1248
    move-result v10

    .line 1249
    const-wide v12, 0x200000000L

    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    goto :goto_31

    .line 1255
    :cond_46
    const-wide v12, 0x200000000L

    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    invoke-static {v10, v11, v12, v13}, Lus6;->a(JJ)Z

    .line 1261
    .line 1262
    .line 1263
    move-result v10

    .line 1264
    if-eqz v10, :cond_47

    .line 1265
    .line 1266
    invoke-static {v14, v15}, Lts6;->c(J)F

    .line 1267
    .line 1268
    .line 1269
    move-result v10

    .line 1270
    mul-float/2addr v10, v5

    .line 1271
    goto :goto_31

    .line 1272
    :cond_47
    move/from16 v10, p3

    .line 1273
    .line 1274
    :goto_31
    invoke-static {v2, v3}, Lts6;->b(J)J

    .line 1275
    .line 1276
    .line 1277
    move-result-wide v14

    .line 1278
    const-wide v12, 0x100000000L

    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    invoke-static {v14, v15, v12, v13}, Lus6;->a(JJ)Z

    .line 1284
    .line 1285
    .line 1286
    move-result v11

    .line 1287
    if-eqz v11, :cond_48

    .line 1288
    .line 1289
    invoke-interface {v9, v2, v3}, Lyh1;->N0(J)F

    .line 1290
    .line 1291
    .line 1292
    move-result v2

    .line 1293
    goto :goto_32

    .line 1294
    :cond_48
    const-wide v12, 0x200000000L

    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    invoke-static {v14, v15, v12, v13}, Lus6;->a(JJ)Z

    .line 1300
    .line 1301
    .line 1302
    move-result v11

    .line 1303
    if-eqz v11, :cond_49

    .line 1304
    .line 1305
    invoke-static {v2, v3}, Lts6;->c(J)F

    .line 1306
    .line 1307
    .line 1308
    move-result v2

    .line 1309
    mul-float/2addr v2, v5

    .line 1310
    goto :goto_32

    .line 1311
    :cond_49
    move/from16 v2, p3

    .line 1312
    .line 1313
    :goto_32
    new-instance v3, Landroid/text/style/LeadingMarginSpan$Standard;

    .line 1314
    .line 1315
    float-to-double v10, v10

    .line 1316
    invoke-static {v10, v11}, Ljava/lang/Math;->ceil(D)D

    .line 1317
    .line 1318
    .line 1319
    move-result-wide v10

    .line 1320
    double-to-float v5, v10

    .line 1321
    float-to-int v5, v5

    .line 1322
    float-to-double v10, v2

    .line 1323
    invoke-static {v10, v11}, Ljava/lang/Math;->ceil(D)D

    .line 1324
    .line 1325
    .line 1326
    move-result-wide v10

    .line 1327
    double-to-float v2, v10

    .line 1328
    float-to-int v2, v2

    .line 1329
    invoke-direct {v3, v5, v2}, Landroid/text/style/LeadingMarginSpan$Standard;-><init>(II)V

    .line 1330
    .line 1331
    .line 1332
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1333
    .line 1334
    .line 1335
    move-result v2

    .line 1336
    const/16 v5, 0x21

    .line 1337
    .line 1338
    const/4 v10, 0x0

    .line 1339
    invoke-interface {v6, v3, v10, v2, v5}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1340
    .line 1341
    .line 1342
    goto :goto_33

    .line 1343
    :cond_4a
    move/from16 v17, v10

    .line 1344
    .line 1345
    move-object/from16 v16, v11

    .line 1346
    .line 1347
    :cond_4b
    :goto_33
    new-instance v2, Ljava/util/ArrayList;

    .line 1348
    .line 1349
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 1350
    .line 1351
    .line 1352
    move-result v3

    .line 1353
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 1354
    .line 1355
    .line 1356
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 1357
    .line 1358
    .line 1359
    move-result v3

    .line 1360
    const/4 v5, 0x0

    .line 1361
    :goto_34
    if-ge v5, v3, :cond_4f

    .line 1362
    .line 1363
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1364
    .line 1365
    .line 1366
    move-result-object v10

    .line 1367
    check-cast v10, Ldi;

    .line 1368
    .line 1369
    iget-object v11, v10, Ldi;->a:Ljava/lang/Object;

    .line 1370
    .line 1371
    instance-of v12, v11, Lr96;

    .line 1372
    .line 1373
    if-eqz v12, :cond_4e

    .line 1374
    .line 1375
    move-object v12, v11

    .line 1376
    check-cast v12, Lr96;

    .line 1377
    .line 1378
    iget-object v13, v12, Lr96;->g:Ld42;

    .line 1379
    .line 1380
    if-nez v13, :cond_4d

    .line 1381
    .line 1382
    iget-object v13, v12, Lr96;->e:Lz42;

    .line 1383
    .line 1384
    if-nez v13, :cond_4d

    .line 1385
    .line 1386
    iget-object v12, v12, Lr96;->d:Lb52;

    .line 1387
    .line 1388
    if-eqz v12, :cond_4c

    .line 1389
    .line 1390
    goto :goto_35

    .line 1391
    :cond_4c
    check-cast v11, Lr96;

    .line 1392
    .line 1393
    iget-object v11, v11, Lr96;->f:La52;

    .line 1394
    .line 1395
    if-eqz v11, :cond_4e

    .line 1396
    .line 1397
    :cond_4d
    :goto_35
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1398
    .line 1399
    .line 1400
    :cond_4e
    add-int/lit8 v5, v5, 0x1

    .line 1401
    .line 1402
    goto :goto_34

    .line 1403
    :cond_4f
    iget-object v3, v7, Lls6;->a:Lr96;

    .line 1404
    .line 1405
    iget-object v5, v3, Lr96;->g:Ld42;

    .line 1406
    .line 1407
    if-nez v5, :cond_52

    .line 1408
    .line 1409
    iget-object v7, v3, Lr96;->e:Lz42;

    .line 1410
    .line 1411
    if-nez v7, :cond_52

    .line 1412
    .line 1413
    iget-object v7, v3, Lr96;->d:Lb52;

    .line 1414
    .line 1415
    if-eqz v7, :cond_50

    .line 1416
    .line 1417
    goto :goto_36

    .line 1418
    :cond_50
    iget-object v7, v3, Lr96;->f:La52;

    .line 1419
    .line 1420
    if-eqz v7, :cond_51

    .line 1421
    .line 1422
    goto :goto_36

    .line 1423
    :cond_51
    move-object/from16 v3, p1

    .line 1424
    .line 1425
    goto :goto_37

    .line 1426
    :cond_52
    :goto_36
    iget-object v7, v3, Lr96;->d:Lb52;

    .line 1427
    .line 1428
    iget-object v10, v3, Lr96;->e:Lz42;

    .line 1429
    .line 1430
    iget-object v3, v3, Lr96;->f:La52;

    .line 1431
    .line 1432
    new-instance v21, Lr96;

    .line 1433
    .line 1434
    const/16 v39, 0x0

    .line 1435
    .line 1436
    const v40, 0xffc3

    .line 1437
    .line 1438
    .line 1439
    const-wide/16 v22, 0x0

    .line 1440
    .line 1441
    const-wide/16 v24, 0x0

    .line 1442
    .line 1443
    const/16 v30, 0x0

    .line 1444
    .line 1445
    const-wide/16 v31, 0x0

    .line 1446
    .line 1447
    const/16 v33, 0x0

    .line 1448
    .line 1449
    const/16 v34, 0x0

    .line 1450
    .line 1451
    const/16 v35, 0x0

    .line 1452
    .line 1453
    const-wide/16 v36, 0x0

    .line 1454
    .line 1455
    const/16 v38, 0x0

    .line 1456
    .line 1457
    move-object/from16 v28, v3

    .line 1458
    .line 1459
    move-object/from16 v29, v5

    .line 1460
    .line 1461
    move-object/from16 v26, v7

    .line 1462
    .line 1463
    move-object/from16 v27, v10

    .line 1464
    .line 1465
    invoke-direct/range {v21 .. v40}, Lr96;-><init>(JJLb52;Lz42;La52;Ld42;Ljava/lang/String;JLi00;Lhq6;Llc3;JLgm6;Lk06;I)V

    .line 1466
    .line 1467
    .line 1468
    move-object/from16 v3, v21

    .line 1469
    .line 1470
    :goto_37
    new-instance v5, Lbp3;

    .line 1471
    .line 1472
    const/16 v7, 0x1d

    .line 1473
    .line 1474
    invoke-direct {v5, v6, v1, v7}, Lbp3;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1475
    .line 1476
    .line 1477
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1478
    .line 1479
    .line 1480
    move-result v1

    .line 1481
    move/from16 v7, p4

    .line 1482
    .line 1483
    if-gt v1, v7, :cond_54

    .line 1484
    .line 1485
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1486
    .line 1487
    .line 1488
    move-result v1

    .line 1489
    if-nez v1, :cond_5c

    .line 1490
    .line 1491
    const/4 v10, 0x0

    .line 1492
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1493
    .line 1494
    .line 1495
    move-result-object v1

    .line 1496
    check-cast v1, Ldi;

    .line 1497
    .line 1498
    iget-object v1, v1, Ldi;->a:Ljava/lang/Object;

    .line 1499
    .line 1500
    check-cast v1, Lr96;

    .line 1501
    .line 1502
    if-nez v3, :cond_53

    .line 1503
    .line 1504
    goto :goto_38

    .line 1505
    :cond_53
    invoke-virtual {v3, v1}, Lr96;->c(Lr96;)Lr96;

    .line 1506
    .line 1507
    .line 1508
    move-result-object v1

    .line 1509
    :goto_38
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1510
    .line 1511
    .line 1512
    move-result-object v3

    .line 1513
    check-cast v3, Ldi;

    .line 1514
    .line 1515
    iget v3, v3, Ldi;->b:I

    .line 1516
    .line 1517
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1518
    .line 1519
    .line 1520
    move-result-object v3

    .line 1521
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1522
    .line 1523
    .line 1524
    move-result-object v2

    .line 1525
    check-cast v2, Ldi;

    .line 1526
    .line 1527
    iget v2, v2, Ldi;->c:I

    .line 1528
    .line 1529
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1530
    .line 1531
    .line 1532
    move-result-object v2

    .line 1533
    invoke-virtual {v5, v1, v3, v2}, Lbp3;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1534
    .line 1535
    .line 1536
    goto/16 :goto_3f

    .line 1537
    .line 1538
    :cond_54
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1539
    .line 1540
    .line 1541
    move-result v1

    .line 1542
    mul-int/lit8 v7, v1, 0x2

    .line 1543
    .line 1544
    new-array v10, v7, [I

    .line 1545
    .line 1546
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1547
    .line 1548
    .line 1549
    move-result v11

    .line 1550
    const/4 v12, 0x0

    .line 1551
    :goto_39
    if-ge v12, v11, :cond_55

    .line 1552
    .line 1553
    invoke-virtual {v2, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1554
    .line 1555
    .line 1556
    move-result-object v13

    .line 1557
    check-cast v13, Ldi;

    .line 1558
    .line 1559
    iget v14, v13, Ldi;->b:I

    .line 1560
    .line 1561
    aput v14, v10, v12

    .line 1562
    .line 1563
    add-int v14, v12, v1

    .line 1564
    .line 1565
    iget v13, v13, Ldi;->c:I

    .line 1566
    .line 1567
    aput v13, v10, v14

    .line 1568
    .line 1569
    add-int/lit8 v12, v12, 0x1

    .line 1570
    .line 1571
    goto :goto_39

    .line 1572
    :cond_55
    const/4 v12, 0x1

    .line 1573
    if-le v7, v12, :cond_56

    .line 1574
    .line 1575
    invoke-static {v10}, Ljava/util/Arrays;->sort([I)V

    .line 1576
    .line 1577
    .line 1578
    :cond_56
    if-eqz v7, :cond_7d

    .line 1579
    .line 1580
    const/4 v13, 0x0

    .line 1581
    aget v1, v10, v13

    .line 1582
    .line 1583
    move v11, v1

    .line 1584
    const/4 v1, 0x0

    .line 1585
    :goto_3a
    if-ge v1, v7, :cond_5c

    .line 1586
    .line 1587
    aget v12, v10, v1

    .line 1588
    .line 1589
    if-ne v12, v11, :cond_57

    .line 1590
    .line 1591
    move/from16 v22, v1

    .line 1592
    .line 1593
    move-object/from16 p7, v2

    .line 1594
    .line 1595
    move-object/from16 v21, v3

    .line 1596
    .line 1597
    goto :goto_3e

    .line 1598
    :cond_57
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1599
    .line 1600
    .line 1601
    move-result v13

    .line 1602
    move-object v15, v3

    .line 1603
    const/4 v14, 0x0

    .line 1604
    :goto_3b
    if-ge v14, v13, :cond_5a

    .line 1605
    .line 1606
    invoke-virtual {v2, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1607
    .line 1608
    .line 1609
    move-result-object v21

    .line 1610
    move/from16 v22, v1

    .line 1611
    .line 1612
    move-object/from16 v1, v21

    .line 1613
    .line 1614
    check-cast v1, Ldi;

    .line 1615
    .line 1616
    move-object/from16 p7, v2

    .line 1617
    .line 1618
    iget v2, v1, Ldi;->b:I

    .line 1619
    .line 1620
    move-object/from16 v21, v3

    .line 1621
    .line 1622
    iget v3, v1, Ldi;->c:I

    .line 1623
    .line 1624
    if-eq v2, v3, :cond_59

    .line 1625
    .line 1626
    invoke-static {v11, v12, v2, v3}, Lfi;->b(IIII)Z

    .line 1627
    .line 1628
    .line 1629
    move-result v2

    .line 1630
    if-eqz v2, :cond_59

    .line 1631
    .line 1632
    iget-object v1, v1, Ldi;->a:Ljava/lang/Object;

    .line 1633
    .line 1634
    check-cast v1, Lr96;

    .line 1635
    .line 1636
    if-nez v15, :cond_58

    .line 1637
    .line 1638
    :goto_3c
    move-object v15, v1

    .line 1639
    goto :goto_3d

    .line 1640
    :cond_58
    invoke-virtual {v15, v1}, Lr96;->c(Lr96;)Lr96;

    .line 1641
    .line 1642
    .line 1643
    move-result-object v1

    .line 1644
    goto :goto_3c

    .line 1645
    :cond_59
    :goto_3d
    add-int/lit8 v14, v14, 0x1

    .line 1646
    .line 1647
    move-object/from16 v2, p7

    .line 1648
    .line 1649
    move-object/from16 v3, v21

    .line 1650
    .line 1651
    move/from16 v1, v22

    .line 1652
    .line 1653
    goto :goto_3b

    .line 1654
    :cond_5a
    move/from16 v22, v1

    .line 1655
    .line 1656
    move-object/from16 p7, v2

    .line 1657
    .line 1658
    move-object/from16 v21, v3

    .line 1659
    .line 1660
    if-eqz v15, :cond_5b

    .line 1661
    .line 1662
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1663
    .line 1664
    .line 1665
    move-result-object v1

    .line 1666
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1667
    .line 1668
    .line 1669
    move-result-object v2

    .line 1670
    invoke-virtual {v5, v15, v1, v2}, Lbp3;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1671
    .line 1672
    .line 1673
    :cond_5b
    move v11, v12

    .line 1674
    :goto_3e
    add-int/lit8 v1, v22, 0x1

    .line 1675
    .line 1676
    move-object/from16 v2, p7

    .line 1677
    .line 1678
    move-object/from16 v3, v21

    .line 1679
    .line 1680
    goto :goto_3a

    .line 1681
    :cond_5c
    :goto_3f
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 1682
    .line 1683
    .line 1684
    move-result v1

    .line 1685
    const/4 v2, 0x0

    .line 1686
    const/4 v3, 0x0

    .line 1687
    :goto_40
    if-ge v2, v1, :cond_6e

    .line 1688
    .line 1689
    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1690
    .line 1691
    .line 1692
    move-result-object v5

    .line 1693
    check-cast v5, Ldi;

    .line 1694
    .line 1695
    iget-object v7, v5, Ldi;->a:Ljava/lang/Object;

    .line 1696
    .line 1697
    instance-of v10, v7, Lr96;

    .line 1698
    .line 1699
    if-eqz v10, :cond_5d

    .line 1700
    .line 1701
    iget v10, v5, Ldi;->b:I

    .line 1702
    .line 1703
    iget v5, v5, Ldi;->c:I

    .line 1704
    .line 1705
    if-ltz v10, :cond_5d

    .line 1706
    .line 1707
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1708
    .line 1709
    .line 1710
    move-result v11

    .line 1711
    if-ge v10, v11, :cond_5d

    .line 1712
    .line 1713
    if-le v5, v10, :cond_5d

    .line 1714
    .line 1715
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 1716
    .line 1717
    .line 1718
    move-result v11

    .line 1719
    if-le v5, v11, :cond_5e

    .line 1720
    .line 1721
    :cond_5d
    move/from16 p7, v1

    .line 1722
    .line 1723
    move/from16 p4, v2

    .line 1724
    .line 1725
    move-object v2, v9

    .line 1726
    const/4 v15, 0x1

    .line 1727
    goto/16 :goto_4b

    .line 1728
    .line 1729
    :cond_5e
    check-cast v7, Lr96;

    .line 1730
    .line 1731
    iget-wide v11, v7, Lr96;->i:J

    .line 1732
    .line 1733
    iget-object v13, v7, Lr96;->j:Li00;

    .line 1734
    .line 1735
    iget-object v14, v7, Lr96;->b:Lgq6;

    .line 1736
    .line 1737
    if-eqz v13, :cond_60

    .line 1738
    .line 1739
    iget v13, v13, Li00;->a:F

    .line 1740
    .line 1741
    invoke-static {v13}, Ljava/lang/Math;->abs(F)F

    .line 1742
    .line 1743
    .line 1744
    move-result v15

    .line 1745
    cmpg-float v15, v15, v17

    .line 1746
    .line 1747
    if-gtz v15, :cond_60

    .line 1748
    .line 1749
    cmpg-float v15, v13, p3

    .line 1750
    .line 1751
    if-nez v15, :cond_5f

    .line 1752
    .line 1753
    goto :goto_42

    .line 1754
    :cond_5f
    new-instance v15, Lj00;

    .line 1755
    .line 1756
    move/from16 p7, v1

    .line 1757
    .line 1758
    const/4 v1, 0x0

    .line 1759
    invoke-direct {v15, v13, v1}, Lj00;-><init>(FB)V

    .line 1760
    .line 1761
    .line 1762
    const/16 v1, 0x21

    .line 1763
    .line 1764
    invoke-interface {v6, v15, v10, v5, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1765
    .line 1766
    .line 1767
    :goto_41
    move v13, v2

    .line 1768
    goto :goto_43

    .line 1769
    :cond_60
    :goto_42
    move/from16 p7, v1

    .line 1770
    .line 1771
    goto :goto_41

    .line 1772
    :goto_43
    invoke-interface {v14}, Lgq6;->a()J

    .line 1773
    .line 1774
    .line 1775
    move-result-wide v1

    .line 1776
    invoke-static {v6, v1, v2, v10, v5}, Lqu5;->a0(Landroid/text/Spannable;JII)V

    .line 1777
    .line 1778
    .line 1779
    invoke-interface {v14}, Lgq6;->b()Lde0;

    .line 1780
    .line 1781
    .line 1782
    move-result-object v1

    .line 1783
    invoke-interface {v14}, Lgq6;->c()F

    .line 1784
    .line 1785
    .line 1786
    move-result v2

    .line 1787
    if-eqz v1, :cond_62

    .line 1788
    .line 1789
    instance-of v14, v1, Lg96;

    .line 1790
    .line 1791
    if-eqz v14, :cond_61

    .line 1792
    .line 1793
    check-cast v1, Lg96;

    .line 1794
    .line 1795
    iget-wide v1, v1, Lg96;->a:J

    .line 1796
    .line 1797
    invoke-static {v6, v1, v2, v10, v5}, Lqu5;->a0(Landroid/text/Spannable;JII)V

    .line 1798
    .line 1799
    .line 1800
    goto :goto_44

    .line 1801
    :cond_61
    new-instance v14, Lh06;

    .line 1802
    .line 1803
    check-cast v1, Lg06;

    .line 1804
    .line 1805
    invoke-direct {v14, v1, v2}, Lh06;-><init>(Lg06;F)V

    .line 1806
    .line 1807
    .line 1808
    const/16 v1, 0x21

    .line 1809
    .line 1810
    invoke-interface {v6, v14, v10, v5, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1811
    .line 1812
    .line 1813
    :cond_62
    :goto_44
    iget-object v1, v7, Lr96;->n:Lgm6;

    .line 1814
    .line 1815
    if-eqz v1, :cond_65

    .line 1816
    .line 1817
    iget v1, v1, Lgm6;->a:I

    .line 1818
    .line 1819
    new-instance v2, Lhm6;

    .line 1820
    .line 1821
    or-int/lit8 v14, v1, 0x1

    .line 1822
    .line 1823
    if-ne v14, v1, :cond_63

    .line 1824
    .line 1825
    const/4 v14, 0x1

    .line 1826
    goto :goto_45

    .line 1827
    :cond_63
    const/4 v14, 0x0

    .line 1828
    :goto_45
    or-int/lit8 v15, v1, 0x2

    .line 1829
    .line 1830
    if-ne v15, v1, :cond_64

    .line 1831
    .line 1832
    const/4 v1, 0x1

    .line 1833
    goto :goto_46

    .line 1834
    :cond_64
    const/4 v1, 0x0

    .line 1835
    :goto_46
    invoke-direct {v2, v14, v1}, Lhm6;-><init>(ZZ)V

    .line 1836
    .line 1837
    .line 1838
    const/16 v1, 0x21

    .line 1839
    .line 1840
    invoke-interface {v6, v2, v10, v5, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1841
    .line 1842
    .line 1843
    goto :goto_47

    .line 1844
    :cond_65
    const/16 v1, 0x21

    .line 1845
    .line 1846
    :goto_47
    iget-wide v14, v7, Lr96;->c:J

    .line 1847
    .line 1848
    move/from16 v26, v5

    .line 1849
    .line 1850
    move-object/from16 v21, v6

    .line 1851
    .line 1852
    move-object/from16 v24, v9

    .line 1853
    .line 1854
    move/from16 v25, v10

    .line 1855
    .line 1856
    move-wide/from16 v22, v14

    .line 1857
    .line 1858
    invoke-static/range {v21 .. v26}, Lqu5;->b0(Landroid/text/Spannable;JLyh1;II)V

    .line 1859
    .line 1860
    .line 1861
    move-object/from16 v2, v24

    .line 1862
    .line 1863
    move/from16 v5, v25

    .line 1864
    .line 1865
    move/from16 v9, v26

    .line 1866
    .line 1867
    iget-object v10, v7, Lr96;->h:Ljava/lang/String;

    .line 1868
    .line 1869
    if-eqz v10, :cond_66

    .line 1870
    .line 1871
    new-instance v14, Lg42;

    .line 1872
    .line 1873
    const/4 v15, 0x0

    .line 1874
    invoke-direct {v14, v10, v15}, Lg42;-><init>(Ljava/lang/Object;B)V

    .line 1875
    .line 1876
    .line 1877
    invoke-interface {v6, v14, v5, v9, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1878
    .line 1879
    .line 1880
    goto :goto_48

    .line 1881
    :cond_66
    const/4 v15, 0x0

    .line 1882
    :goto_48
    iget-object v10, v7, Lr96;->k:Lhq6;

    .line 1883
    .line 1884
    if-eqz v10, :cond_67

    .line 1885
    .line 1886
    new-instance v14, Landroid/text/style/ScaleXSpan;

    .line 1887
    .line 1888
    iget v15, v10, Lhq6;->a:F

    .line 1889
    .line 1890
    invoke-direct {v14, v15}, Landroid/text/style/ScaleXSpan;-><init>(F)V

    .line 1891
    .line 1892
    .line 1893
    invoke-interface {v6, v14, v5, v9, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1894
    .line 1895
    .line 1896
    new-instance v14, Lj00;

    .line 1897
    .line 1898
    iget v10, v10, Lhq6;->b:F

    .line 1899
    .line 1900
    const/4 v15, 0x1

    .line 1901
    invoke-direct {v14, v10, v15}, Lj00;-><init>(FB)V

    .line 1902
    .line 1903
    .line 1904
    invoke-interface {v6, v14, v5, v9, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1905
    .line 1906
    .line 1907
    goto :goto_49

    .line 1908
    :cond_67
    const/4 v15, 0x1

    .line 1909
    :goto_49
    iget-object v1, v7, Lr96;->l:Llc3;

    .line 1910
    .line 1911
    invoke-static {v6, v1, v5, v9}, Lqu5;->c0(Landroid/text/Spannable;Llc3;II)V

    .line 1912
    .line 1913
    .line 1914
    move-wide/from16 v21, v11

    .line 1915
    .line 1916
    iget-wide v10, v7, Lr96;->m:J

    .line 1917
    .line 1918
    const-wide/16 v23, 0x10

    .line 1919
    .line 1920
    cmp-long v1, v10, v23

    .line 1921
    .line 1922
    if-eqz v1, :cond_68

    .line 1923
    .line 1924
    new-instance v1, Landroid/text/style/BackgroundColorSpan;

    .line 1925
    .line 1926
    invoke-static {v10, v11}, Lzm;->c0(J)I

    .line 1927
    .line 1928
    .line 1929
    move-result v10

    .line 1930
    invoke-direct {v1, v10}, Landroid/text/style/BackgroundColorSpan;-><init>(I)V

    .line 1931
    .line 1932
    .line 1933
    const/16 v10, 0x21

    .line 1934
    .line 1935
    invoke-interface {v6, v1, v5, v9, v10}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1936
    .line 1937
    .line 1938
    :cond_68
    iget-object v1, v7, Lr96;->o:Lk06;

    .line 1939
    .line 1940
    if-eqz v1, :cond_6a

    .line 1941
    .line 1942
    iget-wide v10, v1, Lk06;->b:J

    .line 1943
    .line 1944
    new-instance v12, Lm06;

    .line 1945
    .line 1946
    move-wide/from16 v23, v10

    .line 1947
    .line 1948
    iget-wide v10, v1, Lk06;->a:J

    .line 1949
    .line 1950
    invoke-static {v10, v11}, Lzm;->c0(J)I

    .line 1951
    .line 1952
    .line 1953
    move-result v10

    .line 1954
    const/16 v11, 0x20

    .line 1955
    .line 1956
    move/from16 p4, v13

    .line 1957
    .line 1958
    shr-long v13, v23, v11

    .line 1959
    .line 1960
    long-to-int v11, v13

    .line 1961
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1962
    .line 1963
    .line 1964
    move-result v11

    .line 1965
    const-wide v13, 0xffffffffL

    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    and-long v13, v23, v13

    .line 1971
    .line 1972
    long-to-int v13, v13

    .line 1973
    invoke-static {v13}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1974
    .line 1975
    .line 1976
    move-result v13

    .line 1977
    iget v1, v1, Lk06;->c:F

    .line 1978
    .line 1979
    cmpg-float v14, v1, p3

    .line 1980
    .line 1981
    if-nez v14, :cond_69

    .line 1982
    .line 1983
    const/4 v1, 0x1

    .line 1984
    :cond_69
    invoke-direct {v12, v10, v11, v13, v1}, Lm06;-><init>(IFFF)V

    .line 1985
    .line 1986
    .line 1987
    const/16 v1, 0x21

    .line 1988
    .line 1989
    invoke-interface {v6, v12, v5, v9, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 1990
    .line 1991
    .line 1992
    goto :goto_4a

    .line 1993
    :cond_6a
    move/from16 p4, v13

    .line 1994
    .line 1995
    const/16 v1, 0x21

    .line 1996
    .line 1997
    :goto_4a
    iget-object v7, v7, Lr96;->q:Lio1;

    .line 1998
    .line 1999
    if-eqz v7, :cond_6b

    .line 2000
    .line 2001
    new-instance v10, Ljo1;

    .line 2002
    .line 2003
    invoke-direct {v10, v7}, Ljo1;-><init>(Lio1;)V

    .line 2004
    .line 2005
    .line 2006
    invoke-interface {v6, v10, v5, v9, v1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 2007
    .line 2008
    .line 2009
    :cond_6b
    invoke-static/range {v21 .. v22}, Lts6;->b(J)J

    .line 2010
    .line 2011
    .line 2012
    move-result-wide v9

    .line 2013
    const-wide v11, 0x100000000L

    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    invoke-static {v9, v10, v11, v12}, Lus6;->a(JJ)Z

    .line 2019
    .line 2020
    .line 2021
    move-result v1

    .line 2022
    if-nez v1, :cond_6c

    .line 2023
    .line 2024
    invoke-static/range {v21 .. v22}, Lts6;->b(J)J

    .line 2025
    .line 2026
    .line 2027
    move-result-wide v9

    .line 2028
    const-wide v12, 0x200000000L

    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    invoke-static {v9, v10, v12, v13}, Lus6;->a(JJ)Z

    .line 2034
    .line 2035
    .line 2036
    move-result v1

    .line 2037
    if-eqz v1, :cond_6d

    .line 2038
    .line 2039
    :cond_6c
    move v3, v15

    .line 2040
    :cond_6d
    :goto_4b
    add-int/lit8 v1, p4, 0x1

    .line 2041
    .line 2042
    move-object v9, v2

    .line 2043
    move v2, v1

    .line 2044
    move/from16 v1, p7

    .line 2045
    .line 2046
    goto/16 :goto_40

    .line 2047
    .line 2048
    :cond_6e
    move-object v2, v9

    .line 2049
    const/4 v15, 0x1

    .line 2050
    if-eqz v3, :cond_73

    .line 2051
    .line 2052
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 2053
    .line 2054
    .line 2055
    move-result v1

    .line 2056
    const/4 v3, 0x0

    .line 2057
    :goto_4c
    if-ge v3, v1, :cond_73

    .line 2058
    .line 2059
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2060
    .line 2061
    .line 2062
    move-result-object v5

    .line 2063
    check-cast v5, Ldi;

    .line 2064
    .line 2065
    iget-object v7, v5, Ldi;->a:Ljava/lang/Object;

    .line 2066
    .line 2067
    check-cast v7, Lai;

    .line 2068
    .line 2069
    instance-of v9, v7, Lr96;

    .line 2070
    .line 2071
    if-eqz v9, :cond_72

    .line 2072
    .line 2073
    iget v9, v5, Ldi;->b:I

    .line 2074
    .line 2075
    iget v5, v5, Ldi;->c:I

    .line 2076
    .line 2077
    if-ltz v9, :cond_72

    .line 2078
    .line 2079
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 2080
    .line 2081
    .line 2082
    move-result v10

    .line 2083
    if-ge v9, v10, :cond_72

    .line 2084
    .line 2085
    if-le v5, v9, :cond_72

    .line 2086
    .line 2087
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 2088
    .line 2089
    .line 2090
    move-result v10

    .line 2091
    if-le v5, v10, :cond_6f

    .line 2092
    .line 2093
    goto :goto_4e

    .line 2094
    :cond_6f
    check-cast v7, Lr96;

    .line 2095
    .line 2096
    iget-wide v10, v7, Lr96;->i:J

    .line 2097
    .line 2098
    invoke-static {v10, v11}, Lts6;->b(J)J

    .line 2099
    .line 2100
    .line 2101
    move-result-wide v12

    .line 2102
    const-wide v14, 0x100000000L

    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    invoke-static {v12, v13, v14, v15}, Lus6;->a(JJ)Z

    .line 2108
    .line 2109
    .line 2110
    move-result v7

    .line 2111
    if-eqz v7, :cond_70

    .line 2112
    .line 2113
    new-instance v7, Le63;

    .line 2114
    .line 2115
    invoke-interface {v2, v10, v11}, Lyh1;->N0(J)F

    .line 2116
    .line 2117
    .line 2118
    move-result v10

    .line 2119
    invoke-direct {v7, v10}, Le63;-><init>(F)V

    .line 2120
    .line 2121
    .line 2122
    goto :goto_4d

    .line 2123
    :cond_70
    const-wide v14, 0x200000000L

    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    invoke-static {v12, v13, v14, v15}, Lus6;->a(JJ)Z

    .line 2129
    .line 2130
    .line 2131
    move-result v7

    .line 2132
    if-eqz v7, :cond_71

    .line 2133
    .line 2134
    new-instance v7, Ld63;

    .line 2135
    .line 2136
    invoke-static {v10, v11}, Lts6;->c(J)F

    .line 2137
    .line 2138
    .line 2139
    move-result v10

    .line 2140
    invoke-direct {v7, v10}, Ld63;-><init>(F)V

    .line 2141
    .line 2142
    .line 2143
    goto :goto_4d

    .line 2144
    :cond_71
    move-object/from16 v7, p1

    .line 2145
    .line 2146
    :goto_4d
    if-eqz v7, :cond_72

    .line 2147
    .line 2148
    const/16 v10, 0x21

    .line 2149
    .line 2150
    invoke-interface {v6, v7, v9, v5, v10}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 2151
    .line 2152
    .line 2153
    :cond_72
    :goto_4e
    add-int/lit8 v3, v3, 0x1

    .line 2154
    .line 2155
    const/4 v15, 0x1

    .line 2156
    goto :goto_4c

    .line 2157
    :cond_73
    move-object/from16 v1, v16

    .line 2158
    .line 2159
    iget-object v1, v1, Lmm4;->e:Ljq6;

    .line 2160
    .line 2161
    if-eqz v1, :cond_75

    .line 2162
    .line 2163
    iget-wide v9, v1, Ljq6;->a:J

    .line 2164
    .line 2165
    invoke-static {v9, v10}, Lts6;->b(J)J

    .line 2166
    .line 2167
    .line 2168
    move-result-wide v11

    .line 2169
    const-wide v14, 0x100000000L

    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    invoke-static {v11, v12, v14, v15}, Lus6;->a(JJ)Z

    .line 2175
    .line 2176
    .line 2177
    move-result v1

    .line 2178
    if-eqz v1, :cond_74

    .line 2179
    .line 2180
    invoke-interface {v2, v9, v10}, Lyh1;->N0(J)F

    .line 2181
    .line 2182
    .line 2183
    goto :goto_4f

    .line 2184
    :cond_74
    const-wide v13, 0x200000000L

    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
    invoke-static {v11, v12, v13, v14}, Lus6;->a(JJ)Z

    .line 2190
    .line 2191
    .line 2192
    move-result v1

    .line 2193
    if-eqz v1, :cond_75

    .line 2194
    .line 2195
    invoke-static {v9, v10}, Lts6;->c(J)F

    .line 2196
    .line 2197
    .line 2198
    :cond_75
    :goto_4f
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 2199
    .line 2200
    .line 2201
    move-result v1

    .line 2202
    const/4 v3, 0x0

    .line 2203
    :goto_50
    if-ge v3, v1, :cond_76

    .line 2204
    .line 2205
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2206
    .line 2207
    .line 2208
    move-result-object v5

    .line 2209
    check-cast v5, Ldi;

    .line 2210
    .line 2211
    iget-object v5, v5, Ldi;->a:Ljava/lang/Object;

    .line 2212
    .line 2213
    add-int/lit8 v3, v3, 0x1

    .line 2214
    .line 2215
    goto :goto_50

    .line 2216
    :cond_76
    invoke-interface {v8}, Ljava/util/Collection;->size()I

    .line 2217
    .line 2218
    .line 2219
    move-result v1

    .line 2220
    const/4 v3, 0x0

    .line 2221
    :goto_51
    if-ge v3, v1, :cond_7c

    .line 2222
    .line 2223
    invoke-interface {v8, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2224
    .line 2225
    .line 2226
    move-result-object v4

    .line 2227
    check-cast v4, Ldi;

    .line 2228
    .line 2229
    iget-object v5, v4, Ldi;->a:Ljava/lang/Object;

    .line 2230
    .line 2231
    check-cast v5, Lnp4;

    .line 2232
    .line 2233
    iget v7, v4, Ldi;->b:I

    .line 2234
    .line 2235
    iget v4, v4, Ldi;->c:I

    .line 2236
    .line 2237
    const-class v9, Ln17;

    .line 2238
    .line 2239
    invoke-interface {v6, v7, v4, v9}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 2240
    .line 2241
    .line 2242
    move-result-object v9

    .line 2243
    array-length v10, v9

    .line 2244
    const/4 v11, 0x0

    .line 2245
    :goto_52
    if-ge v11, v10, :cond_77

    .line 2246
    .line 2247
    aget-object v12, v9, v11

    .line 2248
    .line 2249
    check-cast v12, Ln17;

    .line 2250
    .line 2251
    invoke-interface {v6, v12}, Landroid/text/Spannable;->removeSpan(Ljava/lang/Object;)V

    .line 2252
    .line 2253
    .line 2254
    add-int/lit8 v11, v11, 0x1

    .line 2255
    .line 2256
    goto :goto_52

    .line 2257
    :cond_77
    new-instance v21, Lop4;

    .line 2258
    .line 2259
    iget-wide v9, v5, Lnp4;->a:J

    .line 2260
    .line 2261
    iget-wide v11, v5, Lnp4;->b:J

    .line 2262
    .line 2263
    invoke-static {v9, v10}, Lts6;->c(J)F

    .line 2264
    .line 2265
    .line 2266
    move-result v22

    .line 2267
    iget-wide v9, v5, Lnp4;->a:J

    .line 2268
    .line 2269
    invoke-static {v9, v10}, Lts6;->b(J)J

    .line 2270
    .line 2271
    .line 2272
    move-result-wide v9

    .line 2273
    const-wide v14, 0x100000000L

    .line 2274
    .line 2275
    .line 2276
    .line 2277
    .line 2278
    invoke-static {v9, v10, v14, v15}, Lus6;->a(JJ)Z

    .line 2279
    .line 2280
    .line 2281
    move-result v5

    .line 2282
    if-eqz v5, :cond_78

    .line 2283
    .line 2284
    const-wide v14, 0x200000000L

    .line 2285
    .line 2286
    .line 2287
    .line 2288
    .line 2289
    const/16 v23, 0x0

    .line 2290
    .line 2291
    goto :goto_53

    .line 2292
    :cond_78
    const-wide v14, 0x200000000L

    .line 2293
    .line 2294
    .line 2295
    .line 2296
    .line 2297
    invoke-static {v9, v10, v14, v15}, Lus6;->a(JJ)Z

    .line 2298
    .line 2299
    .line 2300
    move-result v5

    .line 2301
    if-eqz v5, :cond_79

    .line 2302
    .line 2303
    const/16 v23, 0x1

    .line 2304
    .line 2305
    goto :goto_53

    .line 2306
    :cond_79
    const/16 v23, 0x2

    .line 2307
    .line 2308
    :goto_53
    invoke-static {v11, v12}, Lts6;->c(J)F

    .line 2309
    .line 2310
    .line 2311
    move-result v24

    .line 2312
    invoke-static {v11, v12}, Lts6;->b(J)J

    .line 2313
    .line 2314
    .line 2315
    move-result-wide v9

    .line 2316
    const-wide v11, 0x100000000L

    .line 2317
    .line 2318
    .line 2319
    .line 2320
    .line 2321
    invoke-static {v9, v10, v11, v12}, Lus6;->a(JJ)Z

    .line 2322
    .line 2323
    .line 2324
    move-result v5

    .line 2325
    if-eqz v5, :cond_7a

    .line 2326
    .line 2327
    const/16 v25, 0x0

    .line 2328
    .line 2329
    goto :goto_54

    .line 2330
    :cond_7a
    invoke-static {v9, v10, v14, v15}, Lus6;->a(JJ)Z

    .line 2331
    .line 2332
    .line 2333
    move-result v5

    .line 2334
    if-eqz v5, :cond_7b

    .line 2335
    .line 2336
    const/16 v25, 0x1

    .line 2337
    .line 2338
    goto :goto_54

    .line 2339
    :cond_7b
    const/16 v25, 0x2

    .line 2340
    .line 2341
    :goto_54
    const/16 v27, 0x6

    .line 2342
    .line 2343
    move-object/from16 v26, v2

    .line 2344
    .line 2345
    invoke-direct/range {v21 .. v27}, Lop4;-><init>(FIFILyh1;I)V

    .line 2346
    .line 2347
    .line 2348
    move-object/from16 v2, v21

    .line 2349
    .line 2350
    move-object/from16 v24, v26

    .line 2351
    .line 2352
    const/16 v10, 0x21

    .line 2353
    .line 2354
    invoke-interface {v6, v2, v7, v4, v10}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 2355
    .line 2356
    .line 2357
    add-int/lit8 v3, v3, 0x1

    .line 2358
    .line 2359
    move-object/from16 v2, v24

    .line 2360
    .line 2361
    goto/16 :goto_51

    .line 2362
    .line 2363
    :cond_7c
    :goto_55
    iput-object v6, v0, Lad;->h:Ljava/lang/CharSequence;

    .line 2364
    .line 2365
    new-instance v1, Ly03;

    .line 2366
    .line 2367
    iget-object v2, v0, Lad;->g:Ldf;

    .line 2368
    .line 2369
    iget v3, v0, Lad;->l:I

    .line 2370
    .line 2371
    invoke-direct {v1, v6, v2, v3}, Ly03;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V

    .line 2372
    .line 2373
    .line 2374
    iput-object v1, v0, Lad;->i:Ly03;

    .line 2375
    .line 2376
    return-void

    .line 2377
    :cond_7d
    const-string v0, "Array is empty."

    .line 2378
    .line 2379
    invoke-static {v0}, Lgb4;->h(Ljava/lang/String;)V

    .line 2380
    .line 2381
    .line 2382
    throw p1

    .line 2383
    :cond_7e
    const/16 p1, 0x0

    .line 2384
    .line 2385
    const-string v0, "Invalid TextDirection."

    .line 2386
    .line 2387
    invoke-static {v0}, Ljw1;->e(Ljava/lang/String;)V

    .line 2388
    .line 2389
    .line 2390
    throw p1
.end method


# virtual methods
.method public final a()F
    .locals 10

    .line 1
    iget-object p0, p0, Lad;->i:Ly03;

    .line 2
    .line 3
    iget v0, p0, Ly03;->e:F

    .line 4
    .line 5
    iget-object v1, p0, Ly03;->b:Landroid/text/TextPaint;

    .line 6
    .line 7
    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iget p0, p0, Ly03;->e:F

    .line 14
    .line 15
    return p0

    .line 16
    :cond_0
    invoke-virtual {v1}, Landroid/graphics/Paint;->getTextLocale()Ljava/util/Locale;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0}, Ljava/text/BreakIterator;->getLineInstance(Ljava/util/Locale;)Ljava/text/BreakIterator;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    new-instance v2, Lzn0;

    .line 25
    .line 26
    iget-object v3, p0, Ly03;->a:Ljava/lang/CharSequence;

    .line 27
    .line 28
    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    invoke-direct {v2, v3, v4}, Lzn0;-><init>(Ljava/lang/CharSequence;I)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0, v2}, Ljava/text/BreakIterator;->setText(Ljava/text/CharacterIterator;)V

    .line 36
    .line 37
    .line 38
    new-instance v2, Ljava/util/PriorityQueue;

    .line 39
    .line 40
    sget-object v3, Lkw;->S:Lsa;

    .line 41
    .line 42
    const/16 v4, 0xa

    .line 43
    .line 44
    invoke-direct {v2, v4, v3}, Ljava/util/PriorityQueue;-><init>(ILjava/util/Comparator;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/text/BreakIterator;->next()I

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    const/4 v5, 0x0

    .line 52
    :goto_0
    const/4 v6, -0x1

    .line 53
    if-eq v3, v6, :cond_3

    .line 54
    .line 55
    invoke-virtual {v2}, Ljava/util/PriorityQueue;->size()I

    .line 56
    .line 57
    .line 58
    move-result v6

    .line 59
    const/4 v7, 0x1

    .line 60
    if-ge v6, v4, :cond_1

    .line 61
    .line 62
    new-instance v6, Les2;

    .line 63
    .line 64
    invoke-direct {v6, v5, v3, v7}, Lcs2;-><init>(III)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v2, v6}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_1
    invoke-virtual {v2}, Ljava/util/PriorityQueue;->peek()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    check-cast v6, Les2;

    .line 76
    .line 77
    if-eqz v6, :cond_2

    .line 78
    .line 79
    iget v8, v6, Lcs2;->k:I

    .line 80
    .line 81
    iget v6, v6, Lcs2;->j:I

    .line 82
    .line 83
    sub-int/2addr v8, v6

    .line 84
    sub-int v6, v3, v5

    .line 85
    .line 86
    if-ge v8, v6, :cond_2

    .line 87
    .line 88
    invoke-virtual {v2}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    new-instance v6, Les2;

    .line 92
    .line 93
    invoke-direct {v6, v5, v3, v7}, Lcs2;-><init>(III)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v2, v6}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    :cond_2
    :goto_1
    invoke-virtual {v0}, Ljava/text/BreakIterator;->next()I

    .line 100
    .line 101
    .line 102
    move-result v5

    .line 103
    move v9, v5

    .line 104
    move v5, v3

    .line 105
    move v3, v9

    .line 106
    goto :goto_0

    .line 107
    :cond_3
    invoke-virtual {v2}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    const/4 v3, 0x0

    .line 112
    if-eqz v0, :cond_4

    .line 113
    .line 114
    goto :goto_3

    .line 115
    :cond_4
    invoke-virtual {v2}, Ljava/util/PriorityQueue;->iterator()Ljava/util/Iterator;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 120
    .line 121
    .line 122
    move-result v2

    .line 123
    if-eqz v2, :cond_6

    .line 124
    .line 125
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    check-cast v2, Les2;

    .line 130
    .line 131
    iget v3, v2, Lcs2;->j:I

    .line 132
    .line 133
    iget v2, v2, Lcs2;->k:I

    .line 134
    .line 135
    invoke-virtual {p0}, Ly03;->b()Ljava/lang/CharSequence;

    .line 136
    .line 137
    .line 138
    move-result-object v4

    .line 139
    invoke-static {v4, v3, v2, v1}, Landroid/text/Layout;->getDesiredWidth(Ljava/lang/CharSequence;IILandroid/text/TextPaint;)F

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    move v3, v2

    .line 144
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 145
    .line 146
    .line 147
    move-result v2

    .line 148
    if-eqz v2, :cond_5

    .line 149
    .line 150
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    check-cast v2, Les2;

    .line 155
    .line 156
    iget v4, v2, Lcs2;->j:I

    .line 157
    .line 158
    iget v2, v2, Lcs2;->k:I

    .line 159
    .line 160
    invoke-virtual {p0}, Ly03;->b()Ljava/lang/CharSequence;

    .line 161
    .line 162
    .line 163
    move-result-object v5

    .line 164
    invoke-static {v5, v4, v2, v1}, Landroid/text/Layout;->getDesiredWidth(Ljava/lang/CharSequence;IILandroid/text/TextPaint;)F

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    .line 169
    .line 170
    .line 171
    move-result v3

    .line 172
    goto :goto_2

    .line 173
    :cond_5
    :goto_3
    iput v3, p0, Ly03;->e:F

    .line 174
    .line 175
    return v3

    .line 176
    :cond_6
    invoke-static {}, Lue1;->p()V

    .line 177
    .line 178
    .line 179
    return v3
.end method

.method public final b()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lad;->j:Luq6;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {v0}, Luq6;->e()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    move v0, v1

    .line 12
    :goto_0
    if-nez v0, :cond_4

    .line 13
    .line 14
    iget-boolean v0, p0, Lad;->k:Z

    .line 15
    .line 16
    if-nez v0, :cond_3

    .line 17
    .line 18
    iget-object p0, p0, Lad;->b:Lls6;

    .line 19
    .line 20
    invoke-static {p0}, Lfh3;->B(Lls6;)Z

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    if-eqz p0, :cond_3

    .line 25
    .line 26
    sget-object p0, Lrt1;->a:Le6;

    .line 27
    .line 28
    sget-object p0, Lrt1;->a:Le6;

    .line 29
    .line 30
    iget-object v0, p0, Le6;->k:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v0, Lmb6;

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_1
    invoke-static {}, Lot1;->d()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2

    .line 42
    .line 43
    invoke-virtual {p0}, Le6;->y()Lmb6;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iput-object v0, p0, Le6;->k:Ljava/lang/Object;

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_2
    sget-object v0, Lyt2;->m0:Lgo2;

    .line 51
    .line 52
    :goto_1
    invoke-interface {v0}, Lmb6;->getValue()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    check-cast p0, Ljava/lang/Boolean;

    .line 57
    .line 58
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 59
    .line 60
    .line 61
    move-result p0

    .line 62
    if-eqz p0, :cond_3

    .line 63
    .line 64
    goto :goto_2

    .line 65
    :cond_3
    return v1

    .line 66
    :cond_4
    :goto_2
    const/4 p0, 0x1

    .line 67
    return p0
.end method

.method public final c()F
    .locals 0

    .line 1
    iget-object p0, p0, Lad;->i:Ly03;

    .line 2
    .line 3
    invoke-virtual {p0}, Ly03;->c()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
