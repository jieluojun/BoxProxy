.class public abstract Law3;
.super Ljava/lang/Object;
.source "r8-map-id-20ba21aa719a118f6636b4195284472d40e9653eb9bd33ff7cbddda1dfd1d123"


# static fields
.field public static final a:Lzv3;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lzv3;

    .line 2
    .line 3
    invoke-direct {v0}, Lzv3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Law3;->a:Lzv3;

    .line 7
    .line 8
    return-void
.end method
