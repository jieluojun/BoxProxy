.class public final La22;
.super Lz81;


# instance fields
.field public synthetic j:Ljava/lang/Object;

.field public k:I

.field public final synthetic l:Lol;

.field public m:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lol;Ly81;)V
    .locals 0

    .line 1
    iput-object p1, p0, La22;->l:Lol;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lz81;-><init>(Ly81;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, La22;->j:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, La22;->k:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, La22;->k:I

    .line 9
    .line 10
    iget-object p1, p0, La22;->l:Lol;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lol;->e(Ljava/lang/Object;Ly81;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
