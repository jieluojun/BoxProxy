.class public interface abstract Law5;
.super Ljava/lang/Object;
.source "r8-map-id-adb9385fd45323bd1d9ee3e5a60d53e33e96c144368c2f9b042de79c702db584"

# interfaces
.implements Lio3;


# virtual methods
.method public abstract a1()Lzv5;
.end method
