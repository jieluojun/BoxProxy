.class public final synthetic La63;
.super Ljava/lang/Object;
.source "r8-map-id-adb9385fd45323bd1d9ee3e5a60d53e33e96c144368c2f9b042de79c702db584"

# interfaces
.implements Lc63;


# instance fields
.field public final synthetic j:Lm63;

.field public final synthetic k:Lz85;

.field public final synthetic l:Lo52;


# direct methods
.method public synthetic constructor <init>(Lm63;Lz85;Lo52;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La63;->j:Lm63;

    .line 5
    .line 6
    iput-object p2, p0, La63;->k:Lz85;

    .line 7
    .line 8
    iput-object p3, p0, La63;->l:Lo52;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final f(Le63;Lw53;)V
    .locals 1

    .line 1
    sget-object p1, Lb63;->a:[I

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    aget p1, p1, p2

    .line 8
    .line 9
    const/4 p2, 0x1

    .line 10
    iget-object v0, p0, La63;->k:Lz85;

    .line 11
    .line 12
    if-eq p1, p2, :cond_2

    .line 13
    .line 14
    const/4 p0, 0x2

    .line 15
    if-eq p1, p0, :cond_0

    .line 16
    .line 17
    return-void

    .line 18
    :cond_0
    iget-object p0, v0, Lz85;->j:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p0, Ley;

    .line 21
    .line 22
    if-eqz p0, :cond_1

    .line 23
    .line 24
    invoke-virtual {p0}, Ley;->a()V

    .line 25
    .line 26
    .line 27
    :cond_1
    const/4 p0, 0x0

    .line 28
    iput-object p0, v0, Lz85;->j:Ljava/lang/Object;

    .line 29
    .line 30
    return-void

    .line 31
    :cond_2
    iget-object p1, p0, La63;->l:Lo52;

    .line 32
    .line 33
    iget-object p0, p0, La63;->j:Lm63;

    .line 34
    .line 35
    invoke-interface {p1, p0}, Lo52;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    iput-object p0, v0, Lz85;->j:Ljava/lang/Object;

    .line 40
    .line 41
    return-void
.end method
