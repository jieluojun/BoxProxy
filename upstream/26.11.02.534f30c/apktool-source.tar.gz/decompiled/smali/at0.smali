.class public final Lat0;
.super Ljava/lang/Object;
.source "r8-map-id-adb9385fd45323bd1d9ee3e5a60d53e33e96c144368c2f9b042de79c702db584"


# instance fields
.field public final a:Las3;

.field public final b:Las3;

.field public final c:Las3;


# direct methods
.method public constructor <init>(Las3;Las3;Las3;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lat0;->a:Las3;

    .line 14
    .line 15
    iput-object p2, p0, Lat0;->b:Las3;

    .line 16
    .line 17
    iput-object p3, p0, Lat0;->c:Las3;

    .line 18
    .line 19
    return-void
.end method
