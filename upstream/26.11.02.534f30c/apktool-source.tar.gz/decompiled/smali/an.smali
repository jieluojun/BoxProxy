.class public final Lan;
.super Lz71;
.source "r8-map-id-adb9385fd45323bd1d9ee3e5a60d53e33e96c144368c2f9b042de79c702db584"


# instance fields
.field public j:Ljava/io/InputStream;

.field public k:Ljava/util/Set;

.field public l:Landroid/content/Context;

.field public m:Ljava/io/File;

.field public n:Ljava/lang/Object;

.field public synthetic o:Ljava/lang/Object;

.field public final synthetic p:Lkn;

.field public q:I


# direct methods
.method public constructor <init>(Lkn;Lz71;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lan;->p:Lkn;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lz71;-><init>(Ly71;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lan;->o:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lan;->q:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lan;->q:I

    .line 9
    .line 10
    iget-object p1, p0, Lan;->p:Lkn;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, v0, p0}, Lkn;->i(Landroid/content/Context;Ljava/io/InputStream;Ljava/util/Set;Lz71;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    sget-object p1, Lcb1;->j:Lcb1;

    .line 18
    .line 19
    if-ne p0, p1, :cond_0

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_0
    new-instance p1, Lub5;

    .line 23
    .line 24
    invoke-direct {p1, p0}, Lub5;-><init>(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-object p1
.end method
