.class public final Lac1;
.super Lo83;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public x:Lwh2;


# virtual methods
.method public final G1(Ly18;)Ly18;
    .locals 0

    .line 1
    iget-object p0, p0, Lac1;->x:Lwh2;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-object p1
.end method
