.class public final synthetic Lb80;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic h:Z

.field public final synthetic i:Leq6;

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:Ljava/lang/String;

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:Llh2;

.field public final synthetic n:Ljj1;


# direct methods
.method public synthetic constructor <init>(ZLeq6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Llh2;Ljj1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lb80;->h:Z

    .line 5
    .line 6
    iput-object p2, p0, Lb80;->i:Leq6;

    .line 7
    .line 8
    iput-object p3, p0, Lb80;->j:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lb80;->k:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p5, p0, Lb80;->l:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p6, p0, Lb80;->m:Llh2;

    .line 15
    .line 16
    iput-object p7, p0, Lb80;->n:Ljj1;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    check-cast p1, Lll6;

    .line 2
    .line 3
    iget-boolean v0, p0, Lb80;->h:Z

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    new-instance v0, Lym;

    .line 8
    .line 9
    iget-object v1, p0, Lb80;->m:Llh2;

    .line 10
    .line 11
    const/16 v2, 0x11

    .line 12
    .line 13
    invoke-direct {v0, v1, v2}, Lym;-><init>(Llh2;B)V

    .line 14
    .line 15
    .line 16
    sget-object v1, Ljl6;->a:[Ldg3;

    .line 17
    .line 18
    sget-object v1, Lyk6;->v:Lkl6;

    .line 19
    .line 20
    new-instance v3, Lu4;

    .line 21
    .line 22
    iget-object v4, p0, Lb80;->j:Ljava/lang/String;

    .line 23
    .line 24
    invoke-direct {v3, v4, v0}, Lu4;-><init>(Ljava/lang/String;Lii2;)V

    .line 25
    .line 26
    .line 27
    invoke-interface {p1, v1, v3}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-object v0, p0, Lb80;->i:Leq6;

    .line 31
    .line 32
    invoke-virtual {v0}, Leq6;->c()Lfq6;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iget-object v3, p0, Lb80;->n:Ljj1;

    .line 37
    .line 38
    sget-object v4, Lfq6;->j:Lfq6;

    .line 39
    .line 40
    if-ne v1, v4, :cond_0

    .line 41
    .line 42
    new-instance v1, Llm;

    .line 43
    .line 44
    const/4 v2, 0x5

    .line 45
    invoke-direct {v1, v0, v3, v0, v2}, Llm;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 46
    .line 47
    .line 48
    sget-object v0, Lyk6;->t:Lkl6;

    .line 49
    .line 50
    new-instance v2, Lu4;

    .line 51
    .line 52
    iget-object p0, p0, Lb80;->k:Ljava/lang/String;

    .line 53
    .line 54
    invoke-direct {v2, p0, v1}, Lu4;-><init>(Ljava/lang/String;Lii2;)V

    .line 55
    .line 56
    .line 57
    invoke-interface {p1, v0, v2}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_0
    iget-object v1, v0, Leq6;->d:Lu9;

    .line 62
    .line 63
    invoke-virtual {v1}, Lu9;->e()Lfn1;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-virtual {v1, v4}, Lfn1;->c(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    if-eqz v1, :cond_1

    .line 72
    .line 73
    new-instance v1, Lx;

    .line 74
    .line 75
    invoke-direct {v1, v0, v3, v2}, Lx;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 76
    .line 77
    .line 78
    sget-object v0, Lyk6;->u:Lkl6;

    .line 79
    .line 80
    new-instance v2, Lu4;

    .line 81
    .line 82
    iget-object p0, p0, Lb80;->l:Ljava/lang/String;

    .line 83
    .line 84
    invoke-direct {v2, p0, v1}, Lu4;-><init>(Ljava/lang/String;Lii2;)V

    .line 85
    .line 86
    .line 87
    invoke-interface {p1, v0, v2}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    :cond_1
    :goto_0
    sget-object p0, Lst7;->a:Lst7;

    .line 91
    .line 92
    return-object p0
.end method
