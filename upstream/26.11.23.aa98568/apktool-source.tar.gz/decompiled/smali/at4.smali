.class public interface abstract Lat4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public abstract a(Lab4;)Z
.end method

.method public abstract b()I
.end method

.method public c(Lab4;)Z
    .locals 0

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public abstract d(Lzi3;JLzs2;IZ)V
.end method

.method public abstract f(Lzs2;Lzi3;)Z
.end method

.method public abstract g(Lzi3;)Z
.end method
