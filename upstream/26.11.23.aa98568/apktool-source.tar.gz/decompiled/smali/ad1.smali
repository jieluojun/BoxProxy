.class public interface abstract Lad1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public abstract a()Landroid/view/ContentInfo;
.end method

.method public abstract c()I
.end method

.method public abstract d()Landroid/content/ClipData;
.end method

.method public abstract e()I
.end method
