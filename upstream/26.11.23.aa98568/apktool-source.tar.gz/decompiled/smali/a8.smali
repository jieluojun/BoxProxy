.class public final synthetic La8;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:F

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(FLjava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, La8;->h:B

    .line 2
    .line 3
    iput p1, p0, La8;->i:F

    .line 4
    .line 5
    iput-object p2, p0, La8;->j:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p3, p0, La8;->k:Ljava/lang/Object;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;FLjava/lang/Object;IB)V
    .locals 0

    .line 13
    iput-byte p5, p0, La8;->h:B

    iput-object p1, p0, La8;->j:Ljava/lang/Object;

    iput p2, p0, La8;->i:F

    iput-object p3, p0, La8;->k:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 39

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La8;->h:B

    .line 4
    .line 5
    sget-object v2, Lzi3;->Z:Lu43;

    .line 6
    .line 7
    sget-object v3, Lya4;->h:Lya4;

    .line 8
    .line 9
    const/4 v5, 0x6

    .line 10
    const/high16 v6, 0x3f800000    # 1.0f

    .line 11
    .line 12
    const/4 v7, 0x0

    .line 13
    const/4 v8, 0x2

    .line 14
    const/4 v9, 0x1

    .line 15
    sget-object v10, Lst7;->a:Lst7;

    .line 16
    .line 17
    iget-object v11, v0, La8;->k:Ljava/lang/Object;

    .line 18
    .line 19
    iget v12, v0, La8;->i:F

    .line 20
    .line 21
    iget-object v0, v0, La8;->j:Ljava/lang/Object;

    .line 22
    .line 23
    const/4 v13, 0x3

    .line 24
    packed-switch v1, :pswitch_data_0

    .line 25
    .line 26
    .line 27
    check-cast v0, Lbb4;

    .line 28
    .line 29
    check-cast v11, Ls21;

    .line 30
    .line 31
    move-object/from16 v1, p1

    .line 32
    .line 33
    check-cast v1, Lzi2;

    .line 34
    .line 35
    move-object/from16 v2, p2

    .line 36
    .line 37
    check-cast v2, Ljava/lang/Integer;

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    const/16 v2, 0x187

    .line 43
    .line 44
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    invoke-static {v0, v12, v11, v1, v2}, Luk3;->v(Lbb4;FLs21;Lzi2;I)V

    .line 49
    .line 50
    .line 51
    return-object v10

    .line 52
    :pswitch_0
    check-cast v0, Lyg4;

    .line 53
    .line 54
    check-cast v11, Lvg4;

    .line 55
    .line 56
    move-object/from16 v1, p1

    .line 57
    .line 58
    check-cast v1, Lzi2;

    .line 59
    .line 60
    move-object/from16 v2, p2

    .line 61
    .line 62
    check-cast v2, Ljava/lang/Integer;

    .line 63
    .line 64
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    invoke-static {v9}, Lyj3;->j0(I)I

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    invoke-static {v0, v12, v11, v1, v2}, Lbr7;->x(Lyg4;FLvg4;Lzi2;I)V

    .line 72
    .line 73
    .line 74
    return-object v10

    .line 75
    :pswitch_1
    move-object v14, v0

    .line 76
    check-cast v14, Llh2;

    .line 77
    .line 78
    check-cast v11, Lgu2;

    .line 79
    .line 80
    move-object/from16 v0, p1

    .line 81
    .line 82
    check-cast v0, Lzi2;

    .line 83
    .line 84
    move-object/from16 v1, p2

    .line 85
    .line 86
    check-cast v1, Ljava/lang/Integer;

    .line 87
    .line 88
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    and-int/lit8 v15, v1, 0x3

    .line 93
    .line 94
    if-eq v15, v8, :cond_0

    .line 95
    .line 96
    move v15, v9

    .line 97
    goto :goto_0

    .line 98
    :cond_0
    move v15, v7

    .line 99
    :goto_0
    and-int/2addr v1, v9

    .line 100
    invoke-virtual {v0, v1, v15}, Lzi2;->Y(IZ)Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    if-eqz v1, :cond_4

    .line 105
    .line 106
    invoke-static {v0}, Lbx;->c0(Lzi2;)Leh6;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    invoke-virtual {v0, v1}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v15

    .line 114
    invoke-virtual {v0}, Lzi2;->T()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    if-nez v15, :cond_1

    .line 119
    .line 120
    sget-object v15, Lc51;->a:Lql0;

    .line 121
    .line 122
    if-ne v4, v15, :cond_2

    .line 123
    .line 124
    :cond_1
    new-instance v4, Lg1;

    .line 125
    .line 126
    const/4 v15, 0x0

    .line 127
    invoke-direct {v4, v1, v15, v8}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_2
    check-cast v4, Lwh2;

    .line 134
    .line 135
    invoke-static {v1, v4, v0, v7}, Los2;->a(Lph6;Lwh2;Lzi2;I)V

    .line 136
    .line 137
    .line 138
    invoke-static {v3, v6}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 139
    .line 140
    .line 141
    move-result-object v4

    .line 142
    new-instance v7, Lnw;

    .line 143
    .line 144
    new-instance v8, Ll42;

    .line 145
    .line 146
    invoke-direct {v8, v13}, Ll42;-><init>(B)V

    .line 147
    .line 148
    .line 149
    const/high16 v13, 0x41200000    # 10.0f

    .line 150
    .line 151
    invoke-direct {v7, v13, v9, v8}, Lnw;-><init>(FZLl42;)V

    .line 152
    .line 153
    .line 154
    sget-object v8, Ly6;->v:Lz30;

    .line 155
    .line 156
    invoke-static {v7, v8, v0, v5}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 157
    .line 158
    .line 159
    move-result-object v5

    .line 160
    iget-wide v7, v0, Lzi2;->U:J

    .line 161
    .line 162
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 163
    .line 164
    .line 165
    move-result v7

    .line 166
    invoke-virtual {v0}, Lzi2;->m()Lla5;

    .line 167
    .line 168
    .line 169
    move-result-object v8

    .line 170
    invoke-static {v0, v4}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 171
    .line 172
    .line 173
    move-result-object v4

    .line 174
    sget-object v13, Ls41;->d:Ly6;

    .line 175
    .line 176
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 177
    .line 178
    .line 179
    invoke-virtual {v0}, Lzi2;->k0()V

    .line 180
    .line 181
    .line 182
    iget-boolean v13, v0, Lzi2;->T:Z

    .line 183
    .line 184
    if-eqz v13, :cond_3

    .line 185
    .line 186
    invoke-virtual {v0, v2}, Lzi2;->l(Llh2;)V

    .line 187
    .line 188
    .line 189
    goto :goto_1

    .line 190
    :cond_3
    invoke-virtual {v0}, Lzi2;->t0()V

    .line 191
    .line 192
    .line 193
    :goto_1
    sget-object v2, Ly6;->T:Lx31;

    .line 194
    .line 195
    invoke-static {v2, v0, v5}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    sget-object v2, Ly6;->S:Lx31;

    .line 199
    .line 200
    invoke-static {v2, v0, v8}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 204
    .line 205
    .line 206
    move-result-object v2

    .line 207
    sget-object v5, Ly6;->U:Lx31;

    .line 208
    .line 209
    invoke-static {v5, v0, v2}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    invoke-static {v0}, Lfa7;->k(Lzi2;)V

    .line 213
    .line 214
    .line 215
    sget-object v2, Ly6;->R:Lx31;

    .line 216
    .line 217
    invoke-static {v2, v0, v4}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 218
    .line 219
    .line 220
    invoke-static {v3, v6}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 221
    .line 222
    .line 223
    move-result-object v2

    .line 224
    const/4 v4, 0x0

    .line 225
    invoke-static {v2, v4, v12, v9}, Lxt6;->g(Lbb4;FFI)Lbb4;

    .line 226
    .line 227
    .line 228
    move-result-object v15

    .line 229
    invoke-static {v0}, Lyj3;->v(Lzi2;)Lxl0;

    .line 230
    .line 231
    .line 232
    move-result-object v18

    .line 233
    new-instance v2, Lg94;

    .line 234
    .line 235
    const/16 v4, 0x15

    .line 236
    .line 237
    invoke-direct {v2, v1, v11, v4}, Lg94;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 238
    .line 239
    .line 240
    const v1, -0x41defd1c

    .line 241
    .line 242
    .line 243
    invoke-static {v1, v2, v0}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 244
    .line 245
    .line 246
    move-result-object v26

    .line 247
    const/16 v28, 0x0

    .line 248
    .line 249
    const/16 v29, 0x7f6

    .line 250
    .line 251
    const/16 v16, 0x0

    .line 252
    .line 253
    const/16 v17, 0x0

    .line 254
    .line 255
    const/16 v19, 0x0

    .line 256
    .line 257
    const/16 v20, 0x0

    .line 258
    .line 259
    const/16 v21, 0x0

    .line 260
    .line 261
    const/16 v22, 0x0

    .line 262
    .line 263
    const/16 v23, 0x0

    .line 264
    .line 265
    const-wide/16 v24, 0x0

    .line 266
    .line 267
    move-object/from16 v27, v0

    .line 268
    .line 269
    invoke-static/range {v15 .. v29}, Lc74;->a(Lbb4;FLo45;Lxl0;Lsf5;ZLlh2;Llh2;ZJLs21;Lzi2;II)V

    .line 270
    .line 271
    .line 272
    const v1, 0x104000a

    .line 273
    .line 274
    .line 275
    invoke-static {v1, v0}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v13

    .line 279
    invoke-static {v3, v6}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 280
    .line 281
    .line 282
    move-result-object v15

    .line 283
    const v24, 0xc00180

    .line 284
    .line 285
    .line 286
    const/16 v25, 0xf78

    .line 287
    .line 288
    const/16 v16, 0x0

    .line 289
    .line 290
    const/16 v17, 0x0

    .line 291
    .line 292
    const/16 v18, 0x0

    .line 293
    .line 294
    const/16 v19, 0x0

    .line 295
    .line 296
    sget-object v20, Ld74;->i:Ld74;

    .line 297
    .line 298
    move-object/from16 v23, v0

    .line 299
    .line 300
    invoke-static/range {v13 .. v25}, Lnl3;->c(Ljava/lang/String;Llh2;Lbb4;ZFFFLd74;Lo45;Li63;Lzi2;II)V

    .line 301
    .line 302
    .line 303
    invoke-virtual {v0, v9}, Lzi2;->r(Z)V

    .line 304
    .line 305
    .line 306
    goto :goto_2

    .line 307
    :cond_4
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 308
    .line 309
    .line 310
    :goto_2
    return-object v10

    .line 311
    :pswitch_2
    move-object v14, v0

    .line 312
    check-cast v14, Lm61;

    .line 313
    .line 314
    move-object v15, v11

    .line 315
    check-cast v15, Lte4;

    .line 316
    .line 317
    move-object/from16 v0, p1

    .line 318
    .line 319
    check-cast v0, Lzi2;

    .line 320
    .line 321
    move-object/from16 v1, p2

    .line 322
    .line 323
    check-cast v1, Ljava/lang/Integer;

    .line 324
    .line 325
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 326
    .line 327
    .line 328
    move-result v1

    .line 329
    and-int/lit8 v4, v1, 0x3

    .line 330
    .line 331
    if-eq v4, v8, :cond_5

    .line 332
    .line 333
    move v4, v9

    .line 334
    goto :goto_3

    .line 335
    :cond_5
    move v4, v7

    .line 336
    :goto_3
    and-int/2addr v1, v9

    .line 337
    invoke-virtual {v0, v1, v4}, Lzi2;->Y(IZ)Z

    .line 338
    .line 339
    .line 340
    move-result v1

    .line 341
    if-eqz v1, :cond_a

    .line 342
    .line 343
    invoke-static {v3, v6}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 344
    .line 345
    .line 346
    move-result-object v1

    .line 347
    const/4 v4, 0x0

    .line 348
    invoke-static {v1, v4, v12, v9}, Lxt6;->g(Lbb4;FFI)Lbb4;

    .line 349
    .line 350
    .line 351
    move-result-object v1

    .line 352
    invoke-static {v0}, Lbx;->c0(Lzi2;)Leh6;

    .line 353
    .line 354
    .line 355
    move-result-object v4

    .line 356
    const/16 v8, 0xe

    .line 357
    .line 358
    invoke-static {v1, v4, v7, v8}, Lbx;->i0(Lbb4;Leh6;ZI)Lbb4;

    .line 359
    .line 360
    .line 361
    move-result-object v1

    .line 362
    new-instance v4, Lnw;

    .line 363
    .line 364
    new-instance v8, Ll42;

    .line 365
    .line 366
    invoke-direct {v8, v13}, Ll42;-><init>(B)V

    .line 367
    .line 368
    .line 369
    const/high16 v11, 0x41400000    # 12.0f

    .line 370
    .line 371
    invoke-direct {v4, v11, v9, v8}, Lnw;-><init>(FZLl42;)V

    .line 372
    .line 373
    .line 374
    sget-object v8, Ly6;->v:Lz30;

    .line 375
    .line 376
    invoke-static {v4, v8, v0, v5}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 377
    .line 378
    .line 379
    move-result-object v4

    .line 380
    iget-wide v11, v0, Lzi2;->U:J

    .line 381
    .line 382
    invoke-static {v11, v12}, Ljava/lang/Long;->hashCode(J)I

    .line 383
    .line 384
    .line 385
    move-result v5

    .line 386
    invoke-virtual {v0}, Lzi2;->m()Lla5;

    .line 387
    .line 388
    .line 389
    move-result-object v8

    .line 390
    invoke-static {v0, v1}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 391
    .line 392
    .line 393
    move-result-object v1

    .line 394
    sget-object v11, Ls41;->d:Ly6;

    .line 395
    .line 396
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 397
    .line 398
    .line 399
    invoke-virtual {v0}, Lzi2;->k0()V

    .line 400
    .line 401
    .line 402
    iget-boolean v11, v0, Lzi2;->T:Z

    .line 403
    .line 404
    if-eqz v11, :cond_6

    .line 405
    .line 406
    invoke-virtual {v0, v2}, Lzi2;->l(Llh2;)V

    .line 407
    .line 408
    .line 409
    goto :goto_4

    .line 410
    :cond_6
    invoke-virtual {v0}, Lzi2;->t0()V

    .line 411
    .line 412
    .line 413
    :goto_4
    sget-object v2, Ly6;->T:Lx31;

    .line 414
    .line 415
    invoke-static {v2, v0, v4}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 416
    .line 417
    .line 418
    sget-object v2, Ly6;->S:Lx31;

    .line 419
    .line 420
    invoke-static {v2, v0, v8}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 421
    .line 422
    .line 423
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 424
    .line 425
    .line 426
    move-result-object v2

    .line 427
    sget-object v4, Ly6;->U:Lx31;

    .line 428
    .line 429
    invoke-static {v4, v0, v2}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 430
    .line 431
    .line 432
    invoke-static {v0}, Lfa7;->k(Lzi2;)V

    .line 433
    .line 434
    .line 435
    sget-object v2, Ly6;->R:Lx31;

    .line 436
    .line 437
    invoke-static {v2, v0, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 438
    .line 439
    .line 440
    iget-object v1, v14, Lm61;->d:Lz75;

    .line 441
    .line 442
    invoke-virtual {v1}, Lz75;->getValue()Ljava/lang/Object;

    .line 443
    .line 444
    .line 445
    move-result-object v1

    .line 446
    move-object v13, v1

    .line 447
    check-cast v13, Lv61;

    .line 448
    .line 449
    if-nez v13, :cond_8

    .line 450
    .line 451
    const v1, 0xc0d7237

    .line 452
    .line 453
    .line 454
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 455
    .line 456
    .line 457
    iget-object v1, v14, Lm61;->f:Lz75;

    .line 458
    .line 459
    invoke-virtual {v1}, Lz75;->getValue()Ljava/lang/Object;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    check-cast v1, Ljava/lang/Boolean;

    .line 464
    .line 465
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 466
    .line 467
    .line 468
    move-result v1

    .line 469
    if-eqz v1, :cond_7

    .line 470
    .line 471
    const v1, 0x7f0f0364

    .line 472
    .line 473
    .line 474
    goto :goto_5

    .line 475
    :cond_7
    const v1, 0x7f0f0365

    .line 476
    .line 477
    .line 478
    :goto_5
    invoke-static {v1, v0}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 479
    .line 480
    .line 481
    move-result-object v17

    .line 482
    const/16 v37, 0x0

    .line 483
    .line 484
    const v38, 0x3fffe

    .line 485
    .line 486
    .line 487
    const/16 v18, 0x0

    .line 488
    .line 489
    const-wide/16 v19, 0x0

    .line 490
    .line 491
    const-wide/16 v21, 0x0

    .line 492
    .line 493
    const/16 v23, 0x0

    .line 494
    .line 495
    const/16 v24, 0x0

    .line 496
    .line 497
    const-wide/16 v25, 0x0

    .line 498
    .line 499
    const/16 v27, 0x0

    .line 500
    .line 501
    const-wide/16 v28, 0x0

    .line 502
    .line 503
    const/16 v30, 0x0

    .line 504
    .line 505
    const/16 v31, 0x0

    .line 506
    .line 507
    const/16 v32, 0x0

    .line 508
    .line 509
    const/16 v33, 0x0

    .line 510
    .line 511
    const/16 v34, 0x0

    .line 512
    .line 513
    const/16 v36, 0x0

    .line 514
    .line 515
    move-object/from16 v35, v0

    .line 516
    .line 517
    invoke-static/range {v17 .. v38}, Ltf7;->b(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILbi7;Lzi2;III)V

    .line 518
    .line 519
    .line 520
    invoke-virtual {v0, v7}, Lzi2;->r(Z)V

    .line 521
    .line 522
    .line 523
    goto :goto_7

    .line 524
    :cond_8
    const v1, 0xc10502a

    .line 525
    .line 526
    .line 527
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 528
    .line 529
    .line 530
    invoke-virtual {v13}, Lv61;->c()Ljava/util/ArrayList;

    .line 531
    .line 532
    .line 533
    move-result-object v1

    .line 534
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 535
    .line 536
    .line 537
    move-result-object v1

    .line 538
    :goto_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 539
    .line 540
    .line 541
    move-result v2

    .line 542
    if-eqz v2, :cond_9

    .line 543
    .line 544
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 545
    .line 546
    .line 547
    move-result-object v2

    .line 548
    move-object v12, v2

    .line 549
    check-cast v12, Lx61;

    .line 550
    .line 551
    const v2, -0x420dffa1

    .line 552
    .line 553
    .line 554
    invoke-virtual {v0, v2, v12}, Lzi2;->f0(ILjava/lang/Object;)V

    .line 555
    .line 556
    .line 557
    invoke-static {v3, v6}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 558
    .line 559
    .line 560
    move-result-object v17

    .line 561
    invoke-static {v12}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 562
    .line 563
    .line 564
    move-result-object v21

    .line 565
    new-instance v11, Lsm;

    .line 566
    .line 567
    const/16 v16, 0x4

    .line 568
    .line 569
    invoke-direct/range {v11 .. v16}, Lsm;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 570
    .line 571
    .line 572
    const v2, 0x483beff3

    .line 573
    .line 574
    .line 575
    invoke-static {v2, v11, v0}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 576
    .line 577
    .line 578
    move-result-object v2

    .line 579
    invoke-static {v2}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 580
    .line 581
    .line 582
    move-result-object v20

    .line 583
    const/16 v23, 0xc06

    .line 584
    .line 585
    const/16 v24, 0x6

    .line 586
    .line 587
    const/16 v18, 0x0

    .line 588
    .line 589
    const/16 v19, 0x0

    .line 590
    .line 591
    move-object/from16 v22, v0

    .line 592
    .line 593
    invoke-static/range {v17 .. v24}, Lb14;->d(Lbb4;Ljava/lang/String;Ls21;Ljava/util/List;Ljava/util/List;Lzi2;II)V

    .line 594
    .line 595
    .line 596
    invoke-virtual {v0, v7}, Lzi2;->r(Z)V

    .line 597
    .line 598
    .line 599
    goto :goto_6

    .line 600
    :cond_9
    invoke-virtual {v0, v7}, Lzi2;->r(Z)V

    .line 601
    .line 602
    .line 603
    :goto_7
    invoke-virtual {v0, v9}, Lzi2;->r(Z)V

    .line 604
    .line 605
    .line 606
    goto :goto_8

    .line 607
    :cond_a
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 608
    .line 609
    .line 610
    :goto_8
    return-object v10

    .line 611
    :pswitch_3
    check-cast v0, Lii3;

    .line 612
    .line 613
    check-cast v11, Ls21;

    .line 614
    .line 615
    move-object/from16 v1, p1

    .line 616
    .line 617
    check-cast v1, Lzi2;

    .line 618
    .line 619
    move-object/from16 v2, p2

    .line 620
    .line 621
    check-cast v2, Ljava/lang/Integer;

    .line 622
    .line 623
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 624
    .line 625
    .line 626
    move-result v2

    .line 627
    and-int/lit8 v3, v2, 0x3

    .line 628
    .line 629
    if-eq v3, v8, :cond_b

    .line 630
    .line 631
    move v7, v9

    .line 632
    :cond_b
    and-int/2addr v2, v9

    .line 633
    invoke-virtual {v1, v2, v7}, Lzi2;->Y(IZ)Z

    .line 634
    .line 635
    .line 636
    move-result v2

    .line 637
    if-eqz v2, :cond_c

    .line 638
    .line 639
    new-instance v15, Lnw;

    .line 640
    .line 641
    new-instance v2, Ll42;

    .line 642
    .line 643
    invoke-direct {v2, v13}, Ll42;-><init>(B)V

    .line 644
    .line 645
    .line 646
    const/high16 v3, 0x41000000    # 8.0f

    .line 647
    .line 648
    invoke-direct {v15, v3, v9, v2}, Lnw;-><init>(FZLl42;)V

    .line 649
    .line 650
    .line 651
    new-instance v2, Lnw;

    .line 652
    .line 653
    new-instance v3, Ll42;

    .line 654
    .line 655
    invoke-direct {v3, v13}, Ll42;-><init>(B)V

    .line 656
    .line 657
    .line 658
    invoke-direct {v2, v12, v9, v3}, Lnw;-><init>(FZLl42;)V

    .line 659
    .line 660
    .line 661
    new-instance v3, Lg94;

    .line 662
    .line 663
    const/4 v4, 0x4

    .line 664
    invoke-direct {v3, v0, v11, v4}, Lg94;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 665
    .line 666
    .line 667
    const v0, 0x3472a0d7

    .line 668
    .line 669
    .line 670
    invoke-static {v0, v3, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 671
    .line 672
    .line 673
    move-result-object v20

    .line 674
    const/high16 v22, 0x180000

    .line 675
    .line 676
    const/16 v23, 0x39

    .line 677
    .line 678
    const/4 v14, 0x0

    .line 679
    const/16 v17, 0x0

    .line 680
    .line 681
    const/16 v18, 0x0

    .line 682
    .line 683
    const/16 v19, 0x0

    .line 684
    .line 685
    move-object/from16 v21, v1

    .line 686
    .line 687
    move-object/from16 v16, v2

    .line 688
    .line 689
    invoke-static/range {v14 .. v23}, Lbw;->k(Lbb4;Lmw;Low;La40;IILs21;Lzi2;II)V

    .line 690
    .line 691
    .line 692
    goto :goto_9

    .line 693
    :cond_c
    move-object/from16 v21, v1

    .line 694
    .line 695
    invoke-virtual/range {v21 .. v21}, Lzi2;->b0()V

    .line 696
    .line 697
    .line 698
    :goto_9
    return-object v10

    .line 699
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
