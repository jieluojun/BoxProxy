.class public final Laf6;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Z

.field public final c:Z

.field public final d:Z

.field public final e:Z

.field public final f:Z

.field public final g:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;ZZZZZZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Laf6;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-boolean p2, p0, Laf6;->b:Z

    .line 7
    .line 8
    iput-boolean p3, p0, Laf6;->c:Z

    .line 9
    .line 10
    iput-boolean p4, p0, Laf6;->d:Z

    .line 11
    .line 12
    iput-boolean p5, p0, Laf6;->e:Z

    .line 13
    .line 14
    iput-boolean p6, p0, Laf6;->f:Z

    .line 15
    .line 16
    iput-boolean p7, p0, Laf6;->g:Z

    .line 17
    .line 18
    return-void
.end method
