.class public final Lae;
.super Lvx5;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final b:Landroid/graphics/RenderEffect;


# direct methods
.method public constructor <init>(Landroid/graphics/RenderEffect;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae;->b:Landroid/graphics/RenderEffect;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final b()Landroid/graphics/RenderEffect;
    .locals 0

    .line 1
    iget-object p0, p0, Lae;->b:Landroid/graphics/RenderEffect;

    .line 2
    .line 3
    return-object p0
.end method
