.class public abstract Lao6;
.super Lu02;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Les2;
.implements Lf61;


# instance fields
.field public final synthetic l:Lg61;

.field public final m:Landroid/graphics/Matrix;


# direct methods
.method public constructor <init>(Lv02;Lg61;Landroid/graphics/Matrix;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lx02;-><init>(Lv02;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lao6;->l:Lg61;

    .line 5
    .line 6
    iput-object p3, p0, Lao6;->m:Landroid/graphics/Matrix;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final e()Loe4;
    .locals 0

    .line 1
    iget-object p0, p0, Lao6;->l:Lg61;

    .line 2
    .line 3
    iget-object p0, p0, Lg61;->a:Loe4;

    .line 4
    .line 5
    return-object p0
.end method

.method public final h()Landroid/graphics/Matrix;
    .locals 0

    .line 1
    iget-object p0, p0, Lao6;->m:Landroid/graphics/Matrix;

    .line 2
    .line 3
    return-object p0
.end method

.method public final i()Loe4;
    .locals 0

    .line 1
    iget-object p0, p0, Lao6;->l:Lg61;

    .line 2
    .line 3
    iget-object p0, p0, Lg61;->c:Loe4;

    .line 4
    .line 5
    return-object p0
.end method

.method public final j()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lao6;->l:Lg61;

    .line 2
    .line 3
    iget-object p0, p0, Lg61;->b:Ljava/lang/String;

    .line 4
    .line 5
    return-object p0
.end method

.method public final n()Loe4;
    .locals 0

    .line 1
    iget-object p0, p0, Lao6;->l:Lg61;

    .line 2
    .line 3
    iget-object p0, p0, Lg61;->d:Loe4;

    .line 4
    .line 5
    return-object p0
.end method

.method public final p()Loe4;
    .locals 0

    .line 1
    iget-object p0, p0, Lao6;->l:Lg61;

    .line 2
    .line 3
    iget-object p0, p0, Lg61;->e:Loe4;

    .line 4
    .line 5
    return-object p0
.end method
