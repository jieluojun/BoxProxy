.class public abstract Laz;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:Lux1;

.field public static final b:Lux1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Llv;

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    invoke-direct {v0, v1}, Llv;-><init>(B)V

    .line 5
    .line 6
    .line 7
    new-instance v1, Lux1;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-direct {v1, v0, v2}, Lux1;-><init>(Llh2;B)V

    .line 11
    .line 12
    .line 13
    sput-object v1, Laz;->a:Lux1;

    .line 14
    .line 15
    sget-object v0, Lzy;->i:Lzy;

    .line 16
    .line 17
    new-instance v1, Lux1;

    .line 18
    .line 19
    invoke-direct {v1, v0, v2}, Lux1;-><init>(Llh2;B)V

    .line 20
    .line 21
    .line 22
    sput-object v1, Laz;->b:Lux1;

    .line 23
    .line 24
    return-void
.end method
