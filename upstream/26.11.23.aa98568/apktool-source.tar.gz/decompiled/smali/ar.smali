.class public Lar;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lou0;
.implements Lvr;
.implements Lsx6;
.implements Lgm0;
.implements Lov5;
.implements Luy6;


# static fields
.field public static final k:[I

.field public static final l:Lar;


# instance fields
.field public final synthetic h:B

.field public i:Ljava/lang/Object;

.field public j:Ljava/lang/Object;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 4

    .line 1
    const v0, 0x101013b

    .line 2
    .line 3
    .line 4
    const v1, 0x101013c

    .line 5
    .line 6
    .line 7
    filled-new-array {v0, v1}, [I

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lar;->k:[I

    .line 12
    .line 13
    new-instance v0, Lar;

    .line 14
    .line 15
    new-instance v1, Laa3;

    .line 16
    .line 17
    const/16 v2, 0x1b

    .line 18
    .line 19
    invoke-direct {v1, v2}, Laa3;-><init>(B)V

    .line 20
    .line 21
    .line 22
    new-instance v2, Laa3;

    .line 23
    .line 24
    const/16 v3, 0x1c

    .line 25
    .line 26
    invoke-direct {v2, v3}, Laa3;-><init>(B)V

    .line 27
    .line 28
    .line 29
    const/4 v3, 0x1

    .line 30
    invoke-direct {v0, v1, v2, v3}, Lar;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 31
    .line 32
    .line 33
    sput-object v0, Lar;->l:Lar;

    .line 34
    .line 35
    return-void
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method

.method public constructor <init>(B)V
    .locals 3

    .line 1
    iput-byte p1, p0, Lar;->h:B

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    sparse-switch p1, :sswitch_data_0

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance p1, Ljava/util/ArrayList;

    .line 11
    .line 12
    const/16 v0, 0x80

    .line 13
    .line 14
    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    .line 18
    .line 19
    new-instance p1, Ljava/util/concurrent/locks/ReentrantLock;

    .line 20
    .line 21
    invoke-direct {p1}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 25
    .line 26
    return-void

    .line 27
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    new-instance p1, Lx53;

    .line 31
    .line 32
    const/16 v0, 0xa

    .line 33
    .line 34
    invoke-direct {p1, v0}, Lx53;-><init>(B)V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 38
    .line 39
    new-instance p1, Lx53;

    .line 40
    .line 41
    invoke-direct {p1, v0}, Lx53;-><init>(B)V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    .line 45
    .line 46
    return-void

    .line 47
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 48
    .line 49
    .line 50
    new-instance p1, Ljava/util/ArrayList;

    .line 51
    .line 52
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 53
    .line 54
    .line 55
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 56
    .line 57
    const/4 p1, 0x5

    .line 58
    new-array v1, p1, [F

    .line 59
    .line 60
    :goto_0
    if-ge v0, p1, :cond_0

    .line 61
    .line 62
    const/high16 v2, 0x7fc00000    # Float.NaN

    .line 63
    .line 64
    aput v2, v1, v0

    .line 65
    .line 66
    add-int/lit8 v0, v0, 0x1

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_0
    iput-object v1, p0, Lar;->j:Ljava/lang/Object;

    .line 70
    .line 71
    return-void

    .line 72
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 73
    .line 74
    .line 75
    new-instance p1, Lzw;

    .line 76
    .line 77
    invoke-direct {p1, v0}, Lis6;-><init>(I)V

    .line 78
    .line 79
    .line 80
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 81
    .line 82
    new-instance p1, Lo40;

    .line 83
    .line 84
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 85
    .line 86
    invoke-direct {p1, v0, v0, v1}, Lo40;-><init>(IILandroid/graphics/Bitmap$Config;)V

    .line 87
    .line 88
    .line 89
    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    .line 90
    .line 91
    return-void

    .line 92
    nop

    .line 93
    :sswitch_data_0
    .sparse-switch
        0xd -> :sswitch_2
        0x19 -> :sswitch_1
        0x1c -> :sswitch_0
    .end sparse-switch
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public synthetic constructor <init>(BZ)V
    .locals 0

    .line 153
    iput-byte p1, p0, Lar;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x7

    iput-byte v0, p0, Lar;->h:B

    .line 96
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 97
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 98
    const-string v0, "boxapp_settings"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/util/SparseIntArray;Landroid/util/SparseIntArray;)V
    .locals 2

    const/16 v0, 0x1d

    iput-byte v0, p0, Lar;->h:B

    .line 117
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 118
    invoke-virtual {p1}, Landroid/util/SparseIntArray;->size()I

    move-result v0

    invoke-virtual {p2}, Landroid/util/SparseIntArray;->size()I

    move-result v1

    if-ne v0, v1, :cond_0

    invoke-virtual {p1}, Landroid/util/SparseIntArray;->size()I

    move-result v0

    const v1, 0xffff

    if-gt v0, v1, :cond_0

    .line 119
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 120
    iput-object p2, p0, Lar;->j:Ljava/lang/Object;

    return-void

    .line 121
    :cond_0
    new-instance p0, Ljava/lang/Exception;

    const-string p1, "invalid startIndexes or endIndexes size"

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public constructor <init>(Landroid/widget/EditText;B)V
    .locals 3

    iput-byte p2, p0, Lar;->h:B

    packed-switch p2, :pswitch_data_0

    .line 122
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 123
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 124
    new-instance p2, Lar;

    const/16 v0, 0x1b

    invoke-direct {p2, p1, v0}, Lar;-><init>(Landroid/widget/EditText;B)V

    iput-object p2, p0, Lar;->j:Ljava/lang/Object;

    return-void

    .line 125
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 126
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 127
    new-instance p2, Ld22;

    invoke-direct {p2, p1}, Ld22;-><init>(Landroid/widget/EditText;)V

    iput-object p2, p0, Lar;->j:Ljava/lang/Object;

    .line 128
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 129
    sget-object p0, Ls12;->b:Ls12;

    if-nez p0, :cond_1

    .line 130
    sget-object p0, Ls12;->a:Ljava/lang/Object;

    monitor-enter p0

    .line 131
    :try_start_0
    sget-object p2, Ls12;->b:Ls12;

    if-nez p2, :cond_0

    .line 132
    new-instance p2, Ls12;

    .line 133
    invoke-direct {p2}, Landroid/text/Editable$Factory;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 134
    :try_start_1
    const-string v0, "android.text.DynamicLayout$ChangeWatcher"

    .line 135
    const-class v1, Ls12;

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v0, v2, v1}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    sput-object v0, Ls12;->c:Ljava/lang/Class;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 136
    :catchall_0
    :try_start_2
    sput-object p2, Ls12;->b:Ls12;

    .line 137
    :cond_0
    monitor-exit p0

    goto :goto_1

    :goto_0
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw p1

    :catchall_1
    move-exception p1

    goto :goto_0

    .line 138
    :cond_1
    :goto_1
    sget-object p0, Ls12;->b:Ls12;

    .line 139
    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setEditableFactory(Landroid/text/Editable$Factory;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x1b
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Lar;)V
    .locals 10

    const/16 v0, 0x14

    iput-byte v0, p0, Lar;->h:B

    .line 99
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 100
    new-instance v0, Lve4;

    const/16 v1, 0x10

    new-array v2, v1, [Lro0;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v2}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 101
    iput-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 102
    new-instance v0, Lve4;

    new-array v1, v1, [Lro0;

    invoke-direct {v0, v3, v1}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 103
    iput-object v0, p0, Lar;->j:Ljava/lang/Object;

    if-eqz p1, :cond_0

    .line 104
    iget-object p1, p1, Lar;->i:Ljava/lang/Object;

    check-cast p1, Lve4;

    if-eqz p1, :cond_0

    .line 105
    iget-object v0, p1, Lve4;->h:[Ljava/lang/Object;

    .line 106
    iget p1, p1, Lve4;->j:I

    :goto_0
    if-ge v3, p1, :cond_0

    .line 107
    aget-object v1, v0, v3

    check-cast v1, Lro0;

    .line 108
    iget-object v2, p0, Lar;->i:Ljava/lang/Object;

    check-cast v2, Lve4;

    .line 109
    new-instance v4, Lro0;

    .line 110
    iget v6, v1, Lro0;->a:I

    .line 111
    iget v7, v1, Lro0;->b:I

    .line 112
    iget v8, v1, Lro0;->c:I

    .line 113
    iget v9, v1, Lro0;->d:I

    .line 114
    iget-boolean v5, v1, Lro0;->e:Z

    .line 115
    invoke-direct/range {v4 .. v9}, Lro0;-><init>(ZIIII)V

    .line 116
    invoke-virtual {v2, v4}, Lve4;->b(Ljava/lang/Object;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 93
    iput-byte p2, p0, Lar;->h:B

    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 94
    iput-byte p3, p0, Lar;->h:B

    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    iput-object p2, p0, Lar;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ZB)V
    .locals 0

    .line 95
    iput-byte p3, p0, Lar;->h:B

    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/util/Map;)V
    .locals 2

    const/16 v0, 0xc

    iput-byte v0, p0, Lar;->h:B

    .line 143
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 144
    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 145
    sget-object p1, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    const/4 p1, 0x0

    .line 146
    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    goto :goto_0

    .line 147
    :cond_0
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0, p1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iput-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 148
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Collection;->stream()Ljava/util/stream/Stream;

    move-result-object p1

    new-instance v0, Lj10;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lj10;-><init>(B)V

    .line 149
    invoke-interface {p1, v0}, Ljava/util/stream/Stream;->map(Ljava/util/function/Function;)Ljava/util/stream/Stream;

    move-result-object p1

    .line 150
    invoke-static {}, Ljava/util/Collections;->reverseOrder()Ljava/util/Comparator;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/stream/Stream;->sorted(Ljava/util/Comparator;)Ljava/util/stream/Stream;

    move-result-object p1

    new-instance v0, Lt10;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lt10;-><init>(B)V

    .line 151
    invoke-interface {p1, v0}, Ljava/util/stream/Stream;->toArray(Ljava/util/function/IntFunction;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    .line 152
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "^(("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, ")|("

    invoke-static {v1, p1}, Ljava/lang/String;->join(Ljava/lang/CharSequence;[Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "))($|\\.)"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object p1

    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    :goto_0
    return-void
.end method

.method public constructor <init>(Lpq;Lq21;)V
    .locals 1

    const/4 v0, 0x4

    iput-byte v0, p0, Lar;->h:B

    .line 157
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    .line 158
    iput-object p2, p0, Lar;->i:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lrx0;)V
    .locals 1

    const/16 v0, 0x1a

    iput-byte v0, p0, Lar;->h:B

    .line 140
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 141
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 142
    new-instance v0, Lrg3;

    invoke-direct {v0, p1}, Lrg3;-><init>(Lrx0;)V

    iput-object v0, p0, Lar;->j:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lxr;)V
    .locals 1

    const/4 v0, 0x6

    iput-byte v0, p0, Lar;->h:B

    .line 154
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 155
    iput-object p1, p0, Lar;->j:Ljava/lang/Object;

    .line 156
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    return-void
.end method

.method public static C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V
    .locals 0

    .line 1
    if-eq p2, p3, :cond_0

    .line 2
    .line 3
    invoke-interface {p0, p1, p3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 4
    .line 5
    .line 6
    :cond_0
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
.end method

.method public static D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-static {p2, p3}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    if-nez p2, :cond_0

    .line 6
    .line 7
    invoke-interface {p0, p1, p3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 8
    .line 9
    .line 10
    :cond_0
    return-void
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
.end method

.method public static I(Lrx0;Lhk1;Lic1;Ltz1;Ljg3;)Z
    .locals 0

    .line 1
    iget-object p1, p1, Lhk1;->d:Lnp0;

    .line 2
    .line 3
    invoke-virtual {p1}, Lnp0;->a()Lnp0;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget p1, p1, Lnp0;->b:I

    .line 8
    .line 9
    invoke-virtual {p2, p1}, Lic1;->o(I)Lcd1;

    .line 10
    .line 11
    .line 12
    move-result-object p2

    .line 13
    iget p2, p2, Lcd1;->j:I

    .line 14
    .line 15
    invoke-virtual {p0, p1, p2}, Lrx0;->l0(II)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, Lrx0;->getLineSeparator()Lqq3;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iget-object p1, p1, Lqq3;->h:Ljava/lang/String;

    .line 23
    .line 24
    const/4 p2, 0x1

    .line 25
    invoke-virtual {p0, p1, p2}, Lrx0;->v(Ljava/lang/CharSequence;Z)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, Lrx0;->E()V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p4, p2}, Ltz1;->a(Z)Z

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    if-nez p0, :cond_0

    .line 36
    .line 37
    invoke-virtual {p3, p2}, Ltz1;->a(Z)Z

    .line 38
    .line 39
    .line 40
    move-result p0

    .line 41
    if-nez p0, :cond_0

    .line 42
    .line 43
    const/4 p0, 0x0

    .line 44
    return p0

    .line 45
    :cond_0
    return p2
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
.end method

.method public static o(Ljava/lang/Class;)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Class;->getModifiers()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isInterface(I)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    const-string v0, "Interfaces can\'t be instantiated! Register an InstanceCreator or a TypeAdapter for this type. Interface name: "

    .line 16
    .line 17
    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    :cond_0
    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    new-instance v0, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    const-string v1, "Abstract classes can\'t be instantiated! Adjust the R8 configuration or register an InstanceCreator or a TypeAdapter for this type. Class name: "

    .line 31
    .line 32
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    const-string p0, "\nSee https://github.com/google/gson/blob/main/Troubleshooting.md#r8-abstract-class"

    .line 43
    .line 44
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    return-object p0

    .line 52
    :cond_1
    const/4 p0, 0x0

    .line 53
    return-object p0
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method


# virtual methods
.method public final A(Lq6;Lq24;)Z
    .locals 3

    .line 1
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lpq;

    .line 4
    .line 5
    iget-object v0, v0, Lpq;->G:Landroid/view/ViewGroup;

    .line 6
    .line 7
    sget-object v1, Lox7;->a:Ljava/util/WeakHashMap;

    .line 8
    .line 9
    invoke-virtual {v0}, Landroid/view/View;->requestApplyInsets()V

    .line 10
    .line 11
    .line 12
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p0, Lq21;

    .line 15
    .line 16
    iget-object v0, p0, Lq21;->i:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Landroid/view/ActionMode$Callback;

    .line 19
    .line 20
    invoke-virtual {p0, p1}, Lq21;->m(Lq6;)Li57;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iget-object v1, p0, Lq21;->l:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v1, Lis6;

    .line 27
    .line 28
    invoke-virtual {v1, p2}, Lis6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, Landroid/view/Menu;

    .line 33
    .line 34
    if-nez v2, :cond_0

    .line 35
    .line 36
    new-instance v2, Lx34;

    .line 37
    .line 38
    iget-object p0, p0, Lq21;->j:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast p0, Landroid/content/Context;

    .line 41
    .line 42
    invoke-direct {v2, p0, p2}, Lx34;-><init>(Landroid/content/Context;Lq24;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1, p2, v2}, Lis6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    :cond_0
    invoke-interface {v0, p1, v2}, Landroid/view/ActionMode$Callback;->onPrepareActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z

    .line 49
    .line 50
    .line 51
    move-result p0

    .line 52
    return p0
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final B(Luf2;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Luy5;

    .line 4
    .line 5
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Lut5;

    .line 8
    .line 9
    iget v1, p1, Luf2;->b:I

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    iget-object p1, p1, Luf2;->a:Landroid/graphics/Typeface;

    .line 14
    .line 15
    new-instance v1, Lk6;

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-direct {v1, p0, p1, v3, v2}, Lk6;-><init>(Ljava/lang/Object;Ljava/lang/Object;ZB)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0, v1}, Luy5;->execute(Ljava/lang/Runnable;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_0
    new-instance p1, Lal0;

    .line 27
    .line 28
    invoke-direct {p1, p0, v1}, Lal0;-><init>(Lut5;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, p1}, Luy5;->execute(Ljava/lang/Runnable;)V

    .line 32
    .line 33
    .line 34
    return-void
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final E(Landroid/graphics/Bitmap;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lzw;

    .line 4
    .line 5
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Lo40;

    .line 8
    .line 9
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->isRecycled()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-nez v1, :cond_1

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    if-eqz v1, :cond_1

    .line 20
    .line 21
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    iput v2, p0, Lo40;->a:I

    .line 26
    .line 27
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    iput v2, p0, Lo40;->b:I

    .line 32
    .line 33
    iput-object v1, p0, Lo40;->c:Landroid/graphics/Bitmap$Config;

    .line 34
    .line 35
    invoke-virtual {v0, p0}, Lis6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Lrw;

    .line 40
    .line 41
    if-nez v1, :cond_0

    .line 42
    .line 43
    new-instance v1, Lrw;

    .line 44
    .line 45
    invoke-direct {v1}, Lrw;-><init>()V

    .line 46
    .line 47
    .line 48
    new-instance v2, Lo40;

    .line 49
    .line 50
    iget v3, p0, Lo40;->a:I

    .line 51
    .line 52
    iget v4, p0, Lo40;->b:I

    .line 53
    .line 54
    iget-object p0, p0, Lo40;->c:Landroid/graphics/Bitmap$Config;

    .line 55
    .line 56
    invoke-direct {v2, v3, v4, p0}, Lo40;-><init>(IILandroid/graphics/Bitmap$Config;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0, v2, v1}, Lis6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    :cond_0
    invoke-virtual {v1, p1}, Lrw;->contains(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result p0

    .line 66
    if-nez p0, :cond_1

    .line 67
    .line 68
    invoke-virtual {v1, p1}, Lrw;->addLast(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :cond_1
    return-void
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public final F()Landroid/view/inputmethod/InputMethodManager;
    .locals 2

    .line 1
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Landroid/view/View;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, "input_method"

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 25
    .line 26
    iput-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 27
    .line 28
    :cond_0
    return-object v0
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final G(Lvv;Lvv;)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p0, Landroid/content/SharedPreferences;

    .line 10
    .line 11
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    iget-object v0, p1, Lvv;->a:Lss7;

    .line 19
    .line 20
    iget-object v0, v0, Lss7;->h:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v1, p2, Lvv;->a:Lss7;

    .line 23
    .line 24
    iget-object v1, v1, Lss7;->h:Ljava/lang/String;

    .line 25
    .line 26
    const-string v2, "ui_mode"

    .line 27
    .line 28
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object v0, p1, Lvv;->b:Los;

    .line 32
    .line 33
    iget-object v0, v0, Los;->h:Ljava/lang/String;

    .line 34
    .line 35
    iget-object v1, p2, Lvv;->b:Los;

    .line 36
    .line 37
    iget-object v1, v1, Los;->h:Ljava/lang/String;

    .line 38
    .line 39
    const-string v2, "app_language"

    .line 40
    .line 41
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p1, Lvv;->c:Liy2;

    .line 45
    .line 46
    iget-object v0, v0, Liy2;->h:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v1, p2, Lvv;->c:Liy2;

    .line 49
    .line 50
    iget-object v1, v1, Liy2;->h:Ljava/lang/String;

    .line 51
    .line 52
    const-string v2, "home_panel_entry_mode"

    .line 53
    .line 54
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    iget-boolean v0, p1, Lvv;->d:Z

    .line 58
    .line 59
    iget-boolean v1, p2, Lvv;->d:Z

    .line 60
    .line 61
    const-string v2, "auto_start_enabled"

    .line 62
    .line 63
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 64
    .line 65
    .line 66
    iget-boolean v0, p1, Lvv;->e:Z

    .line 67
    .line 68
    iget-boolean v1, p2, Lvv;->e:Z

    .line 69
    .line 70
    const-string v2, "accelerated_download_enabled"

    .line 71
    .line 72
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 73
    .line 74
    .line 75
    iget-object v0, p1, Lvv;->f:Ljava/lang/String;

    .line 76
    .line 77
    iget-object v1, p2, Lvv;->f:Ljava/lang/String;

    .line 78
    .line 79
    const-string v2, "accelerated_download_prefix"

    .line 80
    .line 81
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    iget-boolean v0, p1, Lvv;->g:Z

    .line 85
    .line 86
    iget-boolean v1, p2, Lvv;->g:Z

    .line 87
    .line 88
    const-string v2, "github_token_enabled"

    .line 89
    .line 90
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 91
    .line 92
    .line 93
    iget-object v0, p1, Lvv;->h:Ljava/lang/String;

    .line 94
    .line 95
    iget-object v1, p2, Lvv;->h:Ljava/lang/String;

    .line 96
    .line 97
    const-string v2, "github_token"

    .line 98
    .line 99
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    iget-boolean v0, p1, Lvv;->i:Z

    .line 103
    .line 104
    iget-boolean v1, p2, Lvv;->i:Z

    .line 105
    .line 106
    const-string v2, "notifications_enabled"

    .line 107
    .line 108
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 109
    .line 110
    .line 111
    iget-object v0, p1, Lvv;->j:Lyt4;

    .line 112
    .line 113
    iget-object v0, v0, Lyt4;->h:Ljava/lang/String;

    .line 114
    .line 115
    iget-object v1, p2, Lvv;->j:Lyt4;

    .line 116
    .line 117
    iget-object v1, v1, Lyt4;->h:Ljava/lang/String;

    .line 118
    .line 119
    const-string v2, "tile_long_click_target"

    .line 120
    .line 121
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    iget v0, p1, Lvv;->k:I

    .line 125
    .line 126
    iget v1, p2, Lvv;->k:I

    .line 127
    .line 128
    if-eq v0, v1, :cond_0

    .line 129
    .line 130
    const-string v0, "notification_refresh_interval_seconds"

    .line 131
    .line 132
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 133
    .line 134
    .line 135
    :cond_0
    iget-object v0, p1, Lvv;->l:Ljava/lang/String;

    .line 136
    .line 137
    iget-object v1, p2, Lvv;->l:Ljava/lang/String;

    .line 138
    .line 139
    const-string v2, "notification_title"

    .line 140
    .line 141
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    iget-object v0, p1, Lvv;->m:Ljava/lang/String;

    .line 145
    .line 146
    iget-object v1, p2, Lvv;->m:Ljava/lang/String;

    .line 147
    .line 148
    const-string v2, "notification_content"

    .line 149
    .line 150
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    iget-object v0, p1, Lvv;->n:Lyt4;

    .line 154
    .line 155
    iget-object v0, v0, Lyt4;->h:Ljava/lang/String;

    .line 156
    .line 157
    iget-object v1, p2, Lvv;->n:Lyt4;

    .line 158
    .line 159
    iget-object v1, v1, Lyt4;->h:Ljava/lang/String;

    .line 160
    .line 161
    const-string v2, "notification_click_target"

    .line 162
    .line 163
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    iget-boolean v0, p1, Lvv;->o:Z

    .line 167
    .line 168
    iget-boolean v1, p2, Lvv;->o:Z

    .line 169
    .line 170
    const-string v2, "notification_action_reload"

    .line 171
    .line 172
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 173
    .line 174
    .line 175
    iget-object v0, p1, Lvv;->p:Ljava/lang/String;

    .line 176
    .line 177
    iget-object v1, p2, Lvv;->p:Ljava/lang/String;

    .line 178
    .line 179
    const-string v2, "notification_action_reload_title"

    .line 180
    .line 181
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    iget-object v0, p1, Lvv;->q:Lxt4;

    .line 185
    .line 186
    iget-object v0, v0, Lxt4;->h:Ljava/lang/String;

    .line 187
    .line 188
    iget-object v1, p2, Lvv;->q:Lxt4;

    .line 189
    .line 190
    iget-object v1, v1, Lxt4;->h:Ljava/lang/String;

    .line 191
    .line 192
    const-string v2, "notification_action_reload_target"

    .line 193
    .line 194
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    iget-boolean v0, p1, Lvv;->r:Z

    .line 198
    .line 199
    iget-boolean v1, p2, Lvv;->r:Z

    .line 200
    .line 201
    const-string v2, "notification_action_stop"

    .line 202
    .line 203
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 204
    .line 205
    .line 206
    iget-object v0, p1, Lvv;->s:Ljava/lang/String;

    .line 207
    .line 208
    iget-object v1, p2, Lvv;->s:Ljava/lang/String;

    .line 209
    .line 210
    const-string v2, "notification_action_stop_title"

    .line 211
    .line 212
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 213
    .line 214
    .line 215
    iget-object v0, p1, Lvv;->t:Lxt4;

    .line 216
    .line 217
    iget-object v0, v0, Lxt4;->h:Ljava/lang/String;

    .line 218
    .line 219
    iget-object v1, p2, Lvv;->t:Lxt4;

    .line 220
    .line 221
    iget-object v1, v1, Lxt4;->h:Ljava/lang/String;

    .line 222
    .line 223
    const-string v2, "notification_action_stop_target"

    .line 224
    .line 225
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 226
    .line 227
    .line 228
    iget-boolean v0, p1, Lvv;->u:Z

    .line 229
    .line 230
    iget-boolean v1, p2, Lvv;->u:Z

    .line 231
    .line 232
    const-string v2, "notification_action_restart"

    .line 233
    .line 234
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 235
    .line 236
    .line 237
    iget-object v0, p1, Lvv;->v:Ljava/lang/String;

    .line 238
    .line 239
    iget-object v1, p2, Lvv;->v:Ljava/lang/String;

    .line 240
    .line 241
    const-string v2, "notification_action_restart_title"

    .line 242
    .line 243
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    iget-object v0, p1, Lvv;->w:Lxt4;

    .line 247
    .line 248
    iget-object v0, v0, Lxt4;->h:Ljava/lang/String;

    .line 249
    .line 250
    iget-object v1, p2, Lvv;->w:Lxt4;

    .line 251
    .line 252
    iget-object v1, v1, Lxt4;->h:Ljava/lang/String;

    .line 253
    .line 254
    const-string v2, "notification_action_restart_target"

    .line 255
    .line 256
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    iget-boolean v0, p1, Lvv;->x:Z

    .line 260
    .line 261
    iget-boolean v1, p2, Lvv;->x:Z

    .line 262
    .line 263
    const-string v2, "open_panel_on_launch"

    .line 264
    .line 265
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 266
    .line 267
    .line 268
    iget-boolean v0, p1, Lvv;->y:Z

    .line 269
    .line 270
    iget-boolean v1, p2, Lvv;->y:Z

    .line 271
    .line 272
    const-string v2, "show_proxy_selector_bottom_bar_item"

    .line 273
    .line 274
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 275
    .line 276
    .line 277
    iget-object v0, p1, Lvv;->z:Lvi7;

    .line 278
    .line 279
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 280
    .line 281
    .line 282
    move-result v0

    .line 283
    iget-object v1, p2, Lvv;->z:Lvi7;

    .line 284
    .line 285
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 286
    .line 287
    .line 288
    move-result v1

    .line 289
    if-eq v0, v1, :cond_1

    .line 290
    .line 291
    const-string v0, "theme_mode"

    .line 292
    .line 293
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 294
    .line 295
    .line 296
    :cond_1
    iget-boolean v0, p1, Lvv;->A:Z

    .line 297
    .line 298
    iget-boolean v1, p2, Lvv;->A:Z

    .line 299
    .line 300
    const-string v2, "pure_black_dark_theme"

    .line 301
    .line 302
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 303
    .line 304
    .line 305
    iget-boolean v0, p1, Lvv;->B:Z

    .line 306
    .line 307
    iget-boolean v1, p2, Lvv;->B:Z

    .line 308
    .line 309
    const-string v2, "miuix_monet_enabled"

    .line 310
    .line 311
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 312
    .line 313
    .line 314
    iget v0, p1, Lvv;->C:I

    .line 315
    .line 316
    iget v1, p2, Lvv;->C:I

    .line 317
    .line 318
    if-eq v0, v1, :cond_2

    .line 319
    .line 320
    const-string v0, "accent_color"

    .line 321
    .line 322
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 323
    .line 324
    .line 325
    :cond_2
    iget-boolean v0, p1, Lvv;->D:Z

    .line 326
    .line 327
    iget-boolean v1, p2, Lvv;->D:Z

    .line 328
    .line 329
    const-string v2, "accent_use_default"

    .line 330
    .line 331
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 332
    .line 333
    .line 334
    iget-object v0, p1, Lvv;->E:Lxi7;

    .line 335
    .line 336
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 337
    .line 338
    .line 339
    move-result-object v0

    .line 340
    iget-object v1, p2, Lvv;->E:Lxi7;

    .line 341
    .line 342
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    const-string v2, "theme_palette_style"

    .line 347
    .line 348
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 349
    .line 350
    .line 351
    iget-object v0, p1, Lvv;->F:Lri7;

    .line 352
    .line 353
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 354
    .line 355
    .line 356
    move-result-object v0

    .line 357
    iget-object v1, p2, Lvv;->F:Lri7;

    .line 358
    .line 359
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object v1

    .line 363
    const-string v2, "theme_color_spec"

    .line 364
    .line 365
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 366
    .line 367
    .line 368
    iget-boolean v0, p1, Lvv;->G:Z

    .line 369
    .line 370
    iget-boolean v1, p2, Lvv;->G:Z

    .line 371
    .line 372
    const-string v2, "enable_blur"

    .line 373
    .line 374
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 375
    .line 376
    .line 377
    iget-boolean v0, p1, Lvv;->J:Z

    .line 378
    .line 379
    iget-boolean v1, p2, Lvv;->J:Z

    .line 380
    .line 381
    const-string v2, "landscape_glass_navigation"

    .line 382
    .line 383
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 384
    .line 385
    .line 386
    iget-object v0, p1, Lvv;->H:Lmn7;

    .line 387
    .line 388
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 389
    .line 390
    .line 391
    move-result-object v0

    .line 392
    iget-object v1, p2, Lvv;->H:Lmn7;

    .line 393
    .line 394
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object v1

    .line 398
    const-string v2, "top_bar_style"

    .line 399
    .line 400
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 401
    .line 402
    .line 403
    iget-object v0, p1, Lvv;->I:Lh60;

    .line 404
    .line 405
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v0

    .line 409
    iget-object v1, p2, Lvv;->I:Lh60;

    .line 410
    .line 411
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 412
    .line 413
    .line 414
    move-result-object v1

    .line 415
    const-string v2, "bottom_bar_style"

    .line 416
    .line 417
    invoke-static {p0, v2, v0, v1}, Lar;->D(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 418
    .line 419
    .line 420
    iget-boolean v0, p1, Lvv;->K:Z

    .line 421
    .line 422
    iget-boolean v1, p2, Lvv;->K:Z

    .line 423
    .line 424
    const-string v2, "enable_predictive_back_animation"

    .line 425
    .line 426
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 427
    .line 428
    .line 429
    iget-boolean v0, p1, Lvv;->L:Z

    .line 430
    .line 431
    iget-boolean v1, p2, Lvv;->L:Z

    .line 432
    .line 433
    const-string v2, "predictive_back_animation_follow_edge"

    .line 434
    .line 435
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 436
    .line 437
    .line 438
    iget-boolean v0, p1, Lvv;->M:Z

    .line 439
    .line 440
    iget-boolean v1, p2, Lvv;->M:Z

    .line 441
    .line 442
    const-string v2, "enable_swipe_back"

    .line 443
    .line 444
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 445
    .line 446
    .line 447
    iget-boolean v0, p1, Lvv;->N:Z

    .line 448
    .line 449
    iget-boolean v1, p2, Lvv;->N:Z

    .line 450
    .line 451
    const-string v2, "use_net_speed_clash_api"

    .line 452
    .line 453
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 454
    .line 455
    .line 456
    iget-object v0, p1, Lvv;->O:Lcy6;

    .line 457
    .line 458
    iget-object v1, p2, Lvv;->O:Lcy6;

    .line 459
    .line 460
    if-eq v0, v1, :cond_3

    .line 461
    .line 462
    const-string v0, "speed_test_source"

    .line 463
    .line 464
    iget-object v1, v1, Lcy6;->h:Ljava/lang/String;

    .line 465
    .line 466
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 467
    .line 468
    .line 469
    :cond_3
    iget-boolean v0, p1, Lvv;->P:Z

    .line 470
    .line 471
    iget-boolean v1, p2, Lvv;->P:Z

    .line 472
    .line 473
    const-string v2, "speed_test_use_megabytes"

    .line 474
    .line 475
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 476
    .line 477
    .line 478
    iget-boolean v0, p1, Lvv;->Q:Z

    .line 479
    .line 480
    iget-boolean v1, p2, Lvv;->Q:Z

    .line 481
    .line 482
    const-string v2, "use_subscription_detail_clash_api"

    .line 483
    .line 484
    invoke-static {p0, v2, v0, v1}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 485
    .line 486
    .line 487
    iget v0, p1, Lvv;->R:F

    .line 488
    .line 489
    iget v1, p2, Lvv;->R:F

    .line 490
    .line 491
    cmpg-float v0, v0, v1

    .line 492
    .line 493
    if-eqz v0, :cond_4

    .line 494
    .line 495
    const-string v0, "page_scale"

    .line 496
    .line 497
    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    .line 498
    .line 499
    .line 500
    :cond_4
    iget-boolean p1, p1, Lvv;->S:Z

    .line 501
    .line 502
    iget-boolean p2, p2, Lvv;->S:Z

    .line 503
    .line 504
    const-string v0, "welcome_onboarding_shown"

    .line 505
    .line 506
    invoke-static {p0, v0, p1, p2}, Lar;->C(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;ZZ)V

    .line 507
    .line 508
    .line 509
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 510
    .line 511
    .line 512
    return-void
    .line 513
    .line 514
.end method

.method public final H(Z)V
    .locals 7

    .line 1
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lar;

    .line 4
    .line 5
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Ld22;

    .line 8
    .line 9
    iget-boolean v0, p0, Ld22;->j:Z

    .line 10
    .line 11
    if-eq v0, p1, :cond_4

    .line 12
    .line 13
    iget-object v0, p0, Ld22;->i:Lc22;

    .line 14
    .line 15
    if-eqz v0, :cond_3

    .line 16
    .line 17
    invoke-static {}, Lo12;->a()Lo12;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget-object v1, p0, Ld22;->i:Lc22;

    .line 22
    .line 23
    iget-object v2, v0, Lo12;->b:Lcx;

    .line 24
    .line 25
    const-string v3, "initCallback cannot be null"

    .line 26
    .line 27
    invoke-static {v3, v1}, Lpm6;->y(Ljava/lang/String;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-object v0, v0, Lo12;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-interface {v3}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 37
    .line 38
    .line 39
    :try_start_0
    new-instance v3, Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    new-instance v4, Lvw;

    .line 48
    .line 49
    invoke-direct {v4, v2}, Lvw;-><init>(Lcx;)V

    .line 50
    .line 51
    .line 52
    :cond_0
    :goto_0
    invoke-virtual {v4}, Lvw;->hasNext()Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_1

    .line 57
    .line 58
    invoke-virtual {v4}, Lvw;->next()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    check-cast v5, Lm12;

    .line 63
    .line 64
    iget-object v6, v5, Lm12;->a:Lmx;

    .line 65
    .line 66
    if-ne v6, v1, :cond_0

    .line 67
    .line 68
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_1
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    if-eqz v3, :cond_2

    .line 81
    .line 82
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v3

    .line 86
    check-cast v3, Lm12;

    .line 87
    .line 88
    invoke-virtual {v2, v3}, Lcx;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 89
    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_2
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 97
    .line 98
    .line 99
    goto :goto_2

    .line 100
    :catchall_0
    move-exception p0

    .line 101
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 106
    .line 107
    .line 108
    throw p0

    .line 109
    :cond_3
    :goto_2
    iput-boolean p1, p0, Ld22;->j:Z

    .line 110
    .line 111
    if-eqz p1, :cond_4

    .line 112
    .line 113
    iget-object p0, p0, Ld22;->h:Landroid/widget/EditText;

    .line 114
    .line 115
    invoke-static {}, Lo12;->a()Lo12;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    invoke-virtual {p1}, Lo12;->c()I

    .line 120
    .line 121
    .line 122
    move-result p1

    .line 123
    invoke-static {p0, p1}, Ld22;->a(Landroid/widget/EditText;I)V

    .line 124
    .line 125
    .line 126
    :cond_4
    return-void
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method

.method public J()V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 1
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Landroid/content/SharedPreferences;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    if-eqz p0, :cond_1

    .line 11
    .line 12
    invoke-virtual {p0, p3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    if-nez p1, :cond_0

    .line 17
    .line 18
    move-object v0, p0

    .line 19
    :cond_0
    if-eqz v0, :cond_1

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_1
    return-object p2
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final L(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;
    .locals 7

    .line 1
    instance-of v0, p1, Landroid/graphics/drawable/LayerDrawable;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_3

    .line 5
    .line 6
    check-cast p1, Landroid/graphics/drawable/LayerDrawable;

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/graphics/drawable/LayerDrawable;->getNumberOfLayers()I

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    new-array v0, p2, [Landroid/graphics/drawable/Drawable;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    move v3, v2

    .line 16
    :goto_0
    if-ge v3, p2, :cond_1

    .line 17
    .line 18
    invoke-virtual {p1, v3}, Landroid/graphics/drawable/LayerDrawable;->getId(I)I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    invoke-virtual {p1, v3}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 23
    .line 24
    .line 25
    move-result-object v5

    .line 26
    const v6, 0x102000d

    .line 27
    .line 28
    .line 29
    if-eq v4, v6, :cond_0

    .line 30
    .line 31
    const v6, 0x102000f

    .line 32
    .line 33
    .line 34
    if-eq v4, v6, :cond_0

    .line 35
    .line 36
    move v4, v2

    .line 37
    goto :goto_1

    .line 38
    :cond_0
    move v4, v1

    .line 39
    :goto_1
    invoke-virtual {p0, v5, v4}, Lar;->L(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    aput-object v4, v0, v3

    .line 44
    .line 45
    add-int/lit8 v3, v3, 0x1

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    new-instance p0, Landroid/graphics/drawable/LayerDrawable;

    .line 49
    .line 50
    invoke-direct {p0, v0}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 51
    .line 52
    .line 53
    :goto_2
    if-ge v2, p2, :cond_2

    .line 54
    .line 55
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getId(I)I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setId(II)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerGravity(I)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerGravity(II)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerWidth(I)I

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerWidth(II)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerHeight(I)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerHeight(II)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerInsetLeft(I)I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerInsetLeft(II)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerInsetRight(I)I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerInsetRight(II)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerInsetTop(I)I

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerInsetTop(II)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerInsetBottom(I)I

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerInsetBottom(II)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerInsetStart(I)I

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerInsetStart(II)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/LayerDrawable;->getLayerInsetEnd(I)I

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    invoke-virtual {p0, v2, v0}, Landroid/graphics/drawable/LayerDrawable;->setLayerInsetEnd(II)V

    .line 123
    .line 124
    .line 125
    add-int/lit8 v2, v2, 0x1

    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_2
    return-object p0

    .line 129
    :cond_3
    instance-of v0, p1, Landroid/graphics/drawable/BitmapDrawable;

    .line 130
    .line 131
    if-eqz v0, :cond_6

    .line 132
    .line 133
    check-cast p1, Landroid/graphics/drawable/BitmapDrawable;

    .line 134
    .line 135
    invoke-virtual {p1}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    iget-object v2, p0, Lar;->j:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast v2, Landroid/graphics/Bitmap;

    .line 142
    .line 143
    if-nez v2, :cond_4

    .line 144
    .line 145
    iput-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 146
    .line 147
    :cond_4
    new-instance p0, Landroid/graphics/drawable/ShapeDrawable;

    .line 148
    .line 149
    const/16 v2, 0x8

    .line 150
    .line 151
    new-array v2, v2, [F

    .line 152
    .line 153
    fill-array-data v2, :array_0

    .line 154
    .line 155
    .line 156
    new-instance v3, Landroid/graphics/drawable/shapes/RoundRectShape;

    .line 157
    .line 158
    const/4 v4, 0x0

    .line 159
    invoke-direct {v3, v2, v4, v4}, Landroid/graphics/drawable/shapes/RoundRectShape;-><init>([FLandroid/graphics/RectF;[F)V

    .line 160
    .line 161
    .line 162
    invoke-direct {p0, v3}, Landroid/graphics/drawable/ShapeDrawable;-><init>(Landroid/graphics/drawable/shapes/Shape;)V

    .line 163
    .line 164
    .line 165
    new-instance v2, Landroid/graphics/BitmapShader;

    .line 166
    .line 167
    sget-object v3, Landroid/graphics/Shader$TileMode;->REPEAT:Landroid/graphics/Shader$TileMode;

    .line 168
    .line 169
    sget-object v4, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    .line 170
    .line 171
    invoke-direct {v2, v0, v3, v4}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p0}, Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 179
    .line 180
    .line 181
    invoke-virtual {p0}, Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    invoke-virtual {p1}, Landroid/graphics/drawable/BitmapDrawable;->getPaint()Landroid/graphics/Paint;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    invoke-virtual {p1}, Landroid/graphics/Paint;->getColorFilter()Landroid/graphics/ColorFilter;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 194
    .line 195
    .line 196
    if-eqz p2, :cond_5

    .line 197
    .line 198
    new-instance p1, Landroid/graphics/drawable/ClipDrawable;

    .line 199
    .line 200
    const/4 p2, 0x3

    .line 201
    invoke-direct {p1, p0, p2, v1}, Landroid/graphics/drawable/ClipDrawable;-><init>(Landroid/graphics/drawable/Drawable;II)V

    .line 202
    .line 203
    .line 204
    return-object p1

    .line 205
    :cond_5
    return-object p0

    .line 206
    :cond_6
    return-object p1

    .line 207
    :array_0
    .array-data 4
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
    .end array-data
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
.end method

.method public final a([IIIFFI)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const/high16 v1, 0x40200000    # 2.5f

    .line 4
    .line 5
    mul-float v2, p4, v1

    .line 6
    .line 7
    const/high16 v3, 0x3f000000    # 0.5f

    .line 8
    .line 9
    add-float/2addr v2, v3

    .line 10
    float-to-int v2, v2

    .line 11
    const/4 v4, 0x0

    .line 12
    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    .line 13
    .line 14
    .line 15
    move-result v8

    .line 16
    mul-float v1, v1, p5

    .line 17
    .line 18
    add-float/2addr v1, v3

    .line 19
    float-to-int v1, v1

    .line 20
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-lez v8, :cond_0

    .line 25
    .line 26
    iget-object v2, v0, Lar;->i:Ljava/lang/Object;

    .line 27
    .line 28
    move-object v10, v2

    .line 29
    check-cast v10, Lx53;

    .line 30
    .line 31
    const/4 v11, 0x1

    .line 32
    const/4 v9, 0x1

    .line 33
    move-object/from16 v5, p1

    .line 34
    .line 35
    move/from16 v6, p2

    .line 36
    .line 37
    move/from16 v7, p3

    .line 38
    .line 39
    move/from16 v12, p6

    .line 40
    .line 41
    invoke-static/range {v5 .. v12}, Lmk3;->o0([IIIIZLx53;ZI)V

    .line 42
    .line 43
    .line 44
    :cond_0
    if-lez v1, :cond_2

    .line 45
    .line 46
    iget-object v0, v0, Lar;->j:Ljava/lang/Object;

    .line 47
    .line 48
    move-object v14, v0

    .line 49
    check-cast v14, Lx53;

    .line 50
    .line 51
    if-nez v8, :cond_1

    .line 52
    .line 53
    const/4 v4, 0x1

    .line 54
    :cond_1
    move v15, v4

    .line 55
    const/4 v13, 0x0

    .line 56
    move-object/from16 v9, p1

    .line 57
    .line 58
    move/from16 v10, p2

    .line 59
    .line 60
    move/from16 v11, p3

    .line 61
    .line 62
    move/from16 v16, p6

    .line 63
    .line 64
    move v12, v1

    .line 65
    invoke-static/range {v9 .. v16}, Lmk3;->o0([IIIIZLx53;ZI)V

    .line 66
    .line 67
    .line 68
    :cond_2
    return-void
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
.end method

.method public final b(I)Ljava/util/List;
    .locals 7

    .line 1
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lar;

    .line 4
    .line 5
    new-instance v1, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    :try_start_0
    iget-object v3, v0, Lar;->i:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v3, Ljava/util/concurrent/locks/ReentrantLock;

    .line 14
    .line 15
    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 16
    .line 17
    const-wide/16 v5, 0x1

    .line 18
    .line 19
    invoke-virtual {v3, v5, v6, v4}, Ljava/util/concurrent/locks/ReentrantLock;->tryLock(JLjava/util/concurrent/TimeUnit;)Z

    .line 20
    .line 21
    .line 22
    move-result v3
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    goto :goto_0

    .line 24
    :catch_0
    move-exception v3

    .line 25
    const-string v4, "LockedSpans"

    .line 26
    .line 27
    const-string v5, "failed to acquire the lock"

    .line 28
    .line 29
    invoke-static {v4, v5, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 30
    .line 31
    .line 32
    move v3, v2

    .line 33
    :goto_0
    if-eqz v3, :cond_2

    .line 34
    .line 35
    :try_start_1
    iget-object v3, v0, Lar;->j:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v3, Ljava/util/ArrayList;

    .line 38
    .line 39
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    if-ge p1, v3, :cond_0

    .line 44
    .line 45
    iget-object v3, v0, Lar;->j:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v3, Ljava/util/ArrayList;

    .line 48
    .line 49
    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    check-cast p1, Loy;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_0
    const/4 p1, 0x0

    .line 57
    :goto_1
    iget-object v0, v0, Lar;->i:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v0, Ljava/util/concurrent/locks/ReentrantLock;

    .line 60
    .line 61
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 62
    .line 63
    .line 64
    if-eqz p1, :cond_1

    .line 65
    .line 66
    iget-object v0, p1, Loy;->a:Ljava/util/concurrent/locks/ReentrantLock;

    .line 67
    .line 68
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->tryLock()Z

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    if-eqz v3, :cond_1

    .line 73
    .line 74
    :try_start_2
    iget-object p0, p1, Loy;->b:Ljava/util/ArrayList;

    .line 75
    .line 76
    invoke-static {p0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 77
    .line 78
    .line 79
    move-result-object p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 80
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 81
    .line 82
    .line 83
    return-object p0

    .line 84
    :catchall_0
    move-exception p0

    .line 85
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 86
    .line 87
    .line 88
    throw p0

    .line 89
    :cond_1
    invoke-virtual {p0, v2}, Lar;->t(I)Lmx6;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    goto :goto_2

    .line 97
    :catchall_1
    move-exception p0

    .line 98
    iget-object p1, v0, Lar;->i:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast p1, Ljava/util/concurrent/locks/ReentrantLock;

    .line 101
    .line 102
    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 103
    .line 104
    .line 105
    throw p0

    .line 106
    :cond_2
    invoke-virtual {p0, v2}, Lar;->t(I)Lmx6;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    :goto_2
    return-object v1
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method

.method public final c(I)V
    .locals 6

    .line 1
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lar;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-ltz p1, :cond_3

    .line 7
    .line 8
    iget-object v2, v0, Lar;->j:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v2, Ljava/util/ArrayList;

    .line 11
    .line 12
    iget-object v3, v0, Lar;->i:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v3, Ljava/util/concurrent/locks/ReentrantLock;

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-ge p1, v2, :cond_3

    .line 21
    .line 22
    iget-object v2, p0, Lar;->i:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v2, Loy;

    .line 25
    .line 26
    if-eqz v2, :cond_0

    .line 27
    .line 28
    iget-object v2, v2, Loy;->a:Ljava/util/concurrent/locks/ReentrantLock;

    .line 29
    .line 30
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 31
    .line 32
    .line 33
    :cond_0
    :try_start_0
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MICROSECONDS:Ljava/util/concurrent/TimeUnit;

    .line 34
    .line 35
    const-wide/16 v4, 0x64

    .line 36
    .line 37
    invoke-virtual {v3, v4, v5, v2}, Ljava/util/concurrent/locks/ReentrantLock;->tryLock(JLjava/util/concurrent/TimeUnit;)Z

    .line 38
    .line 39
    .line 40
    move-result v2
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 41
    goto :goto_0

    .line 42
    :catch_0
    move-exception v2

    .line 43
    const-string v4, "LockedSpans"

    .line 44
    .line 45
    const-string v5, "failed to acquire the lock"

    .line 46
    .line 47
    invoke-static {v4, v5, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 48
    .line 49
    .line 50
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 55
    .line 56
    .line 57
    const/4 v2, 0x0

    .line 58
    :goto_0
    if-eqz v2, :cond_2

    .line 59
    .line 60
    :try_start_1
    iget-object v0, v0, Lar;->j:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v0, Ljava/util/ArrayList;

    .line 63
    .line 64
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    check-cast p1, Loy;

    .line 69
    .line 70
    iget-object v0, p1, Loy;->a:Ljava/util/concurrent/locks/ReentrantLock;

    .line 71
    .line 72
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->tryLock()Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_1

    .line 77
    .line 78
    iput-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_1
    iput-object v1, p0, Lar;->i:Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 82
    .line 83
    :goto_1
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 84
    .line 85
    .line 86
    goto :goto_2

    .line 87
    :catchall_0
    move-exception p0

    .line 88
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 89
    .line 90
    .line 91
    throw p0

    .line 92
    :cond_2
    iput-object v1, p0, Lar;->i:Ljava/lang/Object;

    .line 93
    .line 94
    :goto_2
    return-void

    .line 95
    :cond_3
    iget-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast p1, Loy;

    .line 98
    .line 99
    if-eqz p1, :cond_4

    .line 100
    .line 101
    iget-object p1, p1, Loy;->a:Ljava/util/concurrent/locks/ReentrantLock;

    .line 102
    .line 103
    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 104
    .line 105
    .line 106
    :cond_4
    iput-object v1, p0, Lar;->i:Ljava/lang/Object;

    .line 107
    .line 108
    return-void
    .line 109
.end method

.method public final d(Lnv5;Ljava/lang/Object;)Lxb3;
    .locals 2

    .line 1
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lt51;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    :cond_0
    sget-object v1, Lxb3;->h:Lxb3;

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-virtual {v0, p1, p2}, Lt51;->d(Lnv5;Ljava/lang/Object;)Lxb3;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_2

    .line 17
    .line 18
    :cond_1
    move-object v0, v1

    .line 19
    :cond_2
    if-ne v0, v1, :cond_3

    .line 20
    .line 21
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast p0, Lhc4;

    .line 24
    .line 25
    iget-object v0, p0, Lhc4;->f:Ljava/util/List;

    .line 26
    .line 27
    new-instance v1, Ld75;

    .line 28
    .line 29
    invoke-direct {v1, p1, p2}, Ld75;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    invoke-static {v0, v1}, Lay0;->g1(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    iput-object p1, p0, Lhc4;->f:Ljava/util/List;

    .line 37
    .line 38
    sget-object p0, Lxb3;->i:Lxb3;

    .line 39
    .line 40
    return-object p0

    .line 41
    :cond_3
    return-object v0
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final e()V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final f()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final g(Ljava/lang/Object;)V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final h()I
    .locals 0

    .line 1
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Loy;

    .line 4
    .line 5
    if-nez p0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_0
    iget-object p0, p0, Loy;->b:Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    return p0
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public i(IF)V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final j(Lyn0;Lz00;)V
    .locals 12

    .line 1
    iget-byte v0, p0, Lar;->h:B

    .line 2
    .line 3
    const-string v1, "context"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lqn0;

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast p0, Lmd4;

    .line 18
    .line 19
    if-eqz p0, :cond_0

    .line 20
    .line 21
    invoke-virtual {p2, p1, v0, p0}, Lz00;->f(Lyn0;Lqn0;Lmd4;)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_0
    const-string p0, "extraStore"

    .line 26
    .line 27
    invoke-static {p0}, Lob3;->O(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw v2

    .line 31
    :cond_1
    const-string p0, "ranges"

    .line 32
    .line 33
    invoke-static {p0}, Lob3;->O(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v2

    .line 37
    :pswitch_0
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, Lgo0;

    .line 40
    .line 41
    if-eqz v0, :cond_4

    .line 42
    .line 43
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast p0, Lfd4;

    .line 46
    .line 47
    if-eqz p0, :cond_3

    .line 48
    .line 49
    if-eqz p1, :cond_2

    .line 50
    .line 51
    invoke-virtual {p2, v0, p0, p1}, Lz00;->i(Lgo0;Lfd4;Lyn0;)V

    .line 52
    .line 53
    .line 54
    :cond_2
    return-void

    .line 55
    :cond_3
    const-string p0, "layerDimensions"

    .line 56
    .line 57
    invoke-static {p0}, Lob3;->O(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    throw v2

    .line 61
    :cond_4
    invoke-static {v1}, Lob3;->O(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    throw v2

    .line 65
    :pswitch_1
    iget-object p1, p0, Lar;->i:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast p1, Lgo0;

    .line 68
    .line 69
    if-eqz p1, :cond_6

    .line 70
    .line 71
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast p0, Lvn0;

    .line 74
    .line 75
    if-eqz p0, :cond_5

    .line 76
    .line 77
    return-void

    .line 78
    :cond_5
    const-string p0, "horizontalLayerMargins"

    .line 79
    .line 80
    invoke-static {p0}, Lob3;->O(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    throw v2

    .line 84
    :cond_6
    invoke-static {v1}, Lob3;->O(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    throw v2

    .line 88
    :pswitch_2
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v0, Lrn0;

    .line 91
    .line 92
    if-eqz v0, :cond_9

    .line 93
    .line 94
    if-eqz p1, :cond_8

    .line 95
    .line 96
    iget-object v1, p2, Lz00;->a:Lvn0;

    .line 97
    .line 98
    const/4 v2, 0x0

    .line 99
    iput v2, v1, Lvn0;->a:F

    .line 100
    .line 101
    iput v2, v1, Lvn0;->b:F

    .line 102
    .line 103
    iget-object v3, v0, Lrn0;->d:Lfd4;

    .line 104
    .line 105
    invoke-virtual {p2, v0, v1, v3, p1}, Lz00;->a(Lgo0;Lvn0;Lfd4;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    iget-object v3, v0, Lrn0;->c:Lyv5;

    .line 109
    .line 110
    iget v4, v3, Lyv5;->a:F

    .line 111
    .line 112
    iget-object v5, v0, Lrn0;->a:Lgo0;

    .line 113
    .line 114
    invoke-interface {v5}, Le24;->l()Z

    .line 115
    .line 116
    .line 117
    sub-float v7, v4, v2

    .line 118
    .line 119
    iget v4, v3, Lyv5;->b:F

    .line 120
    .line 121
    iget v6, v1, Lvn0;->a:F

    .line 122
    .line 123
    sub-float v8, v4, v6

    .line 124
    .line 125
    iget v4, v3, Lyv5;->c:F

    .line 126
    .line 127
    invoke-interface {v5}, Le24;->l()Z

    .line 128
    .line 129
    .line 130
    add-float v9, v2, v4

    .line 131
    .line 132
    iget v2, v3, Lyv5;->d:F

    .line 133
    .line 134
    iget v1, v1, Lvn0;->b:F

    .line 135
    .line 136
    add-float v10, v2, v1

    .line 137
    .line 138
    iget-object v1, v0, Lrn0;->g:Lld4;

    .line 139
    .line 140
    iget-object v1, v1, Lld4;->h:Ldw1;

    .line 141
    .line 142
    invoke-interface {v1}, Ldw1;->V()Lzi7;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    invoke-virtual {v1}, Lzi7;->P()J

    .line 147
    .line 148
    .line 149
    move-result-wide v2

    .line 150
    invoke-virtual {v1}, Lzi7;->K()Lpl0;

    .line 151
    .line 152
    .line 153
    move-result-object v4

    .line 154
    invoke-interface {v4}, Lpl0;->n()V

    .line 155
    .line 156
    .line 157
    :try_start_0
    iget-object v4, v1, Lzi7;->i:Ljava/lang/Object;

    .line 158
    .line 159
    move-object v6, v4

    .line 160
    check-cast v6, Lm5;

    .line 161
    .line 162
    const/4 v11, 0x1

    .line 163
    invoke-virtual/range {v6 .. v11}, Lm5;->t(FFFFI)V

    .line 164
    .line 165
    .line 166
    iget-object v6, v0, Lrn0;->b:Lpl0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 167
    .line 168
    :try_start_1
    invoke-interface {v6}, Lpl0;->n()V

    .line 169
    .line 170
    .line 171
    const/4 v11, 0x1

    .line 172
    invoke-interface/range {v6 .. v11}, Lpl0;->h(FFFFI)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {p2, v0, p1}, Lz00;->d(Lrn0;Lyn0;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 176
    .line 177
    .line 178
    :try_start_2
    invoke-interface {v6}, Lpl0;->j()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 179
    .line 180
    .line 181
    invoke-virtual {v1}, Lzi7;->K()Lpl0;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    invoke-interface {p1}, Lpl0;->j()V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v1, v2, v3}, Lzi7;->r0(J)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {p2}, Lz00;->e()Ljava/util/LinkedHashMap;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast p0, Lim0;

    .line 198
    .line 199
    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 208
    .line 209
    .line 210
    move-result p2

    .line 211
    if-eqz p2, :cond_8

    .line 212
    .line 213
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 214
    .line 215
    .line 216
    move-result-object p2

    .line 217
    check-cast p2, Ljava/util/Map$Entry;

    .line 218
    .line 219
    iget-object v0, p0, Lim0;->l:Ljava/util/LinkedHashMap;

    .line 220
    .line 221
    invoke-interface {p2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v1

    .line 225
    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v2

    .line 229
    if-nez v2, :cond_7

    .line 230
    .line 231
    new-instance v2, Ljava/util/ArrayList;

    .line 232
    .line 233
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 234
    .line 235
    .line 236
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    :cond_7
    check-cast v2, Ljava/util/Collection;

    .line 240
    .line 241
    invoke-interface {p2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object p2

    .line 245
    check-cast p2, Ljava/lang/Iterable;

    .line 246
    .line 247
    invoke-static {v2, p2}, Lfy0;->H0(Ljava/util/Collection;Ljava/lang/Iterable;)V

    .line 248
    .line 249
    .line 250
    goto :goto_0

    .line 251
    :cond_8
    return-void

    .line 252
    :catchall_0
    move-exception v0

    .line 253
    move-object p0, v0

    .line 254
    :try_start_3
    invoke-interface {v6}, Lpl0;->j()V

    .line 255
    .line 256
    .line 257
    throw p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 258
    :catchall_1
    move-exception v0

    .line 259
    move-object p0, v0

    .line 260
    invoke-static {v1, v2, v3}, Ln32;->w(Lzi7;J)V

    .line 261
    .line 262
    .line 263
    throw p0

    .line 264
    :cond_9
    invoke-static {v1}, Lob3;->O(Ljava/lang/String;)V

    .line 265
    .line 266
    .line 267
    throw v2

    .line 268
    nop

    .line 269
    :pswitch_data_0
    .packed-switch 0x10
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
.end method

.method public final k(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    .locals 2

    .line 1
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo40;

    .line 4
    .line 5
    iput p1, v0, Lo40;->a:I

    .line 6
    .line 7
    iput p2, v0, Lo40;->b:I

    .line 8
    .line 9
    iput-object p3, v0, Lo40;->c:Landroid/graphics/Bitmap$Config;

    .line 10
    .line 11
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Lzw;

    .line 14
    .line 15
    invoke-virtual {p0, v0}, Lis6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    check-cast p0, Lrw;

    .line 20
    .line 21
    if-nez p0, :cond_0

    .line 22
    .line 23
    invoke-static {p1, p2, p3}, Lm40;->a(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0

    .line 28
    :cond_0
    invoke-virtual {p0}, Lrw;->isEmpty()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    invoke-virtual {p0}, Lrw;->removeLast()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/graphics/Bitmap;

    .line 39
    .line 40
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->isRecycled()Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-nez v1, :cond_0

    .line 45
    .line 46
    const/4 p0, 0x0

    .line 47
    invoke-virtual {v0, p0}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 48
    .line 49
    .line 50
    return-object v0

    .line 51
    :cond_1
    invoke-static {p1, p2, p3}, Lm40;->a(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final l(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, v0, v1, p1}, Lar;->k(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final m(Lro0;IIIZ)V
    .locals 10

    .line 1
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lve4;

    .line 4
    .line 5
    iget v0, p0, Lve4;->j:I

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    const/4 v2, 0x0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    move v3, v2

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    if-eqz v0, :cond_5

    .line 14
    .line 15
    sub-int/2addr v0, v1

    .line 16
    iget-object v3, p0, Lve4;->h:[Ljava/lang/Object;

    .line 17
    .line 18
    aget-object v0, v3, v0

    .line 19
    .line 20
    check-cast v0, Lro0;

    .line 21
    .line 22
    iget v3, v0, Lro0;->b:I

    .line 23
    .line 24
    iget v0, v0, Lro0;->d:I

    .line 25
    .line 26
    sub-int/2addr v3, v0

    .line 27
    :goto_0
    if-nez p1, :cond_1

    .line 28
    .line 29
    sub-int v8, p2, v3

    .line 30
    .line 31
    sub-int p1, p3, p2

    .line 32
    .line 33
    add-int v9, p1, v8

    .line 34
    .line 35
    new-instance v4, Lro0;

    .line 36
    .line 37
    add-int v7, p3, p4

    .line 38
    .line 39
    move v6, p2

    .line 40
    move v5, p5

    .line 41
    invoke-direct/range {v4 .. v9}, Lro0;-><init>(ZIIII)V

    .line 42
    .line 43
    .line 44
    move-object p1, v4

    .line 45
    goto :goto_2

    .line 46
    :cond_1
    move v6, p2

    .line 47
    move v5, p5

    .line 48
    iget-boolean p2, p1, Lro0;->e:Z

    .line 49
    .line 50
    if-nez p2, :cond_2

    .line 51
    .line 52
    if-nez v5, :cond_2

    .line 53
    .line 54
    move v1, v2

    .line 55
    :cond_2
    iput-boolean v1, p1, Lro0;->e:Z

    .line 56
    .line 57
    iget p2, p1, Lro0;->a:I

    .line 58
    .line 59
    if-le p2, v6, :cond_3

    .line 60
    .line 61
    iput v6, p1, Lro0;->a:I

    .line 62
    .line 63
    iput v6, p1, Lro0;->c:I

    .line 64
    .line 65
    :cond_3
    iget p2, p1, Lro0;->b:I

    .line 66
    .line 67
    if-le p3, p2, :cond_4

    .line 68
    .line 69
    iget p5, p1, Lro0;->d:I

    .line 70
    .line 71
    sub-int/2addr p2, p5

    .line 72
    iput p3, p1, Lro0;->b:I

    .line 73
    .line 74
    sub-int p2, p3, p2

    .line 75
    .line 76
    iput p2, p1, Lro0;->d:I

    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_4
    move p3, p2

    .line 80
    :goto_1
    add-int/2addr p3, p4

    .line 81
    iput p3, p1, Lro0;->b:I

    .line 82
    .line 83
    :goto_2
    invoke-virtual {p0, p1}, Lve4;->b(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_5
    const-string p0, "MutableVector is empty."

    .line 88
    .line 89
    invoke-static {p0}, Lwt5;->o(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    return-void
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
.end method

.method public final n(FLjava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    iget-object p2, p0, Lar;->j:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p2, [F

    .line 11
    .line 12
    array-length p2, p2

    .line 13
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-ge p2, v1, :cond_0

    .line 18
    .line 19
    iget-object p2, p0, Lar;->j:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p2, [F

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    add-int/lit8 v1, v1, 0x2

    .line 28
    .line 29
    invoke-static {p2, v1}, Ljava/util/Arrays;->copyOf([FI)[F

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    iput-object p2, p0, Lar;->j:Ljava/lang/Object;

    .line 34
    .line 35
    :cond_0
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p0, [F

    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 40
    .line 41
    .line 42
    move-result p2

    .line 43
    add-int/lit8 p2, p2, -0x1

    .line 44
    .line 45
    aput p1, p0, p2

    .line 46
    .line 47
    return-void
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final p()V
    .locals 0

    .line 1
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lve4;

    .line 4
    .line 5
    invoke-virtual {p0}, Lve4;->g()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final q(Lcr7;Z)Luv4;
    .locals 7

    .line 1
    iget-object v0, p1, Lcr7;->b:Ljava/lang/reflect/Type;

    .line 2
    .line 3
    iget-object p1, p1, Lcr7;->a:Ljava/lang/Class;

    .line 4
    .line 5
    iget-object v1, p0, Lar;->i:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/util/HashMap;

    .line 8
    .line 9
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    const/4 v3, 0x0

    .line 14
    if-nez v2, :cond_14

    .line 15
    .line 16
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-nez v1, :cond_13

    .line 21
    .line 22
    const-class v1, Ljava/util/EnumSet;

    .line 23
    .line 24
    invoke-virtual {v1, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    const/4 v2, 0x1

    .line 29
    const/4 v4, 0x0

    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    new-instance v1, Lyb1;

    .line 33
    .line 34
    invoke-direct {v1, v0, v4}, Lyb1;-><init>(Ljava/lang/reflect/Type;B)V

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const-class v1, Ljava/util/EnumMap;

    .line 39
    .line 40
    if-ne p1, v1, :cond_1

    .line 41
    .line 42
    new-instance v1, Lyb1;

    .line 43
    .line 44
    invoke-direct {v1, v0, v2}, Lyb1;-><init>(Ljava/lang/reflect/Type;B)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    move-object v1, v3

    .line 49
    :goto_0
    if-eqz v1, :cond_2

    .line 50
    .line 51
    return-object v1

    .line 52
    :cond_2
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast p0, Ljava/util/ArrayList;

    .line 55
    .line 56
    invoke-static {p0}, Lnl3;->z(Ljava/util/ArrayList;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Class;->getModifiers()I

    .line 60
    .line 61
    .line 62
    move-result p0

    .line 63
    invoke-static {p0}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    if-nez p0, :cond_4

    .line 68
    .line 69
    :try_start_0
    invoke-virtual {p1, v3}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 70
    .line 71
    .line 72
    move-result-object p0
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1

    .line 73
    sget-object v1, Llw5;->a:Lrl3;

    .line 74
    .line 75
    :try_start_1
    invoke-virtual {p0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 76
    .line 77
    .line 78
    move-object v1, v3

    .line 79
    goto :goto_1

    .line 80
    :catch_0
    move-exception v1

    .line 81
    new-instance v5, Ljava/lang/StringBuilder;

    .line 82
    .line 83
    const-string v6, "Failed making constructor \'"

    .line 84
    .line 85
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-static {p0}, Llw5;->b(Ljava/lang/reflect/Constructor;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v6

    .line 92
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v6, "\' accessible; either increase its visibility or write a custom InstanceCreator or TypeAdapter for its declaring type: "

    .line 96
    .line 97
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v6

    .line 104
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    .line 106
    .line 107
    invoke-static {v1}, Llw5;->e(Ljava/lang/Exception;)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    :goto_1
    if-eqz v1, :cond_3

    .line 119
    .line 120
    new-instance p0, Lwb1;

    .line 121
    .line 122
    invoke-direct {p0, v1, v4}, Lwb1;-><init>(Ljava/lang/String;B)V

    .line 123
    .line 124
    .line 125
    goto :goto_2

    .line 126
    :cond_3
    new-instance v1, Lg7;

    .line 127
    .line 128
    invoke-direct {v1, p0, v2}, Lg7;-><init>(Ljava/lang/Object;B)V

    .line 129
    .line 130
    .line 131
    move-object p0, v1

    .line 132
    goto :goto_2

    .line 133
    :catch_1
    :cond_4
    move-object p0, v3

    .line 134
    :goto_2
    if-eqz p0, :cond_5

    .line 135
    .line 136
    return-object p0

    .line 137
    :cond_5
    const-class p0, Ljava/util/Collection;

    .line 138
    .line 139
    invoke-virtual {p0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 140
    .line 141
    .line 142
    move-result p0

    .line 143
    if-eqz p0, :cond_9

    .line 144
    .line 145
    const-class p0, Ljava/util/ArrayList;

    .line 146
    .line 147
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 148
    .line 149
    .line 150
    move-result p0

    .line 151
    if-eqz p0, :cond_6

    .line 152
    .line 153
    new-instance v3, Ll42;

    .line 154
    .line 155
    const/16 p0, 0x1b

    .line 156
    .line 157
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 158
    .line 159
    .line 160
    goto/16 :goto_3

    .line 161
    .line 162
    :cond_6
    const-class p0, Ljava/util/LinkedHashSet;

    .line 163
    .line 164
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 165
    .line 166
    .line 167
    move-result p0

    .line 168
    if-eqz p0, :cond_7

    .line 169
    .line 170
    new-instance v3, Ll42;

    .line 171
    .line 172
    const/16 p0, 0x1c

    .line 173
    .line 174
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 175
    .line 176
    .line 177
    goto/16 :goto_3

    .line 178
    .line 179
    :cond_7
    const-class p0, Ljava/util/TreeSet;

    .line 180
    .line 181
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 182
    .line 183
    .line 184
    move-result p0

    .line 185
    if-eqz p0, :cond_8

    .line 186
    .line 187
    new-instance v3, Ll42;

    .line 188
    .line 189
    const/16 p0, 0x1d

    .line 190
    .line 191
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 192
    .line 193
    .line 194
    goto/16 :goto_3

    .line 195
    .line 196
    :cond_8
    const-class p0, Ljava/util/ArrayDeque;

    .line 197
    .line 198
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 199
    .line 200
    .line 201
    move-result p0

    .line 202
    if-eqz p0, :cond_f

    .line 203
    .line 204
    new-instance v3, Lxb1;

    .line 205
    .line 206
    invoke-direct {v3, v4}, Lxb1;-><init>(B)V

    .line 207
    .line 208
    .line 209
    goto/16 :goto_3

    .line 210
    .line 211
    :cond_9
    const-class p0, Ljava/util/Map;

    .line 212
    .line 213
    invoke-virtual {p0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 214
    .line 215
    .line 216
    move-result p0

    .line 217
    if-eqz p0, :cond_f

    .line 218
    .line 219
    const-class p0, Ltr3;

    .line 220
    .line 221
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 222
    .line 223
    .line 224
    move-result p0

    .line 225
    if-eqz p0, :cond_b

    .line 226
    .line 227
    instance-of p0, v0, Ljava/lang/reflect/ParameterizedType;

    .line 228
    .line 229
    if-eqz p0, :cond_a

    .line 230
    .line 231
    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    .line 232
    .line 233
    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    .line 234
    .line 235
    .line 236
    move-result-object p0

    .line 237
    array-length v0, p0

    .line 238
    if-eqz v0, :cond_b

    .line 239
    .line 240
    aget-object p0, p0, v4

    .line 241
    .line 242
    invoke-static {p0}, Ldy3;->c0(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    .line 243
    .line 244
    .line 245
    move-result-object p0

    .line 246
    const-class v0, Ljava/lang/String;

    .line 247
    .line 248
    if-ne p0, v0, :cond_b

    .line 249
    .line 250
    :cond_a
    new-instance v3, Ll42;

    .line 251
    .line 252
    const/16 p0, 0x16

    .line 253
    .line 254
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 255
    .line 256
    .line 257
    goto :goto_3

    .line 258
    :cond_b
    const-class p0, Ljava/util/LinkedHashMap;

    .line 259
    .line 260
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 261
    .line 262
    .line 263
    move-result p0

    .line 264
    if-eqz p0, :cond_c

    .line 265
    .line 266
    new-instance v3, Ll42;

    .line 267
    .line 268
    const/16 p0, 0x17

    .line 269
    .line 270
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 271
    .line 272
    .line 273
    goto :goto_3

    .line 274
    :cond_c
    const-class p0, Ljava/util/TreeMap;

    .line 275
    .line 276
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 277
    .line 278
    .line 279
    move-result p0

    .line 280
    if-eqz p0, :cond_d

    .line 281
    .line 282
    new-instance v3, Ll42;

    .line 283
    .line 284
    const/16 p0, 0x18

    .line 285
    .line 286
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 287
    .line 288
    .line 289
    goto :goto_3

    .line 290
    :cond_d
    const-class p0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 291
    .line 292
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 293
    .line 294
    .line 295
    move-result p0

    .line 296
    if-eqz p0, :cond_e

    .line 297
    .line 298
    new-instance v3, Ll42;

    .line 299
    .line 300
    const/16 p0, 0x19

    .line 301
    .line 302
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 303
    .line 304
    .line 305
    goto :goto_3

    .line 306
    :cond_e
    const-class p0, Ljava/util/concurrent/ConcurrentSkipListMap;

    .line 307
    .line 308
    invoke-virtual {p1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 309
    .line 310
    .line 311
    move-result p0

    .line 312
    if-eqz p0, :cond_f

    .line 313
    .line 314
    new-instance v3, Ll42;

    .line 315
    .line 316
    const/16 p0, 0x1a

    .line 317
    .line 318
    invoke-direct {v3, p0}, Ll42;-><init>(B)V

    .line 319
    .line 320
    .line 321
    :cond_f
    :goto_3
    if-eqz v3, :cond_10

    .line 322
    .line 323
    return-object v3

    .line 324
    :cond_10
    invoke-static {p1}, Lar;->o(Ljava/lang/Class;)Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object p0

    .line 328
    if-eqz p0, :cond_11

    .line 329
    .line 330
    new-instance p1, Lwb1;

    .line 331
    .line 332
    invoke-direct {p1, p0, v2}, Lwb1;-><init>(Ljava/lang/String;B)V

    .line 333
    .line 334
    .line 335
    return-object p1

    .line 336
    :cond_11
    const/4 p0, 0x2

    .line 337
    if-nez p2, :cond_12

    .line 338
    .line 339
    new-instance p2, Ljava/lang/StringBuilder;

    .line 340
    .line 341
    const-string v0, "Unable to create instance of "

    .line 342
    .line 343
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 344
    .line 345
    .line 346
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 347
    .line 348
    .line 349
    const-string p1, "; Register an InstanceCreator or a TypeAdapter for this type."

    .line 350
    .line 351
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 352
    .line 353
    .line 354
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object p1

    .line 358
    new-instance p2, Lwb1;

    .line 359
    .line 360
    invoke-direct {p2, p1, p0}, Lwb1;-><init>(Ljava/lang/String;B)V

    .line 361
    .line 362
    .line 363
    return-object p2

    .line 364
    :cond_12
    new-instance p2, Lg7;

    .line 365
    .line 366
    invoke-direct {p2, p1, p0}, Lg7;-><init>(Ljava/lang/Object;B)V

    .line 367
    .line 368
    .line 369
    return-object p2

    .line 370
    :cond_13
    invoke-static {}, Lxb1;->r()V

    .line 371
    .line 372
    .line 373
    return-object v3

    .line 374
    :cond_14
    invoke-static {}, Lxb1;->r()V

    .line 375
    .line 376
    .line 377
    return-object v3
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
.end method

.method public final r()Landroid/content/ClipboardManager;
    .locals 2

    .line 1
    iget-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/ClipboardManager;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Landroid/content/Context;

    .line 10
    .line 11
    const-string v1, "clipboard"

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    check-cast v0, Landroid/content/ClipboardManager;

    .line 21
    .line 22
    iput-object v0, p0, Lar;->j:Ljava/lang/Object;

    .line 23
    .line 24
    :cond_0
    return-object v0
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final s(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;
    .locals 0

    .line 1
    instance-of p0, p1, Landroid/text/method/NumberKeyListener;

    .line 2
    .line 3
    if-nez p0, :cond_3

    .line 4
    .line 5
    instance-of p0, p1, Lw12;

    .line 6
    .line 7
    if-eqz p0, :cond_0

    .line 8
    .line 9
    return-object p1

    .line 10
    :cond_0
    if-nez p1, :cond_1

    .line 11
    .line 12
    const/4 p0, 0x0

    .line 13
    return-object p0

    .line 14
    :cond_1
    instance-of p0, p1, Landroid/text/method/NumberKeyListener;

    .line 15
    .line 16
    if-eqz p0, :cond_2

    .line 17
    .line 18
    return-object p1

    .line 19
    :cond_2
    new-instance p0, Lw12;

    .line 20
    .line 21
    invoke-direct {p0, p1}, Lw12;-><init>(Landroid/text/method/KeyListener;)V

    .line 22
    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_3
    return-object p1
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final t(I)Lmx6;
    .locals 2

    .line 1
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Loy;

    .line 4
    .line 5
    if-nez p0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    const-wide/16 v0, 0x5

    .line 9
    .line 10
    invoke-static {p0, v0, v1}, Lps4;->j(IJ)Lps4;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0

    .line 15
    :cond_0
    iget-object p0, p0, Loy;->b:Ljava/util/ArrayList;

    .line 16
    .line 17
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    check-cast p0, Lmx6;

    .line 22
    .line 23
    return-object p0
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final toString()Ljava/lang/String;
    .locals 12

    .line 1
    iget-byte v0, p0, Lar;->h:B

    .line 2
    .line 3
    const-string v1, ")"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    sparse-switch v0, :sswitch_data_0

    .line 7
    .line 8
    .line 9
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0

    .line 14
    :sswitch_0
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p0, Ljava/util/HashMap;

    .line 17
    .line 18
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :sswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 24
    .line 25
    const-string v3, "ChangeList(changes=["

    .line 26
    .line 27
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    iget-object v3, p0, Lar;->i:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v3, Lve4;

    .line 33
    .line 34
    iget-object v4, v3, Lve4;->h:[Ljava/lang/Object;

    .line 35
    .line 36
    iget v3, v3, Lve4;->j:I

    .line 37
    .line 38
    :goto_0
    if-ge v2, v3, :cond_1

    .line 39
    .line 40
    aget-object v5, v4, v2

    .line 41
    .line 42
    check-cast v5, Lro0;

    .line 43
    .line 44
    iget v6, v5, Lro0;->c:I

    .line 45
    .line 46
    iget v7, v5, Lro0;->d:I

    .line 47
    .line 48
    iget v8, v5, Lro0;->a:I

    .line 49
    .line 50
    iget v5, v5, Lro0;->b:I

    .line 51
    .line 52
    const-string v9, "("

    .line 53
    .line 54
    const-string v10, ")->("

    .line 55
    .line 56
    const-string v11, ","

    .line 57
    .line 58
    invoke-static {v6, v7, v9, v11, v10}, Ln32;->p(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    move-result-object v6

    .line 62
    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    iget-object v5, p0, Lar;->i:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v5, Lve4;

    .line 84
    .line 85
    iget v5, v5, Lve4;->j:I

    .line 86
    .line 87
    add-int/lit8 v5, v5, -0x1

    .line 88
    .line 89
    if-ge v2, v5, :cond_0

    .line 90
    .line 91
    const-string v5, ", "

    .line 92
    .line 93
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 97
    .line 98
    goto :goto_0

    .line 99
    :cond_1
    const-string p0, "])"

    .line 100
    .line 101
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object p0

    .line 108
    return-object p0

    .line 109
    :sswitch_2
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast p0, Lzw;

    .line 112
    .line 113
    iget v0, p0, Lis6;->j:I

    .line 114
    .line 115
    move v3, v2

    .line 116
    move v4, v3

    .line 117
    move v5, v4

    .line 118
    :goto_1
    if-ge v3, v0, :cond_3

    .line 119
    .line 120
    invoke-virtual {p0, v3}, Lis6;->h(I)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v6

    .line 124
    check-cast v6, Lrw;

    .line 125
    .line 126
    iget v7, v6, Lrw;->j:I

    .line 127
    .line 128
    add-int/2addr v4, v7

    .line 129
    invoke-virtual {v6}, Ljava/util/AbstractList;->iterator()Ljava/util/Iterator;

    .line 130
    .line 131
    .line 132
    move-result-object v6

    .line 133
    move v7, v2

    .line 134
    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 135
    .line 136
    .line 137
    move-result v8

    .line 138
    if-eqz v8, :cond_2

    .line 139
    .line 140
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v8

    .line 144
    check-cast v8, Landroid/graphics/Bitmap;

    .line 145
    .line 146
    invoke-virtual {v8}, Landroid/graphics/Bitmap;->getAllocationByteCount()I

    .line 147
    .line 148
    .line 149
    move-result v8

    .line 150
    add-int/2addr v7, v8

    .line 151
    goto :goto_2

    .line 152
    :cond_2
    add-int/2addr v5, v7

    .line 153
    add-int/lit8 v3, v3, 0x1

    .line 154
    .line 155
    goto :goto_1

    .line 156
    :cond_3
    const-string p0, "BitmapPool(imageCount="

    .line 157
    .line 158
    const-string v0, ", imageBytes="

    .line 159
    .line 160
    invoke-static {v4, v5, p0, v0, v1}, Ln32;->k(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object p0

    .line 164
    return-object p0

    .line 165
    :sswitch_data_0
    .sparse-switch
        0xd -> :sswitch_2
        0x14 -> :sswitch_1
        0x17 -> :sswitch_0
    .end sparse-switch
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
.end method

.method public final u(ILandroid/view/KeyEvent;)Z
    .locals 1

    .line 1
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lrg3;

    .line 4
    .line 5
    invoke-virtual {p0}, Lrg3;->b()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Lrg3;->a()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-nez p0, :cond_0

    .line 16
    .line 17
    invoke-virtual {p2}, Landroid/view/KeyEvent;->isCtrlPressed()Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-eqz p0, :cond_2

    .line 22
    .line 23
    :cond_0
    const/16 p0, 0x1d

    .line 24
    .line 25
    if-lt p1, p0, :cond_1

    .line 26
    .line 27
    const/16 p0, 0x36

    .line 28
    .line 29
    if-le p1, p0, :cond_3

    .line 30
    .line 31
    :cond_1
    const/16 p0, 0x42

    .line 32
    .line 33
    if-eq p1, p0, :cond_3

    .line 34
    .line 35
    const/16 p0, 0x13

    .line 36
    .line 37
    if-eq p1, p0, :cond_3

    .line 38
    .line 39
    const/16 p0, 0x14

    .line 40
    .line 41
    if-eq p1, p0, :cond_3

    .line 42
    .line 43
    const/16 p0, 0x15

    .line 44
    .line 45
    if-eq p1, p0, :cond_3

    .line 46
    .line 47
    const/16 p0, 0x16

    .line 48
    .line 49
    if-eq p1, p0, :cond_3

    .line 50
    .line 51
    const/16 p0, 0x7a

    .line 52
    .line 53
    if-eq p1, p0, :cond_3

    .line 54
    .line 55
    const/16 p0, 0x7b

    .line 56
    .line 57
    if-eq p1, p0, :cond_3

    .line 58
    .line 59
    const/16 p0, 0x3e

    .line 60
    .line 61
    if-eq p1, p0, :cond_3

    .line 62
    .line 63
    :cond_2
    const/4 p0, 0x0

    .line 64
    return p0

    .line 65
    :cond_3
    const/4 p0, 0x1

    .line 66
    return p0
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
.end method

.method public final v()Lvv;
    .locals 54

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lar;->i:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Landroid/content/Context;

    .line 6
    .line 7
    const v2, 0x7f0f005d

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const v3, 0x7f0f0331

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    const v4, 0x7f0f0330

    .line 28
    .line 29
    .line 30
    invoke-virtual {v1, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    const v5, 0x7f0f00d9

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    const v6, 0x7f0f01b6

    .line 48
    .line 49
    .line 50
    invoke-virtual {v1, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    iget-object v6, v0, Lar;->j:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v6, Landroid/content/SharedPreferences;

    .line 60
    .line 61
    sget-object v7, Lss7;->i:Luk7;

    .line 62
    .line 63
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    sget-object v7, Lss7;->j:Lss7;

    .line 67
    .line 68
    iget-object v8, v7, Lss7;->h:Ljava/lang/String;

    .line 69
    .line 70
    const-string v9, "ui_mode"

    .line 71
    .line 72
    invoke-interface {v6, v9, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v8

    .line 76
    const-string v9, "material"

    .line 77
    .line 78
    invoke-static {v8, v9}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v9

    .line 82
    if-eqz v9, :cond_1

    .line 83
    .line 84
    sget-object v7, Lss7;->k:Lss7;

    .line 85
    .line 86
    :cond_0
    :goto_0
    move-object v9, v7

    .line 87
    goto :goto_1

    .line 88
    :cond_1
    const-string v9, "miuix"

    .line 89
    .line 90
    invoke-static {v8, v9}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v8

    .line 94
    if-eqz v8, :cond_0

    .line 95
    .line 96
    sget-object v7, Lss7;->l:Lss7;

    .line 97
    .line 98
    goto :goto_0

    .line 99
    :goto_1
    const-string v7, "app_language"

    .line 100
    .line 101
    const-string v8, "system"

    .line 102
    .line 103
    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v7

    .line 107
    sget-object v8, Los;->j:Ls38;

    .line 108
    .line 109
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    sget-object v8, Los;->m:Lc42;

    .line 113
    .line 114
    invoke-virtual {v8}, Lq3;->iterator()Ljava/util/Iterator;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    :cond_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 119
    .line 120
    .line 121
    move-result v10

    .line 122
    const/4 v11, 0x0

    .line 123
    if-eqz v10, :cond_3

    .line 124
    .line 125
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v10

    .line 129
    move-object v12, v10

    .line 130
    check-cast v12, Los;

    .line 131
    .line 132
    iget-object v12, v12, Los;->h:Ljava/lang/String;

    .line 133
    .line 134
    invoke-virtual {v12, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v12

    .line 138
    if-eqz v12, :cond_2

    .line 139
    .line 140
    goto :goto_2

    .line 141
    :cond_3
    move-object v10, v11

    .line 142
    :goto_2
    check-cast v10, Los;

    .line 143
    .line 144
    if-nez v10, :cond_4

    .line 145
    .line 146
    sget-object v10, Los;->k:Los;

    .line 147
    .line 148
    :cond_4
    const-string v7, "home_panel_entry_mode"

    .line 149
    .line 150
    const-string v8, "overview"

    .line 151
    .line 152
    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v7

    .line 156
    sget-object v8, Liy2;->i:Lzk2;

    .line 157
    .line 158
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 159
    .line 160
    .line 161
    sget-object v8, Liy2;->r:Lc42;

    .line 162
    .line 163
    invoke-virtual {v8}, Lq3;->iterator()Ljava/util/Iterator;

    .line 164
    .line 165
    .line 166
    move-result-object v8

    .line 167
    :cond_5
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 168
    .line 169
    .line 170
    move-result v12

    .line 171
    if-eqz v12, :cond_6

    .line 172
    .line 173
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v12

    .line 177
    move-object v13, v12

    .line 178
    check-cast v13, Liy2;

    .line 179
    .line 180
    iget-object v13, v13, Liy2;->h:Ljava/lang/String;

    .line 181
    .line 182
    invoke-virtual {v13, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 183
    .line 184
    .line 185
    move-result v13

    .line 186
    if-eqz v13, :cond_5

    .line 187
    .line 188
    goto :goto_3

    .line 189
    :cond_6
    move-object v12, v11

    .line 190
    :goto_3
    check-cast v12, Liy2;

    .line 191
    .line 192
    if-nez v12, :cond_7

    .line 193
    .line 194
    sget-object v12, Liy2;->j:Liy2;

    .line 195
    .line 196
    :cond_7
    const-string v7, "auto_start_enabled"

    .line 197
    .line 198
    const/4 v8, 0x0

    .line 199
    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 200
    .line 201
    .line 202
    move-result v7

    .line 203
    const-string v13, "accelerated_download_enabled"

    .line 204
    .line 205
    invoke-interface {v6, v13, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 206
    .line 207
    .line 208
    move-result v13

    .line 209
    const-string v14, "accelerated_download_prefix"

    .line 210
    .line 211
    invoke-interface {v6, v14, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v14

    .line 215
    const-string v15, ""

    .line 216
    .line 217
    if-nez v14, :cond_8

    .line 218
    .line 219
    move-object v14, v15

    .line 220
    :cond_8
    const-string v11, "github_token_enabled"

    .line 221
    .line 222
    invoke-interface {v6, v11, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 223
    .line 224
    .line 225
    move-result v11

    .line 226
    const-string v8, "github_token"

    .line 227
    .line 228
    move/from16 v18, v7

    .line 229
    .line 230
    const/4 v7, 0x0

    .line 231
    invoke-interface {v6, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object v8

    .line 235
    if-eqz v8, :cond_9

    .line 236
    .line 237
    move-object v15, v8

    .line 238
    :cond_9
    const-string v8, "notifications_enabled"

    .line 239
    .line 240
    const/4 v7, 0x0

    .line 241
    invoke-interface {v6, v8, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 242
    .line 243
    .line 244
    move-result v8

    .line 245
    const-string v7, "tile_long_click_target"

    .line 246
    .line 247
    move/from16 v19, v8

    .line 248
    .line 249
    const/4 v8, 0x0

    .line 250
    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v7

    .line 254
    sget-object v8, Lyt4;->i:Lzk2;

    .line 255
    .line 256
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 257
    .line 258
    .line 259
    invoke-static {v7}, Lzk2;->l(Ljava/lang/String;)Lyt4;

    .line 260
    .line 261
    .line 262
    move-result-object v7

    .line 263
    const-string v8, "notification_refresh_interval_seconds"

    .line 264
    .line 265
    move-object/from16 v20, v7

    .line 266
    .line 267
    const/4 v7, 0x5

    .line 268
    invoke-interface {v6, v8, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 269
    .line 270
    .line 271
    move-result v7

    .line 272
    const/16 v8, 0x14

    .line 273
    .line 274
    move-object/from16 v21, v9

    .line 275
    .line 276
    const/4 v9, 0x0

    .line 277
    invoke-static {v7, v9, v8}, Lej3;->v(III)I

    .line 278
    .line 279
    .line 280
    move-result v7

    .line 281
    const-string v8, "notification_title"

    .line 282
    .line 283
    const-string v9, "Box"

    .line 284
    .line 285
    invoke-virtual {v0, v8, v2, v9}, Lar;->K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 286
    .line 287
    .line 288
    move-result-object v2

    .line 289
    const-string v8, "notification_content"

    .line 290
    .line 291
    const-string v9, "{status} \u00b7 {uptime}\n\u2191 {upload} \u00b7 \u2193 {download}\nCPU {cpu} \u00b7 RAM {memory}"

    .line 292
    .line 293
    invoke-virtual {v0, v8, v3, v9}, Lar;->K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 294
    .line 295
    .line 296
    move-result-object v3

    .line 297
    const-string v8, "notification_click_target"

    .line 298
    .line 299
    const-string v9, "panel"

    .line 300
    .line 301
    invoke-interface {v6, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    move-result-object v8

    .line 305
    invoke-static {v8}, Lzk2;->l(Ljava/lang/String;)Lyt4;

    .line 306
    .line 307
    .line 308
    move-result-object v22

    .line 309
    const-string v8, "notification_action_reload"

    .line 310
    .line 311
    const/4 v9, 0x1

    .line 312
    invoke-interface {v6, v8, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 313
    .line 314
    .line 315
    move-result v23

    .line 316
    const-string v8, "notification_action_reload_title"

    .line 317
    .line 318
    const-string v9, "Reload"

    .line 319
    .line 320
    invoke-virtual {v0, v8, v4, v9}, Lar;->K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 321
    .line 322
    .line 323
    move-result-object v4

    .line 324
    const-string v8, "notification_action_reload_target"

    .line 325
    .line 326
    const-string v9, "reload"

    .line 327
    .line 328
    invoke-interface {v6, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 329
    .line 330
    .line 331
    move-result-object v8

    .line 332
    sget-object v9, Lxt4;->i:Lzk2;

    .line 333
    .line 334
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 335
    .line 336
    .line 337
    invoke-static {v8}, Lzk2;->k(Ljava/lang/String;)Lxt4;

    .line 338
    .line 339
    .line 340
    move-result-object v25

    .line 341
    const-string v8, "notification_action_stop"

    .line 342
    .line 343
    const/4 v9, 0x1

    .line 344
    invoke-interface {v6, v8, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 345
    .line 346
    .line 347
    move-result v26

    .line 348
    const-string v8, "notification_action_stop_title"

    .line 349
    .line 350
    const-string v9, "Stop"

    .line 351
    .line 352
    invoke-virtual {v0, v8, v5, v9}, Lar;->K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 353
    .line 354
    .line 355
    move-result-object v27

    .line 356
    const-string v5, "notification_action_stop_target"

    .line 357
    .line 358
    const-string v8, "stop"

    .line 359
    .line 360
    invoke-interface {v6, v5, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v5

    .line 364
    invoke-static {v5}, Lzk2;->k(Ljava/lang/String;)Lxt4;

    .line 365
    .line 366
    .line 367
    move-result-object v28

    .line 368
    const-string v5, "notification_action_restart"

    .line 369
    .line 370
    const/4 v9, 0x1

    .line 371
    invoke-interface {v6, v5, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 372
    .line 373
    .line 374
    move-result v29

    .line 375
    const-string v5, "notification_action_restart_title"

    .line 376
    .line 377
    const-string v8, "Restart"

    .line 378
    .line 379
    invoke-virtual {v0, v5, v1, v8}, Lar;->K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object v30

    .line 383
    const-string v0, "notification_action_restart_target"

    .line 384
    .line 385
    const-string v1, "restart"

    .line 386
    .line 387
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 388
    .line 389
    .line 390
    move-result-object v0

    .line 391
    invoke-static {v0}, Lzk2;->k(Ljava/lang/String;)Lxt4;

    .line 392
    .line 393
    .line 394
    move-result-object v31

    .line 395
    const-string v0, "open_panel_on_launch"

    .line 396
    .line 397
    const/4 v1, 0x0

    .line 398
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 399
    .line 400
    .line 401
    move-result v32

    .line 402
    const-string v0, "show_proxy_selector_bottom_bar_item"

    .line 403
    .line 404
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 405
    .line 406
    .line 407
    move-result v33

    .line 408
    const-string v0, "theme_mode"

    .line 409
    .line 410
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 411
    .line 412
    .line 413
    move-result v0

    .line 414
    if-ltz v0, :cond_a

    .line 415
    .line 416
    sget-object v1, Lvi7;->j:Lc42;

    .line 417
    .line 418
    invoke-virtual {v1}, Lc42;->a()I

    .line 419
    .line 420
    .line 421
    move-result v5

    .line 422
    if-ge v0, v5, :cond_a

    .line 423
    .line 424
    invoke-virtual {v1, v0}, Lc42;->get(I)Ljava/lang/Object;

    .line 425
    .line 426
    .line 427
    move-result-object v0

    .line 428
    goto :goto_4

    .line 429
    :cond_a
    sget-object v0, Lvi7;->h:Lvi7;

    .line 430
    .line 431
    :goto_4
    move-object/from16 v34, v0

    .line 432
    .line 433
    check-cast v34, Lvi7;

    .line 434
    .line 435
    const-string v0, "pure_black_dark_theme"

    .line 436
    .line 437
    const/4 v1, 0x0

    .line 438
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 439
    .line 440
    .line 441
    move-result v35

    .line 442
    const-string v0, "miuix_monet_enabled"

    .line 443
    .line 444
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 445
    .line 446
    .line 447
    move-result v36

    .line 448
    const-string v0, "accent_color"

    .line 449
    .line 450
    const v1, -0xb050b0

    .line 451
    .line 452
    .line 453
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 454
    .line 455
    .line 456
    move-result v37

    .line 457
    const-string v0, "accent_use_default"

    .line 458
    .line 459
    const/4 v9, 0x1

    .line 460
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 461
    .line 462
    .line 463
    move-result v38

    .line 464
    const-string v0, "theme_palette_style"

    .line 465
    .line 466
    const/4 v8, 0x0

    .line 467
    invoke-interface {v6, v0, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object v0

    .line 471
    sget-object v1, Lxi7;->h:Lwd6;

    .line 472
    .line 473
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 474
    .line 475
    .line 476
    sget-object v1, Lxi7;->l:Lc42;

    .line 477
    .line 478
    invoke-virtual {v1}, Lq3;->iterator()Ljava/util/Iterator;

    .line 479
    .line 480
    .line 481
    move-result-object v1

    .line 482
    :cond_b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 483
    .line 484
    .line 485
    move-result v5

    .line 486
    if-eqz v5, :cond_c

    .line 487
    .line 488
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 489
    .line 490
    .line 491
    move-result-object v5

    .line 492
    move-object v8, v5

    .line 493
    check-cast v8, Lxi7;

    .line 494
    .line 495
    invoke-virtual {v8}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 496
    .line 497
    .line 498
    move-result-object v8

    .line 499
    invoke-static {v8, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 500
    .line 501
    .line 502
    move-result v8

    .line 503
    if-eqz v8, :cond_b

    .line 504
    .line 505
    goto :goto_5

    .line 506
    :cond_c
    const/4 v5, 0x0

    .line 507
    :goto_5
    check-cast v5, Lxi7;

    .line 508
    .line 509
    if-nez v5, :cond_d

    .line 510
    .line 511
    sget-object v5, Lxi7;->i:Lxi7;

    .line 512
    .line 513
    :cond_d
    move-object/from16 v39, v5

    .line 514
    .line 515
    const-string v0, "theme_color_spec"

    .line 516
    .line 517
    const/4 v8, 0x0

    .line 518
    invoke-interface {v6, v0, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 519
    .line 520
    .line 521
    move-result-object v0

    .line 522
    sget-object v1, Lri7;->h:Lwd6;

    .line 523
    .line 524
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 525
    .line 526
    .line 527
    sget-object v1, Lri7;->m:Lc42;

    .line 528
    .line 529
    invoke-virtual {v1}, Lq3;->iterator()Ljava/util/Iterator;

    .line 530
    .line 531
    .line 532
    move-result-object v1

    .line 533
    :cond_e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 534
    .line 535
    .line 536
    move-result v5

    .line 537
    if-eqz v5, :cond_f

    .line 538
    .line 539
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 540
    .line 541
    .line 542
    move-result-object v5

    .line 543
    move-object v8, v5

    .line 544
    check-cast v8, Lri7;

    .line 545
    .line 546
    invoke-virtual {v8}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 547
    .line 548
    .line 549
    move-result-object v8

    .line 550
    invoke-static {v8, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 551
    .line 552
    .line 553
    move-result v8

    .line 554
    if-eqz v8, :cond_e

    .line 555
    .line 556
    goto :goto_6

    .line 557
    :cond_f
    const/4 v5, 0x0

    .line 558
    :goto_6
    check-cast v5, Lri7;

    .line 559
    .line 560
    if-nez v5, :cond_10

    .line 561
    .line 562
    sget-object v5, Lri7;->i:Lri7;

    .line 563
    .line 564
    :cond_10
    move-object/from16 v40, v5

    .line 565
    .line 566
    const-string v0, "enable_blur"

    .line 567
    .line 568
    const/4 v9, 0x1

    .line 569
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 570
    .line 571
    .line 572
    move-result v41

    .line 573
    const-string v0, "top_bar_style"

    .line 574
    .line 575
    const/4 v8, 0x0

    .line 576
    invoke-interface {v6, v0, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 577
    .line 578
    .line 579
    move-result-object v0

    .line 580
    sget-object v1, Lmn7;->h:Luk7;

    .line 581
    .line 582
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 583
    .line 584
    .line 585
    sget-object v1, Lmn7;->l:Lc42;

    .line 586
    .line 587
    invoke-virtual {v1}, Lq3;->iterator()Ljava/util/Iterator;

    .line 588
    .line 589
    .line 590
    move-result-object v1

    .line 591
    :cond_11
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 592
    .line 593
    .line 594
    move-result v5

    .line 595
    if-eqz v5, :cond_12

    .line 596
    .line 597
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 598
    .line 599
    .line 600
    move-result-object v5

    .line 601
    move-object v8, v5

    .line 602
    check-cast v8, Lmn7;

    .line 603
    .line 604
    invoke-virtual {v8}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 605
    .line 606
    .line 607
    move-result-object v8

    .line 608
    invoke-static {v8, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 609
    .line 610
    .line 611
    move-result v8

    .line 612
    if-eqz v8, :cond_11

    .line 613
    .line 614
    goto :goto_7

    .line 615
    :cond_12
    const/4 v5, 0x0

    .line 616
    :goto_7
    check-cast v5, Lmn7;

    .line 617
    .line 618
    if-nez v5, :cond_13

    .line 619
    .line 620
    sget-object v5, Lmn7;->i:Lmn7;

    .line 621
    .line 622
    :cond_13
    move-object/from16 v42, v5

    .line 623
    .line 624
    const-string v0, "bottom_bar_style"

    .line 625
    .line 626
    const/4 v8, 0x0

    .line 627
    invoke-interface {v6, v0, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 628
    .line 629
    .line 630
    move-result-object v0

    .line 631
    sget-object v1, Lh60;->i:Lh60;

    .line 632
    .line 633
    if-eqz v0, :cond_17

    .line 634
    .line 635
    sget-object v5, Lh60;->h:Ls38;

    .line 636
    .line 637
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 638
    .line 639
    .line 640
    sget-object v5, Lh60;->n:Lc42;

    .line 641
    .line 642
    invoke-virtual {v5}, Lq3;->iterator()Ljava/util/Iterator;

    .line 643
    .line 644
    .line 645
    move-result-object v5

    .line 646
    :cond_14
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 647
    .line 648
    .line 649
    move-result v8

    .line 650
    if-eqz v8, :cond_15

    .line 651
    .line 652
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 653
    .line 654
    .line 655
    move-result-object v8

    .line 656
    move-object v9, v8

    .line 657
    check-cast v9, Lh60;

    .line 658
    .line 659
    invoke-virtual {v9}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 660
    .line 661
    .line 662
    move-result-object v9

    .line 663
    invoke-static {v9, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 664
    .line 665
    .line 666
    move-result v9

    .line 667
    if-eqz v9, :cond_14

    .line 668
    .line 669
    goto :goto_8

    .line 670
    :cond_15
    const/4 v8, 0x0

    .line 671
    :goto_8
    check-cast v8, Lh60;

    .line 672
    .line 673
    if-nez v8, :cond_16

    .line 674
    .line 675
    move-object/from16 v43, v1

    .line 676
    .line 677
    :goto_9
    const/4 v9, 0x0

    .line 678
    goto :goto_b

    .line 679
    :cond_16
    move-object/from16 v43, v8

    .line 680
    .line 681
    goto :goto_9

    .line 682
    :cond_17
    const-string v0, "floating_bottom_bar"

    .line 683
    .line 684
    const/4 v9, 0x0

    .line 685
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 686
    .line 687
    .line 688
    move-result v0

    .line 689
    if-nez v0, :cond_18

    .line 690
    .line 691
    :goto_a
    move-object/from16 v43, v1

    .line 692
    .line 693
    goto :goto_b

    .line 694
    :cond_18
    const-string v0, "floating_bottom_bar_blur"

    .line 695
    .line 696
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 697
    .line 698
    .line 699
    move-result v0

    .line 700
    if-eqz v0, :cond_19

    .line 701
    .line 702
    sget-object v1, Lh60;->k:Lh60;

    .line 703
    .line 704
    goto :goto_a

    .line 705
    :cond_19
    sget-object v1, Lh60;->j:Lh60;

    .line 706
    .line 707
    goto :goto_a

    .line 708
    :goto_b
    const-string v0, "landscape_glass_navigation"

    .line 709
    .line 710
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 711
    .line 712
    .line 713
    move-result v44

    .line 714
    const-string v0, "enable_predictive_back_animation"

    .line 715
    .line 716
    const/4 v1, 0x1

    .line 717
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 718
    .line 719
    .line 720
    move-result v45

    .line 721
    const-string v0, "predictive_back_animation_follow_edge"

    .line 722
    .line 723
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 724
    .line 725
    .line 726
    move-result v46

    .line 727
    const-string v0, "enable_swipe_back"

    .line 728
    .line 729
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 730
    .line 731
    .line 732
    move-result v47

    .line 733
    const-string v0, "use_net_speed_clash_api"

    .line 734
    .line 735
    invoke-interface {v6, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 736
    .line 737
    .line 738
    move-result v48

    .line 739
    const-string v0, "speed_test_source"

    .line 740
    .line 741
    const/4 v8, 0x0

    .line 742
    invoke-interface {v6, v0, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 743
    .line 744
    .line 745
    move-result-object v0

    .line 746
    sget-object v1, Lcy6;->i:Lwd6;

    .line 747
    .line 748
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 749
    .line 750
    .line 751
    sget-object v1, Lcy6;->n:Lc42;

    .line 752
    .line 753
    invoke-virtual {v1}, Lq3;->iterator()Ljava/util/Iterator;

    .line 754
    .line 755
    .line 756
    move-result-object v1

    .line 757
    :cond_1a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 758
    .line 759
    .line 760
    move-result v5

    .line 761
    if-eqz v5, :cond_1b

    .line 762
    .line 763
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 764
    .line 765
    .line 766
    move-result-object v5

    .line 767
    move-object v9, v5

    .line 768
    check-cast v9, Lcy6;

    .line 769
    .line 770
    iget-object v9, v9, Lcy6;->h:Ljava/lang/String;

    .line 771
    .line 772
    invoke-virtual {v9, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 773
    .line 774
    .line 775
    move-result v9

    .line 776
    if-eqz v9, :cond_1a

    .line 777
    .line 778
    goto :goto_c

    .line 779
    :cond_1b
    move-object v5, v8

    .line 780
    :goto_c
    check-cast v5, Lcy6;

    .line 781
    .line 782
    if-nez v5, :cond_1c

    .line 783
    .line 784
    sget-object v5, Lcy6;->j:Lcy6;

    .line 785
    .line 786
    :cond_1c
    move-object/from16 v49, v5

    .line 787
    .line 788
    const-string v0, "speed_test_use_megabytes"

    .line 789
    .line 790
    const/4 v1, 0x0

    .line 791
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 792
    .line 793
    .line 794
    move-result v50

    .line 795
    const-string v0, "use_subscription_detail_clash_api"

    .line 796
    .line 797
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 798
    .line 799
    .line 800
    move-result v51

    .line 801
    const-string v0, "page_scale"

    .line 802
    .line 803
    const/high16 v5, 0x3f800000    # 1.0f

    .line 804
    .line 805
    invoke-interface {v6, v0, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    .line 806
    .line 807
    .line 808
    move-result v0

    .line 809
    const v5, 0x3f4ccccd    # 0.8f

    .line 810
    .line 811
    .line 812
    const v8, 0x3f99999a    # 1.2f

    .line 813
    .line 814
    .line 815
    invoke-static {v0, v5, v8}, Lej3;->u(FFF)F

    .line 816
    .line 817
    .line 818
    move-result v52

    .line 819
    const-string v0, "welcome_onboarding_shown"

    .line 820
    .line 821
    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 822
    .line 823
    .line 824
    move-result v53

    .line 825
    new-instance v8, Lvv;

    .line 826
    .line 827
    move-object/from16 v24, v4

    .line 828
    .line 829
    move-object/from16 v16, v15

    .line 830
    .line 831
    move/from16 v17, v19

    .line 832
    .line 833
    move-object/from16 v9, v21

    .line 834
    .line 835
    move-object/from16 v21, v3

    .line 836
    .line 837
    move/from16 v19, v7

    .line 838
    .line 839
    move v15, v11

    .line 840
    move-object v11, v12

    .line 841
    move/from16 v12, v18

    .line 842
    .line 843
    move-object/from16 v18, v20

    .line 844
    .line 845
    move-object/from16 v20, v2

    .line 846
    .line 847
    invoke-direct/range {v8 .. v53}, Lvv;-><init>(Lss7;Los;Liy2;ZZLjava/lang/String;ZLjava/lang/String;ZLyt4;ILjava/lang/String;Ljava/lang/String;Lyt4;ZLjava/lang/String;Lxt4;ZLjava/lang/String;Lxt4;ZLjava/lang/String;Lxt4;ZZLvi7;ZZIZLxi7;Lri7;ZLmn7;Lh60;ZZZZZLcy6;ZZFZ)V

    .line 848
    .line 849
    .line 850
    return-object v8
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
.end method

.method public w(Landroid/util/AttributeSet;I)V
    .locals 8

    .line 1
    iget-byte v0, p0, Lar;->h:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Landroid/widget/EditText;

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sget-object v3, Ljt5;->i:[I

    .line 17
    .line 18
    invoke-virtual {v0, p1, v3, p2, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const/16 p2, 0xe

    .line 23
    .line 24
    :try_start_0
    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    invoke-virtual {p1, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 31
    .line 32
    .line 33
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    :cond_0
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p0, v1}, Lar;->H(Z)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :catchall_0
    move-exception p0

    .line 42
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 43
    .line 44
    .line 45
    throw p0

    .line 46
    :pswitch_0
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v0, Landroid/widget/AbsSeekBar;

    .line 49
    .line 50
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    sget-object v4, Lar;->k:[I

    .line 55
    .line 56
    invoke-static {v3, p1, v4, p2}, Lnd6;->n(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lnd6;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-virtual {p1, v2}, Lnd6;->i(I)Landroid/graphics/drawable/Drawable;

    .line 61
    .line 62
    .line 63
    move-result-object p2

    .line 64
    if-eqz p2, :cond_3

    .line 65
    .line 66
    instance-of v3, p2, Landroid/graphics/drawable/AnimationDrawable;

    .line 67
    .line 68
    if-eqz v3, :cond_2

    .line 69
    .line 70
    check-cast p2, Landroid/graphics/drawable/AnimationDrawable;

    .line 71
    .line 72
    invoke-virtual {p2}, Landroid/graphics/drawable/AnimationDrawable;->getNumberOfFrames()I

    .line 73
    .line 74
    .line 75
    move-result v3

    .line 76
    new-instance v4, Landroid/graphics/drawable/AnimationDrawable;

    .line 77
    .line 78
    invoke-direct {v4}, Landroid/graphics/drawable/AnimationDrawable;-><init>()V

    .line 79
    .line 80
    .line 81
    invoke-virtual {p2}, Landroid/graphics/drawable/AnimationDrawable;->isOneShot()Z

    .line 82
    .line 83
    .line 84
    move-result v5

    .line 85
    invoke-virtual {v4, v5}, Landroid/graphics/drawable/AnimationDrawable;->setOneShot(Z)V

    .line 86
    .line 87
    .line 88
    move v5, v2

    .line 89
    :goto_0
    const/16 v6, 0x2710

    .line 90
    .line 91
    if-ge v5, v3, :cond_1

    .line 92
    .line 93
    invoke-virtual {p2, v5}, Landroid/graphics/drawable/AnimationDrawable;->getFrame(I)Landroid/graphics/drawable/Drawable;

    .line 94
    .line 95
    .line 96
    move-result-object v7

    .line 97
    invoke-virtual {p0, v7, v1}, Lar;->L(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;

    .line 98
    .line 99
    .line 100
    move-result-object v7

    .line 101
    invoke-virtual {v7, v6}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 102
    .line 103
    .line 104
    invoke-virtual {p2, v5}, Landroid/graphics/drawable/AnimationDrawable;->getDuration(I)I

    .line 105
    .line 106
    .line 107
    move-result v6

    .line 108
    invoke-virtual {v4, v7, v6}, Landroid/graphics/drawable/AnimationDrawable;->addFrame(Landroid/graphics/drawable/Drawable;I)V

    .line 109
    .line 110
    .line 111
    add-int/lit8 v5, v5, 0x1

    .line 112
    .line 113
    goto :goto_0

    .line 114
    :cond_1
    invoke-virtual {v4, v6}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 115
    .line 116
    .line 117
    move-object p2, v4

    .line 118
    :cond_2
    invoke-virtual {v0, p2}, Landroid/widget/ProgressBar;->setIndeterminateDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 119
    .line 120
    .line 121
    :cond_3
    invoke-virtual {p1, v1}, Lnd6;->i(I)Landroid/graphics/drawable/Drawable;

    .line 122
    .line 123
    .line 124
    move-result-object p2

    .line 125
    if-eqz p2, :cond_4

    .line 126
    .line 127
    invoke-virtual {p0, p2, v2}, Lar;->L(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;

    .line 128
    .line 129
    .line 130
    move-result-object p0

    .line 131
    invoke-virtual {v0, p0}, Landroid/widget/ProgressBar;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 132
    .line 133
    .line 134
    :cond_4
    invoke-virtual {p1}, Lnd6;->p()V

    .line 135
    .line 136
    .line 137
    return-void

    .line 138
    nop

    .line 139
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
.end method

.method public final x(J)Landroid/view/autofill/AutofillId;
    .locals 1

    .line 1
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/contentcapture/ContentCaptureSession;

    .line 4
    .line 5
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Landroid/view/View;

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getAutofillId()Landroid/view/autofill/AutofillId;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {v0, p0, p1, p2}, Landroid/view/contentcapture/ContentCaptureSession;->newAutofillId(Landroid/view/autofill/AutofillId;J)Landroid/view/autofill/AutofillId;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final y(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)Lt12;
    .locals 1

    .line 1
    iget-object p0, p0, Lar;->j:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lar;

    .line 4
    .line 5
    if-nez p1, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    return-object p0

    .line 9
    :cond_0
    instance-of v0, p1, Lt12;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    check-cast p1, Lt12;

    .line 14
    .line 15
    return-object p1

    .line 16
    :cond_1
    new-instance v0, Lt12;

    .line 17
    .line 18
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p0, Landroid/widget/EditText;

    .line 21
    .line 22
    invoke-direct {v0, p2, p1, p0}, Lt12;-><init>(Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;Landroid/widget/TextView;)V

    .line 23
    .line 24
    .line 25
    return-object v0
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final z(Lq6;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lar;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lq21;

    .line 4
    .line 5
    iget-object v1, v0, Lq21;->i:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Landroid/view/ActionMode$Callback;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Lq21;->m(Lq6;)Li57;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-interface {v1, p1}, Landroid/view/ActionMode$Callback;->onDestroyActionMode(Landroid/view/ActionMode;)V

    .line 14
    .line 15
    .line 16
    iget-object p1, p0, Lar;->j:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p1, Lpq;

    .line 19
    .line 20
    iget-object v0, p1, Lpq;->C:Landroid/widget/PopupWindow;

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    iget-object v0, p1, Lpq;->s:Landroid/view/Window;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iget-object v1, p1, Lpq;->D:Lfq;

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 33
    .line 34
    .line 35
    :cond_0
    iget-object v0, p1, Lpq;->B:Landroidx/appcompat/widget/ActionBarContextView;

    .line 36
    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    iget-object v0, p1, Lpq;->E:Ljy7;

    .line 40
    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    invoke-virtual {v0}, Ljy7;->b()V

    .line 44
    .line 45
    .line 46
    :cond_1
    iget-object v0, p1, Lpq;->B:Landroidx/appcompat/widget/ActionBarContextView;

    .line 47
    .line 48
    invoke-static {v0}, Lox7;->a(Landroid/view/View;)Ljy7;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    const/4 v1, 0x0

    .line 53
    invoke-virtual {v0, v1}, Ljy7;->a(F)V

    .line 54
    .line 55
    .line 56
    iput-object v0, p1, Lpq;->E:Ljy7;

    .line 57
    .line 58
    new-instance v1, Liq;

    .line 59
    .line 60
    const/4 v2, 0x2

    .line 61
    invoke-direct {v1, p0, v2}, Liq;-><init>(Ljava/lang/Object;B)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0, v1}, Ljy7;->d(Lmy7;)V

    .line 65
    .line 66
    .line 67
    :cond_2
    const/4 p0, 0x0

    .line 68
    iput-object p0, p1, Lpq;->A:Lq6;

    .line 69
    .line 70
    iget-object p0, p1, Lpq;->G:Landroid/view/ViewGroup;

    .line 71
    .line 72
    sget-object v0, Lox7;->a:Ljava/util/WeakHashMap;

    .line 73
    .line 74
    invoke-virtual {p0}, Landroid/view/View;->requestApplyInsets()V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p1}, Lpq;->L()V

    .line 78
    .line 79
    .line 80
    return-void
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method
