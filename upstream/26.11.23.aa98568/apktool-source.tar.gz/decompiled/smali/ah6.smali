.class public final Lah6;
.super Lab4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lqi3;
.implements Lcl6;


# instance fields
.field public v:Leh6;

.field public w:Z


# virtual methods
.method public final R0(Lll6;)V
    .locals 4

    .line 1
    invoke-static {p1}, Ljl6;->o(Lll6;)V

    .line 2
    .line 3
    .line 4
    new-instance v0, Llg6;

    .line 5
    .line 6
    new-instance v1, Lzg6;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-direct {v1, p0, v2}, Lzg6;-><init>(Lah6;B)V

    .line 10
    .line 11
    .line 12
    new-instance v2, Lzg6;

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    invoke-direct {v2, p0, v3}, Lzg6;-><init>(Lah6;B)V

    .line 16
    .line 17
    .line 18
    invoke-direct {v0, v1, v2}, Llg6;-><init>(Llh2;Llh2;)V

    .line 19
    .line 20
    .line 21
    iget-boolean p0, p0, Lah6;->w:Z

    .line 22
    .line 23
    if-eqz p0, :cond_0

    .line 24
    .line 25
    sget-object p0, Lil6;->x:Lkl6;

    .line 26
    .line 27
    sget-object v1, Ljl6;->a:[Ldg3;

    .line 28
    .line 29
    const/16 v2, 0xf

    .line 30
    .line 31
    aget-object v1, v1, v2

    .line 32
    .line 33
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    invoke-interface {p1, p0, v0}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :cond_0
    sget-object p0, Lil6;->w:Lkl6;

    .line 41
    .line 42
    sget-object v1, Ljl6;->a:[Ldg3;

    .line 43
    .line 44
    const/16 v2, 0xe

    .line 45
    .line 46
    aget-object v1, v1, v2

    .line 47
    .line 48
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-interface {p1, p0, v0}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public final c(Lcx3;Lp14;I)I
    .locals 0

    .line 1
    iget-boolean p0, p0, Lah6;->w:Z

    .line 2
    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    const p3, 0x7fffffff

    .line 6
    .line 7
    .line 8
    :cond_0
    invoke-interface {p2, p3}, Lp14;->h0(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0
.end method

.method public final e(Lcx3;Lp14;I)I
    .locals 0

    .line 1
    iget-boolean p0, p0, Lah6;->w:Z

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    const p3, 0x7fffffff

    .line 6
    .line 7
    .line 8
    :cond_0
    invoke-interface {p2, p3}, Lp14;->f(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0
.end method

.method public final i(Lcx3;Lp14;I)I
    .locals 0

    .line 1
    iget-boolean p0, p0, Lah6;->w:Z

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    const p3, 0x7fffffff

    .line 6
    .line 7
    .line 8
    :cond_0
    invoke-interface {p2, p3}, Lp14;->i0(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0
.end method

.method public final l(Lcx3;Lp14;I)I
    .locals 0

    .line 1
    iget-boolean p0, p0, Lah6;->w:Z

    .line 2
    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    const p3, 0x7fffffff

    .line 6
    .line 7
    .line 8
    :cond_0
    invoke-interface {p2, p3}, Lp14;->S(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0
.end method

.method public final m(Ly14;Lp14;J)Lv14;
    .locals 9

    .line 1
    iget-boolean v0, p0, Lah6;->w:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    sget-object v0, Ld05;->h:Ld05;

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    sget-object v0, Ld05;->i:Ld05;

    .line 9
    .line 10
    :goto_0
    invoke-static {p3, p4, v0}, Lrx;->g(JLd05;)V

    .line 11
    .line 12
    .line 13
    iget-boolean v0, p0, Lah6;->w:Z

    .line 14
    .line 15
    const v1, 0x7fffffff

    .line 16
    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    move v7, v1

    .line 21
    goto :goto_1

    .line 22
    :cond_1
    invoke-static {p3, p4}, Ljb1;->h(J)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    move v7, v0

    .line 27
    :goto_1
    iget-boolean v0, p0, Lah6;->w:Z

    .line 28
    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    invoke-static {p3, p4}, Ljb1;->i(J)I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    :cond_2
    move v5, v1

    .line 36
    const/4 v6, 0x0

    .line 37
    const/4 v8, 0x5

    .line 38
    const/4 v4, 0x0

    .line 39
    move-wide v2, p3

    .line 40
    invoke-static/range {v2 .. v8}, Ljb1;->b(JIIIII)J

    .line 41
    .line 42
    .line 43
    move-result-wide p3

    .line 44
    invoke-interface {p2, p3, p4}, Lp14;->e(J)Lfb5;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    iget p3, p2, Lfb5;->h:I

    .line 49
    .line 50
    invoke-static {v2, v3}, Ljb1;->i(J)I

    .line 51
    .line 52
    .line 53
    move-result p4

    .line 54
    if-le p3, p4, :cond_3

    .line 55
    .line 56
    move p3, p4

    .line 57
    :cond_3
    iget p4, p2, Lfb5;->i:I

    .line 58
    .line 59
    invoke-static {v2, v3}, Ljb1;->h(J)I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-le p4, v0, :cond_4

    .line 64
    .line 65
    move p4, v0

    .line 66
    :cond_4
    iget v0, p2, Lfb5;->i:I

    .line 67
    .line 68
    sub-int/2addr v0, p4

    .line 69
    iget v1, p2, Lfb5;->h:I

    .line 70
    .line 71
    sub-int/2addr v1, p3

    .line 72
    iget-boolean v2, p0, Lah6;->w:Z

    .line 73
    .line 74
    if-nez v2, :cond_5

    .line 75
    .line 76
    move v0, v1

    .line 77
    :cond_5
    iget-object v1, p0, Lah6;->v:Leh6;

    .line 78
    .line 79
    invoke-virtual {v1, v0}, Leh6;->i(I)V

    .line 80
    .line 81
    .line 82
    iget-object v1, p0, Lah6;->v:Leh6;

    .line 83
    .line 84
    iget-boolean v2, p0, Lah6;->w:Z

    .line 85
    .line 86
    if-eqz v2, :cond_6

    .line 87
    .line 88
    move v2, p4

    .line 89
    goto :goto_2

    .line 90
    :cond_6
    move v2, p3

    .line 91
    :goto_2
    iget-object v1, v1, Leh6;->i:Lw75;

    .line 92
    .line 93
    invoke-virtual {v1, v2}, Lw75;->i(I)V

    .line 94
    .line 95
    .line 96
    iget-object v1, p0, Lah6;->v:Leh6;

    .line 97
    .line 98
    iget-boolean v2, p0, Lah6;->w:Z

    .line 99
    .line 100
    if-eqz v2, :cond_7

    .line 101
    .line 102
    iget v2, p2, Lfb5;->i:I

    .line 103
    .line 104
    goto :goto_3

    .line 105
    :cond_7
    iget v2, p2, Lfb5;->h:I

    .line 106
    .line 107
    :goto_3
    iget-object v1, v1, Leh6;->j:Lw75;

    .line 108
    .line 109
    invoke-virtual {v1, v2}, Lw75;->i(I)V

    .line 110
    .line 111
    .line 112
    iget-object v1, p0, Lah6;->v:Leh6;

    .line 113
    .line 114
    iget-object v1, v1, Leh6;->k:Lz75;

    .line 115
    .line 116
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 117
    .line 118
    invoke-virtual {v1, v2}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    new-instance v1, Lg04;

    .line 122
    .line 123
    const/4 v2, 0x2

    .line 124
    invoke-direct {v1, p0, v0, p2, v2}, Lg04;-><init>(Ljava/lang/Object;ILjava/lang/Object;B)V

    .line 125
    .line 126
    .line 127
    sget-object p0, Lp22;->h:Lp22;

    .line 128
    .line 129
    invoke-interface {p1, p3, p4, p0, v1}, Ly14;->P0(IILjava/util/Map;Lwh2;)Lv14;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    return-object p0
.end method
