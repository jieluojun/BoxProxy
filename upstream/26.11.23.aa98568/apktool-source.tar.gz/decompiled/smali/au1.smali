.class public interface abstract Lau1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public abstract M(Ltt1;)V
.end method

.method public abstract O(Ltt1;)V
.end method

.method public abstract f1(Ltt1;)Z
.end method

.method public abstract i0(Ltt1;)V
.end method

.method public abstract k0(Ltt1;)V
.end method

.method public abstract p0(Ltt1;)V
.end method
