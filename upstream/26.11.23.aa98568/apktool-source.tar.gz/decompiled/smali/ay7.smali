.class public final Lay7;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Lnt0;

.field public final b:Lg34;


# direct methods
.method public constructor <init>(Lnt0;Lg34;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lay7;->a:Lnt0;

    .line 5
    .line 6
    iput-object p2, p0, Lay7;->b:Lg34;

    .line 7
    .line 8
    return-void
.end method
