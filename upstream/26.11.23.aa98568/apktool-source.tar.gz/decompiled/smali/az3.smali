.class public final Laz3;
.super Lex7;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Ltt4;


# instance fields
.field public final q:Z

.field public final r:Luj0;

.field public final s:Luj0;

.field public final t:Luj0;

.field public final u:Luj0;

.field public final v:Lez3;


# direct methods
.method public constructor <init>(Lv02;Lg61;Lrf5;Lw80;ZLuj0;Luj0;Luj0;Luj0;Lez3;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0, p3}, Li61;-><init>(Lv02;Lf61;Landroid/graphics/Matrix;Lrf5;)V

    .line 3
    .line 4
    .line 5
    iput-object p4, p0, Lex7;->p:Lw80;

    .line 6
    .line 7
    iput-boolean p5, p0, Laz3;->q:Z

    .line 8
    .line 9
    iput-object p6, p0, Laz3;->r:Luj0;

    .line 10
    .line 11
    iput-object p7, p0, Laz3;->s:Luj0;

    .line 12
    .line 13
    iput-object p8, p0, Laz3;->t:Luj0;

    .line 14
    .line 15
    iput-object p9, p0, Laz3;->u:Luj0;

    .line 16
    .line 17
    iput-object p10, p0, Laz3;->v:Lez3;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final q()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "marker"

    .line 2
    .line 3
    return-object p0
.end method
