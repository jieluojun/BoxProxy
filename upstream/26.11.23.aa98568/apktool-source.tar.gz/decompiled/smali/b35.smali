.class public final synthetic Lb35;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ler0;

.field public final synthetic j:Z

.field public final synthetic k:Lwh2;


# direct methods
.method public synthetic constructor <init>(Ler0;ZLwh2;IB)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lb35;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lb35;->i:Ler0;

    .line 4
    .line 5
    iput-boolean p2, p0, Lb35;->j:Z

    .line 6
    .line 7
    iput-object p3, p0, Lb35;->k:Lwh2;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lb35;->h:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    iget-object v3, p0, Lb35;->k:Lwh2;

    .line 7
    .line 8
    iget-boolean v4, p0, Lb35;->j:Z

    .line 9
    .line 10
    iget-object p0, p0, Lb35;->i:Ler0;

    .line 11
    .line 12
    check-cast p1, Lzi2;

    .line 13
    .line 14
    check-cast p2, Ljava/lang/Integer;

    .line 15
    .line 16
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    packed-switch v0, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 23
    .line 24
    .line 25
    move-result p2

    .line 26
    invoke-static {p0, v4, v3, p1, p2}, Lmk3;->s(Ler0;ZLwh2;Lzi2;I)V

    .line 27
    .line 28
    .line 29
    return-object v1

    .line 30
    :pswitch_0
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 31
    .line 32
    .line 33
    move-result p2

    .line 34
    invoke-static {p0, v4, v3, p1, p2}, Lck3;->t(Ler0;ZLwh2;Lzi2;I)V

    .line 35
    .line 36
    .line 37
    return-object v1

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
