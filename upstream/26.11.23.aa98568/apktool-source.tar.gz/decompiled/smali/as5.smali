.class public abstract Las5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:Lbi7;


# direct methods
.method static constructor <clinit>()V
    .locals 14

    .line 1
    const-string v0, "Refreshing..."

    .line 2
    .line 3
    const-string v1, "Refreshed successfully"

    .line 4
    .line 5
    const-string v2, "Pull down to refresh"

    .line 6
    .line 7
    const-string v3, "Release to refresh"

    .line 8
    .line 9
    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v0}, Lix;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    const/16 v0, 0xe

    .line 17
    .line 18
    invoke-static {v0}, Lfa7;->f(I)J

    .line 19
    .line 20
    .line 21
    move-result-wide v4

    .line 22
    sget-object v6, Lhg2;->m:Lhg2;

    .line 23
    .line 24
    new-instance v1, Lbi7;

    .line 25
    .line 26
    const-wide/16 v11, 0x0

    .line 27
    .line 28
    const v13, 0xfffff8

    .line 29
    .line 30
    .line 31
    const-wide v2, -0x77777800000000L

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    const-wide/16 v7, 0x0

    .line 37
    .line 38
    const/4 v9, 0x0

    .line 39
    const/4 v10, 0x0

    .line 40
    invoke-direct/range {v1 .. v13}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 41
    .line 42
    .line 43
    sput-object v1, Las5;->a:Lbi7;

    .line 44
    .line 45
    return-void
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method
