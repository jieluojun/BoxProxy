.class public final Lan2;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public l:Z

.field public final synthetic m:Lrg;

.field public final synthetic n:F

.field public final synthetic o:Z


# direct methods
.method public constructor <init>(Lrg;FZLxd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lan2;->m:Lrg;

    .line 2
    .line 3
    iput p2, p0, Lan2;->n:F

    .line 4
    .line 5
    iput-boolean p3, p0, Lan2;->o:Z

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lt57;-><init>(ILxd1;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ljj1;

    .line 2
    .line 3
    check-cast p2, Lxd1;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, Lan2;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lan2;

    .line 10
    .line 11
    sget-object p1, Lst7;->a:Lst7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lan2;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final s(Lxd1;Ljava/lang/Object;)Lxd1;
    .locals 2

    .line 1
    new-instance p2, Lan2;

    .line 2
    .line 3
    iget v0, p0, Lan2;->n:F

    .line 4
    .line 5
    iget-boolean v1, p0, Lan2;->o:Z

    .line 6
    .line 7
    iget-object p0, p0, Lan2;->m:Lrg;

    .line 8
    .line 9
    invoke-direct {p2, p0, v0, v1, p1}, Lan2;-><init>(Lrg;FZLxd1;)V

    .line 10
    .line 11
    .line 12
    return-object p2
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-boolean v0, p0, Lan2;->l:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_2

    .line 12
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 13
    .line 14
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    return-object p0

    .line 19
    :cond_1
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    move p1, v1

    .line 23
    new-instance v1, Ljava/lang/Float;

    .line 24
    .line 25
    iget v0, p0, Lan2;->n:F

    .line 26
    .line 27
    invoke-direct {v1, v0}, Ljava/lang/Float;-><init>(F)V

    .line 28
    .line 29
    .line 30
    iget-boolean v0, p0, Lan2;->o:Z

    .line 31
    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    sget-object v0, Lgn2;->f:Lqp7;

    .line 35
    .line 36
    :goto_0
    move-object v2, v0

    .line 37
    goto :goto_1

    .line 38
    :cond_2
    sget-object v0, Lgn2;->g:Lqp7;

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :goto_1
    iput-boolean p1, p0, Lan2;->l:Z

    .line 42
    .line 43
    iget-object v0, p0, Lan2;->m:Lrg;

    .line 44
    .line 45
    const/4 v3, 0x0

    .line 46
    const/4 v4, 0x0

    .line 47
    const/16 v6, 0xc

    .line 48
    .line 49
    move-object v5, p0

    .line 50
    invoke-static/range {v0 .. v6}, Lrg;->b(Lrg;Ljava/lang/Object;Lvi;Ljava/lang/Float;Lwh2;Lxd1;I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    sget-object p1, Lkj1;->h:Lkj1;

    .line 55
    .line 56
    if-ne p0, p1, :cond_3

    .line 57
    .line 58
    return-object p1

    .line 59
    :cond_3
    :goto_2
    sget-object p0, Lst7;->a:Lst7;

    .line 60
    .line 61
    return-object p0
.end method
