.class public final La26;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lxi1;
.implements Loh7;


# instance fields
.field public h:F

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lqh7;Llh7;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La26;->j:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, La26;->i:Ljava/lang/Object;

    .line 7
    .line 8
    const/4 p1, 0x0

    .line 9
    iput p1, p0, La26;->h:F

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public constructor <init>(Lxi1;Lxi1;F)V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object p1, p0, La26;->i:Ljava/lang/Object;

    iput-object p2, p0, La26;->j:Ljava/lang/Object;

    iput p3, p0, La26;->h:F

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/ArrayList;ZLh93;)Z
    .locals 8

    .line 1
    iget-object v0, p0, La26;->j:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lqh7;

    .line 5
    .line 6
    iget v6, p0, La26;->h:F

    .line 7
    .line 8
    iget-object v0, p0, La26;->i:Ljava/lang/Object;

    .line 9
    .line 10
    move-object v7, v0

    .line 11
    check-cast v7, Llh7;

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    move-object v2, p1

    .line 15
    move v3, p2

    .line 16
    move-object v4, p3

    .line 17
    invoke-virtual/range {v1 .. v7}, Lqh7;->h(Ljava/util/ArrayList;ZLh93;Landroid/graphics/Canvas;FLlh7;)F

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    iget p2, p0, La26;->h:F

    .line 22
    .line 23
    add-float/2addr p2, p1

    .line 24
    iput p2, p0, La26;->h:F

    .line 25
    .line 26
    iget p0, v7, Llh7;->c:F

    .line 27
    .line 28
    const/4 p1, 0x0

    .line 29
    cmpl-float p0, p0, p1

    .line 30
    .line 31
    if-eqz p0, :cond_0

    .line 32
    .line 33
    const/4 p0, 0x1

    .line 34
    return p0

    .line 35
    :cond_0
    const/4 p0, 0x0

    .line 36
    return p0
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final h(JLkp1;)F
    .locals 2

    .line 1
    iget-object v0, p0, La26;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lxi1;

    .line 4
    .line 5
    invoke-interface {v0, p1, p2, p3}, Lxi1;->h(JLkp1;)F

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iget-object v1, p0, La26;->j:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, Lxi1;

    .line 12
    .line 13
    invoke-interface {v1, p1, p2, p3}, Lxi1;->h(JLkp1;)F

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    iget p0, p0, La26;->h:F

    .line 18
    .line 19
    invoke-static {v0, p1, p0}, Lmk3;->Z(FFF)F

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    return p0
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method
