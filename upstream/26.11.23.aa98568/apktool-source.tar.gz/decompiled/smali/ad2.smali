.class public final Lad2;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public l:Lkc2;

.field public m:B

.field public synthetic n:Lkc2;

.field public synthetic o:Ljava/lang/Object;

.field public final synthetic p:Lai2;


# direct methods
.method public constructor <init>(Lai2;Lxd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lad2;->p:Lai2;

    .line 2
    .line 3
    const/4 p1, 0x3

    .line 4
    invoke-direct {p0, p1, p2}, Lt57;-><init>(ILxd1;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Lkc2;

    .line 2
    .line 3
    check-cast p3, Lxd1;

    .line 4
    .line 5
    new-instance v0, Lad2;

    .line 6
    .line 7
    iget-object p0, p0, Lad2;->p:Lai2;

    .line 8
    .line 9
    invoke-direct {v0, p0, p3}, Lad2;-><init>(Lai2;Lxd1;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, v0, Lad2;->n:Lkc2;

    .line 13
    .line 14
    iput-object p2, v0, Lad2;->o:Ljava/lang/Object;

    .line 15
    .line 16
    sget-object p0, Lst7;->a:Lst7;

    .line 17
    .line 18
    invoke-virtual {v0, p0}, Lad2;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, Lad2;->n:Lkc2;

    .line 2
    .line 3
    iget-object v1, p0, Lad2;->o:Ljava/lang/Object;

    .line 4
    .line 5
    iget-byte v2, p0, Lad2;->m:B

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    const/4 v5, 0x0

    .line 10
    sget-object v6, Lkj1;->h:Lkj1;

    .line 11
    .line 12
    if-eqz v2, :cond_2

    .line 13
    .line 14
    if-eq v2, v4, :cond_1

    .line 15
    .line 16
    if-ne v2, v3, :cond_0

    .line 17
    .line 18
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 23
    .line 24
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-object v5

    .line 28
    :cond_1
    iget-object v0, p0, Lad2;->l:Lkc2;

    .line 29
    .line 30
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_2
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    iput-object v5, p0, Lad2;->n:Lkc2;

    .line 38
    .line 39
    iput-object v5, p0, Lad2;->o:Ljava/lang/Object;

    .line 40
    .line 41
    iput-object v0, p0, Lad2;->l:Lkc2;

    .line 42
    .line 43
    iput-byte v4, p0, Lad2;->m:B

    .line 44
    .line 45
    iget-object p1, p0, Lad2;->p:Lai2;

    .line 46
    .line 47
    invoke-interface {p1, v1, p0}, Lai2;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    if-eq p1, v6, :cond_3

    .line 52
    .line 53
    :goto_0
    iput-object v5, p0, Lad2;->n:Lkc2;

    .line 54
    .line 55
    iput-object v5, p0, Lad2;->o:Ljava/lang/Object;

    .line 56
    .line 57
    iput-object v5, p0, Lad2;->l:Lkc2;

    .line 58
    .line 59
    iput-byte v3, p0, Lad2;->m:B

    .line 60
    .line 61
    invoke-interface {v0, p1, p0}, Lkc2;->l(Ljava/lang/Object;Lxd1;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    if-ne p0, v6, :cond_4

    .line 66
    .line 67
    :cond_3
    return-object v6

    .line 68
    :cond_4
    :goto_1
    sget-object p0, Lst7;->a:Lst7;

    .line 69
    .line 70
    return-object p0
.end method
