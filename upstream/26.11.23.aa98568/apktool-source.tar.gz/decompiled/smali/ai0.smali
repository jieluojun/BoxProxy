.class public final synthetic Lai0;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lwh2;

.field public final synthetic j:Lte4;

.field public final synthetic k:Ljava/lang/String;

.field public final synthetic l:Z


# direct methods
.method public synthetic constructor <init>(Lwh2;Lte4;Ljava/lang/String;ZB)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lai0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lai0;->i:Lwh2;

    .line 4
    .line 5
    iput-object p2, p0, Lai0;->j:Lte4;

    .line 6
    .line 7
    iput-object p3, p0, Lai0;->k:Ljava/lang/String;

    .line 8
    .line 9
    iput-boolean p4, p0, Lai0;->l:Z

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lai0;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const v3, 0x7f0f0229

    .line 8
    .line 9
    .line 10
    sget-object v4, Lc51;->a:Lql0;

    .line 11
    .line 12
    const/4 v5, 0x1

    .line 13
    const/4 v6, 0x0

    .line 14
    iget-object v7, v0, Lai0;->k:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v8, v0, Lai0;->j:Lte4;

    .line 17
    .line 18
    iget-object v9, v0, Lai0;->i:Lwh2;

    .line 19
    .line 20
    const/4 v10, 0x2

    .line 21
    packed-switch v1, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    move-object/from16 v14, p1

    .line 25
    .line 26
    check-cast v14, Lzi2;

    .line 27
    .line 28
    move-object/from16 v1, p2

    .line 29
    .line 30
    check-cast v1, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    and-int/lit8 v11, v1, 0x3

    .line 37
    .line 38
    if-eq v11, v10, :cond_0

    .line 39
    .line 40
    move v6, v5

    .line 41
    :cond_0
    and-int/2addr v1, v5

    .line 42
    invoke-virtual {v14, v1, v6}, Lzi2;->Y(IZ)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_3

    .line 47
    .line 48
    invoke-virtual {v14, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    invoke-virtual {v14, v8}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    or-int/2addr v1, v5

    .line 57
    invoke-virtual {v14}, Lzi2;->T()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    if-nez v1, :cond_1

    .line 62
    .line 63
    if-ne v5, v4, :cond_2

    .line 64
    .line 65
    :cond_1
    new-instance v5, Lvl;

    .line 66
    .line 67
    const/16 v1, 0x11

    .line 68
    .line 69
    invoke-direct {v5, v9, v8, v1}, Lvl;-><init>(Lwh2;Lte4;B)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v14, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :cond_2
    move-object v13, v5

    .line 76
    check-cast v13, Llh2;

    .line 77
    .line 78
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    invoke-static {v3, v1, v14}, Lxl3;->V(I[Ljava/lang/Object;Lzi2;)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v15

    .line 86
    const/4 v11, 0x0

    .line 87
    const/4 v12, 0x0

    .line 88
    iget-boolean v0, v0, Lai0;->l:Z

    .line 89
    .line 90
    move/from16 v16, v0

    .line 91
    .line 92
    invoke-static/range {v11 .. v16}, Lnl3;->b(IILlh2;Lzi2;Ljava/lang/String;Z)V

    .line 93
    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_3
    invoke-virtual {v14}, Lzi2;->b0()V

    .line 97
    .line 98
    .line 99
    :goto_0
    return-object v2

    .line 100
    :pswitch_0
    move v1, v6

    .line 101
    move-object/from16 v6, p1

    .line 102
    .line 103
    check-cast v6, Lzi2;

    .line 104
    .line 105
    move-object/from16 v11, p2

    .line 106
    .line 107
    check-cast v11, Ljava/lang/Integer;

    .line 108
    .line 109
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 110
    .line 111
    .line 112
    move-result v11

    .line 113
    and-int/lit8 v12, v11, 0x3

    .line 114
    .line 115
    if-eq v12, v10, :cond_4

    .line 116
    .line 117
    move v1, v5

    .line 118
    :cond_4
    and-int/2addr v11, v5

    .line 119
    invoke-virtual {v6, v11, v1}, Lzi2;->Y(IZ)Z

    .line 120
    .line 121
    .line 122
    move-result v1

    .line 123
    if-eqz v1, :cond_7

    .line 124
    .line 125
    invoke-virtual {v6, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    invoke-virtual {v6, v8}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v5

    .line 133
    or-int/2addr v1, v5

    .line 134
    invoke-virtual {v6}, Lzi2;->T()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v5

    .line 138
    if-nez v1, :cond_5

    .line 139
    .line 140
    if-ne v5, v4, :cond_6

    .line 141
    .line 142
    :cond_5
    new-instance v5, Lvl;

    .line 143
    .line 144
    const/4 v1, 0x4

    .line 145
    invoke-direct {v5, v9, v8, v1}, Lvl;-><init>(Lwh2;Lte4;B)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v6, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    :cond_6
    check-cast v5, Llh2;

    .line 152
    .line 153
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v1

    .line 157
    invoke-static {v3, v1, v6}, Lxl3;->V(I[Ljava/lang/Object;Lzi2;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v7

    .line 161
    const/4 v3, 0x0

    .line 162
    const/4 v4, 0x0

    .line 163
    iget-boolean v8, v0, Lai0;->l:Z

    .line 164
    .line 165
    invoke-static/range {v3 .. v8}, Lnl3;->b(IILlh2;Lzi2;Ljava/lang/String;Z)V

    .line 166
    .line 167
    .line 168
    goto :goto_1

    .line 169
    :cond_7
    invoke-virtual {v6}, Lzi2;->b0()V

    .line 170
    .line 171
    .line 172
    :goto_1
    return-object v2

    .line 173
    :pswitch_1
    move v1, v6

    .line 174
    move-object/from16 v6, p1

    .line 175
    .line 176
    check-cast v6, Lzi2;

    .line 177
    .line 178
    move-object/from16 v11, p2

    .line 179
    .line 180
    check-cast v11, Ljava/lang/Integer;

    .line 181
    .line 182
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 183
    .line 184
    .line 185
    move-result v11

    .line 186
    and-int/lit8 v12, v11, 0x3

    .line 187
    .line 188
    if-eq v12, v10, :cond_8

    .line 189
    .line 190
    move v1, v5

    .line 191
    :cond_8
    and-int/2addr v11, v5

    .line 192
    invoke-virtual {v6, v11, v1}, Lzi2;->Y(IZ)Z

    .line 193
    .line 194
    .line 195
    move-result v1

    .line 196
    if-eqz v1, :cond_b

    .line 197
    .line 198
    invoke-virtual {v6, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 199
    .line 200
    .line 201
    move-result v1

    .line 202
    invoke-virtual {v6, v8}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v5

    .line 206
    or-int/2addr v1, v5

    .line 207
    invoke-virtual {v6}, Lzi2;->T()Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v5

    .line 211
    if-nez v1, :cond_9

    .line 212
    .line 213
    if-ne v5, v4, :cond_a

    .line 214
    .line 215
    :cond_9
    new-instance v5, Lvl;

    .line 216
    .line 217
    invoke-direct {v5, v9, v8, v10}, Lvl;-><init>(Lwh2;Lte4;B)V

    .line 218
    .line 219
    .line 220
    invoke-virtual {v6, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 221
    .line 222
    .line 223
    :cond_a
    move-object v9, v5

    .line 224
    check-cast v9, Llh2;

    .line 225
    .line 226
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    invoke-static {v3, v1, v6}, Lxl3;->V(I[Ljava/lang/Object;Lzi2;)Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object v11

    .line 234
    const/4 v7, 0x0

    .line 235
    const/4 v8, 0x0

    .line 236
    iget-boolean v12, v0, Lai0;->l:Z

    .line 237
    .line 238
    move-object v10, v6

    .line 239
    invoke-static/range {v7 .. v12}, Lnl3;->b(IILlh2;Lzi2;Ljava/lang/String;Z)V

    .line 240
    .line 241
    .line 242
    goto :goto_2

    .line 243
    :cond_b
    move-object v10, v6

    .line 244
    invoke-virtual {v10}, Lzi2;->b0()V

    .line 245
    .line 246
    .line 247
    :goto_2
    return-object v2

    .line 248
    :pswitch_2
    move v1, v6

    .line 249
    move-object/from16 v6, p1

    .line 250
    .line 251
    check-cast v6, Lzi2;

    .line 252
    .line 253
    move-object/from16 v11, p2

    .line 254
    .line 255
    check-cast v11, Ljava/lang/Integer;

    .line 256
    .line 257
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 258
    .line 259
    .line 260
    move-result v11

    .line 261
    and-int/lit8 v12, v11, 0x3

    .line 262
    .line 263
    if-eq v12, v10, :cond_c

    .line 264
    .line 265
    move v1, v5

    .line 266
    :cond_c
    and-int/2addr v11, v5

    .line 267
    invoke-virtual {v6, v11, v1}, Lzi2;->Y(IZ)Z

    .line 268
    .line 269
    .line 270
    move-result v1

    .line 271
    if-eqz v1, :cond_f

    .line 272
    .line 273
    invoke-virtual {v6, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 274
    .line 275
    .line 276
    move-result v1

    .line 277
    invoke-virtual {v6, v8}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    move-result v5

    .line 281
    or-int/2addr v1, v5

    .line 282
    invoke-virtual {v6}, Lzi2;->T()Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v5

    .line 286
    if-nez v1, :cond_d

    .line 287
    .line 288
    if-ne v5, v4, :cond_e

    .line 289
    .line 290
    :cond_d
    new-instance v5, Lvl;

    .line 291
    .line 292
    const/4 v1, 0x3

    .line 293
    invoke-direct {v5, v9, v8, v1}, Lvl;-><init>(Lwh2;Lte4;B)V

    .line 294
    .line 295
    .line 296
    invoke-virtual {v6, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    :cond_e
    check-cast v5, Llh2;

    .line 300
    .line 301
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object v1

    .line 305
    invoke-static {v3, v1, v6}, Lxl3;->V(I[Ljava/lang/Object;Lzi2;)Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v7

    .line 309
    const/4 v3, 0x0

    .line 310
    const/4 v4, 0x0

    .line 311
    iget-boolean v8, v0, Lai0;->l:Z

    .line 312
    .line 313
    invoke-static/range {v3 .. v8}, Lnl3;->b(IILlh2;Lzi2;Ljava/lang/String;Z)V

    .line 314
    .line 315
    .line 316
    goto :goto_3

    .line 317
    :cond_f
    invoke-virtual {v6}, Lzi2;->b0()V

    .line 318
    .line 319
    .line 320
    :goto_3
    return-object v2

    .line 321
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
