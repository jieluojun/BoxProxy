.class public final synthetic Laj5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lpi5;

.field public final synthetic j:Landroid/content/Context;

.field public final synthetic k:Lar5;

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lpi5;Landroid/content/Context;Lar5;Ljava/lang/String;Ljava/lang/String;B)V
    .locals 0

    .line 1
    iput-byte p6, p0, Laj5;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Laj5;->i:Lpi5;

    .line 4
    .line 5
    iput-object p2, p0, Laj5;->j:Landroid/content/Context;

    .line 6
    .line 7
    iput-object p3, p0, Laj5;->k:Lar5;

    .line 8
    .line 9
    iput-object p4, p0, Laj5;->l:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p5, p0, Laj5;->m:Ljava/lang/String;

    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-byte v0, p0, Laj5;->h:B

    .line 2
    .line 3
    const-string v1, "proxy-config-import"

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    iget-object v3, p0, Laj5;->m:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v4, p0, Laj5;->l:Ljava/lang/String;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    move-object v7, p1

    .line 15
    check-cast v7, Landroid/net/Uri;

    .line 16
    .line 17
    if-eqz v7, :cond_0

    .line 18
    .line 19
    new-instance v8, Lmj5;

    .line 20
    .line 21
    const/4 p1, 0x1

    .line 22
    iget-object v6, p0, Laj5;->j:Landroid/content/Context;

    .line 23
    .line 24
    invoke-direct {v8, v4, v6, v3, p1}, Lmj5;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;B)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    iget-object v10, p0, Laj5;->k:Lar5;

    .line 31
    .line 32
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    iget-object v9, p0, Laj5;->i:Lpi5;

    .line 36
    .line 37
    iget-object p0, v9, Lpi5;->a:Lxp6;

    .line 38
    .line 39
    new-instance v5, Lji5;

    .line 40
    .line 41
    const/4 v11, 0x0

    .line 42
    invoke-direct/range {v5 .. v11}, Lji5;-><init>(Landroid/content/Context;Landroid/net/Uri;Lwh2;Lpi5;Lar5;Lxd1;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p0, v5, v1}, Lxp6;->d(Lwh2;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    :cond_0
    return-object v2

    .line 49
    :pswitch_0
    move-object v8, p1

    .line 50
    check-cast v8, Landroid/net/Uri;

    .line 51
    .line 52
    if-eqz v8, :cond_1

    .line 53
    .line 54
    new-instance v9, Lmj5;

    .line 55
    .line 56
    const/4 p1, 0x0

    .line 57
    iget-object v7, p0, Laj5;->j:Landroid/content/Context;

    .line 58
    .line 59
    invoke-direct {v9, v4, v7, v3, p1}, Lmj5;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;B)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 63
    .line 64
    .line 65
    iget-object v11, p0, Laj5;->k:Lar5;

    .line 66
    .line 67
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget-object v10, p0, Laj5;->i:Lpi5;

    .line 71
    .line 72
    iget-object p0, v10, Lpi5;->a:Lxp6;

    .line 73
    .line 74
    new-instance v6, Lji5;

    .line 75
    .line 76
    const/4 v12, 0x0

    .line 77
    invoke-direct/range {v6 .. v12}, Lji5;-><init>(Landroid/content/Context;Landroid/net/Uri;Lwh2;Lpi5;Lar5;Lxd1;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p0, v6, v1}, Lxp6;->d(Lwh2;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    :cond_1
    return-object v2

    .line 84
    nop

    .line 85
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
