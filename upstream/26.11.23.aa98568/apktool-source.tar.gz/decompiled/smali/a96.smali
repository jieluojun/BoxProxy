.class public final synthetic La96;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lte4;

.field public final synthetic j:Lk96;

.field public final synthetic k:Lte4;


# direct methods
.method public synthetic constructor <init>(Lte4;Lk96;Lte4;)V
    .locals 1

    .line 14
    const/4 v0, 0x1

    iput-byte v0, p0, La96;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La96;->i:Lte4;

    iput-object p2, p0, La96;->j:Lk96;

    iput-object p3, p0, La96;->k:Lte4;

    return-void
.end method

.method public synthetic constructor <init>(Lte4;Lte4;Lk96;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, La96;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La96;->i:Lte4;

    .line 8
    .line 9
    iput-object p2, p0, La96;->k:Lte4;

    .line 10
    .line 11
    iput-object p3, p0, La96;->j:Lk96;

    .line 12
    .line 13
    return-void
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La96;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    const/4 v5, 0x0

    .line 10
    iget-object v6, v0, La96;->k:Lte4;

    .line 11
    .line 12
    iget-object v7, v0, La96;->j:Lk96;

    .line 13
    .line 14
    iget-object v0, v0, La96;->i:Lte4;

    .line 15
    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object/from16 v1, p1

    .line 20
    .line 21
    check-cast v1, Lzi2;

    .line 22
    .line 23
    move-object/from16 v8, p2

    .line 24
    .line 25
    check-cast v8, Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 28
    .line 29
    .line 30
    move-result v8

    .line 31
    and-int/lit8 v9, v8, 0x3

    .line 32
    .line 33
    if-eq v9, v3, :cond_0

    .line 34
    .line 35
    move v3, v4

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move v3, v5

    .line 38
    :goto_0
    and-int/2addr v8, v4

    .line 39
    invoke-virtual {v1, v8, v3}, Lzi2;->Y(IZ)Z

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    if-eqz v3, :cond_a

    .line 44
    .line 45
    sget-object v3, Lya4;->h:Lya4;

    .line 46
    .line 47
    const/high16 v8, 0x3f800000    # 1.0f

    .line 48
    .line 49
    invoke-static {v3, v8}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 50
    .line 51
    .line 52
    move-result-object v9

    .line 53
    sget-object v10, Lob3;->e:Lkw;

    .line 54
    .line 55
    sget-object v11, Ly6;->s:La40;

    .line 56
    .line 57
    invoke-static {v10, v11, v1, v5}, Ln26;->a(Lmw;La40;Lzi2;I)Lo26;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    iget-wide v10, v1, Lzi2;->U:J

    .line 62
    .line 63
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 64
    .line 65
    .line 66
    move-result v10

    .line 67
    invoke-virtual {v1}, Lzi2;->m()Lla5;

    .line 68
    .line 69
    .line 70
    move-result-object v11

    .line 71
    invoke-static {v1, v9}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 72
    .line 73
    .line 74
    move-result-object v9

    .line 75
    sget-object v12, Ls41;->d:Ly6;

    .line 76
    .line 77
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v1}, Lzi2;->k0()V

    .line 81
    .line 82
    .line 83
    iget-boolean v12, v1, Lzi2;->T:Z

    .line 84
    .line 85
    if-eqz v12, :cond_1

    .line 86
    .line 87
    sget-object v12, Lzi3;->Z:Lu43;

    .line 88
    .line 89
    invoke-virtual {v1, v12}, Lzi2;->l(Llh2;)V

    .line 90
    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_1
    invoke-virtual {v1}, Lzi2;->t0()V

    .line 94
    .line 95
    .line 96
    :goto_1
    sget-object v12, Ly6;->T:Lx31;

    .line 97
    .line 98
    invoke-static {v12, v1, v5}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    sget-object v5, Ly6;->S:Lx31;

    .line 102
    .line 103
    invoke-static {v5, v1, v11}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 107
    .line 108
    .line 109
    move-result-object v5

    .line 110
    sget-object v10, Ly6;->U:Lx31;

    .line 111
    .line 112
    invoke-static {v10, v1, v5}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    invoke-static {v1}, Lfa7;->k(Lzi2;)V

    .line 116
    .line 117
    .line 118
    sget-object v5, Ly6;->R:Lx31;

    .line 119
    .line 120
    invoke-static {v5, v1, v9}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    const/high16 v5, 0x1040000

    .line 124
    .line 125
    invoke-static {v5, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    invoke-virtual {v1, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v9

    .line 133
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v10

    .line 137
    sget-object v11, Lc51;->a:Lql0;

    .line 138
    .line 139
    if-nez v9, :cond_2

    .line 140
    .line 141
    if-ne v10, v11, :cond_3

    .line 142
    .line 143
    :cond_2
    new-instance v10, Ls76;

    .line 144
    .line 145
    const/16 v9, 0x11

    .line 146
    .line 147
    invoke-direct {v10, v0, v9}, Ls76;-><init>(Lte4;B)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v1, v10}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    :cond_3
    move-object v9, v10

    .line 154
    check-cast v9, Llh2;

    .line 155
    .line 156
    float-to-double v12, v8

    .line 157
    const-wide/16 v21, 0x0

    .line 158
    .line 159
    cmpl-double v0, v12, v21

    .line 160
    .line 161
    const-string v23, "invalid weight; must be greater than zero"

    .line 162
    .line 163
    if-gtz v0, :cond_4

    .line 164
    .line 165
    invoke-static/range {v23 .. v23}, Ln73;->a(Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    :cond_4
    new-instance v10, Lsj3;

    .line 169
    .line 170
    const v0, 0x7f7fffff    # Float.MAX_VALUE

    .line 171
    .line 172
    .line 173
    cmpl-float v12, v8, v0

    .line 174
    .line 175
    if-lez v12, :cond_5

    .line 176
    .line 177
    move v12, v0

    .line 178
    goto :goto_2

    .line 179
    :cond_5
    move v12, v8

    .line 180
    :goto_2
    invoke-direct {v10, v12, v4}, Lsj3;-><init>(FZ)V

    .line 181
    .line 182
    .line 183
    const/16 v19, 0x0

    .line 184
    .line 185
    const/16 v20, 0xff8

    .line 186
    .line 187
    move-object v12, v11

    .line 188
    const/4 v11, 0x0

    .line 189
    move-object v13, v12

    .line 190
    const/4 v12, 0x0

    .line 191
    move-object v14, v13

    .line 192
    const/4 v13, 0x0

    .line 193
    move-object v15, v14

    .line 194
    const/4 v14, 0x0

    .line 195
    move-object/from16 v16, v15

    .line 196
    .line 197
    const/4 v15, 0x0

    .line 198
    move-object/from16 v17, v16

    .line 199
    .line 200
    const/16 v16, 0x0

    .line 201
    .line 202
    move-object/from16 v18, v17

    .line 203
    .line 204
    const/16 v17, 0x0

    .line 205
    .line 206
    move-object/from16 v24, v18

    .line 207
    .line 208
    move-object/from16 v18, v1

    .line 209
    .line 210
    move v1, v8

    .line 211
    move-object v8, v5

    .line 212
    move-object/from16 v5, v24

    .line 213
    .line 214
    invoke-static/range {v8 .. v20}, Lnl3;->c(Ljava/lang/String;Llh2;Lbb4;ZFFFLd74;Lo45;Li63;Lzi2;II)V

    .line 215
    .line 216
    .line 217
    move-object/from16 v8, v18

    .line 218
    .line 219
    const/high16 v9, 0x41a00000    # 20.0f

    .line 220
    .line 221
    const v10, 0x7f0f0428

    .line 222
    .line 223
    .line 224
    invoke-static {v3, v9, v8, v10, v8}, Lp92;->o(Lya4;FLzi2;ILzi2;)Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object v3

    .line 228
    invoke-interface {v6}, Lmz6;->getValue()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v6

    .line 232
    check-cast v6, Ljava/lang/String;

    .line 233
    .line 234
    invoke-static {v6}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 235
    .line 236
    .line 237
    move-result v6

    .line 238
    xor-int/lit8 v11, v6, 0x1

    .line 239
    .line 240
    float-to-double v9, v1

    .line 241
    cmpl-double v6, v9, v21

    .line 242
    .line 243
    if-gtz v6, :cond_6

    .line 244
    .line 245
    invoke-static/range {v23 .. v23}, Ln73;->a(Ljava/lang/String;)V

    .line 246
    .line 247
    .line 248
    :cond_6
    new-instance v10, Lsj3;

    .line 249
    .line 250
    cmpl-float v6, v1, v0

    .line 251
    .line 252
    if-gtz v6, :cond_7

    .line 253
    .line 254
    move v0, v1

    .line 255
    :cond_7
    invoke-direct {v10, v0, v4}, Lsj3;-><init>(FZ)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {v8, v7}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v0

    .line 262
    invoke-virtual {v8}, Lzi2;->T()Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object v1

    .line 266
    if-nez v0, :cond_8

    .line 267
    .line 268
    if-ne v1, v5, :cond_9

    .line 269
    .line 270
    :cond_8
    new-instance v1, Lr86;

    .line 271
    .line 272
    const/4 v0, 0x3

    .line 273
    invoke-direct {v1, v7, v0}, Lr86;-><init>(Lk96;B)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v8, v1}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 277
    .line 278
    .line 279
    :cond_9
    move-object v9, v1

    .line 280
    check-cast v9, Llh2;

    .line 281
    .line 282
    const/high16 v19, 0xc00000

    .line 283
    .line 284
    const/16 v20, 0xf70

    .line 285
    .line 286
    const/4 v12, 0x0

    .line 287
    const/4 v13, 0x0

    .line 288
    const/4 v14, 0x0

    .line 289
    sget-object v15, Ld74;->i:Ld74;

    .line 290
    .line 291
    const/16 v16, 0x0

    .line 292
    .line 293
    const/16 v17, 0x0

    .line 294
    .line 295
    move-object/from16 v18, v8

    .line 296
    .line 297
    move-object v8, v3

    .line 298
    invoke-static/range {v8 .. v20}, Lnl3;->c(Ljava/lang/String;Llh2;Lbb4;ZFFFLd74;Lo45;Li63;Lzi2;II)V

    .line 299
    .line 300
    .line 301
    move-object/from16 v8, v18

    .line 302
    .line 303
    invoke-virtual {v8, v4}, Lzi2;->r(Z)V

    .line 304
    .line 305
    .line 306
    goto :goto_3

    .line 307
    :cond_a
    move-object v8, v1

    .line 308
    invoke-virtual {v8}, Lzi2;->b0()V

    .line 309
    .line 310
    .line 311
    :goto_3
    return-object v2

    .line 312
    :pswitch_0
    move-object/from16 v15, p1

    .line 313
    .line 314
    check-cast v15, Lzi2;

    .line 315
    .line 316
    move-object/from16 v1, p2

    .line 317
    .line 318
    check-cast v1, Ljava/lang/Integer;

    .line 319
    .line 320
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 321
    .line 322
    .line 323
    move-result v1

    .line 324
    and-int/lit8 v8, v1, 0x3

    .line 325
    .line 326
    if-eq v8, v3, :cond_b

    .line 327
    .line 328
    move v5, v4

    .line 329
    :cond_b
    and-int/2addr v1, v4

    .line 330
    invoke-virtual {v15, v1, v5}, Lzi2;->Y(IZ)Z

    .line 331
    .line 332
    .line 333
    move-result v1

    .line 334
    if-eqz v1, :cond_c

    .line 335
    .line 336
    new-instance v1, Ls71;

    .line 337
    .line 338
    const/16 v3, 0xa

    .line 339
    .line 340
    invoke-direct {v1, v0, v3}, Ls71;-><init>(Lte4;B)V

    .line 341
    .line 342
    .line 343
    const v3, 0x112a18c0

    .line 344
    .line 345
    .line 346
    invoke-static {v3, v1, v15}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 347
    .line 348
    .line 349
    move-result-object v13

    .line 350
    new-instance v1, La96;

    .line 351
    .line 352
    invoke-direct {v1, v6, v7, v0}, La96;-><init>(Lte4;Lk96;Lte4;)V

    .line 353
    .line 354
    .line 355
    const v0, -0xeb37091

    .line 356
    .line 357
    .line 358
    invoke-static {v0, v1, v15}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 359
    .line 360
    .line 361
    move-result-object v14

    .line 362
    const v16, 0x36000

    .line 363
    .line 364
    .line 365
    const/16 v17, 0xf

    .line 366
    .line 367
    const/4 v9, 0x0

    .line 368
    const/4 v10, 0x0

    .line 369
    const/4 v11, 0x0

    .line 370
    const/4 v12, 0x0

    .line 371
    invoke-static/range {v9 .. v17}, Lck3;->c(Lbb4;FLnw;Leh6;Ls21;Ls21;Lzi2;II)V

    .line 372
    .line 373
    .line 374
    goto :goto_4

    .line 375
    :cond_c
    invoke-virtual {v15}, Lzi2;->b0()V

    .line 376
    .line 377
    .line 378
    :goto_4
    return-object v2

    .line 379
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
.end method
