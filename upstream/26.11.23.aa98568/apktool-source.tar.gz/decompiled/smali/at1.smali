.class public final Lat1;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic l:B

.field public final synthetic m:I

.field public synthetic n:Ljava/lang/Object;


# direct methods
.method public constructor <init>(JLxd1;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lat1;->l:B

    .line 3
    .line 4
    long-to-int p1, p1

    .line 5
    iput p1, p0, Lat1;->m:I

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, Lt57;-><init>(ILxd1;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ILxd1;B)V
    .locals 0

    .line 12
    iput-byte p4, p0, Lat1;->l:B

    iput-object p1, p0, Lat1;->n:Ljava/lang/Object;

    iput p2, p0, Lat1;->m:I

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lt57;-><init>(ILxd1;)V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lat1;->l:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lch6;

    .line 9
    .line 10
    check-cast p2, Lxd1;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lat1;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lat1;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lat1;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    check-cast p1, Ljj1;

    .line 23
    .line 24
    check-cast p2, Lxd1;

    .line 25
    .line 26
    invoke-virtual {p0, p2, p1}, Lat1;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Lat1;

    .line 31
    .line 32
    invoke-virtual {p0, v1}, Lat1;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    return-object v1

    .line 36
    :pswitch_1
    check-cast p1, Ljava/io/InputStream;

    .line 37
    .line 38
    check-cast p2, Lxd1;

    .line 39
    .line 40
    invoke-virtual {p0, p2, p1}, Lat1;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    check-cast p0, Lat1;

    .line 45
    .line 46
    invoke-virtual {p0, v1}, Lat1;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final s(Lxd1;Ljava/lang/Object;)Lxd1;
    .locals 3

    .line 1
    iget-byte v0, p0, Lat1;->l:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance p2, Lat1;

    .line 7
    .line 8
    iget-object v0, p0, Lat1;->n:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lbl3;

    .line 11
    .line 12
    iget p0, p0, Lat1;->m:I

    .line 13
    .line 14
    const/4 v1, 0x2

    .line 15
    invoke-direct {p2, v0, p0, p1, v1}, Lat1;-><init>(Ljava/lang/Object;ILxd1;B)V

    .line 16
    .line 17
    .line 18
    return-object p2

    .line 19
    :pswitch_0
    new-instance p2, Lat1;

    .line 20
    .line 21
    iget-object v0, p0, Lat1;->n:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lxl1;

    .line 24
    .line 25
    iget p0, p0, Lat1;->m:I

    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    invoke-direct {p2, v0, p0, p1, v1}, Lat1;-><init>(Ljava/lang/Object;ILxd1;B)V

    .line 29
    .line 30
    .line 31
    return-object p2

    .line 32
    :pswitch_1
    new-instance v0, Lat1;

    .line 33
    .line 34
    iget p0, p0, Lat1;->m:I

    .line 35
    .line 36
    int-to-long v1, p0

    .line 37
    invoke-direct {v0, v1, v2, p1}, Lat1;-><init>(JLxd1;)V

    .line 38
    .line 39
    .line 40
    iput-object p2, v0, Lat1;->n:Ljava/lang/Object;

    .line 41
    .line 42
    return-object v0

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lat1;->l:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Lst7;->a:Lst7;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    iget v4, p0, Lat1;->m:I

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iget-object p0, p0, Lat1;->n:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast p0, Lbl3;

    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    invoke-virtual {p0, v4, v3, p1}, Lbl3;->k(IIZ)V

    .line 21
    .line 22
    .line 23
    return-object v2

    .line 24
    :pswitch_0
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object p0, p0, Lat1;->n:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast p0, Lxl1;

    .line 30
    .line 31
    iget p1, p0, Lxl1;->u:F

    .line 32
    .line 33
    int-to-float v0, v4

    .line 34
    cmpg-float p1, p1, v0

    .line 35
    .line 36
    if-eqz p1, :cond_0

    .line 37
    .line 38
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    iget-object v0, p0, Lxl1;->b:Lqu0;

    .line 43
    .line 44
    invoke-static {p1, v0}, Lej3;->z(Ljava/lang/Comparable;Lru0;)Ljava/lang/Comparable;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    check-cast p1, Ljava/lang/Number;

    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    iput p1, p0, Lxl1;->u:F

    .line 55
    .line 56
    iget-object v0, p0, Lxl1;->a:Ljj1;

    .line 57
    .line 58
    new-instance v4, Lql1;

    .line 59
    .line 60
    invoke-direct {v4, p0, p1, v1, v3}, Lql1;-><init>(Ljava/lang/Object;FLxd1;B)V

    .line 61
    .line 62
    .line 63
    const/4 p0, 0x3

    .line 64
    invoke-static {v0, v1, v1, v4, p0}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 65
    .line 66
    .line 67
    :cond_0
    return-object v2

    .line 68
    :pswitch_1
    iget-object p0, p0, Lat1;->n:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast p0, Ljava/io/InputStream;

    .line 71
    .line 72
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    int-to-long v2, v4

    .line 76
    invoke-static {p0, v2, v3, v1}, Lcw;->I(Ljava/io/InputStream;JLkc1;)[B

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    return-object p0

    .line 81
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
