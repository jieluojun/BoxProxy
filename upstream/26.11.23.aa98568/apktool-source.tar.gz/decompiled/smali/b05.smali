.class public final Lb05;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public final serializer()Lgg3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lgg3;"
        }
    .end annotation

    .line 1
    sget-object p0, La05;->a:La05;

    .line 2
    .line 3
    return-object p0
.end method
