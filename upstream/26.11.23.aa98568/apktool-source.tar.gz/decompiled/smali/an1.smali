.class public final Lan1;
.super Lab4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lcw1;


# instance fields
.field public final v:Lma3;

.field public w:Z

.field public x:Z

.field public y:Z


# direct methods
.method public constructor <init>(Lma3;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lab4;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lan1;->v:Lma3;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final l0(Lbj3;)V
    .locals 10

    .line 1
    invoke-virtual {p1}, Lbj3;->c()V

    .line 2
    .line 3
    .line 4
    iget-object v2, p1, Lbj3;->h:Ltl0;

    .line 5
    .line 6
    iget-boolean v3, p0, Lan1;->w:Z

    .line 7
    .line 8
    const-wide/high16 v4, -0x100000000000000L

    .line 9
    .line 10
    if-eqz v3, :cond_0

    .line 11
    .line 12
    const v0, 0x3e99999a    # 0.3f

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v4, v5}, Lgy0;->b(FJ)J

    .line 16
    .line 17
    .line 18
    move-result-wide v3

    .line 19
    invoke-interface {v2}, Ldw1;->b()J

    .line 20
    .line 21
    .line 22
    move-result-wide v5

    .line 23
    const/4 v8, 0x0

    .line 24
    const/16 v9, 0x7a

    .line 25
    .line 26
    move-wide v1, v3

    .line 27
    const-wide/16 v3, 0x0

    .line 28
    .line 29
    const/4 v7, 0x0

    .line 30
    move-object v0, p1

    .line 31
    invoke-static/range {v0 .. v9}, Ldw1;->n0(Ldw1;JJJFII)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_0
    iget-boolean v1, p0, Lan1;->x:Z

    .line 36
    .line 37
    if-nez v1, :cond_1

    .line 38
    .line 39
    iget-boolean v0, p0, Lan1;->y:Z

    .line 40
    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    return-void

    .line 44
    :cond_1
    const v0, 0x3dcccccd    # 0.1f

    .line 45
    .line 46
    .line 47
    invoke-static {v0, v4, v5}, Lgy0;->b(FJ)J

    .line 48
    .line 49
    .line 50
    move-result-wide v0

    .line 51
    invoke-interface {v2}, Ldw1;->b()J

    .line 52
    .line 53
    .line 54
    move-result-wide v5

    .line 55
    const/4 v8, 0x0

    .line 56
    const/16 v9, 0x7a

    .line 57
    .line 58
    const-wide/16 v3, 0x0

    .line 59
    .line 60
    const/4 v7, 0x0

    .line 61
    move-wide v1, v0

    .line 62
    move-object v0, p1

    .line 63
    invoke-static/range {v0 .. v9}, Ldw1;->n0(Ldw1;JJJFII)V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public final y1()V
    .locals 4

    .line 1
    invoke-virtual {p0}, Lab4;->u1()Ljj1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Ly3;

    .line 6
    .line 7
    const/16 v2, 0xa

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    invoke-direct {v1, p0, v3, v2}, Ly3;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 11
    .line 12
    .line 13
    const/4 p0, 0x3

    .line 14
    invoke-static {v0, v3, v3, v1, p0}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 15
    .line 16
    .line 17
    return-void
.end method
