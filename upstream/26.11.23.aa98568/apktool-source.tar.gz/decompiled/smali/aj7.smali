.class public final synthetic Laj7;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lvv;

.field public final synthetic j:Lui7;


# direct methods
.method public synthetic constructor <init>(Lvv;Lui7;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Laj7;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Laj7;->i:Lvv;

    .line 4
    .line 5
    iput-object p2, p0, Laj7;->j:Lui7;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Laj7;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    iget-object v3, v0, Laj7;->j:Lui7;

    .line 8
    .line 9
    iget-object v0, v0, Laj7;->i:Lvv;

    .line 10
    .line 11
    const/4 v4, 0x2

    .line 12
    const/4 v5, 0x1

    .line 13
    const/4 v6, 0x0

    .line 14
    packed-switch v1, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    move-object/from16 v12, p1

    .line 18
    .line 19
    check-cast v12, Lzi2;

    .line 20
    .line 21
    move-object/from16 v1, p2

    .line 22
    .line 23
    check-cast v1, Ljava/lang/Integer;

    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    and-int/lit8 v7, v1, 0x3

    .line 30
    .line 31
    if-eq v7, v4, :cond_0

    .line 32
    .line 33
    move v6, v5

    .line 34
    :cond_0
    and-int/2addr v1, v5

    .line 35
    invoke-virtual {v12, v1, v6}, Lzi2;->Y(IZ)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_1

    .line 40
    .line 41
    const v1, 0x7f0f005f

    .line 42
    .line 43
    .line 44
    invoke-static {v1, v12}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v7

    .line 48
    iget-boolean v9, v0, Lvv;->G:Z

    .line 49
    .line 50
    iget-object v11, v3, Lui7;->i:Lwh2;

    .line 51
    .line 52
    const/4 v13, 0x0

    .line 53
    const/16 v14, 0x2e

    .line 54
    .line 55
    const/4 v8, 0x0

    .line 56
    const/4 v10, 0x0

    .line 57
    invoke-static/range {v7 .. v14}, Lb14;->h(Ljava/lang/String;Lj53;ZZLwh2;Lzi2;II)V

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_1
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 62
    .line 63
    .line 64
    :goto_0
    return-object v2

    .line 65
    :pswitch_0
    move-object/from16 v1, p1

    .line 66
    .line 67
    check-cast v1, Lzi2;

    .line 68
    .line 69
    move-object/from16 v7, p2

    .line 70
    .line 71
    check-cast v7, Ljava/lang/Integer;

    .line 72
    .line 73
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 74
    .line 75
    .line 76
    move-result v7

    .line 77
    and-int/lit8 v8, v7, 0x3

    .line 78
    .line 79
    if-eq v8, v4, :cond_2

    .line 80
    .line 81
    move v4, v5

    .line 82
    goto :goto_1

    .line 83
    :cond_2
    move v4, v6

    .line 84
    :goto_1
    and-int/2addr v7, v5

    .line 85
    invoke-virtual {v1, v7, v4}, Lzi2;->Y(IZ)Z

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    if-eqz v4, :cond_5

    .line 90
    .line 91
    const v4, 0x7f0f0032

    .line 92
    .line 93
    .line 94
    invoke-static {v4, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v13

    .line 98
    invoke-static {v0}, Ly67;->n(Lvv;)Lpi7;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    invoke-static {v4, v1}, Ly67;->g(Lpi7;Lzi2;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v14

    .line 106
    new-instance v4, Lu31;

    .line 107
    .line 108
    const/16 v5, 0x1d

    .line 109
    .line 110
    invoke-direct {v4, v5}, Lu31;-><init>(B)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v1, v3}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    move-result v5

    .line 117
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v7

    .line 121
    if-nez v5, :cond_3

    .line 122
    .line 123
    sget-object v5, Lc51;->a:Lql0;

    .line 124
    .line 125
    if-ne v7, v5, :cond_4

    .line 126
    .line 127
    :cond_3
    new-instance v7, Lbj7;

    .line 128
    .line 129
    invoke-direct {v7, v3, v6}, Lbj7;-><init>(Lui7;B)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v1, v7}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    :cond_4
    move-object/from16 v17, v7

    .line 136
    .line 137
    check-cast v17, Lwh2;

    .line 138
    .line 139
    new-instance v3, Lcj7;

    .line 140
    .line 141
    invoke-direct {v3, v0, v6}, Lcj7;-><init>(Lvv;B)V

    .line 142
    .line 143
    .line 144
    const v5, -0x34897db1    # -1.6155215E7f

    .line 145
    .line 146
    .line 147
    invoke-static {v5, v3, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 148
    .line 149
    .line 150
    move-result-object v18

    .line 151
    new-instance v3, Ldj7;

    .line 152
    .line 153
    invoke-direct {v3, v0, v6}, Ldj7;-><init>(Lvv;B)V

    .line 154
    .line 155
    .line 156
    const v0, 0x7225f07e

    .line 157
    .line 158
    .line 159
    invoke-static {v0, v3, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 160
    .line 161
    .line 162
    move-result-object v19

    .line 163
    const/high16 v22, 0x6c00000

    .line 164
    .line 165
    const/16 v23, 0x260

    .line 166
    .line 167
    sget-object v15, Lpi7;->m:Lc42;

    .line 168
    .line 169
    const/16 v20, 0x0

    .line 170
    .line 171
    move-object/from16 v21, v1

    .line 172
    .line 173
    move-object/from16 v16, v4

    .line 174
    .line 175
    invoke-static/range {v13 .. v23}, Lkj7;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lbi2;Lwh2;Ls21;Ls21;ZLzi2;II)V

    .line 176
    .line 177
    .line 178
    goto :goto_2

    .line 179
    :cond_5
    move-object/from16 v21, v1

    .line 180
    .line 181
    invoke-virtual/range {v21 .. v21}, Lzi2;->b0()V

    .line 182
    .line 183
    .line 184
    :goto_2
    return-object v2

    .line 185
    :pswitch_1
    move-object/from16 v11, p1

    .line 186
    .line 187
    check-cast v11, Lzi2;

    .line 188
    .line 189
    move-object/from16 v1, p2

    .line 190
    .line 191
    check-cast v1, Ljava/lang/Integer;

    .line 192
    .line 193
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 194
    .line 195
    .line 196
    move-result v1

    .line 197
    and-int/lit8 v7, v1, 0x3

    .line 198
    .line 199
    if-eq v7, v4, :cond_6

    .line 200
    .line 201
    move v6, v5

    .line 202
    :cond_6
    and-int/2addr v1, v5

    .line 203
    invoke-virtual {v11, v1, v6}, Lzi2;->Y(IZ)Z

    .line 204
    .line 205
    .line 206
    move-result v1

    .line 207
    if-eqz v1, :cond_7

    .line 208
    .line 209
    const v1, 0x7f0f0518

    .line 210
    .line 211
    .line 212
    invoke-static {v1, v11}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    iget-object v4, v0, Lvv;->E:Lxi7;

    .line 217
    .line 218
    invoke-static {v4, v11}, Ly67;->j(Lxi7;Lzi2;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v4

    .line 222
    iget-object v7, v3, Lui7;->g:Lwh2;

    .line 223
    .line 224
    new-instance v6, Lej7;

    .line 225
    .line 226
    const/4 v3, 0x4

    .line 227
    invoke-direct {v6, v3}, Lej7;-><init>(B)V

    .line 228
    .line 229
    .line 230
    new-instance v3, Lcj7;

    .line 231
    .line 232
    invoke-direct {v3, v0, v5}, Lcj7;-><init>(Lvv;B)V

    .line 233
    .line 234
    .line 235
    const v8, 0x3bd85858

    .line 236
    .line 237
    .line 238
    invoke-static {v8, v3, v11}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 239
    .line 240
    .line 241
    move-result-object v8

    .line 242
    new-instance v3, Ldj7;

    .line 243
    .line 244
    invoke-direct {v3, v0, v5}, Ldj7;-><init>(Lvv;B)V

    .line 245
    .line 246
    .line 247
    const v0, 0x13c17ba8

    .line 248
    .line 249
    .line 250
    invoke-static {v0, v3, v11}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 251
    .line 252
    .line 253
    move-result-object v9

    .line 254
    const/high16 v12, 0x6c00000

    .line 255
    .line 256
    const/16 v13, 0x260

    .line 257
    .line 258
    sget-object v5, Lxi7;->l:Lc42;

    .line 259
    .line 260
    const/4 v10, 0x0

    .line 261
    move-object v3, v1

    .line 262
    invoke-static/range {v3 .. v13}, Lkj7;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lbi2;Lwh2;Ls21;Ls21;ZLzi2;II)V

    .line 263
    .line 264
    .line 265
    goto :goto_3

    .line 266
    :cond_7
    invoke-virtual {v11}, Lzi2;->b0()V

    .line 267
    .line 268
    .line 269
    :goto_3
    return-object v2

    .line 270
    :pswitch_2
    move-object/from16 v8, p1

    .line 271
    .line 272
    check-cast v8, Lzi2;

    .line 273
    .line 274
    move-object/from16 v1, p2

    .line 275
    .line 276
    check-cast v1, Ljava/lang/Integer;

    .line 277
    .line 278
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 279
    .line 280
    .line 281
    move-result v1

    .line 282
    and-int/lit8 v7, v1, 0x3

    .line 283
    .line 284
    if-eq v7, v4, :cond_8

    .line 285
    .line 286
    move v6, v5

    .line 287
    :cond_8
    and-int/2addr v1, v5

    .line 288
    invoke-virtual {v8, v1, v6}, Lzi2;->Y(IZ)Z

    .line 289
    .line 290
    .line 291
    move-result v1

    .line 292
    if-eqz v1, :cond_9

    .line 293
    .line 294
    const v1, 0x7f0f03e9

    .line 295
    .line 296
    .line 297
    invoke-static {v1, v8}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v1

    .line 301
    iget-boolean v5, v0, Lvv;->A:Z

    .line 302
    .line 303
    iget-object v7, v3, Lui7;->c:Lwh2;

    .line 304
    .line 305
    const/4 v9, 0x0

    .line 306
    const/16 v10, 0x2e

    .line 307
    .line 308
    const/4 v4, 0x0

    .line 309
    const/4 v6, 0x0

    .line 310
    move-object v3, v1

    .line 311
    invoke-static/range {v3 .. v10}, Lb14;->h(Ljava/lang/String;Lj53;ZZLwh2;Lzi2;II)V

    .line 312
    .line 313
    .line 314
    goto :goto_4

    .line 315
    :cond_9
    invoke-virtual {v8}, Lzi2;->b0()V

    .line 316
    .line 317
    .line 318
    :goto_4
    return-object v2

    .line 319
    :pswitch_3
    move-object/from16 v1, p1

    .line 320
    .line 321
    check-cast v1, Lzi2;

    .line 322
    .line 323
    move-object/from16 v7, p2

    .line 324
    .line 325
    check-cast v7, Ljava/lang/Integer;

    .line 326
    .line 327
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 328
    .line 329
    .line 330
    move-result v7

    .line 331
    and-int/lit8 v8, v7, 0x3

    .line 332
    .line 333
    if-eq v8, v4, :cond_a

    .line 334
    .line 335
    move v4, v5

    .line 336
    goto :goto_5

    .line 337
    :cond_a
    move v4, v6

    .line 338
    :goto_5
    and-int/2addr v7, v5

    .line 339
    invoke-virtual {v1, v7, v4}, Lzi2;->Y(IZ)Z

    .line 340
    .line 341
    .line 342
    move-result v4

    .line 343
    if-eqz v4, :cond_b

    .line 344
    .line 345
    const v4, 0x7f0f051e

    .line 346
    .line 347
    .line 348
    invoke-static {v4, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object v9

    .line 352
    iget-object v0, v0, Lvv;->z:Lvi7;

    .line 353
    .line 354
    invoke-static {v0, v1}, Ly67;->i(Lvi7;Lzi2;)Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object v10

    .line 358
    new-instance v12, Lej7;

    .line 359
    .line 360
    invoke-direct {v12, v6}, Lej7;-><init>(B)V

    .line 361
    .line 362
    .line 363
    iget-object v13, v3, Lui7;->b:Lwh2;

    .line 364
    .line 365
    const/16 v18, 0x0

    .line 366
    .line 367
    const/16 v19, 0x3e0

    .line 368
    .line 369
    sget-object v11, Lvi7;->j:Lc42;

    .line 370
    .line 371
    const/4 v14, 0x0

    .line 372
    const/4 v15, 0x0

    .line 373
    const/16 v16, 0x0

    .line 374
    .line 375
    move-object/from16 v17, v1

    .line 376
    .line 377
    invoke-static/range {v9 .. v19}, Lkj7;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lbi2;Lwh2;Ls21;Ls21;ZLzi2;II)V

    .line 378
    .line 379
    .line 380
    goto :goto_6

    .line 381
    :cond_b
    move-object/from16 v17, v1

    .line 382
    .line 383
    invoke-virtual/range {v17 .. v17}, Lzi2;->b0()V

    .line 384
    .line 385
    .line 386
    :goto_6
    return-object v2

    .line 387
    :pswitch_4
    move-object/from16 v8, p1

    .line 388
    .line 389
    check-cast v8, Lzi2;

    .line 390
    .line 391
    move-object/from16 v1, p2

    .line 392
    .line 393
    check-cast v1, Ljava/lang/Integer;

    .line 394
    .line 395
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 396
    .line 397
    .line 398
    move-result v1

    .line 399
    and-int/lit8 v7, v1, 0x3

    .line 400
    .line 401
    if-eq v7, v4, :cond_c

    .line 402
    .line 403
    move v6, v5

    .line 404
    :cond_c
    and-int/2addr v1, v5

    .line 405
    invoke-virtual {v8, v1, v6}, Lzi2;->Y(IZ)Z

    .line 406
    .line 407
    .line 408
    move-result v1

    .line 409
    if-eqz v1, :cond_d

    .line 410
    .line 411
    const v1, 0x7f0f0361

    .line 412
    .line 413
    .line 414
    invoke-static {v1, v8}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v1

    .line 418
    iget-boolean v5, v0, Lvv;->L:Z

    .line 419
    .line 420
    iget-object v7, v3, Lui7;->n:Lwh2;

    .line 421
    .line 422
    const/4 v9, 0x0

    .line 423
    const/16 v10, 0x2e

    .line 424
    .line 425
    const/4 v4, 0x0

    .line 426
    const/4 v6, 0x0

    .line 427
    move-object v3, v1

    .line 428
    invoke-static/range {v3 .. v10}, Lb14;->h(Ljava/lang/String;Lj53;ZZLwh2;Lzi2;II)V

    .line 429
    .line 430
    .line 431
    goto :goto_7

    .line 432
    :cond_d
    invoke-virtual {v8}, Lzi2;->b0()V

    .line 433
    .line 434
    .line 435
    :goto_7
    return-object v2

    .line 436
    :pswitch_5
    move-object/from16 v14, p1

    .line 437
    .line 438
    check-cast v14, Lzi2;

    .line 439
    .line 440
    move-object/from16 v1, p2

    .line 441
    .line 442
    check-cast v1, Ljava/lang/Integer;

    .line 443
    .line 444
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 445
    .line 446
    .line 447
    move-result v1

    .line 448
    and-int/lit8 v7, v1, 0x3

    .line 449
    .line 450
    if-eq v7, v4, :cond_e

    .line 451
    .line 452
    move v6, v5

    .line 453
    :cond_e
    and-int/2addr v1, v5

    .line 454
    invoke-virtual {v14, v1, v6}, Lzi2;->Y(IZ)Z

    .line 455
    .line 456
    .line 457
    move-result v1

    .line 458
    if-eqz v1, :cond_f

    .line 459
    .line 460
    const v1, 0x7f0f0360

    .line 461
    .line 462
    .line 463
    invoke-static {v1, v14}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 464
    .line 465
    .line 466
    move-result-object v9

    .line 467
    iget-boolean v11, v0, Lvv;->K:Z

    .line 468
    .line 469
    iget-object v13, v3, Lui7;->m:Lwh2;

    .line 470
    .line 471
    const/4 v15, 0x0

    .line 472
    const/16 v16, 0x2e

    .line 473
    .line 474
    const/4 v10, 0x0

    .line 475
    const/4 v12, 0x0

    .line 476
    invoke-static/range {v9 .. v16}, Lb14;->h(Ljava/lang/String;Lj53;ZZLwh2;Lzi2;II)V

    .line 477
    .line 478
    .line 479
    goto :goto_8

    .line 480
    :cond_f
    invoke-virtual {v14}, Lzi2;->b0()V

    .line 481
    .line 482
    .line 483
    :goto_8
    return-object v2

    .line 484
    :pswitch_6
    move-object/from16 v8, p1

    .line 485
    .line 486
    check-cast v8, Lzi2;

    .line 487
    .line 488
    move-object/from16 v1, p2

    .line 489
    .line 490
    check-cast v1, Ljava/lang/Integer;

    .line 491
    .line 492
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 493
    .line 494
    .line 495
    move-result v1

    .line 496
    and-int/lit8 v7, v1, 0x3

    .line 497
    .line 498
    if-eq v7, v4, :cond_10

    .line 499
    .line 500
    move v6, v5

    .line 501
    :cond_10
    and-int/2addr v1, v5

    .line 502
    invoke-virtual {v8, v1, v6}, Lzi2;->Y(IZ)Z

    .line 503
    .line 504
    .line 505
    move-result v1

    .line 506
    if-eqz v1, :cond_11

    .line 507
    .line 508
    const v1, 0x7f0f04f4

    .line 509
    .line 510
    .line 511
    invoke-static {v1, v8}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 512
    .line 513
    .line 514
    move-result-object v1

    .line 515
    iget-boolean v5, v0, Lvv;->M:Z

    .line 516
    .line 517
    iget-object v7, v3, Lui7;->o:Lwh2;

    .line 518
    .line 519
    const/4 v9, 0x0

    .line 520
    const/16 v10, 0x2e

    .line 521
    .line 522
    const/4 v4, 0x0

    .line 523
    const/4 v6, 0x0

    .line 524
    move-object v3, v1

    .line 525
    invoke-static/range {v3 .. v10}, Lb14;->h(Ljava/lang/String;Lj53;ZZLwh2;Lzi2;II)V

    .line 526
    .line 527
    .line 528
    goto :goto_9

    .line 529
    :cond_11
    invoke-virtual {v8}, Lzi2;->b0()V

    .line 530
    .line 531
    .line 532
    :goto_9
    return-object v2

    .line 533
    :pswitch_7
    move-object/from16 v1, p1

    .line 534
    .line 535
    check-cast v1, Lzi2;

    .line 536
    .line 537
    move-object/from16 v7, p2

    .line 538
    .line 539
    check-cast v7, Ljava/lang/Integer;

    .line 540
    .line 541
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 542
    .line 543
    .line 544
    move-result v7

    .line 545
    and-int/lit8 v8, v7, 0x3

    .line 546
    .line 547
    if-eq v8, v4, :cond_12

    .line 548
    .line 549
    move v6, v5

    .line 550
    :cond_12
    and-int/2addr v7, v5

    .line 551
    invoke-virtual {v1, v7, v6}, Lzi2;->Y(IZ)Z

    .line 552
    .line 553
    .line 554
    move-result v4

    .line 555
    if-eqz v4, :cond_13

    .line 556
    .line 557
    const v4, 0x7f0f0064

    .line 558
    .line 559
    .line 560
    invoke-static {v4, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 561
    .line 562
    .line 563
    move-result-object v9

    .line 564
    iget-object v0, v0, Lvv;->I:Lh60;

    .line 565
    .line 566
    invoke-static {v0, v1}, Ly67;->f(Lh60;Lzi2;)Ljava/lang/String;

    .line 567
    .line 568
    .line 569
    move-result-object v10

    .line 570
    new-instance v12, Lej7;

    .line 571
    .line 572
    const/4 v0, 0x3

    .line 573
    invoke-direct {v12, v0}, Lej7;-><init>(B)V

    .line 574
    .line 575
    .line 576
    iget-object v13, v3, Lui7;->k:Lwh2;

    .line 577
    .line 578
    const/16 v18, 0x0

    .line 579
    .line 580
    const/16 v19, 0x3e0

    .line 581
    .line 582
    sget-object v11, Lh60;->n:Lc42;

    .line 583
    .line 584
    const/4 v14, 0x0

    .line 585
    const/4 v15, 0x0

    .line 586
    const/16 v16, 0x0

    .line 587
    .line 588
    move-object/from16 v17, v1

    .line 589
    .line 590
    invoke-static/range {v9 .. v19}, Lkj7;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lbi2;Lwh2;Ls21;Ls21;ZLzi2;II)V

    .line 591
    .line 592
    .line 593
    goto :goto_a

    .line 594
    :cond_13
    move-object/from16 v17, v1

    .line 595
    .line 596
    invoke-virtual/range {v17 .. v17}, Lzi2;->b0()V

    .line 597
    .line 598
    .line 599
    :goto_a
    return-object v2

    .line 600
    :pswitch_8
    move-object/from16 v11, p1

    .line 601
    .line 602
    check-cast v11, Lzi2;

    .line 603
    .line 604
    move-object/from16 v1, p2

    .line 605
    .line 606
    check-cast v1, Ljava/lang/Integer;

    .line 607
    .line 608
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 609
    .line 610
    .line 611
    move-result v1

    .line 612
    and-int/lit8 v7, v1, 0x3

    .line 613
    .line 614
    if-eq v7, v4, :cond_14

    .line 615
    .line 616
    move v6, v5

    .line 617
    :cond_14
    and-int/2addr v1, v5

    .line 618
    invoke-virtual {v11, v1, v6}, Lzi2;->Y(IZ)Z

    .line 619
    .line 620
    .line 621
    move-result v1

    .line 622
    if-eqz v1, :cond_15

    .line 623
    .line 624
    const v1, 0x7f0f054a

    .line 625
    .line 626
    .line 627
    invoke-static {v1, v11}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 628
    .line 629
    .line 630
    move-result-object v1

    .line 631
    iget-object v0, v0, Lvv;->H:Lmn7;

    .line 632
    .line 633
    invoke-static {v0, v11}, Ly67;->k(Lmn7;Lzi2;)Ljava/lang/String;

    .line 634
    .line 635
    .line 636
    move-result-object v4

    .line 637
    new-instance v6, Lu31;

    .line 638
    .line 639
    const/16 v0, 0x1c

    .line 640
    .line 641
    invoke-direct {v6, v0}, Lu31;-><init>(B)V

    .line 642
    .line 643
    .line 644
    iget-object v7, v3, Lui7;->j:Lwh2;

    .line 645
    .line 646
    const/4 v12, 0x0

    .line 647
    const/16 v13, 0x3e0

    .line 648
    .line 649
    sget-object v5, Lmn7;->l:Lc42;

    .line 650
    .line 651
    const/4 v8, 0x0

    .line 652
    const/4 v9, 0x0

    .line 653
    const/4 v10, 0x0

    .line 654
    move-object v3, v1

    .line 655
    invoke-static/range {v3 .. v13}, Lkj7;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lbi2;Lwh2;Ls21;Ls21;ZLzi2;II)V

    .line 656
    .line 657
    .line 658
    goto :goto_b

    .line 659
    :cond_15
    invoke-virtual {v11}, Lzi2;->b0()V

    .line 660
    .line 661
    .line 662
    :goto_b
    return-object v2

    .line 663
    :pswitch_9
    move-object/from16 v1, p1

    .line 664
    .line 665
    check-cast v1, Lzi2;

    .line 666
    .line 667
    move-object/from16 v7, p2

    .line 668
    .line 669
    check-cast v7, Ljava/lang/Integer;

    .line 670
    .line 671
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 672
    .line 673
    .line 674
    move-result v7

    .line 675
    and-int/lit8 v8, v7, 0x3

    .line 676
    .line 677
    if-eq v8, v4, :cond_16

    .line 678
    .line 679
    move v6, v5

    .line 680
    :cond_16
    and-int/2addr v7, v5

    .line 681
    invoke-virtual {v1, v7, v6}, Lzi2;->Y(IZ)Z

    .line 682
    .line 683
    .line 684
    move-result v5

    .line 685
    if-eqz v5, :cond_17

    .line 686
    .line 687
    const v5, 0x7f0f054f

    .line 688
    .line 689
    .line 690
    invoke-static {v5, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 691
    .line 692
    .line 693
    move-result-object v12

    .line 694
    iget-object v0, v0, Lvv;->a:Lss7;

    .line 695
    .line 696
    invoke-static {v0, v1}, Ly67;->l(Lss7;Lzi2;)Ljava/lang/String;

    .line 697
    .line 698
    .line 699
    move-result-object v13

    .line 700
    new-instance v15, Lej7;

    .line 701
    .line 702
    invoke-direct {v15, v4}, Lej7;-><init>(B)V

    .line 703
    .line 704
    .line 705
    iget-object v0, v3, Lui7;->a:Lwh2;

    .line 706
    .line 707
    const/16 v21, 0x0

    .line 708
    .line 709
    const/16 v22, 0x3e0

    .line 710
    .line 711
    sget-object v14, Lss7;->n:Lc42;

    .line 712
    .line 713
    const/16 v17, 0x0

    .line 714
    .line 715
    const/16 v18, 0x0

    .line 716
    .line 717
    const/16 v19, 0x0

    .line 718
    .line 719
    move-object/from16 v16, v0

    .line 720
    .line 721
    move-object/from16 v20, v1

    .line 722
    .line 723
    invoke-static/range {v12 .. v22}, Lkj7;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lbi2;Lwh2;Ls21;Ls21;ZLzi2;II)V

    .line 724
    .line 725
    .line 726
    goto :goto_c

    .line 727
    :cond_17
    move-object/from16 v20, v1

    .line 728
    .line 729
    invoke-virtual/range {v20 .. v20}, Lzi2;->b0()V

    .line 730
    .line 731
    .line 732
    :goto_c
    return-object v2

    .line 733
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
