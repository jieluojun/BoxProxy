.class public interface abstract Lb37;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public abstract a()V
.end method

.method public b(Lka;)V
    .locals 0

    .line 1
    return-void
.end method

.method public c(I)J
    .locals 0

    .line 1
    const-wide/16 p0, 0x0

    .line 2
    .line 3
    return-wide p0
.end method

.method public d()I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public e(IJ)V
    .locals 0

    .line 1
    return-void
.end method
