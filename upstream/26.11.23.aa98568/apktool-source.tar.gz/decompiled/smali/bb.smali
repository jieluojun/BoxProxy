.class public final Lbb;
.super Landroid/view/ViewGroup;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lk16;
.implements Ltn1;
.implements Ly05;
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
.implements Landroid/view/ViewTreeObserver$OnScrollChangedListener;
.implements Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;
.implements Lfe2;


# static fields
.field public static R0:Ljava/lang/Class;

.field public static S0:Ljava/lang/reflect/Method;

.field public static T0:Ljava/lang/reflect/Method;

.field public static final U0:Lfe4;

.field public static V0:Lra;

.field public static W0:Ljava/lang/reflect/Method;


# instance fields
.field public final A:Lm38;

.field public A0:F

.field public final B:Lzi3;

.field public B0:F

.field public final C:Lrd4;

.field public C0:F

.field public final D:Lzv5;

.field public D0:F

.field public final E:Lgl6;

.field public final E0:Lya;

.field public final F:Ljb;

.field public final F0:Lpa;

.field public G:Lrb;

.field public G0:Z

.field public final H:Ltc;

.field public H0:Lai2;

.field public final I:Lcz;

.field public final I0:Lu63;

.field public final J:Lfe4;

.field public final J0:Lja;

.field public K:Lfe4;

.field public final K0:Lja;

.field public L:Z

.field public L0:Z

.field public M:Z

.field public M0:Z

.field public final N:Lrb4;

.field public N0:Z

.field public final O:Lse;

.field public final O0:Lmg6;

.field public final P:Lz75;

.field public P0:Landroid/view/View;

.field public final Q:Lz75;

.field public final Q0:Lxa;

.field public final R:Lca;

.field public final S:Lda;

.field public T:Z

.field public final U:Li45;

.field public V:Z

.field public W:Llg;

.field public a0:Ljb1;

.field public b0:Z

.field public final c0:Lk92;

.field public d0:J

.field public final e0:[I

.field public final f0:[F

.field public final g0:Landroid/graphics/Matrix;

.field public h:Lw41;

.field public final h0:[F

.field public i:J

.field public final i0:[F

.field public final j:Z

.field public j0:J

.field public k:Lj63;

.field public k0:Z

.field public l:Lyo3;

.field public l0:J

.field public m:Lzo3;

.field public m0:Lwh2;

.field public n:Lms1;

.field public n0:Llf7;

.field public o:Lzz5;

.field public o0:Ljf7;

.field public final p:Lrw;

.field public final p0:Ljava/util/concurrent/atomic/AtomicReference;

.field public final q:Lpa;

.field public q0:Ldp1;

.field public r:Lsy7;

.field public final r0:Lz75;

.field public final s:Lz75;

.field public final s0:Lz75;

.field public final t:Landroid/view/View;

.field public t0:Lg83;

.field public final u:Lje2;

.field public final u0:Lgb4;

.field public v:Laj1;

.field public v0:Lnf;

.field public final w:Lhc;

.field public w0:Landroid/view/MotionEvent;

.field public final x:Ly6;

.field public x0:J

.field public final y:Lz75;

.field public final y0:Lxp6;

.field public final z:Ltp1;

.field public final z0:Lfe4;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lfe4;

    .line 2
    .line 3
    invoke-direct {v0}, Lfe4;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lbb;->U0:Lfe4;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lw41;)V
    .locals 16

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    move-object/from16 v8, p1

    .line 4
    .line 5
    move-object/from16 v9, p2

    .line 6
    .line 7
    invoke-direct/range {p0 .. p1}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    iput-object v9, v2, Lbb;->h:Lw41;

    .line 11
    .line 12
    const-wide v0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    iput-wide v0, v2, Lbb;->i:J

    .line 18
    .line 19
    const/4 v10, 0x1

    .line 20
    iput-boolean v10, v2, Lbb;->j:Z

    .line 21
    .line 22
    sget-object v0, Lh22;->t:Lh22;

    .line 23
    .line 24
    iput-object v0, v2, Lbb;->o:Lzz5;

    .line 25
    .line 26
    new-instance v0, Lrw;

    .line 27
    .line 28
    invoke-direct {v0}, Lrw;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object v0, v2, Lbb;->p:Lrw;

    .line 32
    .line 33
    new-instance v0, Lpa;

    .line 34
    .line 35
    const/4 v11, 0x0

    .line 36
    invoke-direct {v0, v2, v11}, Lpa;-><init>(Lbb;B)V

    .line 37
    .line 38
    .line 39
    iput-object v0, v2, Lbb;->q:Lpa;

    .line 40
    .line 41
    invoke-static {v8}, Lnb3;->d(Landroid/content/Context;)Lop1;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    sget-object v1, Lpc5;->m:Lpc5;

    .line 46
    .line 47
    new-instance v3, Lz75;

    .line 48
    .line 49
    invoke-direct {v3, v0, v1}, Lz75;-><init>(Ljava/lang/Object;Lhw6;)V

    .line 50
    .line 51
    .line 52
    iput-object v3, v2, Lbb;->s:Lz75;

    .line 53
    .line 54
    new-instance v0, Lje2;

    .line 55
    .line 56
    invoke-direct {v0, v2, v2}, Lje2;-><init>(Lbb;Lbb;)V

    .line 57
    .line 58
    .line 59
    iput-object v0, v2, Lbb;->u:Lje2;

    .line 60
    .line 61
    invoke-virtual {v9}, Lw41;->c()Ln51;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {v0}, Ln51;->k()Laj1;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    iput-object v0, v2, Lbb;->v:Laj1;

    .line 70
    .line 71
    new-instance v0, Lhc;

    .line 72
    .line 73
    invoke-direct {v0}, Lhc;-><init>()V

    .line 74
    .line 75
    .line 76
    iput-object v0, v2, Lbb;->w:Lhc;

    .line 77
    .line 78
    sget-object v0, Ly6;->z:Ly6;

    .line 79
    .line 80
    iput-object v0, v2, Lbb;->x:Ly6;

    .line 81
    .line 82
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 83
    .line 84
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    iput-object v0, v2, Lbb;->y:Lz75;

    .line 89
    .line 90
    new-instance v0, Lja;

    .line 91
    .line 92
    const/4 v12, 0x2

    .line 93
    invoke-direct {v0, v2, v12}, Lja;-><init>(Lbb;B)V

    .line 94
    .line 95
    .line 96
    invoke-static {v0}, Liw6;->a(Llh2;)Ltp1;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    iput-object v0, v2, Lbb;->z:Ltp1;

    .line 101
    .line 102
    new-instance v0, Lm38;

    .line 103
    .line 104
    invoke-direct {v0, v2}, Lm38;-><init>(Lbb;)V

    .line 105
    .line 106
    .line 107
    iput-object v0, v2, Lbb;->A:Lm38;

    .line 108
    .line 109
    new-instance v0, Lzi3;

    .line 110
    .line 111
    const/4 v13, 0x3

    .line 112
    invoke-direct {v0, v13}, Lzi3;-><init>(I)V

    .line 113
    .line 114
    .line 115
    sget-object v1, Ll16;->c:Ll16;

    .line 116
    .line 117
    invoke-virtual {v0, v1}, Lzi3;->d0(Lu14;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v2}, Lbb;->getDensity()Lkp1;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    invoke-virtual {v0, v1}, Lzi3;->a0(Lkp1;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v2}, Lbb;->getViewConfiguration()Lqx7;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    invoke-virtual {v0, v1}, Lzi3;->f0(Lqx7;)V

    .line 132
    .line 133
    .line 134
    new-instance v1, Lza;

    .line 135
    .line 136
    invoke-direct {v1, v2}, Lza;-><init>(Lbb;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v2}, Lbb;->getFocusOwner()Lge2;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    check-cast v3, Lje2;

    .line 144
    .line 145
    iget-object v3, v3, Lje2;->f:Lie2;

    .line 146
    .line 147
    invoke-interface {v1, v3}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 148
    .line 149
    .line 150
    move-result-object v1

    .line 151
    invoke-virtual {v2}, Lbb;->getDragAndDropManager()Lhc;

    .line 152
    .line 153
    .line 154
    move-result-object v3

    .line 155
    iget-object v3, v3, Lhc;->c:Lgc;

    .line 156
    .line 157
    invoke-interface {v1, v3}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-virtual {v0, v1}, Lzi3;->e0(Lbb4;)V

    .line 162
    .line 163
    .line 164
    iput-object v0, v2, Lbb;->B:Lzi3;

    .line 165
    .line 166
    sget-object v0, Lo93;->a:Lrd4;

    .line 167
    .line 168
    new-instance v0, Lrd4;

    .line 169
    .line 170
    invoke-direct {v0}, Lrd4;-><init>()V

    .line 171
    .line 172
    .line 173
    iput-object v0, v2, Lbb;->C:Lrd4;

    .line 174
    .line 175
    new-instance v0, Lzv5;

    .line 176
    .line 177
    invoke-virtual {v2}, Lbb;->getLayoutNodes()Lrd4;

    .line 178
    .line 179
    .line 180
    move-result-object v1

    .line 181
    invoke-direct {v0, v1, v2}, Lzv5;-><init>(Lrd4;Lbb;)V

    .line 182
    .line 183
    .line 184
    iput-object v0, v2, Lbb;->D:Lzv5;

    .line 185
    .line 186
    new-instance v0, Lgl6;

    .line 187
    .line 188
    invoke-virtual {v2}, Lbb;->getRoot()Lzi3;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    new-instance v3, Ls22;

    .line 193
    .line 194
    invoke-direct {v3}, Lab4;-><init>()V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v2}, Lbb;->getLayoutNodes()Lrd4;

    .line 198
    .line 199
    .line 200
    move-result-object v4

    .line 201
    invoke-direct {v0, v1, v3, v4}, Lgl6;-><init>(Lzi3;Ls22;Lrd4;)V

    .line 202
    .line 203
    .line 204
    iput-object v0, v2, Lbb;->E:Lgl6;

    .line 205
    .line 206
    new-instance v14, Ljb;

    .line 207
    .line 208
    invoke-direct {v14, v2}, Ljb;-><init>(Lbb;)V

    .line 209
    .line 210
    .line 211
    iput-object v14, v2, Lbb;->F:Ljb;

    .line 212
    .line 213
    new-instance v15, Lrb;

    .line 214
    .line 215
    new-instance v0, Lwa;

    .line 216
    .line 217
    const/4 v6, 0x1

    .line 218
    const/4 v7, 0x0

    .line 219
    const/4 v1, 0x0

    .line 220
    const-class v3, Lkb;

    .line 221
    .line 222
    const-string v4, "getContentCaptureSessionCompat"

    .line 223
    .line 224
    const-string v5, "getContentCaptureSessionCompat(Landroid/view/View;)Landroidx/compose/ui/contentcapture/ContentCaptureSessionWrapper;"

    .line 225
    .line 226
    invoke-direct/range {v0 .. v7}, Lwa;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 227
    .line 228
    .line 229
    invoke-direct {v15, v2, v0}, Lrb;-><init>(Lbb;Lwa;)V

    .line 230
    .line 231
    .line 232
    iput-object v15, v2, Lbb;->G:Lrb;

    .line 233
    .line 234
    new-instance v0, Ltc;

    .line 235
    .line 236
    invoke-direct {v0, v2}, Ltc;-><init>(Lbb;)V

    .line 237
    .line 238
    .line 239
    iput-object v0, v2, Lbb;->H:Ltc;

    .line 240
    .line 241
    new-instance v0, Lcz;

    .line 242
    .line 243
    invoke-direct {v0}, Lcz;-><init>()V

    .line 244
    .line 245
    .line 246
    iput-object v0, v2, Lbb;->I:Lcz;

    .line 247
    .line 248
    new-instance v0, Lfe4;

    .line 249
    .line 250
    invoke-direct {v0}, Lfe4;-><init>()V

    .line 251
    .line 252
    .line 253
    iput-object v0, v2, Lbb;->J:Lfe4;

    .line 254
    .line 255
    new-instance v0, Lrb4;

    .line 256
    .line 257
    invoke-direct {v0}, Lrb4;-><init>()V

    .line 258
    .line 259
    .line 260
    iput-object v0, v2, Lbb;->N:Lrb4;

    .line 261
    .line 262
    new-instance v0, Lse;

    .line 263
    .line 264
    invoke-virtual {v2}, Lbb;->getRoot()Lzi3;

    .line 265
    .line 266
    .line 267
    move-result-object v1

    .line 268
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 269
    .line 270
    .line 271
    iput-object v1, v0, Lse;->b:Ljava/lang/Object;

    .line 272
    .line 273
    new-instance v3, Lws2;

    .line 274
    .line 275
    iget-object v1, v1, Lzi3;->M:Lu9;

    .line 276
    .line 277
    iget-object v1, v1, Lu9;->d:Ljava/lang/Object;

    .line 278
    .line 279
    check-cast v1, Lv73;

    .line 280
    .line 281
    invoke-direct {v3, v1}, Lws2;-><init>(Lhi3;)V

    .line 282
    .line 283
    .line 284
    iput-object v3, v0, Lse;->c:Ljava/lang/Object;

    .line 285
    .line 286
    new-instance v1, Lzy7;

    .line 287
    .line 288
    const/16 v3, 0x1d

    .line 289
    .line 290
    invoke-direct {v1, v3}, Lzy7;-><init>(B)V

    .line 291
    .line 292
    .line 293
    iput-object v1, v0, Lse;->d:Ljava/lang/Object;

    .line 294
    .line 295
    new-instance v1, Lzs2;

    .line 296
    .line 297
    invoke-direct {v1}, Lzs2;-><init>()V

    .line 298
    .line 299
    .line 300
    iput-object v1, v0, Lse;->e:Ljava/lang/Object;

    .line 301
    .line 302
    iput-object v0, v2, Lbb;->O:Lse;

    .line 303
    .line 304
    new-instance v0, Landroid/content/res/Configuration;

    .line 305
    .line 306
    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 307
    .line 308
    .line 309
    move-result-object v1

    .line 310
    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    invoke-direct {v0, v1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 315
    .line 316
    .line 317
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    iput-object v0, v2, Lbb;->P:Lz75;

    .line 322
    .line 323
    invoke-virtual {v2}, Lbb;->getConfiguration()Landroid/content/res/Configuration;

    .line 324
    .line 325
    .line 326
    move-result-object v0

    .line 327
    invoke-virtual {v0}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    .line 328
    .line 329
    .line 330
    move-result-object v0

    .line 331
    invoke-static {v0}, Lgu3;->d(Landroid/os/LocaleList;)Lgu3;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    invoke-static {v0}, Lbb;->h(Lgu3;)Lfu3;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    iput-object v0, v2, Lbb;->Q:Lz75;

    .line 344
    .line 345
    new-instance v0, Lca;

    .line 346
    .line 347
    invoke-virtual {v2}, Lbb;->getAutofillTree()Lcz;

    .line 348
    .line 349
    .line 350
    move-result-object v1

    .line 351
    invoke-direct {v0, v2, v1}, Lca;-><init>(Lbb;Lcz;)V

    .line 352
    .line 353
    .line 354
    iput-object v0, v2, Lbb;->R:Lca;

    .line 355
    .line 356
    new-instance v0, Lda;

    .line 357
    .line 358
    new-instance v1, Leq2;

    .line 359
    .line 360
    const/16 v3, 0x15

    .line 361
    .line 362
    invoke-direct {v1, v8, v3}, Leq2;-><init>(Ljava/lang/Object;B)V

    .line 363
    .line 364
    .line 365
    invoke-virtual/range {p0 .. p0}, Lbb;->getSemanticsOwner()Lgl6;

    .line 366
    .line 367
    .line 368
    move-result-object v2

    .line 369
    invoke-virtual/range {p0 .. p0}, Lbb;->getRectManager()Lzv5;

    .line 370
    .line 371
    .line 372
    move-result-object v4

    .line 373
    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 374
    .line 375
    .line 376
    move-result-object v5

    .line 377
    move-object/from16 v3, p0

    .line 378
    .line 379
    invoke-direct/range {v0 .. v5}, Lda;-><init>(Leq2;Lgl6;Lbb;Lzv5;Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    move-object v2, v3

    .line 383
    iput-object v0, v2, Lbb;->S:Lda;

    .line 384
    .line 385
    new-instance v0, Li45;

    .line 386
    .line 387
    new-instance v1, Lna;

    .line 388
    .line 389
    invoke-direct {v1, v2, v10}, Lna;-><init>(Lbb;B)V

    .line 390
    .line 391
    .line 392
    invoke-direct {v0, v1}, Li45;-><init>(Lna;)V

    .line 393
    .line 394
    .line 395
    iput-object v0, v2, Lbb;->U:Li45;

    .line 396
    .line 397
    new-instance v0, Lk92;

    .line 398
    .line 399
    invoke-virtual {v2}, Lbb;->getRoot()Lzi3;

    .line 400
    .line 401
    .line 402
    move-result-object v1

    .line 403
    invoke-direct {v0, v1}, Lk92;-><init>(Lzi3;)V

    .line 404
    .line 405
    .line 406
    iput-object v0, v2, Lbb;->c0:Lk92;

    .line 407
    .line 408
    const-wide v0, 0x7fffffff7fffffffL

    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    iput-wide v0, v2, Lbb;->d0:J

    .line 414
    .line 415
    filled-new-array {v11, v11}, [I

    .line 416
    .line 417
    .line 418
    move-result-object v0

    .line 419
    iput-object v0, v2, Lbb;->e0:[I

    .line 420
    .line 421
    invoke-static {}, Lo14;->a()[F

    .line 422
    .line 423
    .line 424
    move-result-object v0

    .line 425
    iput-object v0, v2, Lbb;->f0:[F

    .line 426
    .line 427
    new-instance v0, Landroid/graphics/Matrix;

    .line 428
    .line 429
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    .line 430
    .line 431
    .line 432
    iput-object v0, v2, Lbb;->g0:Landroid/graphics/Matrix;

    .line 433
    .line 434
    invoke-static {}, Lo14;->a()[F

    .line 435
    .line 436
    .line 437
    move-result-object v0

    .line 438
    iput-object v0, v2, Lbb;->h0:[F

    .line 439
    .line 440
    invoke-static {}, Lo14;->a()[F

    .line 441
    .line 442
    .line 443
    move-result-object v0

    .line 444
    iput-object v0, v2, Lbb;->i0:[F

    .line 445
    .line 446
    const-wide/16 v0, -0x1

    .line 447
    .line 448
    iput-wide v0, v2, Lbb;->j0:J

    .line 449
    .line 450
    const-wide v0, 0x7f8000007f800000L    # 1.404448428688076E306

    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    iput-wide v0, v2, Lbb;->l0:J

    .line 456
    .line 457
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 458
    .line 459
    const/4 v1, 0x0

    .line 460
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 461
    .line 462
    .line 463
    iput-object v0, v2, Lbb;->p0:Ljava/util/concurrent/atomic/AtomicReference;

    .line 464
    .line 465
    iget-object v0, v9, Lw41;->t:Lz75;

    .line 466
    .line 467
    iput-object v0, v2, Lbb;->r0:Lz75;

    .line 468
    .line 469
    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 470
    .line 471
    .line 472
    move-result-object v0

    .line 473
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 474
    .line 475
    .line 476
    move-result-object v0

    .line 477
    invoke-virtual {v0}, Landroid/content/res/Configuration;->getLayoutDirection()I

    .line 478
    .line 479
    .line 480
    move-result v0

    .line 481
    sget-object v3, Lde2;->a:[I

    .line 482
    .line 483
    sget-object v3, Lii3;->h:Lii3;

    .line 484
    .line 485
    if-eqz v0, :cond_1

    .line 486
    .line 487
    if-eq v0, v10, :cond_0

    .line 488
    .line 489
    move-object v0, v1

    .line 490
    goto :goto_0

    .line 491
    :cond_0
    sget-object v0, Lii3;->i:Lii3;

    .line 492
    .line 493
    goto :goto_0

    .line 494
    :cond_1
    move-object v0, v3

    .line 495
    :goto_0
    if-eqz v0, :cond_2

    .line 496
    .line 497
    move-object v3, v0

    .line 498
    :cond_2
    invoke-static {v3}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 499
    .line 500
    .line 501
    move-result-object v0

    .line 502
    iput-object v0, v2, Lbb;->s0:Lz75;

    .line 503
    .line 504
    new-instance v0, Lgb4;

    .line 505
    .line 506
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 507
    .line 508
    .line 509
    iput-object v0, v2, Lbb;->u0:Lgb4;

    .line 510
    .line 511
    new-instance v0, Lxp6;

    .line 512
    .line 513
    const/16 v3, 0x8

    .line 514
    .line 515
    invoke-direct {v0, v3}, Lxp6;-><init>(B)V

    .line 516
    .line 517
    .line 518
    iput-object v0, v2, Lbb;->y0:Lxp6;

    .line 519
    .line 520
    new-instance v0, Lfe4;

    .line 521
    .line 522
    invoke-direct {v0}, Lfe4;-><init>()V

    .line 523
    .line 524
    .line 525
    iput-object v0, v2, Lbb;->z0:Lfe4;

    .line 526
    .line 527
    const/high16 v0, 0x7fc00000    # Float.NaN

    .line 528
    .line 529
    iput v0, v2, Lbb;->A0:F

    .line 530
    .line 531
    iput v0, v2, Lbb;->B0:F

    .line 532
    .line 533
    iput v0, v2, Lbb;->C0:F

    .line 534
    .line 535
    iput v0, v2, Lbb;->D0:F

    .line 536
    .line 537
    new-instance v0, Lya;

    .line 538
    .line 539
    invoke-direct {v0, v2, v11}, Lya;-><init>(Ljava/lang/Object;B)V

    .line 540
    .line 541
    .line 542
    iput-object v0, v2, Lbb;->E0:Lya;

    .line 543
    .line 544
    new-instance v0, Lpa;

    .line 545
    .line 546
    invoke-direct {v0, v2, v10}, Lpa;-><init>(Lbb;B)V

    .line 547
    .line 548
    .line 549
    iput-object v0, v2, Lbb;->F0:Lpa;

    .line 550
    .line 551
    new-instance v0, Lu63;

    .line 552
    .line 553
    new-instance v3, Lna;

    .line 554
    .line 555
    invoke-direct {v3, v2, v12}, Lna;-><init>(Lbb;B)V

    .line 556
    .line 557
    .line 558
    invoke-direct {v0, v2, v3}, Lu63;-><init>(Lbb;Lna;)V

    .line 559
    .line 560
    .line 561
    iput-object v0, v2, Lbb;->I0:Lu63;

    .line 562
    .line 563
    new-instance v0, Lja;

    .line 564
    .line 565
    invoke-direct {v0, v2, v13}, Lja;-><init>(Lbb;B)V

    .line 566
    .line 567
    .line 568
    iput-object v0, v2, Lbb;->J0:Lja;

    .line 569
    .line 570
    new-instance v0, Lja;

    .line 571
    .line 572
    invoke-direct {v0, v2, v11}, Lja;-><init>(Lbb;B)V

    .line 573
    .line 574
    .line 575
    iput-object v0, v2, Lbb;->K0:Lja;

    .line 576
    .line 577
    iget-object v0, v2, Lbb;->G:Lrb;

    .line 578
    .line 579
    invoke-virtual {v2, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 580
    .line 581
    .line 582
    invoke-virtual {v2, v11}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 583
    .line 584
    .line 585
    invoke-virtual {v2, v10}, Landroid/view/View;->setFocusable(Z)V

    .line 586
    .line 587
    .line 588
    invoke-static {v2, v10, v11}, Lqj;->a(Landroid/view/View;IZ)V

    .line 589
    .line 590
    .line 591
    invoke-virtual {v2, v10}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 592
    .line 593
    .line 594
    invoke-virtual {v2, v11}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 595
    .line 596
    .line 597
    invoke-static {v2, v14}, Lox7;->e(Landroid/view/View;Lx4;)V

    .line 598
    .line 599
    .line 600
    invoke-virtual {v2}, Lbb;->getDragAndDropManager()Lhc;

    .line 601
    .line 602
    .line 603
    move-result-object v0

    .line 604
    invoke-virtual {v2, v0}, Landroid/view/View;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    .line 605
    .line 606
    .line 607
    invoke-static {v2}, Lrj;->b(Landroid/view/View;)V

    .line 608
    .line 609
    .line 610
    invoke-static {}, Lbb;->l()Z

    .line 611
    .line 612
    .line 613
    move-result v0

    .line 614
    if-eqz v0, :cond_3

    .line 615
    .line 616
    new-instance v0, Landroid/view/View;

    .line 617
    .line 618
    invoke-direct {v0, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 619
    .line 620
    .line 621
    new-instance v3, Landroid/view/ViewGroup$LayoutParams;

    .line 622
    .line 623
    invoke-direct {v3, v10, v10}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 624
    .line 625
    .line 626
    invoke-virtual {v0, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 627
    .line 628
    .line 629
    const v3, 0x7f090074

    .line 630
    .line 631
    .line 632
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 633
    .line 634
    invoke-virtual {v0, v3, v4}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 635
    .line 636
    .line 637
    iput-object v0, v2, Lbb;->t:Landroid/view/View;

    .line 638
    .line 639
    const/4 v3, -0x1

    .line 640
    invoke-virtual {v2, v0, v3}, Lbb;->addView(Landroid/view/View;I)V

    .line 641
    .line 642
    .line 643
    :cond_3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 644
    .line 645
    const/16 v3, 0x1f

    .line 646
    .line 647
    if-lt v0, v3, :cond_4

    .line 648
    .line 649
    new-instance v1, Lmg6;

    .line 650
    .line 651
    invoke-direct {v1}, Lmg6;-><init>()V

    .line 652
    .line 653
    .line 654
    :cond_4
    iput-object v1, v2, Lbb;->O0:Lmg6;

    .line 655
    .line 656
    new-instance v0, Lxa;

    .line 657
    .line 658
    invoke-direct {v0, v2}, Lxa;-><init>(Lbb;)V

    .line 659
    .line 660
    .line 661
    iput-object v0, v2, Lbb;->Q0:Lxa;

    .line 662
    .line 663
    return-void
.end method

.method public static c(Landroid/view/ViewGroup;)V
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    :goto_0
    if-ge v1, v0, :cond_2

    .line 7
    .line 8
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    instance-of v3, v2, Lbb;

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    check-cast v2, Lbb;

    .line 17
    .line 18
    invoke-virtual {v2}, Lbb;->t()V

    .line 19
    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_0
    instance-of v3, v2, Landroid/view/ViewGroup;

    .line 23
    .line 24
    if-eqz v3, :cond_1

    .line 25
    .line 26
    check-cast v2, Landroid/view/ViewGroup;

    .line 27
    .line 28
    invoke-static {v2}, Lbb;->c(Landroid/view/ViewGroup;)V

    .line 29
    .line 30
    .line 31
    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_2
    return-void
.end method

.method public static d(I)J
    .locals 4

    .line 1
    invoke-static {p0}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-static {p0}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    const/high16 v1, -0x80000000

    .line 10
    .line 11
    if-eq v0, v1, :cond_2

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    const/high16 v1, 0x40000000    # 2.0f

    .line 16
    .line 17
    if-ne v0, v1, :cond_0

    .line 18
    .line 19
    int-to-long v0, p0

    .line 20
    const/16 p0, 0x20

    .line 21
    .line 22
    shl-long v2, v0, p0

    .line 23
    .line 24
    or-long/2addr v2, v0

    .line 25
    return-wide v2

    .line 26
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 27
    .line 28
    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 29
    .line 30
    .line 31
    throw p0

    .line 32
    :cond_1
    const-wide/32 v0, 0x7fffffff

    .line 33
    .line 34
    .line 35
    return-wide v0

    .line 36
    :cond_2
    int-to-long v0, p0

    .line 37
    return-wide v0
.end method

.method public static final f(Lbb;Landroid/view/KeyEvent;)Z
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static synthetic getAndroidViewsHandler$androidx_compose_ui_ui$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method private final getCanvasHolder()Lul0;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->y:Lul0;

    .line 4
    .line 5
    return-object p0
.end method

.method private final getDerivedIsAttached()Z
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->z:Ltp1;

    .line 2
    .line 3
    invoke-virtual {p0}, Ltp1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public static synthetic getFontLoader$annotations()V
    .locals 0
    .annotation runtime Lpp1;
    .end annotation

    .line 1
    return-void
.end method

.method public static synthetic getLastMatrixRecalculationAnimationTime$androidx_compose_ui_ui$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method private final getLegacyTextInputServiceAndroid()Llf7;
    .locals 4

    .line 1
    iget-object v0, p0, Lbb;->n0:Llf7;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Llf7;

    .line 6
    .line 7
    new-instance v1, Lla;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-direct {v1, p0, v2}, Lla;-><init>(Ljava/lang/Object;B)V

    .line 11
    .line 12
    .line 13
    new-instance v2, Lla;

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-direct {v2, p0, v3}, Lla;-><init>(Ljava/lang/Object;B)V

    .line 17
    .line 18
    .line 19
    invoke-direct {v0, p0, p0, v1, v2}, Llf7;-><init>(Lbb;Lbb;Lla;Lla;)V

    .line 20
    .line 21
    .line 22
    iput-object v0, p0, Lbb;->n0:Llf7;

    .line 23
    .line 24
    :cond_0
    return-object v0
.end method

.method public static synthetic getPlayNavigationSoundEffect$androidx_compose_ui_ui$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method public static synthetic getPrimaryDirectionalMotionAxisOverride-dqNNBbU$androidx_compose_ui_ui$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method public static synthetic getRoot$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method public static synthetic getTextInputService$annotations()V
    .locals 0
    .annotation runtime Lpp1;
    .end annotation

    .line 1
    return-void
.end method

.method public static synthetic getUiMediaScope$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method public static synthetic getWindowInfo$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method public static synthetic get_uiMediaScope$androidx_compose_ui_ui$annotations()V
    .locals 0

    .line 1
    return-void
.end method

.method public static h(Lgu3;)Lfu3;
    .locals 5

    .line 1
    invoke-virtual {p0}, Lgu3;->b()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-static {}, Landroid/os/LocaleList;->getDefault()Landroid/os/LocaleList;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    invoke-static {p0}, Lgu3;->d(Landroid/os/LocaleList;)Lgu3;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    :cond_0
    iget-object p0, p0, Lgu3;->a:Lhu3;

    .line 16
    .line 17
    iget-object v0, p0, Lhu3;->a:Landroid/os/LocaleList;

    .line 18
    .line 19
    invoke-virtual {v0}, Landroid/os/LocaleList;->size()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    new-instance v1, Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 26
    .line 27
    .line 28
    const/4 v2, 0x0

    .line 29
    :goto_0
    if-ge v2, v0, :cond_1

    .line 30
    .line 31
    new-instance v3, Leu3;

    .line 32
    .line 33
    iget-object v4, p0, Lhu3;->a:Landroid/os/LocaleList;

    .line 34
    .line 35
    invoke-virtual {v4, v2}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    invoke-direct {v3, v4}, Leu3;-><init>(Ljava/util/Locale;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    add-int/lit8 v2, v2, 0x1

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_1
    new-instance p0, Lfu3;

    .line 52
    .line 53
    invoke-direct {p0, v1}, Lfu3;-><init>(Ljava/util/List;)V

    .line 54
    .line 55
    .line 56
    return-object p0
.end method

.method public static j(Lzi3;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lzi3;->D()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lzi3;->z()Lve4;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    iget-object v0, p0, Lve4;->h:[Ljava/lang/Object;

    .line 9
    .line 10
    iget p0, p0, Lve4;->j:I

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    :goto_0
    if-ge v1, p0, :cond_0

    .line 14
    .line 15
    aget-object v2, v0, v1

    .line 16
    .line 17
    check-cast v2, Lzi3;

    .line 18
    .line 19
    invoke-static {v2}, Lbb;->j(Lzi3;)V

    .line 20
    .line 21
    .line 22
    add-int/lit8 v1, v1, 0x1

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    return-void
.end method

.method public static l()Z
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x23

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    return v0

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    return v0
.end method

.method public static m(Landroid/view/MotionEvent;)Z
    .locals 7

    .line 1
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getX()F

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const v1, 0x7fffffff

    .line 10
    .line 11
    .line 12
    and-int/2addr v0, v1

    .line 13
    const/4 v2, 0x0

    .line 14
    const/4 v3, 0x1

    .line 15
    const/high16 v4, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 16
    .line 17
    if-ge v0, v4, :cond_0

    .line 18
    .line 19
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getY()F

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    and-int/2addr v0, v1

    .line 28
    if-ge v0, v4, :cond_0

    .line 29
    .line 30
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawX()F

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    and-int/2addr v0, v1

    .line 39
    if-ge v0, v4, :cond_0

    .line 40
    .line 41
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawY()F

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    and-int/2addr v0, v1

    .line 50
    if-ge v0, v4, :cond_0

    .line 51
    .line 52
    move v0, v2

    .line 53
    goto :goto_0

    .line 54
    :cond_0
    move v0, v3

    .line 55
    :goto_0
    if-nez v0, :cond_2

    .line 56
    .line 57
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 58
    .line 59
    .line 60
    move-result v5

    .line 61
    move v6, v3

    .line 62
    :goto_1
    if-ge v6, v5, :cond_2

    .line 63
    .line 64
    invoke-virtual {p0, v6}, Landroid/view/MotionEvent;->getX(I)F

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    and-int/2addr v0, v1

    .line 73
    if-ge v0, v4, :cond_1

    .line 74
    .line 75
    invoke-virtual {p0, v6}, Landroid/view/MotionEvent;->getY(I)F

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    and-int/2addr v0, v1

    .line 84
    if-ge v0, v4, :cond_1

    .line 85
    .line 86
    invoke-static {p0, v6}, Lrj;->c(Landroid/view/MotionEvent;I)Z

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v0, :cond_1

    .line 91
    .line 92
    move v0, v2

    .line 93
    goto :goto_2

    .line 94
    :cond_1
    move v0, v3

    .line 95
    :goto_2
    if-nez v0, :cond_2

    .line 96
    .line 97
    add-int/lit8 v6, v6, 0x1

    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_2
    return v0
.end method

.method private final setAttached(Z)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->y:Lz75;

    .line 2
    .line 3
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method private setDensity(Lkp1;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->s:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method private setLayoutDirection(Lii3;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->s0:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method private setLocaleList(Lfu3;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->Q:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final A(Landroid/view/MotionEvent;)V
    .locals 8

    .line 1
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    iput-wide v0, p0, Lbb;->j0:J

    .line 6
    .line 7
    iget-object v0, p0, Lbb;->g0:Landroid/graphics/Matrix;

    .line 8
    .line 9
    iget-object v1, p0, Lbb;->e0:[I

    .line 10
    .line 11
    iget-object v2, p0, Lbb;->h0:[F

    .line 12
    .line 13
    invoke-static {p0, v2, v0, v1}, Lrj;->a(Landroid/view/View;[FLandroid/graphics/Matrix;[I)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lbb;->i0:[F

    .line 17
    .line 18
    invoke-static {v2, v0}, Ldw;->H([F[F)Z

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    int-to-long v3, v0

    .line 34
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    int-to-long v0, v0

    .line 39
    const/16 v5, 0x20

    .line 40
    .line 41
    shl-long/2addr v3, v5

    .line 42
    const-wide v6, 0xffffffffL

    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    and-long/2addr v0, v6

    .line 48
    or-long/2addr v3, v0

    .line 49
    invoke-static {v3, v4, v2}, Lo14;->b(J[F)J

    .line 50
    .line 51
    .line 52
    move-result-wide v0

    .line 53
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    shr-long v3, v0, v5

    .line 58
    .line 59
    long-to-int v3, v3

    .line 60
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    sub-float/2addr v2, v3

    .line 65
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    and-long/2addr v0, v6

    .line 70
    long-to-int v0, v0

    .line 71
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    sub-float/2addr p1, v0

    .line 76
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    int-to-long v0, v0

    .line 81
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    int-to-long v2, p1

    .line 86
    shl-long/2addr v0, v5

    .line 87
    and-long/2addr v2, v6

    .line 88
    or-long/2addr v0, v2

    .line 89
    iput-wide v0, p0, Lbb;->l0:J

    .line 90
    .line 91
    return-void
.end method

.method public final B()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_0
    const/16 v0, 0x82

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-super {p0, v0, v1}, Landroid/view/ViewGroup;->requestFocus(ILandroid/graphics/Rect;)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method

.method public final C(Llh2;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lbb;->p:Lrw;

    .line 2
    .line 3
    invoke-virtual {v0}, Lrw;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0, p1}, Lrw;->addLast(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    if-eqz p1, :cond_0

    .line 17
    .line 18
    iget-object p0, p0, Lbb;->q:Lpa;

    .line 19
    .line 20
    invoke-virtual {p1, p0}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    const-string p0, "schedule is called when outOfFrameExecutor is not available (view is detached)"

    .line 25
    .line 26
    invoke-static {p0}, Ll42;->g(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    :cond_1
    return-void
.end method

.method public final D(Lzi3;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isLayoutRequested()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_4

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_4

    .line 12
    .line 13
    if-eqz p1, :cond_2

    .line 14
    .line 15
    :goto_0
    if-eqz p1, :cond_1

    .line 16
    .line 17
    invoke-virtual {p1}, Lzi3;->r()Lxi3;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sget-object v1, Lxi3;->h:Lxi3;

    .line 22
    .line 23
    if-ne v0, v1, :cond_1

    .line 24
    .line 25
    iget-boolean v0, p0, Lbb;->b0:Z

    .line 26
    .line 27
    if-nez v0, :cond_0

    .line 28
    .line 29
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    iget-object v0, v0, Lzi3;->M:Lu9;

    .line 36
    .line 37
    iget-object v0, v0, Lu9;->d:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, Lv73;

    .line 40
    .line 41
    iget-wide v0, v0, Lfb5;->k:J

    .line 42
    .line 43
    invoke-static {v0, v1}, Ljb1;->g(J)Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_0

    .line 48
    .line 49
    invoke-static {v0, v1}, Ljb1;->f(J)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_1

    .line 54
    .line 55
    :cond_0
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    goto :goto_0

    .line 60
    :cond_1
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    if-ne p1, v0, :cond_2

    .line 65
    .line 66
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    if-eqz p1, :cond_3

    .line 75
    .line 76
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    if-eqz p1, :cond_3

    .line 81
    .line 82
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 83
    .line 84
    .line 85
    return-void

    .line 86
    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 87
    .line 88
    .line 89
    :cond_4
    return-void
.end method

.method public final E(J)J
    .locals 6

    .line 1
    invoke-virtual {p0}, Lbb;->z()V

    .line 2
    .line 3
    .line 4
    const/16 v0, 0x20

    .line 5
    .line 6
    shr-long v1, p1, v0

    .line 7
    .line 8
    long-to-int v1, v1

    .line 9
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    iget-wide v2, p0, Lbb;->l0:J

    .line 14
    .line 15
    shr-long/2addr v2, v0

    .line 16
    long-to-int v2, v2

    .line 17
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    sub-float/2addr v1, v2

    .line 22
    const-wide v2, 0xffffffffL

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    and-long/2addr p1, v2

    .line 28
    long-to-int p1, p1

    .line 29
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    iget-wide v4, p0, Lbb;->l0:J

    .line 34
    .line 35
    and-long/2addr v4, v2

    .line 36
    long-to-int p2, v4

    .line 37
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 38
    .line 39
    .line 40
    move-result p2

    .line 41
    sub-float/2addr p1, p2

    .line 42
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 43
    .line 44
    .line 45
    move-result p2

    .line 46
    int-to-long v4, p2

    .line 47
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    int-to-long p1, p1

    .line 52
    shl-long/2addr v4, v0

    .line 53
    and-long/2addr p1, v2

    .line 54
    or-long/2addr v4, p1

    .line 55
    iget-object p0, p0, Lbb;->i0:[F

    .line 56
    .line 57
    invoke-static {v4, v5, p0}, Lo14;->b(J[F)J

    .line 58
    .line 59
    .line 60
    move-result-wide p0

    .line 61
    return-wide p0
.end method

.method public final F(Landroid/view/MotionEvent;)I
    .locals 10

    .line 1
    iget-boolean v0, p0, Lbb;->L0:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iput-boolean v1, p0, Lbb;->L0:Z

    .line 7
    .line 8
    iget-object v0, p0, Lbb;->h:Lw41;

    .line 9
    .line 10
    iget-object v0, v0, Lw41;->x:Lrn3;

    .line 11
    .line 12
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getMetaState()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    sget-object v2, Lx18;->a:Lz75;

    .line 17
    .line 18
    new-instance v3, Lad5;

    .line 19
    .line 20
    invoke-direct {v3, v0}, Lad5;-><init>(I)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v2, v3}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    iget-object v0, p0, Lbb;->N:Lrb4;

    .line 27
    .line 28
    invoke-virtual {v0, p1, p0}, Lrb4;->c(Landroid/view/MotionEvent;Lbb;)Lzi7;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    iget-object v4, p0, Lbb;->O:Lse;

    .line 37
    .line 38
    if-eqz v2, :cond_8

    .line 39
    .line 40
    iget-object v1, v2, Lzi7;->i:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v1, Ljava/util/ArrayList;

    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 45
    .line 46
    .line 47
    move-result v5

    .line 48
    add-int/lit8 v5, v5, -0x1

    .line 49
    .line 50
    const/4 v6, 0x0

    .line 51
    const/4 v7, 0x5

    .line 52
    if-ltz v5, :cond_2

    .line 53
    .line 54
    :goto_0
    add-int/lit8 v8, v5, -0x1

    .line 55
    .line 56
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v5

    .line 60
    move-object v9, v5

    .line 61
    check-cast v9, Lvc5;

    .line 62
    .line 63
    iget-boolean v9, v9, Lvc5;->e:Z

    .line 64
    .line 65
    if-eqz v9, :cond_1

    .line 66
    .line 67
    if-eqz v3, :cond_3

    .line 68
    .line 69
    if-eq v3, v7, :cond_3

    .line 70
    .line 71
    :cond_1
    if-ltz v8, :cond_2

    .line 72
    .line 73
    move v5, v8

    .line 74
    goto :goto_0

    .line 75
    :cond_2
    move-object v5, v6

    .line 76
    :cond_3
    check-cast v5, Lvc5;

    .line 77
    .line 78
    if-eqz v5, :cond_4

    .line 79
    .line 80
    iget-wide v8, v5, Lvc5;->d:J

    .line 81
    .line 82
    iput-wide v8, p0, Lbb;->i:J

    .line 83
    .line 84
    :cond_4
    iget-object v1, v2, Lzi7;->k:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v1, Lic5;

    .line 87
    .line 88
    invoke-virtual {p0, p1, v1}, Lbb;->n(Landroid/view/MotionEvent;Lic5;)Z

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    invoke-virtual {v4, v2, p0, v1}, Lse;->d(Lzi7;Lbb;Z)I

    .line 93
    .line 94
    .line 95
    move-result p0

    .line 96
    iput-object v6, v2, Lzi7;->j:Ljava/lang/Object;

    .line 97
    .line 98
    if-eqz v3, :cond_5

    .line 99
    .line 100
    if-ne v3, v7, :cond_6

    .line 101
    .line 102
    :cond_5
    and-int/lit8 v1, p0, 0x1

    .line 103
    .line 104
    if-eqz v1, :cond_7

    .line 105
    .line 106
    :cond_6
    return p0

    .line 107
    :cond_7
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 112
    .line 113
    .line 114
    move-result p1

    .line 115
    iget-object v1, v0, Lrb4;->c:Landroid/util/SparseBooleanArray;

    .line 116
    .line 117
    invoke-virtual {v1, p1}, Landroid/util/SparseBooleanArray;->delete(I)V

    .line 118
    .line 119
    .line 120
    iget-object v0, v0, Lrb4;->b:Landroid/util/SparseLongArray;

    .line 121
    .line 122
    invoke-virtual {v0, p1}, Landroid/util/SparseLongArray;->delete(I)V

    .line 123
    .line 124
    .line 125
    return p0

    .line 126
    :cond_8
    iget-boolean p0, v4, Lse;->a:Z

    .line 127
    .line 128
    if-nez p0, :cond_9

    .line 129
    .line 130
    iget-object p0, v4, Lse;->d:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast p0, Lzy7;

    .line 133
    .line 134
    iget-object p0, p0, Lzy7;->i:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast p0, Lxw3;

    .line 137
    .line 138
    invoke-virtual {p0}, Lxw3;->a()V

    .line 139
    .line 140
    .line 141
    iget-object p0, v4, Lse;->c:Ljava/lang/Object;

    .line 142
    .line 143
    check-cast p0, Lws2;

    .line 144
    .line 145
    invoke-virtual {p0}, Lws2;->c()V

    .line 146
    .line 147
    .line 148
    :cond_9
    return v1
.end method

.method public final G(Landroid/view/MotionEvent;IJZ)V
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move/from16 v5, p2

    .line 6
    .line 7
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const/16 v3, 0xa

    .line 12
    .line 13
    const/16 v4, 0x9

    .line 14
    .line 15
    const/4 v6, -0x1

    .line 16
    const/4 v7, 0x0

    .line 17
    const/4 v8, 0x1

    .line 18
    if-eq v2, v8, :cond_0

    .line 19
    .line 20
    const/4 v9, 0x6

    .line 21
    if-ne v2, v9, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 24
    .line 25
    .line 26
    move-result v6

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    if-eq v5, v4, :cond_1

    .line 29
    .line 30
    if-eq v5, v3, :cond_1

    .line 31
    .line 32
    move v6, v7

    .line 33
    :cond_1
    :goto_0
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-ltz v6, :cond_2

    .line 38
    .line 39
    move v9, v8

    .line 40
    goto :goto_1

    .line 41
    :cond_2
    move v9, v7

    .line 42
    :goto_1
    sub-int/2addr v2, v9

    .line 43
    if-nez v2, :cond_3

    .line 44
    .line 45
    return-void

    .line 46
    :cond_3
    if-eq v5, v4, :cond_4

    .line 47
    .line 48
    const/4 v4, 0x7

    .line 49
    if-eq v5, v4, :cond_4

    .line 50
    .line 51
    if-eq v5, v3, :cond_4

    .line 52
    .line 53
    move v3, v7

    .line 54
    goto :goto_2

    .line 55
    :cond_4
    move v3, v8

    .line 56
    :goto_2
    const/16 v4, 0x22

    .line 57
    .line 58
    if-eqz v3, :cond_5

    .line 59
    .line 60
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 61
    .line 62
    if-lt v9, v4, :cond_5

    .line 63
    .line 64
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getClassification()I

    .line 65
    .line 66
    .line 67
    move-result v9

    .line 68
    const/4 v10, 0x3

    .line 69
    if-ne v9, v10, :cond_5

    .line 70
    .line 71
    move v10, v7

    .line 72
    move v9, v8

    .line 73
    goto :goto_3

    .line 74
    :cond_5
    move v9, v7

    .line 75
    move v10, v9

    .line 76
    :goto_3
    new-array v7, v2, [Landroid/view/MotionEvent$PointerProperties;

    .line 77
    .line 78
    move v11, v10

    .line 79
    :goto_4
    if-ge v11, v2, :cond_6

    .line 80
    .line 81
    new-instance v12, Landroid/view/MotionEvent$PointerProperties;

    .line 82
    .line 83
    invoke-direct {v12}, Landroid/view/MotionEvent$PointerProperties;-><init>()V

    .line 84
    .line 85
    .line 86
    aput-object v12, v7, v11

    .line 87
    .line 88
    add-int/lit8 v11, v11, 0x1

    .line 89
    .line 90
    goto :goto_4

    .line 91
    :cond_6
    move v11, v8

    .line 92
    new-array v8, v2, [Landroid/view/MotionEvent$PointerCoords;

    .line 93
    .line 94
    move v12, v10

    .line 95
    :goto_5
    if-ge v12, v2, :cond_7

    .line 96
    .line 97
    new-instance v13, Landroid/view/MotionEvent$PointerCoords;

    .line 98
    .line 99
    invoke-direct {v13}, Landroid/view/MotionEvent$PointerCoords;-><init>()V

    .line 100
    .line 101
    .line 102
    aput-object v13, v8, v12

    .line 103
    .line 104
    add-int/lit8 v12, v12, 0x1

    .line 105
    .line 106
    goto :goto_5

    .line 107
    :cond_7
    move v12, v10

    .line 108
    :goto_6
    if-ge v12, v2, :cond_a

    .line 109
    .line 110
    if-ltz v6, :cond_8

    .line 111
    .line 112
    if-gt v6, v12, :cond_8

    .line 113
    .line 114
    move v13, v11

    .line 115
    goto :goto_7

    .line 116
    :cond_8
    move v13, v10

    .line 117
    :goto_7
    add-int/2addr v13, v12

    .line 118
    aget-object v14, v7, v12

    .line 119
    .line 120
    invoke-virtual {v1, v13, v14}, Landroid/view/MotionEvent;->getPointerProperties(ILandroid/view/MotionEvent$PointerProperties;)V

    .line 121
    .line 122
    .line 123
    aget-object v14, v8, v12

    .line 124
    .line 125
    invoke-virtual {v1, v13, v14}, Landroid/view/MotionEvent;->getPointerCoords(ILandroid/view/MotionEvent$PointerCoords;)V

    .line 126
    .line 127
    .line 128
    iget v13, v14, Landroid/view/MotionEvent$PointerCoords;->x:F

    .line 129
    .line 130
    iget v15, v14, Landroid/view/MotionEvent$PointerCoords;->y:F

    .line 131
    .line 132
    invoke-static {v13}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 133
    .line 134
    .line 135
    move-result v13

    .line 136
    int-to-long v10, v13

    .line 137
    invoke-static {v15}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 138
    .line 139
    .line 140
    move-result v13

    .line 141
    int-to-long v4, v13

    .line 142
    const/16 v13, 0x20

    .line 143
    .line 144
    shl-long/2addr v10, v13

    .line 145
    const-wide v18, 0xffffffffL

    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    and-long v4, v4, v18

    .line 151
    .line 152
    or-long/2addr v10, v4

    .line 153
    invoke-virtual {v0, v10, v11}, Lbb;->p(J)J

    .line 154
    .line 155
    .line 156
    move-result-wide v4

    .line 157
    shr-long v10, v4, v13

    .line 158
    .line 159
    long-to-int v10, v10

    .line 160
    invoke-static {v10}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 161
    .line 162
    .line 163
    move-result v10

    .line 164
    iput v10, v14, Landroid/view/MotionEvent$PointerCoords;->x:F

    .line 165
    .line 166
    and-long v4, v4, v18

    .line 167
    .line 168
    long-to-int v4, v4

    .line 169
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 170
    .line 171
    .line 172
    move-result v4

    .line 173
    iput v4, v14, Landroid/view/MotionEvent$PointerCoords;->y:F

    .line 174
    .line 175
    if-eqz v9, :cond_9

    .line 176
    .line 177
    const/16 v4, 0x32

    .line 178
    .line 179
    const/4 v5, 0x0

    .line 180
    invoke-virtual {v14, v4, v5}, Landroid/view/MotionEvent$PointerCoords;->setAxisValue(IF)V

    .line 181
    .line 182
    .line 183
    const/16 v4, 0x33

    .line 184
    .line 185
    invoke-virtual {v14, v4, v5}, Landroid/view/MotionEvent$PointerCoords;->setAxisValue(IF)V

    .line 186
    .line 187
    .line 188
    :cond_9
    add-int/lit8 v12, v12, 0x1

    .line 189
    .line 190
    const/4 v10, 0x0

    .line 191
    const/4 v11, 0x1

    .line 192
    goto :goto_6

    .line 193
    :cond_a
    if-eqz p5, :cond_b

    .line 194
    .line 195
    const/4 v10, 0x0

    .line 196
    goto :goto_8

    .line 197
    :cond_b
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getButtonState()I

    .line 198
    .line 199
    .line 200
    move-result v4

    .line 201
    move v10, v4

    .line 202
    :goto_8
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDownTime()J

    .line 203
    .line 204
    .line 205
    move-result-wide v4

    .line 206
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 207
    .line 208
    .line 209
    move-result-wide v11

    .line 210
    cmp-long v4, v4, v11

    .line 211
    .line 212
    if-nez v4, :cond_c

    .line 213
    .line 214
    move-wide/from16 v4, p3

    .line 215
    .line 216
    goto :goto_9

    .line 217
    :cond_c
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDownTime()J

    .line 218
    .line 219
    .line 220
    move-result-wide v4

    .line 221
    :goto_9
    if-eqz v3, :cond_d

    .line 222
    .line 223
    const/16 v16, 0x0

    .line 224
    .line 225
    goto :goto_a

    .line 226
    :cond_d
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getClassification()I

    .line 227
    .line 228
    .line 229
    move-result v3

    .line 230
    move/from16 v16, v3

    .line 231
    .line 232
    :goto_a
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 233
    .line 234
    const/16 v15, 0x22

    .line 235
    .line 236
    if-lt v3, v15, :cond_e

    .line 237
    .line 238
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getMetaState()I

    .line 239
    .line 240
    .line 241
    move-result v9

    .line 242
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getXPrecision()F

    .line 243
    .line 244
    .line 245
    move-result v11

    .line 246
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getYPrecision()F

    .line 247
    .line 248
    .line 249
    move-result v12

    .line 250
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDeviceId()I

    .line 251
    .line 252
    .line 253
    move-result v13

    .line 254
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEdgeFlags()I

    .line 255
    .line 256
    .line 257
    move-result v14

    .line 258
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getSource()I

    .line 259
    .line 260
    .line 261
    move-result v15

    .line 262
    move/from16 v17, v16

    .line 263
    .line 264
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getFlags()I

    .line 265
    .line 266
    .line 267
    move-result v16

    .line 268
    move v6, v2

    .line 269
    move-wide v1, v4

    .line 270
    move/from16 v5, p2

    .line 271
    .line 272
    move-wide/from16 v3, p3

    .line 273
    .line 274
    invoke-static/range {v1 .. v17}, Lwj;->a(JJII[Landroid/view/MotionEvent$PointerProperties;[Landroid/view/MotionEvent$PointerCoords;IIFFIIIII)Landroid/view/MotionEvent;

    .line 275
    .line 276
    .line 277
    move-result-object v1

    .line 278
    goto :goto_b

    .line 279
    :cond_e
    move v6, v2

    .line 280
    move-wide v1, v4

    .line 281
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getMetaState()I

    .line 282
    .line 283
    .line 284
    move-result v9

    .line 285
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getXPrecision()F

    .line 286
    .line 287
    .line 288
    move-result v11

    .line 289
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getYPrecision()F

    .line 290
    .line 291
    .line 292
    move-result v12

    .line 293
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getDeviceId()I

    .line 294
    .line 295
    .line 296
    move-result v13

    .line 297
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getEdgeFlags()I

    .line 298
    .line 299
    .line 300
    move-result v14

    .line 301
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getSource()I

    .line 302
    .line 303
    .line 304
    move-result v15

    .line 305
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getFlags()I

    .line 306
    .line 307
    .line 308
    move-result v16

    .line 309
    move/from16 v5, p2

    .line 310
    .line 311
    move-wide/from16 v3, p3

    .line 312
    .line 313
    invoke-static/range {v1 .. v16}, Landroid/view/MotionEvent;->obtain(JJII[Landroid/view/MotionEvent$PointerProperties;[Landroid/view/MotionEvent$PointerCoords;IIFFIIII)Landroid/view/MotionEvent;

    .line 314
    .line 315
    .line 316
    move-result-object v1

    .line 317
    :goto_b
    iget-object v2, v0, Lbb;->N:Lrb4;

    .line 318
    .line 319
    invoke-virtual {v2, v1, v0}, Lrb4;->c(Landroid/view/MotionEvent;Lbb;)Lzi7;

    .line 320
    .line 321
    .line 322
    move-result-object v2

    .line 323
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 324
    .line 325
    .line 326
    iget-object v3, v0, Lbb;->O:Lse;

    .line 327
    .line 328
    const/4 v11, 0x1

    .line 329
    invoke-virtual {v3, v2, v0, v11}, Lse;->d(Lzi7;Lbb;Z)I

    .line 330
    .line 331
    .line 332
    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    .line 333
    .line 334
    .line 335
    return-void
.end method

.method public final H(Lik6;Lyd1;)V
    .locals 7

    .line 1
    instance-of v0, p2, Lab;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lab;

    .line 7
    .line 8
    iget v1, v0, Lab;->m:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lab;->m:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lab;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lab;-><init>(Lbb;Lyd1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lab;->k:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lab;->m:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-eq v1, v2, :cond_1

    .line 33
    .line 34
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 35
    .line 36
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :cond_1
    invoke-static {p2}, Lyl3;->M(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_2
    invoke-static {p2}, Lyl3;->M(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    move p2, v2

    .line 48
    new-instance v2, Lna;

    .line 49
    .line 50
    const/4 v1, 0x0

    .line 51
    invoke-direct {v2, p0, v1}, Lna;-><init>(Lbb;B)V

    .line 52
    .line 53
    .line 54
    iput p2, v0, Lab;->m:I

    .line 55
    .line 56
    new-instance v1, Leh1;

    .line 57
    .line 58
    const/4 v5, 0x0

    .line 59
    const/16 v6, 0xa

    .line 60
    .line 61
    iget-object v3, p0, Lbb;->p0:Ljava/util/concurrent/atomic/AtomicReference;

    .line 62
    .line 63
    move-object v4, p1

    .line 64
    invoke-direct/range {v1 .. v6}, Leh1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 65
    .line 66
    .line 67
    invoke-static {v1, v0}, Luu;->Q(Lai2;Lxd1;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    sget-object p1, Lkj1;->h:Lkj1;

    .line 72
    .line 73
    if-ne p0, p1, :cond_3

    .line 74
    .line 75
    return-void

    .line 76
    :cond_3
    :goto_1
    invoke-static {}, Lxb1;->m()V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public final I(Landroid/content/res/Configuration;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lbb;->getConfiguration()Landroid/content/res/Configuration;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_2

    .line 10
    .line 11
    new-instance v1, Landroid/content/res/Configuration;

    .line 12
    .line 13
    invoke-direct {v1, p1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, v1}, Lbb;->setConfiguration(Landroid/content/res/Configuration;)V

    .line 17
    .line 18
    .line 19
    iget v1, v0, Landroid/content/res/Configuration;->fontScale:F

    .line 20
    .line 21
    iget v2, p1, Landroid/content/res/Configuration;->fontScale:F

    .line 22
    .line 23
    cmpg-float v1, v1, v2

    .line 24
    .line 25
    if-nez v1, :cond_0

    .line 26
    .line 27
    iget v1, v0, Landroid/content/res/Configuration;->densityDpi:I

    .line 28
    .line 29
    iget v2, p1, Landroid/content/res/Configuration;->densityDpi:I

    .line 30
    .line 31
    if-eq v1, v2, :cond_1

    .line 32
    .line 33
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-virtual {v1, p1}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-static {v1}, Lnb3;->d(Landroid/content/Context;)Lop1;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-direct {p0, v1}, Lbb;->setDensity(Lkp1;)V

    .line 46
    .line 47
    .line 48
    :cond_1
    invoke-virtual {p1}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    invoke-static {p1}, Lgu3;->d(Landroid/os/LocaleList;)Lgu3;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-virtual {v0}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-static {v0}, Lgu3;->d(Landroid/os/LocaleList;)Lgu3;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-virtual {v0, p1}, Lgu3;->equals(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_2

    .line 69
    .line 70
    invoke-static {p1}, Lbb;->h(Lgu3;)Lfu3;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-direct {p0, p1}, Lbb;->setLocaleList(Lfu3;)V

    .line 75
    .line 76
    .line 77
    :cond_2
    return-void
.end method

.method public final J()V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lbb;->e0:[I

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 6
    .line 7
    .line 8
    iget-wide v2, v0, Lbb;->d0:J

    .line 9
    .line 10
    const/16 v4, 0x20

    .line 11
    .line 12
    shr-long v5, v2, v4

    .line 13
    .line 14
    long-to-int v5, v5

    .line 15
    const-wide v6, 0xffffffffL

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    and-long/2addr v2, v6

    .line 21
    long-to-int v2, v2

    .line 22
    const/4 v3, 0x0

    .line 23
    aget v8, v1, v3

    .line 24
    .line 25
    const/4 v9, 0x1

    .line 26
    if-ne v5, v8, :cond_0

    .line 27
    .line 28
    aget v10, v1, v9

    .line 29
    .line 30
    if-ne v2, v10, :cond_0

    .line 31
    .line 32
    iget-wide v10, v0, Lbb;->j0:J

    .line 33
    .line 34
    const-wide/16 v12, 0x0

    .line 35
    .line 36
    cmp-long v10, v10, v12

    .line 37
    .line 38
    if-gez v10, :cond_2

    .line 39
    .line 40
    :cond_0
    aget v1, v1, v9

    .line 41
    .line 42
    int-to-long v10, v8

    .line 43
    shl-long/2addr v10, v4

    .line 44
    int-to-long v12, v1

    .line 45
    and-long/2addr v12, v6

    .line 46
    or-long/2addr v10, v12

    .line 47
    iput-wide v10, v0, Lbb;->d0:J

    .line 48
    .line 49
    const v1, 0x7fffffff

    .line 50
    .line 51
    .line 52
    if-eq v5, v1, :cond_2

    .line 53
    .line 54
    if-eq v2, v1, :cond_2

    .line 55
    .line 56
    invoke-virtual {v0}, Lbb;->getRoot()Lzi3;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    invoke-virtual {v1}, Lzi3;->z()Lve4;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    iget-object v2, v1, Lve4;->h:[Ljava/lang/Object;

    .line 65
    .line 66
    iget v1, v1, Lve4;->j:I

    .line 67
    .line 68
    move v4, v3

    .line 69
    :goto_0
    if-ge v4, v1, :cond_1

    .line 70
    .line 71
    aget-object v5, v2, v4

    .line 72
    .line 73
    check-cast v5, Lzi3;

    .line 74
    .line 75
    iget-object v5, v5, Lzi3;->N:Ldj3;

    .line 76
    .line 77
    iget-object v5, v5, Ldj3;->p:Lt14;

    .line 78
    .line 79
    invoke-virtual {v5}, Lt14;->W0()V

    .line 80
    .line 81
    .line 82
    add-int/lit8 v4, v4, 0x1

    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_1
    move v1, v9

    .line 86
    goto :goto_1

    .line 87
    :cond_2
    move v1, v3

    .line 88
    :goto_1
    invoke-virtual {v0}, Lbb;->z()V

    .line 89
    .line 90
    .line 91
    iget-object v2, v0, Lbb;->P0:Landroid/view/View;

    .line 92
    .line 93
    if-nez v2, :cond_3

    .line 94
    .line 95
    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    iput-object v2, v0, Lbb;->P0:Landroid/view/View;

    .line 100
    .line 101
    :cond_3
    invoke-virtual {v0}, Lbb;->getRectManager()Lzv5;

    .line 102
    .line 103
    .line 104
    move-result-object v4

    .line 105
    iget-wide v11, v0, Lbb;->d0:J

    .line 106
    .line 107
    iget-wide v5, v0, Lbb;->l0:J

    .line 108
    .line 109
    invoke-static {v5, v6}, Lrx;->M(J)J

    .line 110
    .line 111
    .line 112
    move-result-wide v13

    .line 113
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 114
    .line 115
    .line 116
    move-result v16

    .line 117
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 118
    .line 119
    .line 120
    move-result v17

    .line 121
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 122
    .line 123
    .line 124
    iget-object v2, v0, Lbb;->h0:[F

    .line 125
    .line 126
    array-length v5, v2

    .line 127
    const/16 v6, 0x10

    .line 128
    .line 129
    const/4 v7, 0x2

    .line 130
    if-ge v5, v6, :cond_4

    .line 131
    .line 132
    move v5, v3

    .line 133
    goto/16 :goto_f

    .line 134
    .line 135
    :cond_4
    aget v5, v2, v3

    .line 136
    .line 137
    const/high16 v6, 0x3f800000    # 1.0f

    .line 138
    .line 139
    cmpg-float v5, v5, v6

    .line 140
    .line 141
    if-nez v5, :cond_5

    .line 142
    .line 143
    move v5, v9

    .line 144
    goto :goto_2

    .line 145
    :cond_5
    move v5, v3

    .line 146
    :goto_2
    aget v8, v2, v9

    .line 147
    .line 148
    const/4 v10, 0x0

    .line 149
    cmpg-float v8, v8, v10

    .line 150
    .line 151
    if-nez v8, :cond_6

    .line 152
    .line 153
    move v8, v9

    .line 154
    goto :goto_3

    .line 155
    :cond_6
    move v8, v3

    .line 156
    :goto_3
    and-int/2addr v5, v8

    .line 157
    aget v8, v2, v7

    .line 158
    .line 159
    cmpg-float v8, v8, v10

    .line 160
    .line 161
    if-nez v8, :cond_7

    .line 162
    .line 163
    move v8, v9

    .line 164
    goto :goto_4

    .line 165
    :cond_7
    move v8, v3

    .line 166
    :goto_4
    and-int/2addr v5, v8

    .line 167
    const/4 v8, 0x4

    .line 168
    aget v8, v2, v8

    .line 169
    .line 170
    cmpg-float v8, v8, v10

    .line 171
    .line 172
    if-nez v8, :cond_8

    .line 173
    .line 174
    move v8, v9

    .line 175
    goto :goto_5

    .line 176
    :cond_8
    move v8, v3

    .line 177
    :goto_5
    and-int/2addr v5, v8

    .line 178
    const/4 v8, 0x5

    .line 179
    aget v8, v2, v8

    .line 180
    .line 181
    cmpg-float v8, v8, v6

    .line 182
    .line 183
    if-nez v8, :cond_9

    .line 184
    .line 185
    move v8, v9

    .line 186
    goto :goto_6

    .line 187
    :cond_9
    move v8, v3

    .line 188
    :goto_6
    and-int/2addr v5, v8

    .line 189
    const/4 v8, 0x6

    .line 190
    aget v8, v2, v8

    .line 191
    .line 192
    cmpg-float v8, v8, v10

    .line 193
    .line 194
    if-nez v8, :cond_a

    .line 195
    .line 196
    move v8, v9

    .line 197
    goto :goto_7

    .line 198
    :cond_a
    move v8, v3

    .line 199
    :goto_7
    and-int/2addr v5, v8

    .line 200
    const/16 v8, 0x8

    .line 201
    .line 202
    aget v8, v2, v8

    .line 203
    .line 204
    cmpg-float v8, v8, v10

    .line 205
    .line 206
    if-nez v8, :cond_b

    .line 207
    .line 208
    move v8, v9

    .line 209
    goto :goto_8

    .line 210
    :cond_b
    move v8, v3

    .line 211
    :goto_8
    and-int/2addr v5, v8

    .line 212
    const/16 v8, 0x9

    .line 213
    .line 214
    aget v8, v2, v8

    .line 215
    .line 216
    cmpg-float v8, v8, v10

    .line 217
    .line 218
    if-nez v8, :cond_c

    .line 219
    .line 220
    move v8, v9

    .line 221
    goto :goto_9

    .line 222
    :cond_c
    move v8, v3

    .line 223
    :goto_9
    and-int/2addr v5, v8

    .line 224
    const/16 v8, 0xa

    .line 225
    .line 226
    aget v8, v2, v8

    .line 227
    .line 228
    cmpg-float v8, v8, v6

    .line 229
    .line 230
    if-nez v8, :cond_d

    .line 231
    .line 232
    move v8, v9

    .line 233
    goto :goto_a

    .line 234
    :cond_d
    move v8, v3

    .line 235
    :goto_a
    and-int/2addr v5, v8

    .line 236
    const/16 v8, 0xc

    .line 237
    .line 238
    aget v8, v2, v8

    .line 239
    .line 240
    cmpg-float v8, v8, v10

    .line 241
    .line 242
    if-nez v8, :cond_e

    .line 243
    .line 244
    move v8, v9

    .line 245
    goto :goto_b

    .line 246
    :cond_e
    move v8, v3

    .line 247
    :goto_b
    const/16 v15, 0xd

    .line 248
    .line 249
    aget v15, v2, v15

    .line 250
    .line 251
    cmpg-float v15, v15, v10

    .line 252
    .line 253
    if-nez v15, :cond_f

    .line 254
    .line 255
    move v15, v9

    .line 256
    goto :goto_c

    .line 257
    :cond_f
    move v15, v3

    .line 258
    :goto_c
    and-int/2addr v8, v15

    .line 259
    const/16 v15, 0xe

    .line 260
    .line 261
    aget v15, v2, v15

    .line 262
    .line 263
    cmpg-float v10, v15, v10

    .line 264
    .line 265
    if-nez v10, :cond_10

    .line 266
    .line 267
    move v10, v9

    .line 268
    goto :goto_d

    .line 269
    :cond_10
    move v10, v3

    .line 270
    :goto_d
    and-int/2addr v8, v10

    .line 271
    const/16 v10, 0xf

    .line 272
    .line 273
    aget v10, v2, v10

    .line 274
    .line 275
    cmpg-float v6, v10, v6

    .line 276
    .line 277
    if-nez v6, :cond_11

    .line 278
    .line 279
    move v6, v9

    .line 280
    goto :goto_e

    .line 281
    :cond_11
    move v6, v3

    .line 282
    :goto_e
    and-int/2addr v8, v6

    .line 283
    shl-int/2addr v5, v9

    .line 284
    or-int/2addr v5, v8

    .line 285
    :goto_f
    iget-object v10, v4, Lzv5;->d:Ldk7;

    .line 286
    .line 287
    and-int/2addr v5, v7

    .line 288
    if-nez v5, :cond_12

    .line 289
    .line 290
    :goto_10
    move-object v15, v2

    .line 291
    goto :goto_11

    .line 292
    :cond_12
    const/4 v2, 0x0

    .line 293
    goto :goto_10

    .line 294
    :goto_11
    invoke-virtual/range {v10 .. v17}, Ldk7;->b(JJ[FII)Z

    .line 295
    .line 296
    .line 297
    move-result v2

    .line 298
    if-nez v2, :cond_13

    .line 299
    .line 300
    iget-boolean v2, v4, Lzv5;->g:Z

    .line 301
    .line 302
    if-eqz v2, :cond_14

    .line 303
    .line 304
    :cond_13
    move v3, v9

    .line 305
    :cond_14
    iput-boolean v3, v4, Lzv5;->g:Z

    .line 306
    .line 307
    iget-object v2, v0, Lbb;->c0:Lk92;

    .line 308
    .line 309
    invoke-virtual {v2, v1}, Lk92;->b(Z)V

    .line 310
    .line 311
    .line 312
    invoke-virtual {v0}, Lbb;->getRectManager()Lzv5;

    .line 313
    .line 314
    .line 315
    move-result-object v0

    .line 316
    invoke-virtual {v0}, Lzv5;->a()V

    .line 317
    .line 318
    .line 319
    return-void
.end method

.method public final K(F)V
    .locals 2

    .line 1
    invoke-static {}, Lbb;->l()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_3

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    cmpl-float v1, p1, v0

    .line 9
    .line 10
    if-lez v1, :cond_1

    .line 11
    .line 12
    iget v0, p0, Lbb;->A0:F

    .line 13
    .line 14
    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    iget v0, p0, Lbb;->A0:F

    .line 21
    .line 22
    cmpl-float v0, p1, v0

    .line 23
    .line 24
    if-lez v0, :cond_3

    .line 25
    .line 26
    :cond_0
    iput p1, p0, Lbb;->A0:F

    .line 27
    .line 28
    return-void

    .line 29
    :cond_1
    cmpg-float v0, p1, v0

    .line 30
    .line 31
    if-gez v0, :cond_3

    .line 32
    .line 33
    iget v0, p0, Lbb;->B0:F

    .line 34
    .line 35
    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-nez v0, :cond_2

    .line 40
    .line 41
    iget v0, p0, Lbb;->B0:F

    .line 42
    .line 43
    cmpg-float v0, p1, v0

    .line 44
    .line 45
    if-gez v0, :cond_3

    .line 46
    .line 47
    :cond_2
    iput p1, p0, Lbb;->B0:F

    .line 48
    .line 49
    :cond_3
    return-void
.end method

.method public final a(Lye2;Lye2;)V
    .locals 12

    .line 1
    if-eqz p1, :cond_1f

    .line 2
    .line 3
    move-object p0, p1

    .line 4
    check-cast p0, Lab4;

    .line 5
    .line 6
    iget-object v0, p0, Lab4;->h:Lab4;

    .line 7
    .line 8
    iget-boolean v0, v0, Lab4;->u:Z

    .line 9
    .line 10
    const-string v1, "visitAncestors called on an unattached node"

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-static {v1}, Lp73;->b(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    iget-object p0, p0, Lab4;->h:Lab4;

    .line 18
    .line 19
    invoke-static {p1}, Lsx;->l0(Lap1;)Lzi3;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    const/4 v0, 0x0

    .line 24
    move-object v2, v0

    .line 25
    :goto_0
    const/16 v3, 0x10

    .line 26
    .line 27
    const/high16 v4, 0x200000

    .line 28
    .line 29
    const/4 v5, 0x0

    .line 30
    const/4 v6, 0x1

    .line 31
    if-eqz p1, :cond_d

    .line 32
    .line 33
    iget-object v7, p1, Lzi3;->M:Lu9;

    .line 34
    .line 35
    iget-object v7, v7, Lu9;->g:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v7, Lab4;

    .line 38
    .line 39
    iget v7, v7, Lab4;->k:I

    .line 40
    .line 41
    and-int/2addr v7, v4

    .line 42
    if-eqz v7, :cond_b

    .line 43
    .line 44
    :goto_1
    if-eqz p0, :cond_b

    .line 45
    .line 46
    iget v7, p0, Lab4;->j:I

    .line 47
    .line 48
    and-int/2addr v7, v4

    .line 49
    if-eqz v7, :cond_a

    .line 50
    .line 51
    move-object v7, p0

    .line 52
    move-object v8, v0

    .line 53
    :cond_1
    :goto_2
    if-eqz v7, :cond_a

    .line 54
    .line 55
    instance-of v9, v7, Ls63;

    .line 56
    .line 57
    if-eqz v9, :cond_3

    .line 58
    .line 59
    if-nez v2, :cond_2

    .line 60
    .line 61
    new-instance v2, Ljava/util/ArrayList;

    .line 62
    .line 63
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 64
    .line 65
    .line 66
    :cond_2
    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move v9, v5

    .line 70
    goto :goto_3

    .line 71
    :cond_3
    move v9, v6

    .line 72
    :goto_3
    if-eqz v9, :cond_9

    .line 73
    .line 74
    iget v9, v7, Lab4;->j:I

    .line 75
    .line 76
    and-int/2addr v9, v4

    .line 77
    if-eqz v9, :cond_9

    .line 78
    .line 79
    instance-of v9, v7, Lcp1;

    .line 80
    .line 81
    if-eqz v9, :cond_9

    .line 82
    .line 83
    move-object v9, v7

    .line 84
    check-cast v9, Lcp1;

    .line 85
    .line 86
    iget-object v9, v9, Lcp1;->w:Lab4;

    .line 87
    .line 88
    move v10, v5

    .line 89
    :goto_4
    if-eqz v9, :cond_8

    .line 90
    .line 91
    iget v11, v9, Lab4;->j:I

    .line 92
    .line 93
    and-int/2addr v11, v4

    .line 94
    if-eqz v11, :cond_7

    .line 95
    .line 96
    add-int/lit8 v10, v10, 0x1

    .line 97
    .line 98
    if-ne v10, v6, :cond_4

    .line 99
    .line 100
    move-object v7, v9

    .line 101
    goto :goto_5

    .line 102
    :cond_4
    if-nez v8, :cond_5

    .line 103
    .line 104
    new-instance v8, Lve4;

    .line 105
    .line 106
    new-array v11, v3, [Lab4;

    .line 107
    .line 108
    invoke-direct {v8, v5, v11}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    :cond_5
    if-eqz v7, :cond_6

    .line 112
    .line 113
    invoke-virtual {v8, v7}, Lve4;->b(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    move-object v7, v0

    .line 117
    :cond_6
    invoke-virtual {v8, v9}, Lve4;->b(Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    :cond_7
    :goto_5
    iget-object v9, v9, Lab4;->m:Lab4;

    .line 121
    .line 122
    goto :goto_4

    .line 123
    :cond_8
    if-eq v10, v6, :cond_1

    .line 124
    .line 125
    :cond_9
    invoke-static {v8}, Lsx;->a0(Lve4;)Lab4;

    .line 126
    .line 127
    .line 128
    move-result-object v7

    .line 129
    goto :goto_2

    .line 130
    :cond_a
    iget-object p0, p0, Lab4;->l:Lab4;

    .line 131
    .line 132
    goto :goto_1

    .line 133
    :cond_b
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    if-eqz p1, :cond_c

    .line 138
    .line 139
    iget-object p0, p1, Lzi3;->M:Lu9;

    .line 140
    .line 141
    if-eqz p0, :cond_c

    .line 142
    .line 143
    iget-object p0, p0, Lu9;->f:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast p0, Lz87;

    .line 146
    .line 147
    goto :goto_0

    .line 148
    :cond_c
    move-object p0, v0

    .line 149
    goto :goto_0

    .line 150
    :cond_d
    if-eqz v2, :cond_1f

    .line 151
    .line 152
    if-eqz p2, :cond_1c

    .line 153
    .line 154
    iget-object p0, p2, Lab4;->h:Lab4;

    .line 155
    .line 156
    iget-boolean p0, p0, Lab4;->u:Z

    .line 157
    .line 158
    if-nez p0, :cond_e

    .line 159
    .line 160
    invoke-static {v1}, Lp73;->b(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    :cond_e
    iget-object p0, p2, Lab4;->h:Lab4;

    .line 164
    .line 165
    invoke-static {p2}, Lsx;->l0(Lap1;)Lzi3;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    move-object p2, v0

    .line 170
    :goto_6
    if-eqz p1, :cond_1b

    .line 171
    .line 172
    iget-object v1, p1, Lzi3;->M:Lu9;

    .line 173
    .line 174
    iget-object v1, v1, Lu9;->g:Ljava/lang/Object;

    .line 175
    .line 176
    check-cast v1, Lab4;

    .line 177
    .line 178
    iget v1, v1, Lab4;->k:I

    .line 179
    .line 180
    and-int/2addr v1, v4

    .line 181
    if-eqz v1, :cond_19

    .line 182
    .line 183
    :goto_7
    if-eqz p0, :cond_19

    .line 184
    .line 185
    iget v1, p0, Lab4;->j:I

    .line 186
    .line 187
    and-int/2addr v1, v4

    .line 188
    if-eqz v1, :cond_18

    .line 189
    .line 190
    move-object v1, p0

    .line 191
    move-object v7, v0

    .line 192
    :cond_f
    :goto_8
    if-eqz v1, :cond_18

    .line 193
    .line 194
    instance-of v8, v1, Ls63;

    .line 195
    .line 196
    if-eqz v8, :cond_11

    .line 197
    .line 198
    if-nez p2, :cond_10

    .line 199
    .line 200
    sget-object p2, Lof6;->a:Loe4;

    .line 201
    .line 202
    new-instance p2, Loe4;

    .line 203
    .line 204
    invoke-direct {p2}, Loe4;-><init>()V

    .line 205
    .line 206
    .line 207
    :cond_10
    invoke-virtual {p2, v1}, Loe4;->a(Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move v8, v5

    .line 211
    goto :goto_9

    .line 212
    :cond_11
    move v8, v6

    .line 213
    :goto_9
    if-eqz v8, :cond_17

    .line 214
    .line 215
    iget v8, v1, Lab4;->j:I

    .line 216
    .line 217
    and-int/2addr v8, v4

    .line 218
    if-eqz v8, :cond_17

    .line 219
    .line 220
    instance-of v8, v1, Lcp1;

    .line 221
    .line 222
    if-eqz v8, :cond_17

    .line 223
    .line 224
    move-object v8, v1

    .line 225
    check-cast v8, Lcp1;

    .line 226
    .line 227
    iget-object v8, v8, Lcp1;->w:Lab4;

    .line 228
    .line 229
    move v9, v5

    .line 230
    :goto_a
    if-eqz v8, :cond_16

    .line 231
    .line 232
    iget v10, v8, Lab4;->j:I

    .line 233
    .line 234
    and-int/2addr v10, v4

    .line 235
    if-eqz v10, :cond_15

    .line 236
    .line 237
    add-int/lit8 v9, v9, 0x1

    .line 238
    .line 239
    if-ne v9, v6, :cond_12

    .line 240
    .line 241
    move-object v1, v8

    .line 242
    goto :goto_b

    .line 243
    :cond_12
    if-nez v7, :cond_13

    .line 244
    .line 245
    new-instance v7, Lve4;

    .line 246
    .line 247
    new-array v10, v3, [Lab4;

    .line 248
    .line 249
    invoke-direct {v7, v5, v10}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    :cond_13
    if-eqz v1, :cond_14

    .line 253
    .line 254
    invoke-virtual {v7, v1}, Lve4;->b(Ljava/lang/Object;)V

    .line 255
    .line 256
    .line 257
    move-object v1, v0

    .line 258
    :cond_14
    invoke-virtual {v7, v8}, Lve4;->b(Ljava/lang/Object;)V

    .line 259
    .line 260
    .line 261
    :cond_15
    :goto_b
    iget-object v8, v8, Lab4;->m:Lab4;

    .line 262
    .line 263
    goto :goto_a

    .line 264
    :cond_16
    if-eq v9, v6, :cond_f

    .line 265
    .line 266
    :cond_17
    invoke-static {v7}, Lsx;->a0(Lve4;)Lab4;

    .line 267
    .line 268
    .line 269
    move-result-object v1

    .line 270
    goto :goto_8

    .line 271
    :cond_18
    iget-object p0, p0, Lab4;->l:Lab4;

    .line 272
    .line 273
    goto :goto_7

    .line 274
    :cond_19
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 275
    .line 276
    .line 277
    move-result-object p1

    .line 278
    if-eqz p1, :cond_1a

    .line 279
    .line 280
    iget-object p0, p1, Lzi3;->M:Lu9;

    .line 281
    .line 282
    if-eqz p0, :cond_1a

    .line 283
    .line 284
    iget-object p0, p0, Lu9;->f:Ljava/lang/Object;

    .line 285
    .line 286
    check-cast p0, Lz87;

    .line 287
    .line 288
    goto :goto_6

    .line 289
    :cond_1a
    move-object p0, v0

    .line 290
    goto :goto_6

    .line 291
    :cond_1b
    move-object v0, p2

    .line 292
    :cond_1c
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 293
    .line 294
    .line 295
    move-result p0

    .line 296
    move p1, v5

    .line 297
    :goto_c
    if-ge p1, p0, :cond_1f

    .line 298
    .line 299
    invoke-interface {v2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object p2

    .line 303
    check-cast p2, Ls63;

    .line 304
    .line 305
    if-eqz v0, :cond_1d

    .line 306
    .line 307
    invoke-virtual {v0, p2}, Loe4;->d(Ljava/lang/Object;)Z

    .line 308
    .line 309
    .line 310
    move-result v1

    .line 311
    goto :goto_d

    .line 312
    :cond_1d
    move v1, v5

    .line 313
    :goto_d
    if-nez v1, :cond_1e

    .line 314
    .line 315
    invoke-interface {p2}, Ls63;->S()V

    .line 316
    .line 317
    .line 318
    :cond_1e
    add-int/lit8 p1, p1, 0x1

    .line 319
    .line 320
    goto :goto_c

    .line 321
    :cond_1f
    return-void
.end method

.method public final addFocusables(Ljava/util/ArrayList;II)V
    .locals 13

    .line 1
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lje2;

    .line 6
    .line 7
    iget-object v0, v0, Lje2;->d:Lye2;

    .line 8
    .line 9
    iget-boolean v1, v0, Lab4;->u:Z

    .line 10
    .line 11
    if-eqz v1, :cond_19

    .line 12
    .line 13
    iget-object v1, v0, Lab4;->h:Lab4;

    .line 14
    .line 15
    iget-boolean v1, v1, Lab4;->u:Z

    .line 16
    .line 17
    const-string v2, "visitSubtreeIf called on an unattached node"

    .line 18
    .line 19
    if-nez v1, :cond_0

    .line 20
    .line 21
    invoke-static {v2}, Lp73;->b(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    new-instance v1, Lve4;

    .line 25
    .line 26
    const/16 v3, 0x10

    .line 27
    .line 28
    new-array v4, v3, [Lab4;

    .line 29
    .line 30
    const/4 v5, 0x0

    .line 31
    invoke-direct {v1, v5, v4}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iget-object v0, v0, Lab4;->h:Lab4;

    .line 35
    .line 36
    iget-object v4, v0, Lab4;->m:Lab4;

    .line 37
    .line 38
    if-nez v4, :cond_1

    .line 39
    .line 40
    invoke-static {v1, v0}, Lsx;->q(Lve4;Lab4;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-virtual {v1, v4}, Lve4;->b(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :goto_0
    iget v0, v1, Lve4;->j:I

    .line 48
    .line 49
    if-eqz v0, :cond_19

    .line 50
    .line 51
    add-int/lit8 v0, v0, -0x1

    .line 52
    .line 53
    invoke-virtual {v1, v0}, Lve4;->k(I)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    check-cast v0, Lab4;

    .line 58
    .line 59
    iget v4, v0, Lab4;->k:I

    .line 60
    .line 61
    and-int/lit16 v4, v4, 0x400

    .line 62
    .line 63
    if-eqz v4, :cond_18

    .line 64
    .line 65
    move-object v4, v0

    .line 66
    :goto_1
    if-eqz v4, :cond_18

    .line 67
    .line 68
    iget-boolean v6, v4, Lab4;->u:Z

    .line 69
    .line 70
    if-eqz v6, :cond_18

    .line 71
    .line 72
    iget v6, v4, Lab4;->j:I

    .line 73
    .line 74
    and-int/lit16 v6, v6, 0x400

    .line 75
    .line 76
    if-eqz v6, :cond_17

    .line 77
    .line 78
    const/4 v6, 0x0

    .line 79
    move-object v7, v4

    .line 80
    move-object v8, v6

    .line 81
    :cond_2
    :goto_2
    if-eqz v7, :cond_17

    .line 82
    .line 83
    instance-of v9, v7, Lye2;

    .line 84
    .line 85
    const/4 v10, 0x1

    .line 86
    if-eqz v9, :cond_10

    .line 87
    .line 88
    check-cast v7, Lye2;

    .line 89
    .line 90
    iget-boolean v9, v7, Lab4;->u:Z

    .line 91
    .line 92
    if-eqz v9, :cond_16

    .line 93
    .line 94
    invoke-virtual {v7}, Lye2;->I1()Lme2;

    .line 95
    .line 96
    .line 97
    move-result-object v7

    .line 98
    iget-boolean v7, v7, Lme2;->a:Z

    .line 99
    .line 100
    if-eqz v7, :cond_16

    .line 101
    .line 102
    invoke-super/range {p0 .. p3}, Landroid/view/ViewGroup;->addFocusables(Ljava/util/ArrayList;II)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Lje2;

    .line 110
    .line 111
    iget-object v0, v0, Lje2;->d:Lye2;

    .line 112
    .line 113
    iget-boolean v1, v0, Lab4;->u:Z

    .line 114
    .line 115
    if-eqz v1, :cond_f

    .line 116
    .line 117
    iget-object v1, v0, Lab4;->h:Lab4;

    .line 118
    .line 119
    iget-boolean v1, v1, Lab4;->u:Z

    .line 120
    .line 121
    if-nez v1, :cond_3

    .line 122
    .line 123
    invoke-static {v2}, Lp73;->b(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    :cond_3
    new-instance v1, Lve4;

    .line 127
    .line 128
    new-array v2, v3, [Lab4;

    .line 129
    .line 130
    invoke-direct {v1, v5, v2}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    iget-object v0, v0, Lab4;->h:Lab4;

    .line 134
    .line 135
    iget-object v2, v0, Lab4;->m:Lab4;

    .line 136
    .line 137
    if-nez v2, :cond_4

    .line 138
    .line 139
    invoke-static {v1, v0}, Lsx;->q(Lve4;Lab4;)V

    .line 140
    .line 141
    .line 142
    goto :goto_3

    .line 143
    :cond_4
    invoke-virtual {v1, v2}, Lve4;->b(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    :goto_3
    iget v0, v1, Lve4;->j:I

    .line 147
    .line 148
    if-eqz v0, :cond_f

    .line 149
    .line 150
    add-int/lit8 v0, v0, -0x1

    .line 151
    .line 152
    invoke-virtual {v1, v0}, Lve4;->k(I)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    check-cast v0, Lab4;

    .line 157
    .line 158
    iget v2, v0, Lab4;->k:I

    .line 159
    .line 160
    and-int/lit16 v2, v2, 0x400

    .line 161
    .line 162
    if-eqz v2, :cond_e

    .line 163
    .line 164
    move-object v2, v0

    .line 165
    :goto_4
    if-eqz v2, :cond_e

    .line 166
    .line 167
    iget-boolean v4, v2, Lab4;->u:Z

    .line 168
    .line 169
    if-eqz v4, :cond_e

    .line 170
    .line 171
    iget v4, v2, Lab4;->j:I

    .line 172
    .line 173
    and-int/lit16 v4, v4, 0x400

    .line 174
    .line 175
    if-eqz v4, :cond_d

    .line 176
    .line 177
    move-object v4, v2

    .line 178
    move-object v7, v6

    .line 179
    :cond_5
    :goto_5
    if-eqz v4, :cond_d

    .line 180
    .line 181
    instance-of v8, v4, Lye2;

    .line 182
    .line 183
    if-eqz v8, :cond_6

    .line 184
    .line 185
    check-cast v4, Lye2;

    .line 186
    .line 187
    iget-boolean v8, v4, Lab4;->u:Z

    .line 188
    .line 189
    if-eqz v8, :cond_c

    .line 190
    .line 191
    invoke-virtual {v4}, Lye2;->I1()Lme2;

    .line 192
    .line 193
    .line 194
    move-result-object v8

    .line 195
    iget-boolean v9, v4, Lab4;->u:Z

    .line 196
    .line 197
    if-eqz v9, :cond_c

    .line 198
    .line 199
    iget-boolean v4, v4, Lye2;->v:Z

    .line 200
    .line 201
    if-nez v4, :cond_c

    .line 202
    .line 203
    iget-boolean v4, v8, Lme2;->a:Z

    .line 204
    .line 205
    if-eqz v4, :cond_c

    .line 206
    .line 207
    goto/16 :goto_a

    .line 208
    .line 209
    :cond_6
    iget v8, v4, Lab4;->j:I

    .line 210
    .line 211
    and-int/lit16 v8, v8, 0x400

    .line 212
    .line 213
    if-eqz v8, :cond_c

    .line 214
    .line 215
    instance-of v8, v4, Lcp1;

    .line 216
    .line 217
    if-eqz v8, :cond_c

    .line 218
    .line 219
    move-object v8, v4

    .line 220
    check-cast v8, Lcp1;

    .line 221
    .line 222
    iget-object v8, v8, Lcp1;->w:Lab4;

    .line 223
    .line 224
    move v9, v5

    .line 225
    :goto_6
    if-eqz v8, :cond_b

    .line 226
    .line 227
    iget v11, v8, Lab4;->j:I

    .line 228
    .line 229
    and-int/lit16 v11, v11, 0x400

    .line 230
    .line 231
    if-eqz v11, :cond_a

    .line 232
    .line 233
    add-int/lit8 v9, v9, 0x1

    .line 234
    .line 235
    if-ne v9, v10, :cond_7

    .line 236
    .line 237
    move-object v4, v8

    .line 238
    goto :goto_7

    .line 239
    :cond_7
    if-nez v7, :cond_8

    .line 240
    .line 241
    new-instance v7, Lve4;

    .line 242
    .line 243
    new-array v11, v3, [Lab4;

    .line 244
    .line 245
    invoke-direct {v7, v5, v11}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    :cond_8
    if-eqz v4, :cond_9

    .line 249
    .line 250
    invoke-virtual {v7, v4}, Lve4;->b(Ljava/lang/Object;)V

    .line 251
    .line 252
    .line 253
    move-object v4, v6

    .line 254
    :cond_9
    invoke-virtual {v7, v8}, Lve4;->b(Ljava/lang/Object;)V

    .line 255
    .line 256
    .line 257
    :cond_a
    :goto_7
    iget-object v8, v8, Lab4;->m:Lab4;

    .line 258
    .line 259
    goto :goto_6

    .line 260
    :cond_b
    if-eq v9, v10, :cond_5

    .line 261
    .line 262
    :cond_c
    invoke-static {v7}, Lsx;->a0(Lve4;)Lab4;

    .line 263
    .line 264
    .line 265
    move-result-object v4

    .line 266
    goto :goto_5

    .line 267
    :cond_d
    iget-object v2, v2, Lab4;->m:Lab4;

    .line 268
    .line 269
    goto :goto_4

    .line 270
    :cond_e
    invoke-static {v1, v0}, Lsx;->q(Lve4;Lab4;)V

    .line 271
    .line 272
    .line 273
    goto :goto_3

    .line 274
    :cond_f
    if-eqz p1, :cond_19

    .line 275
    .line 276
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 277
    .line 278
    .line 279
    return-void

    .line 280
    :cond_10
    iget v9, v7, Lab4;->j:I

    .line 281
    .line 282
    and-int/lit16 v9, v9, 0x400

    .line 283
    .line 284
    if-eqz v9, :cond_16

    .line 285
    .line 286
    instance-of v9, v7, Lcp1;

    .line 287
    .line 288
    if-eqz v9, :cond_16

    .line 289
    .line 290
    move-object v9, v7

    .line 291
    check-cast v9, Lcp1;

    .line 292
    .line 293
    iget-object v9, v9, Lcp1;->w:Lab4;

    .line 294
    .line 295
    move v11, v5

    .line 296
    :goto_8
    if-eqz v9, :cond_15

    .line 297
    .line 298
    iget v12, v9, Lab4;->j:I

    .line 299
    .line 300
    and-int/lit16 v12, v12, 0x400

    .line 301
    .line 302
    if-eqz v12, :cond_14

    .line 303
    .line 304
    add-int/lit8 v11, v11, 0x1

    .line 305
    .line 306
    if-ne v11, v10, :cond_11

    .line 307
    .line 308
    move-object v7, v9

    .line 309
    goto :goto_9

    .line 310
    :cond_11
    if-nez v8, :cond_12

    .line 311
    .line 312
    new-instance v8, Lve4;

    .line 313
    .line 314
    new-array v12, v3, [Lab4;

    .line 315
    .line 316
    invoke-direct {v8, v5, v12}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 317
    .line 318
    .line 319
    :cond_12
    if-eqz v7, :cond_13

    .line 320
    .line 321
    invoke-virtual {v8, v7}, Lve4;->b(Ljava/lang/Object;)V

    .line 322
    .line 323
    .line 324
    move-object v7, v6

    .line 325
    :cond_13
    invoke-virtual {v8, v9}, Lve4;->b(Ljava/lang/Object;)V

    .line 326
    .line 327
    .line 328
    :cond_14
    :goto_9
    iget-object v9, v9, Lab4;->m:Lab4;

    .line 329
    .line 330
    goto :goto_8

    .line 331
    :cond_15
    if-eq v11, v10, :cond_2

    .line 332
    .line 333
    :cond_16
    invoke-static {v8}, Lsx;->a0(Lve4;)Lab4;

    .line 334
    .line 335
    .line 336
    move-result-object v7

    .line 337
    goto/16 :goto_2

    .line 338
    .line 339
    :cond_17
    iget-object v4, v4, Lab4;->m:Lab4;

    .line 340
    .line 341
    goto/16 :goto_1

    .line 342
    .line 343
    :cond_18
    invoke-static {v1, v0}, Lsx;->q(Lve4;Lab4;)V

    .line 344
    .line 345
    .line 346
    goto/16 :goto_0

    .line 347
    .line 348
    :cond_19
    :goto_a
    return-void
.end method

.method public final addView(Landroid/view/View;)V
    .locals 1

    const/4 v0, -0x1

    .line 19
    invoke-virtual {p0, p1, v0}, Lbb;->addView(Landroid/view/View;I)V

    return-void
.end method

.method public final addView(Landroid/view/View;I)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/view/ViewGroup;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    :cond_0
    const/4 v1, 0x1

    .line 15
    invoke-virtual {p0, p1, p2, v0, v1}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final addView(Landroid/view/View;II)V
    .locals 1

    .line 20
    invoke-virtual {p0}, Landroid/view/ViewGroup;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 21
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 22
    iput p3, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 p2, 0x1

    const/4 p3, -0x1

    .line 23
    invoke-virtual {p0, p1, p3, v0, p2}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    return-void
.end method

.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 1

    const/4 v0, 0x1

    .line 24
    invoke-virtual {p0, p1, p2, p3, v0}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    return-void
.end method

.method public final addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2

    const/4 v0, -0x1

    const/4 v1, 0x1

    .line 25
    invoke-virtual {p0, p1, v0, p2, v1}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    return-void
.end method

.method public final autofill(Landroid/util/SparseArray;)V
    .locals 10

    .line 1
    invoke-virtual {p0}, Lbb;->getAutofillManager()Lda;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_4

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    move v3, v1

    .line 13
    :goto_0
    if-ge v3, v2, :cond_4

    .line 14
    .line 15
    invoke-virtual {p1, v3}, Landroid/util/SparseArray;->keyAt(I)I

    .line 16
    .line 17
    .line 18
    move-result v4

    .line 19
    invoke-virtual {p1, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    check-cast v5, Landroid/view/autofill/AutofillValue;

    .line 24
    .line 25
    iget-object v6, v0, Lda;->i:Lgl6;

    .line 26
    .line 27
    iget-object v6, v6, Lgl6;->c:Lrd4;

    .line 28
    .line 29
    invoke-virtual {v6, v4}, Ln93;->b(I)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    check-cast v4, Lzi3;

    .line 34
    .line 35
    if-eqz v4, :cond_3

    .line 36
    .line 37
    invoke-virtual {v4}, Lzi3;->w()Lzk6;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    if-eqz v4, :cond_3

    .line 42
    .line 43
    iget-object v4, v4, Lzk6;->h:Lne4;

    .line 44
    .line 45
    sget-object v6, Lyk6;->g:Lkl6;

    .line 46
    .line 47
    invoke-virtual {v4, v6}, Lne4;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    const/4 v7, 0x0

    .line 52
    if-nez v6, :cond_0

    .line 53
    .line 54
    move-object v6, v7

    .line 55
    :cond_0
    check-cast v6, Lu4;

    .line 56
    .line 57
    if-eqz v6, :cond_1

    .line 58
    .line 59
    iget-object v6, v6, Lu4;->b:Lii2;

    .line 60
    .line 61
    check-cast v6, Lwh2;

    .line 62
    .line 63
    if-eqz v6, :cond_1

    .line 64
    .line 65
    new-instance v8, Lij;

    .line 66
    .line 67
    invoke-virtual {v5}, Landroid/view/autofill/AutofillValue;->getTextValue()Ljava/lang/CharSequence;

    .line 68
    .line 69
    .line 70
    move-result-object v9

    .line 71
    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v9

    .line 75
    invoke-direct {v8, v9}, Lij;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    invoke-interface {v6, v8}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v6

    .line 82
    check-cast v6, Ljava/lang/Boolean;

    .line 83
    .line 84
    :cond_1
    sget-object v6, Lyk6;->h:Lkl6;

    .line 85
    .line 86
    invoke-virtual {v4, v6}, Lne4;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v4

    .line 90
    if-eqz v4, :cond_2

    .line 91
    .line 92
    move-object v7, v4

    .line 93
    :cond_2
    check-cast v7, Lu4;

    .line 94
    .line 95
    if-eqz v7, :cond_3

    .line 96
    .line 97
    iget-object v4, v7, Lu4;->b:Lii2;

    .line 98
    .line 99
    check-cast v4, Lwh2;

    .line 100
    .line 101
    if-eqz v4, :cond_3

    .line 102
    .line 103
    new-instance v6, Lnc;

    .line 104
    .line 105
    invoke-direct {v6, v5}, Lnc;-><init>(Landroid/view/autofill/AutofillValue;)V

    .line 106
    .line 107
    .line 108
    invoke-interface {v4, v6}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    check-cast v4, Ljava/lang/Boolean;

    .line 113
    .line 114
    :cond_3
    add-int/lit8 v3, v3, 0x1

    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_4
    invoke-virtual {p0}, Lbb;->getAutofill()Lca;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    if-eqz p0, :cond_a

    .line 122
    .line 123
    iget-object p0, p0, Lca;->b:Lcz;

    .line 124
    .line 125
    iget-object v0, p0, Lcz;->a:Ljava/util/LinkedHashMap;

    .line 126
    .line 127
    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    if-nez v0, :cond_a

    .line 132
    .line 133
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    :goto_1
    if-ge v1, v0, :cond_a

    .line 138
    .line 139
    invoke-virtual {p1, v1}, Landroid/util/SparseArray;->keyAt(I)I

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    invoke-virtual {p1, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    check-cast v3, Landroid/view/autofill/AutofillValue;

    .line 148
    .line 149
    invoke-virtual {v3}, Landroid/view/autofill/AutofillValue;->isText()Z

    .line 150
    .line 151
    .line 152
    move-result v4

    .line 153
    if-eqz v4, :cond_5

    .line 154
    .line 155
    invoke-virtual {v3}, Landroid/view/autofill/AutofillValue;->getTextValue()Ljava/lang/CharSequence;

    .line 156
    .line 157
    .line 158
    move-result-object v3

    .line 159
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    iget-object v3, p0, Lcz;->a:Ljava/util/LinkedHashMap;

    .line 163
    .line 164
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    invoke-virtual {v3, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    if-eqz v2, :cond_6

    .line 173
    .line 174
    invoke-static {}, Lxb1;->r()V

    .line 175
    .line 176
    .line 177
    return-void

    .line 178
    :cond_5
    invoke-virtual {v3}, Landroid/view/autofill/AutofillValue;->isDate()Z

    .line 179
    .line 180
    .line 181
    move-result v2

    .line 182
    if-nez v2, :cond_9

    .line 183
    .line 184
    invoke-virtual {v3}, Landroid/view/autofill/AutofillValue;->isList()Z

    .line 185
    .line 186
    .line 187
    move-result v2

    .line 188
    if-nez v2, :cond_8

    .line 189
    .line 190
    invoke-virtual {v3}, Landroid/view/autofill/AutofillValue;->isToggle()Z

    .line 191
    .line 192
    .line 193
    move-result v2

    .line 194
    if-nez v2, :cond_7

    .line 195
    .line 196
    :cond_6
    add-int/lit8 v1, v1, 0x1

    .line 197
    .line 198
    goto :goto_1

    .line 199
    :cond_7
    new-instance p0, Lut4;

    .line 200
    .line 201
    const-string p1, "An operation is not implemented: b/138604541:  Add onFill() callback for toggle"

    .line 202
    .line 203
    invoke-direct {p0, p1}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    throw p0

    .line 207
    :cond_8
    new-instance p0, Lut4;

    .line 208
    .line 209
    const-string p1, "An operation is not implemented: b/138604541: Add onFill() callback for list"

    .line 210
    .line 211
    invoke-direct {p0, p1}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    throw p0

    .line 215
    :cond_9
    new-instance p0, Lut4;

    .line 216
    .line 217
    const-string p1, "An operation is not implemented: b/138604541: Add onFill() callback for date"

    .line 218
    .line 219
    invoke-direct {p0, p1}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    throw p0

    .line 223
    :cond_a
    return-void
.end method

.method public final b(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object p0, p0, Lbb;->F:Ljb;

    .line 2
    .line 3
    iget-object v0, p0, Ljb;->J:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {p3, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, -0x1

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object p0, p0, Ljb;->H:Lpd4;

    .line 13
    .line 14
    invoke-virtual {p0, p1, v1}, Lpd4;->d(II)I

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    if-eq p0, v1, :cond_1

    .line 19
    .line 20
    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {p1, p3, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    iget-object v0, p0, Ljb;->K:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {p3, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    iget-object p0, p0, Ljb;->I:Lpd4;

    .line 37
    .line 38
    invoke-virtual {p0, p1, v1}, Lpd4;->d(II)I

    .line 39
    .line 40
    .line 41
    move-result p0

    .line 42
    if-eq p0, v1, :cond_1

    .line 43
    .line 44
    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p1, p3, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 49
    .line 50
    .line 51
    :cond_1
    return-void
.end method

.method public final canScrollHorizontally(I)Z
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-wide v1, p0, Lbb;->i:J

    .line 3
    .line 4
    iget-object p0, p0, Lbb;->F:Ljb;

    .line 5
    .line 6
    invoke-virtual {p0, v0, p1, v1, v2}, Ljb;->i(ZIJ)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final canScrollVertically(I)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-wide v1, p0, Lbb;->i:J

    .line 3
    .line 4
    iget-object p0, p0, Lbb;->F:Ljb;

    .line 5
    .line 6
    invoke-virtual {p0, v0, p1, v1, v2}, Ljb;->i(ZIJ)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 6

    .line 1
    iget-object v0, p0, Lbb;->J:Lfe4;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-static {v1}, Lbb;->j(Lzi3;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    const/4 v1, 0x1

    .line 17
    invoke-virtual {p0, v1}, Lbb;->q(Z)V

    .line 18
    .line 19
    .line 20
    invoke-static {}, Law6;->h()Ltv6;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-virtual {v2}, Ltv6;->m()V

    .line 25
    .line 26
    .line 27
    iput-boolean v1, p0, Lbb;->L:Z

    .line 28
    .line 29
    const-string v1, "AndroidOwner:draw"

    .line 30
    .line 31
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    :try_start_0
    invoke-direct {p0}, Lbb;->getCanvasHolder()Lul0;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iget-object v2, v1, Lul0;->a:Lea;

    .line 39
    .line 40
    iget-object v3, v2, Lea;->a:Landroid/graphics/Canvas;

    .line 41
    .line 42
    iput-object p1, v2, Lea;->a:Landroid/graphics/Canvas;

    .line 43
    .line 44
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    const/4 v5, 0x0

    .line 49
    invoke-virtual {v4, v2, v5}, Lzi3;->i(Lpl0;Lsq2;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, v1, Lul0;->a:Lea;

    .line 53
    .line 54
    iput-object v3, v1, Lea;->a:Landroid/graphics/Canvas;

    .line 55
    .line 56
    invoke-virtual {v0}, Lfe4;->j()Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    const/4 v2, 0x0

    .line 61
    if-eqz v1, :cond_1

    .line 62
    .line 63
    iget v1, v0, Lfe4;->b:I

    .line 64
    .line 65
    move v3, v2

    .line 66
    :goto_0
    if-ge v3, v1, :cond_1

    .line 67
    .line 68
    invoke-virtual {v0, v3}, Lfe4;->g(I)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    check-cast v4, Lg45;

    .line 73
    .line 74
    check-cast v4, Luq2;

    .line 75
    .line 76
    invoke-virtual {v4}, Luq2;->g()V

    .line 77
    .line 78
    .line 79
    add-int/lit8 v3, v3, 0x1

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_1
    sget v1, Lux7;->h:I

    .line 83
    .line 84
    invoke-virtual {v0}, Lfe4;->d()V

    .line 85
    .line 86
    .line 87
    iput-boolean v2, p0, Lbb;->L:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 88
    .line 89
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 90
    .line 91
    .line 92
    iget-object v1, p0, Lbb;->K:Lfe4;

    .line 93
    .line 94
    if-eqz v1, :cond_2

    .line 95
    .line 96
    invoke-virtual {v0, v1}, Lfe4;->b(Lfe4;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v1}, Lfe4;->d()V

    .line 100
    .line 101
    .line 102
    :cond_2
    invoke-static {}, Lbb;->l()Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-eqz v0, :cond_6

    .line 107
    .line 108
    iget v0, p0, Lbb;->A0:F

    .line 109
    .line 110
    iget v1, p0, Lbb;->C0:F

    .line 111
    .line 112
    invoke-static {v0, v1}, Ljava/lang/Float;->compare(FF)I

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    if-eqz v0, :cond_3

    .line 117
    .line 118
    iget v0, p0, Lbb;->A0:F

    .line 119
    .line 120
    iput v0, p0, Lbb;->C0:F

    .line 121
    .line 122
    invoke-static {p0, v0}, Lzj;->a(Landroid/view/View;F)V

    .line 123
    .line 124
    .line 125
    :cond_3
    iget-object v0, p0, Lbb;->t:Landroid/view/View;

    .line 126
    .line 127
    if-eqz v0, :cond_5

    .line 128
    .line 129
    iget v1, p0, Lbb;->B0:F

    .line 130
    .line 131
    iget v2, p0, Lbb;->D0:F

    .line 132
    .line 133
    invoke-static {v1, v2}, Ljava/lang/Float;->compare(FF)I

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    if-eqz v1, :cond_4

    .line 138
    .line 139
    iget v1, p0, Lbb;->B0:F

    .line 140
    .line 141
    iput v1, p0, Lbb;->D0:F

    .line 142
    .line 143
    invoke-static {v0, v1}, Lzj;->a(Landroid/view/View;F)V

    .line 144
    .line 145
    .line 146
    :cond_4
    iget v1, p0, Lbb;->B0:F

    .line 147
    .line 148
    invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z

    .line 149
    .line 150
    .line 151
    move-result v1

    .line 152
    if-nez v1, :cond_5

    .line 153
    .line 154
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 155
    .line 156
    .line 157
    invoke-virtual {p0}, Landroid/view/View;->getDrawingTime()J

    .line 158
    .line 159
    .line 160
    move-result-wide v1

    .line 161
    invoke-virtual {p0, p1, v0, v1, v2}, Landroid/view/ViewGroup;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    .line 162
    .line 163
    .line 164
    :cond_5
    const/high16 p1, 0x7fc00000    # Float.NaN

    .line 165
    .line 166
    iput p1, p0, Lbb;->A0:F

    .line 167
    .line 168
    iput p1, p0, Lbb;->B0:F

    .line 169
    .line 170
    :cond_6
    return-void

    .line 171
    :catchall_0
    move-exception p0

    .line 172
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 173
    .line 174
    .line 175
    throw p0
.end method

.method public final dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .locals 39

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-boolean v2, v0, Lbb;->G0:Z

    .line 6
    .line 7
    const/16 v3, 0x8

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    if-eqz v2, :cond_1

    .line 11
    .line 12
    iget-object v2, v0, Lbb;->F0:Lpa;

    .line 13
    .line 14
    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 15
    .line 16
    .line 17
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 18
    .line 19
    .line 20
    move-result v5

    .line 21
    if-ne v5, v3, :cond_0

    .line 22
    .line 23
    iput-boolean v4, v0, Lbb;->G0:Z

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-virtual {v2}, Lpa;->run()V

    .line 27
    .line 28
    .line 29
    :cond_1
    :goto_0
    invoke-static {v1}, Lbb;->m(Landroid/view/MotionEvent;)Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-nez v2, :cond_8e

    .line 34
    .line 35
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_8e

    .line 40
    .line 41
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    const-string v5, "visitAncestors called on an unattached node"

    .line 46
    .line 47
    const/4 v6, -0x1

    .line 48
    const/16 v8, 0x10

    .line 49
    .line 50
    const/4 v9, 0x1

    .line 51
    if-ne v2, v3, :cond_33

    .line 52
    .line 53
    const/high16 v2, 0x400000

    .line 54
    .line 55
    invoke-virtual {v1, v2}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    if-eqz v2, :cond_30

    .line 60
    .line 61
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-static {v2}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    const/16 v3, 0x1a

    .line 70
    .line 71
    invoke-virtual {v1, v3}, Landroid/view/MotionEvent;->getAxisValue(I)F

    .line 72
    .line 73
    .line 74
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 75
    .line 76
    .line 77
    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledVerticalScrollFactor()F

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledHorizontalScrollFactor()F

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 87
    .line 88
    .line 89
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDeviceId()I

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0}, Lbb;->getFocusOwner()Lge2;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    check-cast v2, Lje2;

    .line 97
    .line 98
    iget-object v3, v2, Lje2;->e:Lee2;

    .line 99
    .line 100
    iget-boolean v3, v3, Lee2;->e:Z

    .line 101
    .line 102
    if-eqz v3, :cond_2

    .line 103
    .line 104
    const-string v0, "FocusRelatedWarning: Dispatching rotary event while the focus system is invalidated."

    .line 105
    .line 106
    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    .line 107
    .line 108
    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    return v4

    .line 112
    :cond_2
    iget-object v2, v2, Lje2;->d:Lye2;

    .line 113
    .line 114
    invoke-static {v2}, Lix;->L(Lye2;)Lye2;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    if-eqz v2, :cond_10

    .line 119
    .line 120
    iget-object v3, v2, Lab4;->h:Lab4;

    .line 121
    .line 122
    iget-boolean v3, v3, Lab4;->u:Z

    .line 123
    .line 124
    if-nez v3, :cond_3

    .line 125
    .line 126
    invoke-static {v5}, Lp73;->b(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    :cond_3
    iget-object v3, v2, Lab4;->h:Lab4;

    .line 130
    .line 131
    invoke-static {v2}, Lsx;->l0(Lap1;)Lzi3;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    :goto_1
    if-eqz v2, :cond_e

    .line 136
    .line 137
    iget-object v10, v2, Lzi3;->M:Lu9;

    .line 138
    .line 139
    iget-object v10, v10, Lu9;->g:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast v10, Lab4;

    .line 142
    .line 143
    iget v10, v10, Lab4;->k:I

    .line 144
    .line 145
    and-int/lit16 v10, v10, 0x4000

    .line 146
    .line 147
    if-eqz v10, :cond_c

    .line 148
    .line 149
    :goto_2
    if-eqz v3, :cond_c

    .line 150
    .line 151
    iget v10, v3, Lab4;->j:I

    .line 152
    .line 153
    and-int/lit16 v10, v10, 0x4000

    .line 154
    .line 155
    if-eqz v10, :cond_b

    .line 156
    .line 157
    move-object v10, v3

    .line 158
    const/4 v11, 0x0

    .line 159
    :cond_4
    :goto_3
    if-eqz v10, :cond_b

    .line 160
    .line 161
    instance-of v12, v10, Lta;

    .line 162
    .line 163
    if-nez v12, :cond_f

    .line 164
    .line 165
    iget v12, v10, Lab4;->j:I

    .line 166
    .line 167
    and-int/lit16 v12, v12, 0x4000

    .line 168
    .line 169
    if-eqz v12, :cond_a

    .line 170
    .line 171
    instance-of v12, v10, Lcp1;

    .line 172
    .line 173
    if-eqz v12, :cond_a

    .line 174
    .line 175
    move-object v12, v10

    .line 176
    check-cast v12, Lcp1;

    .line 177
    .line 178
    iget-object v12, v12, Lcp1;->w:Lab4;

    .line 179
    .line 180
    move v13, v4

    .line 181
    :goto_4
    if-eqz v12, :cond_9

    .line 182
    .line 183
    iget v14, v12, Lab4;->j:I

    .line 184
    .line 185
    and-int/lit16 v14, v14, 0x4000

    .line 186
    .line 187
    if-eqz v14, :cond_8

    .line 188
    .line 189
    add-int/lit8 v13, v13, 0x1

    .line 190
    .line 191
    if-ne v13, v9, :cond_5

    .line 192
    .line 193
    move-object v10, v12

    .line 194
    goto :goto_5

    .line 195
    :cond_5
    if-nez v11, :cond_6

    .line 196
    .line 197
    new-instance v11, Lve4;

    .line 198
    .line 199
    new-array v14, v8, [Lab4;

    .line 200
    .line 201
    invoke-direct {v11, v4, v14}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 202
    .line 203
    .line 204
    :cond_6
    if-eqz v10, :cond_7

    .line 205
    .line 206
    invoke-virtual {v11, v10}, Lve4;->b(Ljava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    const/4 v10, 0x0

    .line 210
    :cond_7
    invoke-virtual {v11, v12}, Lve4;->b(Ljava/lang/Object;)V

    .line 211
    .line 212
    .line 213
    :cond_8
    :goto_5
    iget-object v12, v12, Lab4;->m:Lab4;

    .line 214
    .line 215
    goto :goto_4

    .line 216
    :cond_9
    if-eq v13, v9, :cond_4

    .line 217
    .line 218
    :cond_a
    invoke-static {v11}, Lsx;->a0(Lve4;)Lab4;

    .line 219
    .line 220
    .line 221
    move-result-object v10

    .line 222
    goto :goto_3

    .line 223
    :cond_b
    iget-object v3, v3, Lab4;->l:Lab4;

    .line 224
    .line 225
    goto :goto_2

    .line 226
    :cond_c
    invoke-virtual {v2}, Lzi3;->u()Lzi3;

    .line 227
    .line 228
    .line 229
    move-result-object v2

    .line 230
    if-eqz v2, :cond_d

    .line 231
    .line 232
    iget-object v3, v2, Lzi3;->M:Lu9;

    .line 233
    .line 234
    if-eqz v3, :cond_d

    .line 235
    .line 236
    iget-object v3, v3, Lu9;->f:Ljava/lang/Object;

    .line 237
    .line 238
    check-cast v3, Lz87;

    .line 239
    .line 240
    goto :goto_1

    .line 241
    :cond_d
    const/4 v3, 0x0

    .line 242
    goto :goto_1

    .line 243
    :cond_e
    const/4 v10, 0x0

    .line 244
    :cond_f
    check-cast v10, Lta;

    .line 245
    .line 246
    goto :goto_6

    .line 247
    :cond_10
    const/4 v10, 0x0

    .line 248
    :goto_6
    if-eqz v10, :cond_32

    .line 249
    .line 250
    iget-object v2, v10, Lab4;->h:Lab4;

    .line 251
    .line 252
    iget-boolean v2, v2, Lab4;->u:Z

    .line 253
    .line 254
    if-nez v2, :cond_11

    .line 255
    .line 256
    invoke-static {v5}, Lp73;->b(Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    :cond_11
    iget-object v2, v10, Lab4;->h:Lab4;

    .line 260
    .line 261
    iget-object v2, v2, Lab4;->l:Lab4;

    .line 262
    .line 263
    invoke-static {v10}, Lsx;->l0(Lap1;)Lzi3;

    .line 264
    .line 265
    .line 266
    move-result-object v3

    .line 267
    const/4 v5, 0x0

    .line 268
    :goto_7
    if-eqz v3, :cond_1e

    .line 269
    .line 270
    iget-object v11, v3, Lzi3;->M:Lu9;

    .line 271
    .line 272
    iget-object v11, v11, Lu9;->g:Ljava/lang/Object;

    .line 273
    .line 274
    check-cast v11, Lab4;

    .line 275
    .line 276
    iget v11, v11, Lab4;->k:I

    .line 277
    .line 278
    and-int/lit16 v11, v11, 0x4000

    .line 279
    .line 280
    if-eqz v11, :cond_1c

    .line 281
    .line 282
    :goto_8
    if-eqz v2, :cond_1c

    .line 283
    .line 284
    iget v11, v2, Lab4;->j:I

    .line 285
    .line 286
    and-int/lit16 v11, v11, 0x4000

    .line 287
    .line 288
    if-eqz v11, :cond_1b

    .line 289
    .line 290
    move-object v11, v2

    .line 291
    const/4 v12, 0x0

    .line 292
    :cond_12
    :goto_9
    if-eqz v11, :cond_1b

    .line 293
    .line 294
    instance-of v13, v11, Lta;

    .line 295
    .line 296
    if-eqz v13, :cond_14

    .line 297
    .line 298
    if-nez v5, :cond_13

    .line 299
    .line 300
    new-instance v5, Ljava/util/ArrayList;

    .line 301
    .line 302
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 303
    .line 304
    .line 305
    :cond_13
    invoke-interface {v5, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 306
    .line 307
    .line 308
    move v13, v4

    .line 309
    goto :goto_a

    .line 310
    :cond_14
    move v13, v9

    .line 311
    :goto_a
    if-eqz v13, :cond_1a

    .line 312
    .line 313
    iget v13, v11, Lab4;->j:I

    .line 314
    .line 315
    and-int/lit16 v13, v13, 0x4000

    .line 316
    .line 317
    if-eqz v13, :cond_1a

    .line 318
    .line 319
    instance-of v13, v11, Lcp1;

    .line 320
    .line 321
    if-eqz v13, :cond_1a

    .line 322
    .line 323
    move-object v13, v11

    .line 324
    check-cast v13, Lcp1;

    .line 325
    .line 326
    iget-object v13, v13, Lcp1;->w:Lab4;

    .line 327
    .line 328
    move v14, v4

    .line 329
    :goto_b
    if-eqz v13, :cond_19

    .line 330
    .line 331
    iget v15, v13, Lab4;->j:I

    .line 332
    .line 333
    and-int/lit16 v15, v15, 0x4000

    .line 334
    .line 335
    if-eqz v15, :cond_18

    .line 336
    .line 337
    add-int/lit8 v14, v14, 0x1

    .line 338
    .line 339
    if-ne v14, v9, :cond_15

    .line 340
    .line 341
    move-object v11, v13

    .line 342
    goto :goto_c

    .line 343
    :cond_15
    if-nez v12, :cond_16

    .line 344
    .line 345
    new-instance v12, Lve4;

    .line 346
    .line 347
    new-array v15, v8, [Lab4;

    .line 348
    .line 349
    invoke-direct {v12, v4, v15}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 350
    .line 351
    .line 352
    :cond_16
    if-eqz v11, :cond_17

    .line 353
    .line 354
    invoke-virtual {v12, v11}, Lve4;->b(Ljava/lang/Object;)V

    .line 355
    .line 356
    .line 357
    const/4 v11, 0x0

    .line 358
    :cond_17
    invoke-virtual {v12, v13}, Lve4;->b(Ljava/lang/Object;)V

    .line 359
    .line 360
    .line 361
    :cond_18
    :goto_c
    iget-object v13, v13, Lab4;->m:Lab4;

    .line 362
    .line 363
    goto :goto_b

    .line 364
    :cond_19
    if-eq v14, v9, :cond_12

    .line 365
    .line 366
    :cond_1a
    invoke-static {v12}, Lsx;->a0(Lve4;)Lab4;

    .line 367
    .line 368
    .line 369
    move-result-object v11

    .line 370
    goto :goto_9

    .line 371
    :cond_1b
    iget-object v2, v2, Lab4;->l:Lab4;

    .line 372
    .line 373
    goto :goto_8

    .line 374
    :cond_1c
    invoke-virtual {v3}, Lzi3;->u()Lzi3;

    .line 375
    .line 376
    .line 377
    move-result-object v3

    .line 378
    if-eqz v3, :cond_1d

    .line 379
    .line 380
    iget-object v2, v3, Lzi3;->M:Lu9;

    .line 381
    .line 382
    if-eqz v2, :cond_1d

    .line 383
    .line 384
    iget-object v2, v2, Lu9;->f:Ljava/lang/Object;

    .line 385
    .line 386
    check-cast v2, Lz87;

    .line 387
    .line 388
    goto :goto_7

    .line 389
    :cond_1d
    const/4 v2, 0x0

    .line 390
    goto :goto_7

    .line 391
    :cond_1e
    if-eqz v5, :cond_1f

    .line 392
    .line 393
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    .line 394
    .line 395
    .line 396
    move-result v2

    .line 397
    add-int/2addr v2, v6

    .line 398
    if-ltz v2, :cond_1f

    .line 399
    .line 400
    :goto_d
    add-int/lit8 v3, v2, -0x1

    .line 401
    .line 402
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 403
    .line 404
    .line 405
    move-result-object v2

    .line 406
    check-cast v2, Lta;

    .line 407
    .line 408
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 409
    .line 410
    .line 411
    if-ltz v3, :cond_1f

    .line 412
    .line 413
    move v2, v3

    .line 414
    goto :goto_d

    .line 415
    :cond_1f
    iget-object v2, v10, Lab4;->h:Lab4;

    .line 416
    .line 417
    const/4 v3, 0x0

    .line 418
    :cond_20
    :goto_e
    if-eqz v2, :cond_27

    .line 419
    .line 420
    instance-of v6, v2, Lta;

    .line 421
    .line 422
    if-nez v6, :cond_26

    .line 423
    .line 424
    iget v6, v2, Lab4;->j:I

    .line 425
    .line 426
    and-int/lit16 v6, v6, 0x4000

    .line 427
    .line 428
    if-eqz v6, :cond_26

    .line 429
    .line 430
    instance-of v6, v2, Lcp1;

    .line 431
    .line 432
    if-eqz v6, :cond_26

    .line 433
    .line 434
    move-object v6, v2

    .line 435
    check-cast v6, Lcp1;

    .line 436
    .line 437
    iget-object v6, v6, Lcp1;->w:Lab4;

    .line 438
    .line 439
    move v11, v4

    .line 440
    :goto_f
    if-eqz v6, :cond_25

    .line 441
    .line 442
    iget v12, v6, Lab4;->j:I

    .line 443
    .line 444
    and-int/lit16 v12, v12, 0x4000

    .line 445
    .line 446
    if-eqz v12, :cond_24

    .line 447
    .line 448
    add-int/lit8 v11, v11, 0x1

    .line 449
    .line 450
    if-ne v11, v9, :cond_21

    .line 451
    .line 452
    move-object v2, v6

    .line 453
    goto :goto_10

    .line 454
    :cond_21
    if-nez v3, :cond_22

    .line 455
    .line 456
    new-instance v3, Lve4;

    .line 457
    .line 458
    new-array v12, v8, [Lab4;

    .line 459
    .line 460
    invoke-direct {v3, v4, v12}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 461
    .line 462
    .line 463
    :cond_22
    if-eqz v2, :cond_23

    .line 464
    .line 465
    invoke-virtual {v3, v2}, Lve4;->b(Ljava/lang/Object;)V

    .line 466
    .line 467
    .line 468
    const/4 v2, 0x0

    .line 469
    :cond_23
    invoke-virtual {v3, v6}, Lve4;->b(Ljava/lang/Object;)V

    .line 470
    .line 471
    .line 472
    :cond_24
    :goto_10
    iget-object v6, v6, Lab4;->m:Lab4;

    .line 473
    .line 474
    goto :goto_f

    .line 475
    :cond_25
    if-eq v11, v9, :cond_20

    .line 476
    .line 477
    :cond_26
    invoke-static {v3}, Lsx;->a0(Lve4;)Lab4;

    .line 478
    .line 479
    .line 480
    move-result-object v2

    .line 481
    goto :goto_e

    .line 482
    :cond_27
    invoke-super/range {p0 .. p1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 483
    .line 484
    .line 485
    move-result v0

    .line 486
    if-nez v0, :cond_31

    .line 487
    .line 488
    iget-object v0, v10, Lab4;->h:Lab4;

    .line 489
    .line 490
    const/4 v1, 0x0

    .line 491
    :cond_28
    :goto_11
    if-eqz v0, :cond_2f

    .line 492
    .line 493
    instance-of v2, v0, Lta;

    .line 494
    .line 495
    if-nez v2, :cond_2e

    .line 496
    .line 497
    iget v2, v0, Lab4;->j:I

    .line 498
    .line 499
    and-int/lit16 v2, v2, 0x4000

    .line 500
    .line 501
    if-eqz v2, :cond_2e

    .line 502
    .line 503
    instance-of v2, v0, Lcp1;

    .line 504
    .line 505
    if-eqz v2, :cond_2e

    .line 506
    .line 507
    move-object v2, v0

    .line 508
    check-cast v2, Lcp1;

    .line 509
    .line 510
    iget-object v2, v2, Lcp1;->w:Lab4;

    .line 511
    .line 512
    move v3, v4

    .line 513
    :goto_12
    if-eqz v2, :cond_2d

    .line 514
    .line 515
    iget v6, v2, Lab4;->j:I

    .line 516
    .line 517
    and-int/lit16 v6, v6, 0x4000

    .line 518
    .line 519
    if-eqz v6, :cond_2c

    .line 520
    .line 521
    add-int/lit8 v3, v3, 0x1

    .line 522
    .line 523
    if-ne v3, v9, :cond_29

    .line 524
    .line 525
    move-object v0, v2

    .line 526
    goto :goto_13

    .line 527
    :cond_29
    if-nez v1, :cond_2a

    .line 528
    .line 529
    new-instance v1, Lve4;

    .line 530
    .line 531
    new-array v6, v8, [Lab4;

    .line 532
    .line 533
    invoke-direct {v1, v4, v6}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 534
    .line 535
    .line 536
    :cond_2a
    if-eqz v0, :cond_2b

    .line 537
    .line 538
    invoke-virtual {v1, v0}, Lve4;->b(Ljava/lang/Object;)V

    .line 539
    .line 540
    .line 541
    const/4 v0, 0x0

    .line 542
    :cond_2b
    invoke-virtual {v1, v2}, Lve4;->b(Ljava/lang/Object;)V

    .line 543
    .line 544
    .line 545
    :cond_2c
    :goto_13
    iget-object v2, v2, Lab4;->m:Lab4;

    .line 546
    .line 547
    goto :goto_12

    .line 548
    :cond_2d
    if-eq v3, v9, :cond_28

    .line 549
    .line 550
    :cond_2e
    invoke-static {v1}, Lsx;->a0(Lve4;)Lab4;

    .line 551
    .line 552
    .line 553
    move-result-object v0

    .line 554
    goto :goto_11

    .line 555
    :cond_2f
    if-eqz v5, :cond_32

    .line 556
    .line 557
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    .line 558
    .line 559
    .line 560
    move-result v0

    .line 561
    move v1, v4

    .line 562
    :goto_14
    if-ge v1, v0, :cond_32

    .line 563
    .line 564
    invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 565
    .line 566
    .line 567
    move-result-object v2

    .line 568
    check-cast v2, Lta;

    .line 569
    .line 570
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 571
    .line 572
    .line 573
    add-int/lit8 v1, v1, 0x1

    .line 574
    .line 575
    goto :goto_14

    .line 576
    :cond_30
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getSource()I

    .line 577
    .line 578
    .line 579
    invoke-virtual/range {p0 .. p1}, Lbb;->i(Landroid/view/MotionEvent;)I

    .line 580
    .line 581
    .line 582
    move-result v0

    .line 583
    and-int/lit8 v0, v0, 0x4

    .line 584
    .line 585
    if-eqz v0, :cond_32

    .line 586
    .line 587
    :cond_31
    return v9

    .line 588
    :cond_32
    return v4

    .line 589
    :cond_33
    const/high16 v2, 0x200000

    .line 590
    .line 591
    invoke-virtual {v1, v2}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 592
    .line 593
    .line 594
    move-result v3

    .line 595
    if-eqz v3, :cond_8d

    .line 596
    .line 597
    iget-object v3, v0, Lbb;->k:Lj63;

    .line 598
    .line 599
    iget-object v10, v0, Lbb;->N:Lrb4;

    .line 600
    .line 601
    iget-object v11, v10, Lrb4;->e:Lxw3;

    .line 602
    .line 603
    iget-object v12, v10, Lrb4;->b:Landroid/util/SparseLongArray;

    .line 604
    .line 605
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 606
    .line 607
    .line 608
    move-result v13

    .line 609
    invoke-virtual {v10, v1}, Lrb4;->b(Landroid/view/MotionEvent;)V

    .line 610
    .line 611
    .line 612
    const/4 v14, 0x3

    .line 613
    const/4 v15, 0x2

    .line 614
    if-ne v13, v14, :cond_34

    .line 615
    .line 616
    invoke-virtual {v12}, Landroid/util/SparseLongArray;->clear()V

    .line 617
    .line 618
    .line 619
    iget-object v1, v10, Lrb4;->c:Landroid/util/SparseBooleanArray;

    .line 620
    .line 621
    invoke-virtual {v1}, Landroid/util/SparseBooleanArray;->clear()V

    .line 622
    .line 623
    .line 624
    move-object/from16 v21, v5

    .line 625
    .line 626
    move/from16 v16, v6

    .line 627
    .line 628
    move/from16 v17, v8

    .line 629
    .line 630
    const/4 v3, 0x0

    .line 631
    goto/16 :goto_20

    .line 632
    .line 633
    :cond_34
    invoke-virtual {v10, v1}, Lrb4;->a(Landroid/view/MotionEvent;)V

    .line 634
    .line 635
    .line 636
    if-eq v13, v9, :cond_36

    .line 637
    .line 638
    const/4 v14, 0x6

    .line 639
    if-eq v13, v14, :cond_35

    .line 640
    .line 641
    move v14, v6

    .line 642
    goto :goto_15

    .line 643
    :cond_35
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 644
    .line 645
    .line 646
    move-result v14

    .line 647
    goto :goto_15

    .line 648
    :cond_36
    move v14, v4

    .line 649
    :goto_15
    if-eqz v13, :cond_37

    .line 650
    .line 651
    if-eq v13, v15, :cond_37

    .line 652
    .line 653
    move/from16 v16, v6

    .line 654
    .line 655
    const/4 v6, 0x5

    .line 656
    if-eq v13, v6, :cond_38

    .line 657
    .line 658
    move v6, v4

    .line 659
    goto :goto_16

    .line 660
    :cond_37
    move/from16 v16, v6

    .line 661
    .line 662
    :cond_38
    move v6, v9

    .line 663
    :goto_16
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 664
    .line 665
    .line 666
    move-result v13

    .line 667
    new-instance v7, Ljava/util/ArrayList;

    .line 668
    .line 669
    invoke-direct {v7, v13}, Ljava/util/ArrayList;-><init>(I)V

    .line 670
    .line 671
    .line 672
    move v15, v4

    .line 673
    :goto_17
    if-ge v15, v13, :cond_41

    .line 674
    .line 675
    move/from16 v17, v8

    .line 676
    .line 677
    invoke-virtual {v1, v15}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 678
    .line 679
    .line 680
    move-result v8

    .line 681
    move/from16 v18, v9

    .line 682
    .line 683
    invoke-virtual {v12, v8}, Landroid/util/SparseLongArray;->indexOfKey(I)I

    .line 684
    .line 685
    .line 686
    move-result v9

    .line 687
    const-wide/16 v19, 0x1

    .line 688
    .line 689
    if-ltz v9, :cond_39

    .line 690
    .line 691
    invoke-virtual {v12, v9}, Landroid/util/SparseLongArray;->valueAt(I)J

    .line 692
    .line 693
    .line 694
    move-result-wide v8

    .line 695
    move-object/from16 v23, v3

    .line 696
    .line 697
    move-object/from16 v21, v5

    .line 698
    .line 699
    move-wide v4, v8

    .line 700
    goto :goto_18

    .line 701
    :cond_39
    move-object/from16 v21, v5

    .line 702
    .line 703
    iget-wide v4, v10, Lrb4;->a:J

    .line 704
    .line 705
    move-object/from16 v23, v3

    .line 706
    .line 707
    add-long v2, v4, v19

    .line 708
    .line 709
    iput-wide v2, v10, Lrb4;->a:J

    .line 710
    .line 711
    invoke-virtual {v12, v8, v4, v5}, Landroid/util/SparseLongArray;->put(IJ)V

    .line 712
    .line 713
    .line 714
    :goto_18
    invoke-virtual {v1, v15}, Landroid/view/MotionEvent;->getX(I)F

    .line 715
    .line 716
    .line 717
    move-result v2

    .line 718
    invoke-virtual {v1, v15}, Landroid/view/MotionEvent;->getY(I)F

    .line 719
    .line 720
    .line 721
    move-result v3

    .line 722
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 723
    .line 724
    .line 725
    move-result v2

    .line 726
    move-object v8, v10

    .line 727
    int-to-long v9, v2

    .line 728
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 729
    .line 730
    .line 731
    move-result v2

    .line 732
    int-to-long v2, v2

    .line 733
    const/16 v24, 0x20

    .line 734
    .line 735
    shl-long v9, v9, v24

    .line 736
    .line 737
    const-wide v25, 0xffffffffL

    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    and-long v2, v2, v25

    .line 743
    .line 744
    or-long v29, v9, v2

    .line 745
    .line 746
    if-eq v15, v14, :cond_3a

    .line 747
    .line 748
    move/from16 v31, v18

    .line 749
    .line 750
    goto :goto_19

    .line 751
    :cond_3a
    const/16 v31, 0x0

    .line 752
    .line 753
    :goto_19
    invoke-virtual {v11, v4, v5}, Lxw3;->b(J)Ljava/lang/Object;

    .line 754
    .line 755
    .line 756
    move-result-object v2

    .line 757
    check-cast v2, Lqb4;

    .line 758
    .line 759
    const-wide/32 v9, 0x7fffffff

    .line 760
    .line 761
    .line 762
    if-ne v15, v14, :cond_3c

    .line 763
    .line 764
    invoke-virtual {v11, v4, v5}, Lxw3;->e(J)V

    .line 765
    .line 766
    .line 767
    :cond_3b
    move-wide v3, v4

    .line 768
    move-wide/from16 v32, v9

    .line 769
    .line 770
    const v5, 0xffff

    .line 771
    .line 772
    .line 773
    goto :goto_1a

    .line 774
    :cond_3c
    if-eqz v6, :cond_3b

    .line 775
    .line 776
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 777
    .line 778
    .line 779
    move-result-wide v27

    .line 780
    and-long v27, v27, v9

    .line 781
    .line 782
    shl-long v27, v27, v18

    .line 783
    .line 784
    or-long v27, v19, v27

    .line 785
    .line 786
    move-wide/from16 v32, v9

    .line 787
    .line 788
    shr-long v9, v29, v24

    .line 789
    .line 790
    long-to-int v9, v9

    .line 791
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 792
    .line 793
    .line 794
    move-result v9

    .line 795
    float-to-int v9, v9

    .line 796
    int-to-short v9, v9

    .line 797
    move-wide/from16 v34, v4

    .line 798
    .line 799
    const v5, 0xffff

    .line 800
    .line 801
    .line 802
    and-long v3, v29, v25

    .line 803
    .line 804
    long-to-int v3, v3

    .line 805
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 806
    .line 807
    .line 808
    move-result v3

    .line 809
    float-to-int v3, v3

    .line 810
    int-to-short v3, v3

    .line 811
    shl-int/lit8 v9, v9, 0x10

    .line 812
    .line 813
    and-int/2addr v3, v5

    .line 814
    or-int/2addr v9, v3

    .line 815
    int-to-long v3, v9

    .line 816
    shl-long v3, v3, v24

    .line 817
    .line 818
    or-long v3, v27, v3

    .line 819
    .line 820
    new-instance v9, Lqb4;

    .line 821
    .line 822
    invoke-direct {v9, v3, v4}, Lqb4;-><init>(J)V

    .line 823
    .line 824
    .line 825
    move-wide/from16 v3, v34

    .line 826
    .line 827
    invoke-virtual {v11, v3, v4, v9}, Lxw3;->d(JLjava/lang/Object;)V

    .line 828
    .line 829
    .line 830
    :goto_1a
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 831
    .line 832
    .line 833
    move-result-wide v27

    .line 834
    move-wide/from16 v9, v32

    .line 835
    .line 836
    invoke-virtual {v1, v15}, Landroid/view/MotionEvent;->getPressure(I)F

    .line 837
    .line 838
    .line 839
    move-result v32

    .line 840
    if-eqz v2, :cond_3d

    .line 841
    .line 842
    move/from16 v33, v5

    .line 843
    .line 844
    move/from16 v38, v6

    .line 845
    .line 846
    iget-wide v5, v2, Lqb4;->a:J

    .line 847
    .line 848
    shr-long v34, v5, v18

    .line 849
    .line 850
    and-long v34, v34, v9

    .line 851
    .line 852
    ushr-long v5, v5, v24

    .line 853
    .line 854
    long-to-int v5, v5

    .line 855
    ushr-int/lit8 v6, v5, 0x10

    .line 856
    .line 857
    int-to-short v6, v6

    .line 858
    int-to-float v6, v6

    .line 859
    and-int v5, v5, v33

    .line 860
    .line 861
    int-to-short v5, v5

    .line 862
    int-to-float v5, v5

    .line 863
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 864
    .line 865
    .line 866
    move-result v6

    .line 867
    int-to-long v9, v6

    .line 868
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 869
    .line 870
    .line 871
    move-result v5

    .line 872
    int-to-long v5, v5

    .line 873
    shl-long v9, v9, v24

    .line 874
    .line 875
    and-long v5, v5, v25

    .line 876
    .line 877
    or-long/2addr v9, v5

    .line 878
    move-wide/from16 v33, v34

    .line 879
    .line 880
    move-wide/from16 v35, v9

    .line 881
    .line 882
    goto :goto_1b

    .line 883
    :cond_3d
    move/from16 v38, v6

    .line 884
    .line 885
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 886
    .line 887
    .line 888
    move-result-wide v34

    .line 889
    move-wide/from16 v33, v34

    .line 890
    .line 891
    move-wide/from16 v35, v29

    .line 892
    .line 893
    :goto_1b
    if-eqz v2, :cond_3f

    .line 894
    .line 895
    iget-wide v5, v2, Lqb4;->a:J

    .line 896
    .line 897
    and-long v5, v5, v19

    .line 898
    .line 899
    const-wide/16 v9, 0x0

    .line 900
    .line 901
    cmp-long v2, v5, v9

    .line 902
    .line 903
    if-eqz v2, :cond_3e

    .line 904
    .line 905
    move/from16 v2, v18

    .line 906
    .line 907
    goto :goto_1c

    .line 908
    :cond_3e
    const/4 v2, 0x0

    .line 909
    :goto_1c
    move/from16 v37, v2

    .line 910
    .line 911
    goto :goto_1d

    .line 912
    :cond_3f
    const/16 v37, 0x0

    .line 913
    .line 914
    :goto_1d
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getHistorySize()I

    .line 915
    .line 916
    .line 917
    move-result v2

    .line 918
    if-lez v2, :cond_40

    .line 919
    .line 920
    new-instance v24, Lk63;

    .line 921
    .line 922
    new-instance v2, Lel3;

    .line 923
    .line 924
    invoke-direct {v2, v1, v15}, Lel3;-><init>(Landroid/view/MotionEvent;I)V

    .line 925
    .line 926
    .line 927
    move-wide/from16 v25, v3

    .line 928
    .line 929
    invoke-direct/range {v24 .. v37}, Lk63;-><init>(JJJZFJJZ)V

    .line 930
    .line 931
    .line 932
    move-object/from16 v3, v24

    .line 933
    .line 934
    iput-object v2, v3, Lk63;->i:Lel3;

    .line 935
    .line 936
    goto :goto_1e

    .line 937
    :cond_40
    move-wide/from16 v25, v3

    .line 938
    .line 939
    new-instance v24, Lk63;

    .line 940
    .line 941
    invoke-direct/range {v24 .. v37}, Lk63;-><init>(JJJZFJJZ)V

    .line 942
    .line 943
    .line 944
    move-object/from16 v3, v24

    .line 945
    .line 946
    :goto_1e
    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 947
    .line 948
    .line 949
    add-int/lit8 v15, v15, 0x1

    .line 950
    .line 951
    move-object v10, v8

    .line 952
    move/from16 v8, v17

    .line 953
    .line 954
    move/from16 v9, v18

    .line 955
    .line 956
    move-object/from16 v5, v21

    .line 957
    .line 958
    move-object/from16 v3, v23

    .line 959
    .line 960
    move/from16 v6, v38

    .line 961
    .line 962
    goto/16 :goto_17

    .line 963
    .line 964
    :cond_41
    move-object/from16 v23, v3

    .line 965
    .line 966
    move-object/from16 v21, v5

    .line 967
    .line 968
    move/from16 v17, v8

    .line 969
    .line 970
    move/from16 v18, v9

    .line 971
    .line 972
    move-object v8, v10

    .line 973
    invoke-virtual {v8, v1}, Lrb4;->e(Landroid/view/MotionEvent;)V

    .line 974
    .line 975
    .line 976
    if-eqz v23, :cond_42

    .line 977
    .line 978
    move-object/from16 v2, v23

    .line 979
    .line 980
    iget v2, v2, Lj63;->a:I

    .line 981
    .line 982
    goto :goto_1f

    .line 983
    :cond_42
    const/high16 v2, 0x200000

    .line 984
    .line 985
    invoke-virtual {v1, v2}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 986
    .line 987
    .line 988
    move-result v3

    .line 989
    if-eqz v3, :cond_8c

    .line 990
    .line 991
    invoke-virtual {v1}, Landroid/view/InputEvent;->getDevice()Landroid/view/InputDevice;

    .line 992
    .line 993
    .line 994
    move-result-object v2

    .line 995
    if-eqz v2, :cond_48

    .line 996
    .line 997
    const/4 v9, 0x0

    .line 998
    invoke-virtual {v2, v9}, Landroid/view/InputDevice;->getMotionRange(I)Landroid/view/InputDevice$MotionRange;

    .line 999
    .line 1000
    .line 1001
    move-result-object v3

    .line 1002
    move/from16 v4, v18

    .line 1003
    .line 1004
    invoke-virtual {v2, v4}, Landroid/view/InputDevice;->getMotionRange(I)Landroid/view/InputDevice$MotionRange;

    .line 1005
    .line 1006
    .line 1007
    move-result-object v2

    .line 1008
    if-eqz v3, :cond_43

    .line 1009
    .line 1010
    if-eqz v2, :cond_45

    .line 1011
    .line 1012
    :cond_43
    if-eqz v2, :cond_44

    .line 1013
    .line 1014
    if-eqz v3, :cond_47

    .line 1015
    .line 1016
    :cond_44
    if-eqz v3, :cond_48

    .line 1017
    .line 1018
    if-eqz v2, :cond_48

    .line 1019
    .line 1020
    invoke-virtual {v3}, Landroid/view/InputDevice$MotionRange;->getRange()F

    .line 1021
    .line 1022
    .line 1023
    move-result v3

    .line 1024
    invoke-virtual {v2}, Landroid/view/InputDevice$MotionRange;->getRange()F

    .line 1025
    .line 1026
    .line 1027
    move-result v2

    .line 1028
    cmpl-float v4, v3, v2

    .line 1029
    .line 1030
    const/high16 v5, 0x40a00000    # 5.0f

    .line 1031
    .line 1032
    const/4 v6, 0x0

    .line 1033
    if-lez v4, :cond_46

    .line 1034
    .line 1035
    cmpg-float v4, v2, v6

    .line 1036
    .line 1037
    if-eqz v4, :cond_45

    .line 1038
    .line 1039
    div-float v4, v3, v2

    .line 1040
    .line 1041
    cmpl-float v4, v4, v5

    .line 1042
    .line 1043
    if-ltz v4, :cond_46

    .line 1044
    .line 1045
    :cond_45
    const/4 v2, 0x1

    .line 1046
    goto :goto_1f

    .line 1047
    :cond_46
    cmpl-float v4, v2, v3

    .line 1048
    .line 1049
    if-lez v4, :cond_48

    .line 1050
    .line 1051
    cmpg-float v4, v3, v6

    .line 1052
    .line 1053
    if-eqz v4, :cond_47

    .line 1054
    .line 1055
    div-float/2addr v2, v3

    .line 1056
    cmpl-float v2, v2, v5

    .line 1057
    .line 1058
    if-ltz v2, :cond_48

    .line 1059
    .line 1060
    :cond_47
    const/4 v2, 0x2

    .line 1061
    goto :goto_1f

    .line 1062
    :cond_48
    const/4 v2, 0x0

    .line 1063
    :goto_1f
    new-instance v3, Lx53;

    .line 1064
    .line 1065
    invoke-direct {v3, v7, v2, v1}, Lx53;-><init>(Ljava/util/ArrayList;ILandroid/view/MotionEvent;)V

    .line 1066
    .line 1067
    .line 1068
    :goto_20
    iget-object v1, v0, Lbb;->I0:Lu63;

    .line 1069
    .line 1070
    if-eqz v3, :cond_6f

    .line 1071
    .line 1072
    invoke-virtual {v0}, Lbb;->getFocusOwner()Lge2;

    .line 1073
    .line 1074
    .line 1075
    move-result-object v0

    .line 1076
    check-cast v0, Lje2;

    .line 1077
    .line 1078
    iget-object v2, v0, Lje2;->e:Lee2;

    .line 1079
    .line 1080
    iget-boolean v2, v2, Lee2;->e:Z

    .line 1081
    .line 1082
    if-eqz v2, :cond_4a

    .line 1083
    .line 1084
    const-string v0, "FocusRelatedWarning: Dispatching indirect pointer event while the focus system is invalidated."

    .line 1085
    .line 1086
    sget-object v2, Ljava/lang/System;->out:Ljava/io/PrintStream;

    .line 1087
    .line 1088
    invoke-virtual {v2, v0}, Ljava/io/PrintStream;->println(Ljava/lang/Object;)V

    .line 1089
    .line 1090
    .line 1091
    :cond_49
    const/4 v0, 0x0

    .line 1092
    goto/16 :goto_33

    .line 1093
    .line 1094
    :cond_4a
    invoke-virtual {v0}, Lje2;->h()Lye2;

    .line 1095
    .line 1096
    .line 1097
    move-result-object v0

    .line 1098
    if-eqz v0, :cond_57

    .line 1099
    .line 1100
    iget-object v2, v0, Lab4;->h:Lab4;

    .line 1101
    .line 1102
    iget-boolean v2, v2, Lab4;->u:Z

    .line 1103
    .line 1104
    if-nez v2, :cond_4b

    .line 1105
    .line 1106
    invoke-static/range {v21 .. v21}, Lp73;->b(Ljava/lang/String;)V

    .line 1107
    .line 1108
    .line 1109
    :cond_4b
    iget-object v2, v0, Lab4;->h:Lab4;

    .line 1110
    .line 1111
    invoke-static {v0}, Lsx;->l0(Lap1;)Lzi3;

    .line 1112
    .line 1113
    .line 1114
    move-result-object v0

    .line 1115
    :goto_21
    if-eqz v0, :cond_55

    .line 1116
    .line 1117
    iget-object v4, v0, Lzi3;->M:Lu9;

    .line 1118
    .line 1119
    iget-object v4, v4, Lu9;->g:Ljava/lang/Object;

    .line 1120
    .line 1121
    check-cast v4, Lab4;

    .line 1122
    .line 1123
    iget v4, v4, Lab4;->k:I

    .line 1124
    .line 1125
    const/high16 v22, 0x200000

    .line 1126
    .line 1127
    and-int v4, v4, v22

    .line 1128
    .line 1129
    if-eqz v4, :cond_53

    .line 1130
    .line 1131
    :goto_22
    if-eqz v2, :cond_53

    .line 1132
    .line 1133
    iget v4, v2, Lab4;->j:I

    .line 1134
    .line 1135
    and-int v4, v4, v22

    .line 1136
    .line 1137
    if-eqz v4, :cond_52

    .line 1138
    .line 1139
    move-object v4, v2

    .line 1140
    const/4 v5, 0x0

    .line 1141
    :goto_23
    if-eqz v4, :cond_52

    .line 1142
    .line 1143
    instance-of v6, v4, Ls63;

    .line 1144
    .line 1145
    if-nez v6, :cond_56

    .line 1146
    .line 1147
    iget v6, v4, Lab4;->j:I

    .line 1148
    .line 1149
    and-int v6, v6, v22

    .line 1150
    .line 1151
    if-eqz v6, :cond_51

    .line 1152
    .line 1153
    instance-of v6, v4, Lcp1;

    .line 1154
    .line 1155
    if-eqz v6, :cond_51

    .line 1156
    .line 1157
    move-object v6, v4

    .line 1158
    check-cast v6, Lcp1;

    .line 1159
    .line 1160
    iget-object v6, v6, Lcp1;->w:Lab4;

    .line 1161
    .line 1162
    const/4 v7, 0x0

    .line 1163
    :goto_24
    if-eqz v6, :cond_50

    .line 1164
    .line 1165
    iget v8, v6, Lab4;->j:I

    .line 1166
    .line 1167
    and-int v8, v8, v22

    .line 1168
    .line 1169
    if-eqz v8, :cond_4f

    .line 1170
    .line 1171
    add-int/lit8 v7, v7, 0x1

    .line 1172
    .line 1173
    const/4 v8, 0x1

    .line 1174
    if-ne v7, v8, :cond_4c

    .line 1175
    .line 1176
    move-object v4, v6

    .line 1177
    goto :goto_25

    .line 1178
    :cond_4c
    if-nez v5, :cond_4d

    .line 1179
    .line 1180
    new-instance v5, Lve4;

    .line 1181
    .line 1182
    move/from16 v8, v17

    .line 1183
    .line 1184
    new-array v10, v8, [Lab4;

    .line 1185
    .line 1186
    const/4 v9, 0x0

    .line 1187
    invoke-direct {v5, v9, v10}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 1188
    .line 1189
    .line 1190
    :cond_4d
    if-eqz v4, :cond_4e

    .line 1191
    .line 1192
    invoke-virtual {v5, v4}, Lve4;->b(Ljava/lang/Object;)V

    .line 1193
    .line 1194
    .line 1195
    const/4 v4, 0x0

    .line 1196
    :cond_4e
    invoke-virtual {v5, v6}, Lve4;->b(Ljava/lang/Object;)V

    .line 1197
    .line 1198
    .line 1199
    :cond_4f
    :goto_25
    iget-object v6, v6, Lab4;->m:Lab4;

    .line 1200
    .line 1201
    const/16 v17, 0x10

    .line 1202
    .line 1203
    const/high16 v22, 0x200000

    .line 1204
    .line 1205
    goto :goto_24

    .line 1206
    :cond_50
    const/4 v8, 0x1

    .line 1207
    if-ne v7, v8, :cond_51

    .line 1208
    .line 1209
    :goto_26
    const/16 v17, 0x10

    .line 1210
    .line 1211
    const/high16 v22, 0x200000

    .line 1212
    .line 1213
    goto :goto_23

    .line 1214
    :cond_51
    invoke-static {v5}, Lsx;->a0(Lve4;)Lab4;

    .line 1215
    .line 1216
    .line 1217
    move-result-object v4

    .line 1218
    goto :goto_26

    .line 1219
    :cond_52
    iget-object v2, v2, Lab4;->l:Lab4;

    .line 1220
    .line 1221
    const/16 v17, 0x10

    .line 1222
    .line 1223
    const/high16 v22, 0x200000

    .line 1224
    .line 1225
    goto :goto_22

    .line 1226
    :cond_53
    invoke-virtual {v0}, Lzi3;->u()Lzi3;

    .line 1227
    .line 1228
    .line 1229
    move-result-object v0

    .line 1230
    if-eqz v0, :cond_54

    .line 1231
    .line 1232
    iget-object v2, v0, Lzi3;->M:Lu9;

    .line 1233
    .line 1234
    if-eqz v2, :cond_54

    .line 1235
    .line 1236
    iget-object v2, v2, Lu9;->f:Ljava/lang/Object;

    .line 1237
    .line 1238
    check-cast v2, Lz87;

    .line 1239
    .line 1240
    goto :goto_27

    .line 1241
    :cond_54
    const/4 v2, 0x0

    .line 1242
    :goto_27
    const/16 v17, 0x10

    .line 1243
    .line 1244
    goto/16 :goto_21

    .line 1245
    .line 1246
    :cond_55
    const/4 v4, 0x0

    .line 1247
    :cond_56
    check-cast v4, Ls63;

    .line 1248
    .line 1249
    goto :goto_28

    .line 1250
    :cond_57
    const/4 v4, 0x0

    .line 1251
    :goto_28
    if-eqz v4, :cond_69

    .line 1252
    .line 1253
    move-object v0, v4

    .line 1254
    check-cast v0, Lab4;

    .line 1255
    .line 1256
    iget-object v2, v0, Lab4;->h:Lab4;

    .line 1257
    .line 1258
    iget-boolean v2, v2, Lab4;->u:Z

    .line 1259
    .line 1260
    if-nez v2, :cond_58

    .line 1261
    .line 1262
    invoke-static/range {v21 .. v21}, Lp73;->b(Ljava/lang/String;)V

    .line 1263
    .line 1264
    .line 1265
    :cond_58
    iget-object v0, v0, Lab4;->h:Lab4;

    .line 1266
    .line 1267
    iget-object v0, v0, Lab4;->l:Lab4;

    .line 1268
    .line 1269
    invoke-static {v4}, Lsx;->l0(Lap1;)Lzi3;

    .line 1270
    .line 1271
    .line 1272
    move-result-object v2

    .line 1273
    const/4 v5, 0x0

    .line 1274
    :goto_29
    if-eqz v2, :cond_65

    .line 1275
    .line 1276
    iget-object v6, v2, Lzi3;->M:Lu9;

    .line 1277
    .line 1278
    iget-object v6, v6, Lu9;->g:Ljava/lang/Object;

    .line 1279
    .line 1280
    check-cast v6, Lab4;

    .line 1281
    .line 1282
    iget v6, v6, Lab4;->k:I

    .line 1283
    .line 1284
    const/high16 v22, 0x200000

    .line 1285
    .line 1286
    and-int v6, v6, v22

    .line 1287
    .line 1288
    if-eqz v6, :cond_63

    .line 1289
    .line 1290
    :goto_2a
    if-eqz v0, :cond_63

    .line 1291
    .line 1292
    iget v6, v0, Lab4;->j:I

    .line 1293
    .line 1294
    and-int v6, v6, v22

    .line 1295
    .line 1296
    if-eqz v6, :cond_62

    .line 1297
    .line 1298
    move-object v6, v0

    .line 1299
    const/4 v7, 0x0

    .line 1300
    :cond_59
    :goto_2b
    if-eqz v6, :cond_62

    .line 1301
    .line 1302
    instance-of v8, v6, Ls63;

    .line 1303
    .line 1304
    if-eqz v8, :cond_5b

    .line 1305
    .line 1306
    if-nez v5, :cond_5a

    .line 1307
    .line 1308
    new-instance v5, Ljava/util/ArrayList;

    .line 1309
    .line 1310
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 1311
    .line 1312
    .line 1313
    :cond_5a
    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1314
    .line 1315
    .line 1316
    const/4 v8, 0x0

    .line 1317
    goto :goto_2c

    .line 1318
    :cond_5b
    const/4 v8, 0x1

    .line 1319
    :goto_2c
    if-eqz v8, :cond_61

    .line 1320
    .line 1321
    iget v8, v6, Lab4;->j:I

    .line 1322
    .line 1323
    const/high16 v22, 0x200000

    .line 1324
    .line 1325
    and-int v8, v8, v22

    .line 1326
    .line 1327
    if-eqz v8, :cond_61

    .line 1328
    .line 1329
    instance-of v8, v6, Lcp1;

    .line 1330
    .line 1331
    if-eqz v8, :cond_61

    .line 1332
    .line 1333
    move-object v8, v6

    .line 1334
    check-cast v8, Lcp1;

    .line 1335
    .line 1336
    iget-object v8, v8, Lcp1;->w:Lab4;

    .line 1337
    .line 1338
    const/4 v10, 0x0

    .line 1339
    :goto_2d
    if-eqz v8, :cond_60

    .line 1340
    .line 1341
    iget v11, v8, Lab4;->j:I

    .line 1342
    .line 1343
    and-int v11, v11, v22

    .line 1344
    .line 1345
    if-eqz v11, :cond_5f

    .line 1346
    .line 1347
    add-int/lit8 v10, v10, 0x1

    .line 1348
    .line 1349
    const/4 v11, 0x1

    .line 1350
    if-ne v10, v11, :cond_5c

    .line 1351
    .line 1352
    move-object v6, v8

    .line 1353
    goto :goto_2e

    .line 1354
    :cond_5c
    if-nez v7, :cond_5d

    .line 1355
    .line 1356
    new-instance v7, Lve4;

    .line 1357
    .line 1358
    const/16 v11, 0x10

    .line 1359
    .line 1360
    new-array v12, v11, [Lab4;

    .line 1361
    .line 1362
    const/4 v9, 0x0

    .line 1363
    invoke-direct {v7, v9, v12}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 1364
    .line 1365
    .line 1366
    :cond_5d
    if-eqz v6, :cond_5e

    .line 1367
    .line 1368
    invoke-virtual {v7, v6}, Lve4;->b(Ljava/lang/Object;)V

    .line 1369
    .line 1370
    .line 1371
    const/4 v6, 0x0

    .line 1372
    :cond_5e
    invoke-virtual {v7, v8}, Lve4;->b(Ljava/lang/Object;)V

    .line 1373
    .line 1374
    .line 1375
    :cond_5f
    :goto_2e
    iget-object v8, v8, Lab4;->m:Lab4;

    .line 1376
    .line 1377
    const/high16 v22, 0x200000

    .line 1378
    .line 1379
    goto :goto_2d

    .line 1380
    :cond_60
    const/4 v8, 0x1

    .line 1381
    if-eq v10, v8, :cond_59

    .line 1382
    .line 1383
    :cond_61
    invoke-static {v7}, Lsx;->a0(Lve4;)Lab4;

    .line 1384
    .line 1385
    .line 1386
    move-result-object v6

    .line 1387
    goto :goto_2b

    .line 1388
    :cond_62
    iget-object v0, v0, Lab4;->l:Lab4;

    .line 1389
    .line 1390
    const/high16 v22, 0x200000

    .line 1391
    .line 1392
    goto :goto_2a

    .line 1393
    :cond_63
    invoke-virtual {v2}, Lzi3;->u()Lzi3;

    .line 1394
    .line 1395
    .line 1396
    move-result-object v2

    .line 1397
    if-eqz v2, :cond_64

    .line 1398
    .line 1399
    iget-object v0, v2, Lzi3;->M:Lu9;

    .line 1400
    .line 1401
    if-eqz v0, :cond_64

    .line 1402
    .line 1403
    iget-object v0, v0, Lu9;->f:Ljava/lang/Object;

    .line 1404
    .line 1405
    check-cast v0, Lz87;

    .line 1406
    .line 1407
    goto/16 :goto_29

    .line 1408
    .line 1409
    :cond_64
    const/4 v0, 0x0

    .line 1410
    goto/16 :goto_29

    .line 1411
    .line 1412
    :cond_65
    sget-object v0, Lkc5;->h:Lkc5;

    .line 1413
    .line 1414
    if-eqz v5, :cond_66

    .line 1415
    .line 1416
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    .line 1417
    .line 1418
    .line 1419
    move-result v2

    .line 1420
    add-int/lit8 v2, v2, -0x1

    .line 1421
    .line 1422
    if-ltz v2, :cond_66

    .line 1423
    .line 1424
    :goto_2f
    add-int/lit8 v6, v2, -0x1

    .line 1425
    .line 1426
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1427
    .line 1428
    .line 1429
    move-result-object v2

    .line 1430
    check-cast v2, Ls63;

    .line 1431
    .line 1432
    invoke-interface {v2, v3, v0}, Ls63;->C0(Lx53;Lkc5;)V

    .line 1433
    .line 1434
    .line 1435
    if-ltz v6, :cond_66

    .line 1436
    .line 1437
    move v2, v6

    .line 1438
    goto :goto_2f

    .line 1439
    :cond_66
    invoke-interface {v4, v3, v0}, Ls63;->C0(Lx53;Lkc5;)V

    .line 1440
    .line 1441
    .line 1442
    sget-object v0, Lkc5;->i:Lkc5;

    .line 1443
    .line 1444
    invoke-interface {v4, v3, v0}, Ls63;->C0(Lx53;Lkc5;)V

    .line 1445
    .line 1446
    .line 1447
    if-eqz v5, :cond_67

    .line 1448
    .line 1449
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    .line 1450
    .line 1451
    .line 1452
    move-result v2

    .line 1453
    const/4 v6, 0x0

    .line 1454
    :goto_30
    if-ge v6, v2, :cond_67

    .line 1455
    .line 1456
    invoke-interface {v5, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1457
    .line 1458
    .line 1459
    move-result-object v7

    .line 1460
    check-cast v7, Ls63;

    .line 1461
    .line 1462
    invoke-interface {v7, v3, v0}, Ls63;->C0(Lx53;Lkc5;)V

    .line 1463
    .line 1464
    .line 1465
    add-int/lit8 v6, v6, 0x1

    .line 1466
    .line 1467
    goto :goto_30

    .line 1468
    :cond_67
    sget-object v0, Lkc5;->j:Lkc5;

    .line 1469
    .line 1470
    if-eqz v5, :cond_68

    .line 1471
    .line 1472
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    .line 1473
    .line 1474
    .line 1475
    move-result v2

    .line 1476
    add-int/lit8 v2, v2, -0x1

    .line 1477
    .line 1478
    if-ltz v2, :cond_68

    .line 1479
    .line 1480
    :goto_31
    add-int/lit8 v6, v2, -0x1

    .line 1481
    .line 1482
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1483
    .line 1484
    .line 1485
    move-result-object v2

    .line 1486
    check-cast v2, Ls63;

    .line 1487
    .line 1488
    invoke-interface {v2, v3, v0}, Ls63;->C0(Lx53;Lkc5;)V

    .line 1489
    .line 1490
    .line 1491
    if-ltz v6, :cond_68

    .line 1492
    .line 1493
    move v2, v6

    .line 1494
    goto :goto_31

    .line 1495
    :cond_68
    invoke-interface {v4, v3, v0}, Ls63;->C0(Lx53;Lkc5;)V

    .line 1496
    .line 1497
    .line 1498
    :cond_69
    iget-object v0, v3, Lx53;->j:Ljava/lang/Object;

    .line 1499
    .line 1500
    check-cast v0, Ljava/util/ArrayList;

    .line 1501
    .line 1502
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 1503
    .line 1504
    .line 1505
    move-result v2

    .line 1506
    const/4 v4, 0x0

    .line 1507
    :goto_32
    if-ge v4, v2, :cond_49

    .line 1508
    .line 1509
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1510
    .line 1511
    .line 1512
    move-result-object v5

    .line 1513
    check-cast v5, Lk63;

    .line 1514
    .line 1515
    iget-boolean v5, v5, Lk63;->j:Z

    .line 1516
    .line 1517
    if-eqz v5, :cond_6a

    .line 1518
    .line 1519
    const/4 v0, 0x1

    .line 1520
    goto :goto_33

    .line 1521
    :cond_6a
    add-int/lit8 v4, v4, 0x1

    .line 1522
    .line 1523
    goto :goto_32

    .line 1524
    :goto_33
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1525
    .line 1526
    .line 1527
    iget-object v2, v3, Lx53;->k:Ljava/lang/Object;

    .line 1528
    .line 1529
    check-cast v2, Landroid/view/MotionEvent;

    .line 1530
    .line 1531
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getAction()I

    .line 1532
    .line 1533
    .line 1534
    move-result v4

    .line 1535
    if-eqz v4, :cond_6c

    .line 1536
    .line 1537
    const/4 v8, 0x1

    .line 1538
    if-eq v4, v8, :cond_6b

    .line 1539
    .line 1540
    const/4 v3, 0x2

    .line 1541
    if-ne v4, v3, :cond_6d

    .line 1542
    .line 1543
    :cond_6b
    if-eqz v0, :cond_6d

    .line 1544
    .line 1545
    const/4 v9, 0x0

    .line 1546
    iput v9, v1, Lu63;->a:I

    .line 1547
    .line 1548
    iput-boolean v8, v1, Lu63;->b:Z

    .line 1549
    .line 1550
    goto :goto_34

    .line 1551
    :cond_6c
    const/4 v9, 0x0

    .line 1552
    iget v0, v3, Lx53;->i:I

    .line 1553
    .line 1554
    iput v0, v1, Lu63;->a:I

    .line 1555
    .line 1556
    iput-boolean v9, v1, Lu63;->b:Z

    .line 1557
    .line 1558
    :cond_6d
    :goto_34
    iget-object v0, v1, Lu63;->c:Ljava/lang/Object;

    .line 1559
    .line 1560
    check-cast v0, Lbb;

    .line 1561
    .line 1562
    iget-object v3, v1, Lu63;->e:Ljava/lang/Object;

    .line 1563
    .line 1564
    check-cast v3, Landroid/view/GestureDetector;

    .line 1565
    .line 1566
    if-nez v3, :cond_6e

    .line 1567
    .line 1568
    new-instance v3, Landroid/view/GestureDetector;

    .line 1569
    .line 1570
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1571
    .line 1572
    .line 1573
    move-result-object v4

    .line 1574
    iget-object v5, v1, Lu63;->f:Ljava/lang/Object;

    .line 1575
    .line 1576
    check-cast v5, Lt63;

    .line 1577
    .line 1578
    invoke-virtual {v0}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 1579
    .line 1580
    .line 1581
    move-result-object v0

    .line 1582
    invoke-direct {v3, v4, v5, v0}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;Landroid/os/Handler;)V

    .line 1583
    .line 1584
    .line 1585
    iput-object v3, v1, Lu63;->e:Ljava/lang/Object;

    .line 1586
    .line 1587
    :cond_6e
    invoke-virtual {v3, v2}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 1588
    .line 1589
    .line 1590
    const/16 v18, 0x1

    .line 1591
    .line 1592
    return v18

    .line 1593
    :cond_6f
    invoke-virtual {v0}, Lbb;->getFocusOwner()Lge2;

    .line 1594
    .line 1595
    .line 1596
    move-result-object v0

    .line 1597
    check-cast v0, Lje2;

    .line 1598
    .line 1599
    invoke-virtual {v0}, Lje2;->h()Lye2;

    .line 1600
    .line 1601
    .line 1602
    move-result-object v0

    .line 1603
    if-eqz v0, :cond_7c

    .line 1604
    .line 1605
    iget-object v2, v0, Lab4;->h:Lab4;

    .line 1606
    .line 1607
    iget-boolean v2, v2, Lab4;->u:Z

    .line 1608
    .line 1609
    if-nez v2, :cond_70

    .line 1610
    .line 1611
    invoke-static/range {v21 .. v21}, Lp73;->b(Ljava/lang/String;)V

    .line 1612
    .line 1613
    .line 1614
    :cond_70
    iget-object v2, v0, Lab4;->h:Lab4;

    .line 1615
    .line 1616
    invoke-static {v0}, Lsx;->l0(Lap1;)Lzi3;

    .line 1617
    .line 1618
    .line 1619
    move-result-object v0

    .line 1620
    :goto_35
    if-eqz v0, :cond_7a

    .line 1621
    .line 1622
    iget-object v3, v0, Lzi3;->M:Lu9;

    .line 1623
    .line 1624
    iget-object v3, v3, Lu9;->g:Ljava/lang/Object;

    .line 1625
    .line 1626
    check-cast v3, Lab4;

    .line 1627
    .line 1628
    iget v3, v3, Lab4;->k:I

    .line 1629
    .line 1630
    const/high16 v22, 0x200000

    .line 1631
    .line 1632
    and-int v3, v3, v22

    .line 1633
    .line 1634
    if-eqz v3, :cond_78

    .line 1635
    .line 1636
    :goto_36
    if-eqz v2, :cond_78

    .line 1637
    .line 1638
    iget v3, v2, Lab4;->j:I

    .line 1639
    .line 1640
    and-int v3, v3, v22

    .line 1641
    .line 1642
    if-eqz v3, :cond_77

    .line 1643
    .line 1644
    move-object v3, v2

    .line 1645
    const/4 v4, 0x0

    .line 1646
    :goto_37
    if-eqz v3, :cond_77

    .line 1647
    .line 1648
    instance-of v5, v3, Ls63;

    .line 1649
    .line 1650
    if-nez v5, :cond_7b

    .line 1651
    .line 1652
    iget v5, v3, Lab4;->j:I

    .line 1653
    .line 1654
    and-int v5, v5, v22

    .line 1655
    .line 1656
    if-eqz v5, :cond_76

    .line 1657
    .line 1658
    instance-of v5, v3, Lcp1;

    .line 1659
    .line 1660
    if-eqz v5, :cond_76

    .line 1661
    .line 1662
    move-object v5, v3

    .line 1663
    check-cast v5, Lcp1;

    .line 1664
    .line 1665
    iget-object v5, v5, Lcp1;->w:Lab4;

    .line 1666
    .line 1667
    const/4 v6, 0x0

    .line 1668
    :goto_38
    if-eqz v5, :cond_75

    .line 1669
    .line 1670
    iget v7, v5, Lab4;->j:I

    .line 1671
    .line 1672
    and-int v7, v7, v22

    .line 1673
    .line 1674
    if-eqz v7, :cond_74

    .line 1675
    .line 1676
    add-int/lit8 v6, v6, 0x1

    .line 1677
    .line 1678
    const/4 v8, 0x1

    .line 1679
    if-ne v6, v8, :cond_71

    .line 1680
    .line 1681
    move-object v3, v5

    .line 1682
    goto :goto_39

    .line 1683
    :cond_71
    if-nez v4, :cond_72

    .line 1684
    .line 1685
    new-instance v4, Lve4;

    .line 1686
    .line 1687
    const/16 v8, 0x10

    .line 1688
    .line 1689
    new-array v7, v8, [Lab4;

    .line 1690
    .line 1691
    const/4 v9, 0x0

    .line 1692
    invoke-direct {v4, v9, v7}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 1693
    .line 1694
    .line 1695
    :cond_72
    if-eqz v3, :cond_73

    .line 1696
    .line 1697
    invoke-virtual {v4, v3}, Lve4;->b(Ljava/lang/Object;)V

    .line 1698
    .line 1699
    .line 1700
    const/4 v3, 0x0

    .line 1701
    :cond_73
    invoke-virtual {v4, v5}, Lve4;->b(Ljava/lang/Object;)V

    .line 1702
    .line 1703
    .line 1704
    :cond_74
    :goto_39
    iget-object v5, v5, Lab4;->m:Lab4;

    .line 1705
    .line 1706
    const/high16 v22, 0x200000

    .line 1707
    .line 1708
    goto :goto_38

    .line 1709
    :cond_75
    const/4 v8, 0x1

    .line 1710
    if-ne v6, v8, :cond_76

    .line 1711
    .line 1712
    :goto_3a
    const/high16 v22, 0x200000

    .line 1713
    .line 1714
    goto :goto_37

    .line 1715
    :cond_76
    invoke-static {v4}, Lsx;->a0(Lve4;)Lab4;

    .line 1716
    .line 1717
    .line 1718
    move-result-object v3

    .line 1719
    goto :goto_3a

    .line 1720
    :cond_77
    iget-object v2, v2, Lab4;->l:Lab4;

    .line 1721
    .line 1722
    const/high16 v22, 0x200000

    .line 1723
    .line 1724
    goto :goto_36

    .line 1725
    :cond_78
    invoke-virtual {v0}, Lzi3;->u()Lzi3;

    .line 1726
    .line 1727
    .line 1728
    move-result-object v0

    .line 1729
    if-eqz v0, :cond_79

    .line 1730
    .line 1731
    iget-object v2, v0, Lzi3;->M:Lu9;

    .line 1732
    .line 1733
    if-eqz v2, :cond_79

    .line 1734
    .line 1735
    iget-object v2, v2, Lu9;->f:Ljava/lang/Object;

    .line 1736
    .line 1737
    check-cast v2, Lz87;

    .line 1738
    .line 1739
    goto :goto_35

    .line 1740
    :cond_79
    const/4 v2, 0x0

    .line 1741
    goto :goto_35

    .line 1742
    :cond_7a
    const/4 v3, 0x0

    .line 1743
    :cond_7b
    check-cast v3, Ls63;

    .line 1744
    .line 1745
    goto :goto_3b

    .line 1746
    :cond_7c
    const/4 v3, 0x0

    .line 1747
    :goto_3b
    if-eqz v3, :cond_8b

    .line 1748
    .line 1749
    move-object v0, v3

    .line 1750
    check-cast v0, Lab4;

    .line 1751
    .line 1752
    iget-object v2, v0, Lab4;->h:Lab4;

    .line 1753
    .line 1754
    iget-boolean v2, v2, Lab4;->u:Z

    .line 1755
    .line 1756
    if-nez v2, :cond_7d

    .line 1757
    .line 1758
    invoke-static/range {v21 .. v21}, Lp73;->b(Ljava/lang/String;)V

    .line 1759
    .line 1760
    .line 1761
    :cond_7d
    iget-object v0, v0, Lab4;->h:Lab4;

    .line 1762
    .line 1763
    iget-object v0, v0, Lab4;->l:Lab4;

    .line 1764
    .line 1765
    invoke-static {v3}, Lsx;->l0(Lap1;)Lzi3;

    .line 1766
    .line 1767
    .line 1768
    move-result-object v2

    .line 1769
    const/4 v4, 0x0

    .line 1770
    :goto_3c
    if-eqz v2, :cond_8a

    .line 1771
    .line 1772
    iget-object v5, v2, Lzi3;->M:Lu9;

    .line 1773
    .line 1774
    iget-object v5, v5, Lu9;->g:Ljava/lang/Object;

    .line 1775
    .line 1776
    check-cast v5, Lab4;

    .line 1777
    .line 1778
    iget v5, v5, Lab4;->k:I

    .line 1779
    .line 1780
    const/high16 v22, 0x200000

    .line 1781
    .line 1782
    and-int v5, v5, v22

    .line 1783
    .line 1784
    if-eqz v5, :cond_88

    .line 1785
    .line 1786
    :goto_3d
    if-eqz v0, :cond_88

    .line 1787
    .line 1788
    iget v5, v0, Lab4;->j:I

    .line 1789
    .line 1790
    and-int v5, v5, v22

    .line 1791
    .line 1792
    if-eqz v5, :cond_87

    .line 1793
    .line 1794
    move-object v5, v0

    .line 1795
    const/4 v6, 0x0

    .line 1796
    :cond_7e
    :goto_3e
    if-eqz v5, :cond_87

    .line 1797
    .line 1798
    instance-of v7, v5, Ls63;

    .line 1799
    .line 1800
    if-eqz v7, :cond_80

    .line 1801
    .line 1802
    if-nez v4, :cond_7f

    .line 1803
    .line 1804
    new-instance v4, Ljava/util/ArrayList;

    .line 1805
    .line 1806
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 1807
    .line 1808
    .line 1809
    :cond_7f
    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1810
    .line 1811
    .line 1812
    const/4 v7, 0x0

    .line 1813
    goto :goto_3f

    .line 1814
    :cond_80
    const/4 v7, 0x1

    .line 1815
    :goto_3f
    if-eqz v7, :cond_86

    .line 1816
    .line 1817
    iget v7, v5, Lab4;->j:I

    .line 1818
    .line 1819
    const/high16 v22, 0x200000

    .line 1820
    .line 1821
    and-int v7, v7, v22

    .line 1822
    .line 1823
    if-eqz v7, :cond_86

    .line 1824
    .line 1825
    instance-of v7, v5, Lcp1;

    .line 1826
    .line 1827
    if-eqz v7, :cond_86

    .line 1828
    .line 1829
    move-object v7, v5

    .line 1830
    check-cast v7, Lcp1;

    .line 1831
    .line 1832
    iget-object v7, v7, Lcp1;->w:Lab4;

    .line 1833
    .line 1834
    const/4 v8, 0x0

    .line 1835
    :goto_40
    if-eqz v7, :cond_85

    .line 1836
    .line 1837
    iget v10, v7, Lab4;->j:I

    .line 1838
    .line 1839
    and-int v10, v10, v22

    .line 1840
    .line 1841
    if-eqz v10, :cond_84

    .line 1842
    .line 1843
    add-int/lit8 v8, v8, 0x1

    .line 1844
    .line 1845
    const/4 v11, 0x1

    .line 1846
    if-ne v8, v11, :cond_81

    .line 1847
    .line 1848
    move-object v5, v7

    .line 1849
    goto :goto_41

    .line 1850
    :cond_81
    if-nez v6, :cond_82

    .line 1851
    .line 1852
    new-instance v6, Lve4;

    .line 1853
    .line 1854
    const/16 v11, 0x10

    .line 1855
    .line 1856
    new-array v10, v11, [Lab4;

    .line 1857
    .line 1858
    const/4 v9, 0x0

    .line 1859
    invoke-direct {v6, v9, v10}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 1860
    .line 1861
    .line 1862
    :cond_82
    if-eqz v5, :cond_83

    .line 1863
    .line 1864
    invoke-virtual {v6, v5}, Lve4;->b(Ljava/lang/Object;)V

    .line 1865
    .line 1866
    .line 1867
    const/4 v5, 0x0

    .line 1868
    :cond_83
    invoke-virtual {v6, v7}, Lve4;->b(Ljava/lang/Object;)V

    .line 1869
    .line 1870
    .line 1871
    :cond_84
    :goto_41
    iget-object v7, v7, Lab4;->m:Lab4;

    .line 1872
    .line 1873
    goto :goto_40

    .line 1874
    :cond_85
    const/4 v7, 0x1

    .line 1875
    if-eq v8, v7, :cond_7e

    .line 1876
    .line 1877
    :cond_86
    invoke-static {v6}, Lsx;->a0(Lve4;)Lab4;

    .line 1878
    .line 1879
    .line 1880
    move-result-object v5

    .line 1881
    goto :goto_3e

    .line 1882
    :cond_87
    const/high16 v22, 0x200000

    .line 1883
    .line 1884
    iget-object v0, v0, Lab4;->l:Lab4;

    .line 1885
    .line 1886
    goto :goto_3d

    .line 1887
    :cond_88
    invoke-virtual {v2}, Lzi3;->u()Lzi3;

    .line 1888
    .line 1889
    .line 1890
    move-result-object v2

    .line 1891
    if-eqz v2, :cond_89

    .line 1892
    .line 1893
    iget-object v0, v2, Lzi3;->M:Lu9;

    .line 1894
    .line 1895
    if-eqz v0, :cond_89

    .line 1896
    .line 1897
    iget-object v0, v0, Lu9;->f:Ljava/lang/Object;

    .line 1898
    .line 1899
    check-cast v0, Lz87;

    .line 1900
    .line 1901
    goto/16 :goto_3c

    .line 1902
    .line 1903
    :cond_89
    const/4 v0, 0x0

    .line 1904
    goto/16 :goto_3c

    .line 1905
    .line 1906
    :cond_8a
    invoke-interface {v3}, Ls63;->S()V

    .line 1907
    .line 1908
    .line 1909
    if-eqz v4, :cond_8b

    .line 1910
    .line 1911
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 1912
    .line 1913
    .line 1914
    move-result v0

    .line 1915
    const/4 v2, 0x0

    .line 1916
    :goto_42
    if-ge v2, v0, :cond_8b

    .line 1917
    .line 1918
    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1919
    .line 1920
    .line 1921
    move-result-object v3

    .line 1922
    check-cast v3, Ls63;

    .line 1923
    .line 1924
    invoke-interface {v3}, Ls63;->S()V

    .line 1925
    .line 1926
    .line 1927
    add-int/lit8 v2, v2, 0x1

    .line 1928
    .line 1929
    goto :goto_42

    .line 1930
    :cond_8b
    const/4 v9, 0x0

    .line 1931
    iput v9, v1, Lu63;->a:I

    .line 1932
    .line 1933
    const/4 v8, 0x1

    .line 1934
    iput-boolean v8, v1, Lu63;->b:Z

    .line 1935
    .line 1936
    return v8

    .line 1937
    :cond_8c
    const/4 v9, 0x0

    .line 1938
    const-string v0, "MotionEvent must be a touch navigation source"

    .line 1939
    .line 1940
    invoke-static {v0}, Ll42;->g(Ljava/lang/String;)V

    .line 1941
    .line 1942
    .line 1943
    return v9

    .line 1944
    :cond_8d
    invoke-super/range {p0 .. p1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 1945
    .line 1946
    .line 1947
    move-result v0

    .line 1948
    return v0

    .line 1949
    :cond_8e
    invoke-super/range {p0 .. p1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 1950
    .line 1951
    .line 1952
    move-result v0

    .line 1953
    return v0
.end method

.method public final dispatchHoverEvent(Landroid/view/MotionEvent;)Z
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-boolean v2, v0, Lbb;->G0:Z

    .line 6
    .line 7
    iget-object v3, v0, Lbb;->F0:Lpa;

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 12
    .line 13
    .line 14
    invoke-virtual {v3}, Lpa;->run()V

    .line 15
    .line 16
    .line 17
    :cond_0
    invoke-static {v1}, Lbb;->m(Landroid/view/MotionEvent;)Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    const/4 v4, 0x0

    .line 22
    if-nez v2, :cond_15

    .line 23
    .line 24
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_15

    .line 29
    .line 30
    iget-object v2, v0, Lbb;->F:Ljb;

    .line 31
    .line 32
    iget-object v5, v2, Ljb;->k:Lbb;

    .line 33
    .line 34
    invoke-virtual {v2}, Ljb;->t()Z

    .line 35
    .line 36
    .line 37
    move-result v6

    .line 38
    const/4 v7, 0x7

    .line 39
    const/16 v8, 0xa

    .line 40
    .line 41
    const/4 v9, 0x1

    .line 42
    if-nez v6, :cond_2

    .line 43
    .line 44
    iput-boolean v4, v2, Ljb;->m:Z

    .line 45
    .line 46
    :cond_1
    move v2, v4

    .line 47
    goto/16 :goto_9

    .line 48
    .line 49
    :cond_2
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getAction()I

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    const/16 v10, 0x100

    .line 54
    .line 55
    const/16 v11, 0x80

    .line 56
    .line 57
    const/16 v12, 0xc

    .line 58
    .line 59
    const/4 v13, 0x0

    .line 60
    const/high16 v14, -0x80000000

    .line 61
    .line 62
    if-eq v6, v7, :cond_4

    .line 63
    .line 64
    const/16 v15, 0x9

    .line 65
    .line 66
    if-eq v6, v15, :cond_4

    .line 67
    .line 68
    if-ne v6, v8, :cond_1

    .line 69
    .line 70
    iget-boolean v6, v2, Ljb;->m:Z

    .line 71
    .line 72
    iput-boolean v4, v2, Ljb;->m:Z

    .line 73
    .line 74
    iget v15, v2, Ljb;->l:I

    .line 75
    .line 76
    if-eq v15, v14, :cond_3

    .line 77
    .line 78
    if-eq v15, v14, :cond_e

    .line 79
    .line 80
    iput v14, v2, Ljb;->l:I

    .line 81
    .line 82
    invoke-static {v2, v14, v11, v13, v12}, Ljb;->C(Ljb;IILjava/lang/Integer;I)V

    .line 83
    .line 84
    .line 85
    invoke-static {v2, v15, v10, v13, v12}, Ljb;->C(Ljb;IILjava/lang/Integer;I)V

    .line 86
    .line 87
    .line 88
    goto/16 :goto_8

    .line 89
    .line 90
    :cond_3
    if-eqz v6, :cond_1

    .line 91
    .line 92
    invoke-virtual {v5}, Lbb;->getAndroidViewsHandler$androidx_compose_ui_ui()Llg;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    if-eqz v2, :cond_1

    .line 97
    .line 98
    invoke-virtual {v2, v1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 99
    .line 100
    .line 101
    move-result v2

    .line 102
    goto/16 :goto_9

    .line 103
    .line 104
    :cond_4
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getX()F

    .line 105
    .line 106
    .line 107
    move-result v6

    .line 108
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getY()F

    .line 109
    .line 110
    .line 111
    move-result v15

    .line 112
    invoke-virtual {v5, v9}, Lbb;->q(Z)V

    .line 113
    .line 114
    .line 115
    new-instance v20, Lzs2;

    .line 116
    .line 117
    invoke-direct/range {v20 .. v20}, Lzs2;-><init>()V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v5}, Lbb;->getRoot()Lzi3;

    .line 121
    .line 122
    .line 123
    move-result-object v7

    .line 124
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 125
    .line 126
    .line 127
    move-result v6

    .line 128
    move/from16 v16, v15

    .line 129
    .line 130
    int-to-long v14, v6

    .line 131
    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 132
    .line 133
    .line 134
    move-result v6

    .line 135
    int-to-long v10, v6

    .line 136
    const/16 v6, 0x20

    .line 137
    .line 138
    shl-long/2addr v14, v6

    .line 139
    const-wide v16, 0xffffffffL

    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    and-long v10, v10, v16

    .line 145
    .line 146
    or-long/2addr v14, v10

    .line 147
    iget-object v7, v7, Lzi3;->M:Lu9;

    .line 148
    .line 149
    iget-object v10, v7, Lu9;->e:Ljava/lang/Object;

    .line 150
    .line 151
    check-cast v10, Lbt4;

    .line 152
    .line 153
    sget-object v11, Lbt4;->b0:Lnl4;

    .line 154
    .line 155
    invoke-virtual {v10, v14, v15}, Lbt4;->y1(J)J

    .line 156
    .line 157
    .line 158
    move-result-wide v18

    .line 159
    iget-object v7, v7, Lu9;->e:Ljava/lang/Object;

    .line 160
    .line 161
    move-object/from16 v16, v7

    .line 162
    .line 163
    check-cast v16, Lbt4;

    .line 164
    .line 165
    sget-object v17, Lbt4;->h0:Lzk2;

    .line 166
    .line 167
    const/16 v21, 0x1

    .line 168
    .line 169
    const/16 v22, 0x1

    .line 170
    .line 171
    invoke-virtual/range {v16 .. v22}, Lbt4;->H1(Lat4;JLzs2;IZ)V

    .line 172
    .line 173
    .line 174
    move-object/from16 v7, v20

    .line 175
    .line 176
    iget-object v7, v7, Lzs2;->h:Lfe4;

    .line 177
    .line 178
    iget v10, v7, Lfe4;->b:I

    .line 179
    .line 180
    sub-int/2addr v10, v9

    .line 181
    :goto_0
    const/4 v11, -0x1

    .line 182
    if-ge v11, v10, :cond_9

    .line 183
    .line 184
    invoke-virtual {v7, v10}, Lfe4;->g(I)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v11

    .line 188
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 189
    .line 190
    .line 191
    check-cast v11, Lab4;

    .line 192
    .line 193
    invoke-static {v11}, Lsx;->l0(Lap1;)Lzi3;

    .line 194
    .line 195
    .line 196
    move-result-object v11

    .line 197
    invoke-virtual {v5}, Lbb;->getAndroidViewsHandler$androidx_compose_ui_ui()Llg;

    .line 198
    .line 199
    .line 200
    move-result-object v14

    .line 201
    if-eqz v14, :cond_5

    .line 202
    .line 203
    invoke-virtual {v14}, Llg;->getLayoutNodeToHolder()Ljava/util/HashMap;

    .line 204
    .line 205
    .line 206
    move-result-object v14

    .line 207
    invoke-virtual {v14, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v14

    .line 211
    check-cast v14, Lgg;

    .line 212
    .line 213
    goto :goto_1

    .line 214
    :cond_5
    move-object v14, v13

    .line 215
    :goto_1
    iget-object v15, v11, Lzi3;->M:Lu9;

    .line 216
    .line 217
    move/from16 v16, v6

    .line 218
    .line 219
    const/16 v6, 0x8

    .line 220
    .line 221
    invoke-virtual {v15, v6}, Lu9;->f(I)Z

    .line 222
    .line 223
    .line 224
    move-result v6

    .line 225
    if-eqz v6, :cond_8

    .line 226
    .line 227
    iget v6, v11, Lzi3;->i:I

    .line 228
    .line 229
    invoke-virtual {v2, v6}, Ljb;->y(I)I

    .line 230
    .line 231
    .line 232
    move-result v6

    .line 233
    invoke-static {v11, v4}, Lej3;->m(Lzi3;Z)Lel6;

    .line 234
    .line 235
    .line 236
    move-result-object v11

    .line 237
    invoke-virtual {v2}, Ljb;->o()Ln93;

    .line 238
    .line 239
    .line 240
    move-result-object v15

    .line 241
    invoke-virtual {v15, v6}, Ln93;->b(I)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v15

    .line 245
    check-cast v15, Lr7;

    .line 246
    .line 247
    if-eqz v15, :cond_6

    .line 248
    .line 249
    iget-boolean v15, v15, Lr7;->c:Z

    .line 250
    .line 251
    if-ne v15, v9, :cond_6

    .line 252
    .line 253
    move v15, v9

    .line 254
    goto :goto_2

    .line 255
    :cond_6
    move v15, v4

    .line 256
    :goto_2
    invoke-static {v11}, Lem1;->x(Lel6;)Z

    .line 257
    .line 258
    .line 259
    move-result v17

    .line 260
    if-nez v17, :cond_8

    .line 261
    .line 262
    if-nez v15, :cond_8

    .line 263
    .line 264
    if-eqz v14, :cond_7

    .line 265
    .line 266
    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    goto :goto_3

    .line 272
    :cond_7
    invoke-static {v11}, Lem1;->y(Lel6;)Z

    .line 273
    .line 274
    .line 275
    move-result v14

    .line 276
    if-eqz v14, :cond_8

    .line 277
    .line 278
    invoke-static {v11}, Lqj3;->J(Lel6;)Z

    .line 279
    .line 280
    .line 281
    move-result v11

    .line 282
    if-nez v11, :cond_8

    .line 283
    .line 284
    int-to-long v6, v6

    .line 285
    shl-long v6, v6, v16

    .line 286
    .line 287
    goto :goto_3

    .line 288
    :cond_8
    add-int/lit8 v10, v10, -0x1

    .line 289
    .line 290
    move/from16 v6, v16

    .line 291
    .line 292
    goto :goto_0

    .line 293
    :cond_9
    move/from16 v16, v6

    .line 294
    .line 295
    const-wide/high16 v6, -0x8000000000000000L

    .line 296
    .line 297
    :goto_3
    shr-long v10, v6, v16

    .line 298
    .line 299
    long-to-int v10, v10

    .line 300
    const-wide/16 v14, 0x1

    .line 301
    .line 302
    and-long/2addr v6, v14

    .line 303
    const-wide/16 v14, 0x0

    .line 304
    .line 305
    cmp-long v6, v6, v14

    .line 306
    .line 307
    if-eqz v6, :cond_a

    .line 308
    .line 309
    move v6, v9

    .line 310
    goto :goto_4

    .line 311
    :cond_a
    move v6, v4

    .line 312
    :goto_4
    if-eqz v6, :cond_b

    .line 313
    .line 314
    iput-boolean v6, v2, Ljb;->m:Z

    .line 315
    .line 316
    invoke-virtual {v5}, Lbb;->getAndroidViewsHandler$androidx_compose_ui_ui()Llg;

    .line 317
    .line 318
    .line 319
    move-result-object v5

    .line 320
    if-eqz v5, :cond_c

    .line 321
    .line 322
    invoke-virtual {v5, v1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 323
    .line 324
    .line 325
    move-result v5

    .line 326
    goto :goto_5

    .line 327
    :cond_b
    iget-boolean v6, v2, Ljb;->m:Z

    .line 328
    .line 329
    if-eqz v6, :cond_c

    .line 330
    .line 331
    iput-boolean v4, v2, Ljb;->m:Z

    .line 332
    .line 333
    invoke-virtual {v5}, Lbb;->getAndroidViewsHandler$androidx_compose_ui_ui()Llg;

    .line 334
    .line 335
    .line 336
    move-result-object v5

    .line 337
    if-eqz v5, :cond_c

    .line 338
    .line 339
    invoke-static {v1}, Landroid/view/MotionEvent;->obtainNoHistory(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 340
    .line 341
    .line 342
    move-result-object v6

    .line 343
    :try_start_0
    invoke-virtual {v6, v8}, Landroid/view/MotionEvent;->setAction(I)V

    .line 344
    .line 345
    .line 346
    invoke-virtual {v5, v6}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 347
    .line 348
    .line 349
    invoke-virtual {v6}, Landroid/view/MotionEvent;->recycle()V

    .line 350
    .line 351
    .line 352
    :cond_c
    move v5, v4

    .line 353
    :goto_5
    iget v6, v2, Ljb;->l:I

    .line 354
    .line 355
    if-ne v6, v10, :cond_d

    .line 356
    .line 357
    :goto_6
    const/high16 v2, -0x80000000

    .line 358
    .line 359
    goto :goto_7

    .line 360
    :cond_d
    iput v10, v2, Ljb;->l:I

    .line 361
    .line 362
    const/16 v7, 0x80

    .line 363
    .line 364
    invoke-static {v2, v10, v7, v13, v12}, Ljb;->C(Ljb;IILjava/lang/Integer;I)V

    .line 365
    .line 366
    .line 367
    const/16 v7, 0x100

    .line 368
    .line 369
    invoke-static {v2, v6, v7, v13, v12}, Ljb;->C(Ljb;IILjava/lang/Integer;I)V

    .line 370
    .line 371
    .line 372
    goto :goto_6

    .line 373
    :goto_7
    if-ne v10, v2, :cond_e

    .line 374
    .line 375
    move v2, v5

    .line 376
    goto :goto_9

    .line 377
    :cond_e
    :goto_8
    move v2, v9

    .line 378
    :goto_9
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 379
    .line 380
    .line 381
    move-result v5

    .line 382
    const/4 v6, 0x7

    .line 383
    if-eq v5, v6, :cond_11

    .line 384
    .line 385
    if-ne v5, v8, :cond_13

    .line 386
    .line 387
    sget-object v5, Lic5;->h:Lic5;

    .line 388
    .line 389
    invoke-virtual {v0, v1, v5}, Lbb;->n(Landroid/view/MotionEvent;Lic5;)Z

    .line 390
    .line 391
    .line 392
    move-result v5

    .line 393
    if-eqz v5, :cond_13

    .line 394
    .line 395
    invoke-virtual {v1, v4}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 396
    .line 397
    .line 398
    move-result v4

    .line 399
    const/4 v5, 0x3

    .line 400
    if-ne v4, v5, :cond_f

    .line 401
    .line 402
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getButtonState()I

    .line 403
    .line 404
    .line 405
    move-result v4

    .line 406
    if-nez v4, :cond_12

    .line 407
    .line 408
    :cond_f
    iget-object v4, v0, Lbb;->w0:Landroid/view/MotionEvent;

    .line 409
    .line 410
    if-eqz v4, :cond_10

    .line 411
    .line 412
    invoke-virtual {v4}, Landroid/view/MotionEvent;->recycle()V

    .line 413
    .line 414
    .line 415
    :cond_10
    invoke-static {v1}, Landroid/view/MotionEvent;->obtainNoHistory(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 416
    .line 417
    .line 418
    move-result-object v1

    .line 419
    iput-object v1, v0, Lbb;->w0:Landroid/view/MotionEvent;

    .line 420
    .line 421
    iput-boolean v9, v0, Lbb;->G0:Z

    .line 422
    .line 423
    const-wide/16 v4, 0x8

    .line 424
    .line 425
    invoke-virtual {v0, v3, v4, v5}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 426
    .line 427
    .line 428
    return v2

    .line 429
    :cond_11
    invoke-virtual/range {p0 .. p1}, Lbb;->o(Landroid/view/MotionEvent;)Z

    .line 430
    .line 431
    .line 432
    move-result v3

    .line 433
    if-nez v3, :cond_13

    .line 434
    .line 435
    :cond_12
    return v2

    .line 436
    :cond_13
    invoke-virtual/range {p0 .. p1}, Lbb;->i(Landroid/view/MotionEvent;)I

    .line 437
    .line 438
    .line 439
    move-result v0

    .line 440
    and-int/2addr v0, v9

    .line 441
    if-nez v0, :cond_14

    .line 442
    .line 443
    if-eqz v2, :cond_15

    .line 444
    .line 445
    :cond_14
    return v9

    .line 446
    :catchall_0
    move-exception v0

    .line 447
    invoke-virtual {v6}, Landroid/view/MotionEvent;->recycle()V

    .line 448
    .line 449
    .line 450
    throw v0

    .line 451
    :cond_15
    return v4
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    iget-object v0, p0, Lbb;->h:Lw41;

    .line 8
    .line 9
    iget-object v0, v0, Lw41;->x:Lrn3;

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getMetaState()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    sget-object v1, Lx18;->a:Lz75;

    .line 16
    .line 17
    new-instance v2, Lad5;

    .line 18
    .line 19
    invoke-direct {v2, v0}, Lad5;-><init>(I)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1, v2}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    new-instance v1, Lnv3;

    .line 30
    .line 31
    const/4 v2, 0x6

    .line 32
    invoke-direct {v1, v2}, Lnv3;-><init>(B)V

    .line 33
    .line 34
    .line 35
    check-cast v0, Lje2;

    .line 36
    .line 37
    invoke-virtual {v0, p1, v1}, Lje2;->f(Landroid/view/KeyEvent;Llh2;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_0

    .line 42
    .line 43
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 44
    .line 45
    .line 46
    move-result p0

    .line 47
    if-nez p0, :cond_0

    .line 48
    .line 49
    const/4 p0, 0x0

    .line 50
    return p0

    .line 51
    :cond_0
    const/4 p0, 0x1

    .line 52
    return p0

    .line 53
    :cond_1
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    new-instance v1, Lx;

    .line 58
    .line 59
    const/4 v2, 0x5

    .line 60
    invoke-direct {v1, p0, p1, v2}, Lx;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 61
    .line 62
    .line 63
    check-cast v0, Lje2;

    .line 64
    .line 65
    invoke-virtual {v0, p1, v1}, Lje2;->f(Landroid/view/KeyEvent;Llh2;)Z

    .line 66
    .line 67
    .line 68
    move-result p0

    .line 69
    return p0
.end method

.method public final dispatchKeyEventPreIme(Landroid/view/KeyEvent;)Z
    .locals 11

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    if-eqz v0, :cond_c

    .line 8
    .line 9
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Lje2;

    .line 14
    .line 15
    iget-object v3, v0, Lje2;->e:Lee2;

    .line 16
    .line 17
    iget-boolean v3, v3, Lee2;->e:Z

    .line 18
    .line 19
    if-eqz v3, :cond_0

    .line 20
    .line 21
    const-string v0, "FocusRelatedWarning: Dispatching intercepted soft keyboard event while the focus system is invalidated."

    .line 22
    .line 23
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    .line 24
    .line 25
    invoke-virtual {v3, v0}, Ljava/io/PrintStream;->println(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    goto/16 :goto_5

    .line 29
    .line 30
    :cond_0
    iget-object v0, v0, Lje2;->d:Lye2;

    .line 31
    .line 32
    invoke-static {v0}, Lix;->L(Lye2;)Lye2;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    if-eqz v0, :cond_c

    .line 37
    .line 38
    iget-object v3, v0, Lab4;->h:Lab4;

    .line 39
    .line 40
    iget-boolean v3, v3, Lab4;->u:Z

    .line 41
    .line 42
    if-nez v3, :cond_1

    .line 43
    .line 44
    const-string v3, "visitAncestors called on an unattached node"

    .line 45
    .line 46
    invoke-static {v3}, Lp73;->b(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    :cond_1
    iget-object v3, v0, Lab4;->h:Lab4;

    .line 50
    .line 51
    invoke-static {v0}, Lsx;->l0(Lap1;)Lzi3;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    :goto_0
    if-eqz v0, :cond_c

    .line 56
    .line 57
    iget-object v4, v0, Lzi3;->M:Lu9;

    .line 58
    .line 59
    iget-object v4, v4, Lu9;->g:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v4, Lab4;

    .line 62
    .line 63
    iget v4, v4, Lab4;->k:I

    .line 64
    .line 65
    const/high16 v5, 0x20000

    .line 66
    .line 67
    and-int/2addr v4, v5

    .line 68
    const/4 v6, 0x0

    .line 69
    if-eqz v4, :cond_a

    .line 70
    .line 71
    :goto_1
    if-eqz v3, :cond_a

    .line 72
    .line 73
    iget v4, v3, Lab4;->j:I

    .line 74
    .line 75
    and-int/2addr v4, v5

    .line 76
    if-eqz v4, :cond_9

    .line 77
    .line 78
    move-object v4, v3

    .line 79
    move-object v7, v6

    .line 80
    :cond_2
    :goto_2
    if-eqz v4, :cond_9

    .line 81
    .line 82
    iget v8, v4, Lab4;->j:I

    .line 83
    .line 84
    and-int/2addr v8, v5

    .line 85
    if-eqz v8, :cond_8

    .line 86
    .line 87
    instance-of v8, v4, Lcp1;

    .line 88
    .line 89
    if-eqz v8, :cond_8

    .line 90
    .line 91
    move-object v8, v4

    .line 92
    check-cast v8, Lcp1;

    .line 93
    .line 94
    iget-object v8, v8, Lcp1;->w:Lab4;

    .line 95
    .line 96
    move v9, v1

    .line 97
    :goto_3
    if-eqz v8, :cond_7

    .line 98
    .line 99
    iget v10, v8, Lab4;->j:I

    .line 100
    .line 101
    and-int/2addr v10, v5

    .line 102
    if-eqz v10, :cond_6

    .line 103
    .line 104
    add-int/lit8 v9, v9, 0x1

    .line 105
    .line 106
    if-ne v9, v2, :cond_3

    .line 107
    .line 108
    move-object v4, v8

    .line 109
    goto :goto_4

    .line 110
    :cond_3
    if-nez v7, :cond_4

    .line 111
    .line 112
    new-instance v7, Lve4;

    .line 113
    .line 114
    const/16 v10, 0x10

    .line 115
    .line 116
    new-array v10, v10, [Lab4;

    .line 117
    .line 118
    invoke-direct {v7, v1, v10}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    :cond_4
    if-eqz v4, :cond_5

    .line 122
    .line 123
    invoke-virtual {v7, v4}, Lve4;->b(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    move-object v4, v6

    .line 127
    :cond_5
    invoke-virtual {v7, v8}, Lve4;->b(Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :cond_6
    :goto_4
    iget-object v8, v8, Lab4;->m:Lab4;

    .line 131
    .line 132
    goto :goto_3

    .line 133
    :cond_7
    if-eq v9, v2, :cond_2

    .line 134
    .line 135
    :cond_8
    invoke-static {v7}, Lsx;->a0(Lve4;)Lab4;

    .line 136
    .line 137
    .line 138
    move-result-object v4

    .line 139
    goto :goto_2

    .line 140
    :cond_9
    iget-object v3, v3, Lab4;->l:Lab4;

    .line 141
    .line 142
    goto :goto_1

    .line 143
    :cond_a
    invoke-virtual {v0}, Lzi3;->u()Lzi3;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    if-eqz v0, :cond_b

    .line 148
    .line 149
    iget-object v3, v0, Lzi3;->M:Lu9;

    .line 150
    .line 151
    if-eqz v3, :cond_b

    .line 152
    .line 153
    iget-object v3, v3, Lu9;->f:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast v3, Lz87;

    .line 156
    .line 157
    goto :goto_0

    .line 158
    :cond_b
    move-object v3, v6

    .line 159
    goto :goto_0

    .line 160
    :cond_c
    :goto_5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEventPreIme(Landroid/view/KeyEvent;)Z

    .line 161
    .line 162
    .line 163
    move-result p0

    .line 164
    if-eqz p0, :cond_d

    .line 165
    .line 166
    return v2

    .line 167
    :cond_d
    return v1
.end method

.method public final dispatchProvideAutofillStructure(Landroid/view/ViewStructure;I)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lbb;->N0:Z

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->dispatchProvideAutofillStructure(Landroid/view/ViewStructure;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 6
    .line 7
    .line 8
    iput-boolean v0, p0, Lbb;->N0:Z

    .line 9
    .line 10
    invoke-virtual {p0, p1}, Lbb;->y(Landroid/view/ViewStructure;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :catchall_0
    move-exception p1

    .line 15
    iput-boolean v0, p0, Lbb;->N0:Z

    .line 16
    .line 17
    throw p1
.end method

.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 10

    .line 1
    iget-boolean v0, p0, Lbb;->G0:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    iget-object v0, p0, Lbb;->F0:Lpa;

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 9
    .line 10
    .line 11
    iget-object v2, p0, Lbb;->w0:Landroid/view/MotionEvent;

    .line 12
    .line 13
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-nez v3, :cond_0

    .line 21
    .line 22
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getSource()I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-ne v3, v4, :cond_0

    .line 31
    .line 32
    invoke-virtual {v2, v1}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    if-ne v2, v3, :cond_0

    .line 41
    .line 42
    iput-boolean v1, p0, Lbb;->G0:Z

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    invoke-virtual {v0}, Lpa;->run()V

    .line 46
    .line 47
    .line 48
    :cond_1
    :goto_0
    invoke-static {p1}, Lbb;->m(Landroid/view/MotionEvent;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_a

    .line 53
    .line 54
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_a

    .line 59
    .line 60
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    const/4 v2, 0x2

    .line 65
    if-ne v0, v2, :cond_2

    .line 66
    .line 67
    invoke-virtual {p0, p1}, Lbb;->o(Landroid/view/MotionEvent;)Z

    .line 68
    .line 69
    .line 70
    :cond_2
    invoke-virtual {p0, p1}, Lbb;->i(Landroid/view/MotionEvent;)I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    and-int/lit8 v2, v0, 0x2

    .line 75
    .line 76
    const/4 v3, 0x1

    .line 77
    if-eqz v2, :cond_3

    .line 78
    .line 79
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    invoke-interface {v2, v3}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 84
    .line 85
    .line 86
    :cond_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    if-eqz v2, :cond_4

    .line 91
    .line 92
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    const/4 v4, 0x5

    .line 97
    if-eq v2, v4, :cond_4

    .line 98
    .line 99
    move v2, v1

    .line 100
    goto :goto_1

    .line 101
    :cond_4
    move v2, v3

    .line 102
    :goto_1
    const/16 v4, 0x2002

    .line 103
    .line 104
    invoke-virtual {p1, v4}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    if-nez v4, :cond_5

    .line 109
    .line 110
    const v4, 0x100008

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1, v4}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 114
    .line 115
    .line 116
    move-result v4

    .line 117
    if-nez v4, :cond_5

    .line 118
    .line 119
    move v4, v1

    .line 120
    goto :goto_2

    .line 121
    :cond_5
    move v4, v3

    .line 122
    :goto_2
    if-eqz v2, :cond_9

    .line 123
    .line 124
    if-eqz v4, :cond_9

    .line 125
    .line 126
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    instance-of v4, v2, Landroid/view/View;

    .line 131
    .line 132
    if-eqz v4, :cond_6

    .line 133
    .line 134
    check-cast v2, Landroid/view/View;

    .line 135
    .line 136
    goto :goto_3

    .line 137
    :cond_6
    const/4 v2, 0x0

    .line 138
    :goto_3
    if-eqz v2, :cond_7

    .line 139
    .line 140
    const v4, 0x7f090044

    .line 141
    .line 142
    .line 143
    invoke-virtual {v2, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    if-nez v2, :cond_8

    .line 148
    .line 149
    :cond_7
    new-instance v2, Lvy;

    .line 150
    .line 151
    invoke-direct {v2, v3}, Lvy;-><init>(I)V

    .line 152
    .line 153
    .line 154
    :cond_8
    new-instance v4, Lvy;

    .line 155
    .line 156
    invoke-direct {v4, v3}, Lvy;-><init>(I)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v2, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v2

    .line 163
    if-eqz v2, :cond_9

    .line 164
    .line 165
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 166
    .line 167
    .line 168
    move-result-object v2

    .line 169
    check-cast v2, Lje2;

    .line 170
    .line 171
    invoke-virtual {v2}, Lje2;->h()Lye2;

    .line 172
    .line 173
    .line 174
    move-result-object v2

    .line 175
    if-eqz v2, :cond_9

    .line 176
    .line 177
    invoke-static {v2}, Lsx;->k0(Lap1;)Lbt4;

    .line 178
    .line 179
    .line 180
    move-result-object v2

    .line 181
    invoke-static {v2}, Lnx;->F(Lhi3;)Lhi3;

    .line 182
    .line 183
    .line 184
    move-result-object v4

    .line 185
    invoke-interface {v4, v2, v3}, Lhi3;->H(Lhi3;Z)Lyv5;

    .line 186
    .line 187
    .line 188
    move-result-object v2

    .line 189
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 190
    .line 191
    .line 192
    move-result v4

    .line 193
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 194
    .line 195
    .line 196
    move-result p1

    .line 197
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 198
    .line 199
    .line 200
    move-result v4

    .line 201
    int-to-long v4, v4

    .line 202
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 203
    .line 204
    .line 205
    move-result p1

    .line 206
    int-to-long v6, p1

    .line 207
    const/16 p1, 0x20

    .line 208
    .line 209
    shl-long/2addr v4, p1

    .line 210
    const-wide v8, 0xffffffffL

    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    and-long/2addr v6, v8

    .line 216
    or-long/2addr v4, v6

    .line 217
    invoke-virtual {v2, v4, v5}, Lyv5;->a(J)Z

    .line 218
    .line 219
    .line 220
    move-result p1

    .line 221
    if-nez p1, :cond_9

    .line 222
    .line 223
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 224
    .line 225
    .line 226
    move-result-object p0

    .line 227
    invoke-static {p0}, Lge2;->a(Lge2;)V

    .line 228
    .line 229
    .line 230
    :cond_9
    and-int/2addr v0, v3

    .line 231
    if-eqz v0, :cond_a

    .line 232
    .line 233
    return v3

    .line 234
    :cond_a
    return v1
.end method

.method public final findViewByAccessibilityIdTraversal(I)Landroid/view/View;
    .locals 3

    .line 1
    :try_start_0
    sget-object v0, Lbb;->W0:Ljava/lang/reflect/Method;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const-class v0, Landroid/view/View;

    .line 6
    .line 7
    const-string v1, "findViewByAccessibilityIdTraversal"

    .line 8
    .line 9
    sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 10
    .line 11
    filled-new-array {v2}, [Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, Lbb;->W0:Ljava/lang/reflect/Method;

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 23
    .line 24
    .line 25
    :cond_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {v0, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    instance-of p1, p0, Landroid/view/View;

    .line 38
    .line 39
    if-eqz p1, :cond_1

    .line 40
    .line 41
    check-cast p0, Landroid/view/View;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    .line 43
    return-object p0

    .line 44
    :catch_0
    :cond_1
    const/4 p0, 0x0

    .line 45
    return-object p0
.end method

.method public final focusSearch(Landroid/view/View;I)Landroid/view/View;
    .locals 7

    .line 1
    if-eqz p1, :cond_a

    .line 2
    .line 3
    iget-object v0, p0, Lbb;->c0:Lk92;

    .line 4
    .line 5
    iget-boolean v0, v0, Lk92;->b:Z

    .line 6
    .line 7
    if-nez v0, :cond_a

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    check-cast v0, Landroid/view/ViewGroup;

    .line 17
    .line 18
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v1, v0, p1, p2}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    const/4 v1, 0x0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-static {p0, v0}, Lkb;->F(Landroid/view/View;Landroid/view/View;)Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-nez v2, :cond_1

    .line 34
    .line 35
    :cond_0
    move-object v0, v1

    .line 36
    :cond_1
    if-ne p1, p0, :cond_3

    .line 37
    .line 38
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    check-cast v2, Lje2;

    .line 43
    .line 44
    iget-object v2, v2, Lje2;->d:Lye2;

    .line 45
    .line 46
    invoke-static {v2}, Lix;->L(Lye2;)Lye2;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    if-eqz v2, :cond_2

    .line 51
    .line 52
    invoke-static {v2}, Lix;->M(Lye2;)Lyv5;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    :cond_2
    if-nez v1, :cond_4

    .line 57
    .line 58
    invoke-static {p1, p0}, Lde2;->a(Landroid/view/View;Landroid/view/View;)Lyv5;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    goto :goto_0

    .line 63
    :cond_3
    invoke-static {p1, p0}, Lde2;->a(Landroid/view/View;Landroid/view/View;)Lyv5;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    :cond_4
    :goto_0
    invoke-static {p2}, Lde2;->d(I)Ltd2;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    if-eqz v2, :cond_5

    .line 72
    .line 73
    iget-byte v2, v2, Ltd2;->a:B

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_5
    const/4 v2, 0x6

    .line 77
    :goto_1
    new-instance v3, Lgw5;

    .line 78
    .line 79
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    new-instance v5, Lka;

    .line 87
    .line 88
    const/4 v6, 0x0

    .line 89
    invoke-direct {v5, v3, v6}, Lka;-><init>(Lgw5;B)V

    .line 90
    .line 91
    .line 92
    check-cast v4, Lje2;

    .line 93
    .line 94
    invoke-virtual {v4, v2, v1, v5}, Lje2;->g(ILyv5;Lwh2;)Ljava/lang/Boolean;

    .line 95
    .line 96
    .line 97
    move-result-object v4

    .line 98
    if-nez v4, :cond_6

    .line 99
    .line 100
    return-object p1

    .line 101
    :cond_6
    iget-object v3, v3, Lgw5;->h:Ljava/lang/Object;

    .line 102
    .line 103
    if-nez v3, :cond_7

    .line 104
    .line 105
    if-nez v0, :cond_9

    .line 106
    .line 107
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->focusSearch(Landroid/view/View;I)Landroid/view/View;

    .line 108
    .line 109
    .line 110
    move-result-object p0

    .line 111
    return-object p0

    .line 112
    :cond_7
    if-eqz v0, :cond_8

    .line 113
    .line 114
    const/4 p1, 0x1

    .line 115
    if-eq v2, p1, :cond_8

    .line 116
    .line 117
    const/4 p1, 0x2

    .line 118
    if-eq v2, p1, :cond_8

    .line 119
    .line 120
    check-cast v3, Lye2;

    .line 121
    .line 122
    invoke-static {v3}, Lix;->M(Lye2;)Lyv5;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    invoke-static {v0, p0}, Lde2;->a(Landroid/view/View;Landroid/view/View;)Lyv5;

    .line 127
    .line 128
    .line 129
    move-result-object p2

    .line 130
    invoke-static {p1, p2, v1, v2}, Lva7;->p(Lyv5;Lyv5;Lyv5;I)Z

    .line 131
    .line 132
    .line 133
    move-result p1

    .line 134
    if-eqz p1, :cond_9

    .line 135
    .line 136
    :cond_8
    return-object p0

    .line 137
    :cond_9
    return-object v0

    .line 138
    :cond_a
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->focusSearch(Landroid/view/View;I)Landroid/view/View;

    .line 139
    .line 140
    .line 141
    move-result-object p0

    .line 142
    return-object p0
.end method

.method public final g(Lzi3;Z)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lk92;->g(Lzi3;Z)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public getAccessibilityManager()Ld5;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->l:Lzy7;

    .line 4
    .line 5
    return-object p0
.end method

.method public final getAndroidViewsHandler$androidx_compose_ui_ui()Llg;
    .locals 2

    .line 1
    iget-object v0, p0, Lbb;->W:Llg;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Llg;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Llg;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    const/4 v1, -0x1

    .line 15
    invoke-virtual {p0, v0, v1}, Lbb;->addView(Landroid/view/View;I)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, Lbb;->W:Llg;

    .line 22
    .line 23
    :cond_0
    return-object v0
.end method

.method public getAutofill()Lca;
    .locals 0

    .line 6
    iget-object p0, p0, Lbb;->R:Lca;

    return-object p0
.end method

.method public bridge synthetic getAutofill()Lyy;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lbb;->getAutofill()Lca;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge synthetic getAutofillManager()Lbz;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lbb;->getAutofillManager()Lda;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public getAutofillManager()Lda;
    .locals 0

    .line 6
    iget-object p0, p0, Lbb;->S:Lda;

    return-object p0
.end method

.method public getAutofillTree()Lcz;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->I:Lcz;

    .line 2
    .line 3
    return-object p0
.end method

.method public getClipboard()Lnu0;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->r:Lha;

    .line 4
    .line 5
    return-object p0
.end method

.method public getClipboardManager()Lou0;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->q:Lar;

    .line 4
    .line 5
    return-object p0
.end method

.method public final getComposeViewContext()Lw41;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getComposeViewContextIncrementedDuringInit$androidx_compose_ui_ui()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lbb;->M0:Z

    .line 2
    .line 3
    return p0
.end method

.method public final getConfiguration()Landroid/content/res/Configuration;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->P:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz75;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Landroid/content/res/Configuration;

    .line 8
    .line 9
    return-object p0
.end method

.method public final getContentCaptureManager$androidx_compose_ui_ui()Lrb;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->G:Lrb;

    .line 2
    .line 3
    return-object p0
.end method

.method public getCoroutineContext()Laj1;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->v:Laj1;

    .line 2
    .line 3
    return-object p0
.end method

.method public getDensity()Lkp1;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->s:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz75;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lkp1;

    .line 8
    .line 9
    return-object p0
.end method

.method public getDragAndDropManager()Lhc;
    .locals 0

    .line 6
    iget-object p0, p0, Lbb;->w:Lhc;

    return-object p0
.end method

.method public bridge synthetic getDragAndDropManager()Lyt1;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lbb;->getDragAndDropManager()Lhc;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public getEmbeddedViewFocusRect()Lyv5;
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Lje2;

    .line 13
    .line 14
    iget-object p0, p0, Lje2;->d:Lye2;

    .line 15
    .line 16
    invoke-static {p0}, Lix;->L(Lye2;)Lye2;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    if-eqz p0, :cond_0

    .line 21
    .line 22
    invoke-static {p0}, Lix;->M(Lye2;)Lyv5;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0

    .line 27
    :cond_0
    return-object v1

    .line 28
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    invoke-static {v0, p0}, Lde2;->a(Landroid/view/View;Landroid/view/View;)Lyv5;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    return-object p0

    .line 39
    :cond_2
    return-object v1
.end method

.method public getFocusOwner()Lge2;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->u:Lje2;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getFocusedRect(Landroid/graphics/Rect;)V
    .locals 4

    .line 1
    invoke-virtual {p0}, Lbb;->getEmbeddedViewFocusRect()Lyv5;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget p0, v0, Lyv5;->a:F

    .line 8
    .line 9
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    iput p0, p1, Landroid/graphics/Rect;->left:I

    .line 14
    .line 15
    iget p0, v0, Lyv5;->b:F

    .line 16
    .line 17
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    iput p0, p1, Landroid/graphics/Rect;->top:I

    .line 22
    .line 23
    iget p0, v0, Lyv5;->c:F

    .line 24
    .line 25
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    iput p0, p1, Landroid/graphics/Rect;->right:I

    .line 30
    .line 31
    iget p0, v0, Lyv5;->d:F

    .line 32
    .line 33
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 34
    .line 35
    .line 36
    move-result p0

    .line 37
    iput p0, p1, Landroid/graphics/Rect;->bottom:I

    .line 38
    .line 39
    return-void

    .line 40
    :cond_0
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    new-instance v1, Ll;

    .line 45
    .line 46
    const/16 v2, 0xd

    .line 47
    .line 48
    invoke-direct {v1, v2}, Ll;-><init>(B)V

    .line 49
    .line 50
    .line 51
    check-cast v0, Lje2;

    .line 52
    .line 53
    const/4 v2, 0x6

    .line 54
    const/4 v3, 0x0

    .line 55
    invoke-virtual {v0, v2, v3, v1}, Lje2;->g(ILyv5;Lwh2;)Ljava/lang/Boolean;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 60
    .line 61
    invoke-static {v0, v1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-nez v0, :cond_1

    .line 66
    .line 67
    const/high16 p0, -0x80000000

    .line 68
    .line 69
    invoke-virtual {p1, p0, p0, p0, p0}, Landroid/graphics/Rect;->set(IIII)V

    .line 70
    .line 71
    .line 72
    return-void

    .line 73
    :cond_1
    invoke-super {p0, p1}, Landroid/view/View;->getFocusedRect(Landroid/graphics/Rect;)V

    .line 74
    .line 75
    .line 76
    return-void
.end method

.method public getFontFamilyResolver()Lff2;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->r0:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz75;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lff2;

    .line 8
    .line 9
    return-object p0
.end method

.method public getFontLoader()Lef2;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->s:Ls38;

    .line 4
    .line 5
    return-object p0
.end method

.method public final getFrameEndScheduler$androidx_compose_ui_ui()Lyo3;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->l:Lyo3;

    .line 2
    .line 3
    return-object p0
.end method

.method public getGraphicsContext()Lpq2;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->H:Ltc;

    .line 2
    .line 3
    return-object p0
.end method

.method public getGraphicsResourceCache()Lxq2;
    .locals 1

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object v0, p0, Lw41;->i:Lxq2;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Lxq2;

    .line 8
    .line 9
    invoke-direct {v0}, Lxq2;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lw41;->i:Lxq2;

    .line 13
    .line 14
    :cond_0
    return-object v0
.end method

.method public getHapticFeedBack()Lbs2;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->u:Lnb5;

    .line 4
    .line 5
    return-object p0
.end method

.method public getHasPendingMeasureOrLayout()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    iget-object v0, v0, Lk92;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lzi7;

    .line 6
    .line 7
    invoke-virtual {v0}, Lzi7;->V()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iget-object p0, p0, Lbb;->p:Lrw;

    .line 14
    .line 15
    invoke-virtual {p0}, Lrw;->isEmpty()Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    if-eqz p0, :cond_0

    .line 20
    .line 21
    const/4 p0, 0x0

    .line 22
    return p0

    .line 23
    :cond_0
    const/4 p0, 0x1

    .line 24
    return p0
.end method

.method public final getHostDefaultProvider()Lsy7;
    .locals 1

    .line 1
    iget-object v0, p0, Lbb;->r:Lsy7;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lsy7;

    .line 6
    .line 7
    invoke-direct {v0, p0}, Lsy7;-><init>(Lbb;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lbb;->r:Lsy7;

    .line 11
    .line 12
    :cond_0
    return-object v0
.end method

.method public getImportantForAutofill()I
    .locals 0

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public bridge synthetic getInputModeManager()Lf83;
    .locals 0

    .line 22
    invoke-virtual {p0}, Lbb;->getInputModeManager()Lg83;

    move-result-object p0

    return-object p0
.end method

.method public getInputModeManager()Lg83;
    .locals 2

    .line 1
    iget-object v0, p0, Lbb;->t0:Lg83;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    new-instance v0, Lg83;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->isInTouchMode()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    const/4 v1, 0x1

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v1, 0x2

    .line 16
    :goto_0
    invoke-direct {v0, v1}, Lg83;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, Lbb;->t0:Lg83;

    .line 20
    .line 21
    :cond_1
    return-object v0
.end method

.method public final getInsetsListener()Lp83;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final getInsetsWatcher()Lm38;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->A:Lm38;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getLastMatrixRecalculationAnimationTime$androidx_compose_ui_ui()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lbb;->j0:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getLayoutDirection()Lii3;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->s0:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz75;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lii3;

    .line 8
    .line 9
    return-object p0
.end method

.method public bridge synthetic getLayoutNodes()Ln93;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lbb;->getLayoutNodes()Lrd4;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public getLayoutNodes()Lrd4;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lrd4;"
        }
    .end annotation

    .line 6
    iget-object p0, p0, Lbb;->C:Lrd4;

    return-object p0
.end method

.method public getLocaleList()Lfu3;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->Q:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz75;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lfu3;

    .line 8
    .line 9
    return-object p0
.end method

.method public getMeasureIteration()J
    .locals 2

    .line 1
    iget-object p0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    iget-boolean p0, p0, Lk92;->b:Z

    .line 4
    .line 5
    if-nez p0, :cond_0

    .line 6
    .line 7
    const-string p0, "measureIteration should be only used during the measure/layout pass"

    .line 8
    .line 9
    invoke-static {p0}, Lp73;->a(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    const-wide/16 v0, 0x1

    .line 13
    .line 14
    return-wide v0
.end method

.method public getModifierLocalManager()Lgb4;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->u0:Lgb4;

    .line 2
    .line 3
    return-object p0
.end method

.method public getOutOfFrameExecutor()Lbb;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_0
    const/4 p0, 0x0

    .line 9
    return-object p0
.end method

.method public bridge synthetic getOutOfFrameExecutor()Ly05;
    .locals 0

    .line 10
    invoke-virtual {p0}, Lbb;->getOutOfFrameExecutor()Lbb;

    move-result-object p0

    return-object p0
.end method

.method public getPlacementScope()Leb5;
    .locals 2

    .line 1
    new-instance v0, Ldx3;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, p0, v1}, Ldx3;-><init>(Ljava/lang/Object;B)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final getPlayNavigationSoundEffect$androidx_compose_ui_ui()Lai2;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lai2;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lbb;->H0:Lai2;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lqa;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {v0, p0, v1}, Lqa;-><init>(Ljava/lang/Object;B)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lbb;->H0:Lai2;

    .line 12
    .line 13
    :cond_0
    return-object v0
.end method

.method public getPointerIconService()Lrc5;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->Q0:Lxa;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getPrimaryDirectionalMotionAxisOverride-dqNNBbU$androidx_compose_ui_ui()Lj63;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->k:Lj63;

    .line 2
    .line 3
    return-object p0
.end method

.method public getRectManager()Lzv5;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->D:Lzv5;

    .line 2
    .line 3
    return-object p0
.end method

.method public getRetainedValuesStore()Lzz5;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->o:Lzz5;

    .line 2
    .line 3
    return-object p0
.end method

.method public getRoot()Lzi3;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->B:Lzi3;

    .line 2
    .line 3
    return-object p0
.end method

.method public getRootForTest()Lk16;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final getSavedStateRegistry()Lms1;
    .locals 7

    .line 1
    iget-object v0, p0, Lbb;->n:Lms1;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    iget-object v0, p0, Lbb;->h:Lw41;

    .line 6
    .line 7
    invoke-virtual {v0}, Lw41;->g()V

    .line 8
    .line 9
    .line 10
    iget-object v0, v0, Lw41;->e:Lce6;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    check-cast v1, Landroid/view/View;

    .line 23
    .line 24
    const v2, 0x7f090057

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1, v2}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    instance-of v3, v2, Ljava/lang/String;

    .line 32
    .line 33
    const/4 v4, 0x0

    .line 34
    if-eqz v3, :cond_0

    .line 35
    .line 36
    check-cast v2, Ljava/lang/String;

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    move-object v2, v4

    .line 40
    :goto_0
    if-nez v2, :cond_1

    .line 41
    .line 42
    invoke-virtual {v1}, Landroid/view/View;->getId()I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    :cond_1
    const-string v1, "SaveableStateRegistry:"

    .line 51
    .line 52
    invoke-static {v1, v2}, Ldw4;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    invoke-interface {v0}, Lce6;->c()Leq2;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-virtual {v0, v1}, Leq2;->F(Ljava/lang/String;)Landroid/os/Bundle;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    if-eqz v2, :cond_3

    .line 65
    .line 66
    const-class v3, Lu75;

    .line 67
    .line 68
    invoke-static {v3}, Lhw5;->a(Ljava/lang/Class;)Lnt0;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    invoke-static {v3}, Lgu;->H(Lnt0;)Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    const-string v5, "androidx.compose.ui.platform.DisposableSaveableStateRegistry"

    .line 77
    .line 78
    invoke-static {v2, v5, v3}, Lhw;->N(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    check-cast v2, Landroid/os/Parcelable;

    .line 83
    .line 84
    check-cast v2, Lu75;

    .line 85
    .line 86
    if-eqz v2, :cond_2

    .line 87
    .line 88
    iget-object v4, v2, Lu75;->h:Ljava/util/Map;

    .line 89
    .line 90
    :cond_2
    if-nez v4, :cond_3

    .line 91
    .line 92
    sget-object v2, Lp22;->h:Lp22;

    .line 93
    .line 94
    move-object v4, v2

    .line 95
    :cond_3
    new-instance v2, Lof1;

    .line 96
    .line 97
    const/16 v3, 0x8

    .line 98
    .line 99
    invoke-direct {v2, v3}, Lof1;-><init>(B)V

    .line 100
    .line 101
    .line 102
    sget-object v3, Lpd6;->a:Lux1;

    .line 103
    .line 104
    new-instance v3, Lod6;

    .line 105
    .line 106
    invoke-direct {v3, v4, v2}, Lod6;-><init>(Ljava/util/Map;Lwh2;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0, v1}, Leq2;->R(Ljava/lang/String;)Lae6;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    const/4 v4, 0x0

    .line 114
    if-nez v2, :cond_4

    .line 115
    .line 116
    :try_start_0
    new-instance v2, Lns1;

    .line 117
    .line 118
    invoke-direct {v2, v3, v4}, Lns1;-><init>(Ljava/lang/Object;B)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v0, v1, v2}, Leq2;->d0(Ljava/lang/String;Lae6;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 122
    .line 123
    .line 124
    const/4 v4, 0x1

    .line 125
    :catch_0
    :cond_4
    new-instance v2, Lms1;

    .line 126
    .line 127
    new-instance v5, Lp90;

    .line 128
    .line 129
    const/4 v6, 0x3

    .line 130
    invoke-direct {v5, v4, v0, v1, v6}, Lp90;-><init>(ZLjava/lang/Object;Ljava/lang/Object;B)V

    .line 131
    .line 132
    .line 133
    invoke-direct {v2, v3, v5}, Lms1;-><init>(Lod6;Lp90;)V

    .line 134
    .line 135
    .line 136
    iput-object v2, p0, Lbb;->n:Lms1;

    .line 137
    .line 138
    return-object v2

    .line 139
    :cond_5
    return-object v0
.end method

.method public final getScrollCaptureInProgress()Z
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1f

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lbb;->O0:Lmg6;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, v0, Lmg6;->a:Lz75;

    .line 12
    .line 13
    invoke-virtual {v0}, Lz75;->getValue()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Ljava/lang/Boolean;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/4 v1, 0x1

    .line 24
    if-ne v0, v1, :cond_0

    .line 25
    .line 26
    return v1

    .line 27
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    :goto_0
    if-eqz p0, :cond_2

    .line 32
    .line 33
    instance-of v0, p0, Lbb;

    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    check-cast p0, Lbb;

    .line 38
    .line 39
    invoke-virtual {p0}, Lbb;->getScrollCaptureInProgress()Z

    .line 40
    .line 41
    .line 42
    move-result p0

    .line 43
    return p0

    .line 44
    :cond_1
    invoke-interface {p0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    goto :goto_0

    .line 49
    :cond_2
    const/4 p0, 0x0

    .line 50
    return p0
.end method

.method public getSemanticsOwner()Lgl6;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->E:Lgl6;

    .line 2
    .line 3
    return-object p0
.end method

.method public getSharedDrawScope()Lbj3;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->w:Lbj3;

    .line 4
    .line 5
    return-object p0
.end method

.method public getShowLayoutBounds()Z
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1e

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    invoke-static {p0}, Ltj;->a(Landroid/view/View;)Z

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_0
    iget-boolean p0, p0, Lbb;->V:Z

    .line 13
    .line 14
    return p0
.end method

.method public getSnapshotObserver()Li45;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->U:Li45;

    .line 2
    .line 3
    return-object p0
.end method

.method public getSoftwareKeyboardController()Lxw6;
    .locals 2

    .line 1
    iget-object v0, p0, Lbb;->q0:Ldp1;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Ldp1;

    .line 6
    .line 7
    invoke-virtual {p0}, Lbb;->getTextInputService()Ljf7;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Ldp1;-><init>(Ljf7;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lbb;->q0:Ldp1;

    .line 15
    .line 16
    :cond_0
    return-object v0
.end method

.method public getSoundEffect()Lfx6;
    .locals 2

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object v0, p0, Lw41;->E:Lqe;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Lqe;

    .line 8
    .line 9
    iget-object v1, p0, Lw41;->a:Landroid/view/View;

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lqe;-><init>(Landroid/view/View;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lw41;->E:Lqe;

    .line 15
    .line 16
    :cond_0
    return-object v0
.end method

.method public getTaskDispatchers()Lm97;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->x:Ly6;

    .line 2
    .line 3
    return-object p0
.end method

.method public getTextInputService()Ljf7;
    .locals 2

    .line 1
    iget-object v0, p0, Lbb;->o0:Ljf7;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Ljf7;

    .line 6
    .line 7
    invoke-direct {p0}, Lbb;->getLegacyTextInputServiceAndroid()Llf7;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Ljf7;-><init>(Llf7;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lbb;->o0:Ljf7;

    .line 15
    .line 16
    :cond_0
    return-object v0
.end method

.method public getTextToolbar()Lfi7;
    .locals 4

    .line 1
    iget-object v0, p0, Lbb;->v0:Lnf;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lnf;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance v1, Lwd6;

    .line 11
    .line 12
    new-instance v2, Ln7;

    .line 13
    .line 14
    const/4 v3, 0x4

    .line 15
    invoke-direct {v2, v0, v3}, Ln7;-><init>(Ljava/lang/Object;B)V

    .line 16
    .line 17
    .line 18
    const/16 v3, 0x14

    .line 19
    .line 20
    invoke-direct {v1, v2, v3}, Lwd6;-><init>(Ljava/lang/Object;B)V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Lbb;->v0:Lnf;

    .line 24
    .line 25
    :cond_0
    return-object v0
.end method

.method public bridge synthetic getUiMediaScope()Los7;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lbb;->getUiMediaScope()Lps7;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public getUiMediaScope()Lps7;
    .locals 0

    .line 6
    const/4 p0, 0x0

    return-object p0
.end method

.method public final getUncaughtExceptionHandler$androidx_compose_ui_ui()Lj16;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public getUriHandler()Lnu7;
    .locals 2

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object v0, p0, Lw41;->p:Luf;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Luf;

    .line 8
    .line 9
    iget-object v1, p0, Lw41;->a:Landroid/view/View;

    .line 10
    .line 11
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-direct {v0, v1}, Luf;-><init>(Landroid/content/Context;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lw41;->p:Luf;

    .line 19
    .line 20
    :cond_0
    return-object v0
.end method

.method public getView()Landroid/view/View;
    .locals 0

    .line 1
    return-object p0
.end method

.method public getViewConfiguration()Lqx7;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->v:Lxf;

    .line 4
    .line 5
    return-object p0
.end method

.method public final getWindow$androidx_compose_ui_ui()Landroid/view/Window;
    .locals 3

    .line 1
    sget-object v0, Llb;->a:La61;

    .line 2
    .line 3
    move-object v0, p0

    .line 4
    :goto_0
    const/4 v1, 0x0

    .line 5
    if-eqz v0, :cond_3

    .line 6
    .line 7
    instance-of v2, v0, Lzq1;

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    check-cast v0, Lzq1;

    .line 12
    .line 13
    invoke-interface {v0}, Lzq1;->a()Landroid/view/Window;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    goto :goto_1

    .line 18
    :cond_0
    instance-of v2, v0, Lpe5;

    .line 19
    .line 20
    if-eqz v2, :cond_1

    .line 21
    .line 22
    check-cast v0, Lpe5;

    .line 23
    .line 24
    invoke-virtual {v0}, Lpe5;->getComposeView$androidx_compose_ui_ui()Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    instance-of v2, v0, Landroid/view/View;

    .line 34
    .line 35
    if-eqz v2, :cond_2

    .line 36
    .line 37
    check-cast v0, Landroid/view/View;

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_2
    move-object v0, v1

    .line 41
    goto :goto_0

    .line 42
    :cond_3
    move-object v0, v1

    .line 43
    :goto_1
    if-nez v0, :cond_6

    .line 44
    .line 45
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    :goto_2
    instance-of v0, p0, Landroid/content/ContextWrapper;

    .line 50
    .line 51
    if-eqz v0, :cond_5

    .line 52
    .line 53
    instance-of v0, p0, Landroid/app/Activity;

    .line 54
    .line 55
    if-eqz v0, :cond_4

    .line 56
    .line 57
    check-cast p0, Landroid/app/Activity;

    .line 58
    .line 59
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    return-object p0

    .line 64
    :cond_4
    check-cast p0, Landroid/content/ContextWrapper;

    .line 65
    .line 66
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    goto :goto_2

    .line 71
    :cond_5
    return-object v1

    .line 72
    :cond_6
    return-object v0
.end method

.method public getWindowInfo()Lw18;
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    iget-object p0, p0, Lw41;->x:Lrn3;

    .line 4
    .line 5
    return-object p0
.end method

.method public final get_uiMediaScope$androidx_compose_ui_ui()Lps7;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final i(Landroid/view/MotionEvent;)I
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget-object v2, v1, Lbb;->E0:Lya;

    .line 6
    .line 7
    invoke-virtual {v1, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 8
    .line 9
    .line 10
    const/4 v7, 0x0

    .line 11
    :try_start_0
    invoke-virtual/range {p0 .. p1}, Lbb;->A(Landroid/view/MotionEvent;)V

    .line 12
    .line 13
    .line 14
    const/4 v8, 0x1

    .line 15
    iput-boolean v8, v1, Lbb;->k0:Z

    .line 16
    .line 17
    invoke-virtual {v1, v7}, Lbb;->q(Z)V

    .line 18
    .line 19
    .line 20
    const-string v2, "AndroidOwner:onTouch"

    .line 21
    .line 22
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 23
    .line 24
    .line 25
    :try_start_1
    invoke-virtual {v0}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 26
    .line 27
    .line 28
    move-result v9

    .line 29
    iget-object v2, v1, Lbb;->w0:Landroid/view/MotionEvent;

    .line 30
    .line 31
    const/4 v10, 0x3

    .line 32
    if-eqz v2, :cond_0

    .line 33
    .line 34
    invoke-virtual {v2, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 35
    .line 36
    .line 37
    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 38
    if-ne v3, v10, :cond_0

    .line 39
    .line 40
    move v11, v8

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    move v11, v7

    .line 43
    :goto_0
    const/16 v12, 0xa

    .line 44
    .line 45
    iget-object v13, v1, Lbb;->O:Lse;

    .line 46
    .line 47
    if-eqz v2, :cond_3

    .line 48
    .line 49
    :try_start_2
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getSource()I

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    invoke-virtual {v0}, Landroid/view/MotionEvent;->getSource()I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    if-ne v3, v4, :cond_1

    .line 58
    .line 59
    invoke-virtual {v2, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    invoke-virtual {v0, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 64
    .line 65
    .line 66
    move-result v4

    .line 67
    if-ne v3, v4, :cond_1

    .line 68
    .line 69
    move v3, v7

    .line 70
    goto :goto_1

    .line 71
    :cond_1
    move v3, v8

    .line 72
    :goto_1
    if-eqz v3, :cond_3

    .line 73
    .line 74
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getButtonState()I

    .line 75
    .line 76
    .line 77
    move-result v3

    .line 78
    if-nez v3, :cond_2

    .line 79
    .line 80
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    if-eqz v3, :cond_2

    .line 85
    .line 86
    const/4 v4, 0x2

    .line 87
    if-eq v3, v4, :cond_2

    .line 88
    .line 89
    const/4 v4, 0x6

    .line 90
    if-eq v3, v4, :cond_2

    .line 91
    .line 92
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 93
    .line 94
    .line 95
    move-result v3

    .line 96
    if-eq v3, v12, :cond_3

    .line 97
    .line 98
    if-eqz v11, :cond_3

    .line 99
    .line 100
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getEventTime()J

    .line 101
    .line 102
    .line 103
    move-result-wide v4

    .line 104
    const/4 v6, 0x1

    .line 105
    const/16 v3, 0xa

    .line 106
    .line 107
    invoke-virtual/range {v1 .. v6}, Lbb;->G(Landroid/view/MotionEvent;IJZ)V

    .line 108
    .line 109
    .line 110
    move-object v14, v2

    .line 111
    goto :goto_2

    .line 112
    :cond_2
    move-object v14, v2

    .line 113
    iget-boolean v2, v13, Lse;->a:Z

    .line 114
    .line 115
    if-nez v2, :cond_4

    .line 116
    .line 117
    iget-object v2, v13, Lse;->d:Ljava/lang/Object;

    .line 118
    .line 119
    check-cast v2, Lzy7;

    .line 120
    .line 121
    iget-object v2, v2, Lzy7;->i:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast v2, Lxw3;

    .line 124
    .line 125
    invoke-virtual {v2}, Lxw3;->a()V

    .line 126
    .line 127
    .line 128
    iget-object v2, v13, Lse;->c:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast v2, Lws2;

    .line 131
    .line 132
    invoke-virtual {v2}, Lws2;->c()V

    .line 133
    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_3
    move-object v14, v2

    .line 137
    :cond_4
    :goto_2
    invoke-virtual {v0, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 138
    .line 139
    .line 140
    move-result v2

    .line 141
    if-ne v2, v10, :cond_5

    .line 142
    .line 143
    move v2, v8

    .line 144
    goto :goto_3

    .line 145
    :cond_5
    move v2, v7

    .line 146
    :goto_3
    const/16 v15, 0x9

    .line 147
    .line 148
    if-nez v11, :cond_6

    .line 149
    .line 150
    if-eqz v2, :cond_6

    .line 151
    .line 152
    if-eq v9, v10, :cond_6

    .line 153
    .line 154
    if-eq v9, v15, :cond_6

    .line 155
    .line 156
    sget-object v2, Lic5;->h:Lic5;

    .line 157
    .line 158
    invoke-virtual {v1, v0, v2}, Lbb;->n(Landroid/view/MotionEvent;Lic5;)Z

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    if-eqz v2, :cond_6

    .line 163
    .line 164
    invoke-virtual {v0}, Landroid/view/MotionEvent;->getEventTime()J

    .line 165
    .line 166
    .line 167
    move-result-wide v4

    .line 168
    const/4 v6, 0x1

    .line 169
    const/16 v3, 0x9

    .line 170
    .line 171
    move-object v2, v0

    .line 172
    invoke-virtual/range {v1 .. v6}, Lbb;->G(Landroid/view/MotionEvent;IJZ)V

    .line 173
    .line 174
    .line 175
    :cond_6
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getButtonState()I

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    if-eqz v0, :cond_7

    .line 180
    .line 181
    move v0, v8

    .line 182
    goto :goto_4

    .line 183
    :cond_7
    move v0, v7

    .line 184
    :goto_4
    const/16 v2, 0x8

    .line 185
    .line 186
    if-ne v9, v2, :cond_8

    .line 187
    .line 188
    if-nez v0, :cond_8

    .line 189
    .line 190
    if-eqz v14, :cond_8

    .line 191
    .line 192
    const/16 v0, 0x1002

    .line 193
    .line 194
    invoke-virtual {v14, v0}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 195
    .line 196
    .line 197
    move-result v0

    .line 198
    if-nez v0, :cond_8

    .line 199
    .line 200
    move v0, v8

    .line 201
    goto :goto_5

    .line 202
    :cond_8
    move v0, v7

    .line 203
    :goto_5
    iget-object v2, v1, Lbb;->w0:Landroid/view/MotionEvent;

    .line 204
    .line 205
    if-eqz v2, :cond_13

    .line 206
    .line 207
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getAction()I

    .line 208
    .line 209
    .line 210
    move-result v2

    .line 211
    if-ne v2, v12, :cond_13

    .line 212
    .line 213
    iget-object v2, v1, Lbb;->w0:Landroid/view/MotionEvent;

    .line 214
    .line 215
    if-eqz v2, :cond_9

    .line 216
    .line 217
    invoke-virtual {v2, v7}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 218
    .line 219
    .line 220
    move-result v2

    .line 221
    goto :goto_6

    .line 222
    :cond_9
    const/4 v2, -0x1

    .line 223
    :goto_6
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 224
    .line 225
    .line 226
    move-result v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 227
    iget-object v4, v1, Lbb;->N:Lrb4;

    .line 228
    .line 229
    if-ne v3, v15, :cond_a

    .line 230
    .line 231
    :try_start_3
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getHistorySize()I

    .line 232
    .line 233
    .line 234
    move-result v3

    .line 235
    if-nez v3, :cond_a

    .line 236
    .line 237
    if-ltz v2, :cond_13

    .line 238
    .line 239
    iget-object v3, v4, Lrb4;->c:Landroid/util/SparseBooleanArray;

    .line 240
    .line 241
    invoke-virtual {v3, v2}, Landroid/util/SparseBooleanArray;->delete(I)V

    .line 242
    .line 243
    .line 244
    iget-object v3, v4, Lrb4;->b:Landroid/util/SparseLongArray;

    .line 245
    .line 246
    invoke-virtual {v3, v2}, Landroid/util/SparseLongArray;->delete(I)V

    .line 247
    .line 248
    .line 249
    goto/16 :goto_b

    .line 250
    .line 251
    :cond_a
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 252
    .line 253
    .line 254
    move-result v3

    .line 255
    if-nez v3, :cond_13

    .line 256
    .line 257
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getHistorySize()I

    .line 258
    .line 259
    .line 260
    move-result v3

    .line 261
    if-nez v3, :cond_13

    .line 262
    .line 263
    iget-object v3, v1, Lbb;->w0:Landroid/view/MotionEvent;

    .line 264
    .line 265
    const/high16 v5, 0x7fc00000    # Float.NaN

    .line 266
    .line 267
    if-eqz v3, :cond_b

    .line 268
    .line 269
    invoke-virtual {v3}, Landroid/view/MotionEvent;->getX()F

    .line 270
    .line 271
    .line 272
    move-result v3

    .line 273
    goto :goto_7

    .line 274
    :cond_b
    move v3, v5

    .line 275
    :goto_7
    iget-object v6, v1, Lbb;->w0:Landroid/view/MotionEvent;

    .line 276
    .line 277
    if-eqz v6, :cond_c

    .line 278
    .line 279
    invoke-virtual {v6}, Landroid/view/MotionEvent;->getY()F

    .line 280
    .line 281
    .line 282
    move-result v5

    .line 283
    :cond_c
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 284
    .line 285
    .line 286
    move-result v6

    .line 287
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 288
    .line 289
    .line 290
    move-result v9

    .line 291
    cmpg-float v3, v3, v6

    .line 292
    .line 293
    if-nez v3, :cond_d

    .line 294
    .line 295
    cmpg-float v3, v5, v9

    .line 296
    .line 297
    if-nez v3, :cond_d

    .line 298
    .line 299
    move v3, v7

    .line 300
    goto :goto_8

    .line 301
    :cond_d
    move v3, v8

    .line 302
    :goto_8
    iget-object v5, v1, Lbb;->w0:Landroid/view/MotionEvent;

    .line 303
    .line 304
    if-eqz v5, :cond_e

    .line 305
    .line 306
    invoke-virtual {v5}, Landroid/view/MotionEvent;->getEventTime()J

    .line 307
    .line 308
    .line 309
    move-result-wide v5

    .line 310
    goto :goto_9

    .line 311
    :cond_e
    const-wide/16 v5, -0x1

    .line 312
    .line 313
    :goto_9
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 314
    .line 315
    .line 316
    move-result-wide v9

    .line 317
    cmp-long v5, v5, v9

    .line 318
    .line 319
    if-eqz v5, :cond_f

    .line 320
    .line 321
    move v5, v8

    .line 322
    goto :goto_a

    .line 323
    :cond_f
    move v5, v7

    .line 324
    :goto_a
    if-nez v3, :cond_10

    .line 325
    .line 326
    if-eqz v5, :cond_13

    .line 327
    .line 328
    :cond_10
    if-ltz v2, :cond_11

    .line 329
    .line 330
    iget-object v3, v4, Lrb4;->c:Landroid/util/SparseBooleanArray;

    .line 331
    .line 332
    invoke-virtual {v3, v2}, Landroid/util/SparseBooleanArray;->delete(I)V

    .line 333
    .line 334
    .line 335
    iget-object v3, v4, Lrb4;->b:Landroid/util/SparseLongArray;

    .line 336
    .line 337
    invoke-virtual {v3, v2}, Landroid/util/SparseLongArray;->delete(I)V

    .line 338
    .line 339
    .line 340
    :cond_11
    iget-object v2, v13, Lse;->c:Ljava/lang/Object;

    .line 341
    .line 342
    check-cast v2, Lws2;

    .line 343
    .line 344
    iget-boolean v3, v2, Lws2;->d:Z

    .line 345
    .line 346
    if-eqz v3, :cond_12

    .line 347
    .line 348
    iput-boolean v8, v2, Lws2;->d:Z

    .line 349
    .line 350
    goto :goto_b

    .line 351
    :cond_12
    iget-object v2, v2, Lws2;->g:Lht4;

    .line 352
    .line 353
    iget-object v2, v2, Lht4;->a:Lve4;

    .line 354
    .line 355
    invoke-virtual {v2}, Lve4;->g()V

    .line 356
    .line 357
    .line 358
    :cond_13
    :goto_b
    if-eqz v14, :cond_14

    .line 359
    .line 360
    invoke-virtual {v14}, Landroid/view/MotionEvent;->recycle()V

    .line 361
    .line 362
    .line 363
    :cond_14
    invoke-static/range {p1 .. p1}, Landroid/view/MotionEvent;->obtainNoHistory(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 364
    .line 365
    .line 366
    move-result-object v2

    .line 367
    iput-object v2, v1, Lbb;->w0:Landroid/view/MotionEvent;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 368
    .line 369
    if-eqz v0, :cond_15

    .line 370
    .line 371
    :try_start_4
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 372
    .line 373
    .line 374
    move-result-wide v4

    .line 375
    const/4 v6, 0x1

    .line 376
    const/16 v3, 0xa

    .line 377
    .line 378
    move-object/from16 v2, p1

    .line 379
    .line 380
    invoke-virtual/range {v1 .. v6}, Lbb;->G(Landroid/view/MotionEvent;IJZ)V

    .line 381
    .line 382
    .line 383
    :cond_15
    invoke-virtual/range {p0 .. p1}, Lbb;->F(Landroid/view/MotionEvent;)I

    .line 384
    .line 385
    .line 386
    move-result v9
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 387
    :try_start_5
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 388
    .line 389
    .line 390
    and-int/lit8 v1, v9, 0x4

    .line 391
    .line 392
    if-nez v1, :cond_17

    .line 393
    .line 394
    if-eqz v0, :cond_17

    .line 395
    .line 396
    iget-object v0, v13, Lse;->c:Ljava/lang/Object;

    .line 397
    .line 398
    check-cast v0, Lws2;

    .line 399
    .line 400
    iget-boolean v1, v0, Lws2;->d:Z

    .line 401
    .line 402
    if-eqz v1, :cond_16

    .line 403
    .line 404
    iput-boolean v8, v0, Lws2;->d:Z

    .line 405
    .line 406
    goto :goto_c

    .line 407
    :cond_16
    iget-object v0, v0, Lws2;->g:Lht4;

    .line 408
    .line 409
    iget-object v0, v0, Lht4;->a:Lve4;

    .line 410
    .line 411
    invoke-virtual {v0}, Lve4;->g()V

    .line 412
    .line 413
    .line 414
    :goto_c
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getEventTime()J

    .line 415
    .line 416
    .line 417
    move-result-wide v4
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 418
    const/4 v6, 0x1

    .line 419
    const/16 v3, 0x9

    .line 420
    .line 421
    move-object/from16 v1, p0

    .line 422
    .line 423
    move-object/from16 v2, p1

    .line 424
    .line 425
    :try_start_6
    invoke-virtual/range {v1 .. v6}, Lbb;->G(Landroid/view/MotionEvent;IJZ)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 426
    .line 427
    .line 428
    goto :goto_d

    .line 429
    :cond_17
    move-object/from16 v1, p0

    .line 430
    .line 431
    :goto_d
    iput-boolean v7, v1, Lbb;->k0:Z

    .line 432
    .line 433
    return v9

    .line 434
    :catchall_0
    move-exception v0

    .line 435
    move-object/from16 v1, p0

    .line 436
    .line 437
    goto :goto_f

    .line 438
    :catchall_1
    move-exception v0

    .line 439
    move-object/from16 v1, p0

    .line 440
    .line 441
    goto :goto_e

    .line 442
    :catchall_2
    move-exception v0

    .line 443
    :goto_e
    :try_start_7
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 444
    .line 445
    .line 446
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 447
    :catchall_3
    move-exception v0

    .line 448
    :goto_f
    iput-boolean v7, v1, Lbb;->k0:Z

    .line 449
    .line 450
    throw v0
.end method

.method public final k(Lzi3;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, p1, v1}, Lk92;->s(Lzi3;Z)Z

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1}, Lzi3;->z()Lve4;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    iget-object v0, p1, Lve4;->h:[Ljava/lang/Object;

    .line 12
    .line 13
    iget p1, p1, Lve4;->j:I

    .line 14
    .line 15
    :goto_0
    if-ge v1, p1, :cond_0

    .line 16
    .line 17
    aget-object v2, v0, v1

    .line 18
    .line 19
    check-cast v2, Lzi3;

    .line 20
    .line 21
    invoke-virtual {p0, v2}, Lbb;->k(Lzi3;)V

    .line 22
    .line 23
    .line 24
    add-int/lit8 v1, v1, 0x1

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    return-void
.end method

.method public final n(Landroid/view/MotionEvent;Lic5;)Z
    .locals 2

    .line 1
    sget-object v0, Lic5;->l:Lic5;

    .line 2
    .line 3
    if-eq p2, v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    const/4 v0, 0x0

    .line 14
    cmpg-float v1, v0, p2

    .line 15
    .line 16
    if-gtz v1, :cond_1

    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    int-to-float v1, v1

    .line 23
    cmpg-float p2, p2, v1

    .line 24
    .line 25
    if-gtz p2, :cond_1

    .line 26
    .line 27
    cmpg-float p2, v0, p1

    .line 28
    .line 29
    if-gtz p2, :cond_1

    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    int-to-float p0, p0

    .line 36
    cmpg-float p0, p1, p0

    .line 37
    .line 38
    if-gtz p0, :cond_1

    .line 39
    .line 40
    :cond_0
    const/4 p0, 0x1

    .line 41
    return p0

    .line 42
    :cond_1
    const/4 p0, 0x0

    .line 43
    return p0
.end method

.method public final o(Landroid/view/MotionEvent;)Z
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    iget-object p0, p0, Lbb;->w0:Landroid/view/MotionEvent;

    .line 9
    .line 10
    if-eqz p0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-ne v0, v2, :cond_0

    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawX()F

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    cmpg-float v0, v0, v2

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawY()F

    .line 39
    .line 40
    .line 41
    move-result p0

    .line 42
    cmpg-float p0, p1, p0

    .line 43
    .line 44
    if-nez p0, :cond_0

    .line 45
    .line 46
    const/4 p0, 0x0

    .line 47
    return p0

    .line 48
    :cond_0
    return v1
.end method

.method public final onAttachedToWindow()V
    .locals 8

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Lzi3;->H()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0, p0}, Lzi3;->b(Lbb;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    const/4 v0, 0x1

    .line 22
    invoke-direct {p0, v0}, Lbb;->setAttached(Z)V

    .line 23
    .line 24
    .line 25
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 26
    .line 27
    const/16 v2, 0x1e

    .line 28
    .line 29
    if-ge v1, v2, :cond_1

    .line 30
    .line 31
    invoke-static {}, Lp80;->z()Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    invoke-virtual {p0, v1}, Lbb;->setShowLayoutBounds(Z)V

    .line 36
    .line 37
    .line 38
    :cond_1
    iget-object v1, p0, Lbb;->A:Lm38;

    .line 39
    .line 40
    if-eqz v1, :cond_2

    .line 41
    .line 42
    invoke-virtual {v1, p0}, Lm38;->onViewAttachedToWindow(Landroid/view/View;)V

    .line 43
    .line 44
    .line 45
    :cond_2
    iget-boolean v1, p0, Lbb;->M0:Z

    .line 46
    .line 47
    if-nez v1, :cond_3

    .line 48
    .line 49
    iget-object v1, p0, Lbb;->h:Lw41;

    .line 50
    .line 51
    invoke-virtual {v1}, Lw41;->e()V

    .line 52
    .line 53
    .line 54
    :cond_3
    const/4 v1, 0x0

    .line 55
    iput-boolean v1, p0, Lbb;->M0:Z

    .line 56
    .line 57
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-virtual {p0, v2}, Lbb;->k(Lzi3;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    invoke-static {v2}, Lbb;->j(Lzi3;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0}, Lbb;->getSnapshotObserver()Li45;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    iget-object v2, v2, Li45;->a:Lpw6;

    .line 76
    .line 77
    invoke-virtual {v2}, Lpw6;->d()V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p0}, Lbb;->getOutOfFrameExecutor()Lbb;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    if-eqz v2, :cond_f

    .line 85
    .line 86
    new-instance v3, Lja;

    .line 87
    .line 88
    invoke-direct {v3, p0, v0}, Lja;-><init>(Lbb;B)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2, v3}, Lbb;->C(Llh2;)V

    .line 92
    .line 93
    .line 94
    iget-object v2, p0, Lbb;->h:Lw41;

    .line 95
    .line 96
    invoke-virtual {v2}, Lw41;->d()Lto3;

    .line 97
    .line 98
    .line 99
    iget-object v2, p0, Lbb;->h:Lw41;

    .line 100
    .line 101
    invoke-virtual {v2}, Lw41;->g()V

    .line 102
    .line 103
    .line 104
    iget-object v2, v2, Lw41;->f:Lfy7;

    .line 105
    .line 106
    iget-object v3, p0, Lbb;->l:Lyo3;

    .line 107
    .line 108
    const/4 v4, 0x0

    .line 109
    if-eqz v2, :cond_9

    .line 110
    .line 111
    if-eqz v3, :cond_9

    .line 112
    .line 113
    invoke-interface {v2}, Lfy7;->f()Ley7;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    new-instance v3, Ldy7;

    .line 118
    .line 119
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 120
    .line 121
    .line 122
    sget-object v5, Lqj1;->b:Lqj1;

    .line 123
    .line 124
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 125
    .line 126
    .line 127
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    new-instance v6, Lq21;

    .line 131
    .line 132
    invoke-direct {v6, v2, v3, v5}, Lq21;-><init>(Ley7;Lcy7;Lrj1;)V

    .line 133
    .line 134
    .line 135
    const-class v2, Lap3;

    .line 136
    .line 137
    invoke-static {v2}, Lhw5;->a(Ljava/lang/Class;)Lnt0;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    invoke-virtual {v2}, Lnt0;->b()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    if-eqz v3, :cond_8

    .line 146
    .line 147
    const-string v5, "androidx.lifecycle.ViewModelProvider.DefaultKey:"

    .line 148
    .line 149
    invoke-virtual {v5, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    invoke-virtual {v6, v2, v3}, Lq21;->r(Lnt0;Ljava/lang/String;)Lyx7;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    check-cast v2, Lap3;

    .line 158
    .line 159
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 164
    .line 165
    .line 166
    check-cast v3, Landroid/view/View;

    .line 167
    .line 168
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 169
    .line 170
    .line 171
    move-result v3

    .line 172
    iget-object v2, v2, Lap3;->b:Lrd4;

    .line 173
    .line 174
    invoke-virtual {v2, v3}, Ln93;->b(I)Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v5

    .line 178
    if-nez v5, :cond_4

    .line 179
    .line 180
    new-instance v5, Lfe4;

    .line 181
    .line 182
    invoke-direct {v5, v0}, Lfe4;-><init>(I)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v2, v3, v5}, Lrd4;->i(ILjava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    :cond_4
    check-cast v5, Lfe4;

    .line 189
    .line 190
    iget-object v2, v5, Lfe4;->a:[Ljava/lang/Object;

    .line 191
    .line 192
    iget v3, v5, Lfe4;->b:I

    .line 193
    .line 194
    :goto_0
    if-ge v1, v3, :cond_5

    .line 195
    .line 196
    aget-object v6, v2, v1

    .line 197
    .line 198
    move-object v7, v6

    .line 199
    check-cast v7, Lzo3;

    .line 200
    .line 201
    iget-boolean v7, v7, Lzo3;->c:Z

    .line 202
    .line 203
    if-eqz v7, :cond_6

    .line 204
    .line 205
    add-int/lit8 v1, v1, 0x1

    .line 206
    .line 207
    goto :goto_0

    .line 208
    :cond_5
    move-object v6, v4

    .line 209
    :cond_6
    check-cast v6, Lzo3;

    .line 210
    .line 211
    if-nez v6, :cond_7

    .line 212
    .line 213
    new-instance v6, Lzo3;

    .line 214
    .line 215
    invoke-direct {v6}, Lzo3;-><init>()V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v5, v6}, Lfe4;->a(Ljava/lang/Object;)V

    .line 219
    .line 220
    .line 221
    :cond_7
    iput-boolean v0, v6, Lzo3;->c:Z

    .line 222
    .line 223
    iput-object v6, p0, Lbb;->m:Lzo3;

    .line 224
    .line 225
    iget-object v1, v6, Lzo3;->b:Lm5;

    .line 226
    .line 227
    goto :goto_1

    .line 228
    :cond_8
    const-string p0, "Local and anonymous classes can not be ViewModels"

    .line 229
    .line 230
    invoke-static {p0}, Ll42;->g(Ljava/lang/String;)V

    .line 231
    .line 232
    .line 233
    return-void

    .line 234
    :cond_9
    move-object v1, v4

    .line 235
    :goto_1
    if-nez v1, :cond_a

    .line 236
    .line 237
    sget-object v1, Lh22;->t:Lh22;

    .line 238
    .line 239
    :cond_a
    iput-object v1, p0, Lbb;->o:Lzz5;

    .line 240
    .line 241
    iget-object v1, p0, Lbb;->m0:Lwh2;

    .line 242
    .line 243
    if-eqz v1, :cond_b

    .line 244
    .line 245
    iget-object v2, p0, Lbb;->h:Lw41;

    .line 246
    .line 247
    invoke-interface {v1, v2}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    iput-object v4, p0, Lbb;->m0:Lwh2;

    .line 251
    .line 252
    :cond_b
    iget-object v1, p0, Lbb;->h:Lw41;

    .line 253
    .line 254
    invoke-virtual {v1}, Lw41;->d()Lto3;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    invoke-interface {v1}, Lto3;->g()Lwo3;

    .line 259
    .line 260
    .line 261
    move-result-object v1

    .line 262
    invoke-virtual {v1, p0}, Lwo3;->a(Lso3;)V

    .line 263
    .line 264
    .line 265
    iget-object v2, p0, Lbb;->G:Lrb;

    .line 266
    .line 267
    invoke-virtual {v1, v2}, Lwo3;->a(Lso3;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {p0}, Lbb;->getInputModeManager()Lg83;

    .line 271
    .line 272
    .line 273
    move-result-object v1

    .line 274
    invoke-virtual {p0}, Landroid/view/View;->isInTouchMode()Z

    .line 275
    .line 276
    .line 277
    move-result v2

    .line 278
    if-nez v2, :cond_c

    .line 279
    .line 280
    const/4 v0, 0x2

    .line 281
    :cond_c
    iget-object v1, v1, Lg83;->a:Lz75;

    .line 282
    .line 283
    new-instance v2, Le83;

    .line 284
    .line 285
    invoke-direct {v2, v0}, Le83;-><init>(I)V

    .line 286
    .line 287
    .line 288
    invoke-virtual {v1, v2}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 292
    .line 293
    .line 294
    move-result-object v0

    .line 295
    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 299
    .line 300
    .line 301
    move-result-object v0

    .line 302
    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnScrollChangedListener(Landroid/view/ViewTreeObserver$OnScrollChangedListener;)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnTouchModeChangeListener(Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;)V

    .line 310
    .line 311
    .line 312
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 313
    .line 314
    const/16 v1, 0x1f

    .line 315
    .line 316
    if-lt v0, v1, :cond_d

    .line 317
    .line 318
    invoke-static {p0}, Lvj;->c(Landroid/view/View;)V

    .line 319
    .line 320
    .line 321
    :cond_d
    invoke-virtual {p0}, Lbb;->getAutofillManager()Lda;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    if-eqz v0, :cond_e

    .line 326
    .line 327
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 328
    .line 329
    .line 330
    move-result-object v1

    .line 331
    check-cast v1, Lje2;

    .line 332
    .line 333
    iget-object v1, v1, Lje2;->h:Lfe4;

    .line 334
    .line 335
    invoke-virtual {v1, v0}, Lfe4;->a(Ljava/lang/Object;)V

    .line 336
    .line 337
    .line 338
    invoke-virtual {p0}, Lbb;->getSemanticsOwner()Lgl6;

    .line 339
    .line 340
    .line 341
    move-result-object v1

    .line 342
    iget-object v1, v1, Lgl6;->d:Lfe4;

    .line 343
    .line 344
    invoke-virtual {v1, v0}, Lfe4;->a(Ljava/lang/Object;)V

    .line 345
    .line 346
    .line 347
    :cond_e
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    check-cast v0, Lje2;

    .line 352
    .line 353
    iget-object v0, v0, Lje2;->h:Lfe4;

    .line 354
    .line 355
    invoke-virtual {v0, p0}, Lfe4;->a(Ljava/lang/Object;)V

    .line 356
    .line 357
    .line 358
    return-void

    .line 359
    :cond_f
    const-string p0, "Expected the view to be attached to window."

    .line 360
    .line 361
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 362
    .line 363
    .line 364
    return-void
.end method

.method public final onCheckIsTextEditor()Z
    .locals 3

    .line 1
    iget-object v0, p0, Lbb;->p0:Ljava/util/concurrent/atomic/AtomicReference;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lnm6;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, v0, Lnm6;->b:Ljava/lang/Object;

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    move-object v0, v1

    .line 16
    :goto_0
    check-cast v0, Lld;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    invoke-direct {p0}, Lbb;->getLegacyTextInputServiceAndroid()Llf7;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    return v2

    .line 29
    :cond_1
    iget-object p0, v0, Lld;->k:Ljava/util/concurrent/atomic/AtomicReference;

    .line 30
    .line 31
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    check-cast p0, Lnm6;

    .line 36
    .line 37
    if-eqz p0, :cond_2

    .line 38
    .line 39
    iget-object v1, p0, Lnm6;->b:Ljava/lang/Object;

    .line 40
    .line 41
    :cond_2
    check-cast v1, Ld83;

    .line 42
    .line 43
    if-eqz v1, :cond_3

    .line 44
    .line 45
    iget-boolean p0, v1, Ld83;->e:Z

    .line 46
    .line 47
    const/4 v0, 0x1

    .line 48
    xor-int/2addr p0, v0

    .line 49
    if-ne p0, v0, :cond_3

    .line 50
    .line 51
    return v0

    .line 52
    :cond_3
    return v2
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1}, Lbb;->I(Landroid/content/res/Configuration;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 4

    .line 1
    iget-object v0, p0, Lbb;->p0:Ljava/util/concurrent/atomic/AtomicReference;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lnm6;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, v0, Lnm6;->b:Ljava/lang/Object;

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    move-object v0, v1

    .line 16
    :goto_0
    check-cast v0, Lld;

    .line 17
    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    invoke-direct {p0}, Lbb;->getLegacyTextInputServiceAndroid()Llf7;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    return-object v1

    .line 28
    :cond_1
    iget-object p0, v0, Lld;->k:Ljava/util/concurrent/atomic/AtomicReference;

    .line 29
    .line 30
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    check-cast p0, Lnm6;

    .line 35
    .line 36
    if-eqz p0, :cond_2

    .line 37
    .line 38
    iget-object p0, p0, Lnm6;->b:Ljava/lang/Object;

    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_2
    move-object p0, v1

    .line 42
    :goto_1
    check-cast p0, Ld83;

    .line 43
    .line 44
    if-eqz p0, :cond_5

    .line 45
    .line 46
    iget-object v0, p0, Ld83;->c:Ljava/lang/Object;

    .line 47
    .line 48
    monitor-enter v0

    .line 49
    :try_start_0
    iget-boolean v2, p0, Ld83;->e:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 50
    .line 51
    if-eqz v2, :cond_3

    .line 52
    .line 53
    monitor-exit v0

    .line 54
    return-object v1

    .line 55
    :cond_3
    :try_start_1
    iget-object v1, p0, Ld83;->a:Lff;

    .line 56
    .line 57
    invoke-virtual {v1, p1}, Lff;->a(Landroid/view/inputmethod/EditorInfo;)Lb07;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    new-instance v1, Ln41;

    .line 62
    .line 63
    const/16 v2, 0x11

    .line 64
    .line 65
    invoke-direct {v1, p0, v2}, Ln41;-><init>(Ljava/lang/Object;B)V

    .line 66
    .line 67
    .line 68
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 69
    .line 70
    const/16 v3, 0x22

    .line 71
    .line 72
    if-lt v2, v3, :cond_4

    .line 73
    .line 74
    new-instance v2, Llv4;

    .line 75
    .line 76
    invoke-direct {v2, p1, v1}, Lkv4;-><init>(Lb07;Ln41;)V

    .line 77
    .line 78
    .line 79
    goto :goto_2

    .line 80
    :cond_4
    new-instance v2, Lkv4;

    .line 81
    .line 82
    invoke-direct {v2, p1, v1}, Lkv4;-><init>(Lb07;Ln41;)V

    .line 83
    .line 84
    .line 85
    :goto_2
    iget-object p0, p0, Ld83;->d:Lve4;

    .line 86
    .line 87
    new-instance p1, Lxy7;

    .line 88
    .line 89
    invoke-direct {p1, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {p0, p1}, Lve4;->b(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 93
    .line 94
    .line 95
    monitor-exit v0

    .line 96
    return-object v2

    .line 97
    :catchall_0
    move-exception p0

    .line 98
    monitor-exit v0

    .line 99
    throw p0

    .line 100
    :cond_5
    return-object v1
.end method

.method public final onCreateVirtualViewTranslationRequests([J[ILjava/util/function/Consumer;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->G:Lrb;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {p0, p1, p3}, Lpb;->e(Lrb;[JLjava/util/function/Consumer;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 10

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, v0}, Lbb;->setAttached(Z)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lbb;->I0:Lu63;

    .line 9
    .line 10
    iput v0, v1, Lu63;->a:I

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    iput-boolean v2, v1, Lu63;->b:Z

    .line 14
    .line 15
    iget-object v1, v1, Lu63;->e:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v1, Landroid/view/GestureDetector;

    .line 18
    .line 19
    if-eqz v1, :cond_0

    .line 20
    .line 21
    const/4 v8, 0x0

    .line 22
    const/4 v9, 0x0

    .line 23
    const-wide/16 v2, 0x0

    .line 24
    .line 25
    const-wide/16 v4, 0x0

    .line 26
    .line 27
    const/4 v6, 0x3

    .line 28
    const/4 v7, 0x0

    .line 29
    invoke-static/range {v2 .. v9}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    invoke-virtual {v1, v2}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V

    .line 37
    .line 38
    .line 39
    :cond_0
    iget-object v1, p0, Lbb;->A:Lm38;

    .line 40
    .line 41
    if-eqz v1, :cond_1

    .line 42
    .line 43
    invoke-virtual {v1, p0}, Lm38;->onViewDetachedFromWindow(Landroid/view/View;)V

    .line 44
    .line 45
    .line 46
    :cond_1
    iget-object v1, p0, Lbb;->t:Landroid/view/View;

    .line 47
    .line 48
    invoke-static {}, Lbb;->l()Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_2

    .line 53
    .line 54
    if-eqz v1, :cond_2

    .line 55
    .line 56
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 57
    .line 58
    .line 59
    :cond_2
    sget-object v1, Lbb;->U0:Lfe4;

    .line 60
    .line 61
    monitor-enter v1

    .line 62
    :try_start_0
    invoke-virtual {v1, p0}, Lfe4;->k(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 63
    .line 64
    .line 65
    monitor-exit v1

    .line 66
    iget-object v1, p0, Lbb;->h:Lw41;

    .line 67
    .line 68
    invoke-virtual {v1}, Lw41;->b()V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0}, Lbb;->getSnapshotObserver()Li45;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    iget-object v1, v1, Li45;->a:Lpw6;

    .line 76
    .line 77
    iget-object v2, v1, Lpw6;->h:Lg7;

    .line 78
    .line 79
    if-eqz v2, :cond_3

    .line 80
    .line 81
    invoke-virtual {v2}, Lg7;->g()V

    .line 82
    .line 83
    .line 84
    :cond_3
    invoke-virtual {v1}, Lpw6;->a()V

    .line 85
    .line 86
    .line 87
    iget-object v1, p0, Lbb;->h:Lw41;

    .line 88
    .line 89
    invoke-virtual {v1}, Lw41;->d()Lto3;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-interface {v1}, Lto3;->g()Lwo3;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    iget-object v2, p0, Lbb;->G:Lrb;

    .line 98
    .line 99
    invoke-virtual {v1, v2}, Lwo3;->f(Lso3;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v1, p0}, Lwo3;->f(Lso3;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnScrollChangedListener(Landroid/view/ViewTreeObserver$OnScrollChangedListener;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnTouchModeChangeListener(Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;)V

    .line 124
    .line 125
    .line 126
    iget-object v1, p0, Lbb;->m:Lzo3;

    .line 127
    .line 128
    if-eqz v1, :cond_4

    .line 129
    .line 130
    iput-boolean v0, v1, Lzo3;->c:Z

    .line 131
    .line 132
    :cond_4
    const/4 v0, 0x0

    .line 133
    iput-object v0, p0, Lbb;->m:Lzo3;

    .line 134
    .line 135
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 136
    .line 137
    const/16 v2, 0x1f

    .line 138
    .line 139
    if-lt v1, v2, :cond_5

    .line 140
    .line 141
    invoke-static {p0}, Lvj;->a(Landroid/view/View;)V

    .line 142
    .line 143
    .line 144
    :cond_5
    invoke-virtual {p0}, Lbb;->getAutofillManager()Lda;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    if-eqz v1, :cond_6

    .line 149
    .line 150
    invoke-virtual {p0}, Lbb;->getSemanticsOwner()Lgl6;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    iget-object v2, v2, Lgl6;->d:Lfe4;

    .line 155
    .line 156
    invoke-virtual {v2, v1}, Lfe4;->k(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    check-cast v2, Lje2;

    .line 164
    .line 165
    iget-object v2, v2, Lje2;->h:Lfe4;

    .line 166
    .line 167
    invoke-virtual {v2, v1}, Lfe4;->k(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    :cond_6
    invoke-virtual {p0}, Lbb;->getRectManager()Lzv5;

    .line 171
    .line 172
    .line 173
    move-result-object v1

    .line 174
    iget-object v2, v1, Lzv5;->d:Ldk7;

    .line 175
    .line 176
    const/4 v8, 0x0

    .line 177
    const/4 v9, 0x0

    .line 178
    const-wide/16 v3, 0x0

    .line 179
    .line 180
    const-wide/16 v5, 0x0

    .line 181
    .line 182
    const/4 v7, 0x0

    .line 183
    invoke-virtual/range {v2 .. v9}, Ldk7;->b(JJ[FII)Z

    .line 184
    .line 185
    .line 186
    move-result v2

    .line 187
    iput-boolean v2, v1, Lzv5;->g:Z

    .line 188
    .line 189
    invoke-virtual {p0}, Lbb;->getRectManager()Lzv5;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    invoke-virtual {v1}, Lzv5;->a()V

    .line 194
    .line 195
    .line 196
    invoke-virtual {p0}, Lbb;->getRectManager()Lzv5;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    iget-object v2, v1, Lzv5;->i:La3;

    .line 201
    .line 202
    if-eqz v2, :cond_7

    .line 203
    .line 204
    iget-object v3, v1, Lzv5;->b:Lbb;

    .line 205
    .line 206
    invoke-virtual {v3, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 207
    .line 208
    .line 209
    iput-object v0, v1, Lzv5;->i:La3;

    .line 210
    .line 211
    :cond_7
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 212
    .line 213
    .line 214
    move-result-object v0

    .line 215
    check-cast v0, Lje2;

    .line 216
    .line 217
    iget-object v0, v0, Lje2;->h:Lfe4;

    .line 218
    .line 219
    invoke-virtual {v0, p0}, Lfe4;->k(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    return-void

    .line 223
    :catchall_0
    move-exception v0

    .line 224
    move-object p0, v0

    .line 225
    monitor-exit v1

    .line 226
    throw p0
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onFocusChanged(ZILandroid/graphics/Rect;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroid/view/View;->onFocusChanged(ZILandroid/graphics/Rect;)V

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_0

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/view/View;->hasFocus()Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-nez p1, :cond_0

    .line 11
    .line 12
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lje2;

    .line 17
    .line 18
    iget-object p1, p0, Lje2;->d:Lye2;

    .line 19
    .line 20
    const/4 p2, 0x1

    .line 21
    invoke-static {p1, p2}, Ldx;->G(Lye2;Z)Z

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0}, Lje2;->h()Lye2;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    if-eqz p1, :cond_0

    .line 29
    .line 30
    invoke-virtual {p0}, Lje2;->h()Lye2;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    const/4 p2, 0x0

    .line 35
    invoke-virtual {p0, p2}, Lje2;->k(Lye2;)V

    .line 36
    .line 37
    .line 38
    if-eqz p1, :cond_0

    .line 39
    .line 40
    sget-object p0, Lue2;->h:Lue2;

    .line 41
    .line 42
    sget-object p2, Lue2;->j:Lue2;

    .line 43
    .line 44
    invoke-virtual {p1, p0, p2}, Lye2;->H1(Lue2;Lue2;)V

    .line 45
    .line 46
    .line 47
    :cond_0
    return-void
.end method

.method public final onGlobalLayout()V
    .locals 2

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    iput-wide v0, p0, Lbb;->j0:J

    .line 4
    .line 5
    invoke-virtual {p0}, Lbb;->J()V

    .line 6
    .line 7
    .line 8
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 v1, 0x20

    .line 11
    .line 12
    if-gt v1, v0, :cond_0

    .line 13
    .line 14
    const/16 v1, 0x22

    .line 15
    .line 16
    if-ge v0, v1, :cond_0

    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {p0, v0}, Lbb;->I(Landroid/content/res/Configuration;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    return-void
.end method

.method public final onLayout(ZIIII)V
    .locals 2

    .line 1
    const-string p1, "AndroidOwner:onLayout"

    .line 2
    .line 3
    invoke-static {p1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-wide/16 v0, 0x0

    .line 7
    .line 8
    :try_start_0
    iput-wide v0, p0, Lbb;->j0:J

    .line 9
    .line 10
    iget-object p1, p0, Lbb;->c0:Lk92;

    .line 11
    .line 12
    iget-object v0, p0, Lbb;->J0:Lja;

    .line 13
    .line 14
    invoke-virtual {p1, v0}, Lk92;->l(Llh2;)Z

    .line 15
    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    iput-object p1, p0, Lbb;->a0:Ljb1;

    .line 19
    .line 20
    invoke-virtual {p0}, Lbb;->J()V

    .line 21
    .line 22
    .line 23
    iget-object p0, p0, Lbb;->W:Llg;

    .line 24
    .line 25
    if-eqz p0, :cond_0

    .line 26
    .line 27
    const-string p1, "AndroidOwner:viewLayout"

    .line 28
    .line 29
    invoke-static {p1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 30
    .line 31
    .line 32
    sub-int/2addr p4, p2

    .line 33
    sub-int/2addr p5, p3

    .line 34
    const/4 p1, 0x0

    .line 35
    :try_start_1
    invoke-virtual {p0, p1, p1, p4, p5}, Landroid/view/View;->layout(IIII)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 36
    .line 37
    .line 38
    :try_start_2
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception p0

    .line 43
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 44
    .line 45
    .line 46
    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 47
    :cond_0
    :goto_0
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :catchall_1
    move-exception p0

    .line 52
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 53
    .line 54
    .line 55
    throw p0
.end method

.method public final onMeasure(II)V
    .locals 8

    .line 1
    iget-object v0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    const-string v1, "AndroidOwner:onMeasure"

    .line 4
    .line 5
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    :try_start_0
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Lzi3;->H()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-nez v1, :cond_0

    .line 17
    .line 18
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v1, p0}, Lzi3;->b(Lbb;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-nez v1, :cond_1

    .line 30
    .line 31
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-virtual {p0, v1}, Lbb;->k(Lzi3;)V

    .line 36
    .line 37
    .line 38
    :cond_1
    invoke-static {p1}, Lbb;->d(I)J

    .line 39
    .line 40
    .line 41
    move-result-wide v1

    .line 42
    const/16 p1, 0x20

    .line 43
    .line 44
    ushr-long v3, v1, p1

    .line 45
    .line 46
    long-to-int v3, v3

    .line 47
    const-wide v4, 0xffffffffL

    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    and-long/2addr v1, v4

    .line 53
    long-to-int v1, v1

    .line 54
    invoke-static {p2}, Lbb;->d(I)J

    .line 55
    .line 56
    .line 57
    move-result-wide v6

    .line 58
    ushr-long p1, v6, p1

    .line 59
    .line 60
    long-to-int p1, p1

    .line 61
    and-long/2addr v6, v4

    .line 62
    long-to-int p2, v6

    .line 63
    invoke-static {v3, v1, p1, p2}, Lqv;->E(IIII)J

    .line 64
    .line 65
    .line 66
    move-result-wide p1

    .line 67
    iget-object v1, p0, Lbb;->a0:Ljb1;

    .line 68
    .line 69
    if-nez v1, :cond_2

    .line 70
    .line 71
    new-instance v1, Ljb1;

    .line 72
    .line 73
    invoke-direct {v1, p1, p2}, Ljb1;-><init>(J)V

    .line 74
    .line 75
    .line 76
    iput-object v1, p0, Lbb;->a0:Ljb1;

    .line 77
    .line 78
    const/4 v1, 0x0

    .line 79
    iput-boolean v1, p0, Lbb;->b0:Z

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_2
    iget-wide v1, v1, Ljb1;->a:J

    .line 83
    .line 84
    invoke-static {v1, v2, p1, p2}, Ljb1;->c(JJ)Z

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    if-nez v1, :cond_3

    .line 89
    .line 90
    const/4 v1, 0x1

    .line 91
    iput-boolean v1, p0, Lbb;->b0:Z

    .line 92
    .line 93
    :cond_3
    :goto_0
    invoke-virtual {v0, p1, p2}, Lk92;->t(J)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v0}, Lk92;->n()V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    iget-object p1, p1, Lzi3;->N:Ldj3;

    .line 104
    .line 105
    iget-object p1, p1, Ldj3;->p:Lt14;

    .line 106
    .line 107
    iget p1, p1, Lfb5;->h:I

    .line 108
    .line 109
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 110
    .line 111
    .line 112
    move-result-object p2

    .line 113
    iget-object p2, p2, Lzi3;->N:Ldj3;

    .line 114
    .line 115
    iget-object p2, p2, Ldj3;->p:Lt14;

    .line 116
    .line 117
    iget p2, p2, Lfb5;->i:I

    .line 118
    .line 119
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 120
    .line 121
    .line 122
    iget-object p1, p0, Lbb;->W:Llg;

    .line 123
    .line 124
    if-eqz p1, :cond_4

    .line 125
    .line 126
    const-string p2, "AndroidOwner:androidViewMeasure"

    .line 127
    .line 128
    invoke-static {p2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 129
    .line 130
    .line 131
    :try_start_1
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 132
    .line 133
    .line 134
    move-result-object p2

    .line 135
    iget-object p2, p2, Lzi3;->N:Ldj3;

    .line 136
    .line 137
    iget-object p2, p2, Ldj3;->p:Lt14;

    .line 138
    .line 139
    iget p2, p2, Lfb5;->h:I

    .line 140
    .line 141
    const/high16 v0, 0x40000000    # 2.0f

    .line 142
    .line 143
    invoke-static {p2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 144
    .line 145
    .line 146
    move-result p2

    .line 147
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    iget-object p0, p0, Lzi3;->N:Ldj3;

    .line 152
    .line 153
    iget-object p0, p0, Ldj3;->p:Lt14;

    .line 154
    .line 155
    iget p0, p0, Lfb5;->i:I

    .line 156
    .line 157
    invoke-static {p0, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 158
    .line 159
    .line 160
    move-result p0

    .line 161
    invoke-virtual {p1, p2, p0}, Landroid/view/View;->measure(II)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 162
    .line 163
    .line 164
    :try_start_2
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 165
    .line 166
    .line 167
    goto :goto_1

    .line 168
    :catchall_0
    move-exception p0

    .line 169
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 170
    .line 171
    .line 172
    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 173
    :cond_4
    :goto_1
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 174
    .line 175
    .line 176
    return-void

    .line 177
    :catchall_1
    move-exception p0

    .line 178
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 179
    .line 180
    .line 181
    throw p0
.end method

.method public final onProvideAutofillVirtualStructure(Landroid/view/ViewStructure;I)V
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    iget-boolean p2, p0, Lbb;->N0:Z

    .line 4
    .line 5
    if-nez p2, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Lbb;->y(Landroid/view/ViewStructure;)V

    .line 8
    .line 9
    .line 10
    :cond_0
    return-void
.end method

.method public final onResolvePointerIcon(Landroid/view/MotionEvent;I)Landroid/view/PointerIcon;
    .locals 2

    .line 1
    invoke-virtual {p1, p2}, Landroid/view/MotionEvent;->getToolType(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x2002

    .line 6
    .line 7
    invoke-virtual {p1, v1}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    const/16 v1, 0x4002

    .line 14
    .line 15
    invoke-virtual {p1, v1}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_1

    .line 20
    .line 21
    const/4 v1, 0x2

    .line 22
    if-eq v0, v1, :cond_0

    .line 23
    .line 24
    const/4 v1, 0x4

    .line 25
    if-ne v0, v1, :cond_1

    .line 26
    .line 27
    :cond_0
    invoke-virtual {p0}, Lbb;->getPointerIconService()Lrc5;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, Lxa;

    .line 32
    .line 33
    iget-object v0, v0, Lxa;->a:Lmd;

    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    invoke-static {p0, v0}, Lpj;->b(Landroid/content/Context;Lqc5;)Landroid/view/PointerIcon;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    return-object p0

    .line 46
    :cond_1
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->onResolvePointerIcon(Landroid/view/MotionEvent;I)Landroid/view/PointerIcon;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0
.end method

.method public final onResume(Lto3;)V
    .locals 3

    .line 1
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v0, 0x1e

    .line 4
    .line 5
    if-ge p1, v0, :cond_0

    .line 6
    .line 7
    invoke-static {}, Lp80;->z()Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    invoke-virtual {p0, p1}, Lbb;->setShowLayoutBounds(Z)V

    .line 12
    .line 13
    .line 14
    :cond_0
    iget-object p1, p0, Lbb;->m:Lzo3;

    .line 15
    .line 16
    if-eqz p1, :cond_4

    .line 17
    .line 18
    iget-object p0, p0, Lbb;->l:Lyo3;

    .line 19
    .line 20
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    iget-object v0, p1, Lzo3;->a:Lm5;

    .line 24
    .line 25
    iget-object v0, v0, Lm5;->i:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v0, Lhy3;

    .line 28
    .line 29
    iget-boolean v1, v0, Lhy3;->h:Z

    .line 30
    .line 31
    if-eqz v1, :cond_4

    .line 32
    .line 33
    iget-boolean v1, v0, Lhy3;->j:Z

    .line 34
    .line 35
    if-nez v1, :cond_4

    .line 36
    .line 37
    :try_start_0
    new-instance v1, Lt43;

    .line 38
    .line 39
    const/4 v2, 0x6

    .line 40
    invoke-direct {v1, p1, v2}, Lt43;-><init>(Ljava/lang/Object;B)V

    .line 41
    .line 42
    .line 43
    invoke-interface {p0, v1}, Lyo3;->a(Lt43;)Lml0;

    .line 44
    .line 45
    .line 46
    move-result-object p0
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    goto :goto_0

    .line 48
    :catch_0
    iget-boolean p0, v0, Lhy3;->i:Z

    .line 49
    .line 50
    if-nez p0, :cond_2

    .line 51
    .line 52
    iget-boolean p0, v0, Lhy3;->j:Z

    .line 53
    .line 54
    if-eqz p0, :cond_1

    .line 55
    .line 56
    const-string p0, "ManagedValuesStore tried to enter composition twice. Did you attempt to install the same store multiple times or into two compositions?"

    .line 57
    .line 58
    invoke-static {p0}, Lgf5;->a(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    :cond_1
    invoke-virtual {v0}, Lhy3;->a()V

    .line 62
    .line 63
    .line 64
    const/4 p0, 0x1

    .line 65
    iput-boolean p0, v0, Lhy3;->j:Z

    .line 66
    .line 67
    :cond_2
    const/4 p0, 0x0

    .line 68
    :goto_0
    iget-object v0, p1, Lzo3;->d:Lml0;

    .line 69
    .line 70
    if-eqz v0, :cond_3

    .line 71
    .line 72
    invoke-interface {v0}, Lml0;->cancel()V

    .line 73
    .line 74
    .line 75
    :cond_3
    iput-object p0, p1, Lzo3;->d:Lml0;

    .line 76
    .line 77
    :cond_4
    return-void
.end method

.method public final onRtlPropertiesChanged(I)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbb;->j:Z

    .line 2
    .line 3
    if-eqz v0, :cond_3

    .line 4
    .line 5
    sget-object v0, Lde2;->a:[I

    .line 6
    .line 7
    sget-object v0, Lii3;->h:Lii3;

    .line 8
    .line 9
    if-eqz p1, :cond_1

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    if-eq p1, v1, :cond_0

    .line 13
    .line 14
    const/4 p1, 0x0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    sget-object p1, Lii3;->i:Lii3;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    move-object p1, v0

    .line 20
    :goto_0
    if-eqz p1, :cond_2

    .line 21
    .line 22
    move-object v0, p1

    .line 23
    :cond_2
    invoke-direct {p0, v0}, Lbb;->setLayoutDirection(Lii3;)V

    .line 24
    .line 25
    .line 26
    :cond_3
    return-void
.end method

.method public final onScrollCaptureSearch(Landroid/graphics/Rect;Landroid/graphics/Point;Ljava/util/function/Consumer;)V
    .locals 1

    .line 1
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 p2, 0x1f

    .line 4
    .line 5
    if-lt p1, p2, :cond_0

    .line 6
    .line 7
    iget-object p1, p0, Lbb;->O0:Lmg6;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Lbb;->getSemanticsOwner()Lgl6;

    .line 12
    .line 13
    .line 14
    move-result-object p2

    .line 15
    invoke-virtual {p0}, Lbb;->getCoroutineContext()Laj1;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {p1, p0, p2, v0, p3}, Lmg6;->a(Lbb;Lgl6;Laj1;Ljava/util/function/Consumer;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public final onScrollChanged()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lbb;->J()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final onStop(Lto3;)V
    .locals 1

    .line 1
    iget-object p0, p0, Lbb;->m:Lzo3;

    .line 2
    .line 3
    if-eqz p0, :cond_4

    .line 4
    .line 5
    iget-object p1, p0, Lzo3;->a:Lm5;

    .line 6
    .line 7
    iget-object p1, p1, Lm5;->i:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p1, Lhy3;

    .line 10
    .line 11
    iget-boolean v0, p1, Lhy3;->h:Z

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    iget-boolean v0, p1, Lhy3;->j:Z

    .line 16
    .line 17
    if-nez v0, :cond_1

    .line 18
    .line 19
    iget-object p1, p0, Lzo3;->d:Lml0;

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    invoke-interface {p1}, Lml0;->cancel()V

    .line 24
    .line 25
    .line 26
    :cond_0
    const/4 p1, 0x0

    .line 27
    iput-object p1, p0, Lzo3;->d:Lml0;

    .line 28
    .line 29
    return-void

    .line 30
    :cond_1
    iget-boolean p0, p1, Lhy3;->i:Z

    .line 31
    .line 32
    if-nez p0, :cond_4

    .line 33
    .line 34
    iget-boolean p0, p1, Lhy3;->j:Z

    .line 35
    .line 36
    if-nez p0, :cond_2

    .line 37
    .line 38
    const-string p0, "ManagedValuesStore tried to leave composition twice. Is the store installed in multiple places?"

    .line 39
    .line 40
    invoke-static {p0}, Lgf5;->a(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    :cond_2
    iget-object p0, p1, Lhy3;->k:Lne4;

    .line 44
    .line 45
    invoke-virtual {p0}, Lne4;->i()Z

    .line 46
    .line 47
    .line 48
    move-result p0

    .line 49
    if-nez p0, :cond_3

    .line 50
    .line 51
    const-string p0, "Attempted to start retaining exited values with pending exited values"

    .line 52
    .line 53
    invoke-static {p0}, Lgf5;->a(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    :cond_3
    const/4 p0, 0x0

    .line 57
    iput-boolean p0, p1, Lhy3;->j:Z

    .line 58
    .line 59
    :cond_4
    return-void
.end method

.method public final onTouchModeChanged(Z)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lbb;->getInputModeManager()Lg83;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 p1, 0x2

    .line 10
    :goto_0
    iget-object p0, p0, Lg83;->a:Lz75;

    .line 11
    .line 12
    new-instance v0, Le83;

    .line 13
    .line 14
    invoke-direct {v0, p1}, Le83;-><init>(I)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0, v0}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final onVirtualViewTranslationResponses(Landroid/util/LongSparseArray;)V
    .locals 3

    .line 1
    iget-object p0, p0, Lbb;->G:Lrb;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    .line 8
    const/16 v1, 0x1f

    .line 9
    .line 10
    if-ge v0, v1, :cond_0

    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-static {v0, v1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    invoke-static {p0, p1}, Lpb;->b(Lrb;Landroid/util/LongSparseArray;)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_1
    iget-object v0, p0, Lrb;->h:Lbb;

    .line 36
    .line 37
    new-instance v1, Lob;

    .line 38
    .line 39
    const/4 v2, 0x0

    .line 40
    invoke-direct {v1, p0, p1, v2}, Lob;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public final onWindowFocusChanged(Z)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lbb;->L0:Z

    .line 3
    .line 4
    invoke-super {p0, p1}, Landroid/view/View;->onWindowFocusChanged(Z)V

    .line 5
    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 10
    .line 11
    const/16 v0, 0x1e

    .line 12
    .line 13
    if-ge p1, v0, :cond_0

    .line 14
    .line 15
    invoke-static {}, Lp80;->z()Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    invoke-virtual {p0}, Lbb;->getShowLayoutBounds()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eq v0, p1, :cond_0

    .line 24
    .line 25
    invoke-virtual {p0, p1}, Lbb;->setShowLayoutBounds(Z)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, Lbb;->getRoot()Lzi3;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-static {p0}, Lbb;->j(Lzi3;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    return-void
.end method

.method public final p(J)J
    .locals 7

    .line 1
    invoke-virtual {p0}, Lbb;->z()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lbb;->h0:[F

    .line 5
    .line 6
    invoke-static {p1, p2, v0}, Lo14;->b(J[F)J

    .line 7
    .line 8
    .line 9
    move-result-wide p1

    .line 10
    const/16 v0, 0x20

    .line 11
    .line 12
    shr-long v1, p1, v0

    .line 13
    .line 14
    long-to-int v1, v1

    .line 15
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    iget-wide v2, p0, Lbb;->l0:J

    .line 20
    .line 21
    shr-long/2addr v2, v0

    .line 22
    long-to-int v2, v2

    .line 23
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    add-float/2addr v2, v1

    .line 28
    const-wide v3, 0xffffffffL

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    and-long/2addr p1, v3

    .line 34
    long-to-int p1, p1

    .line 35
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    iget-wide v5, p0, Lbb;->l0:J

    .line 40
    .line 41
    and-long/2addr v5, v3

    .line 42
    long-to-int p0, v5

    .line 43
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 44
    .line 45
    .line 46
    move-result p0

    .line 47
    add-float/2addr p0, p1

    .line 48
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    int-to-long p1, p1

    .line 53
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 54
    .line 55
    .line 56
    move-result p0

    .line 57
    int-to-long v1, p0

    .line 58
    shl-long/2addr p1, v0

    .line 59
    and-long/2addr v1, v3

    .line 60
    or-long/2addr p1, v1

    .line 61
    return-wide p1
.end method

.method public final q(Z)V
    .locals 2

    .line 1
    iget-object v0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    iget-object v1, v0, Lk92;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lzi7;

    .line 6
    .line 7
    invoke-virtual {v1}, Lzi7;->V()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    iget-object v1, v0, Lk92;->f:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Leq2;

    .line 16
    .line 17
    iget-object v1, v1, Leq2;->i:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v1, Lve4;

    .line 20
    .line 21
    iget v1, v1, Lve4;->j:I

    .line 22
    .line 23
    if-nez v1, :cond_0

    .line 24
    .line 25
    return-void

    .line 26
    :cond_0
    const-string v1, "AndroidOwner:measureAndLayout"

    .line 27
    .line 28
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    if-eqz p1, :cond_1

    .line 32
    .line 33
    :try_start_0
    iget-object p1, p0, Lbb;->J0:Lja;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    iget-object p1, p0, Lbb;->K0:Lja;

    .line 37
    .line 38
    :goto_0
    invoke-virtual {v0, p1}, Lk92;->l(Llh2;)Z

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    if-eqz p1, :cond_2

    .line 43
    .line 44
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 45
    .line 46
    .line 47
    :cond_2
    const/4 p1, 0x0

    .line 48
    invoke-virtual {v0, p1}, Lk92;->b(Z)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, Lbb;->getRectManager()Lzv5;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {v0}, Lzv5;->a()V

    .line 56
    .line 57
    .line 58
    iget-boolean v0, p0, Lbb;->M:Z

    .line 59
    .line 60
    if-eqz v0, :cond_3

    .line 61
    .line 62
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->dispatchOnGlobalLayout()V

    .line 67
    .line 68
    .line 69
    iput-boolean p1, p0, Lbb;->M:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 70
    .line 71
    :cond_3
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 72
    .line 73
    .line 74
    return-void

    .line 75
    :catchall_0
    move-exception p0

    .line 76
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 77
    .line 78
    .line 79
    throw p0
.end method

.method public final r(Lzi3;J)V
    .locals 2

    .line 1
    iget-object v0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    const-string v1, "AndroidOwner:measureAndLayout"

    .line 4
    .line 5
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    :try_start_0
    invoke-virtual {v0, p1, p2, p3}, Lk92;->m(Lzi3;J)V

    .line 9
    .line 10
    .line 11
    iget-object p1, v0, Lk92;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lzi7;

    .line 14
    .line 15
    invoke-virtual {p1}, Lzi7;->V()Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    if-nez p1, :cond_0

    .line 20
    .line 21
    const/4 p1, 0x0

    .line 22
    invoke-virtual {v0, p1}, Lk92;->b(Z)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0}, Lbb;->getRectManager()Lzv5;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    invoke-virtual {p2}, Lzv5;->a()V

    .line 30
    .line 31
    .line 32
    iget-object p2, p0, Lbb;->K0:Lja;

    .line 33
    .line 34
    invoke-virtual {p2}, Lja;->a()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    iget-boolean p2, p0, Lbb;->M:Z

    .line 38
    .line 39
    if-eqz p2, :cond_0

    .line 40
    .line 41
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    invoke-virtual {p2}, Landroid/view/ViewTreeObserver;->dispatchOnGlobalLayout()V

    .line 46
    .line 47
    .line 48
    iput-boolean p1, p0, Lbb;->M:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    .line 50
    :cond_0
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :catchall_0
    move-exception p0

    .line 55
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 56
    .line 57
    .line 58
    throw p0
.end method

.method public final requestFocus(ILandroid/graphics/Rect;)Z
    .locals 7

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_2

    .line 7
    .line 8
    invoke-static {p1}, Lde2;->d(I)Ltd2;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    iget-byte p1, p1, Ltd2;->a:B

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 p1, 0x7

    .line 18
    :goto_0
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    const/4 v2, 0x0

    .line 23
    if-eqz p2, :cond_1

    .line 24
    .line 25
    new-instance v3, Lyv5;

    .line 26
    .line 27
    iget v4, p2, Landroid/graphics/Rect;->left:I

    .line 28
    .line 29
    int-to-float v4, v4

    .line 30
    iget v5, p2, Landroid/graphics/Rect;->top:I

    .line 31
    .line 32
    int-to-float v5, v5

    .line 33
    iget v6, p2, Landroid/graphics/Rect;->right:I

    .line 34
    .line 35
    int-to-float v6, v6

    .line 36
    iget p2, p2, Landroid/graphics/Rect;->bottom:I

    .line 37
    .line 38
    int-to-float p2, p2

    .line 39
    invoke-direct {v3, v4, v5, v6, p2}, Lyv5;-><init>(FFFF)V

    .line 40
    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    move-object v3, v2

    .line 44
    :goto_1
    new-instance p2, Loa;

    .line 45
    .line 46
    const/4 v4, 0x0

    .line 47
    invoke-direct {p2, p1, v4}, Loa;-><init>(IB)V

    .line 48
    .line 49
    .line 50
    check-cast v0, Lje2;

    .line 51
    .line 52
    invoke-virtual {v0, p1, v3, p2}, Lje2;->g(ILyv5;Lwh2;)Ljava/lang/Boolean;

    .line 53
    .line 54
    .line 55
    move-result-object p2

    .line 56
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 57
    .line 58
    invoke-static {p2, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result p2

    .line 62
    if-nez p2, :cond_2

    .line 63
    .line 64
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    new-instance v3, Loa;

    .line 69
    .line 70
    invoke-direct {v3, p1, v1}, Loa;-><init>(IB)V

    .line 71
    .line 72
    .line 73
    check-cast p2, Lje2;

    .line 74
    .line 75
    invoke-virtual {p2, p1, v2, v3}, Lje2;->g(ILyv5;Lwh2;)Ljava/lang/Boolean;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    invoke-static {p2, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result p2

    .line 83
    if-eqz p2, :cond_3

    .line 84
    .line 85
    :cond_2
    return v1

    .line 86
    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->hasFocus()Z

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    if-eqz p2, :cond_5

    .line 91
    .line 92
    if-eq p1, v1, :cond_4

    .line 93
    .line 94
    const/4 p2, 0x2

    .line 95
    if-ne p1, p2, :cond_5

    .line 96
    .line 97
    :cond_4
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 98
    .line 99
    .line 100
    move-result-object p0

    .line 101
    check-cast p0, Lje2;

    .line 102
    .line 103
    invoke-virtual {p0, p1}, Lje2;->j(I)Z

    .line 104
    .line 105
    .line 106
    move-result p0

    .line 107
    return p0

    .line 108
    :cond_5
    return v4
.end method

.method public final s(I)Z
    .locals 6

    .line 1
    const/4 v0, 0x7

    .line 2
    const/4 v1, 0x0

    .line 3
    if-eq p1, v0, :cond_3

    .line 4
    .line 5
    const/16 v0, 0x8

    .line 6
    .line 7
    if-eq p1, v0, :cond_3

    .line 8
    .line 9
    invoke-static {p1}, Lde2;->c(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const-string v2, "Invalid focus direction"

    .line 14
    .line 15
    if-eqz v0, :cond_6

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-virtual {p0}, Lbb;->getFocusOwner()Lge2;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Lje2;

    .line 26
    .line 27
    invoke-virtual {v3}, Lje2;->h()Lye2;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    if-eqz v3, :cond_5

    .line 32
    .line 33
    invoke-static {p1}, Lde2;->c(I)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    if-eqz p1, :cond_4

    .line 38
    .line 39
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    invoke-static {v3}, Lsx;->l0(Lap1;)Lzi3;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    iget-object v2, v2, Lzi3;->v:Lrx7;

    .line 48
    .line 49
    const/4 v3, 0x0

    .line 50
    if-eqz v2, :cond_0

    .line 51
    .line 52
    invoke-virtual {v2}, Lgg;->getInteropView()Landroid/view/View;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    goto :goto_0

    .line 57
    :cond_0
    move-object v2, v3

    .line 58
    :goto_0
    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    check-cast p0, Landroid/view/ViewGroup;

    .line 74
    .line 75
    invoke-virtual {v5, p0, v4, p1}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    if-eqz p0, :cond_1

    .line 80
    .line 81
    if-eqz v2, :cond_1

    .line 82
    .line 83
    invoke-static {v2, p0}, Lkb;->F(Landroid/view/View;Landroid/view/View;)Z

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    const/4 v2, 0x1

    .line 88
    if-eq p1, v2, :cond_2

    .line 89
    .line 90
    :cond_1
    move-object p0, v3

    .line 91
    :cond_2
    if-eqz p0, :cond_3

    .line 92
    .line 93
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-static {p0, p1, v3}, Lde2;->b(Landroid/view/View;Ljava/lang/Integer;Landroid/graphics/Rect;)Z

    .line 98
    .line 99
    .line 100
    move-result p0

    .line 101
    return p0

    .line 102
    :cond_3
    return v1

    .line 103
    :cond_4
    invoke-static {v2}, Lp92;->g(Ljava/lang/String;)Lo11;

    .line 104
    .line 105
    .line 106
    move-result-object p0

    .line 107
    throw p0

    .line 108
    :cond_5
    const-string p0, "findNextViewInEmbeddedView called when owner does not have anything focused."

    .line 109
    .line 110
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    return v1

    .line 114
    :cond_6
    invoke-static {v2}, Lp92;->g(Ljava/lang/String;)Lo11;

    .line 115
    .line 116
    .line 117
    move-result-object p0

    .line 118
    throw p0
.end method

.method public setAccessibilityEventBatchIntervalMillis(J)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->F:Ljb;

    .line 2
    .line 3
    iput-wide p1, p0, Ljb;->o:J

    .line 4
    .line 5
    return-void
.end method

.method public final setComposeViewContext(Lw41;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lbb;->h:Lw41;

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    invoke-virtual {v0}, Lw41;->b()V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Lw41;->e()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p1}, Lw41;->d()Lto3;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v0}, Lw41;->d()Lto3;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    if-eq v1, v2, :cond_1

    .line 27
    .line 28
    invoke-virtual {v0}, Lw41;->d()Lto3;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-interface {v0}, Lto3;->g()Lwo3;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    iget-object v1, p0, Lbb;->G:Lrb;

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Lwo3;->f(Lso3;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, p0}, Lwo3;->f(Lso3;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1}, Lw41;->d()Lto3;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-interface {v0}, Lto3;->g()Lwo3;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {v0, p0}, Lwo3;->a(Lso3;)V

    .line 53
    .line 54
    .line 55
    iget-object v1, p0, Lbb;->G:Lrb;

    .line 56
    .line 57
    invoke-virtual {v0, v1}, Lwo3;->a(Lso3;)V

    .line 58
    .line 59
    .line 60
    :cond_1
    iput-object p1, p0, Lbb;->h:Lw41;

    .line 61
    .line 62
    invoke-virtual {p1}, Lw41;->c()Ln51;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-virtual {v0}, Ln51;->k()Laj1;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-virtual {p0, v0}, Lbb;->setCoroutineContext(Laj1;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p1}, Lw41;->c()Ln51;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    new-instance v0, Lva;

    .line 78
    .line 79
    const/4 v1, 0x0

    .line 80
    invoke-direct {v0, p1, v1}, Lva;-><init>(Ln51;B)V

    .line 81
    .line 82
    .line 83
    iput-object v0, p0, Lbb;->l:Lyo3;

    .line 84
    .line 85
    return-void
.end method

.method public final setComposeViewContextIncrementedDuringInit$androidx_compose_ui_ui(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Lbb;->M0:Z

    .line 2
    .line 3
    return-void
.end method

.method public final setConfiguration(Landroid/content/res/Configuration;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->P:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final setContentCaptureManager$androidx_compose_ui_ui(Lrb;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lbb;->G:Lrb;

    .line 2
    .line 3
    return-void
.end method

.method public setCoroutineContext(Laj1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lbb;->v:Laj1;

    .line 2
    .line 3
    return-void
.end method

.method public final setFrameEndScheduler$androidx_compose_ui_ui(Lyo3;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lbb;->l:Lyo3;

    .line 2
    .line 3
    return-void
.end method

.method public final setLastMatrixRecalculationAnimationTime$androidx_compose_ui_ui(J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lbb;->j0:J

    .line 2
    .line 3
    return-void
.end method

.method public final setOnReadyForComposition(Lwh2;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwh2;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lbb;->getDerivedIsAttached()Z

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-boolean v0, p0, Lbb;->M0:Z

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    iput-object p1, p0, Lbb;->m0:Lwh2;

    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    iget-object p0, p0, Lbb;->h:Lw41;

    .line 18
    .line 19
    invoke-interface {p1, p0}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final setPlayNavigationSoundEffect$androidx_compose_ui_ui(Lai2;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lai2;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lbb;->H0:Lai2;

    .line 2
    .line 3
    return-void
.end method

.method public final setPrimaryDirectionalMotionAxisOverride-r2epLt8$androidx_compose_ui_ui(Lj63;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lbb;->k:Lj63;

    .line 2
    .line 3
    return-void
.end method

.method public setShowLayoutBounds(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Lbb;->V:Z

    .line 2
    .line 3
    return-void
.end method

.method public setUncaughtExceptionHandler(Lj16;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final setUncaughtExceptionHandler$androidx_compose_ui_ui(Lj16;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final set_uiMediaScope$androidx_compose_ui_ui(Lps7;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final shouldDelayChildPressedState()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final t()V
    .locals 12

    .line 1
    iget-boolean v0, p0, Lbb;->T:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    if-eqz v0, :cond_4

    .line 7
    .line 8
    invoke-virtual {p0}, Lbb;->getSnapshotObserver()Li45;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v0, v0, Li45;->a:Lpw6;

    .line 13
    .line 14
    new-instance v4, Lbv4;

    .line 15
    .line 16
    const/16 v5, 0x9

    .line 17
    .line 18
    invoke-direct {v4, v5}, Lbv4;-><init>(B)V

    .line 19
    .line 20
    .line 21
    iget-object v5, v0, Lpw6;->g:Ljava/lang/Object;

    .line 22
    .line 23
    monitor-enter v5

    .line 24
    :try_start_0
    iget-object v0, v0, Lpw6;->f:Lve4;

    .line 25
    .line 26
    iget v6, v0, Lve4;->j:I

    .line 27
    .line 28
    move v7, v3

    .line 29
    move v8, v7

    .line 30
    :goto_0
    iget-object v9, v0, Lve4;->h:[Ljava/lang/Object;

    .line 31
    .line 32
    if-ge v7, v6, :cond_3

    .line 33
    .line 34
    aget-object v9, v9, v7

    .line 35
    .line 36
    check-cast v9, Low6;

    .line 37
    .line 38
    invoke-virtual {v9, v4}, Low6;->h(Lbv4;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v9}, Low6;->a()Lne4;

    .line 42
    .line 43
    .line 44
    move-result-object v9

    .line 45
    iget v9, v9, Lne4;->e:I

    .line 46
    .line 47
    if-eqz v9, :cond_0

    .line 48
    .line 49
    move v9, v2

    .line 50
    goto :goto_1

    .line 51
    :cond_0
    move v9, v3

    .line 52
    :goto_1
    if-nez v9, :cond_1

    .line 53
    .line 54
    add-int/lit8 v8, v8, 0x1

    .line 55
    .line 56
    goto :goto_2

    .line 57
    :cond_1
    if-lez v8, :cond_2

    .line 58
    .line 59
    iget-object v9, v0, Lve4;->h:[Ljava/lang/Object;

    .line 60
    .line 61
    sub-int v10, v7, v8

    .line 62
    .line 63
    aget-object v11, v9, v7

    .line 64
    .line 65
    aput-object v11, v9, v10

    .line 66
    .line 67
    :cond_2
    :goto_2
    add-int/lit8 v7, v7, 0x1

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_3
    sub-int v4, v6, v8

    .line 71
    .line 72
    invoke-static {v9, v4, v6, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    iput v4, v0, Lve4;->j:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 76
    .line 77
    monitor-exit v5

    .line 78
    iput-boolean v3, p0, Lbb;->T:Z

    .line 79
    .line 80
    goto :goto_3

    .line 81
    :catchall_0
    move-exception p0

    .line 82
    monitor-exit v5

    .line 83
    throw p0

    .line 84
    :cond_4
    :goto_3
    iget-object v0, p0, Lbb;->W:Llg;

    .line 85
    .line 86
    if-eqz v0, :cond_5

    .line 87
    .line 88
    invoke-static {v0}, Lbb;->c(Landroid/view/ViewGroup;)V

    .line 89
    .line 90
    .line 91
    :cond_5
    invoke-virtual {p0}, Lbb;->getAutofillManager()Lda;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    if-eqz v0, :cond_7

    .line 96
    .line 97
    iget-object v4, v0, Lda;->o:Lsd4;

    .line 98
    .line 99
    iget v5, v4, Lsd4;->d:I

    .line 100
    .line 101
    if-nez v5, :cond_6

    .line 102
    .line 103
    iget-boolean v5, v0, Lda;->p:Z

    .line 104
    .line 105
    if-eqz v5, :cond_6

    .line 106
    .line 107
    iget-object v5, v0, Lda;->h:Leq2;

    .line 108
    .line 109
    invoke-virtual {v5}, Leq2;->Q()Landroid/view/autofill/AutofillManager;

    .line 110
    .line 111
    .line 112
    move-result-object v5

    .line 113
    invoke-virtual {v5}, Landroid/view/autofill/AutofillManager;->commit()V

    .line 114
    .line 115
    .line 116
    iput-boolean v3, v0, Lda;->p:Z

    .line 117
    .line 118
    :cond_6
    iget v4, v4, Lsd4;->d:I

    .line 119
    .line 120
    if-eqz v4, :cond_7

    .line 121
    .line 122
    iput-boolean v2, v0, Lda;->p:Z

    .line 123
    .line 124
    :cond_7
    :goto_4
    iget-object v0, p0, Lbb;->z0:Lfe4;

    .line 125
    .line 126
    invoke-virtual {v0}, Lfe4;->j()Z

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    if-eqz v0, :cond_a

    .line 131
    .line 132
    iget-object v0, p0, Lbb;->z0:Lfe4;

    .line 133
    .line 134
    invoke-virtual {v0, v3}, Lfe4;->g(I)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    if-eqz v0, :cond_a

    .line 139
    .line 140
    iget-object v0, p0, Lbb;->z0:Lfe4;

    .line 141
    .line 142
    iget v0, v0, Lfe4;->b:I

    .line 143
    .line 144
    move v2, v3

    .line 145
    :goto_5
    iget-object v4, p0, Lbb;->z0:Lfe4;

    .line 146
    .line 147
    if-ge v2, v0, :cond_9

    .line 148
    .line 149
    invoke-virtual {v4, v2}, Lfe4;->g(I)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v4

    .line 153
    check-cast v4, Llh2;

    .line 154
    .line 155
    iget-object v5, p0, Lbb;->z0:Lfe4;

    .line 156
    .line 157
    invoke-virtual {v5, v2, v1}, Lfe4;->o(ILjava/lang/Object;)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    if-eqz v4, :cond_8

    .line 161
    .line 162
    invoke-interface {v4}, Llh2;->a()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    :cond_8
    add-int/lit8 v2, v2, 0x1

    .line 166
    .line 167
    goto :goto_5

    .line 168
    :cond_9
    invoke-virtual {v4, v3, v0}, Lfe4;->m(II)V

    .line 169
    .line 170
    .line 171
    goto :goto_4

    .line 172
    :cond_a
    return-void
.end method

.method public final u(Lzi3;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lbb;->F:Ljb;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    iput-boolean v1, v0, Ljb;->D:Z

    .line 5
    .line 6
    invoke-virtual {v0}, Ljb;->s()Z

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    if-eqz v2, :cond_0

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Ljb;->u(Lzi3;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    iget-object p0, p0, Lbb;->G:Lrb;

    .line 16
    .line 17
    iput-boolean v1, p0, Lrb;->m:Z

    .line 18
    .line 19
    invoke-virtual {p0}, Lrb;->d()Z

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    if-eqz p1, :cond_1

    .line 24
    .line 25
    iget-object p0, p0, Lrb;->n:Lqg0;

    .line 26
    .line 27
    sget-object p1, Lst7;->a:Lst7;

    .line 28
    .line 29
    invoke-interface {p0, p1}, Lul6;->s(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    :cond_1
    return-void
.end method

.method public final v(Lzi3;ZZZ)V
    .locals 5

    .line 1
    iget-object v0, p0, Lbb;->c0:Lk92;

    .line 2
    .line 3
    if-eqz p2, :cond_a

    .line 4
    .line 5
    iget-object p2, v0, Lk92;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p2, Lzi7;

    .line 8
    .line 9
    iget-object v1, p1, Lzi3;->o:Lzi3;

    .line 10
    .line 11
    iget-object v2, p1, Lzi3;->N:Ldj3;

    .line 12
    .line 13
    if-nez v1, :cond_0

    .line 14
    .line 15
    const-string v1, "Error: requestLookaheadRemeasure cannot be called on a node outside LookaheadScope"

    .line 16
    .line 17
    invoke-static {v1}, Lp73;->b(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    iget-object v1, v2, Ldj3;->d:Lvi3;

    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    const/4 v3, 0x1

    .line 27
    if-eqz v1, :cond_9

    .line 28
    .line 29
    if-eq v1, v3, :cond_b

    .line 30
    .line 31
    const/4 v4, 0x2

    .line 32
    if-eq v1, v4, :cond_9

    .line 33
    .line 34
    const/4 v4, 0x3

    .line 35
    if-eq v1, v4, :cond_9

    .line 36
    .line 37
    const/4 v4, 0x4

    .line 38
    if-ne v1, v4, :cond_8

    .line 39
    .line 40
    iget-boolean v1, v2, Ldj3;->e:Z

    .line 41
    .line 42
    if-eqz v1, :cond_1

    .line 43
    .line 44
    if-eqz p3, :cond_b

    .line 45
    .line 46
    :cond_1
    iput-boolean v3, v2, Ldj3;->e:Z

    .line 47
    .line 48
    iget-object p3, v2, Ldj3;->p:Lt14;

    .line 49
    .line 50
    iput-boolean v3, p3, Lt14;->B:Z

    .line 51
    .line 52
    iget-boolean p3, p1, Lzi3;->X:Z

    .line 53
    .line 54
    if-nez p3, :cond_b

    .line 55
    .line 56
    invoke-virtual {p1}, Lzi3;->J()Ljava/lang/Boolean;

    .line 57
    .line 58
    .line 59
    move-result-object p3

    .line 60
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 61
    .line 62
    invoke-static {p3, v1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result p3

    .line 66
    if-nez p3, :cond_2

    .line 67
    .line 68
    invoke-static {p1}, Lk92;->i(Lzi3;)Z

    .line 69
    .line 70
    .line 71
    move-result p3

    .line 72
    if-eqz p3, :cond_3

    .line 73
    .line 74
    :cond_2
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 75
    .line 76
    .line 77
    move-result-object p3

    .line 78
    if-eqz p3, :cond_6

    .line 79
    .line 80
    iget-object p3, p3, Lzi3;->N:Ldj3;

    .line 81
    .line 82
    iget-boolean p3, p3, Ldj3;->e:Z

    .line 83
    .line 84
    if-ne p3, v3, :cond_6

    .line 85
    .line 86
    :cond_3
    invoke-virtual {p1}, Lzi3;->I()Z

    .line 87
    .line 88
    .line 89
    move-result p3

    .line 90
    if-nez p3, :cond_4

    .line 91
    .line 92
    invoke-static {p1}, Lk92;->j(Lzi3;)Z

    .line 93
    .line 94
    .line 95
    move-result p3

    .line 96
    if-eqz p3, :cond_7

    .line 97
    .line 98
    :cond_4
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 99
    .line 100
    .line 101
    move-result-object p3

    .line 102
    if-eqz p3, :cond_5

    .line 103
    .line 104
    invoke-virtual {p3}, Lzi3;->q()Z

    .line 105
    .line 106
    .line 107
    move-result p3

    .line 108
    if-eq p3, v3, :cond_7

    .line 109
    .line 110
    :cond_5
    sget-object p3, Lvb3;->j:Lvb3;

    .line 111
    .line 112
    invoke-virtual {p2, p1, p3}, Lzi7;->l(Lzi3;Lvb3;)V

    .line 113
    .line 114
    .line 115
    goto :goto_0

    .line 116
    :cond_6
    sget-object p3, Lvb3;->h:Lvb3;

    .line 117
    .line 118
    invoke-virtual {p2, p1, p3}, Lzi7;->l(Lzi3;Lvb3;)V

    .line 119
    .line 120
    .line 121
    :cond_7
    :goto_0
    iget-boolean p2, v0, Lk92;->c:Z

    .line 122
    .line 123
    if-nez p2, :cond_b

    .line 124
    .line 125
    if-eqz p4, :cond_b

    .line 126
    .line 127
    invoke-virtual {p0, p1}, Lbb;->D(Lzi3;)V

    .line 128
    .line 129
    .line 130
    return-void

    .line 131
    :cond_8
    invoke-static {}, Lxb1;->a()V

    .line 132
    .line 133
    .line 134
    return-void

    .line 135
    :cond_9
    iget-object p0, v0, Lk92;->h:Ljava/lang/Object;

    .line 136
    .line 137
    check-cast p0, Lve4;

    .line 138
    .line 139
    new-instance p2, Lq14;

    .line 140
    .line 141
    invoke-direct {p2, p1, v3, p3}, Lq14;-><init>(Lzi3;ZZ)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p0, p2}, Lve4;->b(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    return-void

    .line 148
    :cond_a
    invoke-virtual {v0, p1, p3}, Lk92;->s(Lzi3;Z)Z

    .line 149
    .line 150
    .line 151
    move-result p2

    .line 152
    if-eqz p2, :cond_b

    .line 153
    .line 154
    if-eqz p4, :cond_b

    .line 155
    .line 156
    invoke-virtual {p0, p1}, Lbb;->D(Lzi3;)V

    .line 157
    .line 158
    .line 159
    :cond_b
    return-void
.end method

.method public final w(Lzi3;ZZ)V
    .locals 9

    .line 1
    iget-object v0, p1, Lzi3;->N:Ldj3;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Lvb3;->k:Lvb3;

    .line 5
    .line 6
    const/4 v3, 0x4

    .line 7
    const/4 v4, 0x3

    .line 8
    const/4 v5, 0x2

    .line 9
    const/4 v6, 0x1

    .line 10
    iget-object v7, p0, Lbb;->c0:Lk92;

    .line 11
    .line 12
    if-eqz p2, :cond_7

    .line 13
    .line 14
    iget-object p2, v7, Lk92;->e:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p2, Lzi7;

    .line 17
    .line 18
    iget-object v8, v0, Ldj3;->d:Lvi3;

    .line 19
    .line 20
    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    .line 21
    .line 22
    .line 23
    move-result v8

    .line 24
    if-eqz v8, :cond_0

    .line 25
    .line 26
    if-eq v8, v6, :cond_d

    .line 27
    .line 28
    if-eq v8, v5, :cond_0

    .line 29
    .line 30
    if-eq v8, v4, :cond_d

    .line 31
    .line 32
    if-eq v8, v3, :cond_0

    .line 33
    .line 34
    invoke-static {}, Lxb1;->a()V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_0
    iget-boolean v3, v0, Ldj3;->e:Z

    .line 39
    .line 40
    if-nez v3, :cond_1

    .line 41
    .line 42
    iget-boolean v3, v0, Ldj3;->f:Z

    .line 43
    .line 44
    if-eqz v3, :cond_2

    .line 45
    .line 46
    :cond_1
    if-eqz p3, :cond_d

    .line 47
    .line 48
    :cond_2
    iput-boolean v6, v0, Ldj3;->f:Z

    .line 49
    .line 50
    iput-boolean v6, v0, Ldj3;->g:Z

    .line 51
    .line 52
    iget-object p3, v0, Ldj3;->p:Lt14;

    .line 53
    .line 54
    iput-boolean v6, p3, Lt14;->C:Z

    .line 55
    .line 56
    iput-boolean v6, p3, Lt14;->D:Z

    .line 57
    .line 58
    iget-boolean p3, p1, Lzi3;->X:Z

    .line 59
    .line 60
    if-nez p3, :cond_d

    .line 61
    .line 62
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 63
    .line 64
    .line 65
    move-result-object p3

    .line 66
    invoke-virtual {p1}, Lzi3;->J()Ljava/lang/Boolean;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 71
    .line 72
    invoke-static {v0, v3}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_4

    .line 77
    .line 78
    if-eqz p3, :cond_3

    .line 79
    .line 80
    iget-object v0, p3, Lzi3;->N:Ldj3;

    .line 81
    .line 82
    iget-boolean v3, v0, Ldj3;->e:Z

    .line 83
    .line 84
    if-eq v3, v6, :cond_4

    .line 85
    .line 86
    iget-boolean v0, v0, Ldj3;->f:Z

    .line 87
    .line 88
    if-eq v0, v6, :cond_4

    .line 89
    .line 90
    :cond_3
    sget-object p3, Lvb3;->i:Lvb3;

    .line 91
    .line 92
    invoke-virtual {p2, p1, p3}, Lzi7;->l(Lzi3;Lvb3;)V

    .line 93
    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_4
    invoke-virtual {p1}, Lzi3;->I()Z

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    if-eqz v0, :cond_6

    .line 101
    .line 102
    if-eqz p3, :cond_5

    .line 103
    .line 104
    invoke-virtual {p3}, Lzi3;->p()Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-eq v0, v6, :cond_6

    .line 109
    .line 110
    invoke-virtual {p3}, Lzi3;->q()Z

    .line 111
    .line 112
    .line 113
    move-result p3

    .line 114
    if-eq p3, v6, :cond_6

    .line 115
    .line 116
    :cond_5
    invoke-virtual {p2, p1, v2}, Lzi7;->l(Lzi3;Lvb3;)V

    .line 117
    .line 118
    .line 119
    :cond_6
    :goto_0
    iget-boolean p1, v7, Lk92;->c:Z

    .line 120
    .line 121
    if-nez p1, :cond_d

    .line 122
    .line 123
    invoke-virtual {p0, v1}, Lbb;->D(Lzi3;)V

    .line 124
    .line 125
    .line 126
    return-void

    .line 127
    :cond_7
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    iget-object p2, v0, Ldj3;->d:Lvi3;

    .line 131
    .line 132
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 133
    .line 134
    .line 135
    move-result p2

    .line 136
    if-eqz p2, :cond_d

    .line 137
    .line 138
    if-eq p2, v6, :cond_d

    .line 139
    .line 140
    if-eq p2, v5, :cond_d

    .line 141
    .line 142
    if-eq p2, v4, :cond_d

    .line 143
    .line 144
    if-ne p2, v3, :cond_c

    .line 145
    .line 146
    invoke-virtual {p1}, Lzi3;->u()Lzi3;

    .line 147
    .line 148
    .line 149
    move-result-object p2

    .line 150
    if-eqz p2, :cond_8

    .line 151
    .line 152
    invoke-virtual {p2}, Lzi3;->I()Z

    .line 153
    .line 154
    .line 155
    move-result v3

    .line 156
    if-nez v3, :cond_8

    .line 157
    .line 158
    const/4 v3, 0x0

    .line 159
    goto :goto_1

    .line 160
    :cond_8
    move v3, v6

    .line 161
    :goto_1
    if-nez p3, :cond_9

    .line 162
    .line 163
    invoke-virtual {p1}, Lzi3;->q()Z

    .line 164
    .line 165
    .line 166
    move-result p3

    .line 167
    if-nez p3, :cond_d

    .line 168
    .line 169
    invoke-virtual {p1}, Lzi3;->p()Z

    .line 170
    .line 171
    .line 172
    move-result p3

    .line 173
    if-eqz p3, :cond_9

    .line 174
    .line 175
    invoke-virtual {p1}, Lzi3;->I()Z

    .line 176
    .line 177
    .line 178
    move-result p3

    .line 179
    if-ne p3, v3, :cond_9

    .line 180
    .line 181
    invoke-virtual {p1}, Lzi3;->I()Z

    .line 182
    .line 183
    .line 184
    move-result p3

    .line 185
    iget-object v4, v0, Ldj3;->p:Lt14;

    .line 186
    .line 187
    iget-boolean v4, v4, Lt14;->A:Z

    .line 188
    .line 189
    if-eq p3, v4, :cond_d

    .line 190
    .line 191
    :cond_9
    iget-object p3, v0, Ldj3;->p:Lt14;

    .line 192
    .line 193
    iput-boolean v6, p3, Lt14;->C:Z

    .line 194
    .line 195
    iput-boolean v6, p3, Lt14;->D:Z

    .line 196
    .line 197
    iget-boolean v0, p1, Lzi3;->X:Z

    .line 198
    .line 199
    if-nez v0, :cond_d

    .line 200
    .line 201
    iget-boolean p3, p3, Lt14;->A:Z

    .line 202
    .line 203
    if-eqz p3, :cond_d

    .line 204
    .line 205
    if-eqz v3, :cond_d

    .line 206
    .line 207
    if-eqz p2, :cond_a

    .line 208
    .line 209
    invoke-virtual {p2}, Lzi3;->p()Z

    .line 210
    .line 211
    .line 212
    move-result p3

    .line 213
    if-eq p3, v6, :cond_b

    .line 214
    .line 215
    invoke-virtual {p2}, Lzi3;->q()Z

    .line 216
    .line 217
    .line 218
    move-result p2

    .line 219
    if-eq p2, v6, :cond_b

    .line 220
    .line 221
    :cond_a
    iget-object p2, v7, Lk92;->e:Ljava/lang/Object;

    .line 222
    .line 223
    check-cast p2, Lzi7;

    .line 224
    .line 225
    invoke-virtual {p2, p1, v2}, Lzi7;->l(Lzi3;Lvb3;)V

    .line 226
    .line 227
    .line 228
    :cond_b
    iget-boolean p1, v7, Lk92;->c:Z

    .line 229
    .line 230
    if-nez p1, :cond_d

    .line 231
    .line 232
    invoke-virtual {p0, v1}, Lbb;->D(Lzi3;)V

    .line 233
    .line 234
    .line 235
    return-void

    .line 236
    :cond_c
    invoke-static {}, Lxb1;->a()V

    .line 237
    .line 238
    .line 239
    :cond_d
    return-void
.end method

.method public final x()V
    .locals 4

    .line 1
    iget-object v0, p0, Lbb;->F:Ljb;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    iput-boolean v1, v0, Ljb;->D:Z

    .line 5
    .line 6
    iget-object v2, v0, Ljb;->k:Lbb;

    .line 7
    .line 8
    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {v0}, Ljb;->s()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    if-eqz v3, :cond_0

    .line 17
    .line 18
    iget-boolean v3, v0, Ljb;->O:Z

    .line 19
    .line 20
    if-nez v3, :cond_0

    .line 21
    .line 22
    if-eqz v2, :cond_0

    .line 23
    .line 24
    iput-boolean v1, v0, Ljb;->O:Z

    .line 25
    .line 26
    iget-object v0, v0, Ljb;->Q:La3;

    .line 27
    .line 28
    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 29
    .line 30
    .line 31
    :cond_0
    iget-object p0, p0, Lbb;->G:Lrb;

    .line 32
    .line 33
    iput-boolean v1, p0, Lrb;->m:Z

    .line 34
    .line 35
    iget-object v0, p0, Lrb;->h:Lbb;

    .line 36
    .line 37
    invoke-virtual {v0}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {p0}, Lrb;->d()Z

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    if-eqz v2, :cond_1

    .line 46
    .line 47
    iget-boolean v2, p0, Lrb;->s:Z

    .line 48
    .line 49
    if-nez v2, :cond_1

    .line 50
    .line 51
    if-eqz v0, :cond_1

    .line 52
    .line 53
    iput-boolean v1, p0, Lrb;->s:Z

    .line 54
    .line 55
    iget-object p0, p0, Lrb;->t:La3;

    .line 56
    .line 57
    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 58
    .line 59
    .line 60
    :cond_1
    return-void
.end method

.method public final y(Landroid/view/ViewStructure;)V
    .locals 13

    .line 1
    invoke-virtual {p0}, Lbb;->getAutofillManager()Lda;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_4

    .line 7
    .line 8
    iget-object v2, v0, Lda;->i:Lgl6;

    .line 9
    .line 10
    iget-object v2, v2, Lgl6;->a:Lzi3;

    .line 11
    .line 12
    iget-object v3, v0, Lda;->n:Landroid/view/autofill/AutofillId;

    .line 13
    .line 14
    iget-object v4, v0, Lda;->l:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v0, v0, Lda;->k:Lzv5;

    .line 17
    .line 18
    invoke-static {p1, v2, v3, v4, v0}, Lck3;->m0(Landroid/view/ViewStructure;Lzi3;Landroid/view/autofill/AutofillId;Ljava/lang/String;Lzv5;)V

    .line 19
    .line 20
    .line 21
    sget-object v5, Lwv4;->a:[Ljava/lang/Object;

    .line 22
    .line 23
    new-instance v5, Lfe4;

    .line 24
    .line 25
    const/4 v6, 0x2

    .line 26
    invoke-direct {v5, v6}, Lfe4;-><init>(I)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v5, v2}, Lfe4;->a(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v5, p1}, Lfe4;->a(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    invoke-virtual {v5}, Lfe4;->j()Z

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_4

    .line 40
    .line 41
    iget v2, v5, Lfe4;->b:I

    .line 42
    .line 43
    sub-int/2addr v2, v1

    .line 44
    invoke-virtual {v5, v2}, Lfe4;->l(I)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    check-cast v2, Landroid/view/ViewStructure;

    .line 52
    .line 53
    iget v6, v5, Lfe4;->b:I

    .line 54
    .line 55
    sub-int/2addr v6, v1

    .line 56
    invoke-virtual {v5, v6}, Lfe4;->l(I)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    check-cast v6, Lzi3;

    .line 64
    .line 65
    invoke-virtual {v6}, Lzi3;->n()Ljava/util/List;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    check-cast v6, Lde4;

    .line 70
    .line 71
    iget-object v7, v6, Lde4;->i:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v7, Lve4;

    .line 74
    .line 75
    iget v7, v7, Lve4;->j:I

    .line 76
    .line 77
    const/4 v8, 0x0

    .line 78
    :goto_0
    if-ge v8, v7, :cond_0

    .line 79
    .line 80
    invoke-virtual {v6, v8}, Lde4;->get(I)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    check-cast v9, Lzi3;

    .line 85
    .line 86
    iget-boolean v10, v9, Lzi3;->X:Z

    .line 87
    .line 88
    if-nez v10, :cond_3

    .line 89
    .line 90
    invoke-virtual {v9}, Lzi3;->H()Z

    .line 91
    .line 92
    .line 93
    move-result v10

    .line 94
    if-eqz v10, :cond_3

    .line 95
    .line 96
    invoke-virtual {v9}, Lzi3;->I()Z

    .line 97
    .line 98
    .line 99
    move-result v10

    .line 100
    if-eqz v10, :cond_3

    .line 101
    .line 102
    invoke-virtual {v9}, Lzi3;->w()Lzk6;

    .line 103
    .line 104
    .line 105
    move-result-object v10

    .line 106
    if-eqz v10, :cond_2

    .line 107
    .line 108
    iget-object v10, v10, Lzk6;->h:Lne4;

    .line 109
    .line 110
    sget-object v11, Lyk6;->g:Lkl6;

    .line 111
    .line 112
    invoke-virtual {v10, v11}, Lne4;->b(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v11

    .line 116
    if-nez v11, :cond_1

    .line 117
    .line 118
    sget-object v11, Lyk6;->h:Lkl6;

    .line 119
    .line 120
    invoke-virtual {v10, v11}, Lne4;->b(Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result v11

    .line 124
    if-nez v11, :cond_1

    .line 125
    .line 126
    sget-object v11, Lil6;->r:Lkl6;

    .line 127
    .line 128
    invoke-virtual {v10, v11}, Lne4;->b(Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v11

    .line 132
    if-nez v11, :cond_1

    .line 133
    .line 134
    sget-object v11, Lil6;->s:Lkl6;

    .line 135
    .line 136
    invoke-virtual {v10, v11}, Lne4;->b(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result v11

    .line 140
    if-nez v11, :cond_1

    .line 141
    .line 142
    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 143
    .line 144
    const/16 v12, 0x22

    .line 145
    .line 146
    if-lt v11, v12, :cond_2

    .line 147
    .line 148
    sget-object v11, Lnb3;->h0:Lkl6;

    .line 149
    .line 150
    invoke-virtual {v10, v11}, Lne4;->b(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v10

    .line 154
    if-eqz v10, :cond_2

    .line 155
    .line 156
    :cond_1
    invoke-virtual {v2, v1}, Landroid/view/ViewStructure;->addChildCount(I)I

    .line 157
    .line 158
    .line 159
    move-result v10

    .line 160
    invoke-virtual {v2, v10}, Landroid/view/ViewStructure;->newChild(I)Landroid/view/ViewStructure;

    .line 161
    .line 162
    .line 163
    move-result-object v10

    .line 164
    invoke-static {v10, v9, v3, v4, v0}, Lck3;->m0(Landroid/view/ViewStructure;Lzi3;Landroid/view/autofill/AutofillId;Ljava/lang/String;Lzv5;)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v5, v9}, Lfe4;->a(Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v5, v10}, Lfe4;->a(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    goto :goto_1

    .line 174
    :cond_2
    invoke-virtual {v5, v9}, Lfe4;->a(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v5, v2}, Lfe4;->a(Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    :cond_3
    :goto_1
    add-int/lit8 v8, v8, 0x1

    .line 181
    .line 182
    goto :goto_0

    .line 183
    :cond_4
    invoke-virtual {p0}, Lbb;->getAutofill()Lca;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    if-eqz p0, :cond_6

    .line 188
    .line 189
    iget-object v0, p0, Lca;->b:Lcz;

    .line 190
    .line 191
    iget-object v2, v0, Lcz;->a:Ljava/util/LinkedHashMap;

    .line 192
    .line 193
    iget-object v0, v0, Lcz;->a:Ljava/util/LinkedHashMap;

    .line 194
    .line 195
    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    .line 196
    .line 197
    .line 198
    move-result v2

    .line 199
    if-nez v2, :cond_6

    .line 200
    .line 201
    invoke-interface {v0}, Ljava/util/Map;->size()I

    .line 202
    .line 203
    .line 204
    move-result v2

    .line 205
    invoke-virtual {p1, v2}, Landroid/view/ViewStructure;->addChildCount(I)I

    .line 206
    .line 207
    .line 208
    move-result v2

    .line 209
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 218
    .line 219
    .line 220
    move-result v3

    .line 221
    if-eqz v3, :cond_6

    .line 222
    .line 223
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    check-cast v0, Ljava/util/Map$Entry;

    .line 228
    .line 229
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v3

    .line 233
    check-cast v3, Ljava/lang/Number;

    .line 234
    .line 235
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 236
    .line 237
    .line 238
    move-result v3

    .line 239
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    if-eqz v0, :cond_5

    .line 244
    .line 245
    invoke-static {}, Lxb1;->r()V

    .line 246
    .line 247
    .line 248
    return-void

    .line 249
    :cond_5
    invoke-virtual {p1, v2}, Landroid/view/ViewStructure;->newChild(I)Landroid/view/ViewStructure;

    .line 250
    .line 251
    .line 252
    move-result-object p1

    .line 253
    iget-object v0, p0, Lca;->c:Landroid/view/autofill/AutofillId;

    .line 254
    .line 255
    invoke-virtual {p1, v0, v3}, Landroid/view/ViewStructure;->setAutofillId(Landroid/view/autofill/AutofillId;I)V

    .line 256
    .line 257
    .line 258
    iget-object p0, p0, Lca;->a:Lbb;

    .line 259
    .line 260
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 261
    .line 262
    .line 263
    move-result-object p0

    .line 264
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object p0

    .line 268
    const/4 v0, 0x0

    .line 269
    invoke-virtual {p1, v3, p0, v0, v0}, Landroid/view/ViewStructure;->setId(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    invoke-virtual {p1, v1}, Landroid/view/ViewStructure;->setAutofillType(I)V

    .line 273
    .line 274
    .line 275
    throw v0

    .line 276
    :cond_6
    return-void
.end method

.method public final z()V
    .locals 6

    .line 1
    iget-boolean v0, p0, Lbb;->k0:Z

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    iget-wide v2, p0, Lbb;->j0:J

    .line 10
    .line 11
    cmp-long v2, v0, v2

    .line 12
    .line 13
    if-eqz v2, :cond_1

    .line 14
    .line 15
    iput-wide v0, p0, Lbb;->j0:J

    .line 16
    .line 17
    iget-object v0, p0, Lbb;->g0:Landroid/graphics/Matrix;

    .line 18
    .line 19
    iget-object v1, p0, Lbb;->h0:[F

    .line 20
    .line 21
    iget-object v2, p0, Lbb;->e0:[I

    .line 22
    .line 23
    invoke-static {p0, v1, v0, v2}, Lrj;->a(Landroid/view/View;[FLandroid/graphics/Matrix;[I)V

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Lbb;->i0:[F

    .line 27
    .line 28
    invoke-static {v1, v0}, Ldw;->H([F[F)Z

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    move-object v1, p0

    .line 36
    :goto_0
    instance-of v3, v0, Landroid/view/ViewGroup;

    .line 37
    .line 38
    if-eqz v3, :cond_0

    .line 39
    .line 40
    move-object v1, v0

    .line 41
    check-cast v1, Landroid/view/View;

    .line 42
    .line 43
    move-object v0, v1

    .line 44
    check-cast v0, Landroid/view/ViewGroup;

    .line 45
    .line 46
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    goto :goto_0

    .line 51
    :cond_0
    invoke-virtual {v1, v2}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 52
    .line 53
    .line 54
    const/4 v0, 0x0

    .line 55
    aget v3, v2, v0

    .line 56
    .line 57
    int-to-float v3, v3

    .line 58
    const/4 v4, 0x1

    .line 59
    aget v5, v2, v4

    .line 60
    .line 61
    int-to-float v5, v5

    .line 62
    invoke-virtual {v1, v2}, Landroid/view/View;->getLocationInWindow([I)V

    .line 63
    .line 64
    .line 65
    aget v0, v2, v0

    .line 66
    .line 67
    int-to-float v0, v0

    .line 68
    aget v1, v2, v4

    .line 69
    .line 70
    int-to-float v1, v1

    .line 71
    sub-float/2addr v3, v0

    .line 72
    sub-float/2addr v5, v1

    .line 73
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    int-to-long v0, v0

    .line 78
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    int-to-long v2, v2

    .line 83
    const/16 v4, 0x20

    .line 84
    .line 85
    shl-long/2addr v0, v4

    .line 86
    const-wide v4, 0xffffffffL

    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    and-long/2addr v2, v4

    .line 92
    or-long/2addr v0, v2

    .line 93
    iput-wide v0, p0, Lbb;->l0:J

    .line 94
    .line 95
    :cond_1
    return-void
.end method
