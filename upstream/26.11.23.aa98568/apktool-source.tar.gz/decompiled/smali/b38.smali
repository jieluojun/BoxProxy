.class public final Lb38;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final b:Lb38;


# instance fields
.field public final a:Ly28;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x22

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    sget-object v0, Lw28;->x:Lb38;

    .line 8
    .line 9
    sput-object v0, Lb38;->b:Lb38;

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    const/16 v1, 0x1e

    .line 13
    .line 14
    if-lt v0, v1, :cond_1

    .line 15
    .line 16
    sget-object v0, Lu28;->w:Lb38;

    .line 17
    .line 18
    sput-object v0, Lb38;->b:Lb38;

    .line 19
    .line 20
    return-void

    .line 21
    :cond_1
    sget-object v0, Ly28;->b:Lb38;

    .line 22
    .line 23
    sput-object v0, Lb38;->b:Lb38;

    .line 24
    .line 25
    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsets;)V
    .locals 2

    .line 167
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 168
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x23

    if-lt v0, v1, :cond_0

    .line 169
    new-instance v0, Lx28;

    invoke-direct {v0, p0, p1}, Lx28;-><init>(Lb38;Landroid/view/WindowInsets;)V

    iput-object v0, p0, Lb38;->a:Ly28;

    return-void

    :cond_0
    const/16 v1, 0x22

    if-lt v0, v1, :cond_1

    .line 170
    new-instance v0, Lw28;

    invoke-direct {v0, p0, p1}, Lw28;-><init>(Lb38;Landroid/view/WindowInsets;)V

    iput-object v0, p0, Lb38;->a:Ly28;

    return-void

    :cond_1
    const/16 v1, 0x1f

    if-lt v0, v1, :cond_2

    .line 171
    new-instance v0, Lv28;

    invoke-direct {v0, p0, p1}, Lv28;-><init>(Lb38;Landroid/view/WindowInsets;)V

    iput-object v0, p0, Lb38;->a:Ly28;

    return-void

    :cond_2
    const/16 v1, 0x1e

    if-lt v0, v1, :cond_3

    .line 172
    new-instance v0, Lu28;

    invoke-direct {v0, p0, p1}, Lu28;-><init>(Lb38;Landroid/view/WindowInsets;)V

    iput-object v0, p0, Lb38;->a:Ly28;

    return-void

    .line 173
    :cond_3
    new-instance v0, Lt28;

    invoke-direct {v0, p0, p1}, Lt28;-><init>(Lb38;Landroid/view/WindowInsets;)V

    iput-object v0, p0, Lb38;->a:Ly28;

    return-void
.end method

.method public constructor <init>(Lb38;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_8

    .line 5
    .line 6
    iget-object p1, p1, Lb38;->a:Ly28;

    .line 7
    .line 8
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 v1, 0x23

    .line 11
    .line 12
    if-lt v0, v1, :cond_0

    .line 13
    .line 14
    instance-of v1, p1, Lx28;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    new-instance v0, Lx28;

    .line 19
    .line 20
    move-object v1, p1

    .line 21
    check-cast v1, Lx28;

    .line 22
    .line 23
    invoke-direct {v0, p0, v1}, Lx28;-><init>(Lb38;Lx28;)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 27
    .line 28
    goto/16 :goto_0

    .line 29
    .line 30
    :cond_0
    const/16 v1, 0x22

    .line 31
    .line 32
    if-lt v0, v1, :cond_1

    .line 33
    .line 34
    instance-of v1, p1, Lw28;

    .line 35
    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    new-instance v0, Lw28;

    .line 39
    .line 40
    move-object v1, p1

    .line 41
    check-cast v1, Lw28;

    .line 42
    .line 43
    invoke-direct {v0, p0, v1}, Lw28;-><init>(Lb38;Lw28;)V

    .line 44
    .line 45
    .line 46
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 47
    .line 48
    goto/16 :goto_0

    .line 49
    .line 50
    :cond_1
    const/16 v1, 0x1f

    .line 51
    .line 52
    if-lt v0, v1, :cond_2

    .line 53
    .line 54
    instance-of v1, p1, Lv28;

    .line 55
    .line 56
    if-eqz v1, :cond_2

    .line 57
    .line 58
    new-instance v0, Lv28;

    .line 59
    .line 60
    move-object v1, p1

    .line 61
    check-cast v1, Lv28;

    .line 62
    .line 63
    invoke-direct {v0, p0, v1}, Lv28;-><init>(Lb38;Lv28;)V

    .line 64
    .line 65
    .line 66
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_2
    const/16 v1, 0x1e

    .line 70
    .line 71
    if-lt v0, v1, :cond_3

    .line 72
    .line 73
    instance-of v0, p1, Lu28;

    .line 74
    .line 75
    if-eqz v0, :cond_3

    .line 76
    .line 77
    new-instance v0, Lu28;

    .line 78
    .line 79
    move-object v1, p1

    .line 80
    check-cast v1, Lu28;

    .line 81
    .line 82
    invoke-direct {v0, p0, v1}, Lu28;-><init>(Lb38;Lu28;)V

    .line 83
    .line 84
    .line 85
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 86
    .line 87
    goto :goto_0

    .line 88
    :cond_3
    instance-of v0, p1, Lt28;

    .line 89
    .line 90
    if-eqz v0, :cond_4

    .line 91
    .line 92
    new-instance v0, Lt28;

    .line 93
    .line 94
    move-object v1, p1

    .line 95
    check-cast v1, Lt28;

    .line 96
    .line 97
    invoke-direct {v0, p0, v1}, Lt28;-><init>(Lb38;Lt28;)V

    .line 98
    .line 99
    .line 100
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_4
    instance-of v0, p1, Ls28;

    .line 104
    .line 105
    if-eqz v0, :cond_5

    .line 106
    .line 107
    new-instance v0, Ls28;

    .line 108
    .line 109
    move-object v1, p1

    .line 110
    check-cast v1, Ls28;

    .line 111
    .line 112
    invoke-direct {v0, p0, v1}, Ls28;-><init>(Lb38;Ls28;)V

    .line 113
    .line 114
    .line 115
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 116
    .line 117
    goto :goto_0

    .line 118
    :cond_5
    instance-of v0, p1, Lr28;

    .line 119
    .line 120
    if-eqz v0, :cond_6

    .line 121
    .line 122
    new-instance v0, Lr28;

    .line 123
    .line 124
    move-object v1, p1

    .line 125
    check-cast v1, Lr28;

    .line 126
    .line 127
    invoke-direct {v0, p0, v1}, Lr28;-><init>(Lb38;Lr28;)V

    .line 128
    .line 129
    .line 130
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 131
    .line 132
    goto :goto_0

    .line 133
    :cond_6
    instance-of v0, p1, Lq28;

    .line 134
    .line 135
    if-eqz v0, :cond_7

    .line 136
    .line 137
    new-instance v0, Lq28;

    .line 138
    .line 139
    move-object v1, p1

    .line 140
    check-cast v1, Lq28;

    .line 141
    .line 142
    invoke-direct {v0, p0, v1}, Lq28;-><init>(Lb38;Lq28;)V

    .line 143
    .line 144
    .line 145
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 146
    .line 147
    goto :goto_0

    .line 148
    :cond_7
    new-instance v0, Ly28;

    .line 149
    .line 150
    invoke-direct {v0, p0}, Ly28;-><init>(Lb38;)V

    .line 151
    .line 152
    .line 153
    iput-object v0, p0, Lb38;->a:Ly28;

    .line 154
    .line 155
    :goto_0
    invoke-virtual {p1, p0}, Ly28;->e(Lb38;)V

    .line 156
    .line 157
    .line 158
    return-void

    .line 159
    :cond_8
    new-instance p1, Ly28;

    .line 160
    .line 161
    invoke-direct {p1, p0}, Ly28;-><init>(Lb38;)V

    .line 162
    .line 163
    .line 164
    iput-object p1, p0, Lb38;->a:Ly28;

    .line 165
    .line 166
    return-void
.end method

.method public static a(Lm83;IIII)Lm83;
    .locals 5

    .line 1
    iget v0, p0, Lm83;->a:I

    .line 2
    .line 3
    sub-int/2addr v0, p1

    .line 4
    const/4 v1, 0x0

    .line 5
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iget v2, p0, Lm83;->b:I

    .line 10
    .line 11
    sub-int/2addr v2, p2

    .line 12
    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    iget v3, p0, Lm83;->c:I

    .line 17
    .line 18
    sub-int/2addr v3, p3

    .line 19
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    iget v4, p0, Lm83;->d:I

    .line 24
    .line 25
    sub-int/2addr v4, p4

    .line 26
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-ne v0, p1, :cond_0

    .line 31
    .line 32
    if-ne v2, p2, :cond_0

    .line 33
    .line 34
    if-ne v3, p3, :cond_0

    .line 35
    .line 36
    if-ne v1, p4, :cond_0

    .line 37
    .line 38
    return-object p0

    .line 39
    :cond_0
    invoke-static {v0, v2, v3, v1}, Lm83;->b(IIII)Lm83;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method

.method public static c(Landroid/view/WindowInsets;Landroid/view/View;)Lb38;
    .locals 2

    .line 1
    new-instance v0, Lb38;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-direct {v0, p0}, Lb38;-><init>(Landroid/view/WindowInsets;)V

    .line 7
    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/View;->isAttachedToWindow()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-eqz p0, :cond_0

    .line 16
    .line 17
    sget-object p0, Lox7;->a:Ljava/util/WeakHashMap;

    .line 18
    .line 19
    invoke-static {p1}, Ljx7;->a(Landroid/view/View;)Lb38;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    iget-object v1, v0, Lb38;->a:Ly28;

    .line 24
    .line 25
    invoke-virtual {v1, p0}, Ly28;->y(Lb38;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p1}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-virtual {v1, p0}, Ly28;->d(Landroid/view/View;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1, p0}, Ly28;->p(Landroid/view/View;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v1}, Ly28;->q()V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 42
    .line 43
    .line 44
    move-result p0

    .line 45
    invoke-virtual {v1, p0}, Ly28;->z(I)V

    .line 46
    .line 47
    .line 48
    :cond_0
    return-object v0
.end method


# virtual methods
.method public final b()Landroid/view/WindowInsets;
    .locals 1

    .line 1
    iget-object p0, p0, Lb38;->a:Ly28;

    .line 2
    .line 3
    instance-of v0, p0, Lq28;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p0, Lq28;

    .line 8
    .line 9
    iget-object p0, p0, Lq28;->c:Landroid/view/WindowInsets;

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_0
    const/4 p0, 0x0

    .line 13
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    const/4 p0, 0x1

    .line 4
    return p0

    .line 5
    :cond_0
    instance-of v0, p1, Lb38;

    .line 6
    .line 7
    if-nez v0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_1
    check-cast p1, Lb38;

    .line 12
    .line 13
    iget-object p0, p0, Lb38;->a:Ly28;

    .line 14
    .line 15
    iget-object p1, p1, Lb38;->a:Ly28;

    .line 16
    .line 17
    invoke-static {p0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lb38;->a:Ly28;

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_0
    invoke-virtual {p0}, Ly28;->hashCode()I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method
