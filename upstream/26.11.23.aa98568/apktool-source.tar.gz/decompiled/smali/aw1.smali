.class public final Law1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public a:Luc;

.field public b:Lea;

.field public c:J

.field public d:Z

.field public final e:Ltl0;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-wide/16 v0, 0x0

    .line 5
    .line 6
    iput-wide v0, p0, Law1;->c:J

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-boolean v0, p0, Law1;->d:Z

    .line 10
    .line 11
    new-instance v0, Ltl0;

    .line 12
    .line 13
    invoke-direct {v0}, Ltl0;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Law1;->e:Ltl0;

    .line 17
    .line 18
    return-void
.end method
