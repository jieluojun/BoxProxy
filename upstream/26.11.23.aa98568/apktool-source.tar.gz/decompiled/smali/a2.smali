.class public final synthetic La2;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/String;

.field public final synthetic j:Lwh2;


# direct methods
.method public synthetic constructor <init>(BLwh2;Ljava/lang/String;)V
    .locals 0

    .line 12
    iput-byte p1, p0, La2;->h:B

    iput-object p3, p0, La2;->i:Ljava/lang/String;

    iput-object p2, p0, La2;->j:Lwh2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lwh2;I)V
    .locals 0

    .line 13
    const/4 p3, 0x3

    iput-byte p3, p0, La2;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La2;->i:Ljava/lang/String;

    iput-object p2, p0, La2;->j:Lwh2;

    return-void
.end method

.method public synthetic constructor <init>(Lwh2;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, La2;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La2;->j:Lwh2;

    .line 8
    .line 9
    iput-object p2, p0, La2;->i:Ljava/lang/String;

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La2;->h:B

    .line 4
    .line 5
    sget-object v2, Lc51;->a:Lql0;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x1

    .line 9
    iget-object v5, v0, La2;->j:Lwh2;

    .line 10
    .line 11
    iget-object v6, v0, La2;->i:Ljava/lang/String;

    .line 12
    .line 13
    sget-object v7, Lst7;->a:Lst7;

    .line 14
    .line 15
    const/4 v8, 0x2

    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object/from16 v15, p1

    .line 20
    .line 21
    check-cast v15, Lzi2;

    .line 22
    .line 23
    move-object/from16 v0, p2

    .line 24
    .line 25
    check-cast v0, Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    and-int/lit8 v1, v0, 0x3

    .line 32
    .line 33
    if-eq v1, v8, :cond_0

    .line 34
    .line 35
    move v1, v4

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move v1, v3

    .line 38
    :goto_0
    and-int/2addr v0, v4

    .line 39
    invoke-virtual {v15, v0, v1}, Lzi2;->Y(IZ)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_4

    .line 44
    .line 45
    invoke-static {v6}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-nez v0, :cond_3

    .line 50
    .line 51
    const v0, 0x568f1a70

    .line 52
    .line 53
    .line 54
    invoke-virtual {v15, v0}, Lzi2;->h0(I)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v15, v5}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    invoke-virtual {v15}, Lzi2;->T()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    if-nez v0, :cond_1

    .line 66
    .line 67
    if-ne v1, v2, :cond_2

    .line 68
    .line 69
    :cond_1
    new-instance v1, Lol;

    .line 70
    .line 71
    const/16 v0, 0x1d

    .line 72
    .line 73
    invoke-direct {v1, v5, v0}, Lol;-><init>(Lwh2;B)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v15, v1}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :cond_2
    move-object v9, v1

    .line 80
    check-cast v9, Llh2;

    .line 81
    .line 82
    sget-object v14, Lah0;->x:Ls21;

    .line 83
    .line 84
    const/high16 v16, 0x180000

    .line 85
    .line 86
    const/16 v17, 0x3e

    .line 87
    .line 88
    const/4 v10, 0x0

    .line 89
    const/4 v11, 0x0

    .line 90
    const/4 v12, 0x0

    .line 91
    const/4 v13, 0x0

    .line 92
    invoke-static/range {v9 .. v17}, Lhw;->u(Llh2;Lbb4;ZLi43;Lbo6;Lai2;Lzi2;II)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v15, v3}, Lzi2;->r(Z)V

    .line 96
    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_3
    const v0, 0x56949a27    # 8.16949E13f

    .line 100
    .line 101
    .line 102
    invoke-virtual {v15, v0}, Lzi2;->h0(I)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v15, v3}, Lzi2;->r(Z)V

    .line 106
    .line 107
    .line 108
    goto :goto_1

    .line 109
    :cond_4
    invoke-virtual {v15}, Lzi2;->b0()V

    .line 110
    .line 111
    .line 112
    :goto_1
    return-object v7

    .line 113
    :pswitch_0
    move-object/from16 v0, p1

    .line 114
    .line 115
    check-cast v0, Lzi2;

    .line 116
    .line 117
    move-object/from16 v1, p2

    .line 118
    .line 119
    check-cast v1, Ljava/lang/Integer;

    .line 120
    .line 121
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    and-int/lit8 v9, v1, 0x3

    .line 126
    .line 127
    if-eq v9, v8, :cond_5

    .line 128
    .line 129
    move v8, v4

    .line 130
    goto :goto_2

    .line 131
    :cond_5
    move v8, v3

    .line 132
    :goto_2
    and-int/2addr v1, v4

    .line 133
    invoke-virtual {v0, v1, v8}, Lzi2;->Y(IZ)Z

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    if-eqz v1, :cond_9

    .line 138
    .line 139
    invoke-static {v6}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    if-nez v1, :cond_8

    .line 144
    .line 145
    const v1, 0x4a44f068    # 3226650.0f

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v0, v5}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    invoke-virtual {v0}, Lzi2;->T()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v4

    .line 159
    if-nez v1, :cond_6

    .line 160
    .line 161
    if-ne v4, v2, :cond_7

    .line 162
    .line 163
    :cond_6
    new-instance v4, Lol;

    .line 164
    .line 165
    const/16 v1, 0x1c

    .line 166
    .line 167
    invoke-direct {v4, v5, v1}, Lol;-><init>(Lwh2;B)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v0, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    :cond_7
    move-object/from16 v16, v4

    .line 174
    .line 175
    check-cast v16, Llh2;

    .line 176
    .line 177
    sget-object v21, Lm80;->K:Ls21;

    .line 178
    .line 179
    const/high16 v23, 0x180000

    .line 180
    .line 181
    const/16 v24, 0x3e

    .line 182
    .line 183
    const/16 v17, 0x0

    .line 184
    .line 185
    const/16 v18, 0x0

    .line 186
    .line 187
    const/16 v19, 0x0

    .line 188
    .line 189
    const/16 v20, 0x0

    .line 190
    .line 191
    move-object/from16 v22, v0

    .line 192
    .line 193
    invoke-static/range {v16 .. v24}, Lhw;->u(Llh2;Lbb4;ZLi43;Lbo6;Lai2;Lzi2;II)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v0, v3}, Lzi2;->r(Z)V

    .line 197
    .line 198
    .line 199
    goto :goto_3

    .line 200
    :cond_8
    const v1, 0x4a499de7    # 3303289.8f

    .line 201
    .line 202
    .line 203
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v0, v3}, Lzi2;->r(Z)V

    .line 207
    .line 208
    .line 209
    goto :goto_3

    .line 210
    :cond_9
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 211
    .line 212
    .line 213
    :goto_3
    return-object v7

    .line 214
    :pswitch_1
    move-object/from16 v0, p1

    .line 215
    .line 216
    check-cast v0, Lzi2;

    .line 217
    .line 218
    move-object/from16 v1, p2

    .line 219
    .line 220
    check-cast v1, Ljava/lang/Integer;

    .line 221
    .line 222
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 223
    .line 224
    .line 225
    const/16 v1, 0x31

    .line 226
    .line 227
    invoke-static {v1}, Lyj3;->j0(I)I

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    invoke-static {v1, v5, v0, v6}, Lm80;->u(ILwh2;Lzi2;Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    return-object v7

    .line 235
    :pswitch_2
    move-object/from16 v12, p1

    .line 236
    .line 237
    check-cast v12, Lzi2;

    .line 238
    .line 239
    move-object/from16 v1, p2

    .line 240
    .line 241
    check-cast v1, Ljava/lang/Integer;

    .line 242
    .line 243
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 244
    .line 245
    .line 246
    move-result v1

    .line 247
    and-int/lit8 v2, v1, 0x3

    .line 248
    .line 249
    if-eq v2, v8, :cond_a

    .line 250
    .line 251
    move v3, v4

    .line 252
    :cond_a
    and-int/2addr v1, v4

    .line 253
    invoke-virtual {v12, v1, v3}, Lzi2;->Y(IZ)Z

    .line 254
    .line 255
    .line 256
    move-result v1

    .line 257
    if-eqz v1, :cond_b

    .line 258
    .line 259
    const v1, 0x7f0f0338

    .line 260
    .line 261
    .line 262
    invoke-static {v1, v12}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v9

    .line 266
    const/4 v10, 0x1

    .line 267
    const/16 v13, 0x180

    .line 268
    .line 269
    iget-object v8, v0, La2;->i:Ljava/lang/String;

    .line 270
    .line 271
    iget-object v11, v0, La2;->j:Lwh2;

    .line 272
    .line 273
    invoke-static/range {v8 .. v13}, Luu4;->f(Ljava/lang/String;Ljava/lang/String;ZLwh2;Lzi2;I)V

    .line 274
    .line 275
    .line 276
    goto :goto_4

    .line 277
    :cond_b
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 278
    .line 279
    .line 280
    :goto_4
    return-object v7

    .line 281
    :pswitch_3
    move-object/from16 v0, p1

    .line 282
    .line 283
    check-cast v0, Lzi2;

    .line 284
    .line 285
    move-object/from16 v1, p2

    .line 286
    .line 287
    check-cast v1, Ljava/lang/Integer;

    .line 288
    .line 289
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 290
    .line 291
    .line 292
    move-result v1

    .line 293
    and-int/lit8 v9, v1, 0x3

    .line 294
    .line 295
    if-eq v9, v8, :cond_c

    .line 296
    .line 297
    move v8, v4

    .line 298
    goto :goto_5

    .line 299
    :cond_c
    move v8, v3

    .line 300
    :goto_5
    and-int/2addr v1, v4

    .line 301
    invoke-virtual {v0, v1, v8}, Lzi2;->Y(IZ)Z

    .line 302
    .line 303
    .line 304
    move-result v1

    .line 305
    if-eqz v1, :cond_10

    .line 306
    .line 307
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 308
    .line 309
    .line 310
    move-result v1

    .line 311
    if-lez v1, :cond_f

    .line 312
    .line 313
    const v1, 0x171f86e4

    .line 314
    .line 315
    .line 316
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 317
    .line 318
    .line 319
    invoke-virtual {v0, v5}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 320
    .line 321
    .line 322
    move-result v1

    .line 323
    invoke-virtual {v0}, Lzi2;->T()Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    move-result-object v4

    .line 327
    if-nez v1, :cond_d

    .line 328
    .line 329
    if-ne v4, v2, :cond_e

    .line 330
    .line 331
    :cond_d
    new-instance v4, Lol;

    .line 332
    .line 333
    const/16 v1, 0x11

    .line 334
    .line 335
    invoke-direct {v4, v5, v1}, Lol;-><init>(Lwh2;B)V

    .line 336
    .line 337
    .line 338
    invoke-virtual {v0, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 339
    .line 340
    .line 341
    :cond_e
    move-object v13, v4

    .line 342
    check-cast v13, Llh2;

    .line 343
    .line 344
    sget-object v18, Lt50;->t:Ls21;

    .line 345
    .line 346
    const/high16 v20, 0x180000

    .line 347
    .line 348
    const/16 v21, 0x3e

    .line 349
    .line 350
    const/4 v14, 0x0

    .line 351
    const/4 v15, 0x0

    .line 352
    const/16 v16, 0x0

    .line 353
    .line 354
    const/16 v17, 0x0

    .line 355
    .line 356
    move-object/from16 v19, v0

    .line 357
    .line 358
    invoke-static/range {v13 .. v21}, Lhw;->u(Llh2;Lbb4;ZLi43;Lbo6;Lai2;Lzi2;II)V

    .line 359
    .line 360
    .line 361
    invoke-virtual {v0, v3}, Lzi2;->r(Z)V

    .line 362
    .line 363
    .line 364
    goto :goto_6

    .line 365
    :cond_f
    const v1, 0x1722796d

    .line 366
    .line 367
    .line 368
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 369
    .line 370
    .line 371
    invoke-virtual {v0, v3}, Lzi2;->r(Z)V

    .line 372
    .line 373
    .line 374
    goto :goto_6

    .line 375
    :cond_10
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 376
    .line 377
    .line 378
    :goto_6
    return-object v7

    .line 379
    :pswitch_4
    move-object/from16 v14, p1

    .line 380
    .line 381
    check-cast v14, Lzi2;

    .line 382
    .line 383
    move-object/from16 v0, p2

    .line 384
    .line 385
    check-cast v0, Ljava/lang/Integer;

    .line 386
    .line 387
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 388
    .line 389
    .line 390
    move-result v0

    .line 391
    and-int/lit8 v1, v0, 0x3

    .line 392
    .line 393
    if-eq v1, v8, :cond_11

    .line 394
    .line 395
    move v3, v4

    .line 396
    :cond_11
    and-int/2addr v0, v4

    .line 397
    invoke-virtual {v14, v0, v3}, Lzi2;->Y(IZ)Z

    .line 398
    .line 399
    .line 400
    move-result v0

    .line 401
    if-eqz v0, :cond_14

    .line 402
    .line 403
    invoke-virtual {v14, v5}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 404
    .line 405
    .line 406
    move-result v0

    .line 407
    invoke-virtual {v14, v6}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 408
    .line 409
    .line 410
    move-result v1

    .line 411
    or-int/2addr v0, v1

    .line 412
    invoke-virtual {v14}, Lzi2;->T()Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object v1

    .line 416
    if-nez v0, :cond_12

    .line 417
    .line 418
    if-ne v1, v2, :cond_13

    .line 419
    .line 420
    :cond_12
    new-instance v1, Lu;

    .line 421
    .line 422
    invoke-direct {v1, v8, v5, v6}, Lu;-><init>(BLwh2;Ljava/lang/String;)V

    .line 423
    .line 424
    .line 425
    invoke-virtual {v14, v1}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 426
    .line 427
    .line 428
    :cond_13
    move-object v8, v1

    .line 429
    check-cast v8, Llh2;

    .line 430
    .line 431
    sget-object v13, Ln14;->l:Ls21;

    .line 432
    .line 433
    const/high16 v15, 0x180000

    .line 434
    .line 435
    const/16 v16, 0x3e

    .line 436
    .line 437
    const/4 v9, 0x0

    .line 438
    const/4 v10, 0x0

    .line 439
    const/4 v11, 0x0

    .line 440
    const/4 v12, 0x0

    .line 441
    invoke-static/range {v8 .. v16}, Lhw;->u(Llh2;Lbb4;ZLi43;Lbo6;Lai2;Lzi2;II)V

    .line 442
    .line 443
    .line 444
    goto :goto_7

    .line 445
    :cond_14
    invoke-virtual {v14}, Lzi2;->b0()V

    .line 446
    .line 447
    .line 448
    :goto_7
    return-object v7

    .line 449
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
.end method
