.class public final La61;
.super Lzh5;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final synthetic b:B

.field public final c:Lc61;


# direct methods
.method public constructor <init>(Lwh2;B)V
    .locals 1

    .line 1
    iput-byte p2, p0, La61;->b:B

    .line 2
    .line 3
    packed-switch p2, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance p2, Lz21;

    .line 7
    .line 8
    const/16 v0, 0xb

    .line 9
    .line 10
    invoke-direct {p2, v0}, Lz21;-><init>(B)V

    .line 11
    .line 12
    .line 13
    invoke-direct {p0, p2}, Lzh5;-><init>(Llh2;)V

    .line 14
    .line 15
    .line 16
    new-instance p2, Lc61;

    .line 17
    .line 18
    invoke-direct {p2, p1}, Lc61;-><init>(Lwh2;)V

    .line 19
    .line 20
    .line 21
    iput-object p2, p0, La61;->c:Lc61;

    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_0
    new-instance p2, Las6;

    .line 25
    .line 26
    const/4 v0, 0x4

    .line 27
    invoke-direct {p2, v0}, Las6;-><init>(B)V

    .line 28
    .line 29
    .line 30
    invoke-direct {p0, p2}, Lzh5;-><init>(Llh2;)V

    .line 31
    .line 32
    .line 33
    new-instance p2, Lc61;

    .line 34
    .line 35
    invoke-direct {p2, p1}, Lc61;-><init>(Lwh2;)V

    .line 36
    .line 37
    .line 38
    iput-object p2, p0, La61;->c:Lc61;

    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Lci5;
    .locals 12

    .line 1
    iget-byte v0, p0, La61;->b:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance v3, Lci5;

    .line 9
    .line 10
    if-nez p1, :cond_0

    .line 11
    .line 12
    move v6, v2

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move v6, v1

    .line 15
    :goto_0
    const/4 v9, 0x0

    .line 16
    const/4 v10, 0x0

    .line 17
    const/4 v7, 0x0

    .line 18
    const/4 v8, 0x0

    .line 19
    move-object v4, p0

    .line 20
    move-object v5, p1

    .line 21
    invoke-direct/range {v3 .. v10}, Lci5;-><init>(Lzh5;Ljava/lang/Object;ZLhw6;Lz75;Lwh2;Z)V

    .line 22
    .line 23
    .line 24
    return-object v3

    .line 25
    :pswitch_0
    move-object v4, p0

    .line 26
    move-object v5, p1

    .line 27
    new-instance p0, Lci5;

    .line 28
    .line 29
    if-nez v5, :cond_1

    .line 30
    .line 31
    move v7, v2

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    move v7, v1

    .line 34
    :goto_1
    const/4 v10, 0x0

    .line 35
    const/4 v11, 0x1

    .line 36
    const/4 v8, 0x0

    .line 37
    const/4 v9, 0x0

    .line 38
    move-object v6, v5

    .line 39
    move-object v5, v4

    .line 40
    move-object v4, p0

    .line 41
    invoke-direct/range {v4 .. v11}, Lci5;-><init>(Lzh5;Ljava/lang/Object;ZLhw6;Lz75;Lwh2;Z)V

    .line 42
    .line 43
    .line 44
    return-object v4

    .line 45
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public final b()Lcv7;
    .locals 1

    .line 1
    iget-byte v0, p0, La61;->b:B

    .line 2
    .line 3
    iget-object p0, p0, La61;->c:Lc61;

    .line 4
    .line 5
    return-object p0
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
