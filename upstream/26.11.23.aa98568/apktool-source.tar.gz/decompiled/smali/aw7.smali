.class public final Law7;
.super Lab4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lcw1;


# instance fields
.field public v:Lpo7;

.field public w:Ly32;

.field public x:Lr52;

.field public y:Lso6;


# virtual methods
.method public final l0(Lbj3;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual/range {p1 .. p1}, Lbj3;->c()V

    .line 4
    .line 5
    .line 6
    iget-object v1, v0, Law7;->v:Lpo7;

    .line 7
    .line 8
    new-instance v2, Lhp7;

    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    invoke-direct {v2, v0, v3}, Lhp7;-><init>(Ljava/lang/Object;B)V

    .line 12
    .line 13
    .line 14
    iget-object v4, v0, Law7;->y:Lso6;

    .line 15
    .line 16
    invoke-virtual {v4}, Lso6;->b()Z

    .line 17
    .line 18
    .line 19
    move-result v5

    .line 20
    const/4 v6, 0x0

    .line 21
    if-eqz v5, :cond_0

    .line 22
    .line 23
    iget-wide v4, v4, Lso6;->e:J

    .line 24
    .line 25
    new-instance v7, Lgy0;

    .line 26
    .line 27
    invoke-direct {v7, v4, v5}, Lgy0;-><init>(J)V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move-object v7, v6

    .line 32
    :goto_0
    new-instance v4, Lvd;

    .line 33
    .line 34
    const/16 v5, 0xb

    .line 35
    .line 36
    invoke-direct {v4, v0, v5}, Lvd;-><init>(Ljava/lang/Object;B)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1, v2, v7, v6, v4}, Lpo7;->a(Lwh2;Ljava/lang/Object;Lbj;Lwh2;)Loo7;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    iget-object v2, v0, Law7;->y:Lso6;

    .line 44
    .line 45
    invoke-virtual {v1}, Loo7;->getValue()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    check-cast v1, Lgy0;

    .line 50
    .line 51
    iget-wide v4, v1, Lgy0;->a:J

    .line 52
    .line 53
    iget-object v1, v2, Lso6;->c:Lo50;

    .line 54
    .line 55
    iget-object v6, v2, Lso6;->v:Lvj3;

    .line 56
    .line 57
    iput-wide v4, v2, Lso6;->m:J

    .line 58
    .line 59
    invoke-virtual {v2}, Lso6;->c()Z

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    if-eqz v7, :cond_1

    .line 64
    .line 65
    invoke-virtual {v1}, Lo50;->e()Z

    .line 66
    .line 67
    .line 68
    move-result v7

    .line 69
    if-eqz v7, :cond_1

    .line 70
    .line 71
    move v7, v3

    .line 72
    goto :goto_1

    .line 73
    :cond_1
    const/4 v7, 0x0

    .line 74
    :goto_1
    sget-object v8, Lbf4;->j:Lbf4;

    .line 75
    .line 76
    if-eqz v7, :cond_3

    .line 77
    .line 78
    invoke-virtual {v2}, Lso6;->a()Lbf4;

    .line 79
    .line 80
    .line 81
    move-result-object v9

    .line 82
    if-ne v9, v8, :cond_3

    .line 83
    .line 84
    invoke-interface {v6}, Lvj3;->getValue()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v9

    .line 88
    check-cast v9, Lrg;

    .line 89
    .line 90
    invoke-virtual {v9}, Lrg;->g()Z

    .line 91
    .line 92
    .line 93
    move-result v9

    .line 94
    if-eqz v9, :cond_3

    .line 95
    .line 96
    invoke-interface {v6}, Lvj3;->getValue()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    check-cast v1, Lrg;

    .line 101
    .line 102
    invoke-virtual {v1}, Lrg;->e()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    check-cast v1, Lgy0;

    .line 107
    .line 108
    iget-wide v4, v1, Lgy0;->a:J

    .line 109
    .line 110
    :cond_2
    :goto_2
    move-wide v7, v4

    .line 111
    goto :goto_3

    .line 112
    :cond_3
    if-eqz v7, :cond_2

    .line 113
    .line 114
    invoke-virtual {v2}, Lso6;->a()Lbf4;

    .line 115
    .line 116
    .line 117
    move-result-object v6

    .line 118
    if-eq v6, v8, :cond_4

    .line 119
    .line 120
    invoke-virtual {v2}, Lso6;->a()Lbf4;

    .line 121
    .line 122
    .line 123
    move-result-object v6

    .line 124
    sget-object v7, Lbf4;->k:Lbf4;

    .line 125
    .line 126
    if-ne v6, v7, :cond_2

    .line 127
    .line 128
    :cond_4
    iget-object v1, v1, Lo50;->h:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast v1, Lz75;

    .line 131
    .line 132
    invoke-virtual {v1}, Lz75;->getValue()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    check-cast v1, Lgy0;

    .line 137
    .line 138
    iget-wide v4, v1, Lgy0;->a:J

    .line 139
    .line 140
    goto :goto_2

    .line 141
    :goto_3
    invoke-virtual {v2}, Lso6;->c()Z

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    if-eqz v1, :cond_5

    .line 146
    .line 147
    iput-wide v7, v2, Lso6;->e:J

    .line 148
    .line 149
    :cond_5
    invoke-static {v7, v8}, Lgy0;->c(J)F

    .line 150
    .line 151
    .line 152
    move-result v1

    .line 153
    const/4 v2, 0x0

    .line 154
    cmpg-float v1, v1, v2

    .line 155
    .line 156
    if-nez v1, :cond_6

    .line 157
    .line 158
    return-void

    .line 159
    :cond_6
    iget-object v1, v0, Law7;->w:Ly32;

    .line 160
    .line 161
    iget-object v1, v1, Ly32;->a:Lo32;

    .line 162
    .line 163
    iget-object v1, v1, Lo32;->e:Lyv7;

    .line 164
    .line 165
    if-nez v1, :cond_7

    .line 166
    .line 167
    iget-object v1, v0, Law7;->x:Lr52;

    .line 168
    .line 169
    iget-object v1, v1, Lr52;->a:Lo32;

    .line 170
    .line 171
    iget-object v1, v1, Lo32;->e:Lyv7;

    .line 172
    .line 173
    :cond_7
    if-eqz v1, :cond_a

    .line 174
    .line 175
    iget-boolean v1, v1, Lyv7;->d:Z

    .line 176
    .line 177
    if-ne v1, v3, :cond_a

    .line 178
    .line 179
    invoke-static {v0}, Lsx;->k0(Lap1;)Lbt4;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    invoke-virtual {v0}, Lbt4;->k()Lhi3;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    const-wide/16 v2, 0x0

    .line 188
    .line 189
    if-eqz v1, :cond_8

    .line 190
    .line 191
    check-cast v1, Lbt4;

    .line 192
    .line 193
    iget-wide v4, v1, Lfb5;->j:J

    .line 194
    .line 195
    const/16 v1, 0x20

    .line 196
    .line 197
    shr-long v9, v4, v1

    .line 198
    .line 199
    long-to-int v6, v9

    .line 200
    int-to-float v6, v6

    .line 201
    const-wide v9, 0xffffffffL

    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    and-long/2addr v4, v9

    .line 207
    long-to-int v4, v4

    .line 208
    int-to-float v4, v4

    .line 209
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 210
    .line 211
    .line 212
    move-result v5

    .line 213
    int-to-long v5, v5

    .line 214
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 215
    .line 216
    .line 217
    move-result v4

    .line 218
    int-to-long v11, v4

    .line 219
    shl-long/2addr v5, v1

    .line 220
    and-long/2addr v11, v9

    .line 221
    or-long/2addr v5, v11

    .line 222
    move-wide v11, v5

    .line 223
    goto :goto_4

    .line 224
    :cond_8
    move-wide v11, v2

    .line 225
    :goto_4
    invoke-virtual {v0}, Lbt4;->k()Lhi3;

    .line 226
    .line 227
    .line 228
    move-result-object v1

    .line 229
    if-eqz v1, :cond_9

    .line 230
    .line 231
    check-cast v1, Lbt4;

    .line 232
    .line 233
    invoke-virtual {v1, v0, v2, v3}, Lbt4;->E(Lhi3;J)J

    .line 234
    .line 235
    .line 236
    move-result-wide v2

    .line 237
    :cond_9
    const-wide v0, -0x7fffffff80000000L    # -1.0609978955E-314

    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    xor-long v9, v2, v0

    .line 243
    .line 244
    const/4 v14, 0x0

    .line 245
    const/16 v15, 0x78

    .line 246
    .line 247
    const/4 v13, 0x0

    .line 248
    move-object/from16 v6, p1

    .line 249
    .line 250
    invoke-static/range {v6 .. v15}, Ldw1;->n0(Ldw1;JJJFII)V

    .line 251
    .line 252
    .line 253
    return-void

    .line 254
    :cond_a
    const/4 v14, 0x0

    .line 255
    const/16 v15, 0x7e

    .line 256
    .line 257
    const-wide/16 v9, 0x0

    .line 258
    .line 259
    const-wide/16 v11, 0x0

    .line 260
    .line 261
    const/4 v13, 0x0

    .line 262
    move-object/from16 v6, p1

    .line 263
    .line 264
    invoke-static/range {v6 .. v15}, Ldw1;->n0(Ldw1;JJJFII)V

    .line 265
    .line 266
    .line 267
    return-void
.end method
