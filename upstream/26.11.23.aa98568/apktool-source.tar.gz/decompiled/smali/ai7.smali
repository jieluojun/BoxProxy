.class public final Lai7;
.super Lab4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lqi3;
.implements Lcw1;
.implements Lcl6;


# instance fields
.field public A:Z

.field public B:I

.field public C:I

.field public D:Lky0;

.field public E:Ljava/util/HashMap;

.field public F:Lq75;

.field public G:Lyh7;

.field public H:Lzh7;

.field public v:Ljava/lang/String;

.field public w:Lbi7;

.field public x:Lff2;

.field public y:Lfu3;

.field public z:I


# virtual methods
.method public final G1()Lq75;
    .locals 9

    .line 1
    iget-object v2, p0, Lai7;->w:Lbi7;

    .line 2
    .line 3
    iget-object v0, p0, Lai7;->F:Lq75;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Lq75;

    .line 8
    .line 9
    iget-object v1, p0, Lai7;->v:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v3, p0, Lai7;->x:Lff2;

    .line 12
    .line 13
    iget-object v4, p0, Lai7;->y:Lfu3;

    .line 14
    .line 15
    iget v5, p0, Lai7;->z:I

    .line 16
    .line 17
    iget-boolean v6, p0, Lai7;->A:Z

    .line 18
    .line 19
    iget v7, p0, Lai7;->B:I

    .line 20
    .line 21
    iget v8, p0, Lai7;->C:I

    .line 22
    .line 23
    invoke-direct/range {v0 .. v8}, Lq75;-><init>(Ljava/lang/String;Lbi7;Lff2;Lfu3;IZII)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, Lai7;->F:Lq75;

    .line 27
    .line 28
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    return-object v0
    .line 32
.end method

.method public final R0(Lll6;)V
    .locals 7

    .line 1
    iget-object v0, p0, Lai7;->G:Lyh7;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lyh7;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {v0, p0, v1}, Lyh7;-><init>(Lai7;B)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lai7;->G:Lyh7;

    .line 12
    .line 13
    :cond_0
    new-instance v1, Lij;

    .line 14
    .line 15
    iget-object v2, p0, Lai7;->v:Ljava/lang/String;

    .line 16
    .line 17
    invoke-direct {v1, v2}, Lij;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    sget-object v2, Ljl6;->a:[Ldg3;

    .line 21
    .line 22
    sget-object v2, Lil6;->D:Lkl6;

    .line 23
    .line 24
    invoke-static {v1}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-interface {p1, v2, v1}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, Lai7;->H:Lzh7;

    .line 32
    .line 33
    const/16 v2, 0x13

    .line 34
    .line 35
    if-eqz v1, :cond_1

    .line 36
    .line 37
    iget-boolean v3, v1, Lzh7;->c:Z

    .line 38
    .line 39
    sget-object v4, Lil6;->F:Lkl6;

    .line 40
    .line 41
    sget-object v5, Ljl6;->a:[Ldg3;

    .line 42
    .line 43
    aget-object v6, v5, v2

    .line 44
    .line 45
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    invoke-interface {p1, v4, v3}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    new-instance v3, Lij;

    .line 56
    .line 57
    iget-object v1, v1, Lzh7;->b:Ljava/lang/String;

    .line 58
    .line 59
    invoke-direct {v3, v1}, Lij;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    sget-object v1, Lil6;->E:Lkl6;

    .line 63
    .line 64
    const/16 v4, 0x12

    .line 65
    .line 66
    aget-object v4, v5, v4

    .line 67
    .line 68
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    invoke-interface {p1, v1, v3}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    :cond_1
    new-instance v1, Lyh7;

    .line 75
    .line 76
    const/4 v3, 0x1

    .line 77
    invoke-direct {v1, p0, v3}, Lyh7;-><init>(Lai7;B)V

    .line 78
    .line 79
    .line 80
    sget-object v3, Lyk6;->l:Lkl6;

    .line 81
    .line 82
    new-instance v4, Lu4;

    .line 83
    .line 84
    const/4 v5, 0x0

    .line 85
    invoke-direct {v4, v5, v1}, Lu4;-><init>(Ljava/lang/String;Lii2;)V

    .line 86
    .line 87
    .line 88
    invoke-interface {p1, v3, v4}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    new-instance v1, Lyh7;

    .line 92
    .line 93
    const/4 v3, 0x2

    .line 94
    invoke-direct {v1, p0, v3}, Lyh7;-><init>(Lai7;B)V

    .line 95
    .line 96
    .line 97
    sget-object v3, Lyk6;->m:Lkl6;

    .line 98
    .line 99
    new-instance v4, Lu4;

    .line 100
    .line 101
    invoke-direct {v4, v5, v1}, Lu4;-><init>(Ljava/lang/String;Lii2;)V

    .line 102
    .line 103
    .line 104
    invoke-interface {p1, v3, v4}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    new-instance v1, Lqd6;

    .line 108
    .line 109
    invoke-direct {v1, p0, v2}, Lqd6;-><init>(Ljava/lang/Object;B)V

    .line 110
    .line 111
    .line 112
    sget-object p0, Lyk6;->n:Lkl6;

    .line 113
    .line 114
    new-instance v2, Lu4;

    .line 115
    .line 116
    invoke-direct {v2, v5, v1}, Lu4;-><init>(Ljava/lang/String;Lii2;)V

    .line 117
    .line 118
    .line 119
    invoke-interface {p1, p0, v2}, Lll6;->a(Lkl6;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-static {p1, v0}, Ljl6;->b(Lll6;Lwh2;)V

    .line 123
    .line 124
    .line 125
    return-void
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method

.method public final c(Lcx3;Lp14;I)I
    .locals 0

    .line 1
    iget-object p2, p0, Lai7;->H:Lzh7;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean p3, p2, Lzh7;->c:Z

    .line 6
    .line 7
    if-nez p3, :cond_0

    .line 8
    .line 9
    const/4 p2, 0x0

    .line 10
    :cond_0
    if-eqz p2, :cond_1

    .line 11
    .line 12
    iget-object p2, p2, Lzh7;->d:Lq75;

    .line 13
    .line 14
    if-nez p2, :cond_2

    .line 15
    .line 16
    :cond_1
    invoke-virtual {p0}, Lai7;->G1()Lq75;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    :cond_2
    invoke-virtual {p2, p1}, Lq75;->c(Ly14;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {p2, p0}, Lq75;->d(Lii3;)Lp75;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lfd;

    .line 32
    .line 33
    iget-object p0, p0, Lfd;->k:Lni3;

    .line 34
    .line 35
    invoke-virtual {p0}, Lni3;->c()F

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    invoke-static {p0}, Lx67;->e(F)I

    .line 40
    .line 41
    .line 42
    move-result p0

    .line 43
    return p0
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final e(Lcx3;Lp14;I)I
    .locals 1

    .line 1
    iget-object p2, p0, Lai7;->H:Lzh7;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean v0, p2, Lzh7;->c:Z

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    const/4 p2, 0x0

    .line 10
    :cond_0
    if-eqz p2, :cond_1

    .line 11
    .line 12
    iget-object p2, p2, Lzh7;->d:Lq75;

    .line 13
    .line 14
    if-nez p2, :cond_2

    .line 15
    .line 16
    :cond_1
    invoke-virtual {p0}, Lai7;->G1()Lq75;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    :cond_2
    invoke-virtual {p2, p1}, Lq75;->c(Ly14;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {p2, p3, p0}, Lq75;->a(ILii3;)I

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    return p0
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final i(Lcx3;Lp14;I)I
    .locals 1

    .line 1
    iget-object p2, p0, Lai7;->H:Lzh7;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean v0, p2, Lzh7;->c:Z

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    const/4 p2, 0x0

    .line 10
    :cond_0
    if-eqz p2, :cond_1

    .line 11
    .line 12
    iget-object p2, p2, Lzh7;->d:Lq75;

    .line 13
    .line 14
    if-nez p2, :cond_2

    .line 15
    .line 16
    :cond_1
    invoke-virtual {p0}, Lai7;->G1()Lq75;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    :cond_2
    invoke-virtual {p2, p1}, Lq75;->c(Ly14;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {p2, p3, p0}, Lq75;->a(ILii3;)I

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    return p0
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final l(Lcx3;Lp14;I)I
    .locals 0

    .line 1
    iget-object p2, p0, Lai7;->H:Lzh7;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean p3, p2, Lzh7;->c:Z

    .line 6
    .line 7
    if-nez p3, :cond_0

    .line 8
    .line 9
    const/4 p2, 0x0

    .line 10
    :cond_0
    if-eqz p2, :cond_1

    .line 11
    .line 12
    iget-object p2, p2, Lzh7;->d:Lq75;

    .line 13
    .line 14
    if-nez p2, :cond_2

    .line 15
    .line 16
    :cond_1
    invoke-virtual {p0}, Lai7;->G1()Lq75;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    :cond_2
    invoke-virtual {p2, p1}, Lq75;->c(Ly14;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {p2, p0}, Lq75;->d(Lii3;)Lp75;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lfd;

    .line 32
    .line 33
    invoke-virtual {p0}, Lfd;->b()F

    .line 34
    .line 35
    .line 36
    move-result p0

    .line 37
    invoke-static {p0}, Lx67;->e(F)I

    .line 38
    .line 39
    .line 40
    move-result p0

    .line 41
    return p0
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final l0(Lbj3;)V
    .locals 10

    .line 1
    iget-boolean v0, p0, Lab4;->u:Z

    .line 2
    .line 3
    if-eqz v0, :cond_b

    .line 4
    .line 5
    iget-object v0, p0, Lai7;->H:Lzh7;

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-boolean v1, v0, Lzh7;->c:Z

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    :cond_0
    if-eqz v0, :cond_1

    .line 15
    .line 16
    iget-object v0, v0, Lzh7;->d:Lq75;

    .line 17
    .line 18
    if-nez v0, :cond_2

    .line 19
    .line 20
    :cond_1
    invoke-virtual {p0}, Lai7;->G1()Lq75;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    :cond_2
    iget-object v1, v0, Lq75;->k:Lbd;

    .line 25
    .line 26
    if-eqz v1, :cond_d

    .line 27
    .line 28
    iget-object p1, p1, Lbj3;->h:Ltl0;

    .line 29
    .line 30
    iget-object p1, p1, Ltl0;->i:Lzi7;

    .line 31
    .line 32
    invoke-virtual {p1}, Lzi7;->K()Lpl0;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    iget-boolean p1, v0, Lq75;->l:Z

    .line 37
    .line 38
    if-eqz p1, :cond_3

    .line 39
    .line 40
    iget-wide v3, v0, Lq75;->m:J

    .line 41
    .line 42
    const/16 v0, 0x20

    .line 43
    .line 44
    shr-long v5, v3, v0

    .line 45
    .line 46
    long-to-int v0, v5

    .line 47
    int-to-float v5, v0

    .line 48
    const-wide v6, 0xffffffffL

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    and-long/2addr v3, v6

    .line 54
    long-to-int v0, v3

    .line 55
    int-to-float v6, v0

    .line 56
    invoke-interface {v2}, Lpl0;->n()V

    .line 57
    .line 58
    .line 59
    const/4 v4, 0x0

    .line 60
    const/4 v7, 0x1

    .line 61
    const/4 v3, 0x0

    .line 62
    invoke-interface/range {v2 .. v7}, Lpl0;->h(FFFFI)V

    .line 63
    .line 64
    .line 65
    :cond_3
    :try_start_0
    iget-object v0, p0, Lai7;->w:Lbi7;

    .line 66
    .line 67
    iget-object v3, v0, Lbi7;->a:Lox6;

    .line 68
    .line 69
    iget-object v4, v3, Lox6;->n:Lvb7;

    .line 70
    .line 71
    if-nez v4, :cond_4

    .line 72
    .line 73
    sget-object v4, Lvb7;->b:Lvb7;

    .line 74
    .line 75
    :cond_4
    move-object v6, v4

    .line 76
    iget-object v4, v3, Lox6;->o:Lwn6;

    .line 77
    .line 78
    if-nez v4, :cond_5

    .line 79
    .line 80
    sget-object v4, Lwn6;->d:Lwn6;

    .line 81
    .line 82
    :cond_5
    move-object v5, v4

    .line 83
    iget-object v4, v3, Lox6;->q:Lew1;

    .line 84
    .line 85
    if-nez v4, :cond_6

    .line 86
    .line 87
    sget-object v4, Lba2;->a:Lba2;

    .line 88
    .line 89
    :cond_6
    move-object v7, v4

    .line 90
    iget-object v3, v3, Lox6;->b:Lff7;

    .line 91
    .line 92
    invoke-interface {v3}, Lff7;->b()Ldg0;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    if-eqz v3, :cond_7

    .line 97
    .line 98
    iget-object p0, v0, Lbi7;->a:Lox6;

    .line 99
    .line 100
    iget-object p0, p0, Lox6;->b:Lff7;

    .line 101
    .line 102
    invoke-interface {p0}, Lff7;->c()F

    .line 103
    .line 104
    .line 105
    move-result v4

    .line 106
    invoke-virtual/range {v1 .. v7}, Lbd;->k(Lpl0;Ldg0;FLwn6;Lvb7;Lew1;)V

    .line 107
    .line 108
    .line 109
    goto :goto_2

    .line 110
    :cond_7
    iget-object p0, p0, Lai7;->D:Lky0;

    .line 111
    .line 112
    if-eqz p0, :cond_8

    .line 113
    .line 114
    invoke-interface {p0}, Lky0;->a()J

    .line 115
    .line 116
    .line 117
    move-result-wide v3

    .line 118
    goto :goto_0

    .line 119
    :cond_8
    sget-object p0, Lty0;->u:Li06;

    .line 120
    .line 121
    const/4 v3, 0x0

    .line 122
    invoke-static {v3, v3, v3, v3, p0}, Lnx;->d(FFFFLry0;)J

    .line 123
    .line 124
    .line 125
    move-result-wide v3

    .line 126
    :goto_0
    const-wide/16 v8, 0x10

    .line 127
    .line 128
    cmp-long p0, v3, v8

    .line 129
    .line 130
    if-nez p0, :cond_a

    .line 131
    .line 132
    invoke-virtual {v0}, Lbi7;->b()J

    .line 133
    .line 134
    .line 135
    move-result-wide v3

    .line 136
    cmp-long p0, v3, v8

    .line 137
    .line 138
    if-eqz p0, :cond_9

    .line 139
    .line 140
    invoke-virtual {v0}, Lbi7;->b()J

    .line 141
    .line 142
    .line 143
    move-result-wide v3

    .line 144
    goto :goto_1

    .line 145
    :cond_9
    const-wide/high16 v3, -0x100000000000000L

    .line 146
    .line 147
    :cond_a
    :goto_1
    invoke-virtual/range {v1 .. v7}, Lbd;->j(Lpl0;JLwn6;Lvb7;Lew1;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 148
    .line 149
    .line 150
    :goto_2
    if-eqz p1, :cond_b

    .line 151
    .line 152
    invoke-interface {v2}, Lpl0;->j()V

    .line 153
    .line 154
    .line 155
    :cond_b
    return-void

    .line 156
    :catchall_0
    move-exception v0

    .line 157
    move-object p0, v0

    .line 158
    if-eqz p1, :cond_c

    .line 159
    .line 160
    invoke-interface {v2}, Lpl0;->j()V

    .line 161
    .line 162
    .line 163
    :cond_c
    throw p0

    .line 164
    :cond_d
    iget-object p1, p0, Lai7;->F:Lq75;

    .line 165
    .line 166
    iget-object p0, p0, Lai7;->H:Lzh7;

    .line 167
    .line 168
    new-instance v0, Ljava/lang/StringBuilder;

    .line 169
    .line 170
    const-string v1, "Internal Error: ParagraphLayoutCache could not provide a Paragraph during the draw phase. Please report this bug on the official Issue Tracker with the following diagnostic information: (layoutCache="

    .line 171
    .line 172
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    const-string p1, ", textSubstitution="

    .line 179
    .line 180
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    const-string p0, ")"

    .line 187
    .line 188
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 189
    .line 190
    .line 191
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object p0

    .line 195
    invoke-static {p0}, Ls73;->b(Ljava/lang/String;)Ljava/lang/Void;

    .line 196
    .line 197
    .line 198
    invoke-static {}, Lxb1;->m()V

    .line 199
    .line 200
    .line 201
    return-void
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method

.method public final m(Ly14;Lp14;J)Lv14;
    .locals 4

    .line 1
    const-string v0, "TextStringSimpleNode::measure"

    .line 2
    .line 3
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    :try_start_0
    iget-object v0, p0, Lai7;->H:Lzh7;

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean v1, v0, Lzh7;->c:Z

    .line 11
    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    :cond_0
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iget-object v0, v0, Lzh7;->d:Lq75;

    .line 18
    .line 19
    if-nez v0, :cond_2

    .line 20
    .line 21
    :cond_1
    invoke-virtual {p0}, Lai7;->G1()Lq75;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    :cond_2
    invoke-virtual {v0, p1}, Lq75;->c(Ly14;)V

    .line 26
    .line 27
    .line 28
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    invoke-virtual {v0, p3, p4, v1}, Lq75;->b(JLii3;)Z

    .line 33
    .line 34
    .line 35
    move-result p3

    .line 36
    iget-object p4, v0, Lq75;->o:Lfd;

    .line 37
    .line 38
    if-eqz p4, :cond_3

    .line 39
    .line 40
    invoke-virtual {p4}, Lfd;->a()Z

    .line 41
    .line 42
    .line 43
    :cond_3
    iget-object p4, v0, Lq75;->k:Lbd;

    .line 44
    .line 45
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    iget-wide v0, v0, Lq75;->m:J

    .line 49
    .line 50
    if-eqz p3, :cond_5

    .line 51
    .line 52
    const/4 p3, 0x2

    .line 53
    invoke-static {p0, p3}, Lsx;->i0(Lap1;I)Lbt4;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-virtual {v2}, Lbt4;->J1()V

    .line 58
    .line 59
    .line 60
    iget-object v2, p0, Lai7;->E:Ljava/util/HashMap;

    .line 61
    .line 62
    if-nez v2, :cond_4

    .line 63
    .line 64
    new-instance v2, Ljava/util/HashMap;

    .line 65
    .line 66
    invoke-direct {v2, p3}, Ljava/util/HashMap;-><init>(I)V

    .line 67
    .line 68
    .line 69
    iput-object v2, p0, Lai7;->E:Ljava/util/HashMap;

    .line 70
    .line 71
    :cond_4
    sget-object p3, Ls8;->a:Lq13;

    .line 72
    .line 73
    const/4 v3, 0x0

    .line 74
    invoke-virtual {p4, v3}, Lbd;->c(I)F

    .line 75
    .line 76
    .line 77
    move-result v3

    .line 78
    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    .line 79
    .line 80
    .line 81
    move-result v3

    .line 82
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 83
    .line 84
    .line 85
    move-result-object v3

    .line 86
    invoke-interface {v2, p3, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    sget-object p3, Ls8;->b:Lq13;

    .line 90
    .line 91
    iget-object v3, p4, Lbd;->d:Luf7;

    .line 92
    .line 93
    iget v3, v3, Luf7;->g:I

    .line 94
    .line 95
    add-int/lit8 v3, v3, -0x1

    .line 96
    .line 97
    invoke-virtual {p4, v3}, Lbd;->c(I)F

    .line 98
    .line 99
    .line 100
    move-result p4

    .line 101
    invoke-static {p4}, Ljava/lang/Math;->round(F)I

    .line 102
    .line 103
    .line 104
    move-result p4

    .line 105
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 106
    .line 107
    .line 108
    move-result-object p4

    .line 109
    invoke-interface {v2, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    :cond_5
    const/16 p3, 0x20

    .line 113
    .line 114
    shr-long p3, v0, p3

    .line 115
    .line 116
    long-to-int p3, p3

    .line 117
    const-wide v2, 0xffffffffL

    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    and-long/2addr v0, v2

    .line 123
    long-to-int p4, v0

    .line 124
    invoke-static {p3, p3, p4, p4}, Lqv;->F(IIII)J

    .line 125
    .line 126
    .line 127
    move-result-wide v0

    .line 128
    invoke-interface {p2, v0, v1}, Lp14;->e(J)Lfb5;

    .line 129
    .line 130
    .line 131
    move-result-object p2

    .line 132
    iget-object p0, p0, Lai7;->E:Ljava/util/HashMap;

    .line 133
    .line 134
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 135
    .line 136
    .line 137
    new-instance v0, Lia7;

    .line 138
    .line 139
    const/4 v1, 0x4

    .line 140
    invoke-direct {v0, p2, v1}, Lia7;-><init>(Lfb5;B)V

    .line 141
    .line 142
    .line 143
    invoke-interface {p1, p3, p4, p0, v0}, Ly14;->P0(IILjava/util/Map;Lwh2;)Lv14;

    .line 144
    .line 145
    .line 146
    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 147
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 148
    .line 149
    .line 150
    return-object p0

    .line 151
    :catchall_0
    move-exception p0

    .line 152
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 153
    .line 154
    .line 155
    throw p0
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
.end method

.method public final v1()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
