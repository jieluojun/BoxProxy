.class public final Lak3;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lmk0;


# instance fields
.field public final synthetic a:Lnc4;

.field public final b:Leq2;


# direct methods
.method public constructor <init>(Lsn1;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x6

    .line 5
    invoke-static {p1, v0}, Lbw;->e(Lol3;I)Lnc4;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, Lak3;->a:Lnc4;

    .line 10
    .line 11
    new-instance p1, Leq2;

    .line 12
    .line 13
    const/16 v0, 0x8

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-direct {p1, v0, v1}, Leq2;-><init>(BZ)V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Lak3;->b:Leq2;

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 0

    .line 1
    iget-object p0, p0, Lak3;->a:Lnc4;

    .line 2
    .line 3
    invoke-virtual {p0}, Lnc4;->a()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final b()V
    .locals 0

    .line 1
    return-void
.end method

.method public final c()[I
    .locals 0

    .line 1
    iget-object p0, p0, Lak3;->a:Lnc4;

    .line 2
    .line 3
    iget-object p0, p0, Lnc4;->k:[I

    .line 4
    .line 5
    return-object p0
.end method

.method public final d()[I
    .locals 0

    .line 1
    iget-object p0, p0, Lak3;->a:Lnc4;

    .line 2
    .line 3
    iget-object p0, p0, Lnc4;->j:[I

    .line 4
    .line 5
    return-object p0
.end method

.method public final e()V
    .locals 0

    .line 1
    iget-object p0, p0, Lak3;->a:Lnc4;

    .line 2
    .line 3
    invoke-virtual {p0}, Lnc4;->e()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final f(Lyk3;FLok3;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lak3;->b:Leq2;

    .line 2
    .line 3
    iput-object p3, v0, Leq2;->i:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p1, v0, Leq2;->j:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object p0, p0, Lak3;->a:Lnc4;

    .line 8
    .line 9
    invoke-virtual {p0, v0, p2}, Lnc4;->j(Lnk0;F)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
