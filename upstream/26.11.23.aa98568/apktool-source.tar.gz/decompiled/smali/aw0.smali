.class public final synthetic Law0;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lro3;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ldv0;


# direct methods
.method public synthetic constructor <init>(Ldv0;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Law0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Law0;->i:Ldv0;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final e(Lto3;Lko3;)V
    .locals 2

    .line 1
    iget-byte p1, p0, Law0;->h:B

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    const-string v1, "cnip-local-file-state"

    .line 5
    .line 6
    iget-object p0, p0, Law0;->i:Ldv0;

    .line 7
    .line 8
    packed-switch p1, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    sget-object p1, Lko3;->ON_RESUME:Lko3;

    .line 12
    .line 13
    if-ne p2, p1, :cond_0

    .line 14
    .line 15
    iget-object p1, p0, Ldv0;->e:Lxp6;

    .line 16
    .line 17
    new-instance p2, Lav0;

    .line 18
    .line 19
    invoke-direct {p2, p0, v0}, Lav0;-><init>(Ldv0;Lxd1;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1, p2, v1}, Lxp6;->e(Lwh2;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void

    .line 26
    :pswitch_0
    sget-object p1, Lko3;->ON_RESUME:Lko3;

    .line 27
    .line 28
    if-ne p2, p1, :cond_1

    .line 29
    .line 30
    iget-object p1, p0, Ldv0;->e:Lxp6;

    .line 31
    .line 32
    new-instance p2, Lav0;

    .line 33
    .line 34
    invoke-direct {p2, p0, v0}, Lav0;-><init>(Ldv0;Lxd1;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p1, p2, v1}, Lxp6;->e(Lwh2;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method
