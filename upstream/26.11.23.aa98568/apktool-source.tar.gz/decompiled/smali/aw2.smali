.class public final synthetic Law2;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lqz2;

.field public final synthetic j:Lcz2;

.field public final synthetic k:Ljava/util/ArrayList;

.field public final synthetic l:Lwh2;


# direct methods
.method public synthetic constructor <init>(Lqz2;Lcz2;Ljava/util/ArrayList;Lwh2;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, Law2;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Law2;->i:Lqz2;

    .line 4
    .line 5
    iput-object p2, p0, Law2;->j:Lcz2;

    .line 6
    .line 7
    iput-object p3, p0, Law2;->k:Ljava/util/ArrayList;

    .line 8
    .line 9
    iput-object p4, p0, Law2;->l:Lwh2;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Law2;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/16 v3, 0x30

    .line 8
    .line 9
    sget-object v4, Lzi3;->Z:Lu43;

    .line 10
    .line 11
    const/16 v5, 0x10

    .line 12
    .line 13
    sget-object v6, Lc51;->a:Lql0;

    .line 14
    .line 15
    const/4 v7, 0x1

    .line 16
    const/4 v8, 0x0

    .line 17
    iget-object v9, v0, Law2;->l:Lwh2;

    .line 18
    .line 19
    iget-object v10, v0, Law2;->k:Ljava/util/ArrayList;

    .line 20
    .line 21
    iget-object v11, v0, Law2;->i:Lqz2;

    .line 22
    .line 23
    packed-switch v1, :pswitch_data_0

    .line 24
    .line 25
    .line 26
    move-object/from16 v1, p1

    .line 27
    .line 28
    check-cast v1, Lfl3;

    .line 29
    .line 30
    move-object/from16 v12, p2

    .line 31
    .line 32
    check-cast v12, Lzi2;

    .line 33
    .line 34
    move-object/from16 v13, p3

    .line 35
    .line 36
    check-cast v13, Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v13

    .line 42
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    and-int/lit8 v1, v13, 0x11

    .line 46
    .line 47
    if-eq v1, v5, :cond_0

    .line 48
    .line 49
    move v1, v7

    .line 50
    goto :goto_0

    .line 51
    :cond_0
    move v1, v8

    .line 52
    :goto_0
    and-int/2addr v13, v7

    .line 53
    invoke-virtual {v12, v13, v1}, Lzi2;->Y(IZ)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-eqz v1, :cond_a

    .line 58
    .line 59
    sget-object v1, Lob3;->g:Llw;

    .line 60
    .line 61
    sget-object v5, Ly6;->v:Lz30;

    .line 62
    .line 63
    invoke-static {v1, v5, v12, v8}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    iget-wide v13, v12, Lzi2;->U:J

    .line 68
    .line 69
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 70
    .line 71
    .line 72
    move-result v5

    .line 73
    invoke-virtual {v12}, Lzi2;->m()Lla5;

    .line 74
    .line 75
    .line 76
    move-result-object v8

    .line 77
    sget-object v13, Lya4;->h:Lya4;

    .line 78
    .line 79
    invoke-static {v12, v13}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 80
    .line 81
    .line 82
    move-result-object v14

    .line 83
    sget-object v15, Ls41;->d:Ly6;

    .line 84
    .line 85
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v12}, Lzi2;->k0()V

    .line 89
    .line 90
    .line 91
    iget-boolean v15, v12, Lzi2;->T:Z

    .line 92
    .line 93
    if-eqz v15, :cond_1

    .line 94
    .line 95
    invoke-virtual {v12, v4}, Lzi2;->l(Llh2;)V

    .line 96
    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_1
    invoke-virtual {v12}, Lzi2;->t0()V

    .line 100
    .line 101
    .line 102
    :goto_1
    sget-object v4, Ly6;->T:Lx31;

    .line 103
    .line 104
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    sget-object v1, Ly6;->S:Lx31;

    .line 108
    .line 109
    invoke-static {v1, v12, v8}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    sget-object v4, Ly6;->U:Lx31;

    .line 117
    .line 118
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    invoke-static {v12}, Lfa7;->k(Lzi2;)V

    .line 122
    .line 123
    .line 124
    sget-object v1, Ly6;->R:Lx31;

    .line 125
    .line 126
    invoke-static {v1, v12, v14}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    const/16 v17, 0x0

    .line 130
    .line 131
    const/16 v18, 0xd

    .line 132
    .line 133
    const/4 v14, 0x0

    .line 134
    const/high16 v15, 0x41400000    # 12.0f

    .line 135
    .line 136
    const/16 v16, 0x0

    .line 137
    .line 138
    invoke-static/range {v13 .. v18}, Lah0;->I(Lbb4;FFFFI)Lbb4;

    .line 139
    .line 140
    .line 141
    move-result-object v18

    .line 142
    iget-object v1, v11, Lqz2;->a:Lnz2;

    .line 143
    .line 144
    iget-object v0, v0, Law2;->j:Lcz2;

    .line 145
    .line 146
    invoke-virtual {v0}, Lcz2;->a()Loz2;

    .line 147
    .line 148
    .line 149
    move-result-object v13

    .line 150
    invoke-virtual {v12, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v4

    .line 154
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object v5

    .line 158
    if-nez v4, :cond_2

    .line 159
    .line 160
    if-ne v5, v6, :cond_3

    .line 161
    .line 162
    :cond_2
    new-instance v19, Lhl1;

    .line 163
    .line 164
    const/16 v25, 0x0

    .line 165
    .line 166
    const/16 v26, 0x17

    .line 167
    .line 168
    const/16 v20, 0x0

    .line 169
    .line 170
    const-class v22, Lcz2;

    .line 171
    .line 172
    const-string v23, "start"

    .line 173
    .line 174
    const-string v24, "start()V"

    .line 175
    .line 176
    move-object/from16 v21, v0

    .line 177
    .line 178
    invoke-direct/range {v19 .. v26}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 179
    .line 180
    .line 181
    move-object/from16 v5, v19

    .line 182
    .line 183
    invoke-virtual {v12, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    :cond_3
    check-cast v5, Lli2;

    .line 187
    .line 188
    invoke-virtual {v12, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    move-result v4

    .line 192
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v8

    .line 196
    if-nez v4, :cond_4

    .line 197
    .line 198
    if-ne v8, v6, :cond_5

    .line 199
    .line 200
    :cond_4
    new-instance v19, Lhl1;

    .line 201
    .line 202
    const/16 v25, 0x0

    .line 203
    .line 204
    const/16 v26, 0x18

    .line 205
    .line 206
    const/16 v20, 0x0

    .line 207
    .line 208
    const-class v22, Lcz2;

    .line 209
    .line 210
    const-string v23, "reload"

    .line 211
    .line 212
    const-string v24, "reload()V"

    .line 213
    .line 214
    move-object/from16 v21, v0

    .line 215
    .line 216
    invoke-direct/range {v19 .. v26}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 217
    .line 218
    .line 219
    move-object/from16 v8, v19

    .line 220
    .line 221
    invoke-virtual {v12, v8}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 222
    .line 223
    .line 224
    :cond_5
    check-cast v8, Lli2;

    .line 225
    .line 226
    invoke-virtual {v12, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    move-result v4

    .line 230
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v11

    .line 234
    if-nez v4, :cond_6

    .line 235
    .line 236
    if-ne v11, v6, :cond_7

    .line 237
    .line 238
    :cond_6
    new-instance v19, Lhl1;

    .line 239
    .line 240
    const/16 v25, 0x0

    .line 241
    .line 242
    const/16 v26, 0x19

    .line 243
    .line 244
    const/16 v20, 0x0

    .line 245
    .line 246
    const-class v22, Lcz2;

    .line 247
    .line 248
    const-string v23, "stop"

    .line 249
    .line 250
    const-string v24, "stop()V"

    .line 251
    .line 252
    move-object/from16 v21, v0

    .line 253
    .line 254
    invoke-direct/range {v19 .. v26}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 255
    .line 256
    .line 257
    move-object/from16 v11, v19

    .line 258
    .line 259
    invoke-virtual {v12, v11}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 260
    .line 261
    .line 262
    :cond_7
    check-cast v11, Lli2;

    .line 263
    .line 264
    invoke-virtual {v12, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 265
    .line 266
    .line 267
    move-result v4

    .line 268
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v14

    .line 272
    if-nez v4, :cond_8

    .line 273
    .line 274
    if-ne v14, v6, :cond_9

    .line 275
    .line 276
    :cond_8
    new-instance v19, Lhl1;

    .line 277
    .line 278
    const/16 v25, 0x0

    .line 279
    .line 280
    const/16 v26, 0x1a

    .line 281
    .line 282
    const/16 v20, 0x0

    .line 283
    .line 284
    const-class v22, Lcz2;

    .line 285
    .line 286
    const-string v23, "restart"

    .line 287
    .line 288
    const-string v24, "restart()V"

    .line 289
    .line 290
    move-object/from16 v21, v0

    .line 291
    .line 292
    invoke-direct/range {v19 .. v26}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 293
    .line 294
    .line 295
    move-object/from16 v14, v19

    .line 296
    .line 297
    invoke-virtual {v12, v14}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    :cond_9
    check-cast v14, Lli2;

    .line 301
    .line 302
    check-cast v5, Llh2;

    .line 303
    .line 304
    move-object v15, v8

    .line 305
    check-cast v15, Llh2;

    .line 306
    .line 307
    move-object/from16 v16, v11

    .line 308
    .line 309
    check-cast v16, Llh2;

    .line 310
    .line 311
    move-object/from16 v17, v14

    .line 312
    .line 313
    check-cast v17, Llh2;

    .line 314
    .line 315
    const/high16 v20, 0x180000

    .line 316
    .line 317
    move-object v14, v5

    .line 318
    move-object/from16 v19, v12

    .line 319
    .line 320
    move-object v12, v1

    .line 321
    invoke-static/range {v12 .. v20}, Lza1;->l(Lnz2;Loz2;Llh2;Llh2;Llh2;Llh2;Lbb4;Lzi2;I)V

    .line 322
    .line 323
    .line 324
    move-object/from16 v0, v19

    .line 325
    .line 326
    sget-object v1, Lss7;->l:Lss7;

    .line 327
    .line 328
    invoke-static {v10, v1, v9, v0, v3}, Lhw;->q(Ljava/util/ArrayList;Lss7;Lwh2;Lzi2;I)V

    .line 329
    .line 330
    .line 331
    invoke-virtual {v0, v7}, Lzi2;->r(Z)V

    .line 332
    .line 333
    .line 334
    goto :goto_2

    .line 335
    :cond_a
    move-object v0, v12

    .line 336
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 337
    .line 338
    .line 339
    :goto_2
    return-object v2

    .line 340
    :pswitch_0
    move-object/from16 v1, p1

    .line 341
    .line 342
    check-cast v1, Lfl3;

    .line 343
    .line 344
    move-object/from16 v12, p2

    .line 345
    .line 346
    check-cast v12, Lzi2;

    .line 347
    .line 348
    move-object/from16 v13, p3

    .line 349
    .line 350
    check-cast v13, Ljava/lang/Integer;

    .line 351
    .line 352
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 353
    .line 354
    .line 355
    move-result v13

    .line 356
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 357
    .line 358
    .line 359
    and-int/lit8 v1, v13, 0x11

    .line 360
    .line 361
    if-eq v1, v5, :cond_b

    .line 362
    .line 363
    move v1, v7

    .line 364
    goto :goto_3

    .line 365
    :cond_b
    move v1, v8

    .line 366
    :goto_3
    and-int/2addr v13, v7

    .line 367
    invoke-virtual {v12, v13, v1}, Lzi2;->Y(IZ)Z

    .line 368
    .line 369
    .line 370
    move-result v1

    .line 371
    if-eqz v1, :cond_15

    .line 372
    .line 373
    sget-object v1, Lob3;->g:Llw;

    .line 374
    .line 375
    sget-object v5, Ly6;->v:Lz30;

    .line 376
    .line 377
    invoke-static {v1, v5, v12, v8}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    iget-wide v13, v12, Lzi2;->U:J

    .line 382
    .line 383
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 384
    .line 385
    .line 386
    move-result v5

    .line 387
    invoke-virtual {v12}, Lzi2;->m()Lla5;

    .line 388
    .line 389
    .line 390
    move-result-object v8

    .line 391
    sget-object v13, Lya4;->h:Lya4;

    .line 392
    .line 393
    invoke-static {v12, v13}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 394
    .line 395
    .line 396
    move-result-object v13

    .line 397
    sget-object v14, Ls41;->d:Ly6;

    .line 398
    .line 399
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 400
    .line 401
    .line 402
    invoke-virtual {v12}, Lzi2;->k0()V

    .line 403
    .line 404
    .line 405
    iget-boolean v14, v12, Lzi2;->T:Z

    .line 406
    .line 407
    if-eqz v14, :cond_c

    .line 408
    .line 409
    invoke-virtual {v12, v4}, Lzi2;->l(Llh2;)V

    .line 410
    .line 411
    .line 412
    goto :goto_4

    .line 413
    :cond_c
    invoke-virtual {v12}, Lzi2;->t0()V

    .line 414
    .line 415
    .line 416
    :goto_4
    sget-object v4, Ly6;->T:Lx31;

    .line 417
    .line 418
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 419
    .line 420
    .line 421
    sget-object v1, Ly6;->S:Lx31;

    .line 422
    .line 423
    invoke-static {v1, v12, v8}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 427
    .line 428
    .line 429
    move-result-object v1

    .line 430
    sget-object v4, Ly6;->U:Lx31;

    .line 431
    .line 432
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 433
    .line 434
    .line 435
    invoke-static {v12}, Lfa7;->k(Lzi2;)V

    .line 436
    .line 437
    .line 438
    sget-object v1, Ly6;->R:Lx31;

    .line 439
    .line 440
    invoke-static {v1, v12, v13}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 441
    .line 442
    .line 443
    iget-object v1, v11, Lqz2;->a:Lnz2;

    .line 444
    .line 445
    iget-object v15, v0, Law2;->j:Lcz2;

    .line 446
    .line 447
    invoke-virtual {v15}, Lcz2;->a()Loz2;

    .line 448
    .line 449
    .line 450
    move-result-object v0

    .line 451
    invoke-virtual {v12, v15}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 452
    .line 453
    .line 454
    move-result v4

    .line 455
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v5

    .line 459
    if-nez v4, :cond_d

    .line 460
    .line 461
    if-ne v5, v6, :cond_e

    .line 462
    .line 463
    :cond_d
    new-instance v13, Lhl1;

    .line 464
    .line 465
    const/16 v19, 0x0

    .line 466
    .line 467
    const/16 v20, 0x11

    .line 468
    .line 469
    const/4 v14, 0x0

    .line 470
    const-class v16, Lcz2;

    .line 471
    .line 472
    const-string v17, "start"

    .line 473
    .line 474
    const-string v18, "start()V"

    .line 475
    .line 476
    invoke-direct/range {v13 .. v20}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 477
    .line 478
    .line 479
    invoke-virtual {v12, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 480
    .line 481
    .line 482
    move-object v5, v13

    .line 483
    :cond_e
    check-cast v5, Lli2;

    .line 484
    .line 485
    check-cast v5, Llh2;

    .line 486
    .line 487
    invoke-virtual {v12, v15}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 488
    .line 489
    .line 490
    move-result v4

    .line 491
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 492
    .line 493
    .line 494
    move-result-object v8

    .line 495
    if-nez v4, :cond_f

    .line 496
    .line 497
    if-ne v8, v6, :cond_10

    .line 498
    .line 499
    :cond_f
    new-instance v13, Lhl1;

    .line 500
    .line 501
    const/16 v19, 0x0

    .line 502
    .line 503
    const/16 v20, 0x12

    .line 504
    .line 505
    const/4 v14, 0x0

    .line 506
    const-class v16, Lcz2;

    .line 507
    .line 508
    const-string v17, "reload"

    .line 509
    .line 510
    const-string v18, "reload()V"

    .line 511
    .line 512
    invoke-direct/range {v13 .. v20}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 513
    .line 514
    .line 515
    invoke-virtual {v12, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 516
    .line 517
    .line 518
    move-object v8, v13

    .line 519
    :cond_10
    check-cast v8, Lli2;

    .line 520
    .line 521
    check-cast v8, Llh2;

    .line 522
    .line 523
    invoke-virtual {v12, v15}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 524
    .line 525
    .line 526
    move-result v4

    .line 527
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    move-result-object v11

    .line 531
    if-nez v4, :cond_11

    .line 532
    .line 533
    if-ne v11, v6, :cond_12

    .line 534
    .line 535
    :cond_11
    new-instance v13, Lhl1;

    .line 536
    .line 537
    const/16 v19, 0x0

    .line 538
    .line 539
    const/16 v20, 0x13

    .line 540
    .line 541
    const/4 v14, 0x0

    .line 542
    const-class v16, Lcz2;

    .line 543
    .line 544
    const-string v17, "stop"

    .line 545
    .line 546
    const-string v18, "stop()V"

    .line 547
    .line 548
    invoke-direct/range {v13 .. v20}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 549
    .line 550
    .line 551
    invoke-virtual {v12, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 552
    .line 553
    .line 554
    move-object v11, v13

    .line 555
    :cond_12
    check-cast v11, Lli2;

    .line 556
    .line 557
    check-cast v11, Llh2;

    .line 558
    .line 559
    invoke-virtual {v12, v15}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 560
    .line 561
    .line 562
    move-result v4

    .line 563
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 564
    .line 565
    .line 566
    move-result-object v13

    .line 567
    if-nez v4, :cond_13

    .line 568
    .line 569
    if-ne v13, v6, :cond_14

    .line 570
    .line 571
    :cond_13
    new-instance v13, Lhl1;

    .line 572
    .line 573
    const/16 v19, 0x0

    .line 574
    .line 575
    const/16 v20, 0x14

    .line 576
    .line 577
    const/4 v14, 0x0

    .line 578
    const-class v16, Lcz2;

    .line 579
    .line 580
    const-string v17, "restart"

    .line 581
    .line 582
    const-string v18, "restart()V"

    .line 583
    .line 584
    invoke-direct/range {v13 .. v20}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 585
    .line 586
    .line 587
    invoke-virtual {v12, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 588
    .line 589
    .line 590
    :cond_14
    check-cast v13, Lli2;

    .line 591
    .line 592
    move-object/from16 v17, v13

    .line 593
    .line 594
    check-cast v17, Llh2;

    .line 595
    .line 596
    const/16 v19, 0x0

    .line 597
    .line 598
    move-object v13, v0

    .line 599
    move-object v14, v5

    .line 600
    move-object v15, v8

    .line 601
    move-object/from16 v16, v11

    .line 602
    .line 603
    move-object/from16 v18, v12

    .line 604
    .line 605
    move-object v12, v1

    .line 606
    invoke-static/range {v12 .. v19}, Lah0;->i(Lnz2;Loz2;Llh2;Llh2;Llh2;Llh2;Lzi2;I)V

    .line 607
    .line 608
    .line 609
    move-object/from16 v0, v18

    .line 610
    .line 611
    sget-object v1, Lss7;->k:Lss7;

    .line 612
    .line 613
    invoke-static {v10, v1, v9, v0, v3}, Lhw;->q(Ljava/util/ArrayList;Lss7;Lwh2;Lzi2;I)V

    .line 614
    .line 615
    .line 616
    invoke-virtual {v0, v7}, Lzi2;->r(Z)V

    .line 617
    .line 618
    .line 619
    goto :goto_5

    .line 620
    :cond_15
    move-object v0, v12

    .line 621
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 622
    .line 623
    .line 624
    :goto_5
    return-object v2

    .line 625
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
