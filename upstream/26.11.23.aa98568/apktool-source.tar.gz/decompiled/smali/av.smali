.class public final Lav;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic l:B

.field public synthetic m:Ljava/lang/Object;

.field public synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/Object;Lxd1;B)V
    .locals 0

    .line 16
    iput-byte p4, p0, Lav;->l:B

    iput-object p1, p0, Lav;->m:Ljava/lang/Object;

    iput-object p2, p0, Lav;->o:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V
    .locals 0

    .line 18
    iput-byte p5, p0, Lav;->l:B

    iput-object p1, p0, Lav;->m:Ljava/lang/Object;

    iput-object p2, p0, Lav;->n:Ljava/lang/Object;

    iput-object p3, p0, Lav;->o:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V
    .locals 0

    .line 17
    iput-byte p4, p0, Lav;->l:B

    iput-object p1, p0, Lav;->n:Ljava/lang/Object;

    iput-object p2, p0, Lav;->o:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lxd1;)V
    .locals 1

    const/16 v0, 0xa

    iput-byte v0, p0, Lav;->l:B

    .line 19
    iput-object p1, p0, Lav;->o:Ljava/lang/Object;

    iput-object p2, p0, Lav;->m:Ljava/lang/Object;

    iput-object p3, p0, Lav;->n:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;[BLxd1;)V
    .locals 1

    const/16 v0, 0xc

    iput-byte v0, p0, Lav;->l:B

    .line 20
    iput-object p1, p0, Lav;->o:Ljava/lang/Object;

    iput-object p2, p0, Lav;->n:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public constructor <init>(Lte4;Lte4;Landroid/content/Context;Lxd1;)V
    .locals 1

    .line 1
    const/16 v0, 0xb

    .line 2
    .line 3
    iput-byte v0, p0, Lav;->l:B

    .line 4
    .line 5
    iput-object p1, p0, Lav;->n:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p2, p0, Lav;->o:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p3, p0, Lav;->m:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p4}, Lt57;-><init>(ILxd1;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lav;->l:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    check-cast p1, Ljj1;

    .line 6
    .line 7
    check-cast p2, Lxd1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lav;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Lav;

    .line 27
    .line 28
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-object v1

    .line 32
    :pswitch_1
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    check-cast p0, Lav;

    .line 37
    .line 38
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    return-object v1

    .line 42
    :pswitch_2
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Lav;

    .line 47
    .line 48
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_3
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    check-cast p0, Lav;

    .line 58
    .line 59
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    return-object v1

    .line 63
    :pswitch_4
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    check-cast p0, Lav;

    .line 68
    .line 69
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    return-object v1

    .line 73
    :pswitch_5
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    check-cast p0, Lav;

    .line 78
    .line 79
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    return-object p0

    .line 84
    :pswitch_6
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 85
    .line 86
    .line 87
    move-result-object p0

    .line 88
    check-cast p0, Lav;

    .line 89
    .line 90
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    return-object p0

    .line 95
    :pswitch_7
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    check-cast p0, Lav;

    .line 100
    .line 101
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    return-object v1

    .line 105
    :pswitch_8
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 106
    .line 107
    .line 108
    move-result-object p0

    .line 109
    check-cast p0, Lav;

    .line 110
    .line 111
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    return-object p0

    .line 116
    :pswitch_9
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 117
    .line 118
    .line 119
    move-result-object p0

    .line 120
    check-cast p0, Lav;

    .line 121
    .line 122
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    return-object v1

    .line 126
    :pswitch_a
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 127
    .line 128
    .line 129
    move-result-object p0

    .line 130
    check-cast p0, Lav;

    .line 131
    .line 132
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    return-object p0

    .line 137
    :pswitch_b
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    check-cast p0, Lav;

    .line 142
    .line 143
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object p0

    .line 147
    return-object p0

    .line 148
    :pswitch_c
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 149
    .line 150
    .line 151
    move-result-object p0

    .line 152
    check-cast p0, Lav;

    .line 153
    .line 154
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    return-object v1

    .line 158
    :pswitch_d
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 159
    .line 160
    .line 161
    move-result-object p0

    .line 162
    check-cast p0, Lav;

    .line 163
    .line 164
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    return-object v1

    .line 168
    :pswitch_e
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 169
    .line 170
    .line 171
    move-result-object p0

    .line 172
    check-cast p0, Lav;

    .line 173
    .line 174
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object p0

    .line 178
    return-object p0

    .line 179
    :pswitch_f
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 180
    .line 181
    .line 182
    move-result-object p0

    .line 183
    check-cast p0, Lav;

    .line 184
    .line 185
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    return-object v1

    .line 189
    :pswitch_10
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 190
    .line 191
    .line 192
    move-result-object p0

    .line 193
    check-cast p0, Lav;

    .line 194
    .line 195
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    return-object v1

    .line 199
    :pswitch_11
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 200
    .line 201
    .line 202
    move-result-object p0

    .line 203
    check-cast p0, Lav;

    .line 204
    .line 205
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    return-object v1

    .line 209
    :pswitch_12
    invoke-virtual {p0, p2, p1}, Lav;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 210
    .line 211
    .line 212
    move-result-object p0

    .line 213
    check-cast p0, Lav;

    .line 214
    .line 215
    invoke-virtual {p0, v1}, Lav;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object p0

    .line 219
    return-object p0

    .line 220
    nop

    .line 221
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final s(Lxd1;Ljava/lang/Object;)Lxd1;
    .locals 9

    .line 1
    iget-byte v0, p0, Lav;->l:B

    .line 2
    .line 3
    iget-object v1, p0, Lav;->o:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance v2, Lav;

    .line 9
    .line 10
    iget-object p2, p0, Lav;->m:Ljava/lang/Object;

    .line 11
    .line 12
    move-object v3, p2

    .line 13
    check-cast v3, Lxz7;

    .line 14
    .line 15
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 16
    .line 17
    move-object v4, p0

    .line 18
    check-cast v4, Lfz7;

    .line 19
    .line 20
    move-object v5, v1

    .line 21
    check-cast v5, Ljava/lang/String;

    .line 22
    .line 23
    const/16 v7, 0x13

    .line 24
    .line 25
    move-object v6, p1

    .line 26
    invoke-direct/range {v2 .. v7}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 27
    .line 28
    .line 29
    return-object v2

    .line 30
    :pswitch_0
    move-object v7, p1

    .line 31
    new-instance v3, Lav;

    .line 32
    .line 33
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 34
    .line 35
    move-object v4, p1

    .line 36
    check-cast v4, Lm14;

    .line 37
    .line 38
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 39
    .line 40
    move-object v5, p0

    .line 41
    check-cast v5, Lfz7;

    .line 42
    .line 43
    move-object v6, v1

    .line 44
    check-cast v6, Ljava/lang/String;

    .line 45
    .line 46
    const/16 v8, 0x12

    .line 47
    .line 48
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 49
    .line 50
    .line 51
    return-object v3

    .line 52
    :pswitch_1
    move-object v7, p1

    .line 53
    new-instance v3, Lav;

    .line 54
    .line 55
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 56
    .line 57
    move-object v4, p1

    .line 58
    check-cast v4, Lvv;

    .line 59
    .line 60
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 61
    .line 62
    move-object v5, p0

    .line 63
    check-cast v5, Lav6;

    .line 64
    .line 65
    move-object v6, v1

    .line 66
    check-cast v6, Lv75;

    .line 67
    .line 68
    const/16 v8, 0x11

    .line 69
    .line 70
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 71
    .line 72
    .line 73
    return-object v3

    .line 74
    :pswitch_2
    move-object v7, p1

    .line 75
    new-instance p1, Lav;

    .line 76
    .line 77
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast p0, Lte7;

    .line 80
    .line 81
    check-cast v1, Lxc5;

    .line 82
    .line 83
    const/16 v0, 0x10

    .line 84
    .line 85
    invoke-direct {p1, p0, v1, v7, v0}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 86
    .line 87
    .line 88
    iput-object p2, p1, Lav;->m:Ljava/lang/Object;

    .line 89
    .line 90
    return-object p1

    .line 91
    :pswitch_3
    move-object v7, p1

    .line 92
    new-instance p1, Lav;

    .line 93
    .line 94
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast p0, Lwc7;

    .line 97
    .line 98
    check-cast v1, Lxc5;

    .line 99
    .line 100
    const/16 v0, 0xf

    .line 101
    .line 102
    invoke-direct {p1, p0, v1, v7, v0}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 103
    .line 104
    .line 105
    iput-object p2, p1, Lav;->m:Ljava/lang/Object;

    .line 106
    .line 107
    return-object p1

    .line 108
    :pswitch_4
    move-object v7, p1

    .line 109
    new-instance v3, Lav;

    .line 110
    .line 111
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 112
    .line 113
    move-object v4, p1

    .line 114
    check-cast v4, Lv27;

    .line 115
    .line 116
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 117
    .line 118
    move-object v5, p0

    .line 119
    check-cast v5, Lfz7;

    .line 120
    .line 121
    move-object v6, v1

    .line 122
    check-cast v6, Ljava/lang/String;

    .line 123
    .line 124
    const/16 v8, 0xe

    .line 125
    .line 126
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 127
    .line 128
    .line 129
    return-object v3

    .line 130
    :pswitch_5
    move-object v7, p1

    .line 131
    new-instance p1, Lav;

    .line 132
    .line 133
    iget-object p0, p0, Lav;->m:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast p0, Landroid/content/Context;

    .line 136
    .line 137
    check-cast v1, Lzs6;

    .line 138
    .line 139
    const/16 v0, 0xd

    .line 140
    .line 141
    invoke-direct {p1, p0, v1, v7, v0}, Lav;-><init>(Landroid/content/Context;Ljava/lang/Object;Lxd1;B)V

    .line 142
    .line 143
    .line 144
    iput-object p2, p1, Lav;->n:Ljava/lang/Object;

    .line 145
    .line 146
    return-object p1

    .line 147
    :pswitch_6
    move-object v7, p1

    .line 148
    new-instance p1, Lav;

    .line 149
    .line 150
    check-cast v1, Ljava/lang/String;

    .line 151
    .line 152
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 153
    .line 154
    check-cast p0, [B

    .line 155
    .line 156
    invoke-direct {p1, v1, p0, v7}, Lav;-><init>(Ljava/lang/String;[BLxd1;)V

    .line 157
    .line 158
    .line 159
    iput-object p2, p1, Lav;->m:Ljava/lang/Object;

    .line 160
    .line 161
    return-object p1

    .line 162
    :pswitch_7
    move-object v7, p1

    .line 163
    new-instance p1, Lav;

    .line 164
    .line 165
    iget-object p2, p0, Lav;->n:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast p2, Lte4;

    .line 168
    .line 169
    check-cast v1, Lte4;

    .line 170
    .line 171
    iget-object p0, p0, Lav;->m:Ljava/lang/Object;

    .line 172
    .line 173
    check-cast p0, Landroid/content/Context;

    .line 174
    .line 175
    invoke-direct {p1, p2, v1, p0, v7}, Lav;-><init>(Lte4;Lte4;Landroid/content/Context;Lxd1;)V

    .line 176
    .line 177
    .line 178
    return-object p1

    .line 179
    :pswitch_8
    move-object v7, p1

    .line 180
    new-instance p1, Lav;

    .line 181
    .line 182
    check-cast v1, Ljava/lang/String;

    .line 183
    .line 184
    iget-object p2, p0, Lav;->m:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast p2, Ljava/lang/String;

    .line 187
    .line 188
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 189
    .line 190
    check-cast p0, Ljava/lang/String;

    .line 191
    .line 192
    invoke-direct {p1, v1, p2, p0, v7}, Lav;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lxd1;)V

    .line 193
    .line 194
    .line 195
    return-object p1

    .line 196
    :pswitch_9
    move-object v7, p1

    .line 197
    new-instance v3, Lav;

    .line 198
    .line 199
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 200
    .line 201
    move-object v4, p1

    .line 202
    check-cast v4, Laq5;

    .line 203
    .line 204
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 205
    .line 206
    move-object v5, p0

    .line 207
    check-cast v5, Lte4;

    .line 208
    .line 209
    move-object v6, v1

    .line 210
    check-cast v6, Lte4;

    .line 211
    .line 212
    const/16 v8, 0x9

    .line 213
    .line 214
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 215
    .line 216
    .line 217
    return-object v3

    .line 218
    :pswitch_a
    move-object v7, p1

    .line 219
    new-instance v3, Lav;

    .line 220
    .line 221
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 222
    .line 223
    move-object v4, p1

    .line 224
    check-cast v4, Landroid/content/Context;

    .line 225
    .line 226
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 227
    .line 228
    move-object v5, p0

    .line 229
    check-cast v5, Landroid/net/Uri;

    .line 230
    .line 231
    move-object v6, v1

    .line 232
    check-cast v6, Ljava/lang/String;

    .line 233
    .line 234
    const/16 v8, 0x8

    .line 235
    .line 236
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 237
    .line 238
    .line 239
    return-object v3

    .line 240
    :pswitch_b
    move-object v7, p1

    .line 241
    new-instance p1, Lav;

    .line 242
    .line 243
    iget-object p0, p0, Lav;->m:Ljava/lang/Object;

    .line 244
    .line 245
    check-cast p0, Landroid/content/Context;

    .line 246
    .line 247
    check-cast v1, Ljava/lang/String;

    .line 248
    .line 249
    const/4 v0, 0x7

    .line 250
    invoke-direct {p1, p0, v1, v7, v0}, Lav;-><init>(Landroid/content/Context;Ljava/lang/Object;Lxd1;B)V

    .line 251
    .line 252
    .line 253
    iput-object p2, p1, Lav;->n:Ljava/lang/Object;

    .line 254
    .line 255
    return-object p1

    .line 256
    :pswitch_c
    move-object v7, p1

    .line 257
    new-instance v3, Lav;

    .line 258
    .line 259
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 260
    .line 261
    move-object v4, p1

    .line 262
    check-cast v4, Lte4;

    .line 263
    .line 264
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 265
    .line 266
    move-object v5, p0

    .line 267
    check-cast v5, Ljava/util/List;

    .line 268
    .line 269
    move-object v6, v1

    .line 270
    check-cast v6, Ll94;

    .line 271
    .line 272
    const/4 v8, 0x6

    .line 273
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 274
    .line 275
    .line 276
    return-object v3

    .line 277
    :pswitch_d
    move-object v7, p1

    .line 278
    new-instance v3, Lav;

    .line 279
    .line 280
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 281
    .line 282
    move-object v4, p1

    .line 283
    check-cast v4, Lte4;

    .line 284
    .line 285
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 286
    .line 287
    move-object v5, p0

    .line 288
    check-cast v5, Ljava/util/List;

    .line 289
    .line 290
    move-object v6, v1

    .line 291
    check-cast v6, Lk94;

    .line 292
    .line 293
    const/4 v8, 0x5

    .line 294
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 295
    .line 296
    .line 297
    return-object v3

    .line 298
    :pswitch_e
    move-object v7, p1

    .line 299
    new-instance p1, Lav;

    .line 300
    .line 301
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 302
    .line 303
    check-cast p0, Lxc5;

    .line 304
    .line 305
    check-cast v1, Lac7;

    .line 306
    .line 307
    const/4 v0, 0x4

    .line 308
    invoke-direct {p1, p0, v1, v7, v0}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 309
    .line 310
    .line 311
    iput-object p2, p1, Lav;->m:Ljava/lang/Object;

    .line 312
    .line 313
    return-object p1

    .line 314
    :pswitch_f
    move-object v7, p1

    .line 315
    new-instance v3, Lav;

    .line 316
    .line 317
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 318
    .line 319
    move-object v4, p1

    .line 320
    check-cast v4, Lte4;

    .line 321
    .line 322
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 323
    .line 324
    move-object v5, p0

    .line 325
    check-cast v5, Lte4;

    .line 326
    .line 327
    move-object v6, v1

    .line 328
    check-cast v6, Lte4;

    .line 329
    .line 330
    const/4 v8, 0x3

    .line 331
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 332
    .line 333
    .line 334
    return-object v3

    .line 335
    :pswitch_10
    move-object v7, p1

    .line 336
    new-instance p1, Lav;

    .line 337
    .line 338
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 339
    .line 340
    check-cast p0, Ljava/util/ArrayList;

    .line 341
    .line 342
    check-cast v1, Lgh1;

    .line 343
    .line 344
    const/4 v0, 0x2

    .line 345
    invoke-direct {p1, p0, v1, v7, v0}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 346
    .line 347
    .line 348
    iput-object p2, p1, Lav;->m:Ljava/lang/Object;

    .line 349
    .line 350
    return-object p1

    .line 351
    :pswitch_11
    move-object v7, p1

    .line 352
    new-instance v3, Lav;

    .line 353
    .line 354
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 355
    .line 356
    move-object v4, p1

    .line 357
    check-cast v4, Lte4;

    .line 358
    .line 359
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 360
    .line 361
    move-object v5, p0

    .line 362
    check-cast v5, Lim0;

    .line 363
    .line 364
    move-object v6, v1

    .line 365
    check-cast v6, Lwh2;

    .line 366
    .line 367
    const/4 v8, 0x1

    .line 368
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 369
    .line 370
    .line 371
    return-object v3

    .line 372
    :pswitch_12
    move-object v7, p1

    .line 373
    new-instance v3, Lav;

    .line 374
    .line 375
    iget-object p1, p0, Lav;->m:Ljava/lang/Object;

    .line 376
    .line 377
    move-object v4, p1

    .line 378
    check-cast v4, Landroid/content/Context;

    .line 379
    .line 380
    iget-object p0, p0, Lav;->n:Ljava/lang/Object;

    .line 381
    .line 382
    move-object v5, p0

    .line 383
    check-cast v5, Ljava/util/ArrayList;

    .line 384
    .line 385
    move-object v6, v1

    .line 386
    check-cast v6, Ljava/lang/String;

    .line 387
    .line 388
    const/4 v8, 0x0

    .line 389
    invoke-direct/range {v3 .. v8}, Lav;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 390
    .line 391
    .line 392
    return-object v3

    .line 393
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lav;->l:B

    .line 4
    .line 5
    const/16 v2, 0x1b

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    sget-object v4, Lmj1;->k:Lmj1;

    .line 9
    .line 10
    const-string v5, "local"

    .line 11
    .line 12
    const/4 v6, 0x0

    .line 13
    const/4 v7, 0x0

    .line 14
    const/4 v8, 0x1

    .line 15
    sget-object v9, Lst7;->a:Lst7;

    .line 16
    .line 17
    iget-object v10, v0, Lav;->o:Ljava/lang/Object;

    .line 18
    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v1, Lfz7;

    .line 25
    .line 26
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lxz7;

    .line 32
    .line 33
    iget-object v0, v0, Lxz7;->a:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0, v5}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    invoke-virtual {v1}, Lfz7;->f()Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_1

    .line 46
    .line 47
    check-cast v10, Ljava/lang/String;

    .line 48
    .line 49
    if-eqz v10, :cond_0

    .line 50
    .line 51
    invoke-static {v10}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_1

    .line 56
    .line 57
    :cond_0
    invoke-virtual {v1, v7}, Lfz7;->r(Z)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v1, v7}, Lfz7;->s(Z)V

    .line 61
    .line 62
    .line 63
    iget-object v0, v1, Lfz7;->m:Lte4;

    .line 64
    .line 65
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 66
    .line 67
    invoke-interface {v0, v1}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    :cond_1
    return-object v9

    .line 71
    :pswitch_0
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v1, Lfz7;

    .line 74
    .line 75
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Lm14;

    .line 81
    .line 82
    iget-object v0, v0, Lm14;->a:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v0, v5}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_3

    .line 89
    .line 90
    invoke-virtual {v1}, Lfz7;->f()Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-nez v0, :cond_3

    .line 95
    .line 96
    check-cast v10, Ljava/lang/String;

    .line 97
    .line 98
    if-eqz v10, :cond_2

    .line 99
    .line 100
    invoke-static {v10}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_3

    .line 105
    .line 106
    :cond_2
    invoke-virtual {v1, v7}, Lfz7;->r(Z)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v1, v7}, Lfz7;->s(Z)V

    .line 110
    .line 111
    .line 112
    iget-object v0, v1, Lfz7;->m:Lte4;

    .line 113
    .line 114
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 115
    .line 116
    invoke-interface {v0, v1}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    :cond_3
    return-object v9

    .line 120
    :pswitch_1
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    check-cast v10, Lv75;

    .line 124
    .line 125
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v1, Lvv;

    .line 128
    .line 129
    iget v1, v1, Lvv;->R:F

    .line 130
    .line 131
    sget-object v2, Lkj7;->a:Ljava/util/List;

    .line 132
    .line 133
    invoke-virtual {v10, v1}, Lv75;->i(F)V

    .line 134
    .line 135
    .line 136
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v0, Lav6;

    .line 139
    .line 140
    invoke-virtual {v0, v1}, Lav6;->f(F)V

    .line 141
    .line 142
    .line 143
    return-object v9

    .line 144
    :pswitch_2
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v1, Ljj1;

    .line 147
    .line 148
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    new-instance v2, Luc7;

    .line 152
    .line 153
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast v0, Lte7;

    .line 156
    .line 157
    check-cast v10, Lxc5;

    .line 158
    .line 159
    invoke-direct {v2, v0, v10, v6, v8}, Luc7;-><init>(Lte7;Lxc5;Lxd1;B)V

    .line 160
    .line 161
    .line 162
    invoke-static {v1, v6, v4, v2, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 163
    .line 164
    .line 165
    new-instance v2, Luc7;

    .line 166
    .line 167
    invoke-direct {v2, v0, v10, v6, v3}, Luc7;-><init>(Lte7;Lxc5;Lxd1;B)V

    .line 168
    .line 169
    .line 170
    invoke-static {v1, v6, v4, v2, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 171
    .line 172
    .line 173
    new-instance v2, Luc7;

    .line 174
    .line 175
    invoke-direct {v2, v10, v0, v6}, Luc7;-><init>(Lxc5;Lte7;Lxd1;)V

    .line 176
    .line 177
    .line 178
    invoke-static {v1, v6, v4, v2, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    return-object v0

    .line 183
    :pswitch_3
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 184
    .line 185
    check-cast v1, Ljj1;

    .line 186
    .line 187
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 191
    .line 192
    move-object v12, v0

    .line 193
    check-cast v12, Lwc7;

    .line 194
    .line 195
    iget-object v14, v12, Lwc7;->z:Lte7;

    .line 196
    .line 197
    move-object v15, v10

    .line 198
    check-cast v15, Lxc5;

    .line 199
    .line 200
    new-instance v0, Lcs4;

    .line 201
    .line 202
    invoke-direct {v0, v14, v12, v2}, Lcs4;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 203
    .line 204
    .line 205
    new-instance v2, Luc7;

    .line 206
    .line 207
    const/4 v3, 0x0

    .line 208
    invoke-direct {v2, v14, v15, v3, v7}, Luc7;-><init>(Lte7;Lxc5;Lxd1;B)V

    .line 209
    .line 210
    .line 211
    invoke-static {v1, v3, v4, v2, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 212
    .line 213
    .line 214
    new-instance v11, La4;

    .line 215
    .line 216
    const/16 v16, 0x0

    .line 217
    .line 218
    move-object v13, v14

    .line 219
    move-object v14, v15

    .line 220
    move-object v15, v0

    .line 221
    invoke-direct/range {v11 .. v16}, La4;-><init>(Lwc7;Lte7;Lxc5;Lcs4;Lxd1;)V

    .line 222
    .line 223
    .line 224
    move-object/from16 v16, v15

    .line 225
    .line 226
    move-object v15, v14

    .line 227
    move-object v14, v13

    .line 228
    invoke-static {v1, v3, v4, v11, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 229
    .line 230
    .line 231
    new-instance v13, Lxu2;

    .line 232
    .line 233
    const/16 v18, 0x14

    .line 234
    .line 235
    move-object/from16 v17, v3

    .line 236
    .line 237
    invoke-direct/range {v13 .. v18}, Lxu2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 238
    .line 239
    .line 240
    move-object/from16 v0, v17

    .line 241
    .line 242
    invoke-static {v1, v0, v4, v13, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 243
    .line 244
    .line 245
    return-object v9

    .line 246
    :pswitch_4
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast v1, Lfz7;

    .line 249
    .line 250
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 251
    .line 252
    .line 253
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v0, Lv27;

    .line 256
    .line 257
    iget-object v0, v0, Lv27;->a:Ljava/lang/String;

    .line 258
    .line 259
    invoke-static {v0, v5}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    move-result v0

    .line 263
    if-eqz v0, :cond_5

    .line 264
    .line 265
    invoke-virtual {v1}, Lfz7;->f()Z

    .line 266
    .line 267
    .line 268
    move-result v0

    .line 269
    if-nez v0, :cond_5

    .line 270
    .line 271
    check-cast v10, Ljava/lang/String;

    .line 272
    .line 273
    if-eqz v10, :cond_4

    .line 274
    .line 275
    invoke-static {v10}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 276
    .line 277
    .line 278
    move-result v0

    .line 279
    if-eqz v0, :cond_5

    .line 280
    .line 281
    :cond_4
    invoke-virtual {v1, v7}, Lfz7;->r(Z)V

    .line 282
    .line 283
    .line 284
    invoke-virtual {v1, v7}, Lfz7;->s(Z)V

    .line 285
    .line 286
    .line 287
    iget-object v0, v1, Lfz7;->m:Lte4;

    .line 288
    .line 289
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 290
    .line 291
    invoke-interface {v0, v1}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 292
    .line 293
    .line 294
    :cond_5
    return-object v9

    .line 295
    :pswitch_5
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 296
    .line 297
    check-cast v1, Ljj1;

    .line 298
    .line 299
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 300
    .line 301
    .line 302
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 303
    .line 304
    check-cast v0, Landroid/content/Context;

    .line 305
    .line 306
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 307
    .line 308
    .line 309
    move-result-object v1

    .line 310
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 311
    .line 312
    .line 313
    check-cast v10, Lzs6;

    .line 314
    .line 315
    new-instance v2, Ljava/io/File;

    .line 316
    .line 317
    new-instance v0, Ljava/io/File;

    .line 318
    .line 319
    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 320
    .line 321
    .line 322
    move-result-object v4

    .line 323
    const-string v5, "schema"

    .line 324
    .line 325
    invoke-direct {v0, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 326
    .line 327
    .line 328
    iget-object v4, v10, Lzs6;->k:Ljava/lang/String;

    .line 329
    .line 330
    invoke-direct {v2, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 331
    .line 332
    .line 333
    const-wide/32 v4, 0x200000

    .line 334
    .line 335
    .line 336
    :try_start_0
    invoke-virtual {v2}, Ljava/io/File;->isFile()Z

    .line 337
    .line 338
    .line 339
    move-result v0

    .line 340
    if-eqz v0, :cond_6

    .line 341
    .line 342
    invoke-virtual {v2}, Ljava/io/File;->length()J

    .line 343
    .line 344
    .line 345
    move-result-wide v11

    .line 346
    const-wide/16 v13, 0x0

    .line 347
    .line 348
    cmp-long v0, v11, v13

    .line 349
    .line 350
    if-lez v0, :cond_6

    .line 351
    .line 352
    invoke-virtual {v2}, Ljava/io/File;->length()J

    .line 353
    .line 354
    .line 355
    move-result-wide v11

    .line 356
    cmp-long v0, v11, v4

    .line 357
    .line 358
    if-gtz v0, :cond_6

    .line 359
    .line 360
    new-instance v9, Ljava/io/FileInputStream;

    .line 361
    .line 362
    invoke-direct {v9, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 363
    .line 364
    .line 365
    :try_start_1
    invoke-static {v9, v4, v5}, Lcw;->J(Ljava/io/InputStream;J)Ljava/lang/String;

    .line 366
    .line 367
    .line 368
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 369
    :try_start_2
    invoke-virtual {v9}, Ljava/io/FileInputStream;->close()V

    .line 370
    .line 371
    .line 372
    invoke-static {v0}, Lvl3;->U(Ljava/lang/String;)Z

    .line 373
    .line 374
    .line 375
    move-result v9
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 376
    if-nez v9, :cond_7

    .line 377
    .line 378
    move-object v0, v6

    .line 379
    goto :goto_0

    .line 380
    :catchall_0
    move-exception v0

    .line 381
    move-object v11, v0

    .line 382
    :try_start_3
    throw v11
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 383
    :catchall_1
    move-exception v0

    .line 384
    :try_start_4
    invoke-static {v9, v11}, Lsx;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 385
    .line 386
    .line 387
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 388
    :cond_6
    move-object v0, v6

    .line 389
    goto :goto_1

    .line 390
    :catchall_2
    move-exception v0

    .line 391
    new-instance v9, Ltz5;

    .line 392
    .line 393
    invoke-direct {v9, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 394
    .line 395
    .line 396
    move-object v0, v9

    .line 397
    :cond_7
    :goto_0
    instance-of v9, v0, Ltz5;

    .line 398
    .line 399
    if-eqz v9, :cond_8

    .line 400
    .line 401
    move-object v0, v6

    .line 402
    :cond_8
    check-cast v0, Ljava/lang/String;

    .line 403
    .line 404
    :goto_1
    if-eqz v0, :cond_9

    .line 405
    .line 406
    new-instance v1, Lys6;

    .line 407
    .line 408
    invoke-direct {v1, v3, v0, v6}, Lys6;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 409
    .line 410
    .line 411
    goto/16 :goto_4

    .line 412
    .line 413
    :cond_9
    iget-object v0, v10, Lzs6;->j:Ljava/lang/String;

    .line 414
    .line 415
    if-eqz v0, :cond_b

    .line 416
    .line 417
    :try_start_5
    invoke-virtual {v1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 418
    .line 419
    .line 420
    move-result-object v1

    .line 421
    invoke-virtual {v1, v0}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    .line 422
    .line 423
    .line 424
    move-result-object v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 425
    :try_start_6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 426
    .line 427
    .line 428
    invoke-static {v1, v4, v5}, Lcw;->J(Ljava/io/InputStream;J)Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 432
    :try_start_7
    invoke-interface {v1}, Ljava/io/Closeable;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    .line 433
    .line 434
    .line 435
    goto :goto_2

    .line 436
    :catchall_3
    move-exception v0

    .line 437
    move-object v9, v0

    .line 438
    :try_start_8
    throw v9
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 439
    :catchall_4
    move-exception v0

    .line 440
    :try_start_9
    invoke-static {v1, v9}, Lsx;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 441
    .line 442
    .line 443
    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 444
    :catchall_5
    move-exception v0

    .line 445
    new-instance v1, Ltz5;

    .line 446
    .line 447
    invoke-direct {v1, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 448
    .line 449
    .line 450
    move-object v0, v1

    .line 451
    :goto_2
    instance-of v1, v0, Ltz5;

    .line 452
    .line 453
    if-eqz v1, :cond_a

    .line 454
    .line 455
    move-object v0, v6

    .line 456
    :cond_a
    check-cast v0, Ljava/lang/String;

    .line 457
    .line 458
    goto :goto_3

    .line 459
    :cond_b
    move-object v0, v6

    .line 460
    :goto_3
    if-eqz v0, :cond_c

    .line 461
    .line 462
    invoke-static {v0}, Lvl3;->U(Ljava/lang/String;)Z

    .line 463
    .line 464
    .line 465
    move-result v1

    .line 466
    if-nez v1, :cond_d

    .line 467
    .line 468
    :cond_c
    move-object v0, v6

    .line 469
    :cond_d
    if-eqz v0, :cond_f

    .line 470
    .line 471
    :try_start_a
    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 472
    .line 473
    .line 474
    move-result-object v1

    .line 475
    if-eqz v1, :cond_e

    .line 476
    .line 477
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 478
    .line 479
    .line 480
    :cond_e
    sget-object v1, Lsp0;->a:Ljava/nio/charset/Charset;

    .line 481
    .line 482
    new-instance v7, Ljava/io/ByteArrayInputStream;

    .line 483
    .line 484
    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 485
    .line 486
    .line 487
    move-result-object v1

    .line 488
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 489
    .line 490
    .line 491
    invoke-direct {v7, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 492
    .line 493
    .line 494
    new-instance v1, Ljava/lang/Long;

    .line 495
    .line 496
    invoke-direct {v1, v4, v5}, Ljava/lang/Long;-><init>(J)V

    .line 497
    .line 498
    .line 499
    const/16 v4, 0x8

    .line 500
    .line 501
    invoke-static {v2, v7, v1, v4}, Ly6;->B(Ljava/io/File;Ljava/io/InputStream;Ljava/lang/Long;I)J

    .line 502
    .line 503
    .line 504
    move-result-wide v1

    .line 505
    new-instance v4, Ljava/lang/Long;

    .line 506
    .line 507
    invoke-direct {v4, v1, v2}, Ljava/lang/Long;-><init>(J)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    .line 508
    .line 509
    .line 510
    :catchall_6
    new-instance v1, Lys6;

    .line 511
    .line 512
    invoke-direct {v1, v3, v0, v6}, Lys6;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 513
    .line 514
    .line 515
    goto :goto_4

    .line 516
    :cond_f
    new-instance v1, Lys6;

    .line 517
    .line 518
    const v0, 0x7f0f0434

    .line 519
    .line 520
    .line 521
    new-array v2, v7, [Ljava/lang/Object;

    .line 522
    .line 523
    invoke-static {v0, v2}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    invoke-direct {v1, v8, v6, v0}, Lys6;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 528
    .line 529
    .line 530
    :goto_4
    return-object v1

    .line 531
    :pswitch_6
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 532
    .line 533
    check-cast v1, [B

    .line 534
    .line 535
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 536
    .line 537
    check-cast v0, Ljj1;

    .line 538
    .line 539
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 540
    .line 541
    .line 542
    check-cast v10, Ljava/lang/String;

    .line 543
    .line 544
    invoke-static {v10}, Lwr6;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 545
    .line 546
    .line 547
    move-result-object v12

    .line 548
    sget-object v16, Lsz4;->h:Lsz4;

    .line 549
    .line 550
    if-nez v12, :cond_10

    .line 551
    .line 552
    const v0, 0x7f0f04ae

    .line 553
    .line 554
    .line 555
    new-array v1, v7, [Ljava/lang/Object;

    .line 556
    .line 557
    invoke-static {v0, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 558
    .line 559
    .line 560
    move-result-object v15

    .line 561
    new-instance v13, Luv;

    .line 562
    .line 563
    const/4 v14, 0x0

    .line 564
    const/16 v18, 0x1

    .line 565
    .line 566
    const/16 v17, 0x0

    .line 567
    .line 568
    invoke-direct/range {v13 .. v18}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 569
    .line 570
    .line 571
    goto/16 :goto_7

    .line 572
    .line 573
    :cond_10
    array-length v0, v1

    .line 574
    move v2, v7

    .line 575
    :goto_5
    if-ge v2, v0, :cond_12

    .line 576
    .line 577
    aget-byte v3, v1, v2

    .line 578
    .line 579
    if-nez v3, :cond_11

    .line 580
    .line 581
    const v0, 0x7f0f049d

    .line 582
    .line 583
    .line 584
    new-array v1, v7, [Ljava/lang/Object;

    .line 585
    .line 586
    invoke-static {v0, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 587
    .line 588
    .line 589
    move-result-object v15

    .line 590
    new-instance v13, Luv;

    .line 591
    .line 592
    const/4 v14, 0x0

    .line 593
    const/16 v18, 0x1

    .line 594
    .line 595
    const/16 v17, 0x0

    .line 596
    .line 597
    invoke-direct/range {v13 .. v18}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 598
    .line 599
    .line 600
    goto/16 :goto_7

    .line 601
    .line 602
    :cond_11
    add-int/lit8 v2, v2, 0x1

    .line 603
    .line 604
    goto :goto_5

    .line 605
    :cond_12
    sget-object v0, Lge0;->a:Lge0;

    .line 606
    .line 607
    invoke-static {}, Lge0;->e()V

    .line 608
    .line 609
    .line 610
    new-instance v0, Ljava/io/File;

    .line 611
    .line 612
    invoke-static {}, Lge0;->k()Lwd0;

    .line 613
    .line 614
    .line 615
    move-result-object v2

    .line 616
    iget-object v2, v2, Lwd0;->a:Ljava/io/File;

    .line 617
    .line 618
    const-string v3, "scripts"

    .line 619
    .line 620
    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 621
    .line 622
    .line 623
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 624
    .line 625
    .line 626
    new-instance v2, Ljava/io/File;

    .line 627
    .line 628
    new-instance v0, Ljava/io/File;

    .line 629
    .line 630
    invoke-static {}, Lge0;->k()Lwd0;

    .line 631
    .line 632
    .line 633
    move-result-object v4

    .line 634
    iget-object v4, v4, Lwd0;->a:Ljava/io/File;

    .line 635
    .line 636
    invoke-direct {v0, v4, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 637
    .line 638
    .line 639
    invoke-direct {v2, v0, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 640
    .line 641
    .line 642
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    .line 643
    .line 644
    .line 645
    move-result v0

    .line 646
    if-eqz v0, :cond_13

    .line 647
    .line 648
    const v0, 0x7f0f00b8

    .line 649
    .line 650
    .line 651
    new-array v1, v7, [Ljava/lang/Object;

    .line 652
    .line 653
    invoke-static {v0, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 654
    .line 655
    .line 656
    move-result-object v4

    .line 657
    new-instance v2, Luv;

    .line 658
    .line 659
    const/4 v3, 0x0

    .line 660
    const/4 v7, 0x1

    .line 661
    sget-object v5, Lsz4;->j:Lsz4;

    .line 662
    .line 663
    const/4 v6, 0x0

    .line 664
    invoke-direct/range {v2 .. v7}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 665
    .line 666
    .line 667
    move-object v13, v2

    .line 668
    goto :goto_7

    .line 669
    :cond_13
    :try_start_b
    new-instance v3, Ljava/io/FileOutputStream;

    .line 670
    .line 671
    invoke-direct {v3, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_9

    .line 672
    .line 673
    .line 674
    :try_start_c
    invoke-virtual {v3, v1}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_7

    .line 675
    .line 676
    .line 677
    :try_start_d
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_9

    .line 678
    .line 679
    .line 680
    goto :goto_6

    .line 681
    :catchall_7
    move-exception v0

    .line 682
    move-object v1, v0

    .line 683
    :try_start_e
    throw v1
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_8

    .line 684
    :catchall_8
    move-exception v0

    .line 685
    :try_start_f
    invoke-static {v3, v1}, Lsx;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 686
    .line 687
    .line 688
    throw v0
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_9

    .line 689
    :catchall_9
    move-exception v0

    .line 690
    new-instance v9, Ltz5;

    .line 691
    .line 692
    invoke-direct {v9, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 693
    .line 694
    .line 695
    :goto_6
    invoke-static {v9}, Luz5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 696
    .line 697
    .line 698
    move-result-object v17

    .line 699
    if-nez v17, :cond_14

    .line 700
    .line 701
    check-cast v9, Lst7;

    .line 702
    .line 703
    new-instance v3, Luv;

    .line 704
    .line 705
    new-instance v4, Lur6;

    .line 706
    .line 707
    const-string v0, "scripts/"

    .line 708
    .line 709
    invoke-virtual {v0, v12}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 710
    .line 711
    .line 712
    move-result-object v13

    .line 713
    invoke-virtual {v2}, Ljava/io/File;->length()J

    .line 714
    .line 715
    .line 716
    move-result-wide v14

    .line 717
    invoke-static {v12}, Lwr6;->d(Ljava/lang/String;)Lsr6;

    .line 718
    .line 719
    .line 720
    move-result-object v16

    .line 721
    move-object v11, v4

    .line 722
    invoke-direct/range {v11 .. v16}, Lur6;-><init>(Ljava/lang/String;Ljava/lang/String;JLsr6;)V

    .line 723
    .line 724
    .line 725
    const/4 v7, 0x0

    .line 726
    const/16 v8, 0xe

    .line 727
    .line 728
    const/4 v5, 0x0

    .line 729
    const/4 v6, 0x0

    .line 730
    invoke-direct/range {v3 .. v8}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 731
    .line 732
    .line 733
    move-object v13, v3

    .line 734
    goto :goto_7

    .line 735
    :cond_14
    const v0, 0x7f0f00e3

    .line 736
    .line 737
    .line 738
    new-array v1, v7, [Ljava/lang/Object;

    .line 739
    .line 740
    invoke-static {v0, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 741
    .line 742
    .line 743
    move-result-object v15

    .line 744
    new-instance v13, Luv;

    .line 745
    .line 746
    const/4 v14, 0x0

    .line 747
    const/16 v18, 0x1

    .line 748
    .line 749
    sget-object v16, Lsz4;->l:Lsz4;

    .line 750
    .line 751
    invoke-direct/range {v13 .. v18}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 752
    .line 753
    .line 754
    :goto_7
    return-object v13

    .line 755
    :pswitch_7
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 756
    .line 757
    .line 758
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 759
    .line 760
    check-cast v1, Lte4;

    .line 761
    .line 762
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 763
    .line 764
    .line 765
    move-result-object v2

    .line 766
    check-cast v2, Ljava/lang/Boolean;

    .line 767
    .line 768
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 769
    .line 770
    .line 771
    move-result v2

    .line 772
    if-eqz v2, :cond_15

    .line 773
    .line 774
    check-cast v10, Lte4;

    .line 775
    .line 776
    invoke-interface {v10}, Lmz6;->getValue()Ljava/lang/Object;

    .line 777
    .line 778
    .line 779
    move-result-object v2

    .line 780
    check-cast v2, Ljava/lang/Boolean;

    .line 781
    .line 782
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 783
    .line 784
    .line 785
    move-result v2

    .line 786
    if-eqz v2, :cond_15

    .line 787
    .line 788
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 789
    .line 790
    invoke-interface {v1, v2}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 791
    .line 792
    .line 793
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 794
    .line 795
    check-cast v0, Landroid/content/Context;

    .line 796
    .line 797
    invoke-static {v0}, Ldw;->A(Landroid/content/Context;)Landroid/content/SharedPreferences;

    .line 798
    .line 799
    .line 800
    move-result-object v0

    .line 801
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 802
    .line 803
    .line 804
    move-result-object v0

    .line 805
    const-string v1, "sticky_scroll"

    .line 806
    .line 807
    invoke-interface {v0, v1, v8}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 808
    .line 809
    .line 810
    const-string v1, "word_wrap"

    .line 811
    .line 812
    invoke-interface {v0, v1, v7}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 813
    .line 814
    .line 815
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 816
    .line 817
    .line 818
    :cond_15
    return-object v9

    .line 819
    :pswitch_8
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 820
    .line 821
    .line 822
    check-cast v10, Ljava/lang/String;

    .line 823
    .line 824
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 825
    .line 826
    check-cast v1, Ljava/lang/String;

    .line 827
    .line 828
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 829
    .line 830
    move-object v2, v0

    .line 831
    check-cast v2, Ljava/lang/String;

    .line 832
    .line 833
    sget-object v0, Lm96;->a:Lex5;

    .line 834
    .line 835
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 836
    .line 837
    .line 838
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 839
    .line 840
    .line 841
    invoke-static {v1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 842
    .line 843
    .line 844
    move-result v0

    .line 845
    sget-object v3, Lo22;->h:Lo22;

    .line 846
    .line 847
    if-nez v0, :cond_34

    .line 848
    .line 849
    const/16 v0, 0x2e

    .line 850
    .line 851
    const-string v4, ""

    .line 852
    .line 853
    invoke-static {v10, v0, v4}, Lf17;->U0(Ljava/lang/String;CLjava/lang/String;)Ljava/lang/String;

    .line 854
    .line 855
    .line 856
    move-result-object v0

    .line 857
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 858
    .line 859
    invoke-static {v5, v0, v5}, Lp92;->t(Ljava/util/Locale;Ljava/lang/String;Ljava/util/Locale;)Ljava/lang/String;

    .line 860
    .line 861
    .line 862
    move-result-object v0

    .line 863
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 864
    .line 865
    .line 866
    move-result v5

    .line 867
    sparse-switch v5, :sswitch_data_0

    .line 868
    .line 869
    .line 870
    goto/16 :goto_15

    .line 871
    .line 872
    :sswitch_0
    const-string v5, "jsonc"

    .line 873
    .line 874
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 875
    .line 876
    .line 877
    move-result v0

    .line 878
    if-nez v0, :cond_16

    .line 879
    .line 880
    goto/16 :goto_15

    .line 881
    .line 882
    :sswitch_1
    const-string v2, "yaml"

    .line 883
    .line 884
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 885
    .line 886
    .line 887
    move-result v0

    .line 888
    if-nez v0, :cond_2c

    .line 889
    .line 890
    goto/16 :goto_15

    .line 891
    .line 892
    :sswitch_2
    const-string v5, "json"

    .line 893
    .line 894
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 895
    .line 896
    .line 897
    move-result v0

    .line 898
    if-eqz v0, :cond_34

    .line 899
    .line 900
    :cond_16
    :try_start_10
    sget-object v0, Lqd3;->k:Lqd3;

    .line 901
    .line 902
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 903
    .line 904
    .line 905
    new-instance v5, Ljava/io/StringReader;

    .line 906
    .line 907
    invoke-direct {v5, v1}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    .line 908
    .line 909
    .line 910
    new-instance v9, Lmd3;

    .line 911
    .line 912
    invoke-direct {v9, v5, v0}, Lmd3;-><init>(Ljava/io/StringReader;Lqd3;)V

    .line 913
    .line 914
    .line 915
    invoke-virtual {v9}, Lmd3;->l()C

    .line 916
    .line 917
    .line 918
    move-result v0

    .line 919
    iget-object v10, v9, Lmd3;->k:Ljava/lang/StringBuilder;

    .line 920
    .line 921
    if-nez v10, :cond_17

    .line 922
    .line 923
    move-object v10, v6

    .line 924
    goto :goto_8

    .line 925
    :cond_17
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 926
    .line 927
    .line 928
    move-result-object v10

    .line 929
    iput-object v6, v9, Lmd3;->k:Ljava/lang/StringBuilder;

    .line 930
    .line 931
    :goto_8
    if-eqz v0, :cond_1a

    .line 932
    .line 933
    const/16 v11, 0x5b

    .line 934
    .line 935
    if-eq v0, v11, :cond_19

    .line 936
    .line 937
    const/16 v11, 0x7b

    .line 938
    .line 939
    if-ne v0, v11, :cond_18

    .line 940
    .line 941
    iput-boolean v8, v9, Lmd3;->e:Z

    .line 942
    .line 943
    invoke-static {v9}, Llx;->H(Lmd3;)Lod3;

    .line 944
    .line 945
    .line 946
    move-result-object v0

    .line 947
    goto :goto_9

    .line 948
    :cond_18
    const-string v0, "Unknown or unexpected control character"

    .line 949
    .line 950
    invoke-virtual {v9, v0}, Lmd3;->p(Ljava/lang/String;)Lld3;

    .line 951
    .line 952
    .line 953
    move-result-object v0

    .line 954
    throw v0

    .line 955
    :cond_19
    iput-boolean v8, v9, Lmd3;->e:Z

    .line 956
    .line 957
    invoke-static {v9}, Llx;->G(Lmd3;)Ljd3;

    .line 958
    .line 959
    .line 960
    move-result-object v0

    .line 961
    :goto_9
    iget-object v9, v9, Lmd3;->b:Lqd3;

    .line 962
    .line 963
    iget-boolean v9, v9, Lqd3;->e:Z

    .line 964
    .line 965
    if-eqz v9, :cond_1b

    .line 966
    .line 967
    if-eqz v10, :cond_1b

    .line 968
    .line 969
    iput-object v10, v0, Lkd3;->h:Ljava/lang/String;

    .line 970
    .line 971
    goto :goto_a

    .line 972
    :cond_1a
    move-object v0, v6

    .line 973
    :cond_1b
    :goto_a
    invoke-virtual {v5}, Ljava/io/StringReader;->close()V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_a

    .line 974
    .line 975
    .line 976
    goto :goto_b

    .line 977
    :catchall_a
    move-exception v0

    .line 978
    new-instance v5, Ltz5;

    .line 979
    .line 980
    invoke-direct {v5, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 981
    .line 982
    .line 983
    move-object v0, v5

    .line 984
    :goto_b
    invoke-static {v0}, Luz5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 985
    .line 986
    .line 987
    move-result-object v5

    .line 988
    if-eqz v5, :cond_24

    .line 989
    .line 990
    instance-of v0, v5, Lld3;

    .line 991
    .line 992
    const v2, 0x7f0f042a

    .line 993
    .line 994
    .line 995
    if-eqz v0, :cond_22

    .line 996
    .line 997
    check-cast v5, Lld3;

    .line 998
    .line 999
    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1000
    .line 1001
    .line 1002
    move-result-object v0

    .line 1003
    if-eqz v0, :cond_1c

    .line 1004
    .line 1005
    move-object v4, v0

    .line 1006
    :cond_1c
    sget-object v0, Lm96;->a:Lex5;

    .line 1007
    .line 1008
    invoke-static {v0, v4}, Lex5;->a(Lex5;Ljava/lang/String;)Lb04;

    .line 1009
    .line 1010
    .line 1011
    move-result-object v0

    .line 1012
    if-eqz v0, :cond_1d

    .line 1013
    .line 1014
    invoke-virtual {v0}, Lb04;->a()Ljava/util/List;

    .line 1015
    .line 1016
    .line 1017
    move-result-object v0

    .line 1018
    invoke-static {v8, v0}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 1019
    .line 1020
    .line 1021
    move-result-object v0

    .line 1022
    check-cast v0, Ljava/lang/String;

    .line 1023
    .line 1024
    if-eqz v0, :cond_1d

    .line 1025
    .line 1026
    invoke-static {v0}, Lm17;->l0(Ljava/lang/String;)Ljava/lang/Integer;

    .line 1027
    .line 1028
    .line 1029
    move-result-object v6

    .line 1030
    :cond_1d
    if-nez v6, :cond_1e

    .line 1031
    .line 1032
    new-instance v0, Lz86;

    .line 1033
    .line 1034
    invoke-static {v4}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1035
    .line 1036
    .line 1037
    move-result-object v3

    .line 1038
    invoke-direct {v0, v2, v3}, Lz86;-><init>(ILjava/util/List;)V

    .line 1039
    .line 1040
    .line 1041
    invoke-static {v1, v7, v0}, Lm96;->a(Ljava/lang/String;ILz86;)Lj86;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v0

    .line 1045
    goto :goto_d

    .line 1046
    :cond_1e
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 1047
    .line 1048
    .line 1049
    move-result v0

    .line 1050
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 1051
    .line 1052
    .line 1053
    move-result v2

    .line 1054
    invoke-static {v0, v7, v2}, Lej3;->v(III)I

    .line 1055
    .line 1056
    .line 1057
    move-result v0

    .line 1058
    invoke-static {v0, v1}, Lf17;->Y0(ILjava/lang/String;)Ljava/lang/String;

    .line 1059
    .line 1060
    .line 1061
    move-result-object v2

    .line 1062
    move v3, v7

    .line 1063
    move v5, v3

    .line 1064
    :goto_c
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 1065
    .line 1066
    .line 1067
    move-result v6

    .line 1068
    const/16 v9, 0xa

    .line 1069
    .line 1070
    if-ge v3, v6, :cond_20

    .line 1071
    .line 1072
    invoke-virtual {v2, v3}, Ljava/lang/String;->charAt(I)C

    .line 1073
    .line 1074
    .line 1075
    move-result v6

    .line 1076
    if-ne v6, v9, :cond_1f

    .line 1077
    .line 1078
    add-int/lit8 v5, v5, 0x1

    .line 1079
    .line 1080
    :cond_1f
    add-int/lit8 v3, v3, 0x1

    .line 1081
    .line 1082
    goto :goto_c

    .line 1083
    :cond_20
    add-int/2addr v5, v8

    .line 1084
    add-int/lit8 v2, v0, -0x1

    .line 1085
    .line 1086
    if-ltz v2, :cond_21

    .line 1087
    .line 1088
    move v7, v2

    .line 1089
    :cond_21
    const/4 v2, 0x4

    .line 1090
    invoke-static {v1, v9, v7, v2}, Lf17;->D0(Ljava/lang/CharSequence;CII)I

    .line 1091
    .line 1092
    .line 1093
    move-result v2

    .line 1094
    sub-int v2, v0, v2

    .line 1095
    .line 1096
    sget-object v3, Lm96;->b:Lex5;

    .line 1097
    .line 1098
    invoke-virtual {v3, v4}, Lex5;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 1099
    .line 1100
    .line 1101
    move-result-object v3

    .line 1102
    invoke-static {v3}, Lf17;->Z0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1103
    .line 1104
    .line 1105
    move-result-object v3

    .line 1106
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1107
    .line 1108
    .line 1109
    move-result-object v3

    .line 1110
    new-instance v4, Lz86;

    .line 1111
    .line 1112
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1113
    .line 1114
    .line 1115
    move-result-object v5

    .line 1116
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1117
    .line 1118
    .line 1119
    move-result-object v2

    .line 1120
    filled-new-array {v5, v2, v3}, [Ljava/lang/Object;

    .line 1121
    .line 1122
    .line 1123
    move-result-object v2

    .line 1124
    invoke-static {v2}, Lix;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 1125
    .line 1126
    .line 1127
    move-result-object v2

    .line 1128
    const v3, 0x7f0f0429

    .line 1129
    .line 1130
    .line 1131
    invoke-direct {v4, v3, v2}, Lz86;-><init>(ILjava/util/List;)V

    .line 1132
    .line 1133
    .line 1134
    invoke-static {v1, v0, v4}, Lm96;->a(Ljava/lang/String;ILz86;)Lj86;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v0

    .line 1138
    :goto_d
    invoke-static {v0}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1139
    .line 1140
    .line 1141
    move-result-object v0

    .line 1142
    :goto_e
    move-object v3, v0

    .line 1143
    goto/16 :goto_15

    .line 1144
    .line 1145
    :cond_22
    new-instance v0, Lz86;

    .line 1146
    .line 1147
    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1148
    .line 1149
    .line 1150
    move-result-object v3

    .line 1151
    if-eqz v3, :cond_23

    .line 1152
    .line 1153
    move-object v4, v3

    .line 1154
    :cond_23
    invoke-static {v4}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1155
    .line 1156
    .line 1157
    move-result-object v3

    .line 1158
    invoke-direct {v0, v2, v3}, Lz86;-><init>(ILjava/util/List;)V

    .line 1159
    .line 1160
    .line 1161
    invoke-static {v1, v7, v0}, Lm96;->a(Ljava/lang/String;ILz86;)Lj86;

    .line 1162
    .line 1163
    .line 1164
    move-result-object v0

    .line 1165
    invoke-static {v0}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1166
    .line 1167
    .line 1168
    move-result-object v0

    .line 1169
    goto :goto_e

    .line 1170
    :cond_24
    instance-of v5, v0, Ltz5;

    .line 1171
    .line 1172
    if-eqz v5, :cond_25

    .line 1173
    .line 1174
    move-object v0, v6

    .line 1175
    :cond_25
    move-object v5, v0

    .line 1176
    check-cast v5, Lkd3;

    .line 1177
    .line 1178
    if-eqz v5, :cond_34

    .line 1179
    .line 1180
    :try_start_11
    new-instance v0, Lorg/json/JSONObject;

    .line 1181
    .line 1182
    if-nez v2, :cond_26

    .line 1183
    .line 1184
    move-object v2, v4

    .line 1185
    :cond_26
    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_b

    .line 1186
    .line 1187
    .line 1188
    goto :goto_f

    .line 1189
    :catchall_b
    move-exception v0

    .line 1190
    new-instance v2, Ltz5;

    .line 1191
    .line 1192
    invoke-direct {v2, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 1193
    .line 1194
    .line 1195
    move-object v0, v2

    .line 1196
    :goto_f
    instance-of v2, v0, Ltz5;

    .line 1197
    .line 1198
    if-eqz v2, :cond_27

    .line 1199
    .line 1200
    move-object v0, v6

    .line 1201
    :cond_27
    check-cast v0, Lorg/json/JSONObject;

    .line 1202
    .line 1203
    if-eqz v0, :cond_34

    .line 1204
    .line 1205
    const-string v2, "properties"

    .line 1206
    .line 1207
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1208
    .line 1209
    .line 1210
    move-result-object v0

    .line 1211
    if-eqz v0, :cond_34

    .line 1212
    .line 1213
    instance-of v2, v5, Lod3;

    .line 1214
    .line 1215
    if-eqz v2, :cond_34

    .line 1216
    .line 1217
    check-cast v5, Lod3;

    .line 1218
    .line 1219
    iget-object v2, v5, Lod3;->i:Lsr3;

    .line 1220
    .line 1221
    invoke-virtual {v2}, Lsr3;->keySet()Ljava/util/Set;

    .line 1222
    .line 1223
    .line 1224
    move-result-object v2

    .line 1225
    new-instance v3, Ljava/util/ArrayList;

    .line 1226
    .line 1227
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1228
    .line 1229
    .line 1230
    check-cast v2, Lnr3;

    .line 1231
    .line 1232
    invoke-virtual {v2}, Lnr3;->iterator()Ljava/util/Iterator;

    .line 1233
    .line 1234
    .line 1235
    move-result-object v2

    .line 1236
    :cond_28
    :goto_10
    move-object v4, v2

    .line 1237
    check-cast v4, Lpr3;

    .line 1238
    .line 1239
    invoke-virtual {v4}, Lpr3;->hasNext()Z

    .line 1240
    .line 1241
    .line 1242
    move-result v4

    .line 1243
    if-eqz v4, :cond_34

    .line 1244
    .line 1245
    move-object v4, v2

    .line 1246
    check-cast v4, Llr3;

    .line 1247
    .line 1248
    invoke-virtual {v4}, Lpr3;->a()Lqr3;

    .line 1249
    .line 1250
    .line 1251
    move-result-object v4

    .line 1252
    iget-object v4, v4, Lqr3;->m:Ljava/lang/Object;

    .line 1253
    .line 1254
    check-cast v4, Ljava/lang/String;

    .line 1255
    .line 1256
    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 1257
    .line 1258
    .line 1259
    move-result v5

    .line 1260
    if-eqz v5, :cond_29

    .line 1261
    .line 1262
    move-object v4, v6

    .line 1263
    goto/16 :goto_12

    .line 1264
    .line 1265
    :cond_29
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1266
    .line 1267
    .line 1268
    invoke-static {v4}, Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;

    .line 1269
    .line 1270
    .line 1271
    move-result-object v5

    .line 1272
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1273
    .line 1274
    .line 1275
    new-instance v8, Ljava/lang/StringBuilder;

    .line 1276
    .line 1277
    const-string v9, "\\\""

    .line 1278
    .line 1279
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1280
    .line 1281
    .line 1282
    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1283
    .line 1284
    .line 1285
    const-string v9, "\\\"\\s*:"

    .line 1286
    .line 1287
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1288
    .line 1289
    .line 1290
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1291
    .line 1292
    .line 1293
    move-result-object v8

    .line 1294
    invoke-static {v8}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 1295
    .line 1296
    .line 1297
    move-result-object v8

    .line 1298
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1299
    .line 1300
    .line 1301
    invoke-virtual {v8, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1302
    .line 1303
    .line 1304
    move-result-object v8

    .line 1305
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1306
    .line 1307
    .line 1308
    invoke-static {v8, v7, v1}, Lti3;->y(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lb04;

    .line 1309
    .line 1310
    .line 1311
    move-result-object v8

    .line 1312
    if-eqz v8, :cond_2a

    .line 1313
    .line 1314
    invoke-virtual {v8}, Lb04;->b()Ls93;

    .line 1315
    .line 1316
    .line 1317
    move-result-object v5

    .line 1318
    iget v5, v5, Lq93;->h:I

    .line 1319
    .line 1320
    goto :goto_11

    .line 1321
    :cond_2a
    new-instance v8, Ljava/lang/StringBuilder;

    .line 1322
    .line 1323
    const-string v9, "(?m)(?<!\\w)"

    .line 1324
    .line 1325
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1326
    .line 1327
    .line 1328
    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1329
    .line 1330
    .line 1331
    const-string v5, "(?!\\w)\\s*:"

    .line 1332
    .line 1333
    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1334
    .line 1335
    .line 1336
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1337
    .line 1338
    .line 1339
    move-result-object v5

    .line 1340
    invoke-static {v5}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 1341
    .line 1342
    .line 1343
    move-result-object v5

    .line 1344
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1345
    .line 1346
    .line 1347
    invoke-virtual {v5, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1348
    .line 1349
    .line 1350
    move-result-object v5

    .line 1351
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1352
    .line 1353
    .line 1354
    invoke-static {v5, v7, v1}, Lti3;->y(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lb04;

    .line 1355
    .line 1356
    .line 1357
    move-result-object v5

    .line 1358
    if-eqz v5, :cond_2b

    .line 1359
    .line 1360
    invoke-virtual {v5}, Lb04;->b()Ls93;

    .line 1361
    .line 1362
    .line 1363
    move-result-object v5

    .line 1364
    if-eqz v5, :cond_2b

    .line 1365
    .line 1366
    iget v5, v5, Lq93;->h:I

    .line 1367
    .line 1368
    goto :goto_11

    .line 1369
    :cond_2b
    move v5, v7

    .line 1370
    :goto_11
    new-instance v8, Lz86;

    .line 1371
    .line 1372
    const v9, 0x7f0f043a

    .line 1373
    .line 1374
    .line 1375
    invoke-static {v4}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1376
    .line 1377
    .line 1378
    move-result-object v4

    .line 1379
    invoke-direct {v8, v9, v4}, Lz86;-><init>(ILjava/util/List;)V

    .line 1380
    .line 1381
    .line 1382
    invoke-static {v1, v5, v8}, Lm96;->a(Ljava/lang/String;ILz86;)Lj86;

    .line 1383
    .line 1384
    .line 1385
    move-result-object v4

    .line 1386
    :goto_12
    if-eqz v4, :cond_28

    .line 1387
    .line 1388
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1389
    .line 1390
    .line 1391
    goto/16 :goto_10

    .line 1392
    .line 1393
    :sswitch_3
    const-string v2, "yml"

    .line 1394
    .line 1395
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1396
    .line 1397
    .line 1398
    move-result v0

    .line 1399
    if-eqz v0, :cond_34

    .line 1400
    .line 1401
    :cond_2c
    const v2, 0x7f0f042b

    .line 1402
    .line 1403
    .line 1404
    :try_start_12
    invoke-static {}, Lm96;->c()Lht3;

    .line 1405
    .line 1406
    .line 1407
    move-result-object v0

    .line 1408
    invoke-static {v1}, Lm96;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 1409
    .line 1410
    .line 1411
    move-result-object v5

    .line 1412
    invoke-virtual {v0, v5}, Lht3;->a(Ljava/lang/String;)Ljava/lang/Object;
    :try_end_12
    .catch Lf51; {:try_start_12 .. :try_end_12} :catch_2
    .catch Lw48; {:try_start_12 .. :try_end_12} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_12 .. :try_end_12} :catch_0

    .line 1413
    .line 1414
    .line 1415
    goto/16 :goto_15

    .line 1416
    .line 1417
    :catch_0
    move-exception v0

    .line 1418
    new-instance v3, Lz86;

    .line 1419
    .line 1420
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1421
    .line 1422
    .line 1423
    move-result-object v0

    .line 1424
    if-eqz v0, :cond_2d

    .line 1425
    .line 1426
    move-object v4, v0

    .line 1427
    :cond_2d
    invoke-static {v4}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1428
    .line 1429
    .line 1430
    move-result-object v0

    .line 1431
    invoke-direct {v3, v2, v0}, Lz86;-><init>(ILjava/util/List;)V

    .line 1432
    .line 1433
    .line 1434
    invoke-static {v1, v7, v3}, Lm96;->a(Ljava/lang/String;ILz86;)Lj86;

    .line 1435
    .line 1436
    .line 1437
    move-result-object v0

    .line 1438
    invoke-static {v0}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1439
    .line 1440
    .line 1441
    move-result-object v0

    .line 1442
    goto/16 :goto_e

    .line 1443
    .line 1444
    :catch_1
    move-exception v0

    .line 1445
    new-instance v3, Lz86;

    .line 1446
    .line 1447
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1448
    .line 1449
    .line 1450
    move-result-object v0

    .line 1451
    if-eqz v0, :cond_2e

    .line 1452
    .line 1453
    move-object v4, v0

    .line 1454
    :cond_2e
    invoke-static {v4}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1455
    .line 1456
    .line 1457
    move-result-object v0

    .line 1458
    invoke-direct {v3, v2, v0}, Lz86;-><init>(ILjava/util/List;)V

    .line 1459
    .line 1460
    .line 1461
    invoke-static {v1, v7, v3}, Lm96;->a(Ljava/lang/String;ILz86;)Lj86;

    .line 1462
    .line 1463
    .line 1464
    move-result-object v0

    .line 1465
    invoke-static {v0}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1466
    .line 1467
    .line 1468
    move-result-object v0

    .line 1469
    goto/16 :goto_e

    .line 1470
    .line 1471
    :catch_2
    move-exception v0

    .line 1472
    iget-object v2, v0, Lf51;->k:Ljava/util/Optional;

    .line 1473
    .line 1474
    invoke-virtual {v2, v6}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1475
    .line 1476
    .line 1477
    move-result-object v2

    .line 1478
    check-cast v2, Lyy3;

    .line 1479
    .line 1480
    if-eqz v2, :cond_2f

    .line 1481
    .line 1482
    iget v3, v2, Lyy3;->h:I

    .line 1483
    .line 1484
    goto :goto_13

    .line 1485
    :cond_2f
    move v3, v7

    .line 1486
    :goto_13
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 1487
    .line 1488
    .line 1489
    move-result v4

    .line 1490
    invoke-static {v3, v7, v4}, Lej3;->v(III)I

    .line 1491
    .line 1492
    .line 1493
    move-result v3

    .line 1494
    if-eqz v2, :cond_30

    .line 1495
    .line 1496
    iget v4, v2, Lyy3;->i:I

    .line 1497
    .line 1498
    goto :goto_14

    .line 1499
    :cond_30
    move v4, v7

    .line 1500
    :goto_14
    add-int/2addr v4, v8

    .line 1501
    if-eqz v2, :cond_31

    .line 1502
    .line 1503
    iget v7, v2, Lyy3;->j:I

    .line 1504
    .line 1505
    :cond_31
    add-int/2addr v7, v8

    .line 1506
    iget-object v2, v0, Lf51;->j:Ljava/lang/String;

    .line 1507
    .line 1508
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1509
    .line 1510
    .line 1511
    invoke-static {v2}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 1512
    .line 1513
    .line 1514
    move-result v5

    .line 1515
    if-nez v5, :cond_32

    .line 1516
    .line 1517
    move-object v6, v2

    .line 1518
    :cond_32
    if-nez v6, :cond_33

    .line 1519
    .line 1520
    invoke-virtual {v0}, Lf51;->toString()Ljava/lang/String;

    .line 1521
    .line 1522
    .line 1523
    move-result-object v6

    .line 1524
    :cond_33
    new-instance v0, Lz86;

    .line 1525
    .line 1526
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1527
    .line 1528
    .line 1529
    move-result-object v2

    .line 1530
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1531
    .line 1532
    .line 1533
    move-result-object v4

    .line 1534
    filled-new-array {v2, v4, v6}, [Ljava/lang/Object;

    .line 1535
    .line 1536
    .line 1537
    move-result-object v2

    .line 1538
    invoke-static {v2}, Lix;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 1539
    .line 1540
    .line 1541
    move-result-object v2

    .line 1542
    const v4, 0x7f0f042c

    .line 1543
    .line 1544
    .line 1545
    invoke-direct {v0, v4, v2}, Lz86;-><init>(ILjava/util/List;)V

    .line 1546
    .line 1547
    .line 1548
    invoke-static {v1, v3, v0}, Lm96;->a(Ljava/lang/String;ILz86;)Lj86;

    .line 1549
    .line 1550
    .line 1551
    move-result-object v0

    .line 1552
    invoke-static {v0}, Lix;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 1553
    .line 1554
    .line 1555
    move-result-object v0

    .line 1556
    goto/16 :goto_e

    .line 1557
    .line 1558
    :cond_34
    :goto_15
    return-object v3

    .line 1559
    :pswitch_9
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 1560
    .line 1561
    check-cast v1, Lte4;

    .line 1562
    .line 1563
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1564
    .line 1565
    .line 1566
    iget-object v2, v0, Lav;->m:Ljava/lang/Object;

    .line 1567
    .line 1568
    check-cast v2, Laq5;

    .line 1569
    .line 1570
    if-eqz v2, :cond_35

    .line 1571
    .line 1572
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 1573
    .line 1574
    .line 1575
    move-result-object v3

    .line 1576
    check-cast v3, Lrq5;

    .line 1577
    .line 1578
    iget-object v3, v3, Lrq5;->d:Laq5;

    .line 1579
    .line 1580
    invoke-virtual {v2, v3}, Laq5;->equals(Ljava/lang/Object;)Z

    .line 1581
    .line 1582
    .line 1583
    move-result v2

    .line 1584
    if-nez v2, :cond_35

    .line 1585
    .line 1586
    check-cast v10, Lte4;

    .line 1587
    .line 1588
    invoke-interface {v10}, Lmz6;->getValue()Ljava/lang/Object;

    .line 1589
    .line 1590
    .line 1591
    move-result-object v2

    .line 1592
    check-cast v2, Lwh2;

    .line 1593
    .line 1594
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 1595
    .line 1596
    .line 1597
    move-result-object v1

    .line 1598
    move-object v10, v1

    .line 1599
    check-cast v10, Lrq5;

    .line 1600
    .line 1601
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 1602
    .line 1603
    move-object v14, v0

    .line 1604
    check-cast v14, Laq5;

    .line 1605
    .line 1606
    const/16 v18, 0x0

    .line 1607
    .line 1608
    const/16 v19, 0xe7

    .line 1609
    .line 1610
    const/4 v11, 0x0

    .line 1611
    const/4 v12, 0x0

    .line 1612
    const/4 v13, 0x0

    .line 1613
    const/4 v15, 0x0

    .line 1614
    const/16 v16, 0x0

    .line 1615
    .line 1616
    const/16 v17, 0x0

    .line 1617
    .line 1618
    invoke-static/range {v10 .. v19}, Lrq5;->a(Lrq5;ZZLvq0;Laq5;ZLjava/util/List;Ljava/util/Map;Ljava/lang/String;I)Lrq5;

    .line 1619
    .line 1620
    .line 1621
    move-result-object v0

    .line 1622
    invoke-interface {v2, v0}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1623
    .line 1624
    .line 1625
    :cond_35
    return-object v9

    .line 1626
    :pswitch_a
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1627
    .line 1628
    .line 1629
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 1630
    .line 1631
    check-cast v1, Landroid/content/Context;

    .line 1632
    .line 1633
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 1634
    .line 1635
    check-cast v0, Landroid/net/Uri;

    .line 1636
    .line 1637
    check-cast v10, Ljava/lang/String;

    .line 1638
    .line 1639
    :try_start_13
    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    .line 1640
    .line 1641
    .line 1642
    move-result-object v2

    .line 1643
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 1644
    .line 1645
    .line 1646
    move-result-object v3

    .line 1647
    invoke-virtual {v3, v0}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    .line 1648
    .line 1649
    .line 1650
    move-result-object v3

    .line 1651
    invoke-virtual {v2, v3}, Landroid/webkit/MimeTypeMap;->getExtensionFromMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 1652
    .line 1653
    .line 1654
    move-result-object v2

    .line 1655
    if-eqz v2, :cond_37

    .line 1656
    .line 1657
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 1658
    .line 1659
    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1660
    .line 1661
    .line 1662
    move-result-object v2

    .line 1663
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1664
    .line 1665
    .line 1666
    const-string v3, "[a-z0-9]{1,8}"

    .line 1667
    .line 1668
    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 1669
    .line 1670
    .line 1671
    move-result-object v3

    .line 1672
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1673
    .line 1674
    .line 1675
    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1676
    .line 1677
    .line 1678
    move-result-object v3

    .line 1679
    invoke-virtual {v3}, Ljava/util/regex/Matcher;->matches()Z

    .line 1680
    .line 1681
    .line 1682
    move-result v3

    .line 1683
    if-eqz v3, :cond_36

    .line 1684
    .line 1685
    move-object v6, v2

    .line 1686
    :cond_36
    if-nez v6, :cond_38

    .line 1687
    .line 1688
    :cond_37
    const-string v6, "jpg"

    .line 1689
    .line 1690
    :cond_38
    new-instance v2, Ljava/io/File;

    .line 1691
    .line 1692
    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 1693
    .line 1694
    .line 1695
    move-result-object v3

    .line 1696
    const-string v4, "policy-icons"

    .line 1697
    .line 1698
    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 1699
    .line 1700
    .line 1701
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .line 1702
    .line 1703
    .line 1704
    new-instance v3, Ljava/io/File;

    .line 1705
    .line 1706
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 1707
    .line 1708
    .line 1709
    move-result-object v4

    .line 1710
    new-instance v5, Ljava/lang/StringBuilder;

    .line 1711
    .line 1712
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 1713
    .line 1714
    .line 1715
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1716
    .line 1717
    .line 1718
    const-string v4, "."

    .line 1719
    .line 1720
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1721
    .line 1722
    .line 1723
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1724
    .line 1725
    .line 1726
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1727
    .line 1728
    .line 1729
    move-result-object v4

    .line 1730
    invoke-direct {v3, v2, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    :try_end_13
    .catch Ljava/util/concurrent/CancellationException; {:try_start_13 .. :try_end_13} :catch_3
    .catchall {:try_start_13 .. :try_end_13} :catchall_11

    .line 1731
    .line 1732
    .line 1733
    :try_start_14
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 1734
    .line 1735
    .line 1736
    move-result-object v2

    .line 1737
    invoke-virtual {v2, v0}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    .line 1738
    .line 1739
    .line 1740
    move-result-object v2
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_10

    .line 1741
    if-eqz v2, :cond_39

    .line 1742
    .line 1743
    :try_start_15
    new-instance v4, Ljava/io/FileOutputStream;

    .line 1744
    .line 1745
    invoke-direct {v4, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_e

    .line 1746
    .line 1747
    .line 1748
    :try_start_16
    invoke-static {v2, v4}, Lnx;->C(Ljava/io/InputStream;Ljava/io/OutputStream;)J
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_c

    .line 1749
    .line 1750
    .line 1751
    :try_start_17
    invoke-virtual {v4}, Ljava/io/FileOutputStream;->close()V
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_e

    .line 1752
    .line 1753
    .line 1754
    :try_start_18
    invoke-interface {v2}, Ljava/io/Closeable;->close()V
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_10

    .line 1755
    .line 1756
    .line 1757
    :try_start_19
    new-instance v0, Lsd5;

    .line 1758
    .line 1759
    sget-object v2, Lbe5;->j:Lbe5;

    .line 1760
    .line 1761
    invoke-static {v3}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    .line 1762
    .line 1763
    .line 1764
    move-result-object v3

    .line 1765
    invoke-virtual {v3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 1766
    .line 1767
    .line 1768
    move-result-object v3

    .line 1769
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1770
    .line 1771
    .line 1772
    invoke-direct {v0, v2, v3}, Lsd5;-><init>(Lbe5;Ljava/lang/String;)V

    .line 1773
    .line 1774
    .line 1775
    sget-object v2, Lae5;->a:Lae5;

    .line 1776
    .line 1777
    invoke-static {v1, v10, v0}, Lae5;->e(Landroid/content/Context;Ljava/lang/String;Lsd5;)V
    :try_end_19
    .catch Ljava/util/concurrent/CancellationException; {:try_start_19 .. :try_end_19} :catch_3
    .catchall {:try_start_19 .. :try_end_19} :catchall_11

    .line 1778
    .line 1779
    .line 1780
    goto :goto_16

    .line 1781
    :catchall_c
    move-exception v0

    .line 1782
    move-object v1, v0

    .line 1783
    :try_start_1a
    throw v1
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_d

    .line 1784
    :catchall_d
    move-exception v0

    .line 1785
    :try_start_1b
    invoke-static {v4, v1}, Lsx;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1786
    .line 1787
    .line 1788
    throw v0
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_e

    .line 1789
    :catchall_e
    move-exception v0

    .line 1790
    move-object v1, v0

    .line 1791
    :try_start_1c
    throw v1
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_f

    .line 1792
    :catchall_f
    move-exception v0

    .line 1793
    :try_start_1d
    invoke-static {v2, v1}, Lsx;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1794
    .line 1795
    .line 1796
    throw v0

    .line 1797
    :cond_39
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1798
    .line 1799
    new-array v1, v7, [Ljava/lang/Object;

    .line 1800
    .line 1801
    const v2, 0x7f0f00cf

    .line 1802
    .line 1803
    .line 1804
    invoke-static {v2, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1805
    .line 1806
    .line 1807
    move-result-object v1

    .line 1808
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1809
    .line 1810
    .line 1811
    move-result-object v1

    .line 1812
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1813
    .line 1814
    .line 1815
    throw v0
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_10

    .line 1816
    :catchall_10
    move-exception v0

    .line 1817
    :try_start_1e
    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    .line 1818
    .line 1819
    .line 1820
    throw v0
    :try_end_1e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e .. :try_end_1e} :catch_3
    .catchall {:try_start_1e .. :try_end_1e} :catchall_11

    .line 1821
    :catchall_11
    move-exception v0

    .line 1822
    new-instance v1, Ltz5;

    .line 1823
    .line 1824
    invoke-direct {v1, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 1825
    .line 1826
    .line 1827
    move-object v0, v1

    .line 1828
    :goto_16
    new-instance v1, Luz5;

    .line 1829
    .line 1830
    invoke-direct {v1, v0}, Luz5;-><init>(Ljava/lang/Object;)V

    .line 1831
    .line 1832
    .line 1833
    return-object v1

    .line 1834
    :catch_3
    move-exception v0

    .line 1835
    throw v0

    .line 1836
    :pswitch_b
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 1837
    .line 1838
    check-cast v1, Ljj1;

    .line 1839
    .line 1840
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1841
    .line 1842
    .line 1843
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 1844
    .line 1845
    check-cast v0, Landroid/content/Context;

    .line 1846
    .line 1847
    check-cast v10, Ljava/lang/String;

    .line 1848
    .line 1849
    :try_start_1f
    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 1850
    .line 1851
    .line 1852
    move-result-object v0

    .line 1853
    invoke-virtual {v0, v10}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    .line 1854
    .line 1855
    .line 1856
    move-result-object v0

    .line 1857
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_1f
    .catchall {:try_start_1f .. :try_end_1f} :catchall_12

    .line 1858
    .line 1859
    .line 1860
    goto :goto_17

    .line 1861
    :catchall_12
    move-exception v0

    .line 1862
    new-instance v9, Ltz5;

    .line 1863
    .line 1864
    invoke-direct {v9, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 1865
    .line 1866
    .line 1867
    :goto_17
    instance-of v0, v9, Ltz5;

    .line 1868
    .line 1869
    xor-int/2addr v0, v8

    .line 1870
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1871
    .line 1872
    .line 1873
    move-result-object v0

    .line 1874
    return-object v0

    .line 1875
    :pswitch_c
    check-cast v10, Ll94;

    .line 1876
    .line 1877
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 1878
    .line 1879
    check-cast v1, Ljava/util/List;

    .line 1880
    .line 1881
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1882
    .line 1883
    .line 1884
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 1885
    .line 1886
    check-cast v0, Lte4;

    .line 1887
    .line 1888
    invoke-interface {v0}, Lmz6;->getValue()Ljava/lang/Object;

    .line 1889
    .line 1890
    .line 1891
    move-result-object v0

    .line 1892
    check-cast v0, Ljava/lang/Boolean;

    .line 1893
    .line 1894
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1895
    .line 1896
    .line 1897
    move-result v0

    .line 1898
    if-eqz v0, :cond_3d

    .line 1899
    .line 1900
    if-eqz v1, :cond_3a

    .line 1901
    .line 1902
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 1903
    .line 1904
    .line 1905
    move-result v0

    .line 1906
    if-nez v0, :cond_3c

    .line 1907
    .line 1908
    :cond_3a
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1909
    .line 1910
    .line 1911
    move-result-object v0

    .line 1912
    :cond_3b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1913
    .line 1914
    .line 1915
    move-result v2

    .line 1916
    if-eqz v2, :cond_3c

    .line 1917
    .line 1918
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1919
    .line 1920
    .line 1921
    move-result-object v2

    .line 1922
    check-cast v2, Ll94;

    .line 1923
    .line 1924
    iget-object v2, v2, Ll94;->a:Lte4;

    .line 1925
    .line 1926
    iget-object v3, v10, Ll94;->a:Lte4;

    .line 1927
    .line 1928
    if-ne v2, v3, :cond_3b

    .line 1929
    .line 1930
    goto :goto_18

    .line 1931
    :cond_3c
    invoke-interface {v1, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1932
    .line 1933
    .line 1934
    :cond_3d
    :goto_18
    return-object v9

    .line 1935
    :pswitch_d
    check-cast v10, Lk94;

    .line 1936
    .line 1937
    iget-object v1, v0, Lav;->n:Ljava/lang/Object;

    .line 1938
    .line 1939
    check-cast v1, Ljava/util/List;

    .line 1940
    .line 1941
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1942
    .line 1943
    .line 1944
    iget-object v0, v0, Lav;->m:Ljava/lang/Object;

    .line 1945
    .line 1946
    check-cast v0, Lte4;

    .line 1947
    .line 1948
    invoke-interface {v0}, Lmz6;->getValue()Ljava/lang/Object;

    .line 1949
    .line 1950
    .line 1951
    move-result-object v0

    .line 1952
    check-cast v0, Ljava/lang/Boolean;

    .line 1953
    .line 1954
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1955
    .line 1956
    .line 1957
    move-result v0

    .line 1958
    if-eqz v0, :cond_41

    .line 1959
    .line 1960
    if-eqz v1, :cond_3e

    .line 1961
    .line 1962
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 1963
    .line 1964
    .line 1965
    move-result v0

    .line 1966
    if-nez v0, :cond_40

    .line 1967
    .line 1968
    :cond_3e
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1969
    .line 1970
    .line 1971
    move-result-object v0

    .line 1972
    :cond_3f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1973
    .line 1974
    .line 1975
    move-result v2

    .line 1976
    if-eqz v2, :cond_40

    .line 1977
    .line 1978
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1979
    .line 1980
    .line 1981
    move-result-object v2

    .line 1982
    check-cast v2, Lk94;

    .line 1983
    .line 1984
    iget-object v2, v2, Lk94;->a:Lte4;

    .line 1985
    .line 1986
    iget-object v3, v10, Lk94;->a:Lte4;

    .line 1987
    .line 1988
    if-ne v2, v3, :cond_3f

    .line 1989
    .line 1990
    goto :goto_19

    .line 1991
    :cond_40
    invoke-interface {v1, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1992
    .line 1993
    .line 1994
    :cond_41
    :goto_19
    return-object v9

    .line 1995
    :pswitch_e
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 1996
    .line 1997
    check-cast v1, Ljj1;

    .line 1998
    .line 1999
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 2000
    .line 2001
    .line 2002
    new-instance v2, Luw3;

    .line 2003
    .line 2004
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 2005
    .line 2006
    check-cast v0, Lxc5;

    .line 2007
    .line 2008
    check-cast v10, Lac7;

    .line 2009
    .line 2010
    invoke-direct {v2, v0, v10, v6, v7}, Luw3;-><init>(Lxc5;Lac7;Lxd1;B)V

    .line 2011
    .line 2012
    .line 2013
    invoke-static {v1, v6, v4, v2, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 2014
    .line 2015
    .line 2016
    new-instance v2, Luw3;

    .line 2017
    .line 2018
    invoke-direct {v2, v0, v10, v6, v8}, Luw3;-><init>(Lxc5;Lac7;Lxd1;B)V

    .line 2019
    .line 2020
    .line 2021
    invoke-static {v1, v6, v4, v2, v8}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 2022
    .line 2023
    .line 2024
    move-result-object v0

    .line 2025
    return-object v0

    .line 2026
    :pswitch_f
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 2027
    .line 2028
    .line 2029
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 2030
    .line 2031
    check-cast v1, Lte4;

    .line 2032
    .line 2033
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 2034
    .line 2035
    .line 2036
    move-result-object v1

    .line 2037
    check-cast v1, Lnh1;

    .line 2038
    .line 2039
    iget-object v1, v1, Lnh1;->c:Ljava/util/Map;

    .line 2040
    .line 2041
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 2042
    .line 2043
    check-cast v0, Lte4;

    .line 2044
    .line 2045
    invoke-interface {v0}, Lmz6;->getValue()Ljava/lang/Object;

    .line 2046
    .line 2047
    .line 2048
    move-result-object v0

    .line 2049
    check-cast v0, Lji1;

    .line 2050
    .line 2051
    iget-object v0, v0, Lji1;->a:Lii1;

    .line 2052
    .line 2053
    iget-object v0, v0, Lii1;->c:Ljava/lang/String;

    .line 2054
    .line 2055
    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2056
    .line 2057
    .line 2058
    move-result-object v0

    .line 2059
    check-cast v0, Lyh1;

    .line 2060
    .line 2061
    if-eqz v0, :cond_42

    .line 2062
    .line 2063
    check-cast v10, Lte4;

    .line 2064
    .line 2065
    invoke-interface {v10, v0}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 2066
    .line 2067
    .line 2068
    :cond_42
    return-object v9

    .line 2069
    :pswitch_10
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 2070
    .line 2071
    check-cast v1, Ljj1;

    .line 2072
    .line 2073
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 2074
    .line 2075
    .line 2076
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 2077
    .line 2078
    check-cast v0, Ljava/util/ArrayList;

    .line 2079
    .line 2080
    check-cast v10, Lgh1;

    .line 2081
    .line 2082
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2083
    .line 2084
    .line 2085
    move-result-object v0

    .line 2086
    :goto_1a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 2087
    .line 2088
    .line 2089
    move-result v3

    .line 2090
    if-eqz v3, :cond_43

    .line 2091
    .line 2092
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2093
    .line 2094
    .line 2095
    move-result-object v3

    .line 2096
    check-cast v3, Lii1;

    .line 2097
    .line 2098
    new-instance v4, Lo2;

    .line 2099
    .line 2100
    invoke-direct {v4, v10, v3, v6, v2}, Lo2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 2101
    .line 2102
    .line 2103
    const/4 v3, 0x3

    .line 2104
    invoke-static {v1, v6, v6, v4, v3}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 2105
    .line 2106
    .line 2107
    goto :goto_1a

    .line 2108
    :cond_43
    return-object v9

    .line 2109
    :pswitch_11
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 2110
    .line 2111
    .line 2112
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 2113
    .line 2114
    check-cast v1, Lte4;

    .line 2115
    .line 2116
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 2117
    .line 2118
    check-cast v0, Lim0;

    .line 2119
    .line 2120
    check-cast v10, Lwh2;

    .line 2121
    .line 2122
    invoke-static {v1, v0, v10}, Lwm0;->c(Lte4;Lim0;Lwh2;)V

    .line 2123
    .line 2124
    .line 2125
    return-object v9

    .line 2126
    :pswitch_12
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 2127
    .line 2128
    .line 2129
    iget-object v1, v0, Lav;->m:Ljava/lang/Object;

    .line 2130
    .line 2131
    check-cast v1, Landroid/content/Context;

    .line 2132
    .line 2133
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 2134
    .line 2135
    .line 2136
    move-result-object v1

    .line 2137
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2138
    .line 2139
    .line 2140
    iget-object v0, v0, Lav;->n:Ljava/lang/Object;

    .line 2141
    .line 2142
    check-cast v0, Ljava/util/ArrayList;

    .line 2143
    .line 2144
    check-cast v10, Ljava/lang/String;

    .line 2145
    .line 2146
    invoke-static {v10}, Lf17;->Z0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 2147
    .line 2148
    .line 2149
    move-result-object v2

    .line 2150
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 2151
    .line 2152
    .line 2153
    move-result-object v2

    .line 2154
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 2155
    .line 2156
    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2157
    .line 2158
    .line 2159
    move-result-object v2

    .line 2160
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2161
    .line 2162
    .line 2163
    const-string v3, "whitelist"

    .line 2164
    .line 2165
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 2166
    .line 2167
    .line 2168
    move-result v3

    .line 2169
    if-nez v3, :cond_44

    .line 2170
    .line 2171
    const-string v3, "white"

    .line 2172
    .line 2173
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 2174
    .line 2175
    .line 2176
    move-result v2

    .line 2177
    if-nez v2, :cond_44

    .line 2178
    .line 2179
    sget-object v2, Lgv;->h:Lgv;

    .line 2180
    .line 2181
    goto :goto_1b

    .line 2182
    :cond_44
    sget-object v2, Lgv;->i:Lgv;

    .line 2183
    .line 2184
    :goto_1b
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 2185
    .line 2186
    .line 2187
    move-result-object v1

    .line 2188
    new-instance v3, Lkx;

    .line 2189
    .line 2190
    invoke-direct {v3, v0, v8}, Lkx;-><init>(Ljava/lang/Object;B)V

    .line 2191
    .line 2192
    .line 2193
    new-instance v0, Ln2;

    .line 2194
    .line 2195
    const/4 v4, 0x7

    .line 2196
    invoke-direct {v0, v1, v2, v4}, Ln2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 2197
    .line 2198
    .line 2199
    invoke-static {v3, v0}, Lam6;->s0(Lwl6;Lwh2;)Lsa2;

    .line 2200
    .line 2201
    .line 2202
    move-result-object v0

    .line 2203
    invoke-static {v0}, Lam6;->v0(Lwl6;)Ljava/util/Set;

    .line 2204
    .line 2205
    .line 2206
    move-result-object v0

    .line 2207
    return-object v0

    .line 2208
    nop

    .line 2209
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    .line 2224
    .line 2225
    .line 2226
    .line 2227
    .line 2228
    .line 2229
    .line 2230
    .line 2231
    .line 2232
    .line 2233
    .line 2234
    .line 2235
    .line 2236
    .line 2237
    .line 2238
    .line 2239
    .line 2240
    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    .line 2246
    .line 2247
    .line 2248
    .line 2249
    .line 2250
    .line 2251
    :sswitch_data_0
    .sparse-switch
        0x1d3d8 -> :sswitch_3
        0x31ece8 -> :sswitch_2
        0x387aa7 -> :sswitch_1
        0x60bb07b -> :sswitch_0
    .end sparse-switch
.end method
