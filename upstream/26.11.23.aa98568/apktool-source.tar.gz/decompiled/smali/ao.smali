.class public final Lao;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic l:B

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Lxd1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lao;->l:B

    .line 2
    .line 3
    iput-object p1, p0, Lao;->m:Ljava/lang/Object;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, Lt57;-><init>(ILxd1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lao;->l:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    check-cast p1, Ljj1;

    .line 6
    .line 7
    check-cast p2, Lxd1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lao;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Lao;

    .line 27
    .line 28
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-object v1

    .line 32
    :pswitch_1
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    check-cast p0, Lao;

    .line 37
    .line 38
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0

    .line 43
    :pswitch_2
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    check-cast p0, Lao;

    .line 48
    .line 49
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    return-object p0

    .line 54
    :pswitch_3
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    check-cast p0, Lao;

    .line 59
    .line 60
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    return-object v1

    .line 64
    :pswitch_4
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    check-cast p0, Lao;

    .line 69
    .line 70
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    return-object p0

    .line 75
    :pswitch_5
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    check-cast p0, Lao;

    .line 80
    .line 81
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    return-object v1

    .line 85
    :pswitch_6
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    check-cast p0, Lao;

    .line 90
    .line 91
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    return-object v1

    .line 95
    :pswitch_7
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    check-cast p0, Lao;

    .line 100
    .line 101
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    return-object v1

    .line 105
    :pswitch_8
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 106
    .line 107
    .line 108
    move-result-object p0

    .line 109
    check-cast p0, Lao;

    .line 110
    .line 111
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    return-object p0

    .line 116
    :pswitch_9
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 117
    .line 118
    .line 119
    move-result-object p0

    .line 120
    check-cast p0, Lao;

    .line 121
    .line 122
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    return-object p0

    .line 127
    :pswitch_a
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 128
    .line 129
    .line 130
    move-result-object p0

    .line 131
    check-cast p0, Lao;

    .line 132
    .line 133
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    return-object v1

    .line 137
    :pswitch_b
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    check-cast p0, Lao;

    .line 142
    .line 143
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    return-object v1

    .line 147
    :pswitch_c
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    check-cast p0, Lao;

    .line 152
    .line 153
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    return-object v1

    .line 157
    :pswitch_d
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    check-cast p0, Lao;

    .line 162
    .line 163
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object p0

    .line 167
    return-object p0

    .line 168
    :pswitch_e
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 169
    .line 170
    .line 171
    move-result-object p0

    .line 172
    check-cast p0, Lao;

    .line 173
    .line 174
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object p0

    .line 178
    return-object p0

    .line 179
    :pswitch_f
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 180
    .line 181
    .line 182
    move-result-object p0

    .line 183
    check-cast p0, Lao;

    .line 184
    .line 185
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object p0

    .line 189
    return-object p0

    .line 190
    :pswitch_10
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 191
    .line 192
    .line 193
    move-result-object p0

    .line 194
    check-cast p0, Lao;

    .line 195
    .line 196
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    return-object v1

    .line 200
    :pswitch_11
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 201
    .line 202
    .line 203
    move-result-object p0

    .line 204
    check-cast p0, Lao;

    .line 205
    .line 206
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object p0

    .line 210
    return-object p0

    .line 211
    :pswitch_12
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 212
    .line 213
    .line 214
    move-result-object p0

    .line 215
    check-cast p0, Lao;

    .line 216
    .line 217
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    return-object v1

    .line 221
    :pswitch_13
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 222
    .line 223
    .line 224
    move-result-object p0

    .line 225
    check-cast p0, Lao;

    .line 226
    .line 227
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    return-object v1

    .line 231
    :pswitch_14
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 232
    .line 233
    .line 234
    move-result-object p0

    .line 235
    check-cast p0, Lao;

    .line 236
    .line 237
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    return-object v1

    .line 241
    :pswitch_15
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 242
    .line 243
    .line 244
    move-result-object p0

    .line 245
    check-cast p0, Lao;

    .line 246
    .line 247
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    return-object v1

    .line 251
    :pswitch_16
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 252
    .line 253
    .line 254
    move-result-object p0

    .line 255
    check-cast p0, Lao;

    .line 256
    .line 257
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object p0

    .line 261
    return-object p0

    .line 262
    :pswitch_17
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 263
    .line 264
    .line 265
    move-result-object p0

    .line 266
    check-cast p0, Lao;

    .line 267
    .line 268
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object p0

    .line 272
    return-object p0

    .line 273
    :pswitch_18
    invoke-virtual {p0, p2, p1}, Lao;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 274
    .line 275
    .line 276
    move-result-object p0

    .line 277
    check-cast p0, Lao;

    .line 278
    .line 279
    invoke-virtual {p0, v1}, Lao;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    return-object v1

    .line 283
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final s(Lxd1;Ljava/lang/Object;)Lxd1;
    .locals 1

    .line 1
    iget-byte p2, p0, Lao;->l:B

    .line 2
    .line 3
    iget-object p0, p0, Lao;->m:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch p2, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance p2, Lao;

    .line 9
    .line 10
    check-cast p0, Lry7;

    .line 11
    .line 12
    const/16 v0, 0x19

    .line 13
    .line 14
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 15
    .line 16
    .line 17
    return-object p2

    .line 18
    :pswitch_0
    new-instance p2, Lao;

    .line 19
    .line 20
    check-cast p0, Lhm7;

    .line 21
    .line 22
    const/16 v0, 0x18

    .line 23
    .line 24
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 25
    .line 26
    .line 27
    return-object p2

    .line 28
    :pswitch_1
    new-instance p2, Lao;

    .line 29
    .line 30
    check-cast p0, La57;

    .line 31
    .line 32
    const/16 v0, 0x17

    .line 33
    .line 34
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 35
    .line 36
    .line 37
    return-object p2

    .line 38
    :pswitch_2
    new-instance p2, Lao;

    .line 39
    .line 40
    check-cast p0, Lcy6;

    .line 41
    .line 42
    const/16 v0, 0x16

    .line 43
    .line 44
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 45
    .line 46
    .line 47
    return-object p2

    .line 48
    :pswitch_3
    new-instance p2, Lao;

    .line 49
    .line 50
    check-cast p0, Lzr6;

    .line 51
    .line 52
    const/16 v0, 0x15

    .line 53
    .line 54
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 55
    .line 56
    .line 57
    return-object p2

    .line 58
    :pswitch_4
    new-instance p2, Lao;

    .line 59
    .line 60
    check-cast p0, Lsp6;

    .line 61
    .line 62
    const/16 v0, 0x14

    .line 63
    .line 64
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 65
    .line 66
    .line 67
    return-object p2

    .line 68
    :pswitch_5
    new-instance p2, Lao;

    .line 69
    .line 70
    check-cast p0, Lxo6;

    .line 71
    .line 72
    const/16 v0, 0x13

    .line 73
    .line 74
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 75
    .line 76
    .line 77
    return-object p2

    .line 78
    :pswitch_6
    new-instance p2, Lao;

    .line 79
    .line 80
    check-cast p0, Lx96;

    .line 81
    .line 82
    const/16 v0, 0x12

    .line 83
    .line 84
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 85
    .line 86
    .line 87
    return-object p2

    .line 88
    :pswitch_7
    new-instance p2, Lao;

    .line 89
    .line 90
    check-cast p0, Lh96;

    .line 91
    .line 92
    const/16 v0, 0x11

    .line 93
    .line 94
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 95
    .line 96
    .line 97
    return-object p2

    .line 98
    :pswitch_8
    new-instance p2, Lao;

    .line 99
    .line 100
    check-cast p0, Lwh2;

    .line 101
    .line 102
    const/16 v0, 0x10

    .line 103
    .line 104
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 105
    .line 106
    .line 107
    return-object p2

    .line 108
    :pswitch_9
    new-instance p2, Lao;

    .line 109
    .line 110
    check-cast p0, Lxb5;

    .line 111
    .line 112
    const/16 v0, 0xf

    .line 113
    .line 114
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 115
    .line 116
    .line 117
    return-object p2

    .line 118
    :pswitch_a
    new-instance p2, Lao;

    .line 119
    .line 120
    check-cast p0, Lg05;

    .line 121
    .line 122
    const/16 v0, 0xe

    .line 123
    .line 124
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 125
    .line 126
    .line 127
    return-object p2

    .line 128
    :pswitch_b
    new-instance p2, Lao;

    .line 129
    .line 130
    check-cast p0, Lv52;

    .line 131
    .line 132
    const/16 v0, 0xd

    .line 133
    .line 134
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 135
    .line 136
    .line 137
    return-object p2

    .line 138
    :pswitch_c
    new-instance p2, Lao;

    .line 139
    .line 140
    check-cast p0, Llh2;

    .line 141
    .line 142
    const/16 v0, 0xc

    .line 143
    .line 144
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 145
    .line 146
    .line 147
    return-object p2

    .line 148
    :pswitch_d
    new-instance p2, Lao;

    .line 149
    .line 150
    check-cast p0, Ltl4;

    .line 151
    .line 152
    const/16 v0, 0xb

    .line 153
    .line 154
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 155
    .line 156
    .line 157
    return-object p2

    .line 158
    :pswitch_e
    new-instance p2, Lao;

    .line 159
    .line 160
    check-cast p0, Lrr1;

    .line 161
    .line 162
    const/16 v0, 0xa

    .line 163
    .line 164
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 165
    .line 166
    .line 167
    return-object p2

    .line 168
    :pswitch_f
    new-instance p2, Lao;

    .line 169
    .line 170
    check-cast p0, Lx71;

    .line 171
    .line 172
    const/16 v0, 0x9

    .line 173
    .line 174
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 175
    .line 176
    .line 177
    return-object p2

    .line 178
    :pswitch_10
    new-instance p2, Lao;

    .line 179
    .line 180
    check-cast p0, Ldv0;

    .line 181
    .line 182
    const/16 v0, 0x8

    .line 183
    .line 184
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 185
    .line 186
    .line 187
    return-object p2

    .line 188
    :pswitch_11
    new-instance p2, Lao;

    .line 189
    .line 190
    check-cast p0, Lui0;

    .line 191
    .line 192
    const/4 v0, 0x7

    .line 193
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 194
    .line 195
    .line 196
    return-object p2

    .line 197
    :pswitch_12
    new-instance p2, Lao;

    .line 198
    .line 199
    check-cast p0, Lrh0;

    .line 200
    .line 201
    const/4 v0, 0x6

    .line 202
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 203
    .line 204
    .line 205
    return-object p2

    .line 206
    :pswitch_13
    new-instance p2, Lao;

    .line 207
    .line 208
    check-cast p0, Lpm7;

    .line 209
    .line 210
    const/4 v0, 0x5

    .line 211
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 212
    .line 213
    .line 214
    return-object p2

    .line 215
    :pswitch_14
    new-instance p2, Lao;

    .line 216
    .line 217
    check-cast p0, Lkv;

    .line 218
    .line 219
    const/4 v0, 0x4

    .line 220
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 221
    .line 222
    .line 223
    return-object p2

    .line 224
    :pswitch_15
    new-instance p2, Lao;

    .line 225
    .line 226
    check-cast p0, Lev;

    .line 227
    .line 228
    const/4 v0, 0x3

    .line 229
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 230
    .line 231
    .line 232
    return-object p2

    .line 233
    :pswitch_16
    new-instance p2, Lao;

    .line 234
    .line 235
    check-cast p0, Ljava/util/Set;

    .line 236
    .line 237
    const/4 v0, 0x2

    .line 238
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 239
    .line 240
    .line 241
    return-object p2

    .line 242
    :pswitch_17
    new-instance p2, Lao;

    .line 243
    .line 244
    check-cast p0, Ljava/util/ArrayList;

    .line 245
    .line 246
    const/4 v0, 0x1

    .line 247
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 248
    .line 249
    .line 250
    return-object p2

    .line 251
    :pswitch_18
    new-instance p2, Lao;

    .line 252
    .line 253
    check-cast p0, Lcom/box/app/AppApplication;

    .line 254
    .line 255
    const/4 v0, 0x0

    .line 256
    invoke-direct {p2, p0, p1, v0}, Lao;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 257
    .line 258
    .line 259
    return-object p2

    .line 260
    nop

    .line 261
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-byte v0, v1, Lao;->l:B

    .line 4
    .line 5
    const/4 v3, 0x2

    .line 6
    const/4 v4, 0x1

    .line 7
    const/4 v5, 0x0

    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lry7;

    .line 17
    .line 18
    iget-object v1, v0, Lry7;->j:Lqy7;

    .line 19
    .line 20
    if-eqz v1, :cond_1

    .line 21
    .line 22
    iget-object v2, v1, Lqy7;->k:Lwo3;

    .line 23
    .line 24
    iget-object v3, v1, Lqy7;->l:Lyc3;

    .line 25
    .line 26
    invoke-interface {v3, v5}, Lyc3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 27
    .line 28
    .line 29
    iget-object v3, v1, Lqy7;->j:Ljj2;

    .line 30
    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    if-eqz v2, :cond_0

    .line 34
    .line 35
    invoke-virtual {v2, v3}, Lwo3;->f(Lso3;)V

    .line 36
    .line 37
    .line 38
    :cond_0
    if-eqz v2, :cond_1

    .line 39
    .line 40
    invoke-virtual {v2, v1}, Lwo3;->f(Lso3;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    iput-object v5, v0, Lry7;->j:Lqy7;

    .line 44
    .line 45
    sget-object v0, Lst7;->a:Lst7;

    .line 46
    .line 47
    return-object v0

    .line 48
    :pswitch_0
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v0, Lhm7;

    .line 54
    .line 55
    iget-object v1, v0, Lhm7;->c:Lxp6;

    .line 56
    .line 57
    const-string v2, "tools-update-settings"

    .line 58
    .line 59
    new-instance v3, Lpo;

    .line 60
    .line 61
    const/16 v4, 0xf

    .line 62
    .line 63
    invoke-direct {v3, v0, v5, v4}, Lpo;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v1, v3, v2}, Lxp6;->e(Lwh2;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    sget-object v0, Lst7;->a:Lst7;

    .line 70
    .line 71
    return-object v0

    .line 72
    :pswitch_1
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v0, La57;

    .line 78
    .line 79
    const-string v1, ""

    .line 80
    .line 81
    iget-object v3, v0, La57;->k:Ljava/util/List;

    .line 82
    .line 83
    new-instance v4, Lorg/json/JSONObject;

    .line 84
    .line 85
    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    .line 86
    .line 87
    .line 88
    const-string v6, "managed_provider_names"

    .line 89
    .line 90
    new-instance v7, Lorg/json/JSONArray;

    .line 91
    .line 92
    iget-object v8, v0, La57;->m:Ljava/util/List;

    .line 93
    .line 94
    invoke-direct {v7, v8}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v4, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    iget-object v6, v0, La57;->l:Ljava/util/List;

    .line 102
    .line 103
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 104
    .line 105
    .line 106
    move-result v7

    .line 107
    iget-object v8, v0, La57;->d:Ljava/util/List;

    .line 108
    .line 109
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 110
    .line 111
    .line 112
    move-result v9

    .line 113
    iget-object v10, v0, La57;->c:Ljava/util/List;

    .line 114
    .line 115
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 116
    .line 117
    .line 118
    move-result v11

    .line 119
    iget-object v12, v0, La57;->e:Ljava/util/List;

    .line 120
    .line 121
    invoke-interface {v12}, Ljava/util/List;->size()I

    .line 122
    .line 123
    .line 124
    move-result v13

    .line 125
    invoke-static {v11, v13}, Ljava/lang/Math;->max(II)I

    .line 126
    .line 127
    .line 128
    move-result v11

    .line 129
    invoke-static {v9, v11}, Ljava/lang/Math;->max(II)I

    .line 130
    .line 131
    .line 132
    move-result v9

    .line 133
    if-ne v7, v9, :cond_8

    .line 134
    .line 135
    const-string v7, "sources"

    .line 136
    .line 137
    new-instance v9, Lorg/json/JSONArray;

    .line 138
    .line 139
    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    .line 140
    .line 141
    .line 142
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 143
    .line 144
    .line 145
    move-result-object v11

    .line 146
    const/4 v13, 0x0

    .line 147
    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 148
    .line 149
    .line 150
    move-result v14

    .line 151
    if-eqz v14, :cond_7

    .line 152
    .line 153
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v14

    .line 157
    add-int/lit8 v15, v13, 0x1

    .line 158
    .line 159
    if-ltz v13, :cond_6

    .line 160
    .line 161
    check-cast v14, Ly47;

    .line 162
    .line 163
    move-object/from16 v16, v5

    .line 164
    .line 165
    new-instance v5, Lorg/json/JSONObject;

    .line 166
    .line 167
    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    .line 168
    .line 169
    .line 170
    const-string v2, "name"

    .line 171
    .line 172
    invoke-static {v13, v8}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v17

    .line 176
    check-cast v17, Ljava/lang/String;

    .line 177
    .line 178
    move-object/from16 p0, v1

    .line 179
    .line 180
    if-eqz v17, :cond_2

    .line 181
    .line 182
    move-object/from16 v1, v17

    .line 183
    .line 184
    :cond_2
    invoke-virtual {v5, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    const-string v2, "url"

    .line 189
    .line 190
    invoke-static {v13, v10}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v5

    .line 194
    check-cast v5, Ljava/lang/String;

    .line 195
    .line 196
    if-nez v5, :cond_3

    .line 197
    .line 198
    move-object/from16 v5, p0

    .line 199
    .line 200
    :cond_3
    invoke-virtual {v1, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    const-string v2, "proxy"

    .line 205
    .line 206
    invoke-static {v13, v12}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v5

    .line 210
    check-cast v5, Ljava/lang/String;

    .line 211
    .line 212
    if-nez v5, :cond_4

    .line 213
    .line 214
    move-object/from16 v5, p0

    .line 215
    .line 216
    :cond_4
    invoke-virtual {v1, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 217
    .line 218
    .line 219
    move-result-object v1

    .line 220
    const-string v2, "enabled"

    .line 221
    .line 222
    if-ltz v13, :cond_5

    .line 223
    .line 224
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 225
    .line 226
    .line 227
    move-result v5

    .line 228
    if-ge v13, v5, :cond_5

    .line 229
    .line 230
    invoke-interface {v3, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v5

    .line 234
    goto :goto_1

    .line 235
    :cond_5
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 236
    .line 237
    :goto_1
    check-cast v5, Ljava/lang/Boolean;

    .line 238
    .line 239
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 240
    .line 241
    .line 242
    move-result v5

    .line 243
    invoke-virtual {v1, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 244
    .line 245
    .line 246
    move-result-object v1

    .line 247
    const-string v2, "options"

    .line 248
    .line 249
    invoke-static {v14}, Lxy3;->j(Ly47;)Lorg/json/JSONObject;

    .line 250
    .line 251
    .line 252
    move-result-object v5

    .line 253
    invoke-virtual {v1, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    invoke-virtual {v9, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 258
    .line 259
    .line 260
    move-object/from16 v1, p0

    .line 261
    .line 262
    move v13, v15

    .line 263
    move-object/from16 v5, v16

    .line 264
    .line 265
    goto :goto_0

    .line 266
    :cond_6
    move-object/from16 v16, v5

    .line 267
    .line 268
    invoke-static {}, Lix;->x0()V

    .line 269
    .line 270
    .line 271
    throw v16

    .line 272
    :cond_7
    invoke-virtual {v4, v7, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 273
    .line 274
    .line 275
    :cond_8
    const-string v1, "pull_user_agent"

    .line 276
    .line 277
    iget-object v2, v0, La57;->a:Ljava/lang/String;

    .line 278
    .line 279
    invoke-virtual {v4, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 280
    .line 281
    .line 282
    move-result-object v1

    .line 283
    const-string v2, "mihomo_provide_path"

    .line 284
    .line 285
    iget-object v4, v0, La57;->b:Ljava/lang/String;

    .line 286
    .line 287
    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 288
    .line 289
    .line 290
    move-result-object v1

    .line 291
    const-string v2, "subscription_url_mihomo"

    .line 292
    .line 293
    new-instance v4, Lorg/json/JSONArray;

    .line 294
    .line 295
    invoke-direct {v4, v10}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 299
    .line 300
    .line 301
    move-result-object v1

    .line 302
    const-string v2, "name_provide_mihomo_config"

    .line 303
    .line 304
    new-instance v4, Lorg/json/JSONArray;

    .line 305
    .line 306
    invoke-direct {v4, v8}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    .line 307
    .line 308
    .line 309
    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 310
    .line 311
    .line 312
    move-result-object v1

    .line 313
    const-string v2, "proxy_provide_mihomo"

    .line 314
    .line 315
    new-instance v4, Lorg/json/JSONArray;

    .line 316
    .line 317
    invoke-direct {v4, v12}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 321
    .line 322
    .line 323
    move-result-object v1

    .line 324
    const-string v2, "enabled_provide_mihomo"

    .line 325
    .line 326
    new-instance v4, Lorg/json/JSONArray;

    .line 327
    .line 328
    invoke-direct {v4, v3}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    .line 329
    .line 330
    .line 331
    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 332
    .line 333
    .line 334
    move-result-object v1

    .line 335
    const-string v2, "mihomo_provider_interval"

    .line 336
    .line 337
    iget-object v3, v0, La57;->f:Ljava/lang/String;

    .line 338
    .line 339
    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 340
    .line 341
    .line 342
    move-result-object v1

    .line 343
    const-string v2, "mihomo_health_check_url"

    .line 344
    .line 345
    iget-object v3, v0, La57;->g:Ljava/lang/String;

    .line 346
    .line 347
    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 348
    .line 349
    .line 350
    move-result-object v1

    .line 351
    const-string v2, "mihomo_health_check_interval"

    .line 352
    .line 353
    iget-object v3, v0, La57;->h:Ljava/lang/String;

    .line 354
    .line 355
    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 356
    .line 357
    .line 358
    move-result-object v1

    .line 359
    const-string v2, "mihomo_health_check_timeout"

    .line 360
    .line 361
    iget-object v3, v0, La57;->i:Ljava/lang/String;

    .line 362
    .line 363
    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 364
    .line 365
    .line 366
    move-result-object v1

    .line 367
    const-string v2, "mihomo_health_check_tolerance"

    .line 368
    .line 369
    iget-object v0, v0, La57;->j:Ljava/lang/String;

    .line 370
    .line 371
    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    const-string v1, "mihomo_source_options"

    .line 376
    .line 377
    new-instance v2, Lorg/json/JSONArray;

    .line 378
    .line 379
    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    .line 380
    .line 381
    .line 382
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 383
    .line 384
    .line 385
    move-result-object v3

    .line 386
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 387
    .line 388
    .line 389
    move-result v4

    .line 390
    if-eqz v4, :cond_9

    .line 391
    .line 392
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    move-result-object v4

    .line 396
    check-cast v4, Ly47;

    .line 397
    .line 398
    invoke-static {v4}, Lxy3;->j(Ly47;)Lorg/json/JSONObject;

    .line 399
    .line 400
    .line 401
    move-result-object v4

    .line 402
    invoke-virtual {v2, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 403
    .line 404
    .line 405
    goto :goto_2

    .line 406
    :cond_9
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 407
    .line 408
    .line 409
    move-result-object v0

    .line 410
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 411
    .line 412
    .line 413
    sget-object v1, Lcom/box/app/AppApplication;->h:Landroid/content/Context;

    .line 414
    .line 415
    invoke-static {}, Lob3;->B()Landroid/content/Context;

    .line 416
    .line 417
    .line 418
    move-result-object v1

    .line 419
    const-string v2, "home_subscription_cache"

    .line 420
    .line 421
    const/4 v3, 0x0

    .line 422
    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 423
    .line 424
    .line 425
    move-result-object v1

    .line 426
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 427
    .line 428
    .line 429
    move-result-object v1

    .line 430
    const-string v2, "subscription_settings_json"

    .line 431
    .line 432
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 433
    .line 434
    .line 435
    move-result-object v0

    .line 436
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 437
    .line 438
    .line 439
    move-result-object v0

    .line 440
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 441
    .line 442
    .line 443
    new-instance v0, Lz47;

    .line 444
    .line 445
    sget-object v1, Lst7;->a:Lst7;

    .line 446
    .line 447
    invoke-direct {v0, v1}, Lz47;-><init>(Ljava/lang/Object;)V

    .line 448
    .line 449
    .line 450
    return-object v0

    .line 451
    :pswitch_2
    move-object/from16 v16, v5

    .line 452
    .line 453
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 454
    .line 455
    .line 456
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 457
    .line 458
    check-cast v0, Lcy6;

    .line 459
    .line 460
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 461
    .line 462
    .line 463
    move-result v0

    .line 464
    if-eqz v0, :cond_12

    .line 465
    .line 466
    if-eq v0, v4, :cond_11

    .line 467
    .line 468
    if-ne v0, v3, :cond_f

    .line 469
    .line 470
    const-string v0, "https://www.speedtest.net/api/js/servers?engine=js&limit=5"

    .line 471
    .line 472
    invoke-static {v0}, Lby6;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 473
    .line 474
    .line 475
    move-result-object v0

    .line 476
    if-eqz v0, :cond_10

    .line 477
    .line 478
    :try_start_0
    new-instance v1, Lorg/json/JSONArray;

    .line 479
    .line 480
    invoke-direct {v1, v0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 481
    .line 482
    .line 483
    const/4 v3, 0x0

    .line 484
    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    .line 485
    .line 486
    .line 487
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 488
    goto :goto_3

    .line 489
    :catch_0
    move-object/from16 v0, v16

    .line 490
    .line 491
    :goto_3
    if-eqz v0, :cond_10

    .line 492
    .line 493
    const-string v1, "url"

    .line 494
    .line 495
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 496
    .line 497
    .line 498
    move-result-object v1

    .line 499
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 500
    .line 501
    .line 502
    invoke-static {v1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 503
    .line 504
    .line 505
    move-result v2

    .line 506
    if-nez v2, :cond_a

    .line 507
    .line 508
    move-object v9, v1

    .line 509
    goto :goto_4

    .line 510
    :cond_a
    move-object/from16 v9, v16

    .line 511
    .line 512
    :goto_4
    if-eqz v9, :cond_10

    .line 513
    .line 514
    const-string v1, "sponsor"

    .line 515
    .line 516
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 517
    .line 518
    .line 519
    move-result-object v1

    .line 520
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 521
    .line 522
    .line 523
    invoke-static {v1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 524
    .line 525
    .line 526
    move-result v2

    .line 527
    if-eqz v2, :cond_b

    .line 528
    .line 529
    move-object/from16 v1, v16

    .line 530
    .line 531
    :cond_b
    const-string v2, "name"

    .line 532
    .line 533
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 534
    .line 535
    .line 536
    move-result-object v0

    .line 537
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 538
    .line 539
    .line 540
    invoke-static {v0}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 541
    .line 542
    .line 543
    move-result v2

    .line 544
    if-eqz v2, :cond_c

    .line 545
    .line 546
    move-object/from16 v0, v16

    .line 547
    .line 548
    :cond_c
    const-string v2, "random4000x4000.jpg"

    .line 549
    .line 550
    const/4 v3, 0x6

    .line 551
    const/16 v5, 0x2f

    .line 552
    .line 553
    const/4 v6, 0x0

    .line 554
    invoke-static {v9, v5, v6, v3}, Lf17;->D0(Ljava/lang/CharSequence;CII)I

    .line 555
    .line 556
    .line 557
    move-result v3

    .line 558
    const/4 v5, -0x1

    .line 559
    if-ne v3, v5, :cond_d

    .line 560
    .line 561
    move-object v7, v9

    .line 562
    goto :goto_5

    .line 563
    :cond_d
    add-int/2addr v3, v4

    .line 564
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 565
    .line 566
    .line 567
    move-result v4

    .line 568
    invoke-static {v9, v3, v4, v2}, Lf17;->M0(Ljava/lang/CharSequence;IILjava/lang/String;)Ljava/lang/StringBuilder;

    .line 569
    .line 570
    .line 571
    move-result-object v2

    .line 572
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 573
    .line 574
    .line 575
    move-result-object v2

    .line 576
    move-object v7, v2

    .line 577
    :goto_5
    sget-object v6, Lcy6;->l:Lcy6;

    .line 578
    .line 579
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 580
    .line 581
    .line 582
    move-result-object v0

    .line 583
    invoke-static {v0}, Lhx;->V0([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 584
    .line 585
    .line 586
    move-result-object v10

    .line 587
    const-string v11, " \u00b7 "

    .line 588
    .line 589
    const/4 v14, 0x0

    .line 590
    const/16 v15, 0x3e

    .line 591
    .line 592
    const/4 v12, 0x0

    .line 593
    const/4 v13, 0x0

    .line 594
    invoke-static/range {v10 .. v15}, Lay0;->Z0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Lwh2;I)Ljava/lang/String;

    .line 595
    .line 596
    .line 597
    move-result-object v0

    .line 598
    invoke-static {v0}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 599
    .line 600
    .line 601
    move-result v1

    .line 602
    if-eqz v1, :cond_e

    .line 603
    .line 604
    move-object/from16 v10, v16

    .line 605
    .line 606
    goto :goto_6

    .line 607
    :cond_e
    move-object v10, v0

    .line 608
    :goto_6
    new-instance v5, Lay6;

    .line 609
    .line 610
    move-object v8, v7

    .line 611
    invoke-direct/range {v5 .. v10}, Lay6;-><init>(Lcy6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 612
    .line 613
    .line 614
    goto/16 :goto_b

    .line 615
    .line 616
    :cond_f
    invoke-static {}, Lxb1;->a()V

    .line 617
    .line 618
    .line 619
    :catch_1
    :cond_10
    move-object/from16 v5, v16

    .line 620
    .line 621
    goto/16 :goto_b

    .line 622
    .line 623
    :cond_11
    new-instance v6, Lay6;

    .line 624
    .line 625
    sget-object v7, Lcy6;->k:Lcy6;

    .line 626
    .line 627
    const-string v8, "https://speed.cloudflare.com/__down?bytes=1000"

    .line 628
    .line 629
    const-string v9, "https://speed.cloudflare.com/__down?bytes=25000000"

    .line 630
    .line 631
    const-string v10, "https://speed.cloudflare.com/__up"

    .line 632
    .line 633
    const-string v11, "Cloudflare"

    .line 634
    .line 635
    invoke-direct/range {v6 .. v11}, Lay6;-><init>(Lcy6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 636
    .line 637
    .line 638
    move-object v5, v6

    .line 639
    goto/16 :goto_b

    .line 640
    .line 641
    :cond_12
    const-string v0, "https://mensura.cdn-apple.com/api/v1/gm/config"

    .line 642
    .line 643
    invoke-static {v0}, Lby6;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 644
    .line 645
    .line 646
    move-result-object v0

    .line 647
    if-eqz v0, :cond_10

    .line 648
    .line 649
    :try_start_1
    new-instance v1, Lorg/json/JSONObject;

    .line 650
    .line 651
    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 652
    .line 653
    .line 654
    const-string v0, "urls"

    .line 655
    .line 656
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 657
    .line 658
    .line 659
    move-result-object v0

    .line 660
    if-eqz v0, :cond_10

    .line 661
    .line 662
    const-string v2, "small_https_download_url"

    .line 663
    .line 664
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 665
    .line 666
    .line 667
    move-result-object v2

    .line 668
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 669
    .line 670
    .line 671
    invoke-static {v2}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 672
    .line 673
    .line 674
    move-result v3

    .line 675
    if-eqz v3, :cond_13

    .line 676
    .line 677
    move-object/from16 v2, v16

    .line 678
    .line 679
    :cond_13
    const-string v3, "large_https_download_url"

    .line 680
    .line 681
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 682
    .line 683
    .line 684
    move-result-object v3

    .line 685
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 686
    .line 687
    .line 688
    invoke-static {v3}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 689
    .line 690
    .line 691
    move-result v4

    .line 692
    if-nez v4, :cond_14

    .line 693
    .line 694
    move-object v8, v3

    .line 695
    goto :goto_7

    .line 696
    :cond_14
    move-object/from16 v8, v16

    .line 697
    .line 698
    :goto_7
    if-eqz v8, :cond_10

    .line 699
    .line 700
    const-string v3, "https_upload_url"

    .line 701
    .line 702
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 703
    .line 704
    .line 705
    move-result-object v0

    .line 706
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 707
    .line 708
    .line 709
    invoke-static {v0}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 710
    .line 711
    .line 712
    move-result v3

    .line 713
    if-nez v3, :cond_15

    .line 714
    .line 715
    move-object v9, v0

    .line 716
    goto :goto_8

    .line 717
    :cond_15
    move-object/from16 v9, v16

    .line 718
    .line 719
    :goto_8
    if-eqz v9, :cond_10

    .line 720
    .line 721
    const-string v0, "test_endpoint"

    .line 722
    .line 723
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 724
    .line 725
    .line 726
    move-result-object v0

    .line 727
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 728
    .line 729
    .line 730
    invoke-static {v0}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 731
    .line 732
    .line 733
    move-result v1

    .line 734
    if-nez v1, :cond_16

    .line 735
    .line 736
    move-object v10, v0

    .line 737
    goto :goto_9

    .line 738
    :cond_16
    move-object/from16 v10, v16

    .line 739
    .line 740
    :goto_9
    new-instance v5, Lay6;

    .line 741
    .line 742
    sget-object v6, Lcy6;->j:Lcy6;

    .line 743
    .line 744
    if-nez v2, :cond_17

    .line 745
    .line 746
    move-object v7, v8

    .line 747
    goto :goto_a

    .line 748
    :cond_17
    move-object v7, v2

    .line 749
    :goto_a
    invoke-direct/range {v5 .. v10}, Lay6;-><init>(Lcy6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 750
    .line 751
    .line 752
    :goto_b
    return-object v5

    .line 753
    :pswitch_3
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 754
    .line 755
    .line 756
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 757
    .line 758
    check-cast v0, Lzr6;

    .line 759
    .line 760
    invoke-virtual {v0}, Lzr6;->c()V

    .line 761
    .line 762
    .line 763
    sget-object v0, Lst7;->a:Lst7;

    .line 764
    .line 765
    return-object v0

    .line 766
    :pswitch_4
    move-object/from16 v16, v5

    .line 767
    .line 768
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 769
    .line 770
    .line 771
    invoke-static {}, Ltc0;->e()Lvp6;

    .line 772
    .line 773
    .line 774
    move-result-object v0

    .line 775
    new-instance v5, Lvp6;

    .line 776
    .line 777
    iget-boolean v6, v0, Lvp6;->a:Z

    .line 778
    .line 779
    iget-object v1, v1, Lao;->m:Ljava/lang/Object;

    .line 780
    .line 781
    check-cast v1, Lsp6;

    .line 782
    .line 783
    iget-object v2, v1, Lsp6;->a:Lqp6;

    .line 784
    .line 785
    iget-object v7, v2, Lqp6;->h:Ljava/lang/String;

    .line 786
    .line 787
    sget-object v2, Ltp6;->a:Lex5;

    .line 788
    .line 789
    iget-object v2, v1, Lsp6;->b:Ljava/util/List;

    .line 790
    .line 791
    new-instance v8, Lkx;

    .line 792
    .line 793
    invoke-direct {v8, v2, v4}, Lkx;-><init>(Ljava/lang/Object;B)V

    .line 794
    .line 795
    .line 796
    new-instance v2, Lpp6;

    .line 797
    .line 798
    const/4 v9, 0x0

    .line 799
    invoke-direct {v2, v9}, Lpp6;-><init>(B)V

    .line 800
    .line 801
    .line 802
    new-instance v9, Lts1;

    .line 803
    .line 804
    invoke-direct {v9, v8, v2, v3}, Lts1;-><init>(Lwl6;Lwh2;B)V

    .line 805
    .line 806
    .line 807
    new-instance v2, Lpp6;

    .line 808
    .line 809
    invoke-direct {v2, v4}, Lpp6;-><init>(B)V

    .line 810
    .line 811
    .line 812
    new-instance v8, Lsa2;

    .line 813
    .line 814
    invoke-direct {v8, v9, v4, v2}, Lsa2;-><init>(Lwl6;ZLwh2;)V

    .line 815
    .line 816
    .line 817
    invoke-static {v8}, Lam6;->m0(Lwl6;)Lts1;

    .line 818
    .line 819
    .line 820
    move-result-object v2

    .line 821
    invoke-static {v2}, Lam6;->t0(Lwl6;)Ljava/util/List;

    .line 822
    .line 823
    .line 824
    move-result-object v8

    .line 825
    iget-object v9, v0, Lvp6;->d:Ljava/util/List;

    .line 826
    .line 827
    iget-object v0, v1, Lsp6;->c:Ljava/util/List;

    .line 828
    .line 829
    new-instance v1, Lkx;

    .line 830
    .line 831
    invoke-direct {v1, v0, v4}, Lkx;-><init>(Ljava/lang/Object;B)V

    .line 832
    .line 833
    .line 834
    new-instance v0, Lje6;

    .line 835
    .line 836
    const/16 v2, 0x1c

    .line 837
    .line 838
    invoke-direct {v0, v2}, Lje6;-><init>(B)V

    .line 839
    .line 840
    .line 841
    new-instance v2, Lts1;

    .line 842
    .line 843
    invoke-direct {v2, v1, v0, v3}, Lts1;-><init>(Lwl6;Lwh2;B)V

    .line 844
    .line 845
    .line 846
    new-instance v0, Lje6;

    .line 847
    .line 848
    const/16 v1, 0x1d

    .line 849
    .line 850
    invoke-direct {v0, v1}, Lje6;-><init>(B)V

    .line 851
    .line 852
    .line 853
    new-instance v1, Lsa2;

    .line 854
    .line 855
    invoke-direct {v1, v2, v4, v0}, Lsa2;-><init>(Lwl6;ZLwh2;)V

    .line 856
    .line 857
    .line 858
    invoke-static {v1}, Lam6;->m0(Lwl6;)Lts1;

    .line 859
    .line 860
    .line 861
    move-result-object v0

    .line 862
    invoke-static {v0}, Lam6;->t0(Lwl6;)Ljava/util/List;

    .line 863
    .line 864
    .line 865
    move-result-object v10

    .line 866
    invoke-direct/range {v5 .. v10}, Lvp6;-><init>(ZLjava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 867
    .line 868
    .line 869
    sget-object v0, Lwc0;->a:Lwc0;

    .line 870
    .line 871
    new-instance v1, Lx2;

    .line 872
    .line 873
    const/16 v2, 0x19

    .line 874
    .line 875
    invoke-direct {v1, v5, v2}, Lx2;-><init>(Ljava/lang/Object;B)V

    .line 876
    .line 877
    .line 878
    invoke-virtual {v0, v1}, Lwc0;->p(Lwh2;)Ljava/lang/Object;

    .line 879
    .line 880
    .line 881
    new-instance v0, Lrp6;

    .line 882
    .line 883
    sget-object v1, Lst7;->a:Lst7;

    .line 884
    .line 885
    move-object/from16 v2, v16

    .line 886
    .line 887
    invoke-direct {v0, v3, v1, v2}, Lrp6;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    .line 888
    .line 889
    .line 890
    return-object v0

    .line 891
    :pswitch_5
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 892
    .line 893
    .line 894
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 895
    .line 896
    check-cast v0, Lxo6;

    .line 897
    .line 898
    iget-object v1, v0, Lxo6;->e:Lop6;

    .line 899
    .line 900
    iget-object v1, v1, Lop6;->a:Lte4;

    .line 901
    .line 902
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 903
    .line 904
    .line 905
    move-result-object v1

    .line 906
    check-cast v1, Ljava/lang/Boolean;

    .line 907
    .line 908
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 909
    .line 910
    .line 911
    move-result v1

    .line 912
    if-nez v1, :cond_18

    .line 913
    .line 914
    iget-object v1, v0, Lxo6;->f:Lxp6;

    .line 915
    .line 916
    const-string v2, "shared-network-config-load"

    .line 917
    .line 918
    new-instance v3, Lvo6;

    .line 919
    .line 920
    const/4 v5, 0x0

    .line 921
    invoke-direct {v3, v0, v5, v4}, Lvo6;-><init>(Lxo6;Lxd1;B)V

    .line 922
    .line 923
    .line 924
    invoke-virtual {v1, v3, v2}, Lxp6;->d(Lwh2;Ljava/lang/String;)V

    .line 925
    .line 926
    .line 927
    :cond_18
    sget-object v0, Lst7;->a:Lst7;

    .line 928
    .line 929
    return-object v0

    .line 930
    :pswitch_6
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 931
    .line 932
    .line 933
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 934
    .line 935
    check-cast v0, Lx96;

    .line 936
    .line 937
    iget-object v1, v0, Lx96;->l:Lz75;

    .line 938
    .line 939
    invoke-virtual {v1}, Lz75;->getValue()Ljava/lang/Object;

    .line 940
    .line 941
    .line 942
    move-result-object v1

    .line 943
    check-cast v1, Ljava/lang/Boolean;

    .line 944
    .line 945
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 946
    .line 947
    .line 948
    move-result v1

    .line 949
    if-nez v1, :cond_19

    .line 950
    .line 951
    iget-object v1, v0, Lx96;->l:Lz75;

    .line 952
    .line 953
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 954
    .line 955
    invoke-virtual {v1, v2}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 956
    .line 957
    .line 958
    invoke-virtual {v0}, Lx96;->e()Ljava/lang/String;

    .line 959
    .line 960
    .line 961
    move-result-object v1

    .line 962
    const/4 v3, 0x0

    .line 963
    invoke-virtual {v0, v1, v4, v3}, Lx96;->l(Ljava/lang/String;ZZ)V

    .line 964
    .line 965
    .line 966
    :cond_19
    sget-object v0, Lst7;->a:Lst7;

    .line 967
    .line 968
    return-object v0

    .line 969
    :pswitch_7
    const/4 v3, 0x0

    .line 970
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 971
    .line 972
    .line 973
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 974
    .line 975
    check-cast v0, Lh96;

    .line 976
    .line 977
    sget-object v1, Lh96;->z:Ld86;

    .line 978
    .line 979
    invoke-virtual {v0, v3}, Lh96;->i(Z)V

    .line 980
    .line 981
    .line 982
    sget-object v0, Lst7;->a:Lst7;

    .line 983
    .line 984
    return-object v0

    .line 985
    :pswitch_8
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 986
    .line 987
    .line 988
    sget-object v0, Lge0;->a:Lge0;

    .line 989
    .line 990
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 991
    .line 992
    check-cast v0, Lwh2;

    .line 993
    .line 994
    invoke-static {v0}, Lge0;->w(Lwh2;)Lvd0;

    .line 995
    .line 996
    .line 997
    move-result-object v0

    .line 998
    iget-object v1, v0, Lvd0;->a:Ljava/lang/Object;

    .line 999
    .line 1000
    if-eqz v1, :cond_1a

    .line 1001
    .line 1002
    new-instance v0, Lxq5;

    .line 1003
    .line 1004
    sget-object v1, Lst7;->a:Lst7;

    .line 1005
    .line 1006
    const/4 v2, 0x0

    .line 1007
    invoke-direct {v0, v3, v1, v2}, Lxq5;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    .line 1008
    .line 1009
    .line 1010
    goto :goto_c

    .line 1011
    :cond_1a
    const/4 v2, 0x0

    .line 1012
    new-instance v1, Lxq5;

    .line 1013
    .line 1014
    iget-object v0, v0, Lvd0;->b:Ljava/lang/String;

    .line 1015
    .line 1016
    invoke-direct {v1, v4, v2, v0}, Lxq5;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    .line 1017
    .line 1018
    .line 1019
    move-object v0, v1

    .line 1020
    :goto_c
    return-object v0

    .line 1021
    :pswitch_9
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1022
    .line 1023
    .line 1024
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1025
    .line 1026
    check-cast v0, Lxb5;

    .line 1027
    .line 1028
    iget-object v1, v0, Lxb5;->b:Landroid/content/Context;

    .line 1029
    .line 1030
    iget-object v2, v0, Lxb5;->c:Lfj6;

    .line 1031
    .line 1032
    const-class v3, Landroid/view/textclassifier/TextClassificationManager;

    .line 1033
    .line 1034
    invoke-virtual {v1, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 1035
    .line 1036
    .line 1037
    move-result-object v3

    .line 1038
    check-cast v3, Landroid/view/textclassifier/TextClassificationManager;

    .line 1039
    .line 1040
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 1041
    .line 1042
    .line 1043
    move-result v2

    .line 1044
    if-eqz v2, :cond_1c

    .line 1045
    .line 1046
    if-ne v2, v4, :cond_1b

    .line 1047
    .line 1048
    const-string v2, "textview"

    .line 1049
    .line 1050
    goto :goto_d

    .line 1051
    :cond_1b
    invoke-static {}, Lxb1;->a()V

    .line 1052
    .line 1053
    .line 1054
    const/4 v5, 0x0

    .line 1055
    goto :goto_e

    .line 1056
    :cond_1c
    const-string v2, "edittext"

    .line 1057
    .line 1058
    :goto_d
    new-instance v4, Landroid/view/textclassifier/TextClassificationContext$Builder;

    .line 1059
    .line 1060
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 1061
    .line 1062
    .line 1063
    move-result-object v1

    .line 1064
    invoke-direct {v4, v1, v2}, Landroid/view/textclassifier/TextClassificationContext$Builder;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 1065
    .line 1066
    .line 1067
    invoke-virtual {v4}, Landroid/view/textclassifier/TextClassificationContext$Builder;->build()Landroid/view/textclassifier/TextClassificationContext;

    .line 1068
    .line 1069
    .line 1070
    move-result-object v1

    .line 1071
    invoke-virtual {v3, v1}, Landroid/view/textclassifier/TextClassificationManager;->createTextClassificationSession(Landroid/view/textclassifier/TextClassificationContext;)Landroid/view/textclassifier/TextClassifier;

    .line 1072
    .line 1073
    .line 1074
    move-result-object v5

    .line 1075
    iput-object v5, v0, Lxb5;->f:Landroid/view/textclassifier/TextClassifier;

    .line 1076
    .line 1077
    :goto_e
    return-object v5

    .line 1078
    :pswitch_a
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1079
    .line 1080
    .line 1081
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1082
    .line 1083
    check-cast v0, Lg05;

    .line 1084
    .line 1085
    iget-object v1, v0, Lg05;->a:Lxp6;

    .line 1086
    .line 1087
    const-string v2, "other-proxy-config-load"

    .line 1088
    .line 1089
    new-instance v3, Lpo;

    .line 1090
    .line 1091
    const/4 v4, 0x7

    .line 1092
    const/4 v5, 0x0

    .line 1093
    invoke-direct {v3, v0, v5, v4}, Lpo;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 1094
    .line 1095
    .line 1096
    invoke-virtual {v1, v3, v2}, Lxp6;->e(Lwh2;Ljava/lang/String;)V

    .line 1097
    .line 1098
    .line 1099
    sget-object v0, Lst7;->a:Lst7;

    .line 1100
    .line 1101
    return-object v0

    .line 1102
    :pswitch_b
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1103
    .line 1104
    .line 1105
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1106
    .line 1107
    check-cast v0, Lv52;

    .line 1108
    .line 1109
    iget-object v0, v0, Lv52;->a:Ljn7;

    .line 1110
    .line 1111
    const/4 v1, 0x0

    .line 1112
    iget-object v0, v0, Ljn7;->c:Lv75;

    .line 1113
    .line 1114
    invoke-virtual {v0, v1}, Lv75;->i(F)V

    .line 1115
    .line 1116
    .line 1117
    sget-object v0, Lst7;->a:Lst7;

    .line 1118
    .line 1119
    return-object v0

    .line 1120
    :pswitch_c
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1121
    .line 1122
    .line 1123
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1124
    .line 1125
    check-cast v0, Llh2;

    .line 1126
    .line 1127
    invoke-interface {v0}, Llh2;->a()Ljava/lang/Object;

    .line 1128
    .line 1129
    .line 1130
    sget-object v0, Lst7;->a:Lst7;

    .line 1131
    .line 1132
    return-object v0

    .line 1133
    :pswitch_d
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1134
    .line 1135
    .line 1136
    sget-object v0, Lol4;->c:Ljava/lang/ThreadLocal;

    .line 1137
    .line 1138
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    .line 1139
    .line 1140
    .line 1141
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 1142
    .line 1143
    .line 1144
    move-result-wide v2

    .line 1145
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1146
    .line 1147
    move-object v4, v0

    .line 1148
    check-cast v4, Ltl4;

    .line 1149
    .line 1150
    :try_start_2
    invoke-static {v4}, Lol4;->x(Ltl4;)Lpg5;

    .line 1151
    .line 1152
    .line 1153
    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 1154
    goto :goto_f

    .line 1155
    :catchall_0
    move-exception v0

    .line 1156
    new-instance v5, Ltz5;

    .line 1157
    .line 1158
    invoke-direct {v5, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 1159
    .line 1160
    .line 1161
    move-object v0, v5

    .line 1162
    :goto_f
    invoke-static {v0}, Luz5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 1163
    .line 1164
    .line 1165
    move-result-object v5

    .line 1166
    if-eqz v5, :cond_1d

    .line 1167
    .line 1168
    new-instance v6, Lpg5;

    .line 1169
    .line 1170
    const/4 v12, 0x0

    .line 1171
    const/16 v13, 0x3f

    .line 1172
    .line 1173
    const/4 v7, 0x0

    .line 1174
    const/4 v8, 0x0

    .line 1175
    const/4 v9, 0x0

    .line 1176
    const/4 v10, 0x0

    .line 1177
    const/4 v11, 0x0

    .line 1178
    invoke-direct/range {v6 .. v13}, Lpg5;-><init>(Lsl4;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 1179
    .line 1180
    .line 1181
    move-object v0, v6

    .line 1182
    :cond_1d
    move-object v5, v0

    .line 1183
    check-cast v5, Lpg5;

    .line 1184
    .line 1185
    iget-object v6, v5, Lpg5;->b:Ljava/lang/Integer;

    .line 1186
    .line 1187
    iget-object v0, v5, Lpg5;->a:Lsl4;

    .line 1188
    .line 1189
    sget-object v7, Lsl4;->j:Lsl4;

    .line 1190
    .line 1191
    if-eq v0, v7, :cond_24

    .line 1192
    .line 1193
    sget-object v7, Lsl4;->k:Lsl4;

    .line 1194
    .line 1195
    if-eq v0, v7, :cond_24

    .line 1196
    .line 1197
    sget-object v7, Lsl4;->l:Lsl4;

    .line 1198
    .line 1199
    if-eq v0, v7, :cond_24

    .line 1200
    .line 1201
    if-nez v6, :cond_24

    .line 1202
    .line 1203
    :try_start_3
    invoke-static {v4}, Lol4;->w(Ltl4;)Lpg5;

    .line 1204
    .line 1205
    .line 1206
    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 1207
    goto :goto_10

    .line 1208
    :catchall_1
    move-exception v0

    .line 1209
    new-instance v4, Ltz5;

    .line 1210
    .line 1211
    invoke-direct {v4, v0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 1212
    .line 1213
    .line 1214
    move-object v0, v4

    .line 1215
    :goto_10
    instance-of v4, v0, Ltz5;

    .line 1216
    .line 1217
    if-eqz v4, :cond_1e

    .line 1218
    .line 1219
    const/16 v16, 0x0

    .line 1220
    .line 1221
    goto :goto_11

    .line 1222
    :cond_1e
    move-object/from16 v16, v0

    .line 1223
    .line 1224
    :goto_11
    move-object/from16 v0, v16

    .line 1225
    .line 1226
    check-cast v0, Lpg5;

    .line 1227
    .line 1228
    if-eqz v0, :cond_24

    .line 1229
    .line 1230
    iget-object v8, v0, Lpg5;->a:Lsl4;

    .line 1231
    .line 1232
    if-nez v6, :cond_1f

    .line 1233
    .line 1234
    iget-object v6, v0, Lpg5;->b:Ljava/lang/Integer;

    .line 1235
    .line 1236
    :cond_1f
    move-object v9, v6

    .line 1237
    iget-object v4, v5, Lpg5;->c:Ljava/lang/String;

    .line 1238
    .line 1239
    if-nez v4, :cond_20

    .line 1240
    .line 1241
    iget-object v4, v0, Lpg5;->c:Ljava/lang/String;

    .line 1242
    .line 1243
    :cond_20
    move-object v10, v4

    .line 1244
    iget-object v4, v5, Lpg5;->d:Ljava/lang/String;

    .line 1245
    .line 1246
    if-nez v4, :cond_21

    .line 1247
    .line 1248
    iget-object v4, v0, Lpg5;->d:Ljava/lang/String;

    .line 1249
    .line 1250
    :cond_21
    move-object v11, v4

    .line 1251
    iget-object v4, v5, Lpg5;->e:Ljava/lang/String;

    .line 1252
    .line 1253
    if-nez v4, :cond_22

    .line 1254
    .line 1255
    iget-object v4, v0, Lpg5;->e:Ljava/lang/String;

    .line 1256
    .line 1257
    :cond_22
    move-object v12, v4

    .line 1258
    iget-object v4, v5, Lpg5;->f:Ljava/lang/String;

    .line 1259
    .line 1260
    if-nez v4, :cond_23

    .line 1261
    .line 1262
    iget-object v4, v0, Lpg5;->f:Ljava/lang/String;

    .line 1263
    .line 1264
    :cond_23
    move-object v13, v4

    .line 1265
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1266
    .line 1267
    .line 1268
    new-instance v7, Lpg5;

    .line 1269
    .line 1270
    invoke-direct/range {v7 .. v13}, Lpg5;-><init>(Lsl4;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1271
    .line 1272
    .line 1273
    move-object v5, v7

    .line 1274
    :cond_24
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 1275
    .line 1276
    .line 1277
    move-result-wide v6

    .line 1278
    sub-long/2addr v6, v2

    .line 1279
    const-wide/32 v2, 0xf4240

    .line 1280
    .line 1281
    .line 1282
    div-long/2addr v6, v2

    .line 1283
    new-instance v8, Lql4;

    .line 1284
    .line 1285
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1286
    .line 1287
    move-object v9, v0

    .line 1288
    check-cast v9, Ltl4;

    .line 1289
    .line 1290
    iget-object v10, v5, Lpg5;->a:Lsl4;

    .line 1291
    .line 1292
    sget-object v0, Lol4;->c:Ljava/lang/ThreadLocal;

    .line 1293
    .line 1294
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 1295
    .line 1296
    .line 1297
    move-result-object v0

    .line 1298
    check-cast v0, Ljava/lang/Long;

    .line 1299
    .line 1300
    if-eqz v0, :cond_25

    .line 1301
    .line 1302
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 1303
    .line 1304
    .line 1305
    move-result-wide v6

    .line 1306
    :cond_25
    new-instance v11, Ljava/lang/Long;

    .line 1307
    .line 1308
    invoke-direct {v11, v6, v7}, Ljava/lang/Long;-><init>(J)V

    .line 1309
    .line 1310
    .line 1311
    iget-object v12, v5, Lpg5;->b:Ljava/lang/Integer;

    .line 1312
    .line 1313
    iget-object v13, v5, Lpg5;->c:Ljava/lang/String;

    .line 1314
    .line 1315
    invoke-direct/range {v8 .. v13}, Lql4;-><init>(Ltl4;Lsl4;Ljava/lang/Long;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 1316
    .line 1317
    .line 1318
    return-object v8

    .line 1319
    :pswitch_e
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1320
    .line 1321
    .line 1322
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1323
    .line 1324
    check-cast v0, Lrr1;

    .line 1325
    .line 1326
    iget-object v1, v0, Lrr1;->o:Ljava/lang/Object;

    .line 1327
    .line 1328
    monitor-enter v1

    .line 1329
    :try_start_4
    iget-boolean v2, v0, Lrr1;->t:Z

    .line 1330
    .line 1331
    if-eqz v2, :cond_28

    .line 1332
    .line 1333
    iget-boolean v2, v0, Lrr1;->u:Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 1334
    .line 1335
    if-nez v2, :cond_28

    .line 1336
    .line 1337
    :try_start_5
    invoke-virtual {v0}, Lrr1;->u()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 1338
    .line 1339
    .line 1340
    goto :goto_12

    .line 1341
    :catch_2
    :try_start_6
    iput-boolean v4, v0, Lrr1;->v:Z
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 1342
    .line 1343
    :goto_12
    :try_start_7
    iget v2, v0, Lrr1;->q:I

    .line 1344
    .line 1345
    const/16 v3, 0x7d0

    .line 1346
    .line 1347
    if-lt v2, v3, :cond_26

    .line 1348
    .line 1349
    move v2, v4

    .line 1350
    goto :goto_13

    .line 1351
    :cond_26
    const/4 v2, 0x0

    .line 1352
    :goto_13
    if-eqz v2, :cond_27

    .line 1353
    .line 1354
    invoke-virtual {v0}, Lrr1;->w()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_3
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 1355
    .line 1356
    .line 1357
    goto :goto_14

    .line 1358
    :catch_3
    :try_start_8
    iput-boolean v4, v0, Lrr1;->w:Z

    .line 1359
    .line 1360
    new-instance v2, Lp40;

    .line 1361
    .line 1362
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 1363
    .line 1364
    .line 1365
    new-instance v3, Lku5;

    .line 1366
    .line 1367
    invoke-direct {v3, v2}, Lku5;-><init>(Lmt6;)V

    .line 1368
    .line 1369
    .line 1370
    iput-object v3, v0, Lrr1;->r:Lku5;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 1371
    .line 1372
    :cond_27
    :goto_14
    monitor-exit v1

    .line 1373
    sget-object v0, Lst7;->a:Lst7;

    .line 1374
    .line 1375
    goto :goto_15

    .line 1376
    :cond_28
    :try_start_9
    sget-object v0, Lst7;->a:Lst7;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    .line 1377
    .line 1378
    monitor-exit v1

    .line 1379
    :goto_15
    return-object v0

    .line 1380
    :catchall_2
    move-exception v0

    .line 1381
    monitor-exit v1

    .line 1382
    throw v0

    .line 1383
    :pswitch_f
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1384
    .line 1385
    .line 1386
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1387
    .line 1388
    move-object v1, v0

    .line 1389
    check-cast v1, Lx71;

    .line 1390
    .line 1391
    iget-object v0, v1, Lx71;->c:Ljava/lang/String;

    .line 1392
    .line 1393
    invoke-static {v0}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 1394
    .line 1395
    .line 1396
    move-result v2

    .line 1397
    if-eqz v2, :cond_29

    .line 1398
    .line 1399
    const-string v0, "empty"

    .line 1400
    .line 1401
    :goto_16
    const/4 v3, 0x0

    .line 1402
    goto :goto_17

    .line 1403
    :cond_29
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 1404
    .line 1405
    .line 1406
    move-result v2

    .line 1407
    const/16 v3, 0x200

    .line 1408
    .line 1409
    if-le v2, v3, :cond_2a

    .line 1410
    .line 1411
    const-string v0, "length"

    .line 1412
    .line 1413
    goto :goto_16

    .line 1414
    :cond_2a
    iget-object v2, v1, Lx71;->e:Ljava/util/Set;

    .line 1415
    .line 1416
    invoke-interface {v2}, Ljava/util/Set;->isEmpty()Z

    .line 1417
    .line 1418
    .line 1419
    move-result v2

    .line 1420
    if-eqz v2, :cond_2b

    .line 1421
    .line 1422
    const-string v0, "fields"

    .line 1423
    .line 1424
    goto :goto_16

    .line 1425
    :cond_2b
    const/4 v3, 0x0

    .line 1426
    :try_start_a
    invoke-static {v3, v0, v0}, Lx95;->a(ILjava/lang/String;Ljava/lang/String;)Lx95;
    :try_end_a
    .catch Lz95; {:try_start_a .. :try_end_a} :catch_4

    .line 1427
    .line 1428
    .line 1429
    const/4 v0, 0x0

    .line 1430
    goto :goto_17

    .line 1431
    :catch_4
    move-exception v0

    .line 1432
    iget-object v0, v0, Lz95;->h:Ljava/lang/String;

    .line 1433
    .line 1434
    :goto_17
    new-instance v2, Lq91;

    .line 1435
    .line 1436
    const/4 v5, 0x0

    .line 1437
    invoke-direct {v2, v1, v0, v5, v3}, Lq91;-><init>(Lx71;Ljava/lang/String;Ljava/lang/Integer;I)V

    .line 1438
    .line 1439
    .line 1440
    return-object v2

    .line 1441
    :pswitch_10
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1442
    .line 1443
    .line 1444
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1445
    .line 1446
    check-cast v0, Ldv0;

    .line 1447
    .line 1448
    iget-object v1, v0, Ldv0;->d:Lzw0;

    .line 1449
    .line 1450
    iget-object v1, v1, Lzw0;->a:Lte4;

    .line 1451
    .line 1452
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 1453
    .line 1454
    .line 1455
    move-result-object v1

    .line 1456
    check-cast v1, Ljava/lang/Boolean;

    .line 1457
    .line 1458
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1459
    .line 1460
    .line 1461
    move-result v1

    .line 1462
    if-nez v1, :cond_2c

    .line 1463
    .line 1464
    iget-object v1, v0, Ldv0;->e:Lxp6;

    .line 1465
    .line 1466
    const-string v2, "cnip-settings-load"

    .line 1467
    .line 1468
    new-instance v3, Lzu0;

    .line 1469
    .line 1470
    const/4 v5, 0x0

    .line 1471
    invoke-direct {v3, v0, v5}, Lzu0;-><init>(Ldv0;Lxd1;)V

    .line 1472
    .line 1473
    .line 1474
    invoke-virtual {v1, v3, v2}, Lxp6;->d(Lwh2;Ljava/lang/String;)V

    .line 1475
    .line 1476
    .line 1477
    :cond_2c
    sget-object v0, Lst7;->a:Lst7;

    .line 1478
    .line 1479
    return-object v0

    .line 1480
    :pswitch_11
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1481
    .line 1482
    .line 1483
    sget-object v0, Ltc0;->a:Ljava/util/Set;

    .line 1484
    .line 1485
    new-instance v0, Lti0;

    .line 1486
    .line 1487
    iget-object v1, v1, Lao;->m:Ljava/lang/Object;

    .line 1488
    .line 1489
    check-cast v1, Lui0;

    .line 1490
    .line 1491
    iget-object v2, v1, Lui0;->a:Ljava/util/List;

    .line 1492
    .line 1493
    invoke-static {v2}, Lay0;->L0(Ljava/lang/Iterable;)Lkx;

    .line 1494
    .line 1495
    .line 1496
    move-result-object v2

    .line 1497
    new-instance v5, Lqc0;

    .line 1498
    .line 1499
    const/16 v6, 0x13

    .line 1500
    .line 1501
    invoke-direct {v5, v6}, Lqc0;-><init>(B)V

    .line 1502
    .line 1503
    .line 1504
    new-instance v7, Lts1;

    .line 1505
    .line 1506
    invoke-direct {v7, v2, v5, v3}, Lts1;-><init>(Lwl6;Lwh2;B)V

    .line 1507
    .line 1508
    .line 1509
    new-instance v2, Lqc0;

    .line 1510
    .line 1511
    const/16 v5, 0x14

    .line 1512
    .line 1513
    invoke-direct {v2, v5}, Lqc0;-><init>(B)V

    .line 1514
    .line 1515
    .line 1516
    new-instance v8, Lsa2;

    .line 1517
    .line 1518
    invoke-direct {v8, v7, v4, v2}, Lsa2;-><init>(Lwl6;ZLwh2;)V

    .line 1519
    .line 1520
    .line 1521
    invoke-static {v8}, Lam6;->m0(Lwl6;)Lts1;

    .line 1522
    .line 1523
    .line 1524
    move-result-object v2

    .line 1525
    invoke-static {v2}, Lam6;->t0(Lwl6;)Ljava/util/List;

    .line 1526
    .line 1527
    .line 1528
    move-result-object v2

    .line 1529
    iget-object v7, v1, Lui0;->b:Ljava/util/List;

    .line 1530
    .line 1531
    invoke-static {v7}, Lay0;->L0(Ljava/lang/Iterable;)Lkx;

    .line 1532
    .line 1533
    .line 1534
    move-result-object v7

    .line 1535
    new-instance v8, Lqc0;

    .line 1536
    .line 1537
    invoke-direct {v8, v6}, Lqc0;-><init>(B)V

    .line 1538
    .line 1539
    .line 1540
    new-instance v6, Lts1;

    .line 1541
    .line 1542
    invoke-direct {v6, v7, v8, v3}, Lts1;-><init>(Lwl6;Lwh2;B)V

    .line 1543
    .line 1544
    .line 1545
    new-instance v7, Lqc0;

    .line 1546
    .line 1547
    invoke-direct {v7, v5}, Lqc0;-><init>(B)V

    .line 1548
    .line 1549
    .line 1550
    new-instance v5, Lsa2;

    .line 1551
    .line 1552
    invoke-direct {v5, v6, v4, v7}, Lsa2;-><init>(Lwl6;ZLwh2;)V

    .line 1553
    .line 1554
    .line 1555
    invoke-static {v5}, Lam6;->m0(Lwl6;)Lts1;

    .line 1556
    .line 1557
    .line 1558
    move-result-object v5

    .line 1559
    invoke-static {v5}, Lam6;->t0(Lwl6;)Ljava/util/List;

    .line 1560
    .line 1561
    .line 1562
    move-result-object v5

    .line 1563
    iget-object v1, v1, Lui0;->c:Ljava/util/List;

    .line 1564
    .line 1565
    new-instance v6, Lkx;

    .line 1566
    .line 1567
    invoke-direct {v6, v1, v4}, Lkx;-><init>(Ljava/lang/Object;B)V

    .line 1568
    .line 1569
    .line 1570
    new-instance v1, Lqc0;

    .line 1571
    .line 1572
    const/16 v7, 0x15

    .line 1573
    .line 1574
    invoke-direct {v1, v7}, Lqc0;-><init>(B)V

    .line 1575
    .line 1576
    .line 1577
    new-instance v7, Lts1;

    .line 1578
    .line 1579
    invoke-direct {v7, v6, v1, v3}, Lts1;-><init>(Lwl6;Lwh2;B)V

    .line 1580
    .line 1581
    .line 1582
    new-instance v1, Lqc0;

    .line 1583
    .line 1584
    const/16 v6, 0x16

    .line 1585
    .line 1586
    invoke-direct {v1, v6}, Lqc0;-><init>(B)V

    .line 1587
    .line 1588
    .line 1589
    new-instance v6, Lsa2;

    .line 1590
    .line 1591
    invoke-direct {v6, v7, v4, v1}, Lsa2;-><init>(Lwl6;ZLwh2;)V

    .line 1592
    .line 1593
    .line 1594
    invoke-static {v6}, Lam6;->m0(Lwl6;)Lts1;

    .line 1595
    .line 1596
    .line 1597
    move-result-object v1

    .line 1598
    invoke-static {v1}, Lam6;->t0(Lwl6;)Ljava/util/List;

    .line 1599
    .line 1600
    .line 1601
    move-result-object v1

    .line 1602
    invoke-direct {v0, v2, v5, v1}, Lti0;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 1603
    .line 1604
    .line 1605
    sget-object v1, Lwc0;->a:Lwc0;

    .line 1606
    .line 1607
    new-instance v2, Lx2;

    .line 1608
    .line 1609
    const/16 v4, 0x18

    .line 1610
    .line 1611
    invoke-direct {v2, v0, v4}, Lx2;-><init>(Ljava/lang/Object;B)V

    .line 1612
    .line 1613
    .line 1614
    invoke-virtual {v1, v2}, Lwc0;->p(Lwh2;)Ljava/lang/Object;

    .line 1615
    .line 1616
    .line 1617
    new-instance v0, Lvi0;

    .line 1618
    .line 1619
    sget-object v1, Lst7;->a:Lst7;

    .line 1620
    .line 1621
    const/4 v5, 0x0

    .line 1622
    invoke-direct {v0, v3, v1, v5}, Lvi0;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    .line 1623
    .line 1624
    .line 1625
    return-object v0

    .line 1626
    :pswitch_12
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1627
    .line 1628
    .line 1629
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1630
    .line 1631
    check-cast v0, Lrh0;

    .line 1632
    .line 1633
    iget-object v1, v0, Lrh0;->d:Lsi0;

    .line 1634
    .line 1635
    iget-object v1, v1, Lsi0;->a:Lte4;

    .line 1636
    .line 1637
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 1638
    .line 1639
    .line 1640
    move-result-object v1

    .line 1641
    check-cast v1, Ljava/lang/Boolean;

    .line 1642
    .line 1643
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1644
    .line 1645
    .line 1646
    move-result v1

    .line 1647
    if-nez v1, :cond_2d

    .line 1648
    .line 1649
    iget-object v1, v0, Lrh0;->e:Lxp6;

    .line 1650
    .line 1651
    const-string v2, "bypass-rules-load"

    .line 1652
    .line 1653
    new-instance v3, Lph0;

    .line 1654
    .line 1655
    const/4 v5, 0x0

    .line 1656
    invoke-direct {v3, v0, v5, v4}, Lph0;-><init>(Lrh0;Lxd1;B)V

    .line 1657
    .line 1658
    .line 1659
    invoke-virtual {v1, v3, v2}, Lxp6;->d(Lwh2;Ljava/lang/String;)V

    .line 1660
    .line 1661
    .line 1662
    :cond_2d
    sget-object v0, Lst7;->a:Lst7;

    .line 1663
    .line 1664
    return-object v0

    .line 1665
    :pswitch_13
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1666
    .line 1667
    .line 1668
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1669
    .line 1670
    check-cast v0, Lpm7;

    .line 1671
    .line 1672
    invoke-virtual {v0}, Lpm7;->a()V

    .line 1673
    .line 1674
    .line 1675
    sget-object v0, Lst7;->a:Lst7;

    .line 1676
    .line 1677
    return-object v0

    .line 1678
    :pswitch_14
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1679
    .line 1680
    .line 1681
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1682
    .line 1683
    check-cast v0, Lkv;

    .line 1684
    .line 1685
    invoke-virtual {v0}, Lkv;->a()Ljava/util/List;

    .line 1686
    .line 1687
    .line 1688
    move-result-object v1

    .line 1689
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 1690
    .line 1691
    .line 1692
    move-result v1

    .line 1693
    const/4 v3, 0x0

    .line 1694
    invoke-virtual {v0, v3, v1, v3}, Lkv;->b(ZZZ)V

    .line 1695
    .line 1696
    .line 1697
    sget-object v0, Lst7;->a:Lst7;

    .line 1698
    .line 1699
    return-object v0

    .line 1700
    :pswitch_15
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1701
    .line 1702
    .line 1703
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1704
    .line 1705
    check-cast v0, Lev;

    .line 1706
    .line 1707
    invoke-virtual {v0}, Lev;->e()Z

    .line 1708
    .line 1709
    .line 1710
    move-result v1

    .line 1711
    iget-object v0, v0, Lev;->n:Lvs;

    .line 1712
    .line 1713
    if-eqz v1, :cond_2e

    .line 1714
    .line 1715
    invoke-virtual {v0}, Lvs;->b()V

    .line 1716
    .line 1717
    .line 1718
    goto :goto_18

    .line 1719
    :cond_2e
    iget v1, v0, Lvs;->e:I

    .line 1720
    .line 1721
    add-int/2addr v1, v4

    .line 1722
    iput v1, v0, Lvs;->e:I

    .line 1723
    .line 1724
    iget-object v1, v0, Lvs;->c:Lxp6;

    .line 1725
    .line 1726
    const-string v2, "gid-load"

    .line 1727
    .line 1728
    invoke-virtual {v1, v2}, Lxp6;->a(Ljava/lang/String;)V

    .line 1729
    .line 1730
    .line 1731
    sget-object v1, Lrj2;->h:Lrj2;

    .line 1732
    .line 1733
    invoke-virtual {v0, v1}, Lvs;->c(Lrj2;)V

    .line 1734
    .line 1735
    .line 1736
    iget-object v0, v0, Lvs;->h:Lz75;

    .line 1737
    .line 1738
    const/4 v5, 0x0

    .line 1739
    invoke-virtual {v0, v5}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 1740
    .line 1741
    .line 1742
    :goto_18
    sget-object v0, Lst7;->a:Lst7;

    .line 1743
    .line 1744
    return-object v0

    .line 1745
    :pswitch_16
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1746
    .line 1747
    .line 1748
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1749
    .line 1750
    check-cast v0, Ljava/util/Set;

    .line 1751
    .line 1752
    check-cast v0, Ljava/lang/Iterable;

    .line 1753
    .line 1754
    new-instance v1, Ljava/util/ArrayList;

    .line 1755
    .line 1756
    const/16 v2, 0xa

    .line 1757
    .line 1758
    invoke-static {v0, v2}, Lby0;->D0(Ljava/lang/Iterable;I)I

    .line 1759
    .line 1760
    .line 1761
    move-result v2

    .line 1762
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 1763
    .line 1764
    .line 1765
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1766
    .line 1767
    .line 1768
    move-result-object v0

    .line 1769
    :goto_19
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1770
    .line 1771
    .line 1772
    move-result v2

    .line 1773
    if-eqz v2, :cond_2f

    .line 1774
    .line 1775
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1776
    .line 1777
    .line 1778
    move-result-object v2

    .line 1779
    check-cast v2, Ljava/lang/String;

    .line 1780
    .line 1781
    invoke-static {v2, v1}, Lp92;->y(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 1782
    .line 1783
    .line 1784
    goto :goto_19

    .line 1785
    :cond_2f
    new-instance v0, Ljava/util/ArrayList;

    .line 1786
    .line 1787
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1788
    .line 1789
    .line 1790
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1791
    .line 1792
    .line 1793
    move-result-object v1

    .line 1794
    :cond_30
    :goto_1a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1795
    .line 1796
    .line 1797
    move-result v2

    .line 1798
    if-eqz v2, :cond_32

    .line 1799
    .line 1800
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1801
    .line 1802
    .line 1803
    move-result-object v2

    .line 1804
    move-object v5, v2

    .line 1805
    check-cast v5, Ljava/lang/String;

    .line 1806
    .line 1807
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 1808
    .line 1809
    .line 1810
    move-result v6

    .line 1811
    if-lez v6, :cond_30

    .line 1812
    .line 1813
    const/4 v6, 0x0

    .line 1814
    :goto_1b
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 1815
    .line 1816
    .line 1817
    move-result v7

    .line 1818
    if-ge v6, v7, :cond_31

    .line 1819
    .line 1820
    invoke-virtual {v5, v6}, Ljava/lang/String;->charAt(I)C

    .line 1821
    .line 1822
    .line 1823
    move-result v7

    .line 1824
    invoke-static {v7}, Ljava/lang/Character;->isDigit(C)Z

    .line 1825
    .line 1826
    .line 1827
    move-result v7

    .line 1828
    if-eqz v7, :cond_30

    .line 1829
    .line 1830
    add-int/lit8 v6, v6, 0x1

    .line 1831
    .line 1832
    goto :goto_1b

    .line 1833
    :cond_31
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1834
    .line 1835
    .line 1836
    goto :goto_1a

    .line 1837
    :cond_32
    invoke-static {v0}, Lay0;->v1(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 1838
    .line 1839
    .line 1840
    move-result-object v0

    .line 1841
    check-cast v0, Ljava/util/Collection;

    .line 1842
    .line 1843
    sget-object v1, Lwc0;->a:Lwc0;

    .line 1844
    .line 1845
    new-instance v2, Lu3;

    .line 1846
    .line 1847
    invoke-direct {v2, v0, v4}, Lu3;-><init>(Ljava/util/Collection;B)V

    .line 1848
    .line 1849
    .line 1850
    invoke-virtual {v1, v2}, Lwc0;->p(Lwh2;)Ljava/lang/Object;

    .line 1851
    .line 1852
    .line 1853
    new-instance v0, Lou;

    .line 1854
    .line 1855
    sget-object v1, Lst7;->a:Lst7;

    .line 1856
    .line 1857
    const/4 v5, 0x0

    .line 1858
    invoke-direct {v0, v3, v1, v5}, Lou;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    .line 1859
    .line 1860
    .line 1861
    return-object v0

    .line 1862
    :pswitch_17
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1863
    .line 1864
    .line 1865
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1866
    .line 1867
    check-cast v0, Ljava/util/ArrayList;

    .line 1868
    .line 1869
    sget-object v1, Lwc0;->a:Lwc0;

    .line 1870
    .line 1871
    new-instance v2, Ldc;

    .line 1872
    .line 1873
    const/4 v4, 0x4

    .line 1874
    invoke-direct {v2, v0, v4}, Ldc;-><init>(Ljava/util/ArrayList;B)V

    .line 1875
    .line 1876
    .line 1877
    invoke-virtual {v1, v2}, Lwc0;->p(Lwh2;)Ljava/lang/Object;

    .line 1878
    .line 1879
    .line 1880
    new-instance v0, Lou;

    .line 1881
    .line 1882
    sget-object v1, Lst7;->a:Lst7;

    .line 1883
    .line 1884
    const/4 v5, 0x0

    .line 1885
    invoke-direct {v0, v3, v1, v5}, Lou;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    .line 1886
    .line 1887
    .line 1888
    return-object v0

    .line 1889
    :pswitch_18
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 1890
    .line 1891
    .line 1892
    sget-object v2, Ly6;->A:Ly6;

    .line 1893
    .line 1894
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1895
    .line 1896
    check-cast v0, Lcom/box/app/AppApplication;

    .line 1897
    .line 1898
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 1899
    .line 1900
    .line 1901
    move-result-object v0

    .line 1902
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1903
    .line 1904
    .line 1905
    monitor-enter v2

    .line 1906
    :try_start_b
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 1907
    .line 1908
    .line 1909
    move-result-object v0

    .line 1910
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1911
    .line 1912
    .line 1913
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 1914
    .line 1915
    .line 1916
    move-result-object v3

    .line 1917
    const-string v4, "app_icon_preferences"

    .line 1918
    .line 1919
    const/4 v6, 0x0

    .line 1920
    invoke-virtual {v3, v4, v6}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 1921
    .line 1922
    .line 1923
    move-result-object v3

    .line 1924
    sget-object v4, Lns;->i:Ls38;

    .line 1925
    .line 1926
    const-string v5, "app_icon_variant"

    .line 1927
    .line 1928
    const-string v6, "default"

    .line 1929
    .line 1930
    invoke-interface {v3, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1931
    .line 1932
    .line 1933
    move-result-object v3

    .line 1934
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1935
    .line 1936
    .line 1937
    invoke-static {v3}, Ls38;->v(Ljava/lang/String;)Lns;

    .line 1938
    .line 1939
    .line 1940
    move-result-object v3

    .line 1941
    const/4 v6, 0x0

    .line 1942
    invoke-static {v0, v3, v6, v6}, Ly6;->j(Landroid/content/Context;Lns;ZZ)V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 1943
    .line 1944
    .line 1945
    monitor-exit v2

    .line 1946
    sget-object v3, Ly6;->L:Ly6;

    .line 1947
    .line 1948
    iget-object v0, v1, Lao;->m:Ljava/lang/Object;

    .line 1949
    .line 1950
    check-cast v0, Lcom/box/app/AppApplication;

    .line 1951
    .line 1952
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 1953
    .line 1954
    .line 1955
    move-result-object v0

    .line 1956
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1957
    .line 1958
    .line 1959
    monitor-enter v3

    .line 1960
    :try_start_c
    const-string v1, "boxapp_settings"

    .line 1961
    .line 1962
    const/4 v6, 0x0

    .line 1963
    invoke-virtual {v0, v1, v6}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 1964
    .line 1965
    .line 1966
    move-result-object v1

    .line 1967
    sget-object v2, Lyt4;->i:Lzk2;

    .line 1968
    .line 1969
    const-string v4, "tile_long_click_target"

    .line 1970
    .line 1971
    const/4 v5, 0x0

    .line 1972
    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1973
    .line 1974
    .line 1975
    move-result-object v1

    .line 1976
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1977
    .line 1978
    .line 1979
    invoke-static {v1}, Lzk2;->l(Ljava/lang/String;)Lyt4;

    .line 1980
    .line 1981
    .line 1982
    move-result-object v1

    .line 1983
    invoke-virtual {v3, v0, v1}, Ly6;->F(Landroid/content/Context;Lyt4;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    .line 1984
    .line 1985
    .line 1986
    monitor-exit v3

    .line 1987
    sget-object v0, Lst7;->a:Lst7;

    .line 1988
    .line 1989
    return-object v0

    .line 1990
    :goto_1c
    :try_start_d
    monitor-exit v3
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_3

    .line 1991
    throw v0

    .line 1992
    :catchall_3
    move-exception v0

    .line 1993
    goto :goto_1c

    .line 1994
    :goto_1d
    :try_start_e
    monitor-exit v2
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_4

    .line 1995
    throw v0

    .line 1996
    :catchall_4
    move-exception v0

    .line 1997
    goto :goto_1d

    .line 1998
    nop

    .line 1999
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
