.class public final Lb06;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lvq2;


# instance fields
.field public A:Lkp1;

.field public B:Lii3;

.field public C:Lg50;

.field public D:B

.field public E:Luk3;

.field public h:I

.field public i:F

.field public j:F

.field public k:F

.field public l:F

.field public m:F

.field public n:F

.field public o:J

.field public p:J

.field public q:F

.field public r:F

.field public s:F

.field public t:F

.field public u:J

.field public v:Lbo6;

.field public w:Z

.field public x:B

.field public y:J

.field public z:Lbi3;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/high16 v0, 0x3f800000    # 1.0f

    .line 5
    .line 6
    iput v0, p0, Lb06;->i:F

    .line 7
    .line 8
    iput v0, p0, Lb06;->j:F

    .line 9
    .line 10
    iput v0, p0, Lb06;->k:F

    .line 11
    .line 12
    const-wide/high16 v0, -0x100000000000000L

    .line 13
    .line 14
    iput-wide v0, p0, Lb06;->o:J

    .line 15
    .line 16
    iput-wide v0, p0, Lb06;->p:J

    .line 17
    .line 18
    const/high16 v0, 0x41000000    # 8.0f

    .line 19
    .line 20
    iput v0, p0, Lb06;->t:F

    .line 21
    .line 22
    const/high16 v0, 0x3f000000    # 0.5f

    .line 23
    .line 24
    invoke-static {v0, v0}, Ly67;->a(FF)J

    .line 25
    .line 26
    .line 27
    move-result-wide v0

    .line 28
    iput-wide v0, p0, Lb06;->u:J

    .line 29
    .line 30
    sget-object v0, Lt50;->Y:Lu13;

    .line 31
    .line 32
    iput-object v0, p0, Lb06;->v:Lbo6;

    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    iput-byte v0, p0, Lb06;->x:B

    .line 36
    .line 37
    const-wide v0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    iput-wide v0, p0, Lb06;->y:J

    .line 43
    .line 44
    sget-object v0, Lbi3;->e:Lbi3;

    .line 45
    .line 46
    iput-object v0, p0, Lb06;->z:Lbi3;

    .line 47
    .line 48
    invoke-static {}, Lqv;->j()Lnp1;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iput-object v0, p0, Lb06;->A:Lkp1;

    .line 53
    .line 54
    sget-object v0, Lii3;->h:Lii3;

    .line 55
    .line 56
    iput-object v0, p0, Lb06;->B:Lii3;

    .line 57
    .line 58
    const/4 v0, 0x3

    .line 59
    iput-byte v0, p0, Lb06;->D:B

    .line 60
    .line 61
    return-void
.end method


# virtual methods
.method public final A()F
    .locals 0

    .line 1
    iget-object p0, p0, Lb06;->A:Lkp1;

    .line 2
    .line 3
    invoke-interface {p0}, Lkp1;->A()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final D(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->n:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit8 v0, v0, 0x20

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->n:F

    .line 15
    .line 16
    return-void
.end method

.method public final J0(I)V
    .locals 2

    .line 1
    iget-byte v0, p0, Lb06;->x:B

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 7
    .line 8
    const v1, 0x8000

    .line 9
    .line 10
    .line 11
    or-int/2addr v0, v1

    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput-byte p1, p0, Lb06;->x:B

    .line 15
    .line 16
    return-void
.end method

.method public final P(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->s:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit16 v0, v0, 0x400

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->s:F

    .line 15
    .line 16
    return-void
.end method

.method public final R(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->m:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit8 v0, v0, 0x10

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->m:F

    .line 15
    .line 16
    return-void
.end method

.method public final T(J)V
    .locals 2

    .line 1
    iget-wide v0, p0, Lb06;->o:J

    .line 2
    .line 3
    invoke-static {v0, v1, p1, p2}, Lxr7;->a(JJ)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget v0, p0, Lb06;->h:I

    .line 10
    .line 11
    or-int/lit8 v0, v0, 0x40

    .line 12
    .line 13
    iput v0, p0, Lb06;->h:I

    .line 14
    .line 15
    iput-wide p1, p0, Lb06;->o:J

    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final U(Lvx5;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lb06;->C:Lg50;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget v0, p0, Lb06;->h:I

    .line 10
    .line 11
    const/high16 v1, 0x20000

    .line 12
    .line 13
    or-int/2addr v0, v1

    .line 14
    iput v0, p0, Lb06;->h:I

    .line 15
    .line 16
    check-cast p1, Lg50;

    .line 17
    .line 18
    iput-object p1, p0, Lb06;->C:Lg50;

    .line 19
    .line 20
    :cond_0
    return-void
.end method

.method public final U0(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->t:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit16 v0, v0, 0x800

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->t:F

    .line 15
    .line 16
    return-void
.end method

.method public final X()V
    .locals 0

    .line 1
    return-void
.end method

.method public final Y(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->i:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit8 v0, v0, 0x1

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->i:F

    .line 15
    .line 16
    return-void
.end method

.method public final Y0()F
    .locals 0

    .line 1
    iget p0, p0, Lb06;->j:F

    .line 2
    .line 3
    return p0
.end method

.method public final Z(I)V
    .locals 2

    .line 1
    iget-byte v0, p0, Lb06;->D:B

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 7
    .line 8
    const/high16 v1, 0x80000

    .line 9
    .line 10
    or-int/2addr v0, v1

    .line 11
    iput v0, p0, Lb06;->h:I

    .line 12
    .line 13
    iput-byte p1, p0, Lb06;->D:B

    .line 14
    .line 15
    return-void
.end method

.method public final a()F
    .locals 0

    .line 1
    iget-object p0, p0, Lb06;->A:Lkp1;

    .line 2
    .line 3
    invoke-interface {p0}, Lkp1;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final b()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lb06;->y:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final c()V
    .locals 4

    .line 1
    const/high16 v0, 0x3f800000    # 1.0f

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lb06;->Y(F)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lb06;->x0(F)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lb06;->y(F)V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p0, v0}, Lb06;->u0(F)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, v0}, Lb06;->R(F)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0, v0}, Lb06;->D(F)V

    .line 20
    .line 21
    .line 22
    const-wide/high16 v1, -0x100000000000000L

    .line 23
    .line 24
    invoke-virtual {p0, v1, v2}, Lb06;->T(J)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0, v1, v2}, Lb06;->v0(J)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0, v0}, Lb06;->c1(F)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0, v0}, Lb06;->o(F)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0, v0}, Lb06;->P(F)V

    .line 37
    .line 38
    .line 39
    const/high16 v0, 0x41000000    # 8.0f

    .line 40
    .line 41
    invoke-virtual {p0, v0}, Lb06;->U0(F)V

    .line 42
    .line 43
    .line 44
    const/high16 v0, 0x3f000000    # 0.5f

    .line 45
    .line 46
    invoke-static {v0, v0}, Ly67;->a(FF)J

    .line 47
    .line 48
    .line 49
    move-result-wide v0

    .line 50
    invoke-virtual {p0, v0, v1}, Lb06;->t0(J)V

    .line 51
    .line 52
    .line 53
    sget-object v0, Lt50;->Y:Lu13;

    .line 54
    .line 55
    invoke-virtual {p0, v0}, Lb06;->o0(Lbo6;)V

    .line 56
    .line 57
    .line 58
    const/4 v0, 0x0

    .line 59
    invoke-virtual {p0, v0}, Lb06;->j0(Z)V

    .line 60
    .line 61
    .line 62
    const/4 v1, 0x0

    .line 63
    invoke-virtual {p0, v1}, Lb06;->U(Lvx5;)V

    .line 64
    .line 65
    .line 66
    const/4 v2, 0x3

    .line 67
    invoke-virtual {p0, v2}, Lb06;->Z(I)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p0, v0}, Lb06;->J0(I)V

    .line 71
    .line 72
    .line 73
    sget-object v2, Lbi3;->e:Lbi3;

    .line 74
    .line 75
    invoke-virtual {p0, v2}, Lb06;->k1(Lbi3;)V

    .line 76
    .line 77
    .line 78
    const-wide v2, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    iput-wide v2, p0, Lb06;->y:J

    .line 84
    .line 85
    iput-object v1, p0, Lb06;->E:Luk3;

    .line 86
    .line 87
    iput v0, p0, Lb06;->h:I

    .line 88
    .line 89
    return-void
.end method

.method public final c1(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->q:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit16 v0, v0, 0x100

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->q:F

    .line 15
    .line 16
    return-void
.end method

.method public final j0(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lb06;->w:Z

    .line 2
    .line 3
    if-eq v0, p1, :cond_0

    .line 4
    .line 5
    iget v0, p0, Lb06;->h:I

    .line 6
    .line 7
    or-int/lit16 v0, v0, 0x4000

    .line 8
    .line 9
    iput v0, p0, Lb06;->h:I

    .line 10
    .line 11
    iput-boolean p1, p0, Lb06;->w:Z

    .line 12
    .line 13
    :cond_0
    return-void
.end method

.method public final k1(Lbi3;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lb06;->z:Lbi3;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget v0, p0, Lb06;->h:I

    .line 10
    .line 11
    const/high16 v1, 0x100000

    .line 12
    .line 13
    or-int/2addr v0, v1

    .line 14
    iput v0, p0, Lb06;->h:I

    .line 15
    .line 16
    iput-object p1, p0, Lb06;->z:Lbi3;

    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final o(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->r:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit16 v0, v0, 0x200

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->r:F

    .line 15
    .line 16
    return-void
.end method

.method public final o0(Lbo6;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lb06;->v:Lbo6;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget v0, p0, Lb06;->h:I

    .line 10
    .line 11
    or-int/lit16 v0, v0, 0x2000

    .line 12
    .line 13
    iput v0, p0, Lb06;->h:I

    .line 14
    .line 15
    iput-object p1, p0, Lb06;->v:Lbo6;

    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final t0(J)V
    .locals 2

    .line 1
    iget-wide v0, p0, Lb06;->u:J

    .line 2
    .line 3
    invoke-static {v0, v1, p1, p2}, Lfo7;->a(JJ)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget v0, p0, Lb06;->h:I

    .line 10
    .line 11
    or-int/lit16 v0, v0, 0x1000

    .line 12
    .line 13
    iput v0, p0, Lb06;->h:I

    .line 14
    .line 15
    iput-wide p1, p0, Lb06;->u:J

    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final u0(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->l:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit8 v0, v0, 0x8

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->l:F

    .line 15
    .line 16
    return-void
.end method

.method public final v0(J)V
    .locals 2

    .line 1
    iget-wide v0, p0, Lb06;->p:J

    .line 2
    .line 3
    invoke-static {v0, v1, p1, p2}, Lxr7;->a(JJ)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget v0, p0, Lb06;->h:I

    .line 10
    .line 11
    or-int/lit16 v0, v0, 0x80

    .line 12
    .line 13
    iput v0, p0, Lb06;->h:I

    .line 14
    .line 15
    iput-wide p1, p0, Lb06;->p:J

    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final x0(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->j:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit8 v0, v0, 0x2

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->j:F

    .line 15
    .line 16
    return-void
.end method

.method public final y(F)V
    .locals 1

    .line 1
    iget v0, p0, Lb06;->k:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget v0, p0, Lb06;->h:I

    .line 9
    .line 10
    or-int/lit8 v0, v0, 0x4

    .line 11
    .line 12
    iput v0, p0, Lb06;->h:I

    .line 13
    .line 14
    iput p1, p0, Lb06;->k:F

    .line 15
    .line 16
    return-void
.end method

.method public final z()F
    .locals 0

    .line 1
    iget p0, p0, Lb06;->i:F

    .line 2
    .line 3
    return p0
.end method
