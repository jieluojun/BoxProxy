.class public final synthetic Lak5;
.super Lli2;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic o:B

.field public final synthetic p:Lpi5;

.field public final synthetic q:Lar5;

.field public final synthetic r:Lte4;

.field public final synthetic s:Ljava/lang/String;

.field public final synthetic t:Landroid/content/Context;

.field public final synthetic u:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lpi5;Lar5;Lte4;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;B)V
    .locals 6

    .line 1
    iput-byte p7, p0, Lak5;->o:B

    .line 2
    .line 3
    packed-switch p7, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lak5;->p:Lpi5;

    .line 7
    .line 8
    iput-object p2, p0, Lak5;->q:Lar5;

    .line 9
    .line 10
    iput-object p3, p0, Lak5;->r:Lte4;

    .line 11
    .line 12
    iput-object p4, p0, Lak5;->s:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p5, p0, Lak5;->t:Landroid/content/Context;

    .line 15
    .line 16
    iput-object p6, p0, Lak5;->u:Ljava/lang/String;

    .line 17
    .line 18
    const-string p4, "ProxyConfigMaterialScreen$createConfigFile(Lcom/box/app/ui/screen/settings/ProxyConfigController;Lcom/box/app/data/backend/ProxySettingsRepository$RootProxyCore;Landroidx/compose/runtime/MutableState;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V"

    .line 19
    .line 20
    const/4 p5, 0x0

    .line 21
    const/4 p1, 0x1

    .line 22
    const-class p2, Lnb3;

    .line 23
    .line 24
    const-string p3, "createConfigFile"

    .line 25
    .line 26
    invoke-direct/range {p0 .. p5}, Lli2;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_0
    iput-object p1, p0, Lak5;->p:Lpi5;

    .line 31
    .line 32
    iput-object p2, p0, Lak5;->q:Lar5;

    .line 33
    .line 34
    iput-object p3, p0, Lak5;->r:Lte4;

    .line 35
    .line 36
    iput-object p4, p0, Lak5;->s:Ljava/lang/String;

    .line 37
    .line 38
    iput-object p5, p0, Lak5;->t:Landroid/content/Context;

    .line 39
    .line 40
    iput-object p6, p0, Lak5;->u:Ljava/lang/String;

    .line 41
    .line 42
    const-string v4, "ProxyConfigMiuixScreen$createConfigFile(Lcom/box/app/ui/screen/settings/ProxyConfigController;Lcom/box/app/data/backend/ProxySettingsRepository$RootProxyCore;Landroidx/compose/runtime/MutableState;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V"

    .line 43
    .line 44
    const/4 v5, 0x0

    .line 45
    const/4 v1, 0x1

    .line 46
    const-class v2, Lnb3;

    .line 47
    .line 48
    const-string v3, "createConfigFile"

    .line 49
    .line 50
    move-object v0, p0

    .line 51
    invoke-direct/range {v0 .. v5}, Lli2;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-byte v0, p0, Lak5;->o:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    const-string v2, "proxy-config-create"

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    move-object v5, p1

    .line 11
    check-cast v5, Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    new-instance v6, Lnj5;

    .line 17
    .line 18
    const/4 v11, 0x1

    .line 19
    iget-object v7, p0, Lak5;->r:Lte4;

    .line 20
    .line 21
    iget-object v8, p0, Lak5;->s:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v9, p0, Lak5;->t:Landroid/content/Context;

    .line 24
    .line 25
    iget-object v10, p0, Lak5;->u:Ljava/lang/String;

    .line 26
    .line 27
    invoke-direct/range {v6 .. v11}, Lnj5;-><init>(Lte4;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;B)V

    .line 28
    .line 29
    .line 30
    iget-object v4, p0, Lak5;->q:Lar5;

    .line 31
    .line 32
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    move-object v7, v6

    .line 36
    iget-object v6, p0, Lak5;->p:Lpi5;

    .line 37
    .line 38
    iget-object p0, v6, Lpi5;->a:Lxp6;

    .line 39
    .line 40
    new-instance v3, Le44;

    .line 41
    .line 42
    const/4 v8, 0x0

    .line 43
    const/4 v9, 0x3

    .line 44
    invoke-direct/range {v3 .. v9}, Le44;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0, v3, v2}, Lxp6;->d(Lwh2;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-object v1

    .line 51
    :pswitch_0
    move-object v6, p1

    .line 52
    check-cast v6, Ljava/lang/String;

    .line 53
    .line 54
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    new-instance v7, Lnj5;

    .line 58
    .line 59
    const/4 v12, 0x0

    .line 60
    iget-object v8, p0, Lak5;->r:Lte4;

    .line 61
    .line 62
    iget-object v9, p0, Lak5;->s:Ljava/lang/String;

    .line 63
    .line 64
    iget-object v10, p0, Lak5;->t:Landroid/content/Context;

    .line 65
    .line 66
    iget-object v11, p0, Lak5;->u:Ljava/lang/String;

    .line 67
    .line 68
    invoke-direct/range {v7 .. v12}, Lnj5;-><init>(Lte4;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;B)V

    .line 69
    .line 70
    .line 71
    iget-object p1, p0, Lak5;->p:Lpi5;

    .line 72
    .line 73
    iget-object v0, p1, Lpi5;->a:Lxp6;

    .line 74
    .line 75
    new-instance v4, Le44;

    .line 76
    .line 77
    const/4 v9, 0x0

    .line 78
    const/4 v10, 0x3

    .line 79
    iget-object v5, p0, Lak5;->q:Lar5;

    .line 80
    .line 81
    move-object v8, v7

    .line 82
    move-object v7, p1

    .line 83
    invoke-direct/range {v4 .. v10}, Le44;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v0, v4, v2}, Lxp6;->d(Lwh2;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    return-object v1

    .line 90
    nop

    .line 91
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method
