.class public final Laj6;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:J

.field public final b:J

.field public final c:J

.field public final d:J

.field public final e:J

.field public final f:J

.field public final g:J

.field public final h:J

.field public final i:J

.field public final j:J

.field public final k:J

.field public final l:J


# direct methods
.method public constructor <init>(JJJJJJJJJJJJ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Laj6;->a:J

    .line 5
    .line 6
    iput-wide p3, p0, Laj6;->b:J

    .line 7
    .line 8
    iput-wide p5, p0, Laj6;->c:J

    .line 9
    .line 10
    iput-wide p7, p0, Laj6;->d:J

    .line 11
    .line 12
    iput-wide p9, p0, Laj6;->e:J

    .line 13
    .line 14
    iput-wide p11, p0, Laj6;->f:J

    .line 15
    .line 16
    iput-wide p13, p0, Laj6;->g:J

    .line 17
    .line 18
    move-wide p1, p15

    .line 19
    iput-wide p1, p0, Laj6;->h:J

    .line 20
    .line 21
    move-wide/from16 p1, p17

    .line 22
    .line 23
    iput-wide p1, p0, Laj6;->i:J

    .line 24
    .line 25
    move-wide/from16 p1, p19

    .line 26
    .line 27
    iput-wide p1, p0, Laj6;->j:J

    .line 28
    .line 29
    move-wide/from16 p1, p21

    .line 30
    .line 31
    iput-wide p1, p0, Laj6;->k:J

    .line 32
    .line 33
    move-wide/from16 p1, p23

    .line 34
    .line 35
    iput-wide p1, p0, Laj6;->l:J

    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    if-eq p0, p1, :cond_0

    .line 2
    .line 3
    if-eqz p1, :cond_1

    .line 4
    .line 5
    instance-of v0, p1, Laj6;

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    check-cast p1, Laj6;

    .line 10
    .line 11
    iget-wide v0, p1, Laj6;->a:J

    .line 12
    .line 13
    iget-wide v2, p0, Laj6;->a:J

    .line 14
    .line 15
    invoke-static {v2, v3, v0, v1}, Lxr7;->a(JJ)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    iget-wide v0, p0, Laj6;->b:J

    .line 22
    .line 23
    iget-wide v2, p1, Laj6;->b:J

    .line 24
    .line 25
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    iget-wide v0, p0, Laj6;->c:J

    .line 32
    .line 33
    iget-wide v2, p1, Laj6;->c:J

    .line 34
    .line 35
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    iget-wide v0, p0, Laj6;->d:J

    .line 42
    .line 43
    iget-wide v2, p1, Laj6;->d:J

    .line 44
    .line 45
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_1

    .line 50
    .line 51
    iget-wide v0, p0, Laj6;->e:J

    .line 52
    .line 53
    iget-wide v2, p1, Laj6;->e:J

    .line 54
    .line 55
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_1

    .line 60
    .line 61
    iget-wide v0, p0, Laj6;->f:J

    .line 62
    .line 63
    iget-wide v2, p1, Laj6;->f:J

    .line 64
    .line 65
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_1

    .line 70
    .line 71
    iget-wide v0, p0, Laj6;->g:J

    .line 72
    .line 73
    iget-wide v2, p1, Laj6;->g:J

    .line 74
    .line 75
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_1

    .line 80
    .line 81
    iget-wide v0, p0, Laj6;->h:J

    .line 82
    .line 83
    iget-wide v2, p1, Laj6;->h:J

    .line 84
    .line 85
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_1

    .line 90
    .line 91
    iget-wide v0, p0, Laj6;->i:J

    .line 92
    .line 93
    iget-wide v2, p1, Laj6;->i:J

    .line 94
    .line 95
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_1

    .line 100
    .line 101
    iget-wide v0, p0, Laj6;->j:J

    .line 102
    .line 103
    iget-wide v2, p1, Laj6;->j:J

    .line 104
    .line 105
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_1

    .line 110
    .line 111
    iget-wide v0, p0, Laj6;->k:J

    .line 112
    .line 113
    iget-wide v2, p1, Laj6;->k:J

    .line 114
    .line 115
    invoke-static {v0, v1, v2, v3}, Lxr7;->a(JJ)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_1

    .line 120
    .line 121
    iget-wide v0, p0, Laj6;->l:J

    .line 122
    .line 123
    iget-wide p0, p1, Laj6;->l:J

    .line 124
    .line 125
    invoke-static {v0, v1, p0, p1}, Lxr7;->a(JJ)Z

    .line 126
    .line 127
    .line 128
    move-result p0

    .line 129
    if-eqz p0, :cond_1

    .line 130
    .line 131
    :cond_0
    const/4 p0, 0x1

    .line 132
    return p0

    .line 133
    :cond_1
    const/4 p0, 0x0

    .line 134
    return p0
.end method

.method public final hashCode()I
    .locals 4

    .line 1
    iget-wide v0, p0, Laj6;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-wide v2, p0, Laj6;->b:J

    .line 11
    .line 12
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-wide v2, p0, Laj6;->c:J

    .line 17
    .line 18
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-wide v2, p0, Laj6;->d:J

    .line 23
    .line 24
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-wide v2, p0, Laj6;->e:J

    .line 29
    .line 30
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget-wide v2, p0, Laj6;->f:J

    .line 35
    .line 36
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    iget-wide v2, p0, Laj6;->g:J

    .line 41
    .line 42
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    iget-wide v2, p0, Laj6;->h:J

    .line 47
    .line 48
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    iget-wide v2, p0, Laj6;->i:J

    .line 53
    .line 54
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    iget-wide v2, p0, Laj6;->j:J

    .line 59
    .line 60
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    iget-wide v2, p0, Laj6;->k:J

    .line 65
    .line 66
    invoke-static {v2, v3, v0, v1}, Ldw4;->f(JII)I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    iget-wide v1, p0, Laj6;->l:J

    .line 71
    .line 72
    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    .line 73
    .line 74
    .line 75
    move-result p0

    .line 76
    add-int/2addr p0, v0

    .line 77
    return p0
.end method
