.class public final Lag5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbg5;


# instance fields
.field public final a:Lzf5;


# direct methods
.method public constructor <init>(Lzf5;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lag5;->a:Lzf5;

    .line 5
    .line 6
    return-void
.end method
