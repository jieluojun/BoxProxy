.class public final synthetic Lao4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lyn4;


# direct methods
.method public synthetic constructor <init>(Lyn4;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lao4;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lao4;->i:Lyn4;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    iget-byte v0, p0, Lao4;->h:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    sget-object v2, Lc51;->a:Lql0;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    iget-object p0, p0, Lao4;->i:Lyn4;

    .line 9
    .line 10
    const/4 v4, 0x1

    .line 11
    const/4 v5, 0x0

    .line 12
    packed-switch v0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    move-object v11, p1

    .line 16
    check-cast v11, Lzi2;

    .line 17
    .line 18
    move-object/from16 v0, p2

    .line 19
    .line 20
    check-cast v0, Ljava/lang/Integer;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    and-int/lit8 v6, v0, 0x3

    .line 27
    .line 28
    if-eq v6, v3, :cond_0

    .line 29
    .line 30
    move v3, v4

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    move v3, v5

    .line 33
    :goto_0
    and-int/2addr v0, v4

    .line 34
    invoke-virtual {v11, v0, v3}, Lzi2;->Y(IZ)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_3

    .line 39
    .line 40
    const v0, 0x7f0f052b

    .line 41
    .line 42
    .line 43
    invoke-static {v0, v11}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    iget-object v0, p0, Lyn4;->e:Lte4;

    .line 48
    .line 49
    invoke-interface {v0}, Lmz6;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    check-cast v0, Ljava/lang/Boolean;

    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 56
    .line 57
    .line 58
    move-result v8

    .line 59
    invoke-virtual {v11, p0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    invoke-virtual {v11}, Lzi2;->T()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    if-nez v0, :cond_1

    .line 68
    .line 69
    if-ne v3, v2, :cond_2

    .line 70
    .line 71
    :cond_1
    new-instance v3, Ldo4;

    .line 72
    .line 73
    invoke-direct {v3, p0, v5}, Ldo4;-><init>(Lyn4;B)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v11, v3}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :cond_2
    move-object v10, v3

    .line 80
    check-cast v10, Lwh2;

    .line 81
    .line 82
    const/4 v12, 0x0

    .line 83
    const/16 v13, 0x2e

    .line 84
    .line 85
    const/4 v7, 0x0

    .line 86
    const/4 v9, 0x0

    .line 87
    invoke-static/range {v6 .. v13}, Lb14;->h(Ljava/lang/String;Lj53;ZZLwh2;Lzi2;II)V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_3
    invoke-virtual {v11}, Lzi2;->b0()V

    .line 92
    .line 93
    .line 94
    :goto_1
    return-object v1

    .line 95
    :pswitch_0
    move-object v7, p1

    .line 96
    check-cast v7, Lzi2;

    .line 97
    .line 98
    move-object/from16 v0, p2

    .line 99
    .line 100
    check-cast v0, Ljava/lang/Integer;

    .line 101
    .line 102
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    and-int/lit8 v6, v0, 0x3

    .line 107
    .line 108
    if-eq v6, v3, :cond_4

    .line 109
    .line 110
    move v5, v4

    .line 111
    :cond_4
    and-int/2addr v0, v4

    .line 112
    invoke-virtual {v7, v0, v5}, Lzi2;->Y(IZ)Z

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    if-eqz v0, :cond_7

    .line 117
    .line 118
    const v0, 0x7f0f02a3

    .line 119
    .line 120
    .line 121
    invoke-static {v0, v7}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    iget-object v3, p0, Lyn4;->a:Lte4;

    .line 126
    .line 127
    invoke-interface {v3}, Lmz6;->getValue()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    check-cast v3, Ljava/lang/Boolean;

    .line 132
    .line 133
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 134
    .line 135
    .line 136
    move-result v3

    .line 137
    invoke-virtual {v7, p0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v5

    .line 141
    invoke-virtual {v7}, Lzi2;->T()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v6

    .line 145
    if-nez v5, :cond_5

    .line 146
    .line 147
    if-ne v6, v2, :cond_6

    .line 148
    .line 149
    :cond_5
    new-instance v6, Ldo4;

    .line 150
    .line 151
    invoke-direct {v6, p0, v4}, Ldo4;-><init>(Lyn4;B)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v7, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    :cond_6
    check-cast v6, Lwh2;

    .line 158
    .line 159
    const/4 v8, 0x0

    .line 160
    const/16 v9, 0x2e

    .line 161
    .line 162
    move v4, v3

    .line 163
    const/4 v3, 0x0

    .line 164
    const/4 v5, 0x0

    .line 165
    move-object v2, v0

    .line 166
    invoke-static/range {v2 .. v9}, Lb14;->h(Ljava/lang/String;Lj53;ZZLwh2;Lzi2;II)V

    .line 167
    .line 168
    .line 169
    goto :goto_2

    .line 170
    :cond_7
    invoke-virtual {v7}, Lzi2;->b0()V

    .line 171
    .line 172
    .line 173
    :goto_2
    return-object v1

    .line 174
    nop

    .line 175
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
.end method
