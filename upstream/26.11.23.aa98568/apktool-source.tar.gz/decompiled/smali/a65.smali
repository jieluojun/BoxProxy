.class public final La65;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Lo65;

.field public final b:Lw75;

.field public final c:Lv75;

.field public d:Z

.field public e:Ljava/lang/Object;

.field public final f:Ldm3;


# direct methods
.method public constructor <init>(IFLo65;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, La65;->a:Lo65;

    .line 5
    .line 6
    new-instance p3, Lw75;

    .line 7
    .line 8
    invoke-direct {p3, p1}, Lw75;-><init>(I)V

    .line 9
    .line 10
    .line 11
    iput-object p3, p0, La65;->b:Lw75;

    .line 12
    .line 13
    new-instance p3, Lv75;

    .line 14
    .line 15
    invoke-direct {p3, p2}, Lv75;-><init>(F)V

    .line 16
    .line 17
    .line 18
    iput-object p3, p0, La65;->c:Lv75;

    .line 19
    .line 20
    new-instance p2, Ldm3;

    .line 21
    .line 22
    const/16 p3, 0x1e

    .line 23
    .line 24
    const/16 v0, 0x64

    .line 25
    .line 26
    invoke-direct {p2, p1, p3, v0}, Ldm3;-><init>(III)V

    .line 27
    .line 28
    .line 29
    iput-object p2, p0, La65;->f:Ldm3;

    .line 30
    .line 31
    return-void
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method
