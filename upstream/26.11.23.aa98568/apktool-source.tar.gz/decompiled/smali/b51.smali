.class public final Lb51;
.super Lej3;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final synthetic c:Ld51;


# direct methods
.method public constructor <init>(Ld51;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb51;->c:Ld51;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final p(Lus4;)Lvy3;
    .locals 2

    .line 1
    instance-of v0, p1, Lvy3;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    check-cast p1, Lvy3;

    .line 6
    .line 7
    return-object p1

    .line 8
    :cond_0
    iget-object p1, p1, Lus4;->e:Ljava/util/Optional;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/util/Optional;->isPresent()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    iget-object p0, p0, Lb51;->c:Ld51;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    iget-object v0, p0, Ld51;->j:Ljava/util/HashMap;

    .line 19
    .line 20
    invoke-virtual {p1}, Ljava/util/Optional;->get()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    check-cast p1, Lus4;

    .line 29
    .line 30
    instance-of v0, p1, Lvy3;

    .line 31
    .line 32
    if-eqz v0, :cond_1

    .line 33
    .line 34
    check-cast p1, Lvy3;

    .line 35
    .line 36
    return-object p1

    .line 37
    :cond_1
    iget-object p0, p0, Ld51;->h:Lp85;

    .line 38
    .line 39
    invoke-virtual {p0}, Lp85;->e()Li42;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    new-instance p1, Lf51;

    .line 44
    .line 45
    iget-object p0, p0, Li42;->a:Ljava/util/Optional;

    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    const-string v1, "Expected mapping node or an anchor referencing mapping"

    .line 49
    .line 50
    invoke-direct {p1, v1, p0, v0}, Lf51;-><init>(Ljava/lang/String;Ljava/util/Optional;B)V

    .line 51
    .line 52
    .line 53
    throw p1
.end method
