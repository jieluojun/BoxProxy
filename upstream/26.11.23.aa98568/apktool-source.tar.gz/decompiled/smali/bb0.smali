.class public final Lbb0;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lkb0;


# static fields
.field public static final INSTANCE:Lbb0;

.field public static final synthetic a:Lvj3;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lbb0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lbb0;->INSTANCE:Lbb0;

    .line 7
    .line 8
    new-instance v0, Lta0;

    .line 9
    .line 10
    const/4 v1, 0x4

    .line 11
    invoke-direct {v0, v1}, Lta0;-><init>(B)V

    .line 12
    .line 13
    .line 14
    sget-object v1, Lpn3;->i:Lpn3;

    .line 15
    .line 16
    invoke-static {v1, v0}, Lxy3;->s(Lpn3;Llh2;)Lvj3;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Lbb0;->a:Lvj3;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of p0, p1, Lbb0;

    .line 6
    .line 7
    if-nez p0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_1
    return v0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    const p0, -0x10e2295c

    .line 2
    .line 3
    .line 4
    return p0
.end method

.method public final serializer()Lgg3;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lgg3;"
        }
    .end annotation

    .line 1
    sget-object p0, Lbb0;->a:Lvj3;

    .line 2
    .line 3
    invoke-interface {p0}, Lvj3;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lgg3;

    .line 8
    .line 9
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "RuntimeFiles"

    .line 2
    .line 3
    return-object p0
.end method
