.class public final Lac3;
.super Lbd3;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final l:Lwh2;


# direct methods
.method public constructor <init>(Lwh2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lju3;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lac3;->l:Lwh2;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final m()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final n(Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lac3;->l:Lwh2;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method
