.class public abstract Lb;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:[B

.field public static final b:[J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "0123456789abcdef"

    .line 2
    .line 3
    sget-object v1, Lsp0;->a:Ljava/nio/charset/Charset;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sput-object v0, Lb;->a:[B

    .line 13
    .line 14
    const/16 v0, 0x14

    .line 15
    .line 16
    new-array v0, v0, [J

    .line 17
    .line 18
    fill-array-data v0, :array_0

    .line 19
    .line 20
    .line 21
    sput-object v0, Lb;->b:[J

    .line 22
    .line 23
    return-void

    .line 24
    nop

    .line 25
    :array_0
    .array-data 8
        -0x1
        0x9
        0x63
        0x3e7
        0x270f
        0x1869f
        0xf423f
        0x98967f
        0x5f5e0ff
        0x3b9ac9ff
        0x2540be3ffL
        0x174876e7ffL
        0xe8d4a50fffL
        0x9184e729fffL
        0x5af3107a3fffL
        0x38d7ea4c67fffL
        0x2386f26fc0ffffL
        0x16345785d89ffffL
        0xde0b6b3a763ffffL
        0x7fffffffffffffffL
    .end array-data
.end method

.method public static final a(Ljg0;Ldj0;JJI)J
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-wide/from16 v1, p2

    .line 4
    .line 5
    move-wide/from16 v3, p4

    .line 6
    .line 7
    move-object/from16 v5, p1

    .line 8
    .line 9
    move/from16 v6, p6

    .line 10
    .line 11
    iget-object v5, v5, Ldj0;->h:[B

    .line 12
    .line 13
    array-length v7, v5

    .line 14
    int-to-long v8, v7

    .line 15
    int-to-long v12, v6

    .line 16
    const-wide/16 v10, 0x0

    .line 17
    .line 18
    invoke-static/range {v8 .. v13}, Ln14;->o(JJJ)V

    .line 19
    .line 20
    .line 21
    const-wide/16 v7, 0x0

    .line 22
    .line 23
    if-lez v6, :cond_b

    .line 24
    .line 25
    cmp-long v9, v1, v7

    .line 26
    .line 27
    if-ltz v9, :cond_a

    .line 28
    .line 29
    cmp-long v9, v1, v3

    .line 30
    .line 31
    if-gtz v9, :cond_9

    .line 32
    .line 33
    iget-wide v9, v0, Ljg0;->i:J

    .line 34
    .line 35
    cmp-long v11, v3, v9

    .line 36
    .line 37
    if-lez v11, :cond_0

    .line 38
    .line 39
    move-wide v3, v9

    .line 40
    :cond_0
    cmp-long v11, v1, v3

    .line 41
    .line 42
    if-eqz v11, :cond_8

    .line 43
    .line 44
    iget-object v11, v0, Ljg0;->h:Lgi6;

    .line 45
    .line 46
    if-eqz v11, :cond_8

    .line 47
    .line 48
    sub-long v14, v9, v1

    .line 49
    .line 50
    cmp-long v14, v14, v1

    .line 51
    .line 52
    const/4 v15, 0x0

    .line 53
    const-wide/16 v16, 0x1

    .line 54
    .line 55
    move-wide/from16 v18, v7

    .line 56
    .line 57
    if-gez v14, :cond_4

    .line 58
    .line 59
    :goto_0
    cmp-long v8, v9, v1

    .line 60
    .line 61
    if-lez v8, :cond_1

    .line 62
    .line 63
    iget-object v11, v11, Lgi6;->g:Lgi6;

    .line 64
    .line 65
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    iget v8, v11, Lgi6;->c:I

    .line 69
    .line 70
    iget v14, v11, Lgi6;->b:I

    .line 71
    .line 72
    sub-int/2addr v8, v14

    .line 73
    int-to-long v7, v8

    .line 74
    sub-long/2addr v9, v7

    .line 75
    goto :goto_0

    .line 76
    :cond_1
    aget-byte v7, v5, v15

    .line 77
    .line 78
    iget-wide v14, v0, Ljg0;->i:J

    .line 79
    .line 80
    sub-long/2addr v14, v12

    .line 81
    add-long v14, v14, v16

    .line 82
    .line 83
    invoke-static {v3, v4, v14, v15}, Ljava/lang/Math;->min(JJ)J

    .line 84
    .line 85
    .line 86
    move-result-wide v3

    .line 87
    :goto_1
    cmp-long v0, v9, v3

    .line 88
    .line 89
    if-gez v0, :cond_8

    .line 90
    .line 91
    iget-object v0, v11, Lgi6;->a:[B

    .line 92
    .line 93
    iget v8, v11, Lgi6;->c:I

    .line 94
    .line 95
    iget v12, v11, Lgi6;->b:I

    .line 96
    .line 97
    int-to-long v12, v12

    .line 98
    add-long/2addr v12, v3

    .line 99
    sub-long/2addr v12, v9

    .line 100
    int-to-long v14, v8

    .line 101
    invoke-static {v14, v15, v12, v13}, Ljava/lang/Math;->min(JJ)J

    .line 102
    .line 103
    .line 104
    move-result-wide v12

    .line 105
    long-to-int v8, v12

    .line 106
    iget v12, v11, Lgi6;->b:I

    .line 107
    .line 108
    int-to-long v12, v12

    .line 109
    add-long/2addr v12, v1

    .line 110
    sub-long/2addr v12, v9

    .line 111
    long-to-int v1, v12

    .line 112
    :goto_2
    if-ge v1, v8, :cond_3

    .line 113
    .line 114
    aget-byte v2, v0, v1

    .line 115
    .line 116
    if-ne v2, v7, :cond_2

    .line 117
    .line 118
    add-int/lit8 v2, v1, 0x1

    .line 119
    .line 120
    const/4 v12, 0x1

    .line 121
    invoke-static {v11, v2, v5, v12, v6}, Lb;->b(Lgi6;I[BII)Z

    .line 122
    .line 123
    .line 124
    move-result v2

    .line 125
    if-eqz v2, :cond_2

    .line 126
    .line 127
    iget v0, v11, Lgi6;->b:I

    .line 128
    .line 129
    sub-int/2addr v1, v0

    .line 130
    int-to-long v0, v1

    .line 131
    add-long/2addr v0, v9

    .line 132
    return-wide v0

    .line 133
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_3
    iget v0, v11, Lgi6;->c:I

    .line 137
    .line 138
    iget v1, v11, Lgi6;->b:I

    .line 139
    .line 140
    sub-int/2addr v0, v1

    .line 141
    int-to-long v0, v0

    .line 142
    add-long/2addr v9, v0

    .line 143
    iget-object v11, v11, Lgi6;->f:Lgi6;

    .line 144
    .line 145
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    move-wide v1, v9

    .line 149
    goto :goto_1

    .line 150
    :cond_4
    move-wide/from16 v7, v18

    .line 151
    .line 152
    :goto_3
    iget v9, v11, Lgi6;->c:I

    .line 153
    .line 154
    iget v10, v11, Lgi6;->b:I

    .line 155
    .line 156
    sub-int/2addr v9, v10

    .line 157
    int-to-long v9, v9

    .line 158
    add-long/2addr v9, v7

    .line 159
    cmp-long v14, v9, v1

    .line 160
    .line 161
    if-gtz v14, :cond_5

    .line 162
    .line 163
    iget-object v11, v11, Lgi6;->f:Lgi6;

    .line 164
    .line 165
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    move-wide v7, v9

    .line 169
    goto :goto_3

    .line 170
    :cond_5
    aget-byte v9, v5, v15

    .line 171
    .line 172
    iget-wide v14, v0, Ljg0;->i:J

    .line 173
    .line 174
    sub-long/2addr v14, v12

    .line 175
    add-long v14, v14, v16

    .line 176
    .line 177
    invoke-static {v3, v4, v14, v15}, Ljava/lang/Math;->min(JJ)J

    .line 178
    .line 179
    .line 180
    move-result-wide v3

    .line 181
    :goto_4
    cmp-long v0, v7, v3

    .line 182
    .line 183
    if-gez v0, :cond_8

    .line 184
    .line 185
    iget-object v0, v11, Lgi6;->a:[B

    .line 186
    .line 187
    iget v10, v11, Lgi6;->c:I

    .line 188
    .line 189
    iget v12, v11, Lgi6;->b:I

    .line 190
    .line 191
    int-to-long v12, v12

    .line 192
    add-long/2addr v12, v3

    .line 193
    sub-long/2addr v12, v7

    .line 194
    int-to-long v14, v10

    .line 195
    invoke-static {v14, v15, v12, v13}, Ljava/lang/Math;->min(JJ)J

    .line 196
    .line 197
    .line 198
    move-result-wide v12

    .line 199
    long-to-int v10, v12

    .line 200
    iget v12, v11, Lgi6;->b:I

    .line 201
    .line 202
    int-to-long v12, v12

    .line 203
    add-long/2addr v12, v1

    .line 204
    sub-long/2addr v12, v7

    .line 205
    long-to-int v1, v12

    .line 206
    :goto_5
    if-ge v1, v10, :cond_7

    .line 207
    .line 208
    aget-byte v2, v0, v1

    .line 209
    .line 210
    if-ne v2, v9, :cond_6

    .line 211
    .line 212
    add-int/lit8 v2, v1, 0x1

    .line 213
    .line 214
    const/4 v12, 0x1

    .line 215
    invoke-static {v11, v2, v5, v12, v6}, Lb;->b(Lgi6;I[BII)Z

    .line 216
    .line 217
    .line 218
    move-result v2

    .line 219
    if-eqz v2, :cond_6

    .line 220
    .line 221
    iget v0, v11, Lgi6;->b:I

    .line 222
    .line 223
    sub-int/2addr v1, v0

    .line 224
    int-to-long v0, v1

    .line 225
    add-long/2addr v0, v7

    .line 226
    return-wide v0

    .line 227
    :cond_6
    add-int/lit8 v1, v1, 0x1

    .line 228
    .line 229
    goto :goto_5

    .line 230
    :cond_7
    iget v0, v11, Lgi6;->c:I

    .line 231
    .line 232
    iget v1, v11, Lgi6;->b:I

    .line 233
    .line 234
    sub-int/2addr v0, v1

    .line 235
    int-to-long v0, v0

    .line 236
    add-long/2addr v7, v0

    .line 237
    iget-object v11, v11, Lgi6;->f:Lgi6;

    .line 238
    .line 239
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 240
    .line 241
    .line 242
    move-wide v1, v7

    .line 243
    goto :goto_4

    .line 244
    :cond_8
    const-wide/16 v0, -0x1

    .line 245
    .line 246
    return-wide v0

    .line 247
    :cond_9
    const-string v0, "fromIndex > toIndex: "

    .line 248
    .line 249
    const-string v5, " > "

    .line 250
    .line 251
    invoke-static {v1, v2, v0, v5}, Ldw4;->o(JLjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 256
    .line 257
    .line 258
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 263
    .line 264
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v0

    .line 268
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    throw v1

    .line 272
    :cond_a
    move-wide/from16 v18, v7

    .line 273
    .line 274
    const-string v0, "fromIndex < 0: "

    .line 275
    .line 276
    invoke-static {v1, v2, v0}, Ln32;->m(JLjava/lang/String;)Ljava/lang/String;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    invoke-static {v0}, Ll42;->c(Ljava/lang/Object;)V

    .line 281
    .line 282
    .line 283
    return-wide v18

    .line 284
    :cond_b
    move-wide/from16 v18, v7

    .line 285
    .line 286
    const-string v0, "byteCount == 0"

    .line 287
    .line 288
    invoke-static {v0}, Ll42;->g(Ljava/lang/String;)V

    .line 289
    .line 290
    .line 291
    return-wide v18
.end method

.method public static final b(Lgi6;I[BII)Z
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lgi6;->c:I

    .line 5
    .line 6
    iget-object v1, p0, Lgi6;->a:[B

    .line 7
    .line 8
    :goto_0
    if-ge p3, p4, :cond_2

    .line 9
    .line 10
    if-ne p1, v0, :cond_0

    .line 11
    .line 12
    iget-object p0, p0, Lgi6;->f:Lgi6;

    .line 13
    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object p1, p0, Lgi6;->a:[B

    .line 18
    .line 19
    iget v0, p0, Lgi6;->b:I

    .line 20
    .line 21
    iget v1, p0, Lgi6;->c:I

    .line 22
    .line 23
    move v4, v1

    .line 24
    move-object v1, p1

    .line 25
    move p1, v0

    .line 26
    move v0, v4

    .line 27
    :cond_0
    aget-byte v2, v1, p1

    .line 28
    .line 29
    aget-byte v3, p2, p3

    .line 30
    .line 31
    if-eq v2, v3, :cond_1

    .line 32
    .line 33
    const/4 p0, 0x0

    .line 34
    return p0

    .line 35
    :cond_1
    add-int/lit8 p1, p1, 0x1

    .line 36
    .line 37
    add-int/lit8 p3, p3, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_2
    const/4 p0, 0x1

    .line 41
    return p0
.end method

.method public static final c(Ljg0;J)Ljava/lang/String;
    .locals 6

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long v0, p1, v0

    .line 4
    .line 5
    const-wide/16 v1, 0x1

    .line 6
    .line 7
    if-lez v0, :cond_0

    .line 8
    .line 9
    sub-long v3, p1, v1

    .line 10
    .line 11
    invoke-virtual {p0, v3, v4}, Ljg0;->i(J)B

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/16 v5, 0xd

    .line 16
    .line 17
    if-ne v0, v5, :cond_0

    .line 18
    .line 19
    sget-object p1, Lsp0;->a:Ljava/nio/charset/Charset;

    .line 20
    .line 21
    invoke-virtual {p0, v3, v4, p1}, Ljg0;->F(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    const-wide/16 v0, 0x2

    .line 26
    .line 27
    invoke-virtual {p0, v0, v1}, Ljg0;->H(J)V

    .line 28
    .line 29
    .line 30
    return-object p1

    .line 31
    :cond_0
    sget-object v0, Lsp0;->a:Ljava/nio/charset/Charset;

    .line 32
    .line 33
    invoke-virtual {p0, p1, p2, v0}, Ljg0;->F(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    invoke-virtual {p0, v1, v2}, Ljg0;->H(J)V

    .line 38
    .line 39
    .line 40
    return-object p1
.end method

.method public static final d(Ljg0;Lxz4;Z)I
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v0, v0, Ljg0;->h:Lgi6;

    .line 4
    .line 5
    const/4 v1, -0x1

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    if-nez p2, :cond_4

    .line 9
    .line 10
    return v1

    .line 11
    :cond_0
    iget-object v2, v0, Lgi6;->a:[B

    .line 12
    .line 13
    iget v3, v0, Lgi6;->b:I

    .line 14
    .line 15
    iget v4, v0, Lgi6;->c:I

    .line 16
    .line 17
    move-object/from16 v5, p1

    .line 18
    .line 19
    iget-object v5, v5, Lxz4;->i:[I

    .line 20
    .line 21
    const/4 v6, 0x0

    .line 22
    move-object v8, v0

    .line 23
    move v9, v1

    .line 24
    move v7, v6

    .line 25
    :goto_0
    add-int/lit8 v10, v7, 0x1

    .line 26
    .line 27
    aget v11, v5, v7

    .line 28
    .line 29
    add-int/lit8 v7, v7, 0x2

    .line 30
    .line 31
    aget v10, v5, v10

    .line 32
    .line 33
    if-eq v10, v1, :cond_1

    .line 34
    .line 35
    move v9, v10

    .line 36
    :cond_1
    if-eqz v8, :cond_3

    .line 37
    .line 38
    const/4 v10, 0x0

    .line 39
    if-gez v11, :cond_8

    .line 40
    .line 41
    mul-int/lit8 v11, v11, -0x1

    .line 42
    .line 43
    add-int v12, v11, v7

    .line 44
    .line 45
    :goto_1
    add-int/lit8 v11, v3, 0x1

    .line 46
    .line 47
    aget-byte v3, v2, v3

    .line 48
    .line 49
    and-int/lit16 v3, v3, 0xff

    .line 50
    .line 51
    add-int/lit8 v13, v7, 0x1

    .line 52
    .line 53
    aget v7, v5, v7

    .line 54
    .line 55
    if-ne v3, v7, :cond_9

    .line 56
    .line 57
    if-ne v13, v12, :cond_2

    .line 58
    .line 59
    const/4 v3, 0x1

    .line 60
    goto :goto_2

    .line 61
    :cond_2
    move v3, v6

    .line 62
    :goto_2
    if-ne v11, v4, :cond_6

    .line 63
    .line 64
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    iget-object v2, v8, Lgi6;->f:Lgi6;

    .line 68
    .line 69
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    iget v4, v2, Lgi6;->b:I

    .line 73
    .line 74
    iget-object v7, v2, Lgi6;->a:[B

    .line 75
    .line 76
    iget v8, v2, Lgi6;->c:I

    .line 77
    .line 78
    if-ne v2, v0, :cond_5

    .line 79
    .line 80
    if-eqz v3, :cond_3

    .line 81
    .line 82
    move-object v2, v7

    .line 83
    move-object v7, v10

    .line 84
    goto :goto_3

    .line 85
    :cond_3
    if-eqz p2, :cond_9

    .line 86
    .line 87
    :cond_4
    const/4 v0, -0x2

    .line 88
    return v0

    .line 89
    :cond_5
    move-object v15, v7

    .line 90
    move-object v7, v2

    .line 91
    move-object v2, v15

    .line 92
    goto :goto_3

    .line 93
    :cond_6
    move-object v7, v8

    .line 94
    move v8, v4

    .line 95
    move v4, v11

    .line 96
    :goto_3
    if-eqz v3, :cond_7

    .line 97
    .line 98
    aget v3, v5, v13

    .line 99
    .line 100
    move v15, v8

    .line 101
    move-object v8, v7

    .line 102
    move v7, v15

    .line 103
    goto :goto_5

    .line 104
    :cond_7
    move v3, v4

    .line 105
    move v4, v8

    .line 106
    move-object v8, v7

    .line 107
    move v7, v13

    .line 108
    goto :goto_1

    .line 109
    :cond_8
    add-int/lit8 v12, v3, 0x1

    .line 110
    .line 111
    aget-byte v3, v2, v3

    .line 112
    .line 113
    and-int/lit16 v3, v3, 0xff

    .line 114
    .line 115
    add-int v13, v7, v11

    .line 116
    .line 117
    :goto_4
    if-ne v7, v13, :cond_a

    .line 118
    .line 119
    :cond_9
    return v9

    .line 120
    :cond_a
    aget v14, v5, v7

    .line 121
    .line 122
    if-ne v3, v14, :cond_e

    .line 123
    .line 124
    add-int/2addr v7, v11

    .line 125
    aget v3, v5, v7

    .line 126
    .line 127
    if-ne v12, v4, :cond_c

    .line 128
    .line 129
    iget-object v8, v8, Lgi6;->f:Lgi6;

    .line 130
    .line 131
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    .line 133
    .line 134
    iget v2, v8, Lgi6;->b:I

    .line 135
    .line 136
    iget-object v4, v8, Lgi6;->a:[B

    .line 137
    .line 138
    iget v7, v8, Lgi6;->c:I

    .line 139
    .line 140
    if-ne v8, v0, :cond_b

    .line 141
    .line 142
    move-object v8, v4

    .line 143
    move v4, v2

    .line 144
    move-object v2, v8

    .line 145
    move-object v8, v10

    .line 146
    goto :goto_5

    .line 147
    :cond_b
    move-object v15, v4

    .line 148
    move v4, v2

    .line 149
    move-object v2, v15

    .line 150
    goto :goto_5

    .line 151
    :cond_c
    move v7, v4

    .line 152
    move v4, v12

    .line 153
    :goto_5
    if-ltz v3, :cond_d

    .line 154
    .line 155
    return v3

    .line 156
    :cond_d
    neg-int v3, v3

    .line 157
    move v15, v7

    .line 158
    move v7, v3

    .line 159
    move v3, v4

    .line 160
    move v4, v15

    .line 161
    goto/16 :goto_0

    .line 162
    .line 163
    :cond_e
    add-int/lit8 v7, v7, 0x1

    .line 164
    .line 165
    goto :goto_4
.end method
