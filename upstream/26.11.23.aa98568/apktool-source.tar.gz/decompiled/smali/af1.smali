.class public final synthetic Laf1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Laf1;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Laf1;->i:Ljava/util/List;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 37

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Laf1;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    iget-object v0, v0, Laf1;->i:Ljava/util/List;

    .line 11
    .line 12
    packed-switch v1, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    move-object/from16 v1, p1

    .line 16
    .line 17
    check-cast v1, Lp01;

    .line 18
    .line 19
    move-object/from16 v15, p2

    .line 20
    .line 21
    check-cast v15, Lzi2;

    .line 22
    .line 23
    move-object/from16 v6, p3

    .line 24
    .line 25
    check-cast v6, Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 28
    .line 29
    .line 30
    move-result v6

    .line 31
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    and-int/lit8 v1, v6, 0x11

    .line 35
    .line 36
    if-eq v1, v3, :cond_0

    .line 37
    .line 38
    move v1, v4

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    const/4 v1, 0x0

    .line 41
    :goto_0
    and-int/2addr v6, v4

    .line 42
    invoke-virtual {v15, v6, v1}, Lzi2;->Y(IZ)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_2

    .line 47
    .line 48
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    const/4 v8, 0x0

    .line 53
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 54
    .line 55
    .line 56
    move-result v3

    .line 57
    if-eqz v3, :cond_3

    .line 58
    .line 59
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    add-int/lit8 v5, v8, 0x1

    .line 64
    .line 65
    if-ltz v8, :cond_1

    .line 66
    .line 67
    check-cast v3, Ld75;

    .line 68
    .line 69
    iget-object v4, v3, Ld75;->h:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v4, Ljava/lang/String;

    .line 72
    .line 73
    iget-object v3, v3, Ld75;->i:Ljava/lang/Object;

    .line 74
    .line 75
    move-object v7, v3

    .line 76
    check-cast v7, Llh2;

    .line 77
    .line 78
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 79
    .line 80
    .line 81
    move-result v9

    .line 82
    new-instance v3, Lq05;

    .line 83
    .line 84
    const/16 v6, 0xc

    .line 85
    .line 86
    invoke-direct {v3, v4, v6}, Lq05;-><init>(Ljava/lang/String;B)V

    .line 87
    .line 88
    .line 89
    const v4, -0x3ea1e952

    .line 90
    .line 91
    .line 92
    invoke-static {v4, v3, v15}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    const/16 v16, 0x6

    .line 97
    .line 98
    const/16 v17, 0x3f0

    .line 99
    .line 100
    const/4 v10, 0x0

    .line 101
    const/4 v11, 0x0

    .line 102
    const/4 v12, 0x0

    .line 103
    const/4 v13, 0x0

    .line 104
    const/4 v14, 0x0

    .line 105
    invoke-static/range {v6 .. v17}, Lr04;->a(Ls21;Llh2;IILbb4;Ls21;ZLu24;Lo45;Lzi2;II)V

    .line 106
    .line 107
    .line 108
    move v8, v5

    .line 109
    goto :goto_1

    .line 110
    :cond_1
    invoke-static {}, Lix;->x0()V

    .line 111
    .line 112
    .line 113
    const/4 v0, 0x0

    .line 114
    throw v0

    .line 115
    :cond_2
    invoke-virtual {v15}, Lzi2;->b0()V

    .line 116
    .line 117
    .line 118
    :cond_3
    return-object v2

    .line 119
    :pswitch_0
    sget-object v1, Ly6;->R:Lx31;

    .line 120
    .line 121
    sget-object v6, Ly6;->U:Lx31;

    .line 122
    .line 123
    sget-object v7, Ly6;->S:Lx31;

    .line 124
    .line 125
    sget-object v8, Ly6;->T:Lx31;

    .line 126
    .line 127
    move-object/from16 v9, p1

    .line 128
    .line 129
    check-cast v9, Lp01;

    .line 130
    .line 131
    move-object/from16 v10, p2

    .line 132
    .line 133
    check-cast v10, Lzi2;

    .line 134
    .line 135
    move-object/from16 v11, p3

    .line 136
    .line 137
    check-cast v11, Ljava/lang/Integer;

    .line 138
    .line 139
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 140
    .line 141
    .line 142
    move-result v11

    .line 143
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 144
    .line 145
    .line 146
    and-int/lit8 v9, v11, 0x11

    .line 147
    .line 148
    if-eq v9, v3, :cond_4

    .line 149
    .line 150
    move v3, v4

    .line 151
    goto :goto_2

    .line 152
    :cond_4
    const/4 v3, 0x0

    .line 153
    :goto_2
    and-int/2addr v11, v4

    .line 154
    invoke-virtual {v10, v11, v3}, Lzi2;->Y(IZ)Z

    .line 155
    .line 156
    .line 157
    move-result v3

    .line 158
    if-eqz v3, :cond_c

    .line 159
    .line 160
    sget-object v3, Lya4;->h:Lya4;

    .line 161
    .line 162
    const/high16 v9, 0x41800000    # 16.0f

    .line 163
    .line 164
    const/high16 v11, 0x41400000    # 12.0f

    .line 165
    .line 166
    invoke-static {v3, v9, v11}, Lah0;->F(Lbb4;FF)Lbb4;

    .line 167
    .line 168
    .line 169
    move-result-object v9

    .line 170
    new-instance v12, Lnw;

    .line 171
    .line 172
    new-instance v13, Ll42;

    .line 173
    .line 174
    const/4 v14, 0x3

    .line 175
    invoke-direct {v13, v14}, Ll42;-><init>(B)V

    .line 176
    .line 177
    .line 178
    const/high16 v14, 0x41000000    # 8.0f

    .line 179
    .line 180
    invoke-direct {v12, v14, v4, v13}, Lnw;-><init>(FZLl42;)V

    .line 181
    .line 182
    .line 183
    sget-object v13, Ly6;->v:Lz30;

    .line 184
    .line 185
    const/4 v14, 0x6

    .line 186
    invoke-static {v12, v13, v10, v14}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 187
    .line 188
    .line 189
    move-result-object v12

    .line 190
    iget-wide v14, v10, Lzi2;->U:J

    .line 191
    .line 192
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 193
    .line 194
    .line 195
    move-result v13

    .line 196
    invoke-virtual {v10}, Lzi2;->m()Lla5;

    .line 197
    .line 198
    .line 199
    move-result-object v14

    .line 200
    invoke-static {v10, v9}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 201
    .line 202
    .line 203
    move-result-object v9

    .line 204
    sget-object v15, Ls41;->d:Ly6;

    .line 205
    .line 206
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 207
    .line 208
    .line 209
    invoke-virtual {v10}, Lzi2;->k0()V

    .line 210
    .line 211
    .line 212
    iget-boolean v15, v10, Lzi2;->T:Z

    .line 213
    .line 214
    sget-object v5, Lzi3;->Z:Lu43;

    .line 215
    .line 216
    if-eqz v15, :cond_5

    .line 217
    .line 218
    invoke-virtual {v10, v5}, Lzi2;->l(Llh2;)V

    .line 219
    .line 220
    .line 221
    goto :goto_3

    .line 222
    :cond_5
    invoke-virtual {v10}, Lzi2;->t0()V

    .line 223
    .line 224
    .line 225
    :goto_3
    invoke-static {v8, v10, v12}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    invoke-static {v7, v10, v14}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    invoke-static {v13, v10, v6, v10}, Lp92;->w(ILzi2;Lx31;Lzi2;)V

    .line 232
    .line 233
    .line 234
    const v12, 0x29197259

    .line 235
    .line 236
    .line 237
    invoke-static {v10, v9, v1, v12, v0}, Ln32;->t(Lzi2;Lbb4;Lx31;ILjava/util/List;)Ljava/util/Iterator;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 242
    .line 243
    .line 244
    move-result v9

    .line 245
    if-eqz v9, :cond_b

    .line 246
    .line 247
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v9

    .line 251
    check-cast v9, Ld75;

    .line 252
    .line 253
    iget-object v12, v9, Ld75;->h:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v12, Ljava/lang/String;

    .line 256
    .line 257
    iget-object v9, v9, Ld75;->i:Ljava/lang/Object;

    .line 258
    .line 259
    check-cast v9, Ljava/lang/String;

    .line 260
    .line 261
    const/high16 v13, 0x3f800000    # 1.0f

    .line 262
    .line 263
    invoke-static {v3, v13}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 264
    .line 265
    .line 266
    move-result-object v13

    .line 267
    sget-object v14, Ly6;->s:La40;

    .line 268
    .line 269
    sget-object v15, Lob3;->e:Lkw;

    .line 270
    .line 271
    const/16 v11, 0x30

    .line 272
    .line 273
    invoke-static {v15, v14, v10, v11}, Ln26;->a(Lmw;La40;Lzi2;I)Lo26;

    .line 274
    .line 275
    .line 276
    move-result-object v11

    .line 277
    iget-wide v14, v10, Lzi2;->U:J

    .line 278
    .line 279
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 280
    .line 281
    .line 282
    move-result v14

    .line 283
    invoke-virtual {v10}, Lzi2;->m()Lla5;

    .line 284
    .line 285
    .line 286
    move-result-object v15

    .line 287
    invoke-static {v10, v13}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 288
    .line 289
    .line 290
    move-result-object v13

    .line 291
    sget-object v16, Ls41;->d:Ly6;

    .line 292
    .line 293
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 294
    .line 295
    .line 296
    invoke-virtual {v10}, Lzi2;->k0()V

    .line 297
    .line 298
    .line 299
    iget-boolean v4, v10, Lzi2;->T:Z

    .line 300
    .line 301
    if-eqz v4, :cond_6

    .line 302
    .line 303
    invoke-virtual {v10, v5}, Lzi2;->l(Llh2;)V

    .line 304
    .line 305
    .line 306
    goto :goto_5

    .line 307
    :cond_6
    invoke-virtual {v10}, Lzi2;->t0()V

    .line 308
    .line 309
    .line 310
    :goto_5
    invoke-static {v8, v10, v11}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 311
    .line 312
    .line 313
    invoke-static {v7, v10, v15}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    invoke-static {v14, v10, v6, v10}, Lp92;->w(ILzi2;Lx31;Lzi2;)V

    .line 317
    .line 318
    .line 319
    invoke-static {v1, v10, v13}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 320
    .line 321
    .line 322
    sget-object v4, Lvz0;->a:Lux1;

    .line 323
    .line 324
    invoke-virtual {v10, v4}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v11

    .line 328
    check-cast v11, Luz0;

    .line 329
    .line 330
    invoke-virtual {v11}, Luz0;->n()J

    .line 331
    .line 332
    .line 333
    move-result-wide v13

    .line 334
    sget-object v11, Lei7;->a:Lux1;

    .line 335
    .line 336
    invoke-virtual {v10, v11}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    move-result-object v15

    .line 340
    check-cast v15, Ldi7;

    .line 341
    .line 342
    invoke-virtual {v15}, Ldi7;->c()Lbi7;

    .line 343
    .line 344
    .line 345
    move-result-object v28

    .line 346
    const v15, 0x3eae147b    # 0.34f

    .line 347
    .line 348
    .line 349
    move-object/from16 p2, v0

    .line 350
    .line 351
    move-object/from16 v33, v1

    .line 352
    .line 353
    float-to-double v0, v15

    .line 354
    const-wide/16 v34, 0x0

    .line 355
    .line 356
    cmpl-double v0, v0, v34

    .line 357
    .line 358
    const-string v1, "invalid weight; must be greater than zero"

    .line 359
    .line 360
    if-lez v0, :cond_7

    .line 361
    .line 362
    :goto_6
    move-object v0, v11

    .line 363
    goto :goto_7

    .line 364
    :cond_7
    invoke-static {v1}, Ln73;->a(Ljava/lang/String;)V

    .line 365
    .line 366
    .line 367
    goto :goto_6

    .line 368
    :goto_7
    new-instance v11, Lsj3;

    .line 369
    .line 370
    const v36, 0x7f7fffff    # Float.MAX_VALUE

    .line 371
    .line 372
    .line 373
    cmpl-float v16, v15, v36

    .line 374
    .line 375
    if-lez v16, :cond_8

    .line 376
    .line 377
    move/from16 v15, v36

    .line 378
    .line 379
    :cond_8
    move-object/from16 p3, v0

    .line 380
    .line 381
    const/4 v0, 0x1

    .line 382
    invoke-direct {v11, v15, v0}, Lsj3;-><init>(FZ)V

    .line 383
    .line 384
    .line 385
    const/16 v31, 0x0

    .line 386
    .line 387
    const v32, 0x1fff8

    .line 388
    .line 389
    .line 390
    move-object/from16 v29, v10

    .line 391
    .line 392
    move-object v10, v12

    .line 393
    move-wide v12, v13

    .line 394
    const-wide/16 v14, 0x0

    .line 395
    .line 396
    const/16 v16, 0x0

    .line 397
    .line 398
    const/16 v17, 0x0

    .line 399
    .line 400
    const-wide/16 v18, 0x0

    .line 401
    .line 402
    const/16 v20, 0x0

    .line 403
    .line 404
    const-wide/16 v21, 0x0

    .line 405
    .line 406
    const/16 v23, 0x0

    .line 407
    .line 408
    const/16 v24, 0x0

    .line 409
    .line 410
    const/16 v25, 0x0

    .line 411
    .line 412
    const/16 v26, 0x0

    .line 413
    .line 414
    const/16 v27, 0x0

    .line 415
    .line 416
    const/16 v30, 0x0

    .line 417
    .line 418
    move-object/from16 v0, p3

    .line 419
    .line 420
    move-object/from16 p0, v1

    .line 421
    .line 422
    const/high16 v1, 0x41400000    # 12.0f

    .line 423
    .line 424
    invoke-static/range {v10 .. v32}, Lma7;->a(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILwh2;Lbi7;Lzi2;III)V

    .line 425
    .line 426
    .line 427
    move-object/from16 v10, v29

    .line 428
    .line 429
    invoke-static {v3, v1}, Lxt6;->q(Lbb4;F)Lbb4;

    .line 430
    .line 431
    .line 432
    move-result-object v11

    .line 433
    invoke-static {v10, v11}, Lvl3;->A(Lzi2;Lbb4;)V

    .line 434
    .line 435
    .line 436
    invoke-virtual {v10, v4}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 437
    .line 438
    .line 439
    move-result-object v4

    .line 440
    check-cast v4, Luz0;

    .line 441
    .line 442
    invoke-virtual {v4}, Luz0;->i()J

    .line 443
    .line 444
    .line 445
    move-result-wide v12

    .line 446
    invoke-virtual {v10, v0}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 447
    .line 448
    .line 449
    move-result-object v0

    .line 450
    check-cast v0, Ldi7;

    .line 451
    .line 452
    invoke-virtual {v0}, Ldi7;->c()Lbi7;

    .line 453
    .line 454
    .line 455
    move-result-object v28

    .line 456
    const v0, 0x3f28f5c3    # 0.66f

    .line 457
    .line 458
    .line 459
    float-to-double v14, v0

    .line 460
    cmpl-double v4, v14, v34

    .line 461
    .line 462
    if-gtz v4, :cond_9

    .line 463
    .line 464
    invoke-static/range {p0 .. p0}, Ln73;->a(Ljava/lang/String;)V

    .line 465
    .line 466
    .line 467
    :cond_9
    new-instance v11, Lsj3;

    .line 468
    .line 469
    cmpl-float v4, v0, v36

    .line 470
    .line 471
    if-lez v4, :cond_a

    .line 472
    .line 473
    move/from16 v0, v36

    .line 474
    .line 475
    :cond_a
    const/4 v4, 0x1

    .line 476
    invoke-direct {v11, v0, v4}, Lsj3;-><init>(FZ)V

    .line 477
    .line 478
    .line 479
    new-instance v0, Lca7;

    .line 480
    .line 481
    const/4 v4, 0x6

    .line 482
    invoke-direct {v0, v4}, Lca7;-><init>(I)V

    .line 483
    .line 484
    .line 485
    const/16 v31, 0x0

    .line 486
    .line 487
    const v32, 0x1fbf8

    .line 488
    .line 489
    .line 490
    const-wide/16 v14, 0x0

    .line 491
    .line 492
    const/16 v16, 0x0

    .line 493
    .line 494
    const/16 v17, 0x0

    .line 495
    .line 496
    const-wide/16 v18, 0x0

    .line 497
    .line 498
    const-wide/16 v21, 0x0

    .line 499
    .line 500
    const/16 v23, 0x0

    .line 501
    .line 502
    const/16 v24, 0x0

    .line 503
    .line 504
    const/16 v25, 0x0

    .line 505
    .line 506
    const/16 v26, 0x0

    .line 507
    .line 508
    const/16 v27, 0x0

    .line 509
    .line 510
    const/16 v30, 0x0

    .line 511
    .line 512
    move-object/from16 v20, v0

    .line 513
    .line 514
    move-object/from16 v29, v10

    .line 515
    .line 516
    move-object v10, v9

    .line 517
    invoke-static/range {v10 .. v32}, Lma7;->a(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILwh2;Lbi7;Lzi2;III)V

    .line 518
    .line 519
    .line 520
    move-object/from16 v10, v29

    .line 521
    .line 522
    const/4 v0, 0x1

    .line 523
    invoke-virtual {v10, v0}, Lzi2;->r(Z)V

    .line 524
    .line 525
    .line 526
    move v4, v0

    .line 527
    move-object/from16 v1, v33

    .line 528
    .line 529
    move-object/from16 v0, p2

    .line 530
    .line 531
    goto/16 :goto_4

    .line 532
    .line 533
    :cond_b
    move v0, v4

    .line 534
    const/4 v9, 0x0

    .line 535
    invoke-virtual {v10, v9}, Lzi2;->r(Z)V

    .line 536
    .line 537
    .line 538
    invoke-virtual {v10, v0}, Lzi2;->r(Z)V

    .line 539
    .line 540
    .line 541
    goto :goto_8

    .line 542
    :cond_c
    invoke-virtual {v10}, Lzi2;->b0()V

    .line 543
    .line 544
    .line 545
    :goto_8
    return-object v2

    .line 546
    nop

    .line 547
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
