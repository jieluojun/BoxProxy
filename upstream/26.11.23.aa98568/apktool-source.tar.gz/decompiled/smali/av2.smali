.class public final Lav2;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:Lav2;

.field public static final b:Ljava/util/List;

.field public static final c:Lif4;

.field public static d:Z

.field public static final e:Lpz6;

.field public static final f:Lju5;

.field public static final g:Llw4;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lav2;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lav2;->a:Lav2;

    .line 7
    .line 8
    new-instance v0, Lkh3;

    .line 9
    .line 10
    const-string v1, "Baidu"

    .line 11
    .line 12
    const-string v2, "https://baidu.com"

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, Lkh3;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    new-instance v1, Lkh3;

    .line 18
    .line 19
    const-string v2, "Cloudflare"

    .line 20
    .line 21
    const-string v3, "https://cloudflare.com"

    .line 22
    .line 23
    invoke-direct {v1, v2, v3}, Lkh3;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    new-instance v2, Lkh3;

    .line 27
    .line 28
    const-string v3, "Google"

    .line 29
    .line 30
    const-string v4, "https://google.com"

    .line 31
    .line 32
    invoke-direct {v2, v3, v4}, Lkh3;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    filled-new-array {v0, v1, v2}, [Lkh3;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-static {v0}, Lix;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sput-object v0, Lav2;->b:Ljava/util/List;

    .line 44
    .line 45
    new-instance v0, Lif4;

    .line 46
    .line 47
    invoke-direct {v0}, Lif4;-><init>()V

    .line 48
    .line 49
    .line 50
    sput-object v0, Lav2;->c:Lif4;

    .line 51
    .line 52
    new-instance v0, Lqu2;

    .line 53
    .line 54
    new-instance v1, Ljava/util/ArrayList;

    .line 55
    .line 56
    const/4 v2, 0x3

    .line 57
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 58
    .line 59
    .line 60
    const/4 v3, 0x0

    .line 61
    move v4, v3

    .line 62
    :goto_0
    if-ge v4, v2, :cond_0

    .line 63
    .line 64
    const/4 v5, 0x0

    .line 65
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    add-int/lit8 v4, v4, 0x1

    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_0
    sget-object v2, Lav2;->b:Ljava/util/List;

    .line 72
    .line 73
    const/4 v4, 0x1

    .line 74
    invoke-direct {v0, v4, v3, v1, v2}, Lqu2;-><init>(ZZLjava/util/List;Ljava/util/List;)V

    .line 75
    .line 76
    .line 77
    invoke-static {v0}, Lnb3;->n(Ljava/lang/Object;)Lpz6;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    sput-object v0, Lav2;->e:Lpz6;

    .line 82
    .line 83
    invoke-static {v0}, Lnv;->U(Lpz6;)Lju5;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    sput-object v0, Lav2;->f:Lju5;

    .line 88
    .line 89
    sget-object v0, Lxc0;->a:Lz67;

    .line 90
    .line 91
    sget-object v0, Lxc0;->f:Lz67;

    .line 92
    .line 93
    invoke-virtual {v0}, Lz67;->getValue()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    check-cast v0, Llw4;

    .line 98
    .line 99
    sput-object v0, Lav2;->g:Llw4;

    .line 100
    .line 101
    return-void
.end method

.method public static a(Ljava/util/List;)Ljava/util/ArrayList;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 5
    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    :goto_0
    if-ge v2, v1, :cond_1

    .line 9
    .line 10
    invoke-static {v2, p0}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    check-cast v3, Lkh3;

    .line 15
    .line 16
    if-nez v3, :cond_0

    .line 17
    .line 18
    sget-object v3, Lav2;->b:Ljava/util/List;

    .line 19
    .line 20
    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    check-cast v3, Lkh3;

    .line 25
    .line 26
    :cond_0
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    add-int/lit8 v2, v2, 0x1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    return-object v0
.end method


# virtual methods
.method public final b(Ljava/util/List;Lyd1;)Ljava/lang/Object;
    .locals 13

    .line 1
    sget-object v0, Lav2;->a:Lav2;

    .line 2
    .line 3
    instance-of v1, p2, Luu2;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    move-object v1, p2

    .line 8
    check-cast v1, Luu2;

    .line 9
    .line 10
    iget v2, v1, Luu2;->p:I

    .line 11
    .line 12
    const/high16 v3, -0x80000000

    .line 13
    .line 14
    and-int v4, v2, v3

    .line 15
    .line 16
    if-eqz v4, :cond_0

    .line 17
    .line 18
    sub-int/2addr v2, v3

    .line 19
    iput v2, v1, Luu2;->p:I

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    new-instance v1, Luu2;

    .line 23
    .line 24
    invoke-direct {v1, p0, p2}, Luu2;-><init>(Lav2;Lyd1;)V

    .line 25
    .line 26
    .line 27
    :goto_0
    iget-object p0, v1, Luu2;->n:Ljava/lang/Object;

    .line 28
    .line 29
    iget p2, v1, Luu2;->p:I

    .line 30
    .line 31
    const/4 v2, 0x2

    .line 32
    sget-object v3, Lav2;->e:Lpz6;

    .line 33
    .line 34
    const/4 v4, 0x0

    .line 35
    const/4 v5, 0x1

    .line 36
    const/4 v6, 0x0

    .line 37
    sget-object v7, Lkj1;->h:Lkj1;

    .line 38
    .line 39
    if-eqz p2, :cond_3

    .line 40
    .line 41
    if-eq p2, v5, :cond_2

    .line 42
    .line 43
    if-ne p2, v2, :cond_1

    .line 44
    .line 45
    iget-object p1, v1, Luu2;->m:Ljava/util/ArrayList;

    .line 46
    .line 47
    iget-object p2, v1, Luu2;->l:Lif4;

    .line 48
    .line 49
    :try_start_0
    invoke-static {p0}, Lyl3;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 50
    .line 51
    .line 52
    goto/16 :goto_5

    .line 53
    .line 54
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 55
    .line 56
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    return-object v6

    .line 60
    :cond_2
    iget-object p1, v1, Luu2;->l:Lif4;

    .line 61
    .line 62
    iget-object p2, v1, Luu2;->k:Ljava/util/List;

    .line 63
    .line 64
    invoke-static {p0}, Lyl3;->M(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    move-object v12, p2

    .line 68
    move-object p2, p1

    .line 69
    move-object p1, v12

    .line 70
    goto :goto_1

    .line 71
    :cond_3
    invoke-static {p0}, Lyl3;->M(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    iput-object p1, v1, Luu2;->k:Ljava/util/List;

    .line 75
    .line 76
    sget-object p0, Lav2;->c:Lif4;

    .line 77
    .line 78
    iput-object p0, v1, Luu2;->l:Lif4;

    .line 79
    .line 80
    iput v5, v1, Luu2;->p:I

    .line 81
    .line 82
    invoke-virtual {p0, v1}, Lif4;->e(Lxd1;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    if-eq p2, v7, :cond_7

    .line 87
    .line 88
    move-object p2, p0

    .line 89
    :goto_1
    :try_start_1
    invoke-static {p1}, Lav2;->a(Ljava/util/List;)Ljava/util/ArrayList;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-virtual {v3}, Lpz6;->getValue()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    check-cast p0, Lqu2;

    .line 98
    .line 99
    iget-object p0, p0, Lqu2;->c:Ljava/util/List;

    .line 100
    .line 101
    new-instance v8, Ljava/util/ArrayList;

    .line 102
    .line 103
    const/4 v9, 0x3

    .line 104
    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 105
    .line 106
    .line 107
    move v10, v4

    .line 108
    :goto_2
    if-ge v10, v9, :cond_4

    .line 109
    .line 110
    invoke-static {v10, p0}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v11

    .line 114
    check-cast v11, Ltu2;

    .line 115
    .line 116
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    add-int/lit8 v10, v10, 0x1

    .line 120
    .line 121
    goto :goto_2

    .line 122
    :cond_4
    invoke-virtual {v3}, Lpz6;->getValue()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v10

    .line 126
    check-cast v10, Lqu2;

    .line 127
    .line 128
    iget-boolean v10, v10, Lqu2;->b:Z

    .line 129
    .line 130
    if-eqz v10, :cond_5

    .line 131
    .line 132
    invoke-virtual {v3}, Lpz6;->getValue()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v10

    .line 136
    check-cast v10, Lqu2;

    .line 137
    .line 138
    iget-object v10, v10, Lqu2;->d:Ljava/util/List;

    .line 139
    .line 140
    invoke-static {v10, p1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v10

    .line 144
    if-eqz v10, :cond_5

    .line 145
    .line 146
    move v10, v5

    .line 147
    goto :goto_3

    .line 148
    :cond_5
    move v10, v4

    .line 149
    :goto_3
    invoke-virtual {v3}, Lpz6;->getValue()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v11

    .line 153
    check-cast v11, Lqu2;

    .line 154
    .line 155
    iget-object v11, v11, Lqu2;->d:Ljava/util/List;

    .line 156
    .line 157
    invoke-static {v11, p1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v11

    .line 161
    if-nez v11, :cond_6

    .line 162
    .line 163
    new-instance p0, Ljava/util/ArrayList;

    .line 164
    .line 165
    invoke-direct {p0, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 166
    .line 167
    .line 168
    move v11, v4

    .line 169
    :goto_4
    if-ge v11, v9, :cond_6

    .line 170
    .line 171
    invoke-virtual {p0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    add-int/lit8 v11, v11, 0x1

    .line 175
    .line 176
    goto :goto_4

    .line 177
    :cond_6
    new-instance v9, Lqu2;

    .line 178
    .line 179
    invoke-direct {v9, v5, v10, p0, p1}, Lqu2;-><init>(ZZLjava/util/List;Ljava/util/List;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v3, v6, v9}, Lpz6;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 183
    .line 184
    .line 185
    new-instance p0, Lvu2;

    .line 186
    .line 187
    invoke-direct {p0, v8, v6}, Lvu2;-><init>(Ljava/util/ArrayList;Lxd1;)V

    .line 188
    .line 189
    .line 190
    iput-object v6, v1, Luu2;->k:Ljava/util/List;

    .line 191
    .line 192
    iput-object p2, v1, Luu2;->l:Lif4;

    .line 193
    .line 194
    iput-object p1, v1, Luu2;->m:Ljava/util/ArrayList;

    .line 195
    .line 196
    iput v2, v1, Luu2;->p:I

    .line 197
    .line 198
    invoke-virtual {v0, p1, p0, v1}, Lav2;->c(Ljava/util/ArrayList;Lvu2;Lyd1;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object p0

    .line 202
    if-ne p0, v7, :cond_8

    .line 203
    .line 204
    :cond_7
    return-object v7

    .line 205
    :cond_8
    :goto_5
    check-cast p0, Ljava/util/List;

    .line 206
    .line 207
    new-instance v0, Ljava/util/ArrayList;

    .line 208
    .line 209
    const/16 v1, 0xa

    .line 210
    .line 211
    invoke-static {p0, v1}, Lby0;->D0(Ljava/lang/Iterable;I)I

    .line 212
    .line 213
    .line 214
    move-result v1

    .line 215
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 216
    .line 217
    .line 218
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 219
    .line 220
    .line 221
    move-result-object p0

    .line 222
    :goto_6
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 223
    .line 224
    .line 225
    move-result v1

    .line 226
    if-eqz v1, :cond_9

    .line 227
    .line 228
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    check-cast v1, Ltu2;

    .line 233
    .line 234
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 235
    .line 236
    .line 237
    goto :goto_6

    .line 238
    :cond_9
    new-instance p0, Lqu2;

    .line 239
    .line 240
    invoke-direct {p0, v4, v5, v0, p1}, Lqu2;-><init>(ZZLjava/util/List;Ljava/util/List;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 244
    .line 245
    .line 246
    invoke-virtual {v3, v6, p0}, Lpz6;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 247
    .line 248
    .line 249
    sget-object p0, Lst7;->a:Lst7;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 250
    .line 251
    invoke-virtual {p2, v6}, Lif4;->g(Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    return-object p0

    .line 255
    :catchall_0
    move-exception p0

    .line 256
    invoke-virtual {p2, v6}, Lif4;->g(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    throw p0
.end method

.method public final c(Ljava/util/ArrayList;Lvu2;Lyd1;)Ljava/lang/Object;
    .locals 5

    .line 1
    instance-of v0, p3, Lwu2;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Lwu2;

    .line 7
    .line 8
    iget v1, v0, Lwu2;->o:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lwu2;->o:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lwu2;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, Lwu2;-><init>(Lav2;Lyd1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p0, v0, Lwu2;->m:Ljava/lang/Object;

    .line 26
    .line 27
    iget p3, v0, Lwu2;->o:I

    .line 28
    .line 29
    const/4 v1, 0x2

    .line 30
    const/4 v2, 0x1

    .line 31
    const/4 v3, 0x0

    .line 32
    sget-object v4, Lkj1;->h:Lkj1;

    .line 33
    .line 34
    if-eqz p3, :cond_3

    .line 35
    .line 36
    if-eq p3, v2, :cond_2

    .line 37
    .line 38
    if-ne p3, v1, :cond_1

    .line 39
    .line 40
    invoke-static {p0}, Lyl3;->M(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    return-object p0

    .line 44
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v3

    .line 50
    :cond_2
    iget-object p2, v0, Lwu2;->l:Lvu2;

    .line 51
    .line 52
    iget-object p1, v0, Lwu2;->k:Ljava/util/ArrayList;

    .line 53
    .line 54
    :try_start_0
    invoke-static {p0}, Lyl3;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 55
    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_3
    invoke-static {p0}, Lyl3;->M(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    sget-boolean p0, Lav2;->d:Z

    .line 62
    .line 63
    if-nez p0, :cond_4

    .line 64
    .line 65
    sput-boolean v2, Lav2;->d:Z

    .line 66
    .line 67
    :try_start_1
    new-instance p0, Lxu2;

    .line 68
    .line 69
    invoke-direct {p0, p1, v3}, Lxu2;-><init>(Ljava/util/ArrayList;Lxd1;)V

    .line 70
    .line 71
    .line 72
    iput-object p1, v0, Lwu2;->k:Ljava/util/ArrayList;

    .line 73
    .line 74
    iput-object p2, v0, Lwu2;->l:Lvu2;

    .line 75
    .line 76
    iput v2, v0, Lwu2;->o:I

    .line 77
    .line 78
    invoke-static {p0, v0}, Luu;->Q(Lai2;Lxd1;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p0
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 82
    if-ne p0, v4, :cond_4

    .line 83
    .line 84
    goto :goto_2

    .line 85
    :catch_0
    move-exception p0

    .line 86
    throw p0

    .line 87
    :catchall_0
    :cond_4
    :goto_1
    new-instance p0, Lzu2;

    .line 88
    .line 89
    invoke-direct {p0, p1, p2, v3}, Lzu2;-><init>(Ljava/util/ArrayList;Lvu2;Lxd1;)V

    .line 90
    .line 91
    .line 92
    iput-object v3, v0, Lwu2;->k:Ljava/util/ArrayList;

    .line 93
    .line 94
    iput-object v3, v0, Lwu2;->l:Lvu2;

    .line 95
    .line 96
    iput v1, v0, Lwu2;->o:I

    .line 97
    .line 98
    invoke-static {p0, v0}, Luu;->Q(Lai2;Lxd1;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object p0

    .line 102
    if-ne p0, v4, :cond_5

    .line 103
    .line 104
    :goto_2
    return-object v4

    .line 105
    :cond_5
    return-object p0
.end method
