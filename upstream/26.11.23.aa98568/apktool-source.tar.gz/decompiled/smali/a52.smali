.class public interface abstract La52;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public abstract a(Lny5;)V
.end method

.method public abstract b(Loz5;)Lgx6;
.end method

.method public abstract c()V
.end method

.method public abstract cancel()V
.end method

.method public abstract d()Z
.end method

.method public abstract e()V
.end method

.method public abstract f()Ltw6;
.end method

.method public abstract g(Lny5;J)Lmt6;
.end method

.method public abstract h()Lz42;
.end method

.method public abstract i(Loz5;)J
.end method

.method public abstract j(Z)Lnz5;
.end method
