.class public final synthetic La80;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Leq6;

.field public final synthetic j:Ljj1;

.field public final synthetic k:Llh2;


# direct methods
.method public synthetic constructor <init>(Leq6;Ljj1;Llh2;B)V
    .locals 0

    .line 14
    iput-byte p4, p0, La80;->h:B

    iput-object p1, p0, La80;->i:Leq6;

    iput-object p2, p0, La80;->j:Ljj1;

    iput-object p3, p0, La80;->k:Llh2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Leq6;Llh2;Ljj1;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, La80;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La80;->i:Leq6;

    .line 8
    .line 9
    iput-object p2, p0, La80;->k:Llh2;

    .line 10
    .line 11
    iput-object p3, p0, La80;->j:Ljj1;

    .line 12
    .line 13
    return-void
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 8

    .line 1
    iget-byte v0, p0, La80;->h:B

    .line 2
    .line 3
    sget-object v1, Lfq6;->h:Lfq6;

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    sget-object v3, Lst7;->a:Lst7;

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    iget-object v5, p0, La80;->k:Llh2;

    .line 10
    .line 11
    iget-object v6, p0, La80;->j:Ljj1;

    .line 12
    .line 13
    iget-object p0, p0, La80;->i:Leq6;

    .line 14
    .line 15
    const/4 v7, 0x3

    .line 16
    packed-switch v0, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Leq6;->c()Lfq6;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sget-object v1, Lfq6;->i:Lfq6;

    .line 24
    .line 25
    if-ne v0, v1, :cond_0

    .line 26
    .line 27
    iget-object v0, p0, Leq6;->d:Lu9;

    .line 28
    .line 29
    invoke-virtual {v0}, Lu9;->e()Lfn1;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    sget-object v1, Lfq6;->j:Lfq6;

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Lfn1;->c(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_0

    .line 40
    .line 41
    new-instance v0, Lh80;

    .line 42
    .line 43
    const/16 v1, 0x9

    .line 44
    .line 45
    invoke-direct {v0, p0, v4, v1}, Lh80;-><init>(Leq6;Lxd1;B)V

    .line 46
    .line 47
    .line 48
    invoke-static {v6, v4, v4, v0, v7}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_0
    new-instance v0, Lh80;

    .line 53
    .line 54
    const/16 v1, 0xa

    .line 55
    .line 56
    invoke-direct {v0, p0, v4, v1}, Lh80;-><init>(Leq6;Lxd1;B)V

    .line 57
    .line 58
    .line 59
    invoke-static {v6, v4, v4, v0, v7}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    new-instance v0, Lyo;

    .line 64
    .line 65
    const/16 v1, 0x13

    .line 66
    .line 67
    invoke-direct {v0, v5, v1}, Lyo;-><init>(Llh2;B)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p0, v0}, Lfd3;->x(Lwh2;)Lls1;

    .line 71
    .line 72
    .line 73
    :goto_0
    return-object v3

    .line 74
    :pswitch_0
    iget-object v0, p0, Leq6;->c:Lwh2;

    .line 75
    .line 76
    invoke-interface {v0, v1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Ljava/lang/Boolean;

    .line 81
    .line 82
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_1

    .line 87
    .line 88
    new-instance v0, Lh80;

    .line 89
    .line 90
    const/16 v1, 0x8

    .line 91
    .line 92
    invoke-direct {v0, p0, v4, v1}, Lh80;-><init>(Leq6;Lxd1;B)V

    .line 93
    .line 94
    .line 95
    invoke-static {v6, v4, v4, v0, v7}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    new-instance v1, Lc80;

    .line 100
    .line 101
    invoke-direct {v1, p0, v5, v2}, Lc80;-><init>(Leq6;Llh2;B)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v0, v1}, Lfd3;->x(Lwh2;)Lls1;

    .line 105
    .line 106
    .line 107
    :cond_1
    return-object v3

    .line 108
    :pswitch_1
    iget-object v0, p0, Leq6;->c:Lwh2;

    .line 109
    .line 110
    invoke-interface {v0, v1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    check-cast v0, Ljava/lang/Boolean;

    .line 115
    .line 116
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    if-eqz v0, :cond_2

    .line 121
    .line 122
    new-instance v0, Lh80;

    .line 123
    .line 124
    const/4 v1, 0x6

    .line 125
    invoke-direct {v0, p0, v4, v1}, Lh80;-><init>(Leq6;Lxd1;B)V

    .line 126
    .line 127
    .line 128
    invoke-static {v6, v4, v4, v0, v7}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    new-instance v1, Lc80;

    .line 133
    .line 134
    const/4 v2, 0x0

    .line 135
    invoke-direct {v1, p0, v5, v2}, Lc80;-><init>(Leq6;Llh2;B)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v0, v1}, Lfd3;->x(Lwh2;)Lls1;

    .line 139
    .line 140
    .line 141
    :cond_2
    return-object v3

    .line 142
    :pswitch_2
    invoke-virtual {p0}, Leq6;->c()Lfq6;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    const/4 v1, 0x1

    .line 151
    if-eq v0, v1, :cond_4

    .line 152
    .line 153
    if-eq v0, v2, :cond_3

    .line 154
    .line 155
    new-instance v0, Lh80;

    .line 156
    .line 157
    invoke-direct {v0, p0, v4, v7}, Lh80;-><init>(Leq6;Lxd1;B)V

    .line 158
    .line 159
    .line 160
    invoke-static {v6, v4, v4, v0, v7}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 161
    .line 162
    .line 163
    goto :goto_1

    .line 164
    :cond_3
    new-instance v0, Lh80;

    .line 165
    .line 166
    invoke-direct {v0, p0, v4, v2}, Lh80;-><init>(Leq6;Lxd1;B)V

    .line 167
    .line 168
    .line 169
    invoke-static {v6, v4, v4, v0, v7}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 170
    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_4
    invoke-interface {v5}, Llh2;->a()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    :goto_1
    return-object v3

    .line 177
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
.end method
