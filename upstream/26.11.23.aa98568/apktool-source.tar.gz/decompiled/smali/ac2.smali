.class public final synthetic Lac2;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic A:J

.field public final synthetic B:Lv75;

.field public final synthetic C:Lv75;

.field public final synthetic D:Lbb4;

.field public final synthetic h:Lkp1;

.field public final synthetic i:I

.field public final synthetic j:Lmz6;

.field public final synthetic k:Lz16;

.field public final synthetic l:Z

.field public final synthetic m:Lg00;

.field public final synthetic n:Lbb4;

.field public final synthetic o:Lyh3;

.field public final synthetic p:Le50;

.field public final synthetic q:J

.field public final synthetic r:Lta3;

.field public final synthetic s:Lxl1;

.field public final synthetic t:F

.field public final synthetic u:Ls21;

.field public final synthetic v:Lyh3;

.field public final synthetic w:J

.field public final synthetic x:Z

.field public final synthetic y:Lr01;

.field public final synthetic z:Lbb4;


# direct methods
.method public synthetic constructor <init>(Lkp1;ILmz6;Lz16;ZLg00;Lbb4;Lyh3;Le50;JLta3;Lxl1;FLs21;Lyh3;JZLr01;Lbb4;JLv75;Lv75;Lbb4;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lac2;->h:Lkp1;

    .line 5
    .line 6
    iput p2, p0, Lac2;->i:I

    .line 7
    .line 8
    iput-object p3, p0, Lac2;->j:Lmz6;

    .line 9
    .line 10
    iput-object p4, p0, Lac2;->k:Lz16;

    .line 11
    .line 12
    iput-boolean p5, p0, Lac2;->l:Z

    .line 13
    .line 14
    iput-object p6, p0, Lac2;->m:Lg00;

    .line 15
    .line 16
    iput-object p7, p0, Lac2;->n:Lbb4;

    .line 17
    .line 18
    iput-object p8, p0, Lac2;->o:Lyh3;

    .line 19
    .line 20
    iput-object p9, p0, Lac2;->p:Le50;

    .line 21
    .line 22
    iput-wide p10, p0, Lac2;->q:J

    .line 23
    .line 24
    iput-object p12, p0, Lac2;->r:Lta3;

    .line 25
    .line 26
    iput-object p13, p0, Lac2;->s:Lxl1;

    .line 27
    .line 28
    iput p14, p0, Lac2;->t:F

    .line 29
    .line 30
    iput-object p15, p0, Lac2;->u:Ls21;

    .line 31
    .line 32
    move-object/from16 p1, p16

    .line 33
    .line 34
    iput-object p1, p0, Lac2;->v:Lyh3;

    .line 35
    .line 36
    move-wide/from16 p1, p17

    .line 37
    .line 38
    iput-wide p1, p0, Lac2;->w:J

    .line 39
    .line 40
    move/from16 p1, p19

    .line 41
    .line 42
    iput-boolean p1, p0, Lac2;->x:Z

    .line 43
    .line 44
    move-object/from16 p1, p20

    .line 45
    .line 46
    iput-object p1, p0, Lac2;->y:Lr01;

    .line 47
    .line 48
    move-object/from16 p1, p21

    .line 49
    .line 50
    iput-object p1, p0, Lac2;->z:Lbb4;

    .line 51
    .line 52
    move-wide/from16 p1, p22

    .line 53
    .line 54
    iput-wide p1, p0, Lac2;->A:J

    .line 55
    .line 56
    move-object/from16 p1, p24

    .line 57
    .line 58
    iput-object p1, p0, Lac2;->B:Lv75;

    .line 59
    .line 60
    move-object/from16 p1, p25

    .line 61
    .line 62
    iput-object p1, p0, Lac2;->C:Lv75;

    .line 63
    .line 64
    move-object/from16 p1, p26

    .line 65
    .line 66
    iput-object p1, p0, Lac2;->D:Lbb4;

    .line 67
    .line 68
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lzi2;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    sget-object v3, Lhc2;->a:Lux1;

    .line 16
    .line 17
    and-int/lit8 v4, v2, 0x3

    .line 18
    .line 19
    const/4 v5, 0x1

    .line 20
    const/4 v6, 0x0

    .line 21
    const/4 v7, 0x2

    .line 22
    if-eq v4, v7, :cond_0

    .line 23
    .line 24
    move v4, v5

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    move v4, v6

    .line 27
    :goto_0
    and-int/2addr v2, v5

    .line 28
    invoke-virtual {v1, v2, v4}, Lzi2;->Y(IZ)Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_14

    .line 33
    .line 34
    iget-object v2, v0, Lac2;->h:Lkp1;

    .line 35
    .line 36
    invoke-virtual {v1, v2}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    iget v8, v0, Lac2;->i:I

    .line 41
    .line 42
    invoke-virtual {v1, v8}, Lzi2;->e(I)Z

    .line 43
    .line 44
    .line 45
    move-result v9

    .line 46
    or-int/2addr v4, v9

    .line 47
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v9

    .line 51
    iget-object v10, v0, Lac2;->B:Lv75;

    .line 52
    .line 53
    iget-object v14, v0, Lac2;->C:Lv75;

    .line 54
    .line 55
    sget-object v11, Lc51;->a:Lql0;

    .line 56
    .line 57
    if-nez v4, :cond_1

    .line 58
    .line 59
    if-ne v9, v11, :cond_2

    .line 60
    .line 61
    :cond_1
    new-instance v9, Lrp1;

    .line 62
    .line 63
    invoke-direct {v9, v2, v8, v10, v14}, Lrp1;-><init>(Lkp1;ILv75;Lv75;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v1, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    :cond_2
    check-cast v9, Lwh2;

    .line 70
    .line 71
    sget-object v4, Lya4;->h:Lya4;

    .line 72
    .line 73
    invoke-static {v4, v9}, Lv97;->H(Lbb4;Lwh2;)Lbb4;

    .line 74
    .line 75
    .line 76
    move-result-object v8

    .line 77
    iget-object v15, v0, Lac2;->j:Lmz6;

    .line 78
    .line 79
    invoke-virtual {v1, v15}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v9

    .line 83
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v12

    .line 87
    if-nez v9, :cond_3

    .line 88
    .line 89
    if-ne v12, v11, :cond_4

    .line 90
    .line 91
    :cond_3
    new-instance v12, Lo60;

    .line 92
    .line 93
    invoke-direct {v12, v15, v7}, Lo60;-><init>(Lmz6;B)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v1, v12}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :cond_4
    check-cast v12, Lwh2;

    .line 100
    .line 101
    invoke-static {v8, v12}, Lkb;->H(Lbb4;Lwh2;)Lbb4;

    .line 102
    .line 103
    .line 104
    move-result-object v8

    .line 105
    new-instance v16, Lvn6;

    .line 106
    .line 107
    iget-boolean v9, v0, Lac2;->l:Z

    .line 108
    .line 109
    if-eqz v9, :cond_5

    .line 110
    .line 111
    const v13, 0x3dcccccd    # 0.1f

    .line 112
    .line 113
    .line 114
    move/from16 v23, v13

    .line 115
    .line 116
    goto :goto_1

    .line 117
    :cond_5
    const v23, 0x3e4ccccd    # 0.2f

    .line 118
    .line 119
    .line 120
    :goto_1
    const-wide/16 v21, 0x0

    .line 121
    .line 122
    const/16 v24, 0x3

    .line 123
    .line 124
    const/high16 v17, 0x41200000    # 10.0f

    .line 125
    .line 126
    const-wide/high16 v18, -0x100000000000000L

    .line 127
    .line 128
    const/16 v20, 0x0

    .line 129
    .line 130
    invoke-direct/range {v16 .. v24}, Lvn6;-><init>(FJFJFI)V

    .line 131
    .line 132
    .line 133
    move-object/from16 v13, v16

    .line 134
    .line 135
    new-instance v12, Lks6;

    .line 136
    .line 137
    iget-object v7, v0, Lac2;->k:Lz16;

    .line 138
    .line 139
    invoke-direct {v12, v7, v13}, Lks6;-><init>(Lbo6;Lvn6;)V

    .line 140
    .line 141
    .line 142
    invoke-interface {v8, v12}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 143
    .line 144
    .line 145
    move-result-object v8

    .line 146
    iget-object v12, v0, Lac2;->m:Lg00;

    .line 147
    .line 148
    if-eqz v12, :cond_6

    .line 149
    .line 150
    const v9, 0x484badfa

    .line 151
    .line 152
    .line 153
    invoke-virtual {v1, v9}, Lzi2;->h0(I)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v1, v6}, Lzi2;->r(Z)V

    .line 157
    .line 158
    .line 159
    iget-object v9, v0, Lac2;->n:Lbb4;

    .line 160
    .line 161
    move-object/from16 v24, v10

    .line 162
    .line 163
    goto/16 :goto_3

    .line 164
    .line 165
    :cond_6
    iget-object v13, v0, Lac2;->o:Lyh3;

    .line 166
    .line 167
    iget-wide v5, v0, Lac2;->q:J

    .line 168
    .line 169
    move/from16 v16, v9

    .line 170
    .line 171
    if-eqz v13, :cond_8

    .line 172
    .line 173
    iget-object v9, v0, Lac2;->p:Le50;

    .line 174
    .line 175
    if-eqz v9, :cond_8

    .line 176
    .line 177
    invoke-static {}, Ls64;->a()Z

    .line 178
    .line 179
    .line 180
    move-result v18

    .line 181
    if-eqz v18, :cond_8

    .line 182
    .line 183
    move-object/from16 v24, v10

    .line 184
    .line 185
    const v10, 0x4850c8d2

    .line 186
    .line 187
    .line 188
    invoke-virtual {v1, v10}, Lzi2;->h0(I)V

    .line 189
    .line 190
    .line 191
    const/16 v10, 0x8

    .line 192
    .line 193
    invoke-static {v4, v13, v9, v7, v10}, Ls64;->c(Lbb4;Lyh3;Le50;Lbo6;I)Lbb4;

    .line 194
    .line 195
    .line 196
    move-result-object v9

    .line 197
    if-eqz v16, :cond_7

    .line 198
    .line 199
    const v10, 0x3e0f5c29    # 0.14f

    .line 200
    .line 201
    .line 202
    goto :goto_2

    .line 203
    :cond_7
    const v10, 0x3e4ccccd    # 0.2f

    .line 204
    .line 205
    .line 206
    :goto_2
    invoke-static {v10, v5, v6}, Lgy0;->b(FJ)J

    .line 207
    .line 208
    .line 209
    move-result-wide v5

    .line 210
    invoke-static {v9, v5, v6, v7}, Lbr7;->B(Lbb4;JLbo6;)Lbb4;

    .line 211
    .line 212
    .line 213
    move-result-object v5

    .line 214
    invoke-static/range {v16 .. v16}, Lhc2;->d(Z)J

    .line 215
    .line 216
    .line 217
    move-result-wide v9

    .line 218
    new-instance v6, Lcx6;

    .line 219
    .line 220
    invoke-direct {v6, v9, v10}, Lcx6;-><init>(J)V

    .line 221
    .line 222
    .line 223
    new-instance v9, Lq50;

    .line 224
    .line 225
    const/high16 v10, 0x3f800000    # 1.0f

    .line 226
    .line 227
    invoke-direct {v9, v10, v6, v7}, Lq50;-><init>(FLcx6;Lbo6;)V

    .line 228
    .line 229
    .line 230
    invoke-interface {v5, v9}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 231
    .line 232
    .line 233
    move-result-object v5

    .line 234
    invoke-static {v5, v7}, Lix;->x(Lbb4;Lbo6;)Lbb4;

    .line 235
    .line 236
    .line 237
    move-result-object v9

    .line 238
    const/4 v10, 0x0

    .line 239
    invoke-virtual {v1, v10}, Lzi2;->r(Z)V

    .line 240
    .line 241
    .line 242
    goto :goto_3

    .line 243
    :cond_8
    move-object/from16 v24, v10

    .line 244
    .line 245
    const/4 v10, 0x0

    .line 246
    const v9, 0x485fae8c

    .line 247
    .line 248
    .line 249
    invoke-virtual {v1, v9}, Lzi2;->h0(I)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v1, v10}, Lzi2;->r(Z)V

    .line 253
    .line 254
    .line 255
    invoke-static {v4, v5, v6, v7}, Lbr7;->B(Lbb4;JLbo6;)Lbb4;

    .line 256
    .line 257
    .line 258
    move-result-object v5

    .line 259
    invoke-static/range {v16 .. v16}, Lhc2;->d(Z)J

    .line 260
    .line 261
    .line 262
    move-result-wide v9

    .line 263
    new-instance v6, Lcx6;

    .line 264
    .line 265
    invoke-direct {v6, v9, v10}, Lcx6;-><init>(J)V

    .line 266
    .line 267
    .line 268
    new-instance v9, Lq50;

    .line 269
    .line 270
    const/high16 v10, 0x3f800000    # 1.0f

    .line 271
    .line 272
    invoke-direct {v9, v10, v6, v7}, Lq50;-><init>(FLcx6;Lbo6;)V

    .line 273
    .line 274
    .line 275
    invoke-interface {v5, v9}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 276
    .line 277
    .line 278
    move-result-object v5

    .line 279
    invoke-static {v5, v7}, Lix;->x(Lbb4;Lbo6;)Lbb4;

    .line 280
    .line 281
    .line 282
    move-result-object v9

    .line 283
    :goto_3
    invoke-interface {v8, v9}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 284
    .line 285
    .line 286
    move-result-object v5

    .line 287
    iget-object v6, v0, Lac2;->r:Lta3;

    .line 288
    .line 289
    if-eqz v6, :cond_9

    .line 290
    .line 291
    iget-object v8, v6, Lta3;->i:Lbb4;

    .line 292
    .line 293
    iget-object v9, v6, Lta3;->j:Lbb4;

    .line 294
    .line 295
    invoke-interface {v8, v9}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 296
    .line 297
    .line 298
    move-result-object v8

    .line 299
    goto :goto_4

    .line 300
    :cond_9
    move-object v8, v4

    .line 301
    :goto_4
    invoke-interface {v5, v8}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 302
    .line 303
    .line 304
    move-result-object v5

    .line 305
    move-object v8, v12

    .line 306
    iget-object v12, v0, Lac2;->s:Lxl1;

    .line 307
    .line 308
    iget-object v9, v12, Lxl1;->v:Lbb4;

    .line 309
    .line 310
    invoke-interface {v5, v9}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 311
    .line 312
    .line 313
    move-result-object v5

    .line 314
    iget v13, v0, Lac2;->t:F

    .line 315
    .line 316
    const/high16 v9, 0x41000000    # 8.0f

    .line 317
    .line 318
    add-float v10, v13, v9

    .line 319
    .line 320
    const/4 v9, 0x0

    .line 321
    add-float/2addr v10, v9

    .line 322
    invoke-static {v5, v10}, Lxt6;->f(Lbb4;F)Lbb4;

    .line 323
    .line 324
    .line 325
    move-result-object v5

    .line 326
    const/high16 v10, 0x40800000    # 4.0f

    .line 327
    .line 328
    invoke-static {v5, v10}, Lah0;->E(Lbb4;F)Lbb4;

    .line 329
    .line 330
    .line 331
    move-result-object v5

    .line 332
    move/from16 v25, v9

    .line 333
    .line 334
    sget-object v9, Ly6;->t:La40;

    .line 335
    .line 336
    sget-object v10, Lob3;->e:Lkw;

    .line 337
    .line 338
    move-object/from16 v19, v6

    .line 339
    .line 340
    const/16 v6, 0x30

    .line 341
    .line 342
    invoke-static {v10, v9, v1, v6}, Ln26;->a(Lmw;La40;Lzi2;I)Lo26;

    .line 343
    .line 344
    .line 345
    move-result-object v9

    .line 346
    move-object v10, v7

    .line 347
    iget-wide v6, v1, Lzi2;->U:J

    .line 348
    .line 349
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 350
    .line 351
    .line 352
    move-result v6

    .line 353
    invoke-virtual {v1}, Lzi2;->m()Lla5;

    .line 354
    .line 355
    .line 356
    move-result-object v7

    .line 357
    invoke-static {v1, v5}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 358
    .line 359
    .line 360
    move-result-object v5

    .line 361
    sget-object v16, Ls41;->d:Ly6;

    .line 362
    .line 363
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 364
    .line 365
    .line 366
    invoke-virtual {v1}, Lzi2;->k0()V

    .line 367
    .line 368
    .line 369
    move/from16 v16, v6

    .line 370
    .line 371
    iget-boolean v6, v1, Lzi2;->T:Z

    .line 372
    .line 373
    move/from16 v17, v6

    .line 374
    .line 375
    sget-object v6, Lzi3;->Z:Lu43;

    .line 376
    .line 377
    if-eqz v17, :cond_a

    .line 378
    .line 379
    invoke-virtual {v1, v6}, Lzi2;->l(Llh2;)V

    .line 380
    .line 381
    .line 382
    :goto_5
    move-object/from16 v17, v8

    .line 383
    .line 384
    goto :goto_6

    .line 385
    :cond_a
    invoke-virtual {v1}, Lzi2;->t0()V

    .line 386
    .line 387
    .line 388
    goto :goto_5

    .line 389
    :goto_6
    sget-object v8, Ly6;->T:Lx31;

    .line 390
    .line 391
    invoke-static {v8, v1, v9}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 392
    .line 393
    .line 394
    sget-object v9, Ly6;->S:Lx31;

    .line 395
    .line 396
    invoke-static {v9, v1, v7}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 397
    .line 398
    .line 399
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 400
    .line 401
    .line 402
    move-result-object v7

    .line 403
    move-object/from16 v26, v10

    .line 404
    .line 405
    sget-object v10, Ly6;->U:Lx31;

    .line 406
    .line 407
    invoke-static {v10, v1, v7}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 408
    .line 409
    .line 410
    invoke-static {v1}, Lfa7;->k(Lzi2;)V

    .line 411
    .line 412
    .line 413
    sget-object v7, Ly6;->R:Lx31;

    .line 414
    .line 415
    invoke-static {v7, v1, v5}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 416
    .line 417
    .line 418
    const/4 v5, 0x6

    .line 419
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 420
    .line 421
    .line 422
    move-result-object v5

    .line 423
    move/from16 v20, v13

    .line 424
    .line 425
    iget-object v13, v0, Lac2;->u:Ls21;

    .line 426
    .line 427
    move-object/from16 v27, v14

    .line 428
    .line 429
    sget-object v14, Lq26;->a:Lq26;

    .line 430
    .line 431
    invoke-virtual {v13, v14, v1, v5}, Ls21;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    const/4 v5, 0x1

    .line 435
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 436
    .line 437
    .line 438
    move-object v5, v9

    .line 439
    move-object/from16 v28, v10

    .line 440
    .line 441
    iget-wide v9, v0, Lac2;->w:J

    .line 442
    .line 443
    if-eqz v17, :cond_c

    .line 444
    .line 445
    iget-object v14, v0, Lac2;->v:Lyh3;

    .line 446
    .line 447
    if-eqz v14, :cond_c

    .line 448
    .line 449
    move-object/from16 v29, v5

    .line 450
    .line 451
    const v5, 0x487029d1

    .line 452
    .line 453
    .line 454
    invoke-virtual {v1, v5}, Lzi2;->h0(I)V

    .line 455
    .line 456
    .line 457
    sget-object v5, Lhc2;->b:Lux1;

    .line 458
    .line 459
    invoke-virtual {v1, v12}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 460
    .line 461
    .line 462
    move-result v16

    .line 463
    move-object/from16 v21, v13

    .line 464
    .line 465
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 466
    .line 467
    .line 468
    move-result-object v13

    .line 469
    if-nez v16, :cond_b

    .line 470
    .line 471
    if-eq v13, v11, :cond_b

    .line 472
    .line 473
    move-object/from16 v16, v14

    .line 474
    .line 475
    goto :goto_7

    .line 476
    :cond_b
    new-instance v13, Lsl1;

    .line 477
    .line 478
    move-object/from16 v16, v14

    .line 479
    .line 480
    const/4 v14, 0x2

    .line 481
    invoke-direct {v13, v12, v14}, Lsl1;-><init>(Lxl1;B)V

    .line 482
    .line 483
    .line 484
    invoke-virtual {v1, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 485
    .line 486
    .line 487
    :goto_7
    check-cast v13, Llh2;

    .line 488
    .line 489
    invoke-virtual {v5, v13}, Lux1;->a(Ljava/lang/Object;)Lci5;

    .line 490
    .line 491
    .line 492
    move-result-object v5

    .line 493
    new-instance v13, Lgy0;

    .line 494
    .line 495
    invoke-direct {v13, v9, v10}, Lgy0;-><init>(J)V

    .line 496
    .line 497
    .line 498
    invoke-virtual {v3, v13}, Lux1;->a(Ljava/lang/Object;)Lci5;

    .line 499
    .line 500
    .line 501
    move-result-object v13

    .line 502
    filled-new-array {v5, v13}, [Lci5;

    .line 503
    .line 504
    .line 505
    move-result-object v5

    .line 506
    move-object/from16 v17, v15

    .line 507
    .line 508
    new-instance v15, Lfc2;

    .line 509
    .line 510
    iget-object v13, v0, Lac2;->D:Lbb4;

    .line 511
    .line 512
    move-object/from16 v18, v13

    .line 513
    .line 514
    invoke-direct/range {v15 .. v21}, Lfc2;-><init>(Lyh3;Lmz6;Lbb4;Lta3;FLs21;)V

    .line 515
    .line 516
    .line 517
    move-object/from16 v13, v17

    .line 518
    .line 519
    const v14, 0x478d2231

    .line 520
    .line 521
    .line 522
    invoke-static {v14, v15, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 523
    .line 524
    .line 525
    move-result-object v14

    .line 526
    const/16 v15, 0x30

    .line 527
    .line 528
    invoke-static {v5, v14, v1, v15}, Luu;->j([Lci5;Lai2;Lzi2;I)V

    .line 529
    .line 530
    .line 531
    const/4 v5, 0x0

    .line 532
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 533
    .line 534
    .line 535
    goto :goto_8

    .line 536
    :cond_c
    move-object/from16 v29, v5

    .line 537
    .line 538
    move-object/from16 v21, v13

    .line 539
    .line 540
    move-object v13, v15

    .line 541
    const/4 v5, 0x0

    .line 542
    const v14, 0x487ec876

    .line 543
    .line 544
    .line 545
    invoke-virtual {v1, v14}, Lzi2;->h0(I)V

    .line 546
    .line 547
    .line 548
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 549
    .line 550
    .line 551
    :goto_8
    invoke-virtual/range {v27 .. v27}, Lv75;->h()F

    .line 552
    .line 553
    .line 554
    move-result v5

    .line 555
    cmpl-float v5, v5, v25

    .line 556
    .line 557
    if-lez v5, :cond_13

    .line 558
    .line 559
    const v5, 0x4880b686

    .line 560
    .line 561
    .line 562
    invoke-virtual {v1, v5}, Lzi2;->h0(I)V

    .line 563
    .line 564
    .line 565
    invoke-virtual/range {v27 .. v27}, Lv75;->h()F

    .line 566
    .line 567
    .line 568
    move-result v5

    .line 569
    invoke-interface {v2, v5}, Lkp1;->p1(F)F

    .line 570
    .line 571
    .line 572
    move-result v5

    .line 573
    invoke-virtual {v1, v12}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 574
    .line 575
    .line 576
    move-result v14

    .line 577
    iget-boolean v15, v0, Lac2;->x:Z

    .line 578
    .line 579
    invoke-virtual {v1, v15}, Lzi2;->h(Z)Z

    .line 580
    .line 581
    .line 582
    move-result v16

    .line 583
    or-int v14, v14, v16

    .line 584
    .line 585
    invoke-virtual {v1, v13}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 586
    .line 587
    .line 588
    move-result v16

    .line 589
    or-int v14, v14, v16

    .line 590
    .line 591
    move-object/from16 v16, v12

    .line 592
    .line 593
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 594
    .line 595
    .line 596
    move-result-object v12

    .line 597
    if-nez v14, :cond_d

    .line 598
    .line 599
    if-eq v12, v11, :cond_d

    .line 600
    .line 601
    move-object/from16 v17, v3

    .line 602
    .line 603
    move-wide/from16 v18, v9

    .line 604
    .line 605
    move-object v9, v11

    .line 606
    move v13, v15

    .line 607
    move-object/from16 v14, v16

    .line 608
    .line 609
    move/from16 v3, v20

    .line 610
    .line 611
    goto :goto_9

    .line 612
    :cond_d
    move-object v12, v11

    .line 613
    new-instance v11, Lge;

    .line 614
    .line 615
    move-object/from16 v14, v16

    .line 616
    .line 617
    const/16 v16, 0x3

    .line 618
    .line 619
    move/from16 v17, v15

    .line 620
    .line 621
    move-object v15, v13

    .line 622
    move/from16 v13, v17

    .line 623
    .line 624
    move-object/from16 v17, v3

    .line 625
    .line 626
    move-wide/from16 v18, v9

    .line 627
    .line 628
    move-object v9, v12

    .line 629
    move-object v12, v14

    .line 630
    move/from16 v3, v20

    .line 631
    .line 632
    move-object/from16 v14, v27

    .line 633
    .line 634
    invoke-direct/range {v11 .. v16}, Lge;-><init>(Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;B)V

    .line 635
    .line 636
    .line 637
    move-object v14, v12

    .line 638
    invoke-virtual {v1, v11}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 639
    .line 640
    .line 641
    move-object v12, v11

    .line 642
    :goto_9
    check-cast v12, Lwh2;

    .line 643
    .line 644
    iget-object v10, v0, Lac2;->y:Lr01;

    .line 645
    .line 646
    if-eqz v10, :cond_10

    .line 647
    .line 648
    const v2, 0x48867c3b

    .line 649
    .line 650
    .line 651
    invoke-virtual {v1, v2}, Lzi2;->h0(I)V

    .line 652
    .line 653
    .line 654
    move/from16 v2, v25

    .line 655
    .line 656
    const/4 v6, 0x2

    .line 657
    const/high16 v7, 0x40800000    # 4.0f

    .line 658
    .line 659
    invoke-static {v4, v7, v2, v6}, Lah0;->G(Lbb4;FFI)Lbb4;

    .line 660
    .line 661
    .line 662
    move-result-object v2

    .line 663
    invoke-static {v2, v12}, Lkb;->H(Lbb4;Lwh2;)Lbb4;

    .line 664
    .line 665
    .line 666
    move-result-object v2

    .line 667
    iget-object v0, v0, Lac2;->z:Lbb4;

    .line 668
    .line 669
    invoke-interface {v2, v0}, Lbb4;->b0(Lbb4;)Lbb4;

    .line 670
    .line 671
    .line 672
    move-result-object v0

    .line 673
    invoke-virtual {v1, v14}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 674
    .line 675
    .line 676
    move-result v2

    .line 677
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 678
    .line 679
    .line 680
    move-result-object v4

    .line 681
    if-nez v2, :cond_e

    .line 682
    .line 683
    if-ne v4, v9, :cond_f

    .line 684
    .line 685
    :cond_e
    new-instance v4, Lsl1;

    .line 686
    .line 687
    const/4 v2, 0x3

    .line 688
    invoke-direct {v4, v14, v2}, Lsl1;-><init>(Lxl1;B)V

    .line 689
    .line 690
    .line 691
    invoke-virtual {v1, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 692
    .line 693
    .line 694
    :cond_f
    check-cast v4, Llh2;

    .line 695
    .line 696
    move-object/from16 v10, v26

    .line 697
    .line 698
    invoke-static {v0, v10, v4}, Lz73;->a(Lbb4;Lbo6;Llh2;)Lbb4;

    .line 699
    .line 700
    .line 701
    move-result-object v0

    .line 702
    invoke-static {v0, v3}, Lxt6;->f(Lbb4;F)Lbb4;

    .line 703
    .line 704
    .line 705
    move-result-object v0

    .line 706
    invoke-static {v0, v5}, Lxt6;->q(Lbb4;F)Lbb4;

    .line 707
    .line 708
    .line 709
    move-result-object v0

    .line 710
    const/4 v5, 0x0

    .line 711
    invoke-static {v0, v1, v5}, Lzc0;->a(Lbb4;Lzi2;I)V

    .line 712
    .line 713
    .line 714
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 715
    .line 716
    .line 717
    goto/16 :goto_b

    .line 718
    .line 719
    :cond_10
    move-object/from16 v10, v26

    .line 720
    .line 721
    const v9, 0x489294d7

    .line 722
    .line 723
    .line 724
    invoke-virtual {v1, v9}, Lzi2;->h0(I)V

    .line 725
    .line 726
    .line 727
    invoke-virtual/range {v24 .. v24}, Lv75;->h()F

    .line 728
    .line 729
    .line 730
    move-result v9

    .line 731
    const/high16 v11, 0x41000000    # 8.0f

    .line 732
    .line 733
    invoke-interface {v2, v11}, Lkp1;->L(F)F

    .line 734
    .line 735
    .line 736
    move-result v11

    .line 737
    sub-float/2addr v9, v11

    .line 738
    const/4 v11, 0x0

    .line 739
    cmpg-float v15, v9, v11

    .line 740
    .line 741
    if-gez v15, :cond_11

    .line 742
    .line 743
    move v9, v11

    .line 744
    :cond_11
    invoke-interface {v2, v9}, Lkp1;->p1(F)F

    .line 745
    .line 746
    .line 747
    move-result v2

    .line 748
    const/4 v9, 0x2

    .line 749
    const/high16 v15, 0x40800000    # 4.0f

    .line 750
    .line 751
    invoke-static {v4, v15, v11, v9}, Lah0;->G(Lbb4;FFI)Lbb4;

    .line 752
    .line 753
    .line 754
    move-result-object v4

    .line 755
    invoke-static {v4, v12}, Lkb;->H(Lbb4;Lwh2;)Lbb4;

    .line 756
    .line 757
    .line 758
    move-result-object v4

    .line 759
    invoke-static {v4, v10}, Lix;->x(Lbb4;Lbo6;)Lbb4;

    .line 760
    .line 761
    .line 762
    move-result-object v4

    .line 763
    const v9, 0x3e19999a    # 0.15f

    .line 764
    .line 765
    .line 766
    iget-wide v11, v0, Lac2;->A:J

    .line 767
    .line 768
    invoke-static {v9, v11, v12}, Lgy0;->b(FJ)J

    .line 769
    .line 770
    .line 771
    move-result-wide v11

    .line 772
    invoke-static {v4, v11, v12, v10}, Lbr7;->B(Lbb4;JLbo6;)Lbb4;

    .line 773
    .line 774
    .line 775
    move-result-object v0

    .line 776
    invoke-static {v0, v3}, Lxt6;->f(Lbb4;F)Lbb4;

    .line 777
    .line 778
    .line 779
    move-result-object v0

    .line 780
    invoke-static {v0, v5}, Lxt6;->q(Lbb4;F)Lbb4;

    .line 781
    .line 782
    .line 783
    move-result-object v0

    .line 784
    sget-object v4, Ly6;->m:Lb40;

    .line 785
    .line 786
    const/4 v5, 0x0

    .line 787
    invoke-static {v4, v5}, Lzc0;->c(Lb40;Z)Lu14;

    .line 788
    .line 789
    .line 790
    move-result-object v4

    .line 791
    iget-wide v9, v1, Lzi2;->U:J

    .line 792
    .line 793
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 794
    .line 795
    .line 796
    move-result v5

    .line 797
    invoke-virtual {v1}, Lzi2;->m()Lla5;

    .line 798
    .line 799
    .line 800
    move-result-object v9

    .line 801
    invoke-static {v1, v0}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 802
    .line 803
    .line 804
    move-result-object v0

    .line 805
    invoke-virtual {v1}, Lzi2;->k0()V

    .line 806
    .line 807
    .line 808
    iget-boolean v10, v1, Lzi2;->T:Z

    .line 809
    .line 810
    if-eqz v10, :cond_12

    .line 811
    .line 812
    invoke-virtual {v1, v6}, Lzi2;->l(Llh2;)V

    .line 813
    .line 814
    .line 815
    goto :goto_a

    .line 816
    :cond_12
    invoke-virtual {v1}, Lzi2;->t0()V

    .line 817
    .line 818
    .line 819
    :goto_a
    invoke-static {v8, v1, v4}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 820
    .line 821
    .line 822
    move-object/from16 v4, v29

    .line 823
    .line 824
    invoke-static {v4, v1, v9}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 825
    .line 826
    .line 827
    move-object/from16 v4, v28

    .line 828
    .line 829
    invoke-static {v5, v1, v4, v1}, Lp92;->w(ILzi2;Lx31;Lzi2;)V

    .line 830
    .line 831
    .line 832
    invoke-static {v7, v1, v0}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 833
    .line 834
    .line 835
    new-instance v0, Lgy0;

    .line 836
    .line 837
    move-wide/from16 v4, v18

    .line 838
    .line 839
    invoke-direct {v0, v4, v5}, Lgy0;-><init>(J)V

    .line 840
    .line 841
    .line 842
    move-object/from16 v4, v17

    .line 843
    .line 844
    invoke-virtual {v4, v0}, Lux1;->a(Ljava/lang/Object;)Lci5;

    .line 845
    .line 846
    .line 847
    move-result-object v0

    .line 848
    new-instance v11, Lgc2;

    .line 849
    .line 850
    move v12, v2

    .line 851
    move v15, v13

    .line 852
    move-object/from16 v16, v21

    .line 853
    .line 854
    move-object/from16 v17, v27

    .line 855
    .line 856
    move v13, v3

    .line 857
    invoke-direct/range {v11 .. v17}, Lgc2;-><init>(FFLxl1;ZLs21;Lv75;)V

    .line 858
    .line 859
    .line 860
    const v2, 0x52fdfa70

    .line 861
    .line 862
    .line 863
    invoke-static {v2, v11, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 864
    .line 865
    .line 866
    move-result-object v2

    .line 867
    const/16 v3, 0x38

    .line 868
    .line 869
    invoke-static {v0, v2, v1, v3}, Luu;->i(Lci5;Lai2;Lzi2;I)V

    .line 870
    .line 871
    .line 872
    const/4 v5, 0x1

    .line 873
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 874
    .line 875
    .line 876
    const/4 v5, 0x0

    .line 877
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 878
    .line 879
    .line 880
    :goto_b
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 881
    .line 882
    .line 883
    goto :goto_c

    .line 884
    :cond_13
    const/4 v5, 0x0

    .line 885
    const v0, 0x48ac1e16

    .line 886
    .line 887
    .line 888
    invoke-virtual {v1, v0}, Lzi2;->h0(I)V

    .line 889
    .line 890
    .line 891
    invoke-virtual {v1, v5}, Lzi2;->r(Z)V

    .line 892
    .line 893
    .line 894
    goto :goto_c

    .line 895
    :cond_14
    invoke-virtual {v1}, Lzi2;->b0()V

    .line 896
    .line 897
    .line 898
    :goto_c
    sget-object v0, Lst7;->a:Lst7;

    .line 899
    .line 900
    return-object v0
.end method
