.class public final synthetic La60;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:I

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/util/List;)V
    .locals 1

    .line 12
    const/4 v0, 0x0

    iput-byte v0, p0, La60;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La60;->j:Ljava/lang/Object;

    iput p1, p0, La60;->i:I

    return-void
.end method

.method public synthetic constructor <init>(ILs21;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, La60;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, La60;->i:I

    .line 8
    .line 9
    iput-object p2, p0, La60;->j:Ljava/lang/Object;

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La60;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x4

    .line 9
    const/4 v5, 0x1

    .line 10
    iget-object v6, v0, La60;->j:Ljava/lang/Object;

    .line 11
    .line 12
    iget v0, v0, La60;->i:I

    .line 13
    .line 14
    const/16 v7, 0x12

    .line 15
    .line 16
    const/4 v8, 0x2

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    check-cast v6, Ls21;

    .line 21
    .line 22
    move-object/from16 v1, p1

    .line 23
    .line 24
    check-cast v1, Lp01;

    .line 25
    .line 26
    move-object/from16 v9, p2

    .line 27
    .line 28
    check-cast v9, Lzi2;

    .line 29
    .line 30
    move-object/from16 v10, p3

    .line 31
    .line 32
    check-cast v10, Ljava/lang/Integer;

    .line 33
    .line 34
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 35
    .line 36
    .line 37
    move-result v10

    .line 38
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    and-int/lit8 v11, v10, 0x6

    .line 42
    .line 43
    if-nez v11, :cond_1

    .line 44
    .line 45
    invoke-virtual {v9, v1}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v11

    .line 49
    if-nez v11, :cond_0

    .line 50
    .line 51
    move v4, v8

    .line 52
    :cond_0
    or-int/2addr v10, v4

    .line 53
    :cond_1
    and-int/lit8 v4, v10, 0x13

    .line 54
    .line 55
    if-eq v4, v7, :cond_2

    .line 56
    .line 57
    move v3, v5

    .line 58
    :cond_2
    and-int/2addr v10, v5

    .line 59
    invoke-virtual {v9, v10, v3}, Lzi2;->Y(IZ)Z

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    if-eqz v3, :cond_3

    .line 64
    .line 65
    sget-object v3, Lr84;->b:Lux1;

    .line 66
    .line 67
    add-int/2addr v0, v5

    .line 68
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    invoke-virtual {v3, v0}, Lux1;->a(Ljava/lang/Object;)Lci5;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    new-instance v3, Lhg1;

    .line 77
    .line 78
    invoke-direct {v3, v6, v1, v7}, Lhg1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 79
    .line 80
    .line 81
    const v1, 0x474e5f8

    .line 82
    .line 83
    .line 84
    invoke-static {v1, v3, v9}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    const/16 v3, 0x38

    .line 89
    .line 90
    invoke-static {v0, v1, v9, v3}, Luu;->i(Lci5;Lai2;Lzi2;I)V

    .line 91
    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_3
    invoke-virtual {v9}, Lzi2;->b0()V

    .line 95
    .line 96
    .line 97
    :goto_0
    return-object v2

    .line 98
    :pswitch_0
    check-cast v6, Ljava/util/List;

    .line 99
    .line 100
    move-object/from16 v9, p1

    .line 101
    .line 102
    check-cast v9, Lp26;

    .line 103
    .line 104
    move-object/from16 v13, p2

    .line 105
    .line 106
    check-cast v13, Lzi2;

    .line 107
    .line 108
    move-object/from16 v1, p3

    .line 109
    .line 110
    check-cast v1, Ljava/lang/Integer;

    .line 111
    .line 112
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 113
    .line 114
    .line 115
    move-result v1

    .line 116
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    and-int/lit8 v10, v1, 0x6

    .line 120
    .line 121
    if-nez v10, :cond_5

    .line 122
    .line 123
    invoke-virtual {v13, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v10

    .line 127
    if-nez v10, :cond_4

    .line 128
    .line 129
    move v4, v8

    .line 130
    :cond_4
    or-int/2addr v1, v4

    .line 131
    :cond_5
    and-int/lit8 v4, v1, 0x13

    .line 132
    .line 133
    if-eq v4, v7, :cond_6

    .line 134
    .line 135
    move v4, v5

    .line 136
    goto :goto_1

    .line 137
    :cond_6
    move v4, v3

    .line 138
    :goto_1
    and-int/lit8 v7, v1, 0x1

    .line 139
    .line 140
    invoke-virtual {v13, v7, v4}, Lzi2;->Y(IZ)Z

    .line 141
    .line 142
    .line 143
    move-result v4

    .line 144
    if-eqz v4, :cond_9

    .line 145
    .line 146
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 147
    .line 148
    .line 149
    move-result-object v4

    .line 150
    move v10, v3

    .line 151
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 152
    .line 153
    .line 154
    move-result v6

    .line 155
    if-eqz v6, :cond_a

    .line 156
    .line 157
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v6

    .line 161
    add-int/lit8 v7, v10, 0x1

    .line 162
    .line 163
    if-ltz v10, :cond_8

    .line 164
    .line 165
    check-cast v6, Ls50;

    .line 166
    .line 167
    if-ne v0, v10, :cond_7

    .line 168
    .line 169
    move v11, v5

    .line 170
    goto :goto_3

    .line 171
    :cond_7
    move v11, v3

    .line 172
    :goto_3
    const/high16 v12, 0x42980000    # 76.0f

    .line 173
    .line 174
    const/4 v14, 0x0

    .line 175
    sget-object v15, Lya4;->h:Lya4;

    .line 176
    .line 177
    invoke-static {v15, v12, v14, v8}, Lxt6;->b(Lbb4;FFI)Lbb4;

    .line 178
    .line 179
    .line 180
    move-result-object v12

    .line 181
    new-instance v14, Lvm;

    .line 182
    .line 183
    invoke-direct {v14, v11, v6, v8}, Lvm;-><init>(ZLjava/lang/Object;B)V

    .line 184
    .line 185
    .line 186
    const v6, 0x193f5ef1

    .line 187
    .line 188
    .line 189
    invoke-static {v6, v14, v13}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 190
    .line 191
    .line 192
    move-result-object v6

    .line 193
    and-int/lit8 v11, v1, 0xe

    .line 194
    .line 195
    or-int/lit16 v14, v11, 0xd80

    .line 196
    .line 197
    move-object v11, v12

    .line 198
    move-object v12, v6

    .line 199
    invoke-static/range {v9 .. v14}, Lhc2;->b(Lp26;ILbb4;Ls21;Lzi2;I)V

    .line 200
    .line 201
    .line 202
    move v10, v7

    .line 203
    goto :goto_2

    .line 204
    :cond_8
    invoke-static {}, Lix;->x0()V

    .line 205
    .line 206
    .line 207
    const/4 v0, 0x0

    .line 208
    throw v0

    .line 209
    :cond_9
    invoke-virtual {v13}, Lzi2;->b0()V

    .line 210
    .line 211
    .line 212
    :cond_a
    return-object v2

    .line 213
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
.end method
