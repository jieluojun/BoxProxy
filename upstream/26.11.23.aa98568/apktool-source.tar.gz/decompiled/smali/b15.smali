.class public final Lb15;
.super Luk3;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final c:Lw16;

.field public final d:Lgd;


# direct methods
.method public constructor <init>(Lw16;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb15;->c:Lw16;

    .line 5
    .line 6
    invoke-static {p1}, Lrj3;->O(Lw16;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    invoke-static {}, Lid;->a()Lgd;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v0, p1}, Lgd;->c(Lgd;Lw16;)V

    .line 17
    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v0, 0x0

    .line 21
    :goto_0
    iput-object v0, p0, Lb15;->d:Lgd;

    .line 22
    .line 23
    return-void
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method


# virtual methods
.method public final G()Lyv5;
    .locals 4

    .line 1
    new-instance v0, Lyv5;

    .line 2
    .line 3
    iget-object p0, p0, Lb15;->c:Lw16;

    .line 4
    .line 5
    iget v1, p0, Lw16;->a:F

    .line 6
    .line 7
    iget v2, p0, Lw16;->b:F

    .line 8
    .line 9
    iget v3, p0, Lw16;->c:F

    .line 10
    .line 11
    iget p0, p0, Lw16;->d:F

    .line 12
    .line 13
    invoke-direct {v0, v1, v2, v3, p0}, Lyv5;-><init>(FFFF)V

    .line 14
    .line 15
    .line 16
    return-object v0
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lb15;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, Lb15;

    .line 8
    .line 9
    iget-object p1, p1, Lb15;->c:Lw16;

    .line 10
    .line 11
    iget-object p0, p0, Lb15;->c:Lw16;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lw16;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-nez p0, :cond_1

    .line 18
    .line 19
    :cond_0
    const/4 p0, 0x0

    .line 20
    return p0

    .line 21
    :cond_1
    const/4 p0, 0x1

    .line 22
    return p0
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lb15;->c:Lw16;

    .line 2
    .line 3
    invoke-virtual {p0}, Lw16;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
