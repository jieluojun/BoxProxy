.class public final Lai;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lu14;


# instance fields
.field public final a:Z

.field public final b:Llh2;

.field public final c:Llh2;

.field public final d:Ltx1;


# direct methods
.method public constructor <init>(ILlh2;Llh2;Ltx1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lai;->a:Z

    .line 5
    .line 6
    iput-object p2, p0, Lai;->b:Llh2;

    .line 7
    .line 8
    iput-object p3, p0, Lai;->c:Llh2;

    .line 9
    .line 10
    iput-object p4, p0, Lai;->d:Ltx1;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final b(Lgb3;Ljava/util/List;I)I
    .locals 7

    .line 1
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    move v2, v1

    .line 7
    :goto_0
    const-string v3, "Collection contains no element matching the predicate."

    .line 8
    .line 9
    if-ge v2, v0, :cond_4

    .line 10
    .line 11
    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    check-cast v4, Lp14;

    .line 16
    .line 17
    invoke-static {v4}, Lqj3;->D(Lp14;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    const-string v6, "icon"

    .line 22
    .line 23
    invoke-static {v5, v6}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    if-eqz v5, :cond_3

    .line 28
    .line 29
    invoke-interface {v4, p3}, Lp14;->h0(I)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    :goto_1
    if-ge v1, v2, :cond_2

    .line 38
    .line 39
    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    check-cast v4, Lp14;

    .line 44
    .line 45
    invoke-static {v4}, Lqj3;->D(Lp14;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    const-string v6, "label"

    .line 50
    .line 51
    invoke-static {v5, v6}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v5

    .line 55
    if-eqz v5, :cond_1

    .line 56
    .line 57
    invoke-interface {v4, p3}, Lp14;->h0(I)I

    .line 58
    .line 59
    .line 60
    move-result p2

    .line 61
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 62
    .line 63
    .line 64
    move-result-object p3

    .line 65
    iget-object v1, p0, Lai;->d:Ltx1;

    .line 66
    .line 67
    invoke-static {v1, p3}, Lah0;->z(Lm45;Lii3;)F

    .line 68
    .line 69
    .line 70
    move-result p3

    .line 71
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    invoke-static {v1, v2}, Lah0;->y(Lm45;Lii3;)F

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    add-float/2addr v1, p3

    .line 80
    invoke-interface {p1, v1}, Lkp1;->s0(F)I

    .line 81
    .line 82
    .line 83
    move-result p3

    .line 84
    iget-boolean p0, p0, Lai;->a:Z

    .line 85
    .line 86
    if-nez p0, :cond_0

    .line 87
    .line 88
    const/high16 p0, 0x42200000    # 40.0f

    .line 89
    .line 90
    invoke-interface {p1, p0}, Lkp1;->s0(F)I

    .line 91
    .line 92
    .line 93
    move-result p0

    .line 94
    add-int/2addr p0, p3

    .line 95
    add-int/2addr p0, v0

    .line 96
    invoke-static {p2, p0}, Ljava/lang/Math;->max(II)I

    .line 97
    .line 98
    .line 99
    move-result p0

    .line 100
    return p0

    .line 101
    :cond_0
    const/high16 p0, 0x41e00000    # 28.0f

    .line 102
    .line 103
    invoke-interface {p1, p0}, Lkp1;->s0(F)I

    .line 104
    .line 105
    .line 106
    move-result p0

    .line 107
    add-int/2addr p0, p3

    .line 108
    add-int/2addr v0, p2

    .line 109
    add-int/2addr v0, p0

    .line 110
    return v0

    .line 111
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 112
    .line 113
    goto :goto_1

    .line 114
    :cond_2
    invoke-static {v3}, Lp92;->B(Ljava/lang/String;)Lo11;

    .line 115
    .line 116
    .line 117
    move-result-object p0

    .line 118
    throw p0

    .line 119
    :cond_3
    add-int/lit8 v2, v2, 0x1

    .line 120
    .line 121
    goto :goto_0

    .line 122
    :cond_4
    invoke-static {v3}, Lp92;->B(Ljava/lang/String;)Lo11;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    throw p0
.end method

.method public final c(Ly14;Ljava/util/List;J)Lv14;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, Lai;->c:Llh2;

    .line 8
    .line 9
    invoke-interface {v3}, Llh2;->a()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    check-cast v3, Ljava/lang/Number;

    .line 14
    .line 15
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    iget-object v4, v0, Lai;->b:Llh2;

    .line 20
    .line 21
    invoke-interface {v4}, Llh2;->a()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    check-cast v5, Ljava/lang/Number;

    .line 26
    .line 27
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 28
    .line 29
    .line 30
    move-result v5

    .line 31
    const/4 v11, 0x0

    .line 32
    const/16 v12, 0xa

    .line 33
    .line 34
    const/4 v8, 0x0

    .line 35
    const/4 v9, 0x0

    .line 36
    const/4 v10, 0x0

    .line 37
    move-wide/from16 v6, p3

    .line 38
    .line 39
    invoke-static/range {v6 .. v12}, Ljb1;->b(JIIIII)J

    .line 40
    .line 41
    .line 42
    move-result-wide v6

    .line 43
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 44
    .line 45
    .line 46
    move-result v8

    .line 47
    const/4 v10, 0x0

    .line 48
    :goto_0
    const-string v11, "Collection contains no element matching the predicate."

    .line 49
    .line 50
    if-ge v10, v8, :cond_10

    .line 51
    .line 52
    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v12

    .line 56
    check-cast v12, Lp14;

    .line 57
    .line 58
    invoke-static {v12}, Ln14;->t(Lp14;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v13

    .line 62
    const-string v14, "icon"

    .line 63
    .line 64
    invoke-static {v13, v14}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v13

    .line 68
    if-eqz v13, :cond_f

    .line 69
    .line 70
    invoke-interface {v12, v6, v7}, Lp14;->e(J)Lfb5;

    .line 71
    .line 72
    .line 73
    move-result-object v8

    .line 74
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 75
    .line 76
    .line 77
    move-result v10

    .line 78
    const/4 v12, 0x0

    .line 79
    :goto_1
    if-ge v12, v10, :cond_e

    .line 80
    .line 81
    invoke-interface {v2, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v13

    .line 85
    check-cast v13, Lp14;

    .line 86
    .line 87
    invoke-static {v13}, Ln14;->t(Lp14;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v14

    .line 91
    const-string v15, "label"

    .line 92
    .line 93
    invoke-static {v14, v15}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v14

    .line 97
    if-eqz v14, :cond_d

    .line 98
    .line 99
    invoke-interface {v13, v6, v7}, Lp14;->e(J)Lfb5;

    .line 100
    .line 101
    .line 102
    move-result-object v10

    .line 103
    const/high16 v12, 0x3f800000    # 1.0f

    .line 104
    .line 105
    const/4 v13, 0x0

    .line 106
    iget-object v14, v0, Lai;->d:Ltx1;

    .line 107
    .line 108
    if-eqz v14, :cond_0

    .line 109
    .line 110
    invoke-static {v5, v13, v12}, Lej3;->u(FFF)F

    .line 111
    .line 112
    .line 113
    move-result v15

    .line 114
    iput v15, v14, Ltx1;->c:F

    .line 115
    .line 116
    :cond_0
    invoke-interface {v1}, Lgb3;->getLayoutDirection()Lii3;

    .line 117
    .line 118
    .line 119
    move-result-object v15

    .line 120
    invoke-static {v14, v15}, Lah0;->z(Lm45;Lii3;)F

    .line 121
    .line 122
    .line 123
    move-result v15

    .line 124
    move/from16 p3, v12

    .line 125
    .line 126
    invoke-interface {v1}, Lgb3;->getLayoutDirection()Lii3;

    .line 127
    .line 128
    .line 129
    move-result-object v12

    .line 130
    invoke-static {v14, v12}, Lah0;->y(Lm45;Lii3;)F

    .line 131
    .line 132
    .line 133
    move-result v12

    .line 134
    add-float/2addr v12, v15

    .line 135
    invoke-virtual {v14}, Ltx1;->d()F

    .line 136
    .line 137
    .line 138
    move-result v15

    .line 139
    invoke-virtual {v14}, Ltx1;->c()F

    .line 140
    .line 141
    .line 142
    move-result v16

    .line 143
    add-float v15, v16, v15

    .line 144
    .line 145
    move/from16 p4, v13

    .line 146
    .line 147
    iget v13, v8, Lfb5;->h:I

    .line 148
    .line 149
    iget v9, v8, Lfb5;->i:I

    .line 150
    .line 151
    move/from16 v17, v3

    .line 152
    .line 153
    iget v3, v10, Lfb5;->h:I

    .line 154
    .line 155
    add-int/2addr v3, v13

    .line 156
    move/from16 v18, v3

    .line 157
    .line 158
    const/high16 v3, 0x41000000    # 8.0f

    .line 159
    .line 160
    invoke-interface {v1, v3}, Lkp1;->s0(F)I

    .line 161
    .line 162
    .line 163
    move-result v19

    .line 164
    add-int v3, v19, v18

    .line 165
    .line 166
    move-object/from16 v18, v4

    .line 167
    .line 168
    iget v4, v8, Lfb5;->i:I

    .line 169
    .line 170
    move-object/from16 v19, v11

    .line 171
    .line 172
    iget v11, v10, Lfb5;->i:I

    .line 173
    .line 174
    invoke-static {v4, v11}, Ljava/lang/Math;->max(II)I

    .line 175
    .line 176
    .line 177
    move-result v4

    .line 178
    invoke-static {v5, v13, v3}, Lmk3;->a0(FII)I

    .line 179
    .line 180
    .line 181
    move-result v3

    .line 182
    invoke-interface {v1, v12}, Lkp1;->s0(F)I

    .line 183
    .line 184
    .line 185
    move-result v11

    .line 186
    add-int/2addr v11, v3

    .line 187
    int-to-float v3, v11

    .line 188
    mul-float v3, v3, v17

    .line 189
    .line 190
    invoke-static {v3}, Ln14;->M(F)I

    .line 191
    .line 192
    .line 193
    move-result v3

    .line 194
    invoke-static {v5, v9, v4}, Lmk3;->a0(FII)I

    .line 195
    .line 196
    .line 197
    move-result v4

    .line 198
    invoke-interface {v1, v15}, Lkp1;->s0(F)I

    .line 199
    .line 200
    .line 201
    move-result v5

    .line 202
    add-int/2addr v5, v4

    .line 203
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 204
    .line 205
    .line 206
    move-result v4

    .line 207
    const/4 v9, 0x0

    .line 208
    :goto_2
    if-ge v9, v4, :cond_c

    .line 209
    .line 210
    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object v12

    .line 214
    check-cast v12, Lp14;

    .line 215
    .line 216
    invoke-static {v12}, Ln14;->t(Lp14;)Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object v15

    .line 220
    move/from16 v17, v4

    .line 221
    .line 222
    const-string v4, "indicatorRipple"

    .line 223
    .line 224
    invoke-static {v15, v4}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 225
    .line 226
    .line 227
    move-result v4

    .line 228
    if-eqz v4, :cond_b

    .line 229
    .line 230
    if-ltz v11, :cond_1

    .line 231
    .line 232
    const/4 v9, 0x1

    .line 233
    goto :goto_3

    .line 234
    :cond_1
    const/4 v9, 0x0

    .line 235
    :goto_3
    if-ltz v5, :cond_2

    .line 236
    .line 237
    const/4 v15, 0x1

    .line 238
    goto :goto_4

    .line 239
    :cond_2
    const/4 v15, 0x0

    .line 240
    :goto_4
    and-int/2addr v9, v15

    .line 241
    const-string v15, ") must be >= 0"

    .line 242
    .line 243
    const-string v4, ") and height("

    .line 244
    .line 245
    move/from16 v21, v9

    .line 246
    .line 247
    const-string v9, "width("

    .line 248
    .line 249
    if-nez v21, :cond_3

    .line 250
    .line 251
    move/from16 v21, v13

    .line 252
    .line 253
    new-instance v13, Ljava/lang/StringBuilder;

    .line 254
    .line 255
    invoke-direct {v13, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 259
    .line 260
    .line 261
    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 262
    .line 263
    .line 264
    invoke-virtual {v13, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 268
    .line 269
    .line 270
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v13

    .line 274
    invoke-static {v13}, Lr73;->a(Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    :goto_5
    move-object/from16 v22, v14

    .line 278
    .line 279
    goto :goto_6

    .line 280
    :cond_3
    move/from16 v21, v13

    .line 281
    .line 282
    goto :goto_5

    .line 283
    :goto_6
    invoke-static {v11, v11, v5, v5}, Lkb1;->h(IIII)J

    .line 284
    .line 285
    .line 286
    move-result-wide v13

    .line 287
    invoke-static {v6, v7, v13, v14}, Lkb1;->e(JJ)J

    .line 288
    .line 289
    .line 290
    move-result-wide v13

    .line 291
    invoke-interface {v12, v13, v14}, Lp14;->e(J)Lfb5;

    .line 292
    .line 293
    .line 294
    move-result-object v11

    .line 295
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 296
    .line 297
    .line 298
    move-result v12

    .line 299
    const/4 v13, 0x0

    .line 300
    :goto_7
    if-ge v13, v12, :cond_a

    .line 301
    .line 302
    invoke-interface {v2, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v14

    .line 306
    check-cast v14, Lp14;

    .line 307
    .line 308
    invoke-static {v14}, Ln14;->t(Lp14;)Ljava/lang/Object;

    .line 309
    .line 310
    .line 311
    move-result-object v2

    .line 312
    move/from16 v23, v12

    .line 313
    .line 314
    const-string v12, "indicator"

    .line 315
    .line 316
    invoke-static {v2, v12}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 317
    .line 318
    .line 319
    move-result v2

    .line 320
    if-eqz v2, :cond_9

    .line 321
    .line 322
    if-ltz v3, :cond_4

    .line 323
    .line 324
    const/4 v2, 0x1

    .line 325
    goto :goto_8

    .line 326
    :cond_4
    const/4 v2, 0x0

    .line 327
    :goto_8
    if-ltz v5, :cond_5

    .line 328
    .line 329
    const/16 v17, 0x1

    .line 330
    .line 331
    goto :goto_9

    .line 332
    :cond_5
    const/16 v17, 0x0

    .line 333
    .line 334
    :goto_9
    and-int v2, v2, v17

    .line 335
    .line 336
    if-nez v2, :cond_6

    .line 337
    .line 338
    new-instance v2, Ljava/lang/StringBuilder;

    .line 339
    .line 340
    invoke-direct {v2, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 341
    .line 342
    .line 343
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 344
    .line 345
    .line 346
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 347
    .line 348
    .line 349
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 350
    .line 351
    .line 352
    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 353
    .line 354
    .line 355
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 356
    .line 357
    .line 358
    move-result-object v2

    .line 359
    invoke-static {v2}, Lr73;->a(Ljava/lang/String;)V

    .line 360
    .line 361
    .line 362
    :cond_6
    invoke-static {v3, v3, v5, v5}, Lkb1;->h(IIII)J

    .line 363
    .line 364
    .line 365
    move-result-wide v2

    .line 366
    invoke-static {v6, v7, v2, v3}, Lkb1;->e(JJ)J

    .line 367
    .line 368
    .line 369
    move-result-wide v2

    .line 370
    invoke-interface {v14, v2, v3}, Lp14;->e(J)Lfb5;

    .line 371
    .line 372
    .line 373
    move-result-object v15

    .line 374
    invoke-interface/range {v18 .. v18}, Llh2;->a()Ljava/lang/Object;

    .line 375
    .line 376
    .line 377
    move-result-object v2

    .line 378
    check-cast v2, Ljava/lang/Number;

    .line 379
    .line 380
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 381
    .line 382
    .line 383
    move-result v2

    .line 384
    iget v3, v10, Lfb5;->h:I

    .line 385
    .line 386
    const/high16 v4, 0x42200000    # 40.0f

    .line 387
    .line 388
    invoke-interface {v1, v4}, Lkp1;->s0(F)I

    .line 389
    .line 390
    .line 391
    move-result v5

    .line 392
    add-int v5, v5, v21

    .line 393
    .line 394
    invoke-interface {v1}, Lgb3;->getLayoutDirection()Lii3;

    .line 395
    .line 396
    .line 397
    move-result-object v9

    .line 398
    move-object/from16 v12, v22

    .line 399
    .line 400
    invoke-static {v12, v9}, Lah0;->y(Lm45;Lii3;)F

    .line 401
    .line 402
    .line 403
    move-result v9

    .line 404
    invoke-interface {v1}, Lgb3;->getLayoutDirection()Lii3;

    .line 405
    .line 406
    .line 407
    move-result-object v13

    .line 408
    invoke-static {v12, v13}, Lah0;->z(Lm45;Lii3;)F

    .line 409
    .line 410
    .line 411
    move-result v13

    .line 412
    add-float/2addr v13, v9

    .line 413
    invoke-interface {v1, v13}, Lkp1;->s0(F)I

    .line 414
    .line 415
    .line 416
    move-result v9

    .line 417
    add-int/2addr v9, v5

    .line 418
    invoke-static {v3, v9}, Ljava/lang/Math;->max(II)I

    .line 419
    .line 420
    .line 421
    move-result v3

    .line 422
    invoke-static {v3, v6, v7}, Lkb1;->g(IJ)I

    .line 423
    .line 424
    .line 425
    move-result v3

    .line 426
    iget v5, v11, Lfb5;->h:I

    .line 427
    .line 428
    const/high16 v9, 0x41a00000    # 20.0f

    .line 429
    .line 430
    invoke-interface {v1, v9}, Lkp1;->s0(F)I

    .line 431
    .line 432
    .line 433
    move-result v13

    .line 434
    add-int/2addr v13, v5

    .line 435
    invoke-static {v13, v6, v7}, Lkb1;->g(IJ)I

    .line 436
    .line 437
    .line 438
    move-result v5

    .line 439
    int-to-float v13, v3

    .line 440
    sub-int/2addr v5, v3

    .line 441
    int-to-float v3, v5

    .line 442
    mul-float/2addr v3, v2

    .line 443
    add-float/2addr v3, v13

    .line 444
    iget v5, v11, Lfb5;->i:I

    .line 445
    .line 446
    int-to-float v5, v5

    .line 447
    const/high16 v13, 0x40800000    # 4.0f

    .line 448
    .line 449
    invoke-interface {v1, v13}, Lkp1;->L(F)F

    .line 450
    .line 451
    .line 452
    move-result v14

    .line 453
    add-float/2addr v14, v5

    .line 454
    iget v5, v10, Lfb5;->i:I

    .line 455
    .line 456
    int-to-float v5, v5

    .line 457
    add-float/2addr v14, v5

    .line 458
    invoke-static {v14}, Ln14;->M(F)I

    .line 459
    .line 460
    .line 461
    move-result v5

    .line 462
    invoke-static {v5, v6, v7}, Lkb1;->f(IJ)I

    .line 463
    .line 464
    .line 465
    move-result v5

    .line 466
    iget v14, v11, Lfb5;->i:I

    .line 467
    .line 468
    invoke-static {v14, v6, v7}, Lkb1;->f(IJ)I

    .line 469
    .line 470
    .line 471
    move-result v6

    .line 472
    invoke-static {v2, v5, v6}, Lmk3;->a0(FII)I

    .line 473
    .line 474
    .line 475
    move-result v5

    .line 476
    invoke-interface {v1, v9}, Lkp1;->s0(F)I

    .line 477
    .line 478
    .line 479
    move-result v6

    .line 480
    invoke-interface {v1, v9}, Lkp1;->s0(F)I

    .line 481
    .line 482
    .line 483
    move-result v7

    .line 484
    int-to-float v7, v7

    .line 485
    add-float/2addr v7, v3

    .line 486
    iget v14, v11, Lfb5;->h:I

    .line 487
    .line 488
    int-to-float v14, v14

    .line 489
    sub-float/2addr v7, v14

    .line 490
    const/high16 v14, 0x40000000    # 2.0f

    .line 491
    .line 492
    div-float/2addr v7, v14

    .line 493
    invoke-static {v7}, Ln14;->M(F)I

    .line 494
    .line 495
    .line 496
    move-result v7

    .line 497
    invoke-static {v2, v6, v7}, Lmk3;->a0(FII)I

    .line 498
    .line 499
    .line 500
    move-result v24

    .line 501
    const/4 v6, 0x0

    .line 502
    invoke-interface {v1, v9}, Lkp1;->s0(F)I

    .line 503
    .line 504
    .line 505
    move-result v16

    .line 506
    invoke-interface {v1, v9}, Lkp1;->s0(F)I

    .line 507
    .line 508
    .line 509
    move-result v7

    .line 510
    invoke-interface {v1}, Lgb3;->getLayoutDirection()Lii3;

    .line 511
    .line 512
    .line 513
    move-result-object v14

    .line 514
    invoke-static {v12, v14}, Lah0;->z(Lm45;Lii3;)F

    .line 515
    .line 516
    .line 517
    move-result v14

    .line 518
    invoke-interface {v1, v14}, Lkp1;->s0(F)I

    .line 519
    .line 520
    .line 521
    move-result v14

    .line 522
    add-int v18, v14, v7

    .line 523
    .line 524
    invoke-virtual {v12}, Ltx1;->d()F

    .line 525
    .line 526
    .line 527
    move-result v7

    .line 528
    invoke-interface {v1, v7}, Lkp1;->s0(F)I

    .line 529
    .line 530
    .line 531
    move-result v7

    .line 532
    iget v14, v8, Lfb5;->i:I

    .line 533
    .line 534
    sub-int v14, v5, v14

    .line 535
    .line 536
    div-int/lit8 v14, v14, 0x2

    .line 537
    .line 538
    sub-int/2addr v14, v7

    .line 539
    invoke-static {v2, v6, v14}, Lmk3;->a0(FII)I

    .line 540
    .line 541
    .line 542
    move-result v6

    .line 543
    add-int v19, v6, v7

    .line 544
    .line 545
    invoke-interface {v1}, Lgb3;->getLayoutDirection()Lii3;

    .line 546
    .line 547
    .line 548
    move-result-object v6

    .line 549
    invoke-static {v12, v6}, Lah0;->z(Lm45;Lii3;)F

    .line 550
    .line 551
    .line 552
    move-result v6

    .line 553
    invoke-interface {v1}, Lgb3;->getLayoutDirection()Lii3;

    .line 554
    .line 555
    .line 556
    move-result-object v7

    .line 557
    invoke-static {v12, v7}, Lah0;->y(Lm45;Lii3;)F

    .line 558
    .line 559
    .line 560
    move-result v7

    .line 561
    add-float/2addr v7, v6

    .line 562
    iget v6, v8, Lfb5;->h:I

    .line 563
    .line 564
    add-float/2addr v7, v4

    .line 565
    invoke-interface {v1, v7}, Lkp1;->s0(F)I

    .line 566
    .line 567
    .line 568
    move-result v4

    .line 569
    add-int/2addr v4, v6

    .line 570
    iget v6, v10, Lfb5;->h:I

    .line 571
    .line 572
    sub-int/2addr v4, v6

    .line 573
    div-int/lit8 v4, v4, 0x2

    .line 574
    .line 575
    iget v6, v8, Lfb5;->i:I

    .line 576
    .line 577
    add-int v6, v19, v6

    .line 578
    .line 579
    invoke-virtual {v12}, Ltx1;->c()F

    .line 580
    .line 581
    .line 582
    move-result v7

    .line 583
    add-float/2addr v7, v13

    .line 584
    invoke-interface {v1, v7}, Lkp1;->s0(F)I

    .line 585
    .line 586
    .line 587
    move-result v7

    .line 588
    add-int/2addr v7, v6

    .line 589
    iget-boolean v0, v0, Lai;->a:Z

    .line 590
    .line 591
    if-nez v0, :cond_7

    .line 592
    .line 593
    cmpl-float v0, v2, p4

    .line 594
    .line 595
    if-lez v0, :cond_7

    .line 596
    .line 597
    move/from16 v13, p4

    .line 598
    .line 599
    goto :goto_a

    .line 600
    :cond_7
    invoke-interface {v1, v9}, Lkp1;->s0(F)I

    .line 601
    .line 602
    .line 603
    move-result v0

    .line 604
    int-to-float v0, v0

    .line 605
    sub-float v12, p3, v2

    .line 606
    .line 607
    mul-float v13, v12, v0

    .line 608
    .line 609
    :goto_a
    iget v0, v8, Lfb5;->h:I

    .line 610
    .line 611
    add-int v0, v18, v0

    .line 612
    .line 613
    const/high16 v14, 0x41000000    # 8.0f

    .line 614
    .line 615
    invoke-interface {v1, v14}, Lkp1;->s0(F)I

    .line 616
    .line 617
    .line 618
    move-result v6

    .line 619
    add-int/2addr v6, v0

    .line 620
    int-to-float v0, v6

    .line 621
    sub-float/2addr v0, v13

    .line 622
    iget v6, v10, Lfb5;->i:I

    .line 623
    .line 624
    sub-int v6, v5, v6

    .line 625
    .line 626
    div-int/lit8 v6, v6, 0x2

    .line 627
    .line 628
    const/high16 v9, 0x3f000000    # 0.5f

    .line 629
    .line 630
    cmpg-float v9, v2, v9

    .line 631
    .line 632
    if-gez v9, :cond_8

    .line 633
    .line 634
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 635
    .line 636
    .line 637
    move-result-object v0

    .line 638
    move/from16 v22, v7

    .line 639
    .line 640
    :goto_b
    move-object/from16 v21, v0

    .line 641
    .line 642
    goto :goto_c

    .line 643
    :cond_8
    mul-float/2addr v0, v2

    .line 644
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 645
    .line 646
    .line 647
    move-result-object v0

    .line 648
    move/from16 v22, v6

    .line 649
    .line 650
    goto :goto_b

    .line 651
    :goto_c
    invoke-static {v3}, Ln14;->M(F)I

    .line 652
    .line 653
    .line 654
    move-result v0

    .line 655
    new-instance v14, Lgj4;

    .line 656
    .line 657
    move/from16 v25, v2

    .line 658
    .line 659
    move-object/from16 v17, v8

    .line 660
    .line 661
    move-object/from16 v20, v10

    .line 662
    .line 663
    move-object/from16 v23, v11

    .line 664
    .line 665
    invoke-direct/range {v14 .. v25}, Lgj4;-><init>(Lfb5;ILfb5;IILfb5;Ljava/lang/Number;ILfb5;IF)V

    .line 666
    .line 667
    .line 668
    sget-object v2, Lp22;->h:Lp22;

    .line 669
    .line 670
    invoke-interface {v1, v0, v5, v2, v14}, Ly14;->P0(IILjava/util/Map;Lwh2;)Lv14;

    .line 671
    .line 672
    .line 673
    move-result-object v0

    .line 674
    return-object v0

    .line 675
    :cond_9
    move-object v2, v8

    .line 676
    add-int/lit8 v13, v13, 0x1

    .line 677
    .line 678
    move/from16 v12, v23

    .line 679
    .line 680
    move-object v8, v2

    .line 681
    move-object/from16 v2, p2

    .line 682
    .line 683
    goto/16 :goto_7

    .line 684
    .line 685
    :cond_a
    invoke-static/range {v19 .. v19}, Lp92;->B(Ljava/lang/String;)Lo11;

    .line 686
    .line 687
    .line 688
    move-result-object v0

    .line 689
    throw v0

    .line 690
    :cond_b
    move-object v12, v14

    .line 691
    add-int/lit8 v9, v9, 0x1

    .line 692
    .line 693
    move-object v14, v12

    .line 694
    move/from16 v4, v17

    .line 695
    .line 696
    move-object/from16 v2, p2

    .line 697
    .line 698
    goto/16 :goto_2

    .line 699
    .line 700
    :cond_c
    invoke-static/range {v19 .. v19}, Lp92;->B(Ljava/lang/String;)Lo11;

    .line 701
    .line 702
    .line 703
    move-result-object v0

    .line 704
    throw v0

    .line 705
    :cond_d
    add-int/lit8 v12, v12, 0x1

    .line 706
    .line 707
    move-object/from16 v2, p2

    .line 708
    .line 709
    goto/16 :goto_1

    .line 710
    .line 711
    :cond_e
    move-object/from16 v19, v11

    .line 712
    .line 713
    invoke-static/range {v19 .. v19}, Lp92;->B(Ljava/lang/String;)Lo11;

    .line 714
    .line 715
    .line 716
    move-result-object v0

    .line 717
    throw v0

    .line 718
    :cond_f
    add-int/lit8 v10, v10, 0x1

    .line 719
    .line 720
    move-object/from16 v2, p2

    .line 721
    .line 722
    goto/16 :goto_0

    .line 723
    .line 724
    :cond_10
    move-object/from16 v19, v11

    .line 725
    .line 726
    invoke-static/range {v19 .. v19}, Lp92;->B(Ljava/lang/String;)Lo11;

    .line 727
    .line 728
    .line 729
    move-result-object v0

    .line 730
    throw v0
.end method
