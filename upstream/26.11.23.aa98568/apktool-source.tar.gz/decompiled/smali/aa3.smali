.class public final synthetic Laa3;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic h:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Laa3;->h:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-byte p0, p0, Laa3;->h:B

    .line 2
    .line 3
    const/16 v0, 0x20

    .line 4
    .line 5
    const-wide v1, 0xffffffffL

    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    const/4 v3, 0x3

    .line 11
    const/4 v4, 0x0

    .line 12
    const/4 v5, 0x2

    .line 13
    const/4 v6, 0x0

    .line 14
    sget-object v7, Lst7;->a:Lst7;

    .line 15
    .line 16
    const/4 v8, 0x1

    .line 17
    packed-switch p0, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    check-cast p1, Lll6;

    .line 21
    .line 22
    invoke-static {p1, v3}, Ljl6;->k(Lll6;I)V

    .line 23
    .line 24
    .line 25
    return-object v7

    .line 26
    :pswitch_0
    check-cast p1, Ls34;

    .line 27
    .line 28
    iget-object p0, p1, Ls34;->a:Lt93;

    .line 29
    .line 30
    invoke-virtual {p0}, Lt93;->a()J

    .line 31
    .line 32
    .line 33
    move-result-wide v9

    .line 34
    and-long/2addr v9, v1

    .line 35
    long-to-int p0, v9

    .line 36
    iget-wide v9, p1, Ls34;->b:J

    .line 37
    .line 38
    and-long v11, v9, v1

    .line 39
    .line 40
    long-to-int v0, v11

    .line 41
    div-int/2addr v0, v5

    .line 42
    if-ge p0, v0, :cond_0

    .line 43
    .line 44
    sget-object p0, Lr34;->h:Lp18;

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_0
    sget-object p0, Lr34;->i:Lp18;

    .line 48
    .line 49
    :goto_0
    const/4 v0, 0x4

    .line 50
    new-array v0, v0, [Lq34;

    .line 51
    .line 52
    sget-object v4, Lr34;->e:Lx8;

    .line 53
    .line 54
    aput-object v4, v0, v6

    .line 55
    .line 56
    sget-object v4, Lr34;->f:Lx8;

    .line 57
    .line 58
    aput-object v4, v0, v8

    .line 59
    .line 60
    sget-object v4, Lr34;->g:Lx8;

    .line 61
    .line 62
    aput-object v4, v0, v5

    .line 63
    .line 64
    aput-object p0, v0, v3

    .line 65
    .line 66
    invoke-static {v0}, Lix;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    iget-object v0, p1, Ls34;->a:Lt93;

    .line 71
    .line 72
    iget-wide v3, p1, Ls34;->c:J

    .line 73
    .line 74
    and-long/2addr v3, v1

    .line 75
    long-to-int p1, v3

    .line 76
    new-instance v1, Lqd4;

    .line 77
    .line 78
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    invoke-direct {v1, v2}, Lqd4;-><init>(I)V

    .line 83
    .line 84
    .line 85
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 86
    .line 87
    .line 88
    move-result v2

    .line 89
    :goto_1
    if-ge v6, v2, :cond_1

    .line 90
    .line 91
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    check-cast v3, Lq34;

    .line 96
    .line 97
    invoke-interface {v3, v0, v9, v10, p1}, Lq34;->a(Lt93;JI)I

    .line 98
    .line 99
    .line 100
    move-result v3

    .line 101
    invoke-virtual {v1, v3}, Lqd4;->a(I)V

    .line 102
    .line 103
    .line 104
    add-int/lit8 v6, v6, 0x1

    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_1
    return-object v1

    .line 108
    :pswitch_1
    check-cast p1, Ls34;

    .line 109
    .line 110
    iget-object p0, p1, Ls34;->a:Lt93;

    .line 111
    .line 112
    invoke-virtual {p0}, Lt93;->a()J

    .line 113
    .line 114
    .line 115
    move-result-wide v1

    .line 116
    shr-long/2addr v1, v0

    .line 117
    long-to-int p0, v1

    .line 118
    iget-wide v1, p1, Ls34;->b:J

    .line 119
    .line 120
    shr-long/2addr v1, v0

    .line 121
    long-to-int v1, v1

    .line 122
    div-int/2addr v1, v5

    .line 123
    if-ge p0, v1, :cond_2

    .line 124
    .line 125
    sget-object p0, Lr34;->c:Lo18;

    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_2
    sget-object p0, Lr34;->d:Lo18;

    .line 129
    .line 130
    :goto_2
    new-array v1, v3, [Lp34;

    .line 131
    .line 132
    sget-object v2, Lr34;->a:Lw8;

    .line 133
    .line 134
    aput-object v2, v1, v6

    .line 135
    .line 136
    sget-object v2, Lr34;->b:Lw8;

    .line 137
    .line 138
    aput-object v2, v1, v8

    .line 139
    .line 140
    aput-object p0, v1, v5

    .line 141
    .line 142
    invoke-static {v1}, Lix;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 143
    .line 144
    .line 145
    move-result-object p0

    .line 146
    iget-object v8, p1, Ls34;->a:Lt93;

    .line 147
    .line 148
    iget-wide v9, p1, Ls34;->b:J

    .line 149
    .line 150
    iget-wide v1, p1, Ls34;->c:J

    .line 151
    .line 152
    shr-long/2addr v1, v0

    .line 153
    long-to-int v11, v1

    .line 154
    iget-object v12, p1, Ls34;->d:Lii3;

    .line 155
    .line 156
    new-instance p1, Lqd4;

    .line 157
    .line 158
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 159
    .line 160
    .line 161
    move-result v0

    .line 162
    invoke-direct {p1, v0}, Lqd4;-><init>(I)V

    .line 163
    .line 164
    .line 165
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 166
    .line 167
    .line 168
    move-result v0

    .line 169
    :goto_3
    if-ge v6, v0, :cond_3

    .line 170
    .line 171
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v1

    .line 175
    move-object v7, v1

    .line 176
    check-cast v7, Lp34;

    .line 177
    .line 178
    invoke-interface/range {v7 .. v12}, Lp34;->a(Lt93;JILii3;)I

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    invoke-virtual {p1, v1}, Lqd4;->a(I)V

    .line 183
    .line 184
    .line 185
    add-int/lit8 v6, v6, 0x1

    .line 186
    .line 187
    goto :goto_3

    .line 188
    :cond_3
    return-object p1

    .line 189
    :pswitch_2
    check-cast p1, Ljava/lang/Long;

    .line 190
    .line 191
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 192
    .line 193
    .line 194
    return-object v7

    .line 195
    :pswitch_3
    check-cast p1, Lgb5;

    .line 196
    .line 197
    invoke-virtual {p1}, Lgb5;->N()Z

    .line 198
    .line 199
    .line 200
    move-result p0

    .line 201
    if-eqz p0, :cond_4

    .line 202
    .line 203
    iget-object p0, p1, Lgb5;->j:Lt13;

    .line 204
    .line 205
    if-eqz p0, :cond_4

    .line 206
    .line 207
    iget-object p1, p1, Lgb5;->i:Lcx3;

    .line 208
    .line 209
    invoke-virtual {p1, p0}, Lcx3;->j1(Lt13;)V

    .line 210
    .line 211
    .line 212
    :cond_4
    return-object v7

    .line 213
    :pswitch_4
    move-object v1, p1

    .line 214
    check-cast v1, Lgb5;

    .line 215
    .line 216
    invoke-virtual {v1}, Lgb5;->N()Z

    .line 217
    .line 218
    .line 219
    move-result p0

    .line 220
    if-eqz p0, :cond_7

    .line 221
    .line 222
    iget-object v0, v1, Lgb5;->i:Lcx3;

    .line 223
    .line 224
    iget-boolean p0, v0, Lcx3;->v:Z

    .line 225
    .line 226
    if-nez p0, :cond_7

    .line 227
    .line 228
    iget-object p0, v1, Lgb5;->h:Lv14;

    .line 229
    .line 230
    invoke-interface {p0}, Lv14;->f()Lwh2;

    .line 231
    .line 232
    .line 233
    move-result-object p0

    .line 234
    iget-object p1, v1, Lgb5;->h:Lv14;

    .line 235
    .line 236
    invoke-interface {p1}, Lv14;->e()Lai2;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    if-eqz p1, :cond_5

    .line 241
    .line 242
    invoke-virtual {v0}, Lcx3;->i1()V

    .line 243
    .line 244
    .line 245
    goto :goto_4

    .line 246
    :cond_5
    if-nez p0, :cond_6

    .line 247
    .line 248
    iput-object v4, v0, Lcx3;->o:Lai2;

    .line 249
    .line 250
    iput-object v4, v0, Lcx3;->p:Lwh2;

    .line 251
    .line 252
    iput-object v4, v0, Lcx3;->n:Lwh2;

    .line 253
    .line 254
    invoke-virtual {v0}, Lcx3;->i1()V

    .line 255
    .line 256
    .line 257
    goto :goto_4

    .line 258
    :cond_6
    iput-object v4, v0, Lcx3;->o:Lai2;

    .line 259
    .line 260
    iput-object v4, v0, Lcx3;->p:Lwh2;

    .line 261
    .line 262
    const-wide v2, 0x7fffffff7fffffffL

    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    const-wide/16 v4, 0x0

    .line 268
    .line 269
    invoke-virtual/range {v0 .. v5}, Lcx3;->M0(Lgb5;JJ)V

    .line 270
    .line 271
    .line 272
    iput-object p0, v0, Lcx3;->n:Lwh2;

    .line 273
    .line 274
    :cond_7
    :goto_4
    return-object v7

    .line 275
    :pswitch_5
    check-cast p1, Ljava/lang/String;

    .line 276
    .line 277
    const-string p0, ".ru.log"

    .line 278
    .line 279
    invoke-static {p1, p0, v8}, Lm17;->c0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 280
    .line 281
    .line 282
    move-result p0

    .line 283
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 284
    .line 285
    .line 286
    move-result-object p0

    .line 287
    return-object p0

    .line 288
    :pswitch_6
    check-cast p1, Ljava/lang/String;

    .line 289
    .line 290
    const-string p0, ".zh-TW.log"

    .line 291
    .line 292
    invoke-static {p1, p0, v8}, Lm17;->c0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 293
    .line 294
    .line 295
    move-result p0

    .line 296
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 297
    .line 298
    .line 299
    move-result-object p0

    .line 300
    return-object p0

    .line 301
    :pswitch_7
    check-cast p1, Ljava/lang/String;

    .line 302
    .line 303
    const-string p0, ".zh-CN.log"

    .line 304
    .line 305
    invoke-static {p1, p0, v8}, Lm17;->c0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 306
    .line 307
    .line 308
    move-result p0

    .line 309
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 310
    .line 311
    .line 312
    move-result-object p0

    .line 313
    return-object p0

    .line 314
    :pswitch_8
    check-cast p1, Ljava/lang/String;

    .line 315
    .line 316
    const-string p0, ".en.log"

    .line 317
    .line 318
    invoke-static {p1, p0, v8}, Lm17;->c0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 319
    .line 320
    .line 321
    move-result p0

    .line 322
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 323
    .line 324
    .line 325
    move-result-object p0

    .line 326
    return-object p0

    .line 327
    :pswitch_9
    check-cast p1, Ljava/lang/String;

    .line 328
    .line 329
    invoke-static {p1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 330
    .line 331
    .line 332
    move-result p0

    .line 333
    xor-int/2addr p0, v8

    .line 334
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 335
    .line 336
    .line 337
    move-result-object p0

    .line 338
    return-object p0

    .line 339
    :pswitch_a
    check-cast p1, Ljava/lang/String;

    .line 340
    .line 341
    invoke-static {p1}, Lf17;->Z0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 342
    .line 343
    .line 344
    move-result-object p0

    .line 345
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 346
    .line 347
    .line 348
    move-result-object p0

    .line 349
    return-object p0

    .line 350
    :pswitch_b
    check-cast p1, Ljava/lang/String;

    .line 351
    .line 352
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 353
    .line 354
    .line 355
    return-object v7

    .line 356
    :pswitch_c
    check-cast p1, Ljava/lang/String;

    .line 357
    .line 358
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 359
    .line 360
    .line 361
    invoke-static {p1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 362
    .line 363
    .line 364
    move-result p0

    .line 365
    xor-int/2addr p0, v8

    .line 366
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 367
    .line 368
    .line 369
    move-result-object p0

    .line 370
    return-object p0

    .line 371
    :pswitch_d
    check-cast p1, Ljava/lang/String;

    .line 372
    .line 373
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 374
    .line 375
    .line 376
    invoke-static {p1}, Lf17;->b1(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 377
    .line 378
    .line 379
    move-result-object p0

    .line 380
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 381
    .line 382
    .line 383
    move-result-object p0

    .line 384
    return-object p0

    .line 385
    :pswitch_e
    check-cast p1, Lla5;

    .line 386
    .line 387
    sget-object p0, Llb;->b:La61;

    .line 388
    .line 389
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 390
    .line 391
    .line 392
    invoke-static {p1, p0}, Ldv;->T(Lla5;Lzh5;)Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    move-result-object p0

    .line 396
    check-cast p0, Landroid/content/Context;

    .line 397
    .line 398
    :goto_5
    instance-of p1, p0, Landroid/content/ContextWrapper;

    .line 399
    .line 400
    if-eqz p1, :cond_9

    .line 401
    .line 402
    instance-of p1, p0, Landroid/app/Activity;

    .line 403
    .line 404
    if-eqz p1, :cond_8

    .line 405
    .line 406
    move-object v4, p0

    .line 407
    goto :goto_6

    .line 408
    :cond_8
    check-cast p0, Landroid/content/ContextWrapper;

    .line 409
    .line 410
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 411
    .line 412
    .line 413
    move-result-object p0

    .line 414
    goto :goto_5

    .line 415
    :cond_9
    :goto_6
    check-cast v4, Landroid/app/Activity;

    .line 416
    .line 417
    return-object v4

    .line 418
    :pswitch_f
    check-cast p1, Lll6;

    .line 419
    .line 420
    return-object v7

    .line 421
    :pswitch_10
    check-cast p1, Lkr3;

    .line 422
    .line 423
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 424
    .line 425
    .line 426
    new-instance p0, Ljava/lang/StringBuilder;

    .line 427
    .line 428
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 429
    .line 430
    .line 431
    iget-object v0, p1, Lkr3;->c:Lnt0;

    .line 432
    .line 433
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 434
    .line 435
    .line 436
    const/16 v0, 0x3d

    .line 437
    .line 438
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 439
    .line 440
    .line 441
    iget-object p1, p1, Lkr3;->d:Luj2;

    .line 442
    .line 443
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 444
    .line 445
    .line 446
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 447
    .line 448
    .line 449
    move-result-object p0

    .line 450
    return-object p0

    .line 451
    :pswitch_11
    check-cast p1, Lkr3;

    .line 452
    .line 453
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 454
    .line 455
    .line 456
    iget-object p0, p1, Lkr3;->e:Ly87;

    .line 457
    .line 458
    instance-of p1, p0, Lkr3;

    .line 459
    .line 460
    if-eqz p1, :cond_a

    .line 461
    .line 462
    move-object v4, p0

    .line 463
    check-cast v4, Lkr3;

    .line 464
    .line 465
    :cond_a
    return-object v4

    .line 466
    :pswitch_12
    check-cast p1, Lmd4;

    .line 467
    .line 468
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 469
    .line 470
    .line 471
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 472
    .line 473
    .line 474
    move-result-object p0

    .line 475
    return-object p0

    .line 476
    :pswitch_13
    check-cast p1, Ljava/util/List;

    .line 477
    .line 478
    new-instance p0, Ljn3;

    .line 479
    .line 480
    invoke-interface {p1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 481
    .line 482
    .line 483
    move-result-object v0

    .line 484
    check-cast v0, Ljava/lang/Number;

    .line 485
    .line 486
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 487
    .line 488
    .line 489
    move-result v0

    .line 490
    invoke-interface {p1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 491
    .line 492
    .line 493
    move-result-object p1

    .line 494
    check-cast p1, Ljava/lang/Number;

    .line 495
    .line 496
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 497
    .line 498
    .line 499
    move-result p1

    .line 500
    invoke-direct {p0, v0, p1}, Ljn3;-><init>(II)V

    .line 501
    .line 502
    .line 503
    return-object p0

    .line 504
    :pswitch_14
    check-cast p1, Ljava/lang/Integer;

    .line 505
    .line 506
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 507
    .line 508
    .line 509
    return-object v4

    .line 510
    :pswitch_15
    check-cast p1, Ljava/lang/Integer;

    .line 511
    .line 512
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 513
    .line 514
    .line 515
    const/4 p0, -0x1

    .line 516
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 517
    .line 518
    .line 519
    move-result-object p0

    .line 520
    return-object p0

    .line 521
    :pswitch_16
    check-cast p1, Ljava/lang/Integer;

    .line 522
    .line 523
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 524
    .line 525
    .line 526
    sget-object p0, Lo22;->h:Lo22;

    .line 527
    .line 528
    return-object p0

    .line 529
    :pswitch_17
    check-cast p1, Ljava/util/List;

    .line 530
    .line 531
    new-instance p0, Lbl3;

    .line 532
    .line 533
    invoke-interface {p1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 534
    .line 535
    .line 536
    move-result-object v0

    .line 537
    check-cast v0, Ljava/lang/Number;

    .line 538
    .line 539
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 540
    .line 541
    .line 542
    move-result v0

    .line 543
    invoke-interface {p1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 544
    .line 545
    .line 546
    move-result-object p1

    .line 547
    check-cast p1, Ljava/lang/Number;

    .line 548
    .line 549
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 550
    .line 551
    .line 552
    move-result p1

    .line 553
    invoke-direct {p0, v0, p1}, Lbl3;-><init>(II)V

    .line 554
    .line 555
    .line 556
    return-object p0

    .line 557
    :pswitch_18
    check-cast p1, Leb5;

    .line 558
    .line 559
    return-object v7

    .line 560
    :pswitch_19
    check-cast p1, Lbj3;

    .line 561
    .line 562
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 563
    .line 564
    .line 565
    invoke-virtual {p1}, Lbj3;->c()V

    .line 566
    .line 567
    .line 568
    return-object v7

    .line 569
    :pswitch_1a
    check-cast p1, Lot0;

    .line 570
    .line 571
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 572
    .line 573
    .line 574
    new-instance p0, Lu43;

    .line 575
    .line 576
    const/4 v0, 0x7

    .line 577
    invoke-direct {p0, v0}, Lu43;-><init>(B)V

    .line 578
    .line 579
    .line 580
    new-instance v0, Lne3;

    .line 581
    .line 582
    invoke-direct {v0, p0}, Lne3;-><init>(Llh2;)V

    .line 583
    .line 584
    .line 585
    const-string p0, "JsonPrimitive"

    .line 586
    .line 587
    invoke-static {p1, p0, v0}, Lot0;->a(Lot0;Ljava/lang/String;Ldm6;)V

    .line 588
    .line 589
    .line 590
    new-instance p0, Lu43;

    .line 591
    .line 592
    const/16 v0, 0x8

    .line 593
    .line 594
    invoke-direct {p0, v0}, Lu43;-><init>(B)V

    .line 595
    .line 596
    .line 597
    new-instance v0, Lne3;

    .line 598
    .line 599
    invoke-direct {v0, p0}, Lne3;-><init>(Llh2;)V

    .line 600
    .line 601
    .line 602
    const-string p0, "JsonNull"

    .line 603
    .line 604
    invoke-static {p1, p0, v0}, Lot0;->a(Lot0;Ljava/lang/String;Ldm6;)V

    .line 605
    .line 606
    .line 607
    new-instance p0, Lu43;

    .line 608
    .line 609
    const/16 v0, 0x9

    .line 610
    .line 611
    invoke-direct {p0, v0}, Lu43;-><init>(B)V

    .line 612
    .line 613
    .line 614
    new-instance v0, Lne3;

    .line 615
    .line 616
    invoke-direct {v0, p0}, Lne3;-><init>(Llh2;)V

    .line 617
    .line 618
    .line 619
    const-string p0, "JsonLiteral"

    .line 620
    .line 621
    invoke-static {p1, p0, v0}, Lot0;->a(Lot0;Ljava/lang/String;Ldm6;)V

    .line 622
    .line 623
    .line 624
    new-instance p0, Lu43;

    .line 625
    .line 626
    const/16 v0, 0xa

    .line 627
    .line 628
    invoke-direct {p0, v0}, Lu43;-><init>(B)V

    .line 629
    .line 630
    .line 631
    new-instance v0, Lne3;

    .line 632
    .line 633
    invoke-direct {v0, p0}, Lne3;-><init>(Llh2;)V

    .line 634
    .line 635
    .line 636
    const-string p0, "JsonObject"

    .line 637
    .line 638
    invoke-static {p1, p0, v0}, Lot0;->a(Lot0;Ljava/lang/String;Ldm6;)V

    .line 639
    .line 640
    .line 641
    new-instance p0, Lu43;

    .line 642
    .line 643
    const/16 v0, 0xb

    .line 644
    .line 645
    invoke-direct {p0, v0}, Lu43;-><init>(B)V

    .line 646
    .line 647
    .line 648
    new-instance v0, Lne3;

    .line 649
    .line 650
    invoke-direct {v0, p0}, Lne3;-><init>(Llh2;)V

    .line 651
    .line 652
    .line 653
    const-string p0, "JsonArray"

    .line 654
    .line 655
    invoke-static {p1, p0, v0}, Lot0;->a(Lot0;Ljava/lang/String;Ldm6;)V

    .line 656
    .line 657
    .line 658
    return-object v7

    .line 659
    :pswitch_1b
    check-cast p1, Ljava/util/List;

    .line 660
    .line 661
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 662
    .line 663
    .line 664
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 665
    .line 666
    .line 667
    move-result p0

    .line 668
    if-eqz p0, :cond_b

    .line 669
    .line 670
    invoke-static {v4}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 671
    .line 672
    .line 673
    move-result-object p0

    .line 674
    goto/16 :goto_8

    .line 675
    .line 676
    :cond_b
    invoke-interface {p1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 677
    .line 678
    .line 679
    move-result-object p0

    .line 680
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 681
    .line 682
    .line 683
    check-cast p0, Ljava/lang/String;

    .line 684
    .line 685
    invoke-interface {p1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 686
    .line 687
    .line 688
    move-result-object v4

    .line 689
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 690
    .line 691
    .line 692
    check-cast v4, Ljava/lang/Float;

    .line 693
    .line 694
    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    .line 695
    .line 696
    .line 697
    move-result v4

    .line 698
    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 699
    .line 700
    .line 701
    move-result-object v5

    .line 702
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 703
    .line 704
    .line 705
    check-cast v5, Ljava/lang/Float;

    .line 706
    .line 707
    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    .line 708
    .line 709
    .line 710
    move-result v5

    .line 711
    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    .line 712
    .line 713
    .line 714
    move-result v4

    .line 715
    int-to-long v6, v4

    .line 716
    invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I

    .line 717
    .line 718
    .line 719
    move-result v4

    .line 720
    int-to-long v4, v4

    .line 721
    shl-long/2addr v6, v0

    .line 722
    and-long/2addr v4, v1

    .line 723
    or-long/2addr v6, v4

    .line 724
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 725
    .line 726
    .line 727
    move-result v0

    .line 728
    sparse-switch v0, :sswitch_data_0

    .line 729
    .line 730
    .line 731
    goto/16 :goto_9

    .line 732
    .line 733
    :sswitch_0
    const-string p1, "LongPress"

    .line 734
    .line 735
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 736
    .line 737
    .line 738
    move-result p1

    .line 739
    if-eqz p1, :cond_c

    .line 740
    .line 741
    new-instance p0, Lda3;

    .line 742
    .line 743
    invoke-direct {p0, v6, v7}, Lda3;-><init>(J)V

    .line 744
    .line 745
    .line 746
    goto/16 :goto_7

    .line 747
    .line 748
    :sswitch_1
    const-string p1, "Press"

    .line 749
    .line 750
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 751
    .line 752
    .line 753
    move-result p1

    .line 754
    if-eqz p1, :cond_c

    .line 755
    .line 756
    new-instance p0, Lfa3;

    .line 757
    .line 758
    invoke-direct {p0, v6, v7}, Lfa3;-><init>(J)V

    .line 759
    .line 760
    .line 761
    goto :goto_7

    .line 762
    :sswitch_2
    const-string p1, "Enter"

    .line 763
    .line 764
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 765
    .line 766
    .line 767
    move-result p1

    .line 768
    if-eqz p1, :cond_c

    .line 769
    .line 770
    new-instance p0, Lba3;

    .line 771
    .line 772
    invoke-direct {p0, v6, v7}, Lba3;-><init>(J)V

    .line 773
    .line 774
    .line 775
    goto :goto_7

    .line 776
    :sswitch_3
    const-string p1, "Zoom"

    .line 777
    .line 778
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 779
    .line 780
    .line 781
    move-result p1

    .line 782
    if-eqz p1, :cond_c

    .line 783
    .line 784
    new-instance p0, Lia3;

    .line 785
    .line 786
    invoke-direct {p0, v6, v7}, Lia3;-><init>(J)V

    .line 787
    .line 788
    .line 789
    goto :goto_7

    .line 790
    :sswitch_4
    const-string p1, "Move"

    .line 791
    .line 792
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 793
    .line 794
    .line 795
    move-result p1

    .line 796
    if-eqz p1, :cond_c

    .line 797
    .line 798
    new-instance p0, Lea3;

    .line 799
    .line 800
    invoke-direct {p0, v6, v7}, Lea3;-><init>(J)V

    .line 801
    .line 802
    .line 803
    goto :goto_7

    .line 804
    :sswitch_5
    const-string v0, "Exit"

    .line 805
    .line 806
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 807
    .line 808
    .line 809
    move-result v0

    .line 810
    if-eqz v0, :cond_c

    .line 811
    .line 812
    new-instance p0, Lca3;

    .line 813
    .line 814
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 815
    .line 816
    .line 817
    move-result-object p1

    .line 818
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 819
    .line 820
    .line 821
    check-cast p1, Ljava/lang/Boolean;

    .line 822
    .line 823
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 824
    .line 825
    .line 826
    move-result p1

    .line 827
    invoke-direct {p0, v6, v7, p1}, Lca3;-><init>(JZ)V

    .line 828
    .line 829
    .line 830
    goto :goto_7

    .line 831
    :sswitch_6
    const-string p1, "Tap"

    .line 832
    .line 833
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 834
    .line 835
    .line 836
    move-result p1

    .line 837
    if-eqz p1, :cond_c

    .line 838
    .line 839
    new-instance p0, Lha3;

    .line 840
    .line 841
    invoke-direct {p0, v6, v7}, Lha3;-><init>(J)V

    .line 842
    .line 843
    .line 844
    goto :goto_7

    .line 845
    :sswitch_7
    const-string p1, "Release"

    .line 846
    .line 847
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 848
    .line 849
    .line 850
    move-result p1

    .line 851
    if-eqz p1, :cond_c

    .line 852
    .line 853
    new-instance p0, Lga3;

    .line 854
    .line 855
    invoke-direct {p0, v6, v7}, Lga3;-><init>(J)V

    .line 856
    .line 857
    .line 858
    :goto_7
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 859
    .line 860
    .line 861
    move-result-object p0

    .line 862
    :goto_8
    return-object p0

    .line 863
    :cond_c
    :goto_9
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 864
    .line 865
    const-string v0, "Unknown Interaction type: "

    .line 866
    .line 867
    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 868
    .line 869
    .line 870
    move-result-object p0

    .line 871
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 872
    .line 873
    .line 874
    move-result-object p0

    .line 875
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 876
    .line 877
    .line 878
    throw p1

    .line 879
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_18
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    :sswitch_data_0
    .sparse-switch
        -0x5bc64019 -> :sswitch_7
        0x14783 -> :sswitch_6
        0x212d3e -> :sswitch_5
        0x24aff1 -> :sswitch_4
        0x2a97f3 -> :sswitch_3
        0x40016b8 -> :sswitch_2
        0x49cb423 -> :sswitch_1
        0x7e40bb07 -> :sswitch_0
    .end sparse-switch
.end method
