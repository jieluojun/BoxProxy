.class public final synthetic La47;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/util/List;

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:Lte4;

.field public final synthetic l:Lwh2;

.field public final synthetic m:Lbi2;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;Lte4;Lwh2;Lbi2;B)V
    .locals 0

    .line 1
    iput-byte p6, p0, La47;->h:B

    .line 2
    .line 3
    iput-object p1, p0, La47;->i:Ljava/util/List;

    .line 4
    .line 5
    iput-object p2, p0, La47;->j:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, La47;->k:Lte4;

    .line 8
    .line 9
    iput-object p4, p0, La47;->l:Lwh2;

    .line 10
    .line 11
    iput-object p5, p0, La47;->m:Lbi2;

    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La47;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    const/4 v5, 0x0

    .line 11
    packed-switch v1, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    move-object/from16 v1, p1

    .line 15
    .line 16
    check-cast v1, Lp01;

    .line 17
    .line 18
    move-object/from16 v15, p2

    .line 19
    .line 20
    check-cast v15, Lzi2;

    .line 21
    .line 22
    move-object/from16 v6, p3

    .line 23
    .line 24
    check-cast v6, Ljava/lang/Integer;

    .line 25
    .line 26
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    and-int/lit8 v1, v6, 0x11

    .line 34
    .line 35
    if-eq v1, v3, :cond_0

    .line 36
    .line 37
    move v1, v4

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    move v1, v5

    .line 40
    :goto_0
    and-int/2addr v6, v4

    .line 41
    invoke-virtual {v15, v6, v1}, Lzi2;->Y(IZ)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-eqz v1, :cond_4

    .line 46
    .line 47
    iget-object v1, v0, La47;->i:Ljava/util/List;

    .line 48
    .line 49
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    :goto_1
    move v11, v5

    .line 54
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    if-eqz v4, :cond_5

    .line 59
    .line 60
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v4

    .line 64
    add-int/lit8 v5, v11, 0x1

    .line 65
    .line 66
    if-ltz v11, :cond_3

    .line 67
    .line 68
    check-cast v4, Ljava/lang/String;

    .line 69
    .line 70
    iget-object v6, v0, La47;->j:Ljava/lang/String;

    .line 71
    .line 72
    invoke-static {v4, v6}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v6

    .line 76
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 77
    .line 78
    .line 79
    move-result v12

    .line 80
    new-instance v7, Lz66;

    .line 81
    .line 82
    const/16 v8, 0xd

    .line 83
    .line 84
    iget-object v9, v0, La47;->m:Lbi2;

    .line 85
    .line 86
    invoke-direct {v7, v9, v4, v8}, Lz66;-><init>(Ljava/lang/Object;Ljava/lang/String;B)V

    .line 87
    .line 88
    .line 89
    const v8, 0x3c9e0357

    .line 90
    .line 91
    .line 92
    invoke-static {v8, v7, v15}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 93
    .line 94
    .line 95
    move-result-object v7

    .line 96
    iget-object v8, v0, La47;->k:Lte4;

    .line 97
    .line 98
    invoke-virtual {v15, v8}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v9

    .line 102
    iget-object v10, v0, La47;->l:Lwh2;

    .line 103
    .line 104
    invoke-virtual {v15, v10}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v13

    .line 108
    or-int/2addr v9, v13

    .line 109
    invoke-virtual {v15, v4}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result v13

    .line 113
    or-int/2addr v9, v13

    .line 114
    invoke-virtual {v15}, Lzi2;->T()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v13

    .line 118
    if-nez v9, :cond_1

    .line 119
    .line 120
    sget-object v9, Lc51;->a:Lql0;

    .line 121
    .line 122
    if-ne v13, v9, :cond_2

    .line 123
    .line 124
    :cond_1
    new-instance v13, Lkg1;

    .line 125
    .line 126
    const/4 v9, 0x2

    .line 127
    invoke-direct {v13, v10, v4, v8, v9}, Lkg1;-><init>(Lwh2;Ljava/lang/String;Lte4;B)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v15, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_2
    move-object v8, v13

    .line 134
    check-cast v8, Llh2;

    .line 135
    .line 136
    const/16 v16, 0x30

    .line 137
    .line 138
    const/16 v17, 0x678

    .line 139
    .line 140
    const/4 v9, 0x0

    .line 141
    const/4 v10, 0x0

    .line 142
    const/4 v13, 0x0

    .line 143
    const/4 v14, 0x0

    .line 144
    invoke-static/range {v6 .. v17}, Lr04;->e(ZLs21;Llh2;Lbb4;ZIILaj6;Lo45;Lzi2;II)V

    .line 145
    .line 146
    .line 147
    goto :goto_1

    .line 148
    :cond_3
    invoke-static {}, Lix;->x0()V

    .line 149
    .line 150
    .line 151
    const/4 v0, 0x0

    .line 152
    throw v0

    .line 153
    :cond_4
    invoke-virtual {v15}, Lzi2;->b0()V

    .line 154
    .line 155
    .line 156
    :cond_5
    return-object v2

    .line 157
    :pswitch_0
    move-object/from16 v1, p1

    .line 158
    .line 159
    check-cast v1, Lp01;

    .line 160
    .line 161
    move-object/from16 v13, p2

    .line 162
    .line 163
    check-cast v13, Lzi2;

    .line 164
    .line 165
    move-object/from16 v6, p3

    .line 166
    .line 167
    check-cast v6, Ljava/lang/Integer;

    .line 168
    .line 169
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 170
    .line 171
    .line 172
    move-result v6

    .line 173
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 174
    .line 175
    .line 176
    and-int/lit8 v1, v6, 0x11

    .line 177
    .line 178
    if-eq v1, v3, :cond_6

    .line 179
    .line 180
    move v5, v4

    .line 181
    :cond_6
    and-int/2addr v6, v4

    .line 182
    invoke-virtual {v13, v6, v5}, Lzi2;->Y(IZ)Z

    .line 183
    .line 184
    .line 185
    move-result v1

    .line 186
    if-eqz v1, :cond_7

    .line 187
    .line 188
    new-instance v3, La47;

    .line 189
    .line 190
    const/4 v9, 0x1

    .line 191
    iget-object v4, v0, La47;->i:Ljava/util/List;

    .line 192
    .line 193
    iget-object v5, v0, La47;->j:Ljava/lang/String;

    .line 194
    .line 195
    iget-object v6, v0, La47;->k:Lte4;

    .line 196
    .line 197
    iget-object v7, v0, La47;->l:Lwh2;

    .line 198
    .line 199
    iget-object v8, v0, La47;->m:Lbi2;

    .line 200
    .line 201
    invoke-direct/range {v3 .. v9}, La47;-><init>(Ljava/util/List;Ljava/lang/String;Lte4;Lwh2;Lbi2;B)V

    .line 202
    .line 203
    .line 204
    const v0, -0x92c746d

    .line 205
    .line 206
    .line 207
    invoke-static {v0, v3, v13}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 208
    .line 209
    .line 210
    move-result-object v12

    .line 211
    const/high16 v14, 0x30000

    .line 212
    .line 213
    const/16 v15, 0x1f

    .line 214
    .line 215
    const/4 v6, 0x0

    .line 216
    const/4 v7, 0x0

    .line 217
    const/4 v8, 0x0

    .line 218
    const/4 v9, 0x0

    .line 219
    const-wide/16 v10, 0x0

    .line 220
    .line 221
    invoke-static/range {v6 .. v15}, Lr04;->c(IILbb4;Lt24;JLs21;Lzi2;II)V

    .line 222
    .line 223
    .line 224
    goto :goto_2

    .line 225
    :cond_7
    invoke-virtual {v13}, Lzi2;->b0()V

    .line 226
    .line 227
    .line 228
    :goto_2
    return-object v2

    .line 229
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
