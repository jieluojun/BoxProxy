.class public final synthetic Lb55;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:Lyn1;

.field public final synthetic i:Lbb4;

.field public final synthetic j:Lo45;

.field public final synthetic k:Lh22;

.field public final synthetic l:I

.field public final synthetic m:La40;

.field public final synthetic n:Lov6;

.field public final synthetic o:Z

.field public final synthetic p:Lwh2;

.field public final synthetic q:Lgk4;

.field public final synthetic r:Lpc5;

.field public final synthetic s:Lv15;

.field public final synthetic t:Lwn1;

.field public final synthetic u:Ls21;

.field public final synthetic v:I

.field public final synthetic w:S


# direct methods
.method public synthetic constructor <init>(IIILa40;Ls21;Lwn1;Lyn1;Lh22;Lwh2;Lbb4;Lgk4;Lv15;Lo45;Lpc5;Lov6;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p7, p0, Lb55;->h:Lyn1;

    .line 5
    .line 6
    iput-object p10, p0, Lb55;->i:Lbb4;

    .line 7
    .line 8
    iput-object p13, p0, Lb55;->j:Lo45;

    .line 9
    .line 10
    iput-object p8, p0, Lb55;->k:Lh22;

    .line 11
    .line 12
    iput p1, p0, Lb55;->l:I

    .line 13
    .line 14
    iput-object p4, p0, Lb55;->m:La40;

    .line 15
    .line 16
    iput-object p15, p0, Lb55;->n:Lov6;

    .line 17
    .line 18
    move/from16 p1, p16

    .line 19
    .line 20
    iput-boolean p1, p0, Lb55;->o:Z

    .line 21
    .line 22
    iput-object p9, p0, Lb55;->p:Lwh2;

    .line 23
    .line 24
    iput-object p11, p0, Lb55;->q:Lgk4;

    .line 25
    .line 26
    iput-object p14, p0, Lb55;->r:Lpc5;

    .line 27
    .line 28
    iput-object p12, p0, Lb55;->s:Lv15;

    .line 29
    .line 30
    iput-object p6, p0, Lb55;->t:Lwn1;

    .line 31
    .line 32
    iput-object p5, p0, Lb55;->u:Ls21;

    .line 33
    .line 34
    iput p2, p0, Lb55;->v:I

    .line 35
    .line 36
    iput-short p3, p0, Lb55;->w:S

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v9, p1

    .line 4
    .line 5
    check-cast v9, Lzi2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget v1, v0, Lb55;->v:I

    .line 15
    .line 16
    or-int/lit8 v1, v1, 0x1

    .line 17
    .line 18
    invoke-static {v1}, Lyj3;->j0(I)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    iget v2, v0, Lb55;->l:I

    .line 23
    .line 24
    move v3, v2

    .line 25
    iget-short v2, v0, Lb55;->w:S

    .line 26
    .line 27
    move v4, v3

    .line 28
    iget-object v3, v0, Lb55;->m:La40;

    .line 29
    .line 30
    move v5, v4

    .line 31
    iget-object v4, v0, Lb55;->u:Ls21;

    .line 32
    .line 33
    move v6, v5

    .line 34
    iget-object v5, v0, Lb55;->t:Lwn1;

    .line 35
    .line 36
    move v7, v6

    .line 37
    iget-object v6, v0, Lb55;->h:Lyn1;

    .line 38
    .line 39
    move v8, v7

    .line 40
    iget-object v7, v0, Lb55;->k:Lh22;

    .line 41
    .line 42
    move v10, v8

    .line 43
    iget-object v8, v0, Lb55;->p:Lwh2;

    .line 44
    .line 45
    move v11, v10

    .line 46
    iget-object v10, v0, Lb55;->i:Lbb4;

    .line 47
    .line 48
    move v12, v11

    .line 49
    iget-object v11, v0, Lb55;->q:Lgk4;

    .line 50
    .line 51
    move v13, v12

    .line 52
    iget-object v12, v0, Lb55;->s:Lv15;

    .line 53
    .line 54
    move v14, v13

    .line 55
    iget-object v13, v0, Lb55;->j:Lo45;

    .line 56
    .line 57
    move v15, v14

    .line 58
    iget-object v14, v0, Lb55;->r:Lpc5;

    .line 59
    .line 60
    move/from16 v16, v15

    .line 61
    .line 62
    iget-object v15, v0, Lb55;->n:Lov6;

    .line 63
    .line 64
    iget-boolean v0, v0, Lb55;->o:Z

    .line 65
    .line 66
    move/from16 v17, v16

    .line 67
    .line 68
    move/from16 v16, v0

    .line 69
    .line 70
    move/from16 v0, v17

    .line 71
    .line 72
    invoke-static/range {v0 .. v16}, Lml3;->b(IIILa40;Ls21;Lwn1;Lyn1;Lh22;Lwh2;Lzi2;Lbb4;Lgk4;Lv15;Lo45;Lpc5;Lov6;Z)V

    .line 73
    .line 74
    .line 75
    sget-object v0, Lst7;->a:Lst7;

    .line 76
    .line 77
    return-object v0
.end method
