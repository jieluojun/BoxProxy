.class public final synthetic Lan7;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic h:Lfb5;

.field public final synthetic i:I

.field public final synthetic j:Lfb5;

.field public final synthetic k:Lfb5;

.field public final synthetic l:Ly14;

.field public final synthetic m:I

.field public final synthetic n:Lfb5;

.field public final synthetic o:I

.field public final synthetic p:J

.field public final synthetic q:Z

.field public final synthetic r:Lsk7;

.field public final synthetic s:I

.field public final synthetic t:Ltk7;

.field public final synthetic u:Lln7;

.field public final synthetic v:I

.field public final synthetic w:Lfb5;

.field public final synthetic x:Lfb5;

.field public final synthetic y:I


# direct methods
.method public synthetic constructor <init>(Lfb5;ILfb5;Lfb5;Ly14;ILfb5;IJZLsk7;ILtk7;Lln7;ILfb5;Lfb5;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lan7;->h:Lfb5;

    .line 5
    .line 6
    iput p2, p0, Lan7;->i:I

    .line 7
    .line 8
    iput-object p3, p0, Lan7;->j:Lfb5;

    .line 9
    .line 10
    iput-object p4, p0, Lan7;->k:Lfb5;

    .line 11
    .line 12
    iput-object p5, p0, Lan7;->l:Ly14;

    .line 13
    .line 14
    iput p6, p0, Lan7;->m:I

    .line 15
    .line 16
    iput-object p7, p0, Lan7;->n:Lfb5;

    .line 17
    .line 18
    iput p8, p0, Lan7;->o:I

    .line 19
    .line 20
    iput-wide p9, p0, Lan7;->p:J

    .line 21
    .line 22
    iput-boolean p11, p0, Lan7;->q:Z

    .line 23
    .line 24
    iput-object p12, p0, Lan7;->r:Lsk7;

    .line 25
    .line 26
    iput p13, p0, Lan7;->s:I

    .line 27
    .line 28
    iput-object p14, p0, Lan7;->t:Ltk7;

    .line 29
    .line 30
    iput-object p15, p0, Lan7;->u:Lln7;

    .line 31
    .line 32
    move/from16 p1, p16

    .line 33
    .line 34
    iput p1, p0, Lan7;->v:I

    .line 35
    .line 36
    move-object/from16 p1, p17

    .line 37
    .line 38
    iput-object p1, p0, Lan7;->w:Lfb5;

    .line 39
    .line 40
    move-object/from16 p1, p18

    .line 41
    .line 42
    iput-object p1, p0, Lan7;->x:Lfb5;

    .line 43
    .line 44
    move/from16 p1, p19

    .line 45
    .line 46
    iput p1, p0, Lan7;->y:I

    .line 47
    .line 48
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lan7;->r:Lsk7;

    .line 4
    .line 5
    iget-object v2, v1, Lsk7;->b:Lz75;

    .line 6
    .line 7
    move-object/from16 v3, p1

    .line 8
    .line 9
    check-cast v3, Leb5;

    .line 10
    .line 11
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object v4, v0, Lan7;->h:Lfb5;

    .line 15
    .line 16
    iget v5, v4, Lfb5;->i:I

    .line 17
    .line 18
    div-int/lit8 v5, v5, 0x2

    .line 19
    .line 20
    iget v6, v0, Lan7;->i:I

    .line 21
    .line 22
    sub-int v5, v6, v5

    .line 23
    .line 24
    const/4 v7, 0x0

    .line 25
    const/4 v8, 0x0

    .line 26
    invoke-virtual {v3, v4, v7, v5, v8}, Leb5;->j(Lfb5;IIF)V

    .line 27
    .line 28
    .line 29
    iget-object v5, v0, Lan7;->j:Lfb5;

    .line 30
    .line 31
    iget v9, v5, Lfb5;->h:I

    .line 32
    .line 33
    iget-object v10, v0, Lan7;->k:Lfb5;

    .line 34
    .line 35
    if-eqz v10, :cond_0

    .line 36
    .line 37
    iget v11, v10, Lfb5;->h:I

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    move v11, v7

    .line 41
    :goto_0
    invoke-static {v9, v11}, Ljava/lang/Math;->max(II)I

    .line 42
    .line 43
    .line 44
    move-result v9

    .line 45
    iget-object v11, v0, Lan7;->l:Ly14;

    .line 46
    .line 47
    invoke-interface {v11}, Lgb3;->getLayoutDirection()Lii3;

    .line 48
    .line 49
    .line 50
    move-result-object v12

    .line 51
    iget v13, v0, Lan7;->m:I

    .line 52
    .line 53
    iget-object v14, v0, Lan7;->n:Lfb5;

    .line 54
    .line 55
    iget v15, v0, Lan7;->o:I

    .line 56
    .line 57
    sget-object v7, Lii3;->h:Lii3;

    .line 58
    .line 59
    if-ne v12, v7, :cond_1

    .line 60
    .line 61
    iget v12, v4, Lfb5;->h:I

    .line 62
    .line 63
    add-int/2addr v12, v13

    .line 64
    goto :goto_1

    .line 65
    :cond_1
    iget v12, v14, Lfb5;->h:I

    .line 66
    .line 67
    add-int/2addr v12, v15

    .line 68
    :goto_1
    invoke-interface {v11}, Lgb3;->getLayoutDirection()Lii3;

    .line 69
    .line 70
    .line 71
    move-result-object v8

    .line 72
    if-ne v8, v7, :cond_2

    .line 73
    .line 74
    iget v4, v14, Lfb5;->h:I

    .line 75
    .line 76
    add-int/2addr v4, v15

    .line 77
    :goto_2
    move v13, v9

    .line 78
    goto :goto_3

    .line 79
    :cond_2
    iget v4, v4, Lfb5;->h:I

    .line 80
    .line 81
    add-int/2addr v4, v13

    .line 82
    goto :goto_2

    .line 83
    :goto_3
    iget-wide v8, v0, Lan7;->p:J

    .line 84
    .line 85
    invoke-static {v8, v9}, Ljb1;->i(J)I

    .line 86
    .line 87
    .line 88
    move-result v15

    .line 89
    sub-int/2addr v15, v13

    .line 90
    div-int/lit8 v15, v15, 0x2

    .line 91
    .line 92
    move/from16 v16, v4

    .line 93
    .line 94
    iget-boolean v4, v0, Lan7;->q:Z

    .line 95
    .line 96
    move/from16 v17, v4

    .line 97
    .line 98
    if-nez v17, :cond_3

    .line 99
    .line 100
    if-lt v15, v12, :cond_3

    .line 101
    .line 102
    add-int v4, v15, v13

    .line 103
    .line 104
    invoke-static {v8, v9}, Ljb1;->i(J)I

    .line 105
    .line 106
    .line 107
    move-result v18

    .line 108
    move/from16 v19, v6

    .line 109
    .line 110
    sub-int v6, v18, v16

    .line 111
    .line 112
    if-gt v4, v6, :cond_4

    .line 113
    .line 114
    const/4 v4, 0x1

    .line 115
    goto :goto_4

    .line 116
    :cond_3
    move/from16 v19, v6

    .line 117
    .line 118
    :cond_4
    const/4 v4, 0x0

    .line 119
    :goto_4
    iget-boolean v6, v1, Lsk7;->a:Z

    .line 120
    .line 121
    const/high16 v18, 0x3f800000    # 1.0f

    .line 122
    .line 123
    if-nez v6, :cond_5

    .line 124
    .line 125
    const/4 v6, 0x1

    .line 126
    iput-boolean v6, v1, Lsk7;->a:Z

    .line 127
    .line 128
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    invoke-virtual {v2, v1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    if-eqz v4, :cond_8

    .line 136
    .line 137
    goto :goto_5

    .line 138
    :cond_5
    invoke-virtual {v2}, Lz75;->getValue()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v6

    .line 142
    check-cast v6, Ljava/lang/Boolean;

    .line 143
    .line 144
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 145
    .line 146
    .line 147
    move-result v6

    .line 148
    if-eq v6, v4, :cond_6

    .line 149
    .line 150
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 151
    .line 152
    .line 153
    move-result-object v6

    .line 154
    invoke-virtual {v2, v6}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    :cond_6
    iget-boolean v2, v1, Lsk7;->c:Z

    .line 158
    .line 159
    if-eqz v2, :cond_7

    .line 160
    .line 161
    iget-object v1, v1, Lsk7;->d:Lrg;

    .line 162
    .line 163
    invoke-virtual {v1}, Lrg;->e()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    check-cast v1, Ljava/lang/Number;

    .line 168
    .line 169
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 170
    .line 171
    .line 172
    move-result v1

    .line 173
    goto :goto_6

    .line 174
    :cond_7
    if-eqz v4, :cond_8

    .line 175
    .line 176
    :goto_5
    move/from16 v1, v18

    .line 177
    .line 178
    goto :goto_6

    .line 179
    :cond_8
    const/4 v1, 0x0

    .line 180
    :goto_6
    iget v2, v5, Lfb5;->h:I

    .line 181
    .line 182
    sub-int v2, v13, v2

    .line 183
    .line 184
    div-int/lit8 v2, v2, 0x2

    .line 185
    .line 186
    add-int/2addr v2, v15

    .line 187
    if-eqz v10, :cond_9

    .line 188
    .line 189
    iget v4, v10, Lfb5;->h:I

    .line 190
    .line 191
    goto :goto_7

    .line 192
    :cond_9
    const/4 v4, 0x0

    .line 193
    :goto_7
    sub-int v4, v13, v4

    .line 194
    .line 195
    div-int/lit8 v4, v4, 0x2

    .line 196
    .line 197
    add-int/2addr v4, v15

    .line 198
    invoke-interface {v11}, Lgb3;->getLayoutDirection()Lii3;

    .line 199
    .line 200
    .line 201
    move-result-object v6

    .line 202
    if-ne v6, v7, :cond_a

    .line 203
    .line 204
    move v6, v12

    .line 205
    goto :goto_8

    .line 206
    :cond_a
    invoke-static {v8, v9}, Ljb1;->i(J)I

    .line 207
    .line 208
    .line 209
    move-result v6

    .line 210
    sub-int v6, v6, v16

    .line 211
    .line 212
    iget v13, v5, Lfb5;->h:I

    .line 213
    .line 214
    sub-int/2addr v6, v13

    .line 215
    :goto_8
    invoke-interface {v11}, Lgb3;->getLayoutDirection()Lii3;

    .line 216
    .line 217
    .line 218
    move-result-object v13

    .line 219
    if-eq v13, v7, :cond_c

    .line 220
    .line 221
    invoke-static {v8, v9}, Ljb1;->i(J)I

    .line 222
    .line 223
    .line 224
    move-result v12

    .line 225
    sub-int v12, v12, v16

    .line 226
    .line 227
    if-eqz v10, :cond_b

    .line 228
    .line 229
    iget v13, v10, Lfb5;->h:I

    .line 230
    .line 231
    goto :goto_9

    .line 232
    :cond_b
    const/4 v13, 0x0

    .line 233
    :goto_9
    sub-int/2addr v12, v13

    .line 234
    :cond_c
    invoke-static {v1, v6, v2}, Lmk3;->a0(FII)I

    .line 235
    .line 236
    .line 237
    move-result v2

    .line 238
    invoke-static {v1, v12, v4}, Lmk3;->a0(FII)I

    .line 239
    .line 240
    .line 241
    move-result v1

    .line 242
    iget v4, v0, Lan7;->s:I

    .line 243
    .line 244
    iget-object v6, v0, Lan7;->u:Lln7;

    .line 245
    .line 246
    if-lez v4, :cond_e

    .line 247
    .line 248
    iget-object v4, v0, Lan7;->t:Ltk7;

    .line 249
    .line 250
    iget-object v4, v4, Ltk7;->l:Lrg;

    .line 251
    .line 252
    invoke-virtual {v4}, Lrg;->e()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v4

    .line 256
    check-cast v4, Ljava/lang/Number;

    .line 257
    .line 258
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 259
    .line 260
    .line 261
    move-result v4

    .line 262
    const v13, 0x3a83126f    # 0.001f

    .line 263
    .line 264
    .line 265
    cmpl-float v4, v4, v13

    .line 266
    .line 267
    if-lez v4, :cond_e

    .line 268
    .line 269
    const/16 v4, 0x20

    .line 270
    .line 271
    int-to-long v12, v2

    .line 272
    shl-long/2addr v12, v4

    .line 273
    iget v15, v0, Lan7;->v:I

    .line 274
    .line 275
    move/from16 v17, v4

    .line 276
    .line 277
    move-object/from16 v16, v5

    .line 278
    .line 279
    int-to-long v4, v15

    .line 280
    const-wide v20, 0xffffffffL

    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    and-long v4, v4, v20

    .line 286
    .line 287
    or-long/2addr v12, v4

    .line 288
    iget-object v4, v6, Lln7;->c:Lz75;

    .line 289
    .line 290
    new-instance v5, Lp93;

    .line 291
    .line 292
    invoke-direct {v5, v12, v13}, Lp93;-><init>(J)V

    .line 293
    .line 294
    .line 295
    invoke-virtual {v4, v5}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 296
    .line 297
    .line 298
    move-object/from16 v4, v16

    .line 299
    .line 300
    const/4 v5, 0x0

    .line 301
    invoke-virtual {v3, v4, v2, v15, v5}, Leb5;->g(Lfb5;IIF)V

    .line 302
    .line 303
    .line 304
    if-eqz v10, :cond_d

    .line 305
    .line 306
    iget v2, v4, Lfb5;->i:I

    .line 307
    .line 308
    add-int/2addr v15, v2

    .line 309
    int-to-long v4, v1

    .line 310
    shl-long v4, v4, v17

    .line 311
    .line 312
    int-to-long v12, v15

    .line 313
    and-long v12, v12, v20

    .line 314
    .line 315
    or-long/2addr v4, v12

    .line 316
    iget-object v2, v6, Lln7;->e:Lz75;

    .line 317
    .line 318
    new-instance v12, Lp93;

    .line 319
    .line 320
    invoke-direct {v12, v4, v5}, Lp93;-><init>(J)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v2, v12}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 324
    .line 325
    .line 326
    const/4 v5, 0x0

    .line 327
    invoke-virtual {v3, v10, v1, v15, v5}, Leb5;->g(Lfb5;IIF)V

    .line 328
    .line 329
    .line 330
    goto :goto_a

    .line 331
    :cond_d
    const/4 v5, 0x0

    .line 332
    goto :goto_a

    .line 333
    :cond_e
    const/4 v5, 0x0

    .line 334
    const/16 v17, 0x20

    .line 335
    .line 336
    :goto_a
    invoke-static {v8, v9}, Ljb1;->i(J)I

    .line 337
    .line 338
    .line 339
    move-result v1

    .line 340
    iget v2, v14, Lfb5;->h:I

    .line 341
    .line 342
    sub-int/2addr v1, v2

    .line 343
    iget v2, v14, Lfb5;->i:I

    .line 344
    .line 345
    div-int/lit8 v2, v2, 0x2

    .line 346
    .line 347
    sub-int v2, v19, v2

    .line 348
    .line 349
    invoke-virtual {v3, v14, v1, v2, v5}, Leb5;->j(Lfb5;IIF)V

    .line 350
    .line 351
    .line 352
    invoke-interface {v11}, Lgb3;->getLayoutDirection()Lii3;

    .line 353
    .line 354
    .line 355
    move-result-object v1

    .line 356
    iget-object v2, v0, Lan7;->w:Lfb5;

    .line 357
    .line 358
    if-ne v1, v7, :cond_f

    .line 359
    .line 360
    const/4 v1, 0x0

    .line 361
    goto :goto_b

    .line 362
    :cond_f
    invoke-static {v8, v9}, Ljb1;->i(J)I

    .line 363
    .line 364
    .line 365
    move-result v1

    .line 366
    iget v4, v2, Lfb5;->h:I

    .line 367
    .line 368
    sub-int/2addr v1, v4

    .line 369
    :goto_b
    int-to-long v4, v1

    .line 370
    shl-long v4, v4, v17

    .line 371
    .line 372
    iget-object v1, v6, Lln7;->d:Lz75;

    .line 373
    .line 374
    new-instance v6, Lp93;

    .line 375
    .line 376
    invoke-direct {v6, v4, v5}, Lp93;-><init>(J)V

    .line 377
    .line 378
    .line 379
    invoke-virtual {v1, v6}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 380
    .line 381
    .line 382
    const/4 v1, 0x0

    .line 383
    const/4 v5, 0x0

    .line 384
    invoke-virtual {v3, v2, v1, v1, v5}, Leb5;->j(Lfb5;IIF)V

    .line 385
    .line 386
    .line 387
    iget-object v2, v0, Lan7;->x:Lfb5;

    .line 388
    .line 389
    iget v0, v0, Lan7;->y:I

    .line 390
    .line 391
    invoke-virtual {v3, v2, v1, v0, v5}, Leb5;->j(Lfb5;IIF)V

    .line 392
    .line 393
    .line 394
    sget-object v0, Lst7;->a:Lst7;

    .line 395
    .line 396
    return-object v0
.end method
