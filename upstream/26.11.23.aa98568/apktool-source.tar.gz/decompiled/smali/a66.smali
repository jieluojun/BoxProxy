.class public final synthetic La66;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lf26;

.field public final synthetic j:J


# direct methods
.method public synthetic constructor <init>(Lf26;JB)V
    .locals 0

    .line 1
    iput-byte p4, p0, La66;->h:B

    .line 2
    .line 3
    iput-object p1, p0, La66;->i:Lf26;

    .line 4
    .line 5
    iput-wide p2, p0, La66;->j:J

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La66;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x2

    .line 9
    const/4 v5, 0x1

    .line 10
    iget-object v6, v0, La66;->i:Lf26;

    .line 11
    .line 12
    packed-switch v1, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    move-object/from16 v1, p1

    .line 16
    .line 17
    check-cast v1, Lzi2;

    .line 18
    .line 19
    move-object/from16 v7, p2

    .line 20
    .line 21
    check-cast v7, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v7

    .line 27
    and-int/lit8 v8, v7, 0x3

    .line 28
    .line 29
    if-eq v8, v4, :cond_0

    .line 30
    .line 31
    move v3, v5

    .line 32
    :cond_0
    and-int/2addr v7, v5

    .line 33
    invoke-virtual {v1, v7, v3}, Lzi2;->Y(IZ)Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-eqz v3, :cond_1

    .line 38
    .line 39
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    iget-object v7, v6, Lf26;->b:Ljava/util/ArrayList;

    .line 43
    .line 44
    new-instance v11, Lf46;

    .line 45
    .line 46
    const/16 v3, 0x10

    .line 47
    .line 48
    invoke-direct {v11, v3}, Lf46;-><init>(B)V

    .line 49
    .line 50
    .line 51
    const/16 v12, 0x1e

    .line 52
    .line 53
    const-string v8, "\n"

    .line 54
    .line 55
    const/4 v9, 0x0

    .line 56
    const/4 v10, 0x0

    .line 57
    invoke-static/range {v7 .. v12}, Lay0;->Z0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Lwh2;I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v7

    .line 61
    sget-object v3, Lh14;->b:Lux1;

    .line 62
    .line 63
    invoke-virtual {v1, v3}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    check-cast v3, Le14;

    .line 68
    .line 69
    iget-object v3, v3, Le14;->b:Lkr7;

    .line 70
    .line 71
    iget-object v3, v3, Lkr7;->k:Lbi7;

    .line 72
    .line 73
    const/16 v27, 0x0

    .line 74
    .line 75
    const v28, 0x1fffa

    .line 76
    .line 77
    .line 78
    const/4 v8, 0x0

    .line 79
    iget-wide v9, v0, La66;->j:J

    .line 80
    .line 81
    const-wide/16 v11, 0x0

    .line 82
    .line 83
    const/4 v13, 0x0

    .line 84
    const/4 v14, 0x0

    .line 85
    const-wide/16 v15, 0x0

    .line 86
    .line 87
    const/16 v17, 0x0

    .line 88
    .line 89
    const-wide/16 v18, 0x0

    .line 90
    .line 91
    const/16 v20, 0x0

    .line 92
    .line 93
    const/16 v21, 0x0

    .line 94
    .line 95
    const/16 v22, 0x0

    .line 96
    .line 97
    const/16 v23, 0x0

    .line 98
    .line 99
    const/16 v26, 0x0

    .line 100
    .line 101
    move-object/from16 v25, v1

    .line 102
    .line 103
    move-object/from16 v24, v3

    .line 104
    .line 105
    invoke-static/range {v7 .. v28}, Ltf7;->b(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILbi7;Lzi2;III)V

    .line 106
    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_1
    move-object/from16 v25, v1

    .line 110
    .line 111
    invoke-virtual/range {v25 .. v25}, Lzi2;->b0()V

    .line 112
    .line 113
    .line 114
    :goto_0
    return-object v2

    .line 115
    :pswitch_0
    move-object/from16 v1, p1

    .line 116
    .line 117
    check-cast v1, Lzi2;

    .line 118
    .line 119
    move-object/from16 v7, p2

    .line 120
    .line 121
    check-cast v7, Ljava/lang/Integer;

    .line 122
    .line 123
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 124
    .line 125
    .line 126
    move-result v7

    .line 127
    and-int/lit8 v8, v7, 0x3

    .line 128
    .line 129
    if-eq v8, v4, :cond_2

    .line 130
    .line 131
    move v3, v5

    .line 132
    :cond_2
    and-int/2addr v7, v5

    .line 133
    invoke-virtual {v1, v7, v3}, Lzi2;->Y(IZ)Z

    .line 134
    .line 135
    .line 136
    move-result v3

    .line 137
    if-eqz v3, :cond_3

    .line 138
    .line 139
    iget-object v3, v6, Lf26;->a:Lz36;

    .line 140
    .line 141
    invoke-static {v3}, Lz76;->d(Lz36;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    sget-object v4, Lh14;->b:Lux1;

    .line 146
    .line 147
    invoke-virtual {v1, v4}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v4

    .line 151
    check-cast v4, Le14;

    .line 152
    .line 153
    iget-object v4, v4, Le14;->b:Lkr7;

    .line 154
    .line 155
    iget-object v4, v4, Lkr7;->j:Lbi7;

    .line 156
    .line 157
    const/16 v23, 0x0

    .line 158
    .line 159
    const v24, 0x1fffa

    .line 160
    .line 161
    .line 162
    move-object/from16 v20, v4

    .line 163
    .line 164
    const/4 v4, 0x0

    .line 165
    iget-wide v5, v0, La66;->j:J

    .line 166
    .line 167
    const-wide/16 v7, 0x0

    .line 168
    .line 169
    const/4 v9, 0x0

    .line 170
    const/4 v10, 0x0

    .line 171
    const-wide/16 v11, 0x0

    .line 172
    .line 173
    const/4 v13, 0x0

    .line 174
    const-wide/16 v14, 0x0

    .line 175
    .line 176
    const/16 v16, 0x0

    .line 177
    .line 178
    const/16 v17, 0x0

    .line 179
    .line 180
    const/16 v18, 0x0

    .line 181
    .line 182
    const/16 v19, 0x0

    .line 183
    .line 184
    const/16 v22, 0x0

    .line 185
    .line 186
    move-object/from16 v21, v1

    .line 187
    .line 188
    invoke-static/range {v3 .. v24}, Ltf7;->b(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILbi7;Lzi2;III)V

    .line 189
    .line 190
    .line 191
    goto :goto_1

    .line 192
    :cond_3
    move-object/from16 v21, v1

    .line 193
    .line 194
    invoke-virtual/range {v21 .. v21}, Lzi2;->b0()V

    .line 195
    .line 196
    .line 197
    :goto_1
    return-object v2

    .line 198
    nop

    .line 199
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
