.class public final La28;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:Li28;

.field public final synthetic b:Lb38;

.field public final synthetic c:Lb38;

.field public final synthetic d:I

.field public final synthetic e:Landroid/view/View;


# direct methods
.method public constructor <init>(Li28;Lb38;Lb38;ILandroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La28;->a:Li28;

    .line 5
    .line 6
    iput-object p2, p0, La28;->b:Lb38;

    .line 7
    .line 8
    iput-object p3, p0, La28;->c:Lb38;

    .line 9
    .line 10
    iput p4, p0, La28;->d:I

    .line 11
    .line 12
    iput-object p5, p0, La28;->e:Landroid/view/View;

    .line 13
    .line 14
    return-void
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 14

    .line 1
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedFraction()F

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iget-object v0, p0, La28;->a:Li28;

    .line 6
    .line 7
    iget-object v1, v0, Li28;->a:Lh28;

    .line 8
    .line 9
    invoke-virtual {v1, p1}, Lh28;->d(F)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v1}, Lh28;->b()F

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    sget-object v1, Ld28;->e:Landroid/view/animation/PathInterpolator;

    .line 17
    .line 18
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 19
    .line 20
    const/16 v2, 0x24

    .line 21
    .line 22
    iget-object v3, p0, La28;->b:Lb38;

    .line 23
    .line 24
    if-lt v1, v2, :cond_0

    .line 25
    .line 26
    new-instance v1, Lo28;

    .line 27
    .line 28
    invoke-direct {v1, v3}, Lo28;-><init>(Lb38;)V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    const/16 v2, 0x23

    .line 33
    .line 34
    if-lt v1, v2, :cond_1

    .line 35
    .line 36
    new-instance v1, Ln28;

    .line 37
    .line 38
    invoke-direct {v1, v3}, Ln28;-><init>(Lb38;)V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_1
    const/16 v2, 0x22

    .line 43
    .line 44
    if-lt v1, v2, :cond_2

    .line 45
    .line 46
    new-instance v1, Lm28;

    .line 47
    .line 48
    invoke-direct {v1, v3}, Lm28;-><init>(Lb38;)V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_2
    const/16 v2, 0x1f

    .line 53
    .line 54
    if-lt v1, v2, :cond_3

    .line 55
    .line 56
    new-instance v1, Ll28;

    .line 57
    .line 58
    invoke-direct {v1, v3}, Ll28;-><init>(Lb38;)V

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_3
    const/16 v2, 0x1e

    .line 63
    .line 64
    if-lt v1, v2, :cond_4

    .line 65
    .line 66
    new-instance v1, Lk28;

    .line 67
    .line 68
    invoke-direct {v1, v3}, Lk28;-><init>(Lb38;)V

    .line 69
    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_4
    new-instance v1, Lj28;

    .line 73
    .line 74
    invoke-direct {v1, v3}, Lj28;-><init>(Lb38;)V

    .line 75
    .line 76
    .line 77
    :goto_0
    const/4 v2, 0x1

    .line 78
    :goto_1
    const/16 v4, 0x200

    .line 79
    .line 80
    if-gt v2, v4, :cond_6

    .line 81
    .line 82
    iget v4, p0, La28;->d:I

    .line 83
    .line 84
    and-int/2addr v4, v2

    .line 85
    iget-object v5, v3, Lb38;->a:Ly28;

    .line 86
    .line 87
    if-nez v4, :cond_5

    .line 88
    .line 89
    invoke-virtual {v5, v2}, Ly28;->i(I)Lm83;

    .line 90
    .line 91
    .line 92
    move-result-object v4

    .line 93
    invoke-virtual {v1, v2, v4}, Lp28;->d(ILm83;)V

    .line 94
    .line 95
    .line 96
    goto :goto_2

    .line 97
    :cond_5
    invoke-virtual {v5, v2}, Ly28;->i(I)Lm83;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    iget-object v5, p0, La28;->c:Lb38;

    .line 102
    .line 103
    iget-object v5, v5, Lb38;->a:Ly28;

    .line 104
    .line 105
    invoke-virtual {v5, v2}, Ly28;->i(I)Lm83;

    .line 106
    .line 107
    .line 108
    move-result-object v5

    .line 109
    iget v6, v4, Lm83;->a:I

    .line 110
    .line 111
    iget v7, v5, Lm83;->a:I

    .line 112
    .line 113
    sub-int/2addr v6, v7

    .line 114
    int-to-float v6, v6

    .line 115
    const/high16 v7, 0x3f800000    # 1.0f

    .line 116
    .line 117
    sub-float/2addr v7, p1

    .line 118
    mul-float/2addr v6, v7

    .line 119
    float-to-double v8, v6

    .line 120
    const-wide/high16 v10, 0x3fe0000000000000L    # 0.5

    .line 121
    .line 122
    add-double/2addr v8, v10

    .line 123
    double-to-int v6, v8

    .line 124
    iget v8, v4, Lm83;->b:I

    .line 125
    .line 126
    iget v9, v5, Lm83;->b:I

    .line 127
    .line 128
    sub-int/2addr v8, v9

    .line 129
    int-to-float v8, v8

    .line 130
    mul-float/2addr v8, v7

    .line 131
    float-to-double v8, v8

    .line 132
    add-double/2addr v8, v10

    .line 133
    double-to-int v8, v8

    .line 134
    iget v9, v4, Lm83;->c:I

    .line 135
    .line 136
    iget v12, v5, Lm83;->c:I

    .line 137
    .line 138
    sub-int/2addr v9, v12

    .line 139
    int-to-float v9, v9

    .line 140
    mul-float/2addr v9, v7

    .line 141
    float-to-double v12, v9

    .line 142
    add-double/2addr v12, v10

    .line 143
    double-to-int v9, v12

    .line 144
    iget v12, v4, Lm83;->d:I

    .line 145
    .line 146
    iget v5, v5, Lm83;->d:I

    .line 147
    .line 148
    sub-int/2addr v12, v5

    .line 149
    int-to-float v5, v12

    .line 150
    mul-float/2addr v5, v7

    .line 151
    float-to-double v12, v5

    .line 152
    add-double/2addr v12, v10

    .line 153
    double-to-int v5, v12

    .line 154
    invoke-static {v4, v6, v8, v9, v5}, Lb38;->a(Lm83;IIII)Lm83;

    .line 155
    .line 156
    .line 157
    move-result-object v4

    .line 158
    invoke-virtual {v1, v2, v4}, Lp28;->d(ILm83;)V

    .line 159
    .line 160
    .line 161
    :goto_2
    shl-int/lit8 v2, v2, 0x1

    .line 162
    .line 163
    goto :goto_1

    .line 164
    :cond_6
    invoke-virtual {v1}, Lj28;->b()Lb38;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    iget-object p0, p0, La28;->e:Landroid/view/View;

    .line 173
    .line 174
    invoke-static {p0, p1, v0}, Ld28;->g(Landroid/view/View;Lb38;Ljava/util/List;)V

    .line 175
    .line 176
    .line 177
    return-void
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method
