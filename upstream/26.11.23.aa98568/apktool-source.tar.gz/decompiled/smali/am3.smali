.class public final Lam3;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Ly14;


# instance fields
.field public final h:Lul3;

.field public final i:Ld37;

.field public final j:Lwl3;

.field public final k:Lrd4;


# direct methods
.method public constructor <init>(Lul3;Ld37;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lam3;->h:Lul3;

    .line 5
    .line 6
    iput-object p2, p0, Lam3;->i:Ld37;

    .line 7
    .line 8
    iget-object p1, p1, Lul3;->b:Lgw2;

    .line 9
    .line 10
    invoke-virtual {p1}, Lgw2;->a()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lwl3;

    .line 15
    .line 16
    iput-object p1, p0, Lam3;->j:Lwl3;

    .line 17
    .line 18
    invoke-static {}, Lo93;->a()Lrd4;

    .line 19
    .line 20
    .line 21
    new-instance p1, Lrd4;

    .line 22
    .line 23
    invoke-direct {p1}, Lrd4;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, Lam3;->k:Lrd4;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final A()F
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0}, Lkp1;->A()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final F()Z
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0}, Lgb3;->F()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final G0(IILsa;Lv;Lc3;)Lv14;
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p5}, Ly14;->G0(IILsa;Lv;Lc3;)Lv14;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final H0(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkp1;->H0(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final I(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkp1;->I(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final J(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkp1;->J(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final L(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkp1;->L(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final O0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkp1;->O0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final P0(IILjava/util/Map;Lwh2;)Lv14;
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2, p3, p4}, Ly14;->P0(IILjava/util/Map;Lwh2;)Lv14;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final a()F
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0}, Lkp1;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final a1(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkp1;->a1(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final c(I)Ljava/util/List;
    .locals 4

    .line 1
    iget-object v0, p0, Lam3;->k:Lrd4;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ln93;->b(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Ljava/util/List;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    return-object v1

    .line 12
    :cond_0
    iget-object v1, p0, Lam3;->j:Lwl3;

    .line 13
    .line 14
    invoke-interface {v1, p1}, Lwl3;->b(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    invoke-interface {v1, p1}, Lwl3;->c(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    iget-object v3, p0, Lam3;->h:Lul3;

    .line 23
    .line 24
    invoke-virtual {v3, p1, v2, v1}, Lul3;->a(ILjava/lang/Object;Ljava/lang/Object;)Lai2;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 29
    .line 30
    invoke-interface {p0, v1, v2}, Ld37;->a0(Lai2;Ljava/lang/Object;)Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    invoke-virtual {v0, p1, p0}, Lrd4;->i(ILjava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    return-object p0
.end method

.method public final c0(J)I
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkp1;->c0(J)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final g0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkp1;->g0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final getLayoutDirection()Lii3;
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0}, Lgb3;->getLayoutDirection()Lii3;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final l1(I)F
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkp1;->l1(I)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final p1(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkp1;->p1(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final r0(IILjava/util/Map;Lwh2;Lwh2;)Lv14;
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p5}, Ly14;->r0(IILjava/util/Map;Lwh2;Lwh2;)Lv14;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final s0(F)I
    .locals 0

    .line 1
    iget-object p0, p0, Lam3;->i:Ld37;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkp1;->s0(F)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
