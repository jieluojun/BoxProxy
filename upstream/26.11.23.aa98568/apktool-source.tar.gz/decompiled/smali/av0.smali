.class public final Lav0;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic l:B

.field public m:B

.field public n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lb46;Lr76;Lxd1;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lav0;->l:B

    .line 3
    .line 4
    iput-object p1, p0, Lav0;->n:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Lav0;->o:Ljava/lang/Object;

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    invoke-direct {p0, p1, p3}, Lt57;-><init>(ILxd1;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>(Ldv0;Lxd1;)V
    .locals 1

    const/4 v0, 0x0

    iput-byte v0, p0, Lav0;->l:B

    .line 13
    iput-object p1, p0, Lav0;->o:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, Lt57;-><init>(ILxd1;)V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lav0;->l:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    iget-object v2, p0, Lav0;->o:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p1, Lxd1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    new-instance v0, Lav0;

    .line 13
    .line 14
    iget-object p0, p0, Lav0;->n:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p0, Lb46;

    .line 17
    .line 18
    check-cast v2, Lr76;

    .line 19
    .line 20
    invoke-direct {v0, p0, v2, p1}, Lav0;-><init>(Lb46;Lr76;Lxd1;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lav0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0

    .line 28
    :pswitch_0
    new-instance p0, Lav0;

    .line 29
    .line 30
    check-cast v2, Ldv0;

    .line 31
    .line 32
    invoke-direct {p0, v2, p1}, Lav0;-><init>(Ldv0;Lxd1;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0, v1}, Lav0;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    return-object p0

    .line 40
    nop

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget-byte v0, p0, Lav0;->l:B

    .line 2
    .line 3
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 4
    .line 5
    sget-object v2, Lkj1;->h:Lkj1;

    .line 6
    .line 7
    iget-object v3, p0, Lav0;->o:Ljava/lang/Object;

    .line 8
    .line 9
    const/4 v4, 0x2

    .line 10
    sget-object v5, Lst7;->a:Lst7;

    .line 11
    .line 12
    const/4 v6, 0x0

    .line 13
    const/4 v7, 0x1

    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lav0;->n:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lb46;

    .line 20
    .line 21
    check-cast v3, Lr76;

    .line 22
    .line 23
    iget-byte v8, p0, Lav0;->m:B

    .line 24
    .line 25
    if-eqz v8, :cond_2

    .line 26
    .line 27
    if-eq v8, v7, :cond_1

    .line 28
    .line 29
    if-ne v8, v4, :cond_0

    .line 30
    .line 31
    :try_start_0
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_0
    invoke-static {v1}, Ll42;->d(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    move-object v2, v6

    .line 39
    goto/16 :goto_3

    .line 40
    .line 41
    :cond_1
    :try_start_1
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_2
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :try_start_2
    sget-object p1, Lk46;->a:Lk46;

    .line 49
    .line 50
    iget-object v1, v0, Lb46;->a:Ljava/lang/String;

    .line 51
    .line 52
    iput-byte v7, p0, Lav0;->m:B

    .line 53
    .line 54
    invoke-virtual {p1, v1, p0}, Lk46;->i(Ljava/lang/String;Lyd1;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    if-eq p1, v2, :cond_4

    .line 59
    .line 60
    :goto_0
    check-cast p1, Lu36;

    .line 61
    .line 62
    iget-boolean p1, p1, Lu36;->a:Z

    .line 63
    .line 64
    if-nez p1, :cond_3

    .line 65
    .line 66
    iget-object p0, v3, Lr76;->e:Lfk5;

    .line 67
    .line 68
    invoke-virtual {p0}, Lfk5;->a()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p0

    .line 72
    check-cast p0, Ljava/lang/String;

    .line 73
    .line 74
    invoke-static {v3, p0}, Lr76;->g(Lr76;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v3}, Lr76;->h()La86;

    .line 78
    .line 79
    .line 80
    move-result-object p0

    .line 81
    invoke-virtual {v3}, Lr76;->h()La86;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    invoke-virtual {p1}, La86;->l()Ljava/util/Set;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    iget-object v1, v0, Lb46;->a:Ljava/lang/String;

    .line 90
    .line 91
    invoke-static {p1, v1}, Lpm6;->O(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    iget-object p0, p0, La86;->q:Lz75;

    .line 96
    .line 97
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    goto :goto_2

    .line 101
    :cond_3
    iput-byte v4, p0, Lav0;->m:B

    .line 102
    .line 103
    const-wide/16 v6, 0x258

    .line 104
    .line 105
    invoke-static {v6, v7, p0}, Lrx;->l(JLxd1;)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object p0

    .line 109
    if-eq p0, v2, :cond_4

    .line 110
    .line 111
    :goto_1
    new-instance p0, Ls45;

    .line 112
    .line 113
    const/16 p1, 0xb

    .line 114
    .line 115
    invoke-direct {p0, v3, v0, p1}, Ls45;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 116
    .line 117
    .line 118
    const/4 p1, 0x0

    .line 119
    invoke-static {v3, p1, p0, v4}, Lr76;->d(Lr76;ZLs45;I)V
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 120
    .line 121
    .line 122
    :goto_2
    move-object v2, v5

    .line 123
    goto :goto_3

    .line 124
    :catch_0
    move-exception p0

    .line 125
    iget-object p1, v0, Lb46;->a:Ljava/lang/String;

    .line 126
    .line 127
    new-instance v1, Ljava/lang/StringBuilder;

    .line 128
    .line 129
    const-string v2, "Unable to update rule provider "

    .line 130
    .line 131
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 135
    .line 136
    .line 137
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    const-string v1, "RulesRefresh"

    .line 142
    .line 143
    invoke-static {v1, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 144
    .line 145
    .line 146
    invoke-virtual {v3}, Lr76;->h()La86;

    .line 147
    .line 148
    .line 149
    move-result-object p0

    .line 150
    invoke-virtual {v3}, Lr76;->h()La86;

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    invoke-virtual {p1}, La86;->l()Ljava/util/Set;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    iget-object v0, v0, Lb46;->a:Ljava/lang/String;

    .line 159
    .line 160
    invoke-static {p1, v0}, Lpm6;->O(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    iget-object p0, p0, La86;->q:Lz75;

    .line 165
    .line 166
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    iget-object p0, v3, Lr76;->e:Lfk5;

    .line 170
    .line 171
    invoke-virtual {p0}, Lfk5;->a()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object p0

    .line 175
    check-cast p0, Ljava/lang/String;

    .line 176
    .line 177
    invoke-static {v3, p0}, Lr76;->g(Lr76;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    goto :goto_2

    .line 181
    :cond_4
    :goto_3
    return-object v2

    .line 182
    :catch_1
    move-exception p0

    .line 183
    throw p0

    .line 184
    :pswitch_0
    check-cast v3, Ldv0;

    .line 185
    .line 186
    iget-object v0, v3, Ldv0;->b:Lev0;

    .line 187
    .line 188
    iget-byte v3, p0, Lav0;->m:B

    .line 189
    .line 190
    if-eqz v3, :cond_7

    .line 191
    .line 192
    if-eq v3, v7, :cond_6

    .line 193
    .line 194
    if-ne v3, v4, :cond_5

    .line 195
    .line 196
    iget-object p0, p0, Lav0;->n:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast p0, Lte4;

    .line 199
    .line 200
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    goto :goto_5

    .line 204
    :cond_5
    invoke-static {v1}, Ll42;->d(Ljava/lang/String;)V

    .line 205
    .line 206
    .line 207
    move-object v2, v6

    .line 208
    goto :goto_6

    .line 209
    :cond_6
    iget-object v1, p0, Lav0;->n:Ljava/lang/Object;

    .line 210
    .line 211
    check-cast v1, Lte4;

    .line 212
    .line 213
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    goto :goto_4

    .line 217
    :cond_7
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 218
    .line 219
    .line 220
    iget-object v1, v0, Lev0;->e:Lte4;

    .line 221
    .line 222
    iget-object p1, v0, Lev0;->a:Laf7;

    .line 223
    .line 224
    invoke-virtual {p1}, Laf7;->c()Lec7;

    .line 225
    .line 226
    .line 227
    move-result-object p1

    .line 228
    iget-object p1, p1, Lec7;->j:Ljava/lang/CharSequence;

    .line 229
    .line 230
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object p1

    .line 234
    iput-object v1, p0, Lav0;->n:Ljava/lang/Object;

    .line 235
    .line 236
    iput-byte v7, p0, Lav0;->m:B

    .line 237
    .line 238
    sget-object v3, Lzr1;->a:Lao1;

    .line 239
    .line 240
    sget-object v3, Lqn1;->j:Lqn1;

    .line 241
    .line 242
    new-instance v8, Lru;

    .line 243
    .line 244
    invoke-direct {v8, p1, v6, v7}, Lru;-><init>(Ljava/lang/String;Lxd1;B)V

    .line 245
    .line 246
    .line 247
    invoke-static {v3, v8, p0}, Lbw;->f0(Laj1;Lai2;Lxd1;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object p1

    .line 251
    if-eq p1, v2, :cond_8

    .line 252
    .line 253
    :goto_4
    invoke-interface {v1, p1}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 254
    .line 255
    .line 256
    iget-object p1, v0, Lev0;->f:Lte4;

    .line 257
    .line 258
    iget-object v0, v0, Lev0;->c:Laf7;

    .line 259
    .line 260
    invoke-virtual {v0}, Laf7;->c()Lec7;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    iget-object v0, v0, Lec7;->j:Ljava/lang/CharSequence;

    .line 265
    .line 266
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    iput-object p1, p0, Lav0;->n:Ljava/lang/Object;

    .line 271
    .line 272
    iput-byte v4, p0, Lav0;->m:B

    .line 273
    .line 274
    sget-object v1, Lzr1;->a:Lao1;

    .line 275
    .line 276
    sget-object v1, Lqn1;->j:Lqn1;

    .line 277
    .line 278
    new-instance v3, Lru;

    .line 279
    .line 280
    invoke-direct {v3, v0, v6, v7}, Lru;-><init>(Ljava/lang/String;Lxd1;B)V

    .line 281
    .line 282
    .line 283
    invoke-static {v1, v3, p0}, Lbw;->f0(Laj1;Lai2;Lxd1;)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object p0

    .line 287
    if-eq p0, v2, :cond_8

    .line 288
    .line 289
    move-object v9, p1

    .line 290
    move-object p1, p0

    .line 291
    move-object p0, v9

    .line 292
    :goto_5
    invoke-interface {p0, p1}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 293
    .line 294
    .line 295
    move-object v2, v5

    .line 296
    :cond_8
    :goto_6
    return-object v2

    .line 297
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
