.class public final synthetic Laq1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lro3;


# instance fields
.field public final synthetic h:Lcw5;

.field public final synthetic i:Landroid/hardware/SensorManager;

.field public final synthetic j:Lcq1;

.field public final synthetic k:Landroid/hardware/Sensor;

.field public final synthetic l:Lcw5;


# direct methods
.method public synthetic constructor <init>(Lcw5;Landroid/hardware/SensorManager;Lcq1;Landroid/hardware/Sensor;Lcw5;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Laq1;->h:Lcw5;

    .line 5
    .line 6
    iput-object p2, p0, Laq1;->i:Landroid/hardware/SensorManager;

    .line 7
    .line 8
    iput-object p3, p0, Laq1;->j:Lcq1;

    .line 9
    .line 10
    iput-object p4, p0, Laq1;->k:Landroid/hardware/Sensor;

    .line 11
    .line 12
    iput-object p5, p0, Laq1;->l:Lcw5;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final e(Lto3;Lko3;)V
    .locals 3

    .line 1
    sget-object p1, Lbq1;->a:[I

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    aget p1, p1, p2

    .line 8
    .line 9
    iget-object p2, p0, Laq1;->h:Lcw5;

    .line 10
    .line 11
    iget-object v0, p0, Laq1;->i:Landroid/hardware/SensorManager;

    .line 12
    .line 13
    iget-object v1, p0, Laq1;->j:Lcq1;

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    if-eq p1, v2, :cond_0

    .line 17
    .line 18
    const/4 v2, 0x2

    .line 19
    if-ne p1, v2, :cond_1

    .line 20
    .line 21
    iget-boolean p1, p2, Lcw5;->h:Z

    .line 22
    .line 23
    if-eqz p1, :cond_1

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V

    .line 26
    .line 27
    .line 28
    const/4 p1, 0x0

    .line 29
    iput-boolean p1, p2, Lcw5;->h:Z

    .line 30
    .line 31
    iget-object p0, p0, Laq1;->l:Lcw5;

    .line 32
    .line 33
    iput-boolean p1, p0, Lcw5;->h:Z

    .line 34
    .line 35
    return-void

    .line 36
    :cond_0
    iget-boolean p1, p2, Lcw5;->h:Z

    .line 37
    .line 38
    if-nez p1, :cond_1

    .line 39
    .line 40
    iget-object p0, p0, Laq1;->k:Landroid/hardware/Sensor;

    .line 41
    .line 42
    invoke-virtual {v0, v1, p0, v2}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z

    .line 43
    .line 44
    .line 45
    iput-boolean v2, p2, Lcw5;->h:Z

    .line 46
    .line 47
    :cond_1
    return-void
.end method
