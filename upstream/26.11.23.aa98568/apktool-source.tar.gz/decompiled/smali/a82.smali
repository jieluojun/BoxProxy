.class public final La82;
.super Lna2;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final v:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lv02;Lg61;Luj0;Luj0;Luj0;Luj0;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct/range {p0 .. p8}, Lna2;-><init>(Lv02;Lf61;Luj0;Luj0;Luj0;Luj0;Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    iput-object p9, p0, La82;->v:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final q()Ljava/lang/String;
    .locals 0

    .line 1
    const-string p0, "feImage"

    .line 2
    .line 3
    return-object p0
.end method
