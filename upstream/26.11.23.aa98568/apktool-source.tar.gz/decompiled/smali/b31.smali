.class public final synthetic Lb31;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lgi2;


# virtual methods
.method public final q(Ljava/lang/String;Ljava/lang/Boolean;Lqd1;Ljava/lang/Object;Ljava/lang/Object;Lzi2;Ljava/lang/Integer;)Ljava/lang/Object;
    .locals 3

    .line 1
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    check-cast p4, Lbi2;

    .line 6
    .line 7
    check-cast p5, Llh2;

    .line 8
    .line 9
    invoke-virtual {p7}, Ljava/lang/Integer;->intValue()I

    .line 10
    .line 11
    .line 12
    move-result p2

    .line 13
    and-int/lit8 p7, p2, 0x6

    .line 14
    .line 15
    move v0, p2

    .line 16
    move-object p2, p3

    .line 17
    sget-object p3, Lya4;->h:Lya4;

    .line 18
    .line 19
    if-nez p7, :cond_1

    .line 20
    .line 21
    invoke-virtual {p6, p3}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result p7

    .line 25
    if-eqz p7, :cond_0

    .line 26
    .line 27
    const/4 p7, 0x4

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 p7, 0x2

    .line 30
    :goto_0
    or-int/2addr p7, v0

    .line 31
    goto :goto_1

    .line 32
    :cond_1
    move p7, v0

    .line 33
    :goto_1
    and-int/lit8 v1, v0, 0x30

    .line 34
    .line 35
    if-nez v1, :cond_3

    .line 36
    .line 37
    invoke-virtual {p6, p1}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    const/16 v1, 0x20

    .line 44
    .line 45
    goto :goto_2

    .line 46
    :cond_2
    const/16 v1, 0x10

    .line 47
    .line 48
    :goto_2
    or-int/2addr p7, v1

    .line 49
    :cond_3
    and-int/lit16 v1, v0, 0x180

    .line 50
    .line 51
    if-nez v1, :cond_5

    .line 52
    .line 53
    invoke-virtual {p6, p0}, Lzi2;->h(Z)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-eqz v1, :cond_4

    .line 58
    .line 59
    const/16 v1, 0x100

    .line 60
    .line 61
    goto :goto_3

    .line 62
    :cond_4
    const/16 v1, 0x80

    .line 63
    .line 64
    :goto_3
    or-int/2addr p7, v1

    .line 65
    :cond_5
    and-int/lit16 v1, v0, 0xc00

    .line 66
    .line 67
    if-nez v1, :cond_7

    .line 68
    .line 69
    invoke-virtual {p6, p2}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-eqz v1, :cond_6

    .line 74
    .line 75
    const/16 v1, 0x800

    .line 76
    .line 77
    goto :goto_4

    .line 78
    :cond_6
    const/16 v1, 0x400

    .line 79
    .line 80
    :goto_4
    or-int/2addr p7, v1

    .line 81
    :cond_7
    and-int/lit16 v1, v0, 0x6000

    .line 82
    .line 83
    if-nez v1, :cond_9

    .line 84
    .line 85
    invoke-virtual {p6, p4}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v1

    .line 89
    if-eqz v1, :cond_8

    .line 90
    .line 91
    const/16 v1, 0x4000

    .line 92
    .line 93
    goto :goto_5

    .line 94
    :cond_8
    const/16 v1, 0x2000

    .line 95
    .line 96
    :goto_5
    or-int/2addr p7, v1

    .line 97
    :cond_9
    const/high16 v1, 0x30000

    .line 98
    .line 99
    and-int/2addr v0, v1

    .line 100
    if-nez v0, :cond_b

    .line 101
    .line 102
    invoke-virtual {p6, p5}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-eqz v0, :cond_a

    .line 107
    .line 108
    const/high16 v0, 0x20000

    .line 109
    .line 110
    goto :goto_6

    .line 111
    :cond_a
    const/high16 v0, 0x10000

    .line 112
    .line 113
    :goto_6
    or-int/2addr p7, v0

    .line 114
    :cond_b
    const v0, 0x92493

    .line 115
    .line 116
    .line 117
    and-int/2addr v0, p7

    .line 118
    const v1, 0x92492

    .line 119
    .line 120
    .line 121
    if-eq v0, v1, :cond_c

    .line 122
    .line 123
    const/4 v0, 0x1

    .line 124
    goto :goto_7

    .line 125
    :cond_c
    const/4 v0, 0x0

    .line 126
    :goto_7
    and-int/lit8 v1, p7, 0x1

    .line 127
    .line 128
    invoke-virtual {p6, v1, v0}, Lzi2;->Y(IZ)Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    if-eqz v0, :cond_d

    .line 133
    .line 134
    shr-int/lit8 v0, p7, 0x3

    .line 135
    .line 136
    and-int/lit16 v0, v0, 0x3fe

    .line 137
    .line 138
    shl-int/lit8 v1, p7, 0x9

    .line 139
    .line 140
    and-int/lit16 v1, v1, 0x1c00

    .line 141
    .line 142
    or-int/2addr v0, v1

    .line 143
    const v1, 0xe000

    .line 144
    .line 145
    .line 146
    and-int/2addr v1, p7

    .line 147
    or-int/2addr v0, v1

    .line 148
    const/high16 v1, 0x70000

    .line 149
    .line 150
    and-int/2addr p7, v1

    .line 151
    or-int/2addr p7, v0

    .line 152
    move-object v2, p1

    .line 153
    move p1, p0

    .line 154
    move-object p0, v2

    .line 155
    invoke-static/range {p0 .. p7}, Ltd1;->c(Ljava/lang/String;ZLqd1;Lbb4;Lbi2;Llh2;Lzi2;I)V

    .line 156
    .line 157
    .line 158
    goto :goto_8

    .line 159
    :cond_d
    invoke-virtual {p6}, Lzi2;->b0()V

    .line 160
    .line 161
    .line 162
    :goto_8
    sget-object p0, Lst7;->a:Lst7;

    .line 163
    .line 164
    return-object p0
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
.end method
