.class public final synthetic Lap5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:Lyp5;

.field public final synthetic i:I

.field public final synthetic j:Lxk5;

.field public final synthetic k:Z

.field public final synthetic l:Lmp5;

.field public final synthetic m:Lqp5;

.field public final synthetic n:Ljava/util/Map;

.field public final synthetic o:Ljava/util/Map;

.field public final synthetic p:Ljava/util/Map;

.field public final synthetic q:Ljava/util/Set;

.field public final synthetic r:Ljava/util/Map;

.field public final synthetic s:Ljava/util/Set;

.field public final synthetic t:Lwh2;

.field public final synthetic u:Lwh2;

.field public final synthetic v:Lwh2;

.field public final synthetic w:Lai2;

.field public final synthetic x:Lwh2;

.field public final synthetic y:Lte4;


# direct methods
.method public synthetic constructor <init>(Lyp5;ILxk5;ZLmp5;Lqp5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Ljava/util/Set;Lwh2;Lwh2;Lwh2;Lai2;Lwh2;Lte4;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lap5;->h:Lyp5;

    .line 5
    .line 6
    iput p2, p0, Lap5;->i:I

    .line 7
    .line 8
    iput-object p3, p0, Lap5;->j:Lxk5;

    .line 9
    .line 10
    iput-boolean p4, p0, Lap5;->k:Z

    .line 11
    .line 12
    iput-object p5, p0, Lap5;->l:Lmp5;

    .line 13
    .line 14
    iput-object p6, p0, Lap5;->m:Lqp5;

    .line 15
    .line 16
    iput-object p7, p0, Lap5;->n:Ljava/util/Map;

    .line 17
    .line 18
    iput-object p8, p0, Lap5;->o:Ljava/util/Map;

    .line 19
    .line 20
    iput-object p9, p0, Lap5;->p:Ljava/util/Map;

    .line 21
    .line 22
    iput-object p10, p0, Lap5;->q:Ljava/util/Set;

    .line 23
    .line 24
    iput-object p11, p0, Lap5;->r:Ljava/util/Map;

    .line 25
    .line 26
    iput-object p12, p0, Lap5;->s:Ljava/util/Set;

    .line 27
    .line 28
    iput-object p13, p0, Lap5;->t:Lwh2;

    .line 29
    .line 30
    iput-object p14, p0, Lap5;->u:Lwh2;

    .line 31
    .line 32
    iput-object p15, p0, Lap5;->v:Lwh2;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lap5;->w:Lai2;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Lap5;->x:Lwh2;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lap5;->y:Lte4;

    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lm45;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Lzi2;

    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 23
    .line 24
    if-nez v4, :cond_1

    .line 25
    .line 26
    invoke-virtual {v2, v1}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-eqz v4, :cond_0

    .line 31
    .line 32
    const/4 v4, 0x4

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const/4 v4, 0x2

    .line 35
    :goto_0
    or-int/2addr v3, v4

    .line 36
    :cond_1
    and-int/lit8 v4, v3, 0x13

    .line 37
    .line 38
    const/16 v5, 0x12

    .line 39
    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x1

    .line 42
    if-eq v4, v5, :cond_2

    .line 43
    .line 44
    move v4, v7

    .line 45
    goto :goto_1

    .line 46
    :cond_2
    move v4, v6

    .line 47
    :goto_1
    and-int/2addr v3, v7

    .line 48
    invoke-virtual {v2, v3, v4}, Lzi2;->Y(IZ)Z

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    if-eqz v3, :cond_6

    .line 53
    .line 54
    sget-object v3, Lya4;->h:Lya4;

    .line 55
    .line 56
    const/high16 v4, 0x3f800000    # 1.0f

    .line 57
    .line 58
    invoke-static {v3, v4}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    const/high16 v4, 0x44340000    # 720.0f

    .line 63
    .line 64
    const/4 v5, 0x0

    .line 65
    invoke-static {v3, v5, v4, v7}, Lxt6;->g(Lbb4;FFI)Lbb4;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    sget-object v4, Lob3;->g:Llw;

    .line 70
    .line 71
    sget-object v5, Ly6;->v:Lz30;

    .line 72
    .line 73
    invoke-static {v4, v5, v2, v6}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    iget-wide v5, v2, Lzi2;->U:J

    .line 78
    .line 79
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    invoke-virtual {v2}, Lzi2;->m()Lla5;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    invoke-static {v2, v3}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    sget-object v8, Ls41;->d:Ly6;

    .line 92
    .line 93
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v2}, Lzi2;->k0()V

    .line 97
    .line 98
    .line 99
    iget-boolean v8, v2, Lzi2;->T:Z

    .line 100
    .line 101
    if-eqz v8, :cond_3

    .line 102
    .line 103
    sget-object v8, Lzi3;->Z:Lu43;

    .line 104
    .line 105
    invoke-virtual {v2, v8}, Lzi2;->l(Llh2;)V

    .line 106
    .line 107
    .line 108
    goto :goto_2

    .line 109
    :cond_3
    invoke-virtual {v2}, Lzi2;->t0()V

    .line 110
    .line 111
    .line 112
    :goto_2
    sget-object v8, Ly6;->T:Lx31;

    .line 113
    .line 114
    invoke-static {v8, v2, v4}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    sget-object v4, Ly6;->S:Lx31;

    .line 118
    .line 119
    invoke-static {v4, v2, v6}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 123
    .line 124
    .line 125
    move-result-object v4

    .line 126
    sget-object v5, Ly6;->U:Lx31;

    .line 127
    .line 128
    invoke-static {v5, v2, v4}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    invoke-static {v2}, Lfa7;->k(Lzi2;)V

    .line 132
    .line 133
    .line 134
    sget-object v4, Ly6;->R:Lx31;

    .line 135
    .line 136
    invoke-static {v4, v2, v3}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v2}, Lzi2;->T()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    sget-object v4, Lc51;->a:Lql0;

    .line 144
    .line 145
    if-ne v3, v4, :cond_4

    .line 146
    .line 147
    new-instance v3, Lbl5;

    .line 148
    .line 149
    const/16 v5, 0xe

    .line 150
    .line 151
    invoke-direct {v3, v5}, Lbl5;-><init>(B)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v2, v3}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    :cond_4
    move-object/from16 v20, v3

    .line 158
    .line 159
    check-cast v20, Lwh2;

    .line 160
    .line 161
    invoke-virtual {v2}, Lzi2;->T()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v3

    .line 165
    if-ne v3, v4, :cond_5

    .line 166
    .line 167
    new-instance v3, Lbl5;

    .line 168
    .line 169
    const/16 v4, 0xf

    .line 170
    .line 171
    invoke-direct {v3, v4}, Lbl5;-><init>(B)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v2, v3}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    :cond_5
    move-object/from16 v21, v3

    .line 178
    .line 179
    check-cast v21, Lwh2;

    .line 180
    .line 181
    new-instance v3, Lzo5;

    .line 182
    .line 183
    move-object v9, v2

    .line 184
    iget v2, v0, Lap5;->i:I

    .line 185
    .line 186
    move-object v4, v3

    .line 187
    iget-object v3, v0, Lap5;->j:Lxk5;

    .line 188
    .line 189
    move-object v5, v4

    .line 190
    iget-boolean v4, v0, Lap5;->k:Z

    .line 191
    .line 192
    move-object v6, v5

    .line 193
    iget-object v5, v0, Lap5;->l:Lmp5;

    .line 194
    .line 195
    move-object v8, v6

    .line 196
    iget-object v6, v0, Lap5;->m:Lqp5;

    .line 197
    .line 198
    iget-object v7, v0, Lap5;->n:Ljava/util/Map;

    .line 199
    .line 200
    move-object v11, v8

    .line 201
    iget-object v8, v0, Lap5;->o:Ljava/util/Map;

    .line 202
    .line 203
    move-object v12, v9

    .line 204
    iget-object v9, v0, Lap5;->p:Ljava/util/Map;

    .line 205
    .line 206
    iget-object v10, v0, Lap5;->q:Ljava/util/Set;

    .line 207
    .line 208
    move-object v14, v11

    .line 209
    iget-object v11, v0, Lap5;->r:Ljava/util/Map;

    .line 210
    .line 211
    move-object v15, v12

    .line 212
    iget-object v12, v0, Lap5;->s:Ljava/util/Set;

    .line 213
    .line 214
    iget-object v13, v0, Lap5;->t:Lwh2;

    .line 215
    .line 216
    move-object/from16 v17, v14

    .line 217
    .line 218
    iget-object v14, v0, Lap5;->u:Lwh2;

    .line 219
    .line 220
    move-object/from16 v18, v15

    .line 221
    .line 222
    iget-object v15, v0, Lap5;->v:Lwh2;

    .line 223
    .line 224
    move-object/from16 p1, v1

    .line 225
    .line 226
    iget-object v1, v0, Lap5;->w:Lai2;

    .line 227
    .line 228
    move-object/from16 v19, v1

    .line 229
    .line 230
    iget-object v1, v0, Lap5;->x:Lwh2;

    .line 231
    .line 232
    move-object/from16 p2, v1

    .line 233
    .line 234
    iget-object v1, v0, Lap5;->h:Lyp5;

    .line 235
    .line 236
    iget-object v0, v0, Lap5;->y:Lte4;

    .line 237
    .line 238
    move-object/from16 v22, v18

    .line 239
    .line 240
    move-object/from16 v16, v19

    .line 241
    .line 242
    move-object/from16 v19, v0

    .line 243
    .line 244
    move-object/from16 v18, v1

    .line 245
    .line 246
    move-object/from16 v0, v17

    .line 247
    .line 248
    move-object/from16 v1, p1

    .line 249
    .line 250
    move-object/from16 v17, p2

    .line 251
    .line 252
    invoke-direct/range {v0 .. v19}, Lzo5;-><init>(Lm45;ILxk5;ZLmp5;Lqp5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Ljava/util/Set;Lwh2;Lwh2;Lwh2;Lai2;Lwh2;Lyp5;Lte4;)V

    .line 253
    .line 254
    .line 255
    move-object v14, v0

    .line 256
    const v0, 0x18502b7c

    .line 257
    .line 258
    .line 259
    move-object/from16 v9, v22

    .line 260
    .line 261
    invoke-static {v0, v14, v9}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 262
    .line 263
    .line 264
    move-result-object v8

    .line 265
    const v10, 0x1b6180

    .line 266
    .line 267
    .line 268
    const/16 v11, 0xa

    .line 269
    .line 270
    const/4 v3, 0x0

    .line 271
    const/4 v5, 0x0

    .line 272
    const-string v6, "policy-bottom-sheet-content"

    .line 273
    .line 274
    move-object/from16 v2, v18

    .line 275
    .line 276
    move-object/from16 v4, v20

    .line 277
    .line 278
    move-object/from16 v7, v21

    .line 279
    .line 280
    invoke-static/range {v2 .. v11}, Lru7;->F(Ljava/lang/Object;Lbb4;Lwh2;Lb40;Ljava/lang/String;Lwh2;Ls21;Lzi2;II)V

    .line 281
    .line 282
    .line 283
    const/4 v13, 0x1

    .line 284
    invoke-virtual {v9, v13}, Lzi2;->r(Z)V

    .line 285
    .line 286
    .line 287
    goto :goto_3

    .line 288
    :cond_6
    move-object v9, v2

    .line 289
    invoke-virtual {v9}, Lzi2;->b0()V

    .line 290
    .line 291
    .line 292
    :goto_3
    sget-object v0, Lst7;->a:Lst7;

    .line 293
    .line 294
    return-object v0
.end method
