.class public final synthetic La14;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:Lbb4;

.field public final synthetic i:J

.field public final synthetic j:Ls21;

.field public final synthetic k:I

.field public final synthetic l:B


# direct methods
.method public synthetic constructor <init>(Lbb4;JLs21;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La14;->h:Lbb4;

    .line 5
    .line 6
    iput-wide p2, p0, La14;->i:J

    .line 7
    .line 8
    iput-object p4, p0, La14;->j:Ls21;

    .line 9
    .line 10
    iput p5, p0, La14;->k:I

    .line 11
    .line 12
    iput-byte p6, p0, La14;->l:B

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    move-object v4, p1

    .line 2
    check-cast v4, Lzi2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, La14;->k:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lyj3;->j0(I)I

    .line 14
    .line 15
    .line 16
    move-result v5

    .line 17
    iget-object v0, p0, La14;->h:Lbb4;

    .line 18
    .line 19
    iget-wide v1, p0, La14;->i:J

    .line 20
    .line 21
    iget-object v3, p0, La14;->j:Ls21;

    .line 22
    .line 23
    iget-byte v6, p0, La14;->l:B

    .line 24
    .line 25
    invoke-static/range {v0 .. v6}, Lb14;->g(Lbb4;JLs21;Lzi2;II)V

    .line 26
    .line 27
    .line 28
    sget-object p0, Lst7;->a:Lst7;

    .line 29
    .line 30
    return-object p0
.end method
