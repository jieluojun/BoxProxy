.class public abstract Lai5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:Lux1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lf75;

    .line 2
    .line 3
    const/16 v1, 0xa

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lf75;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lux1;

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-direct {v1, v0, v2}, Lux1;-><init>(Llh2;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Lai5;->a:Lux1;

    .line 15
    .line 16
    return-void
.end method
