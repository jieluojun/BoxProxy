.class public final La73;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lvi;


# instance fields
.field public final a:Lmx1;

.field public final b:Lhy5;

.field public final c:J


# direct methods
.method public constructor <init>(Lmx1;Lhy5;J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La73;->a:Lmx1;

    .line 5
    .line 6
    iput-object p2, p0, La73;->b:Lhy5;

    .line 7
    .line 8
    iput-wide p3, p0, La73;->c:J

    .line 9
    .line 10
    instance-of p0, p1, Lqp7;

    .line 11
    .line 12
    if-eqz p0, :cond_0

    .line 13
    .line 14
    check-cast p1, Lqp7;

    .line 15
    .line 16
    iget p0, p1, Lqp7;->a:I

    .line 17
    .line 18
    if-nez p0, :cond_3

    .line 19
    .line 20
    iget p0, p1, Lqp7;->b:I

    .line 21
    .line 22
    if-eqz p0, :cond_2

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    instance-of p0, p1, Lsv6;

    .line 26
    .line 27
    if-eqz p0, :cond_1

    .line 28
    .line 29
    check-cast p1, Lsv6;

    .line 30
    .line 31
    iget-byte p0, p1, Lsv6;->a:B

    .line 32
    .line 33
    if-eqz p0, :cond_2

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    instance-of p0, p1, Lzg3;

    .line 37
    .line 38
    if-eqz p0, :cond_3

    .line 39
    .line 40
    check-cast p1, Lzg3;

    .line 41
    .line 42
    iget-object p0, p1, Lzg3;->a:Lyg3;

    .line 43
    .line 44
    iget-short p0, p0, Lyg3;->a:S

    .line 45
    .line 46
    if-nez p0, :cond_3

    .line 47
    .line 48
    :cond_2
    const-string p0, "Animation to be infinitely repeated cannot have a 0-duration"

    .line 49
    .line 50
    invoke-static {p0}, Ll42;->g(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    const/4 p0, 0x0

    .line 54
    throw p0

    .line 55
    :cond_3
    :goto_0
    return-void
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method


# virtual methods
.method public final a(Ltp7;)Lqv7;
    .locals 4

    .line 1
    new-instance v0, Lhv5;

    .line 2
    .line 3
    iget-object v1, p0, La73;->a:Lmx1;

    .line 4
    .line 5
    invoke-interface {v1, p1}, Lmx1;->a(Ltp7;)Lsv7;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iget-object v1, p0, La73;->b:Lhy5;

    .line 10
    .line 11
    iget-wide v2, p0, La73;->c:J

    .line 12
    .line 13
    invoke-direct {v0, p1, v1, v2, v3}, Lhv5;-><init>(Lsv7;Lhy5;J)V

    .line 14
    .line 15
    .line 16
    return-object v0
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    instance-of v0, p1, La73;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    check-cast p1, La73;

    .line 7
    .line 8
    iget-object v0, p1, La73;->a:Lmx1;

    .line 9
    .line 10
    iget-object v2, p0, La73;->a:Lmx1;

    .line 11
    .line 12
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    iget-object v0, p1, La73;->b:Lhy5;

    .line 19
    .line 20
    iget-object v2, p0, La73;->b:Lhy5;

    .line 21
    .line 22
    if-ne v0, v2, :cond_0

    .line 23
    .line 24
    iget-wide v2, p1, La73;->c:J

    .line 25
    .line 26
    iget-wide p0, p0, La73;->c:J

    .line 27
    .line 28
    cmp-long p0, v2, p0

    .line 29
    .line 30
    if-nez p0, :cond_0

    .line 31
    .line 32
    const/4 p0, 0x1

    .line 33
    return p0

    .line 34
    :cond_0
    return v1
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final hashCode()I
    .locals 4

    .line 1
    iget-object v0, p0, La73;->a:Lmx1;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, La73;->b:Lhy5;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-wide v2, p0, La73;->c:J

    .line 19
    .line 20
    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    add-int/2addr p0, v1

    .line 25
    return p0
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
