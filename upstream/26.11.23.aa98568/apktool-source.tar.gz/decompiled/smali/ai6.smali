.class public final Lai6;
.super Lqj3;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final synthetic c:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lai6;->c:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c0(Lsz3;[BIIIIII)I
    .locals 14

    .line 1
    move-object/from16 v2, p2

    .line 2
    .line 3
    move/from16 v8, p3

    .line 4
    .line 5
    move/from16 v9, p4

    .line 6
    .line 7
    move/from16 v4, p5

    .line 8
    .line 9
    move/from16 v1, p6

    .line 10
    .line 11
    iget-byte p0, p0, Lai6;->c:B

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    const/4 v5, 0x1

    .line 15
    const/4 v10, -0x1

    .line 16
    packed-switch p0, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    iget-object p0, p1, Lsz3;->d:Ldx5;

    .line 20
    .line 21
    iget-object v0, p0, Ldx5;->p:Lms7;

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Ldx5;->A:[B

    .line 27
    .line 28
    iget p0, p0, Ldx5;->B:I

    .line 29
    .line 30
    sub-int p0, v4, p0

    .line 31
    .line 32
    if-le p0, v1, :cond_0

    .line 33
    .line 34
    move p0, v1

    .line 35
    :cond_0
    if-ge p0, v8, :cond_1

    .line 36
    .line 37
    return v10

    .line 38
    :cond_1
    aget-byte v0, v0, v3

    .line 39
    .line 40
    aget-byte p0, v2, p0

    .line 41
    .line 42
    const/4 p0, 0x0

    .line 43
    throw p0

    .line 44
    :pswitch_0
    iget-object p0, p1, Lsz3;->d:Ldx5;

    .line 45
    .line 46
    iget-object v5, p0, Ldx5;->p:Lms7;

    .line 47
    .line 48
    iget-object v3, p0, Ldx5;->A:[B

    .line 49
    .line 50
    iget v6, p0, Ldx5;->B:I

    .line 51
    .line 52
    sub-int v7, v4, v6

    .line 53
    .line 54
    if-gt v7, v1, :cond_2

    .line 55
    .line 56
    invoke-virtual {v5, v9, v7, v4, v2}, Lms7;->i(III[B)I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    :cond_2
    iget-object v7, p1, Lsz3;->p:[B

    .line 61
    .line 62
    if-nez v7, :cond_3

    .line 63
    .line 64
    const/16 v7, 0x12

    .line 65
    .line 66
    new-array v7, v7, [B

    .line 67
    .line 68
    iput-object v7, p1, Lsz3;->p:[B

    .line 69
    .line 70
    :cond_3
    :goto_0
    if-lt v1, v8, :cond_5

    .line 71
    .line 72
    move-object v0, v3

    .line 73
    move v3, v1

    .line 74
    move v1, v6

    .line 75
    move-object v6, v7

    .line 76
    iget v7, p0, Ldx5;->r:I

    .line 77
    .line 78
    invoke-static/range {v0 .. v7}, Lbi6;->a([BI[BIILms7;[BI)Z

    .line 79
    .line 80
    .line 81
    move-result v7

    .line 82
    if-eqz v7, :cond_4

    .line 83
    .line 84
    move v10, v3

    .line 85
    goto :goto_1

    .line 86
    :cond_4
    invoke-virtual {v5, v9, v3, v4, v2}, Lf3;->l(III[B)I

    .line 87
    .line 88
    .line 89
    move-result v3

    .line 90
    move-object v7, v6

    .line 91
    move v6, v1

    .line 92
    move v1, v3

    .line 93
    move-object v3, v0

    .line 94
    goto :goto_0

    .line 95
    :cond_5
    :goto_1
    return v10

    .line 96
    :pswitch_1
    iget-object p0, p1, Lsz3;->d:Ldx5;

    .line 97
    .line 98
    iget-object v0, p0, Ldx5;->A:[B

    .line 99
    .line 100
    iget p0, p0, Ldx5;->B:I

    .line 101
    .line 102
    sub-int/2addr v4, p0

    .line 103
    if-gt v4, v1, :cond_6

    .line 104
    .line 105
    move v1, v4

    .line 106
    :cond_6
    :goto_2
    if-lt v1, v8, :cond_9

    .line 107
    .line 108
    aget-byte v4, v2, v1

    .line 109
    .line 110
    aget-byte v6, v0, v3

    .line 111
    .line 112
    if-ne v4, v6, :cond_8

    .line 113
    .line 114
    add-int/lit8 v4, v1, 0x1

    .line 115
    .line 116
    move v6, v5

    .line 117
    :goto_3
    if-ge v6, p0, :cond_7

    .line 118
    .line 119
    aget-byte v7, v0, v6

    .line 120
    .line 121
    add-int/lit8 v9, v4, 0x1

    .line 122
    .line 123
    aget-byte v4, v2, v4

    .line 124
    .line 125
    if-ne v7, v4, :cond_7

    .line 126
    .line 127
    add-int/lit8 v6, v6, 0x1

    .line 128
    .line 129
    move v4, v9

    .line 130
    goto :goto_3

    .line 131
    :cond_7
    if-ne v6, p0, :cond_8

    .line 132
    .line 133
    move v10, v1

    .line 134
    goto :goto_4

    .line 135
    :cond_8
    add-int/lit8 v1, v1, -0x1

    .line 136
    .line 137
    goto :goto_2

    .line 138
    :cond_9
    :goto_4
    return v10

    .line 139
    :pswitch_2
    iget-object p0, p1, Lsz3;->d:Ldx5;

    .line 140
    .line 141
    iget-object v0, p0, Ldx5;->p:Lms7;

    .line 142
    .line 143
    iget-object v6, p0, Ldx5;->A:[B

    .line 144
    .line 145
    iget p0, p0, Ldx5;->B:I

    .line 146
    .line 147
    sub-int v7, v4, p0

    .line 148
    .line 149
    if-gt v7, v1, :cond_a

    .line 150
    .line 151
    invoke-virtual {v0, v9, v7, v4, v2}, Lms7;->i(III[B)I

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    :cond_a
    :goto_5
    if-lt v1, v8, :cond_d

    .line 156
    .line 157
    aget-byte v7, v2, v1

    .line 158
    .line 159
    aget-byte v11, v6, v3

    .line 160
    .line 161
    if-ne v7, v11, :cond_c

    .line 162
    .line 163
    add-int/lit8 v7, v1, 0x1

    .line 164
    .line 165
    move v11, v5

    .line 166
    :goto_6
    if-ge v11, p0, :cond_b

    .line 167
    .line 168
    aget-byte v12, v6, v11

    .line 169
    .line 170
    add-int/lit8 v13, v7, 0x1

    .line 171
    .line 172
    aget-byte v7, v2, v7

    .line 173
    .line 174
    if-ne v12, v7, :cond_b

    .line 175
    .line 176
    add-int/lit8 v11, v11, 0x1

    .line 177
    .line 178
    move v7, v13

    .line 179
    goto :goto_6

    .line 180
    :cond_b
    if-ne v11, p0, :cond_c

    .line 181
    .line 182
    move v10, v1

    .line 183
    goto :goto_7

    .line 184
    :cond_c
    invoke-virtual {v0, v9, v1, v4, v2}, Lf3;->l(III[B)I

    .line 185
    .line 186
    .line 187
    move-result v1

    .line 188
    goto :goto_5

    .line 189
    :cond_d
    :goto_7
    return v10

    .line 190
    :pswitch_3
    iget-object p0, p1, Lsz3;->d:Ldx5;

    .line 191
    .line 192
    iget-object p0, p0, Ldx5;->C:[B

    .line 193
    .line 194
    if-lt v1, v4, :cond_e

    .line 195
    .line 196
    add-int/lit8 v0, v4, -0x1

    .line 197
    .line 198
    goto :goto_8

    .line 199
    :cond_e
    move v0, v1

    .line 200
    :goto_8
    if-lt v0, v8, :cond_10

    .line 201
    .line 202
    aget-byte v1, v2, v0

    .line 203
    .line 204
    and-int/lit16 v1, v1, 0xff

    .line 205
    .line 206
    aget-byte v1, p0, v1

    .line 207
    .line 208
    if-eqz v1, :cond_f

    .line 209
    .line 210
    move v10, v0

    .line 211
    goto :goto_9

    .line 212
    :cond_f
    add-int/lit8 v0, v0, -0x1

    .line 213
    .line 214
    goto :goto_8

    .line 215
    :cond_10
    :goto_9
    return v10

    .line 216
    :pswitch_4
    iget-object p0, p1, Lsz3;->d:Ldx5;

    .line 217
    .line 218
    iget-object v0, p0, Ldx5;->p:Lms7;

    .line 219
    .line 220
    iget-object p0, p0, Ldx5;->C:[B

    .line 221
    .line 222
    if-lt v1, v4, :cond_11

    .line 223
    .line 224
    add-int/lit8 v1, v4, -0x1

    .line 225
    .line 226
    :cond_11
    :goto_a
    if-lt v1, v8, :cond_13

    .line 227
    .line 228
    aget-byte v3, v2, v1

    .line 229
    .line 230
    and-int/lit16 v3, v3, 0xff

    .line 231
    .line 232
    aget-byte v3, p0, v3

    .line 233
    .line 234
    if-eqz v3, :cond_12

    .line 235
    .line 236
    move v10, v1

    .line 237
    goto :goto_b

    .line 238
    :cond_12
    invoke-virtual {v0, v9, v1, v4, v2}, Lf3;->l(III[B)I

    .line 239
    .line 240
    .line 241
    move-result v1

    .line 242
    goto :goto_a

    .line 243
    :cond_13
    :goto_b
    return v10

    .line 244
    nop

    .line 245
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
