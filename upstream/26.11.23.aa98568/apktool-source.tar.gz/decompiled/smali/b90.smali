.class public final synthetic Lb90;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:Lck4;

.field public final synthetic i:F

.field public final synthetic j:Z


# direct methods
.method public synthetic constructor <init>(Lck4;FZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb90;->h:Lck4;

    .line 5
    .line 6
    iput p2, p0, Lb90;->i:F

    .line 7
    .line 8
    iput-boolean p3, p0, Lb90;->j:Z

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v13, p1

    .line 4
    .line 5
    check-cast v13, Lzi2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    and-int/lit8 v2, v1, 0x3

    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    const/4 v4, 0x1

    .line 19
    const/4 v5, 0x2

    .line 20
    if-eq v2, v5, :cond_0

    .line 21
    .line 22
    move v2, v4

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    move v2, v3

    .line 25
    :goto_0
    and-int/2addr v1, v4

    .line 26
    invoke-virtual {v13, v1, v2}, Lzi2;->Y(IZ)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_17

    .line 31
    .line 32
    iget-object v1, v0, Lb90;->h:Lck4;

    .line 33
    .line 34
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v6

    .line 42
    sget-object v7, Lc51;->a:Lql0;

    .line 43
    .line 44
    if-nez v2, :cond_1

    .line 45
    .line 46
    if-ne v6, v7, :cond_2

    .line 47
    .line 48
    :cond_1
    new-instance v6, Lz80;

    .line 49
    .line 50
    const/16 v2, 0x1b

    .line 51
    .line 52
    invoke-direct {v6, v1, v2}, Lz80;-><init>(Lck4;B)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v13, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    :cond_2
    check-cast v6, Llh2;

    .line 59
    .line 60
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v8

    .line 68
    if-nez v2, :cond_3

    .line 69
    .line 70
    if-ne v8, v7, :cond_4

    .line 71
    .line 72
    :cond_3
    new-instance v8, Lz80;

    .line 73
    .line 74
    const/16 v2, 0x1d

    .line 75
    .line 76
    invoke-direct {v8, v1, v2}, Lz80;-><init>(Lck4;B)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v13, v8}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_4
    check-cast v8, Llh2;

    .line 83
    .line 84
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v2

    .line 88
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v9

    .line 92
    if-nez v2, :cond_5

    .line 93
    .line 94
    if-ne v9, v7, :cond_6

    .line 95
    .line 96
    :cond_5
    new-instance v9, Lg90;

    .line 97
    .line 98
    invoke-direct {v9, v1, v3}, Lg90;-><init>(Lck4;B)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v13, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    :cond_6
    move-object v2, v9

    .line 105
    check-cast v2, Llh2;

    .line 106
    .line 107
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v9

    .line 115
    if-nez v3, :cond_7

    .line 116
    .line 117
    if-ne v9, v7, :cond_8

    .line 118
    .line 119
    :cond_7
    new-instance v9, Lg90;

    .line 120
    .line 121
    invoke-direct {v9, v1, v4}, Lg90;-><init>(Lck4;B)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v13, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    :cond_8
    move-object v3, v9

    .line 128
    check-cast v3, Llh2;

    .line 129
    .line 130
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v4

    .line 134
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v9

    .line 138
    if-nez v4, :cond_9

    .line 139
    .line 140
    if-ne v9, v7, :cond_a

    .line 141
    .line 142
    :cond_9
    new-instance v9, Lg90;

    .line 143
    .line 144
    invoke-direct {v9, v1, v5}, Lg90;-><init>(Lck4;B)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v13, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_a
    move-object v4, v9

    .line 151
    check-cast v4, Llh2;

    .line 152
    .line 153
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v5

    .line 157
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v9

    .line 161
    if-nez v5, :cond_b

    .line 162
    .line 163
    if-ne v9, v7, :cond_c

    .line 164
    .line 165
    :cond_b
    new-instance v9, Lg90;

    .line 166
    .line 167
    const/4 v5, 0x3

    .line 168
    invoke-direct {v9, v1, v5}, Lg90;-><init>(Lck4;B)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v13, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    :cond_c
    move-object v5, v9

    .line 175
    check-cast v5, Llh2;

    .line 176
    .line 177
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 178
    .line 179
    .line 180
    move-result v9

    .line 181
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v10

    .line 185
    if-nez v9, :cond_d

    .line 186
    .line 187
    if-ne v10, v7, :cond_e

    .line 188
    .line 189
    :cond_d
    new-instance v10, Lg90;

    .line 190
    .line 191
    const/4 v9, 0x4

    .line 192
    invoke-direct {v10, v1, v9}, Lg90;-><init>(Lck4;B)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v13, v10}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    :cond_e
    check-cast v10, Llh2;

    .line 199
    .line 200
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    move-result v9

    .line 204
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v11

    .line 208
    if-nez v9, :cond_f

    .line 209
    .line 210
    if-ne v11, v7, :cond_10

    .line 211
    .line 212
    :cond_f
    new-instance v11, Lg90;

    .line 213
    .line 214
    const/4 v9, 0x6

    .line 215
    invoke-direct {v11, v1, v9}, Lg90;-><init>(Lck4;B)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v13, v11}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 219
    .line 220
    .line 221
    :cond_10
    check-cast v11, Llh2;

    .line 222
    .line 223
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 224
    .line 225
    .line 226
    move-result v9

    .line 227
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v12

    .line 231
    if-nez v9, :cond_11

    .line 232
    .line 233
    if-ne v12, v7, :cond_12

    .line 234
    .line 235
    :cond_11
    new-instance v12, Lg90;

    .line 236
    .line 237
    const/4 v9, 0x7

    .line 238
    invoke-direct {v12, v1, v9}, Lg90;-><init>(Lck4;B)V

    .line 239
    .line 240
    .line 241
    invoke-virtual {v13, v12}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 242
    .line 243
    .line 244
    :cond_12
    check-cast v12, Llh2;

    .line 245
    .line 246
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 247
    .line 248
    .line 249
    move-result v9

    .line 250
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v14

    .line 254
    if-nez v9, :cond_13

    .line 255
    .line 256
    if-ne v14, v7, :cond_14

    .line 257
    .line 258
    :cond_13
    new-instance v14, Lg90;

    .line 259
    .line 260
    const/16 v9, 0x8

    .line 261
    .line 262
    invoke-direct {v14, v1, v9}, Lg90;-><init>(Lck4;B)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {v13, v14}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    :cond_14
    move-object v9, v14

    .line 269
    check-cast v9, Llh2;

    .line 270
    .line 271
    invoke-virtual {v13, v1}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v14

    .line 275
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object v15

    .line 279
    if-nez v14, :cond_15

    .line 280
    .line 281
    if-ne v15, v7, :cond_16

    .line 282
    .line 283
    :cond_15
    new-instance v15, Lz80;

    .line 284
    .line 285
    const/16 v7, 0x1c

    .line 286
    .line 287
    invoke-direct {v15, v1, v7}, Lz80;-><init>(Lck4;B)V

    .line 288
    .line 289
    .line 290
    invoke-virtual {v13, v15}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 291
    .line 292
    .line 293
    :cond_16
    check-cast v15, Llh2;

    .line 294
    .line 295
    const/4 v14, 0x0

    .line 296
    move-object v7, v11

    .line 297
    iget v11, v0, Lb90;->i:F

    .line 298
    .line 299
    iget-boolean v0, v0, Lb90;->j:Z

    .line 300
    .line 301
    move-object v1, v8

    .line 302
    move-object v8, v12

    .line 303
    move v12, v0

    .line 304
    move-object v0, v6

    .line 305
    move-object v6, v10

    .line 306
    move-object v10, v15

    .line 307
    invoke-static/range {v0 .. v14}, Lv97;->p(Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;FZLzi2;I)V

    .line 308
    .line 309
    .line 310
    goto :goto_1

    .line 311
    :cond_17
    invoke-virtual {v13}, Lzi2;->b0()V

    .line 312
    .line 313
    .line 314
    :goto_1
    sget-object v0, Lst7;->a:Lst7;

    .line 315
    .line 316
    return-object v0
.end method
