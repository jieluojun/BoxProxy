.class public final Lb12;
.super Lzn6;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public A:Luj0;

.field public B:Luj0;

.field public C:F

.field public final synthetic x:B

.field public y:Luj0;

.field public z:Luj0;


# direct methods
.method public synthetic constructor <init>(Lyc6;Lcc1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lb12;->x:B

    .line 2
    .line 3
    invoke-direct {p0, p1, p2}, Lw02;-><init>(Lyc6;Lcc1;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method


# virtual methods
.method public final c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z
    .locals 5

    .line 1
    iget-byte v0, p0, Lb12;->x:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/16 v2, 0x5f

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eq v0, v2, :cond_0

    .line 15
    .line 16
    packed-switch v0, :pswitch_data_1

    .line 17
    .line 18
    .line 19
    invoke-super {p0, p1, p2, p3, p4}, Lzn6;->c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    goto :goto_0

    .line 24
    :pswitch_0
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    invoke-static {v3, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iput-object p1, p0, Lb12;->B:Luj0;

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :pswitch_1
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    invoke-static {v3, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    iput-object p1, p0, Lb12;->A:Luj0;

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :pswitch_2
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    invoke-static {v3, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    iput-object p1, p0, Lb12;->z:Luj0;

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :pswitch_3
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    invoke-static {v3, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    iput-object p1, p0, Lb12;->y:Luj0;

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_0
    const-string p1, "Invalid <line> element. pathLength cannot be negative"

    .line 69
    .line 70
    invoke-static {p4, p1}, Lix;->q0(Ljava/lang/String;Ljava/lang/String;)F

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    iput p1, p0, Lb12;->C:F

    .line 75
    .line 76
    :goto_0
    return v1

    .line 77
    :pswitch_4
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    const/16 v4, 0x13

    .line 82
    .line 83
    if-eq v0, v4, :cond_5

    .line 84
    .line 85
    const/16 v4, 0x14

    .line 86
    .line 87
    if-eq v0, v4, :cond_4

    .line 88
    .line 89
    if-eq v0, v2, :cond_3

    .line 90
    .line 91
    const/16 v2, 0x8f

    .line 92
    .line 93
    if-eq v0, v2, :cond_2

    .line 94
    .line 95
    const/16 v2, 0x90

    .line 96
    .line 97
    if-eq v0, v2, :cond_1

    .line 98
    .line 99
    invoke-super {p0, p1, p2, p3, p4}, Lzn6;->c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    goto :goto_1

    .line 104
    :cond_1
    const-string p1, "Invalid <ellipse> element. ry cannot be negative"

    .line 105
    .line 106
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    iput-object p1, p0, Lb12;->B:Luj0;

    .line 111
    .line 112
    goto :goto_1

    .line 113
    :cond_2
    const-string p1, "Invalid <ellipse> element. rx cannot be negative"

    .line 114
    .line 115
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    iput-object p1, p0, Lb12;->A:Luj0;

    .line 120
    .line 121
    goto :goto_1

    .line 122
    :cond_3
    const-string p1, "Invalid <ellipse> element. pathLength cannot be negative"

    .line 123
    .line 124
    invoke-static {p4, p1}, Lix;->q0(Ljava/lang/String;Ljava/lang/String;)F

    .line 125
    .line 126
    .line 127
    move-result p1

    .line 128
    iput p1, p0, Lb12;->C:F

    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_4
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 132
    .line 133
    .line 134
    move-result p1

    .line 135
    invoke-static {v3, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    iput-object p1, p0, Lb12;->z:Luj0;

    .line 140
    .line 141
    goto :goto_1

    .line 142
    :cond_5
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 143
    .line 144
    .line 145
    move-result p1

    .line 146
    invoke-static {v3, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    iput-object p1, p0, Lb12;->y:Luj0;

    .line 151
    .line 152
    :goto_1
    return v1

    .line 153
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
    .end packed-switch

    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    :pswitch_data_1
    .packed-switch 0xc5
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
.end method
