.class public interface abstract Lbb4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public b0(Lbb4;)Lbb4;
    .locals 1

    .line 1
    sget-object v0, Lya4;->h:Lya4;

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_0
    new-instance v0, Lx01;

    .line 7
    .line 8
    invoke-direct {v0, p0, p1}, Lx01;-><init>(Lbb4;Lbb4;)V

    .line 9
    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public abstract h(Lai2;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public abstract n(Lwh2;)Z
.end method
