.class public final Lb72;
.super Lma2;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public E:I

.field public F:I

.field public G:[F

.field public H:F

.field public I:F

.field public J:Ljava/lang/Integer;

.field public K:Ljava/lang/Integer;

.field public L:F

.field public M:F

.field public N:Lae1;

.field public O:Z


# virtual methods
.method public final c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z
    .locals 3

    .line 1
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-super {p0, p1, p2, p3, p4}, Lma2;->c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    return p0

    .line 15
    :pswitch_0
    const-string p1, "true"

    .line 16
    .line 17
    invoke-virtual {p4, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    iput-boolean p1, p0, Lb72;->O:Z

    .line 22
    .line 23
    return v2

    .line 24
    :pswitch_1
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    if-nez p1, :cond_0

    .line 29
    .line 30
    sget-object p1, Lae1;->h:Lae1;

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    :try_start_0
    sget-object p1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 34
    .line 35
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p4, p1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    invoke-static {p1}, Lae1;->valueOf(Ljava/lang/String;)Lae1;

    .line 46
    .line 47
    .line 48
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 49
    :goto_0
    iput-object p1, p0, Lb72;->N:Lae1;

    .line 50
    .line 51
    return v2

    .line 52
    :catch_0
    new-instance p0, Leg3;

    .line 53
    .line 54
    const-string p1, "Invalid matrix edge mode: "

    .line 55
    .line 56
    invoke-virtual {p1, p4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-direct {p0, p1}, Lorg/xml/sax/SAXException;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    throw p0

    .line 64
    :pswitch_2
    invoke-static {p4}, Lix;->o0(Ljava/lang/String;)F

    .line 65
    .line 66
    .line 67
    move-result p1

    .line 68
    float-to-int p1, p1

    .line 69
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    iput-object p1, p0, Lb72;->K:Ljava/lang/Integer;

    .line 74
    .line 75
    return v2

    .line 76
    :pswitch_3
    invoke-static {p4}, Lix;->o0(Ljava/lang/String;)F

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    float-to-int p1, p1

    .line 81
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    iput-object p1, p0, Lb72;->J:Ljava/lang/Integer;

    .line 86
    .line 87
    return v2

    .line 88
    :pswitch_4
    invoke-static {p4}, Lix;->o0(Ljava/lang/String;)F

    .line 89
    .line 90
    .line 91
    move-result p1

    .line 92
    iput p1, p0, Lb72;->I:F

    .line 93
    .line 94
    return v2

    .line 95
    :pswitch_5
    invoke-static {p4}, Lix;->o0(Ljava/lang/String;)F

    .line 96
    .line 97
    .line 98
    move-result p1

    .line 99
    iput p1, p0, Lb72;->H:F

    .line 100
    .line 101
    return v2

    .line 102
    :pswitch_6
    invoke-static {p4}, Lix;->p0(Ljava/lang/String;)[F

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    array-length p2, p1

    .line 107
    if-lez p2, :cond_1

    .line 108
    .line 109
    aget p2, p1, v1

    .line 110
    .line 111
    goto :goto_1

    .line 112
    :cond_1
    const/high16 p2, -0x40800000    # -1.0f

    .line 113
    .line 114
    :goto_1
    array-length p3, p1

    .line 115
    if-ge v2, p3, :cond_2

    .line 116
    .line 117
    aget p1, p1, v2

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_2
    move p1, p2

    .line 121
    :goto_2
    const/4 p3, 0x0

    .line 122
    cmpl-float p4, p2, p3

    .line 123
    .line 124
    if-gtz p4, :cond_3

    .line 125
    .line 126
    move p2, p3

    .line 127
    :cond_3
    iput p2, p0, Lb72;->L:F

    .line 128
    .line 129
    cmpl-float p2, p1, p3

    .line 130
    .line 131
    if-gtz p2, :cond_4

    .line 132
    .line 133
    move p1, p3

    .line 134
    :cond_4
    iput p1, p0, Lb72;->M:F

    .line 135
    .line 136
    return v2

    .line 137
    :pswitch_7
    invoke-static {p4}, Lix;->p0(Ljava/lang/String;)[F

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    iput-object p1, p0, Lb72;->G:[F

    .line 142
    .line 143
    return v2

    .line 144
    :pswitch_8
    invoke-static {p4}, Lix;->p0(Ljava/lang/String;)[F

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    array-length p2, p1

    .line 149
    if-lez p2, :cond_5

    .line 150
    .line 151
    aget p2, p1, v1

    .line 152
    .line 153
    goto :goto_3

    .line 154
    :cond_5
    const/high16 p2, 0x40400000    # 3.0f

    .line 155
    .line 156
    :goto_3
    float-to-int p2, p2

    .line 157
    iput p2, p0, Lb72;->E:I

    .line 158
    .line 159
    array-length p3, p1

    .line 160
    if-ge v2, p3, :cond_6

    .line 161
    .line 162
    aget p1, p1, v2

    .line 163
    .line 164
    goto :goto_4

    .line 165
    :cond_6
    int-to-float p1, p2

    .line 166
    :goto_4
    float-to-int p1, p1

    .line 167
    iput p1, p0, Lb72;->F:I

    .line 168
    .line 169
    return v2

    .line 170
    nop

    .line 171
    :pswitch_data_0
    .packed-switch 0x74
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
.end method
