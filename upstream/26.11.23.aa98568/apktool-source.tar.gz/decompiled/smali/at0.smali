.class public final enum Lat0;
.super Ljava/lang/Enum;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final i:Lql0;

.field public static final enum j:Lat0;

.field public static final enum k:Lat0;

.field public static final enum l:Lat0;

.field public static final enum m:Lat0;

.field public static final synthetic n:[Lat0;


# instance fields
.field public final h:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v0, Lat0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "debug"

    .line 5
    .line 6
    const-string v3, "DEBUG"

    .line 7
    .line 8
    invoke-direct {v0, v1, v3, v2}, Lat0;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sput-object v0, Lat0;->j:Lat0;

    .line 12
    .line 13
    new-instance v1, Lat0;

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    const-string v3, "info"

    .line 17
    .line 18
    const-string v4, "INFO"

    .line 19
    .line 20
    invoke-direct {v1, v2, v4, v3}, Lat0;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    sput-object v1, Lat0;->k:Lat0;

    .line 24
    .line 25
    new-instance v2, Lat0;

    .line 26
    .line 27
    const/4 v3, 0x2

    .line 28
    const-string v4, "warning"

    .line 29
    .line 30
    const-string v5, "WARNING"

    .line 31
    .line 32
    invoke-direct {v2, v3, v5, v4}, Lat0;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    sput-object v2, Lat0;->l:Lat0;

    .line 36
    .line 37
    new-instance v3, Lat0;

    .line 38
    .line 39
    const/4 v4, 0x3

    .line 40
    const-string v5, "error"

    .line 41
    .line 42
    const-string v6, "ERROR"

    .line 43
    .line 44
    invoke-direct {v3, v4, v6, v5}, Lat0;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    sput-object v3, Lat0;->m:Lat0;

    .line 48
    .line 49
    filled-new-array {v0, v1, v2, v3}, [Lat0;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    sput-object v0, Lat0;->n:[Lat0;

    .line 54
    .line 55
    new-instance v0, Lql0;

    .line 56
    .line 57
    const/4 v1, 0x3

    .line 58
    invoke-direct {v0, v1}, Lql0;-><init>(B)V

    .line 59
    .line 60
    .line 61
    sput-object v0, Lat0;->i:Lql0;

    .line 62
    .line 63
    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p2, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lat0;->h:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lat0;
    .locals 1

    .line 1
    const-class v0, Lat0;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lat0;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lat0;
    .locals 1

    .line 1
    sget-object v0, Lat0;->n:[Lat0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lat0;

    .line 8
    .line 9
    return-object v0
.end method
