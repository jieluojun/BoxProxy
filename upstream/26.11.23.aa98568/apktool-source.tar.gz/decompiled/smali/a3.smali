.class public final synthetic La3;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, La3;->h:B

    .line 2
    .line 3
    iput-object p1, p0, La3;->i:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La3;->h:B

    .line 4
    .line 5
    const/16 v2, 0x8

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    const/4 v5, 0x0

    .line 10
    const/4 v6, 0x0

    .line 11
    iget-object v0, v0, La3;->i:Ljava/lang/Object;

    .line 12
    .line 13
    packed-switch v1, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast v0, Landroid/view/View;

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-string v2, "input_method"

    .line 23
    .line 24
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    check-cast v1, Landroid/view/inputmethod/InputMethodManager;

    .line 29
    .line 30
    invoke-virtual {v1, v0, v6}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_0
    check-cast v0, Ljq6;

    .line 35
    .line 36
    :catch_0
    :goto_0
    iget-object v1, v0, Ljq6;->o:Ljava/util/ArrayDeque;

    .line 37
    .line 38
    iget-object v2, v0, Ljq6;->m:Ljava/util/concurrent/locks/ReentrantLock;

    .line 39
    .line 40
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 41
    .line 42
    .line 43
    :try_start_0
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    check-cast v1, Lkq6;

    .line 48
    .line 49
    if-nez v1, :cond_0

    .line 50
    .line 51
    iput-boolean v6, v0, Ljq6;->p:Z

    .line 52
    .line 53
    iget-object v1, v0, Ljq6;->n:Ljava/util/concurrent/locks/Condition;

    .line 54
    .line 55
    invoke-interface {v1}, Ljava/util/concurrent/locks/Condition;->signalAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 59
    .line 60
    .line 61
    move-object v1, v5

    .line 62
    goto :goto_1

    .line 63
    :cond_0
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 64
    .line 65
    .line 66
    :goto_1
    if-eqz v1, :cond_1

    .line 67
    .line 68
    :try_start_1
    invoke-virtual {v0, v1}, Ljq6;->b(Lkq6;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    .line 69
    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_1
    return-void

    .line 73
    :catchall_0
    move-exception v0

    .line 74
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 75
    .line 76
    .line 77
    throw v0

    .line 78
    :pswitch_1
    check-cast v0, Lo06;

    .line 79
    .line 80
    invoke-static {v0}, Lo06;->a(Lo06;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :pswitch_2
    check-cast v0, Lrg5;

    .line 85
    .line 86
    iget-object v1, v0, Lrg5;->m:Lwo3;

    .line 87
    .line 88
    iget v2, v0, Lrg5;->i:I

    .line 89
    .line 90
    if-nez v2, :cond_2

    .line 91
    .line 92
    iput-boolean v4, v0, Lrg5;->j:Z

    .line 93
    .line 94
    sget-object v2, Lko3;->ON_PAUSE:Lko3;

    .line 95
    .line 96
    invoke-virtual {v1, v2}, Lwo3;->d(Lko3;)V

    .line 97
    .line 98
    .line 99
    :cond_2
    iget v2, v0, Lrg5;->h:I

    .line 100
    .line 101
    if-nez v2, :cond_3

    .line 102
    .line 103
    iget-boolean v2, v0, Lrg5;->j:Z

    .line 104
    .line 105
    if-eqz v2, :cond_3

    .line 106
    .line 107
    sget-object v2, Lko3;->ON_STOP:Lko3;

    .line 108
    .line 109
    invoke-virtual {v1, v2}, Lwo3;->d(Lko3;)V

    .line 110
    .line 111
    .line 112
    iput-boolean v4, v0, Lrg5;->k:Z

    .line 113
    .line 114
    :cond_3
    return-void

    .line 115
    :pswitch_3
    check-cast v0, Leh2;

    .line 116
    .line 117
    iget-object v0, v0, Leh2;->m:Ljava/util/ArrayList;

    .line 118
    .line 119
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 124
    .line 125
    .line 126
    move-result v1

    .line 127
    if-nez v1, :cond_4

    .line 128
    .line 129
    return-void

    .line 130
    :cond_4
    invoke-static {v0}, Ln32;->j(Ljava/util/Iterator;)Ljava/lang/ClassCastException;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    throw v0

    .line 135
    :pswitch_4
    move-object v1, v0

    .line 136
    check-cast v1, Lqf2;

    .line 137
    .line 138
    const-string v0, "fetchFonts result is not OK. ("

    .line 139
    .line 140
    iget-object v2, v1, Lqf2;->c:Ljava/lang/Object;

    .line 141
    .line 142
    monitor-enter v2

    .line 143
    :try_start_2
    iget-object v4, v1, Lqf2;->g:Lnx;

    .line 144
    .line 145
    if-nez v4, :cond_5

    .line 146
    .line 147
    monitor-exit v2

    .line 148
    goto/16 :goto_5

    .line 149
    .line 150
    :cond_5
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_7

    .line 151
    :try_start_3
    invoke-virtual {v1}, Lqf2;->c()Ljg2;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    iget v4, v2, Ljg2;->f:I

    .line 156
    .line 157
    if-ne v4, v3, :cond_6

    .line 158
    .line 159
    iget-object v3, v1, Lqf2;->c:Ljava/lang/Object;

    .line 160
    .line 161
    monitor-enter v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_5

    .line 162
    :try_start_4
    monitor-exit v3

    .line 163
    goto :goto_3

    .line 164
    :goto_2
    monitor-exit v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 165
    :try_start_5
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 166
    :catchall_1
    move-exception v0

    .line 167
    goto :goto_2

    .line 168
    :cond_6
    :goto_3
    if-nez v4, :cond_9

    .line 169
    .line 170
    :try_start_6
    const-string v0, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    .line 171
    .line 172
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    iget-object v0, v1, Lqf2;->a:Landroid/content/Context;

    .line 176
    .line 177
    filled-new-array {v2}, [Ljg2;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    invoke-static {v0, v3, v6}, Ldr7;->a(Landroid/content/Context;[Ljg2;I)Landroid/graphics/Typeface;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    iget-object v3, v1, Lqf2;->a:Landroid/content/Context;

    .line 186
    .line 187
    iget-object v2, v2, Ljg2;->a:Landroid/net/Uri;

    .line 188
    .line 189
    invoke-static {v3, v2}, Lt67;->e(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    .line 190
    .line 191
    .line 192
    move-result-object v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 193
    if-eqz v2, :cond_8

    .line 194
    .line 195
    if-eqz v0, :cond_8

    .line 196
    .line 197
    :try_start_7
    const-string v3, "EmojiCompat.MetadataRepo.create"

    .line 198
    .line 199
    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    new-instance v3, Lb44;

    .line 203
    .line 204
    invoke-static {v2}, Lqj3;->Q(Ljava/nio/MappedByteBuffer;)La44;

    .line 205
    .line 206
    .line 207
    move-result-object v2

    .line 208
    invoke-direct {v3, v0, v2}, Lb44;-><init>(Landroid/graphics/Typeface;La44;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 209
    .line 210
    .line 211
    :try_start_8
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 212
    .line 213
    .line 214
    :try_start_9
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 215
    .line 216
    .line 217
    iget-object v2, v1, Lqf2;->c:Ljava/lang/Object;

    .line 218
    .line 219
    monitor-enter v2
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 220
    :try_start_a
    iget-object v0, v1, Lqf2;->g:Lnx;

    .line 221
    .line 222
    if-eqz v0, :cond_7

    .line 223
    .line 224
    invoke-virtual {v0, v3}, Lnx;->b0(Lb44;)V

    .line 225
    .line 226
    .line 227
    :cond_7
    monitor-exit v2
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 228
    :try_start_b
    invoke-virtual {v1}, Lqf2;->b()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 229
    .line 230
    .line 231
    goto :goto_5

    .line 232
    :goto_4
    :try_start_c
    monitor-exit v2
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_2

    .line 233
    :try_start_d
    throw v0
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_5

    .line 234
    :catchall_2
    move-exception v0

    .line 235
    goto :goto_4

    .line 236
    :catchall_3
    move-exception v0

    .line 237
    :try_start_e
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 238
    .line 239
    .line 240
    throw v0

    .line 241
    :cond_8
    new-instance v0, Ljava/lang/RuntimeException;

    .line 242
    .line 243
    const-string v2, "Unable to open file."

    .line 244
    .line 245
    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 246
    .line 247
    .line 248
    throw v0
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_4

    .line 249
    :catchall_4
    move-exception v0

    .line 250
    :try_start_f
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 251
    .line 252
    .line 253
    throw v0

    .line 254
    :cond_9
    new-instance v2, Ljava/lang/RuntimeException;

    .line 255
    .line 256
    new-instance v3, Ljava/lang/StringBuilder;

    .line 257
    .line 258
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 262
    .line 263
    .line 264
    const-string v0, ")"

    .line 265
    .line 266
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 267
    .line 268
    .line 269
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 270
    .line 271
    .line 272
    move-result-object v0

    .line 273
    invoke-direct {v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    throw v2
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_5

    .line 277
    :catchall_5
    move-exception v0

    .line 278
    iget-object v3, v1, Lqf2;->c:Ljava/lang/Object;

    .line 279
    .line 280
    monitor-enter v3

    .line 281
    :try_start_10
    iget-object v2, v1, Lqf2;->g:Lnx;

    .line 282
    .line 283
    if-eqz v2, :cond_a

    .line 284
    .line 285
    invoke-virtual {v2, v0}, Lnx;->a0(Ljava/lang/Throwable;)V

    .line 286
    .line 287
    .line 288
    :cond_a
    monitor-exit v3
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_6

    .line 289
    invoke-virtual {v1}, Lqf2;->b()V

    .line 290
    .line 291
    .line 292
    :goto_5
    return-void

    .line 293
    :goto_6
    :try_start_11
    monitor-exit v3
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_6

    .line 294
    throw v0

    .line 295
    :catchall_6
    move-exception v0

    .line 296
    goto :goto_6

    .line 297
    :goto_7
    :try_start_12
    monitor-exit v2
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_7

    .line 298
    throw v0

    .line 299
    :catchall_7
    move-exception v0

    .line 300
    goto :goto_7

    .line 301
    :pswitch_5
    check-cast v0, Lo02;

    .line 302
    .line 303
    invoke-virtual {v0}, Lo02;->f()V

    .line 304
    .line 305
    .line 306
    return-void

    .line 307
    :pswitch_6
    check-cast v0, Lzi7;

    .line 308
    .line 309
    iget-object v1, v0, Lzi7;->k:Ljava/lang/Object;

    .line 310
    .line 311
    check-cast v1, Lzy7;

    .line 312
    .line 313
    iget-object v2, v0, Lzi7;->i:Ljava/lang/Object;

    .line 314
    .line 315
    check-cast v2, Ljava/lang/ref/WeakReference;

    .line 316
    .line 317
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    move-result-object v2

    .line 321
    check-cast v2, Lrx0;

    .line 322
    .line 323
    if-eqz v1, :cond_d

    .line 324
    .line 325
    if-eqz v2, :cond_d

    .line 326
    .line 327
    invoke-virtual {v2}, Lrx0;->getCursor()Lhk1;

    .line 328
    .line 329
    .line 330
    move-result-object v3

    .line 331
    invoke-virtual {v3}, Lhk1;->a()Z

    .line 332
    .line 333
    .line 334
    move-result v3

    .line 335
    if-nez v3, :cond_d

    .line 336
    .line 337
    iget-boolean v3, v2, Lrx0;->n0:Z

    .line 338
    .line 339
    if-eqz v3, :cond_d

    .line 340
    .line 341
    invoke-virtual {v2}, Lrx0;->getText()Lic1;

    .line 342
    .line 343
    .line 344
    move-result-object v3

    .line 345
    invoke-virtual {v2}, Lrx0;->getCursor()Lhk1;

    .line 346
    .line 347
    .line 348
    move-result-object v4

    .line 349
    iget-object v4, v4, Lhk1;->c:Lnp0;

    .line 350
    .line 351
    iget v4, v4, Lnp0;->a:I

    .line 352
    .line 353
    if-lez v4, :cond_b

    .line 354
    .line 355
    add-int/lit8 v5, v4, -0x1

    .line 356
    .line 357
    invoke-virtual {v1, v3, v5}, Lzy7;->C(Lic1;I)Lj64;

    .line 358
    .line 359
    .line 360
    move-result-object v5

    .line 361
    :cond_b
    if-nez v5, :cond_c

    .line 362
    .line 363
    iget v6, v3, Lic1;->k:I

    .line 364
    .line 365
    if-ge v4, v6, :cond_c

    .line 366
    .line 367
    invoke-virtual {v1, v3, v4}, Lzy7;->C(Lic1;I)Lj64;

    .line 368
    .line 369
    .line 370
    move-result-object v5

    .line 371
    :cond_c
    iput-object v5, v0, Lzi7;->j:Ljava/lang/Object;

    .line 372
    .line 373
    invoke-virtual {v2}, Landroid/view/View;->invalidate()V

    .line 374
    .line 375
    .line 376
    :cond_d
    return-void

    .line 377
    :pswitch_7
    check-cast v0, Lrx0;

    .line 378
    .line 379
    invoke-virtual {v0}, Lrx0;->g0()V

    .line 380
    .line 381
    .line 382
    return-void

    .line 383
    :pswitch_8
    check-cast v0, Lmz1;

    .line 384
    .line 385
    iget-object v1, v0, Lmz1;->D:Lnp0;

    .line 386
    .line 387
    iget-object v2, v0, Lxz1;->h:Landroid/widget/PopupWindow;

    .line 388
    .line 389
    invoke-virtual {v2}, Landroid/widget/PopupWindow;->isShowing()Z

    .line 390
    .line 391
    .line 392
    move-result v2

    .line 393
    if-eqz v2, :cond_e

    .line 394
    .line 395
    iget-object v2, v0, Lmz1;->x:Len1;

    .line 396
    .line 397
    iget-boolean v2, v2, Len1;->i:Z

    .line 398
    .line 399
    if-nez v2, :cond_f

    .line 400
    .line 401
    if-eqz v1, :cond_f

    .line 402
    .line 403
    invoke-virtual {v0, v1}, Lmz1;->g(Lnp0;)V

    .line 404
    .line 405
    .line 406
    goto :goto_8

    .line 407
    :cond_e
    if-eqz v1, :cond_f

    .line 408
    .line 409
    invoke-virtual {v0, v1}, Lmz1;->g(Lnp0;)V

    .line 410
    .line 411
    .line 412
    :cond_f
    :goto_8
    return-void

    .line 413
    :pswitch_9
    check-cast v0, Ldz1;

    .line 414
    .line 415
    iget-object v0, v0, Ldz1;->o:Lez1;

    .line 416
    .line 417
    iput-boolean v6, v0, Lez1;->K:Z

    .line 418
    .line 419
    iget-object v0, v0, Lez1;->E:Lq21;

    .line 420
    .line 421
    iget-object v0, v0, Lq21;->j:Ljava/lang/Object;

    .line 422
    .line 423
    check-cast v0, Landroid/widget/ProgressBar;

    .line 424
    .line 425
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 426
    .line 427
    .line 428
    return-void

    .line 429
    :pswitch_a
    check-cast v0, Lh21;

    .line 430
    .line 431
    invoke-static {v0}, Lh21;->e(Lh21;)V

    .line 432
    .line 433
    .line 434
    return-void

    .line 435
    :pswitch_b
    check-cast v0, La21;

    .line 436
    .line 437
    iget-object v1, v0, La21;->i:Ljava/lang/Runnable;

    .line 438
    .line 439
    if-eqz v1, :cond_10

    .line 440
    .line 441
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 442
    .line 443
    .line 444
    iput-object v5, v0, La21;->i:Ljava/lang/Runnable;

    .line 445
    .line 446
    :cond_10
    return-void

    .line 447
    :pswitch_c
    check-cast v0, Lwx3;

    .line 448
    .line 449
    invoke-virtual {v0}, Lwx3;->c()V

    .line 450
    .line 451
    .line 452
    return-void

    .line 453
    :pswitch_d
    check-cast v0, Lcom/box/app/tile/BoxServiceTileService;

    .line 454
    .line 455
    sget v1, Lcom/box/app/tile/BoxServiceTileService;->i:I

    .line 456
    .line 457
    invoke-virtual {v0}, Landroid/service/quicksettings/TileService;->getQsTile()Landroid/service/quicksettings/Tile;

    .line 458
    .line 459
    .line 460
    move-result-object v1

    .line 461
    if-eqz v1, :cond_12

    .line 462
    .line 463
    invoke-virtual {v1, v6}, Landroid/service/quicksettings/Tile;->setState(I)V

    .line 464
    .line 465
    .line 466
    const v2, 0x7f0f0522

    .line 467
    .line 468
    .line 469
    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 470
    .line 471
    .line 472
    move-result-object v3

    .line 473
    invoke-virtual {v1, v3}, Landroid/service/quicksettings/Tile;->setSubtitle(Ljava/lang/CharSequence;)V

    .line 474
    .line 475
    .line 476
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 477
    .line 478
    const/16 v4, 0x1e

    .line 479
    .line 480
    if-lt v3, v4, :cond_11

    .line 481
    .line 482
    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 483
    .line 484
    .line 485
    move-result-object v2

    .line 486
    invoke-static {v1, v2}, Le5;->z(Landroid/service/quicksettings/Tile;Ljava/lang/String;)V

    .line 487
    .line 488
    .line 489
    :cond_11
    const v2, 0x7f0f0521

    .line 490
    .line 491
    .line 492
    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 493
    .line 494
    .line 495
    move-result-object v2

    .line 496
    invoke-virtual {v1, v2}, Landroid/service/quicksettings/Tile;->setLabel(Ljava/lang/CharSequence;)V

    .line 497
    .line 498
    .line 499
    const v2, 0x7f080065

    .line 500
    .line 501
    .line 502
    invoke-static {v0, v2}, Landroid/graphics/drawable/Icon;->createWithResource(Landroid/content/Context;I)Landroid/graphics/drawable/Icon;

    .line 503
    .line 504
    .line 505
    move-result-object v2

    .line 506
    invoke-virtual {v1, v2}, Landroid/service/quicksettings/Tile;->setIcon(Landroid/graphics/drawable/Icon;)V

    .line 507
    .line 508
    .line 509
    invoke-virtual {v1}, Landroid/service/quicksettings/Tile;->updateTile()V

    .line 510
    .line 511
    .line 512
    :cond_12
    iget-object v1, v0, Lcom/box/app/tile/BoxServiceTileService;->h:Lud1;

    .line 513
    .line 514
    new-instance v2, Ljy;

    .line 515
    .line 516
    const/4 v3, 0x4

    .line 517
    invoke-direct {v2, v0, v5, v3}, Ljy;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 518
    .line 519
    .line 520
    const/4 v0, 0x3

    .line 521
    invoke-static {v1, v5, v5, v2, v0}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 522
    .line 523
    .line 524
    return-void

    .line 525
    :pswitch_e
    check-cast v0, Lbg;

    .line 526
    .line 527
    invoke-virtual {v0}, Lbg;->a()Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    return-void

    .line 531
    :pswitch_f
    check-cast v0, Lbg;

    .line 532
    .line 533
    invoke-virtual {v0}, Lbg;->a()Ljava/lang/Object;

    .line 534
    .line 535
    .line 536
    return-void

    .line 537
    :pswitch_10
    check-cast v0, Laf;

    .line 538
    .line 539
    iget-object v0, v0, Laf;->h:Landroid/view/ActionMode;

    .line 540
    .line 541
    if-eqz v0, :cond_13

    .line 542
    .line 543
    invoke-virtual {v0}, Landroid/view/ActionMode;->finish()V

    .line 544
    .line 545
    .line 546
    :cond_13
    return-void

    .line 547
    :pswitch_11
    check-cast v0, Lrb;

    .line 548
    .line 549
    invoke-virtual {v0}, Lrb;->d()Z

    .line 550
    .line 551
    .line 552
    move-result v1

    .line 553
    iget-object v5, v0, Lrb;->h:Lbb;

    .line 554
    .line 555
    if-eqz v1, :cond_19

    .line 556
    .line 557
    invoke-virtual {v5}, Landroid/view/View;->isAttachedToWindow()Z

    .line 558
    .line 559
    .line 560
    move-result v1

    .line 561
    if-nez v1, :cond_14

    .line 562
    .line 563
    iput-boolean v6, v0, Lrb;->s:Z

    .line 564
    .line 565
    goto/16 :goto_c

    .line 566
    .line 567
    :cond_14
    const-string v1, "ContentCapture:changeChecker"

    .line 568
    .line 569
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 570
    .line 571
    .line 572
    :try_start_13
    invoke-virtual {v5, v4}, Lbb;->q(Z)V

    .line 573
    .line 574
    .line 575
    iget-object v1, v0, Lrb;->q:Lrd4;

    .line 576
    .line 577
    iget-object v4, v1, Ln93;->b:[I

    .line 578
    .line 579
    iget-object v1, v1, Ln93;->a:[J

    .line 580
    .line 581
    array-length v7, v1

    .line 582
    sub-int/2addr v7, v3

    .line 583
    if-ltz v7, :cond_18

    .line 584
    .line 585
    move v3, v6

    .line 586
    :goto_9
    aget-wide v8, v1, v3

    .line 587
    .line 588
    not-long v10, v8

    .line 589
    const/4 v12, 0x7

    .line 590
    shl-long/2addr v10, v12

    .line 591
    and-long/2addr v10, v8

    .line 592
    const-wide v12, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    and-long/2addr v10, v12

    .line 598
    cmp-long v10, v10, v12

    .line 599
    .line 600
    if-eqz v10, :cond_17

    .line 601
    .line 602
    sub-int v10, v3, v7

    .line 603
    .line 604
    not-int v10, v10

    .line 605
    ushr-int/lit8 v10, v10, 0x1f

    .line 606
    .line 607
    rsub-int/lit8 v10, v10, 0x8

    .line 608
    .line 609
    move v11, v6

    .line 610
    :goto_a
    if-ge v11, v10, :cond_16

    .line 611
    .line 612
    const-wide/16 v12, 0xff

    .line 613
    .line 614
    and-long/2addr v12, v8

    .line 615
    const-wide/16 v14, 0x80

    .line 616
    .line 617
    cmp-long v12, v12, v14

    .line 618
    .line 619
    if-gez v12, :cond_15

    .line 620
    .line 621
    shl-int/lit8 v12, v3, 0x3

    .line 622
    .line 623
    add-int/2addr v12, v11

    .line 624
    aget v14, v4, v12

    .line 625
    .line 626
    invoke-virtual {v0}, Lrb;->c()Ln93;

    .line 627
    .line 628
    .line 629
    move-result-object v12

    .line 630
    invoke-virtual {v12, v14}, Ln93;->a(I)Z

    .line 631
    .line 632
    .line 633
    move-result v12

    .line 634
    if-nez v12, :cond_15

    .line 635
    .line 636
    iget-object v12, v0, Lrb;->k:Ljava/util/ArrayList;

    .line 637
    .line 638
    new-instance v13, Llc1;

    .line 639
    .line 640
    move/from16 p0, v7

    .line 641
    .line 642
    iget-wide v6, v0, Lrb;->p:J

    .line 643
    .line 644
    sget-object v17, Lmc1;->i:Lmc1;

    .line 645
    .line 646
    const/16 v18, 0x0

    .line 647
    .line 648
    move-wide v15, v6

    .line 649
    invoke-direct/range {v13 .. v18}, Llc1;-><init>(IJLmc1;Lut5;)V

    .line 650
    .line 651
    .line 652
    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 653
    .line 654
    .line 655
    iget-object v6, v0, Lrb;->n:Lqg0;

    .line 656
    .line 657
    sget-object v7, Lst7;->a:Lst7;

    .line 658
    .line 659
    invoke-interface {v6, v7}, Lul6;->s(Ljava/lang/Object;)Ljava/lang/Object;

    .line 660
    .line 661
    .line 662
    goto :goto_b

    .line 663
    :cond_15
    move/from16 p0, v7

    .line 664
    .line 665
    :goto_b
    shr-long/2addr v8, v2

    .line 666
    add-int/lit8 v11, v11, 0x1

    .line 667
    .line 668
    move/from16 v7, p0

    .line 669
    .line 670
    goto :goto_a

    .line 671
    :cond_16
    move/from16 p0, v7

    .line 672
    .line 673
    if-ne v10, v2, :cond_18

    .line 674
    .line 675
    move/from16 v7, p0

    .line 676
    .line 677
    :cond_17
    if-eq v3, v7, :cond_18

    .line 678
    .line 679
    add-int/lit8 v3, v3, 0x1

    .line 680
    .line 681
    const/4 v6, 0x0

    .line 682
    goto :goto_9

    .line 683
    :cond_18
    const-string v1, "ContentCapture:sendAppearEvents"

    .line 684
    .line 685
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_9

    .line 686
    .line 687
    .line 688
    :try_start_14
    invoke-virtual {v5}, Lbb;->getSemanticsOwner()Lgl6;

    .line 689
    .line 690
    .line 691
    move-result-object v1

    .line 692
    invoke-virtual {v1}, Lgl6;->a()Lel6;

    .line 693
    .line 694
    .line 695
    move-result-object v1

    .line 696
    iget-object v2, v0, Lrb;->r:Lfl6;

    .line 697
    .line 698
    invoke-virtual {v0, v1, v2}, Lrb;->g(Lel6;Lfl6;)V
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_8

    .line 699
    .line 700
    .line 701
    :try_start_15
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 702
    .line 703
    .line 704
    invoke-virtual {v0}, Lrb;->c()Ln93;

    .line 705
    .line 706
    .line 707
    move-result-object v1

    .line 708
    invoke-virtual {v0, v1}, Lrb;->b(Ln93;)V

    .line 709
    .line 710
    .line 711
    invoke-virtual {v0}, Lrb;->j()V

    .line 712
    .line 713
    .line 714
    const/4 v1, 0x0

    .line 715
    iput-boolean v1, v0, Lrb;->s:Z
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_9

    .line 716
    .line 717
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 718
    .line 719
    .line 720
    :cond_19
    :goto_c
    return-void

    .line 721
    :catchall_8
    move-exception v0

    .line 722
    :try_start_16
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 723
    .line 724
    .line 725
    throw v0
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_9

    .line 726
    :catchall_9
    move-exception v0

    .line 727
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 728
    .line 729
    .line 730
    throw v0

    .line 731
    :pswitch_12
    check-cast v0, Ljb;

    .line 732
    .line 733
    iget-object v1, v0, Ljb;->k:Lbb;

    .line 734
    .line 735
    invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z

    .line 736
    .line 737
    .line 738
    move-result v2

    .line 739
    if-nez v2, :cond_1a

    .line 740
    .line 741
    const/4 v2, 0x0

    .line 742
    iput-boolean v2, v0, Ljb;->O:Z

    .line 743
    .line 744
    goto :goto_d

    .line 745
    :cond_1a
    const-string v2, "Compose:semantics:measureAndLayout"

    .line 746
    .line 747
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 748
    .line 749
    .line 750
    :try_start_17
    invoke-virtual {v1, v4}, Lbb;->q(Z)V
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_b

    .line 751
    .line 752
    .line 753
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 754
    .line 755
    .line 756
    const-string v1, "Compose:semantics:checkForSemanticsChanges"

    .line 757
    .line 758
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 759
    .line 760
    .line 761
    :try_start_18
    invoke-virtual {v0}, Ljb;->j()V
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_a

    .line 762
    .line 763
    .line 764
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 765
    .line 766
    .line 767
    const/4 v1, 0x0

    .line 768
    iput-boolean v1, v0, Ljb;->O:Z

    .line 769
    .line 770
    :goto_d
    return-void

    .line 771
    :catchall_a
    move-exception v0

    .line 772
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 773
    .line 774
    .line 775
    throw v0

    .line 776
    :catchall_b
    move-exception v0

    .line 777
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 778
    .line 779
    .line 780
    throw v0

    .line 781
    :pswitch_13
    check-cast v0, Lt43;

    .line 782
    .line 783
    invoke-virtual {v0}, Lt43;->a()Ljava/lang/Object;

    .line 784
    .line 785
    .line 786
    return-void

    .line 787
    :pswitch_14
    check-cast v0, Lb3;

    .line 788
    .line 789
    invoke-virtual {v0}, Lb3;->c()V

    .line 790
    .line 791
    .line 792
    return-void

    .line 793
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
