.class public final Law;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final g:Ls38;

.field public static final h:Lud1;

.field public static volatile i:Law;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lar;

.field public final c:Lpz6;

.field public final d:Lif4;

.field public final e:Ljava/util/concurrent/atomic/AtomicLong;

.field public final f:Lju5;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ls38;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ls38;-><init>(B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Law;->g:Ls38;

    .line 9
    .line 10
    sget-object v0, Les;->a:Lud1;

    .line 11
    .line 12
    sput-object v0, Law;->h:Lud1;

    .line 13
    .line 14
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, Law;->a:Landroid/content/Context;

    .line 9
    .line 10
    new-instance v0, Lar;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lar;-><init>(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Law;->b:Lar;

    .line 16
    .line 17
    invoke-virtual {v0}, Lar;->v()Lvv;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-static {p1}, Lnb3;->n(Ljava/lang/Object;)Lpz6;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iput-object p1, p0, Law;->c:Lpz6;

    .line 26
    .line 27
    new-instance v0, Lif4;

    .line 28
    .line 29
    invoke-direct {v0}, Lif4;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Law;->d:Lif4;

    .line 33
    .line 34
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 35
    .line 36
    const-wide/16 v1, 0x0

    .line 37
    .line 38
    invoke-direct {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    .line 39
    .line 40
    .line 41
    iput-object v0, p0, Law;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 42
    .line 43
    invoke-static {p1}, Lnv;->U(Lpz6;)Lju5;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iput-object v0, p0, Law;->f:Lju5;

    .line 48
    .line 49
    invoke-virtual {p1}, Lpz6;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    check-cast p1, Lvv;

    .line 54
    .line 55
    iget-object p1, p1, Lvv;->b:Los;

    .line 56
    .line 57
    invoke-virtual {p0, p1}, Law;->a(Los;)V

    .line 58
    .line 59
    .line 60
    return-void
.end method


# virtual methods
.method public final a(Los;)V
    .locals 6

    .line 1
    iget-object p1, p1, Los;->i:Ljava/lang/String;

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    sget-object p1, Los;->j:Ls38;

    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-static {}, Ls38;->r()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    :cond_0
    move-object v4, p1

    .line 15
    iget-object p1, p0, Law;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 18
    .line 19
    .line 20
    move-result-wide v2

    .line 21
    new-instance v0, Lzv;

    .line 22
    .line 23
    const/4 v5, 0x0

    .line 24
    move-object v1, p0

    .line 25
    invoke-direct/range {v0 .. v5}, Lzv;-><init>(Law;JLjava/lang/String;Lxd1;)V

    .line 26
    .line 27
    .line 28
    const/4 p0, 0x3

    .line 29
    sget-object p1, Law;->h:Lud1;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    invoke-static {p1, v1, v1, v0, p0}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final b(Liy2;)V
    .locals 2

    .line 1
    new-instance v0, Lx2;

    .line 2
    .line 3
    const/16 v1, 0x12

    .line 4
    .line 5
    invoke-direct {v0, p1, v1}, Lx2;-><init>(Ljava/lang/Object;B)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, v0}, Law;->c(Lwh2;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final declared-synchronized c(Lwh2;)V
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Law;->c:Lpz6;

    .line 3
    .line 4
    invoke-virtual {v0}, Lpz6;->getValue()Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lvv;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lvv;

    .line 15
    .line 16
    invoke-static {p1, v0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    monitor-exit p0

    .line 23
    return-void

    .line 24
    :cond_0
    :try_start_1
    iget-object v1, p0, Law;->c:Lpz6;

    .line 25
    .line 26
    invoke-virtual {v1, p1}, Lpz6;->j(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object v1, p0, Law;->b:Lar;

    .line 30
    .line 31
    invoke-virtual {v1, v0, p1}, Lar;->G(Lvv;Lvv;)V

    .line 32
    .line 33
    .line 34
    iget-object v1, p1, Lvv;->j:Lyt4;

    .line 35
    .line 36
    iget-object v2, v0, Lvv;->j:Lyt4;

    .line 37
    .line 38
    if-eq v1, v2, :cond_1

    .line 39
    .line 40
    sget-object v1, Ly6;->L:Ly6;

    .line 41
    .line 42
    iget-object v2, p0, Law;->a:Landroid/content/Context;

    .line 43
    .line 44
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    iget-object v3, p1, Lvv;->j:Lyt4;

    .line 48
    .line 49
    invoke-virtual {v1, v2, v3}, Ly6;->F(Landroid/content/Context;Lyt4;)V

    .line 50
    .line 51
    .line 52
    :cond_1
    iget-object p1, p1, Lvv;->b:Los;

    .line 53
    .line 54
    iget-object v0, v0, Lvv;->b:Los;

    .line 55
    .line 56
    if-eq p1, v0, :cond_2

    .line 57
    .line 58
    invoke-virtual {p0, p1}, Law;->a(Los;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 59
    .line 60
    .line 61
    :cond_2
    monitor-exit p0

    .line 62
    return-void

    .line 63
    :goto_0
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 64
    throw p1

    .line 65
    :catchall_0
    move-exception p1

    .line 66
    goto :goto_0
.end method
