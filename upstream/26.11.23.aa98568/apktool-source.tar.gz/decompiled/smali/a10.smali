.class public final La10;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Lsn0;

.field public final b:Lsn0;


# direct methods
.method public constructor <init>(Lsn0;Lsn0;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La10;->a:Lsn0;

    .line 8
    .line 9
    iput-object p2, p0, La10;->b:Lsn0;

    .line 10
    .line 11
    return-void
.end method
