.class public final synthetic La90;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:Lvv;

.field public final synthetic i:Lgc0;

.field public final synthetic j:Lfc0;

.field public final synthetic k:Law;

.field public final synthetic l:Lck4;

.field public final synthetic m:F

.field public final synthetic n:Z


# direct methods
.method public synthetic constructor <init>(Lvv;Lgc0;Lfc0;Law;Lck4;FZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La90;->h:Lvv;

    .line 5
    .line 6
    iput-object p2, p0, La90;->i:Lgc0;

    .line 7
    .line 8
    iput-object p3, p0, La90;->j:Lfc0;

    .line 9
    .line 10
    iput-object p4, p0, La90;->k:Law;

    .line 11
    .line 12
    iput-object p5, p0, La90;->l:Lck4;

    .line 13
    .line 14
    iput p6, p0, La90;->m:F

    .line 15
    .line 16
    iput-boolean p7, p0, La90;->n:Z

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lzi2;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    and-int/lit8 v3, v2, 0x3

    .line 16
    .line 17
    const/4 v4, 0x2

    .line 18
    const/4 v5, 0x1

    .line 19
    if-eq v3, v4, :cond_0

    .line 20
    .line 21
    move v3, v5

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v3, 0x0

    .line 24
    :goto_0
    and-int/2addr v2, v5

    .line 25
    invoke-virtual {v1, v2, v3}, Lzi2;->Y(IZ)Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_10

    .line 30
    .line 31
    iget-object v2, v0, La90;->h:Lvv;

    .line 32
    .line 33
    iget-object v3, v2, Lvv;->b:Los;

    .line 34
    .line 35
    iget-object v4, v2, Lvv;->c:Liy2;

    .line 36
    .line 37
    iget-object v5, v0, La90;->i:Lgc0;

    .line 38
    .line 39
    iget-object v6, v5, Lgc0;->d:Lz75;

    .line 40
    .line 41
    invoke-virtual {v6}, Lz75;->getValue()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    check-cast v6, Ljava/lang/Boolean;

    .line 46
    .line 47
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 48
    .line 49
    .line 50
    move-result v6

    .line 51
    iget-object v7, v5, Lgc0;->e:Lz75;

    .line 52
    .line 53
    invoke-virtual {v7}, Lz75;->getValue()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v7

    .line 57
    check-cast v7, Ljava/lang/Boolean;

    .line 58
    .line 59
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    iget-object v8, v5, Lgc0;->g:Lz75;

    .line 64
    .line 65
    invoke-virtual {v8}, Lz75;->getValue()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v8

    .line 69
    check-cast v8, Ljava/lang/Boolean;

    .line 70
    .line 71
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 72
    .line 73
    .line 74
    move-result v8

    .line 75
    iget-object v9, v5, Lgc0;->h:Lz75;

    .line 76
    .line 77
    invoke-virtual {v9}, Lz75;->getValue()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v9

    .line 81
    check-cast v9, Ljava/lang/String;

    .line 82
    .line 83
    iget-object v10, v0, La90;->j:Lfc0;

    .line 84
    .line 85
    move-object v11, v3

    .line 86
    move v3, v7

    .line 87
    iget-object v7, v10, Lfc0;->d:Lic0;

    .line 88
    .line 89
    move v12, v8

    .line 90
    iget-object v8, v10, Lfc0;->e:Lic0;

    .line 91
    .line 92
    iget-object v13, v5, Lgc0;->f:Lz75;

    .line 93
    .line 94
    invoke-virtual {v13}, Lz75;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v13

    .line 98
    check-cast v13, Ljava/lang/String;

    .line 99
    .line 100
    move v14, v6

    .line 101
    move-object v6, v9

    .line 102
    iget-boolean v9, v2, Lvv;->i:Z

    .line 103
    .line 104
    iget-object v15, v2, Lvv;->j:Lyt4;

    .line 105
    .line 106
    move-object/from16 v16, v11

    .line 107
    .line 108
    iget-boolean v11, v2, Lvv;->x:Z

    .line 109
    .line 110
    iget-boolean v2, v2, Lvv;->y:Z

    .line 111
    .line 112
    move/from16 v25, v2

    .line 113
    .line 114
    iget-object v2, v0, La90;->k:Law;

    .line 115
    .line 116
    invoke-virtual {v1, v2}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v17

    .line 120
    move-object/from16 v19, v2

    .line 121
    .line 122
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    move/from16 p1, v3

    .line 127
    .line 128
    sget-object v3, Lc51;->a:Lql0;

    .line 129
    .line 130
    if-nez v17, :cond_1

    .line 131
    .line 132
    if-eq v2, v3, :cond_1

    .line 133
    .line 134
    move-object/from16 v26, v4

    .line 135
    .line 136
    move-object/from16 v4, v19

    .line 137
    .line 138
    goto :goto_1

    .line 139
    :cond_1
    new-instance v17, Lp2;

    .line 140
    .line 141
    const/16 v23, 0x0

    .line 142
    .line 143
    const/16 v24, 0x5

    .line 144
    .line 145
    const/16 v18, 0x1

    .line 146
    .line 147
    const-class v20, Law;

    .line 148
    .line 149
    const-string v21, "setAppLanguage"

    .line 150
    .line 151
    const-string v22, "setAppLanguage(Lcom/box/app/data/AppLanguage;)V"

    .line 152
    .line 153
    invoke-direct/range {v17 .. v24}, Lp2;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 154
    .line 155
    .line 156
    move-object/from16 v26, v4

    .line 157
    .line 158
    move-object/from16 v2, v17

    .line 159
    .line 160
    move-object/from16 v4, v19

    .line 161
    .line 162
    invoke-virtual {v1, v2}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    :goto_1
    check-cast v2, Lli2;

    .line 166
    .line 167
    invoke-virtual {v1, v4}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v17

    .line 171
    move-object/from16 p2, v2

    .line 172
    .line 173
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    if-nez v17, :cond_2

    .line 178
    .line 179
    if-ne v2, v3, :cond_3

    .line 180
    .line 181
    :cond_2
    new-instance v17, Lp2;

    .line 182
    .line 183
    const/16 v23, 0x0

    .line 184
    .line 185
    const/16 v24, 0x6

    .line 186
    .line 187
    const/16 v18, 0x1

    .line 188
    .line 189
    const-class v20, Law;

    .line 190
    .line 191
    const-string v21, "setHomePanelEntryMode"

    .line 192
    .line 193
    const-string v22, "setHomePanelEntryMode(Lcom/box/app/data/HomePanelEntryMode;)V"

    .line 194
    .line 195
    move-object/from16 v19, v4

    .line 196
    .line 197
    invoke-direct/range {v17 .. v24}, Lp2;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 198
    .line 199
    .line 200
    move-object/from16 v2, v17

    .line 201
    .line 202
    invoke-virtual {v1, v2}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 203
    .line 204
    .line 205
    :cond_3
    check-cast v2, Lli2;

    .line 206
    .line 207
    move-object/from16 v27, v15

    .line 208
    .line 209
    iget-object v15, v10, Lfc0;->a:Lf7;

    .line 210
    .line 211
    move-object/from16 v28, v2

    .line 212
    .line 213
    iget-object v2, v10, Lfc0;->b:Lic0;

    .line 214
    .line 215
    move-object/from16 v29, v2

    .line 216
    .line 217
    iget-object v2, v10, Lfc0;->c:Lic0;

    .line 218
    .line 219
    move-object/from16 v30, v2

    .line 220
    .line 221
    iget-object v2, v10, Lfc0;->f:Lyf;

    .line 222
    .line 223
    invoke-virtual {v1, v4}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 224
    .line 225
    .line 226
    move-result v17

    .line 227
    move-object/from16 v31, v2

    .line 228
    .line 229
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v2

    .line 233
    if-nez v17, :cond_4

    .line 234
    .line 235
    if-ne v2, v3, :cond_5

    .line 236
    .line 237
    :cond_4
    new-instance v17, Lp2;

    .line 238
    .line 239
    const/16 v23, 0x0

    .line 240
    .line 241
    const/16 v24, 0x7

    .line 242
    .line 243
    const/16 v18, 0x1

    .line 244
    .line 245
    const-class v20, Law;

    .line 246
    .line 247
    const-string v21, "setTileLongClickTarget"

    .line 248
    .line 249
    const-string v22, "setTileLongClickTarget(Lcom/box/app/data/NotificationClickTarget;)V"

    .line 250
    .line 251
    move-object/from16 v19, v4

    .line 252
    .line 253
    invoke-direct/range {v17 .. v24}, Lp2;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 254
    .line 255
    .line 256
    move-object/from16 v2, v17

    .line 257
    .line 258
    invoke-virtual {v1, v2}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 259
    .line 260
    .line 261
    :cond_5
    check-cast v2, Lli2;

    .line 262
    .line 263
    invoke-virtual {v1, v4}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    move-result v17

    .line 267
    move-object/from16 v32, v2

    .line 268
    .line 269
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v2

    .line 273
    if-nez v17, :cond_6

    .line 274
    .line 275
    if-ne v2, v3, :cond_7

    .line 276
    .line 277
    :cond_6
    new-instance v17, Lp2;

    .line 278
    .line 279
    const/16 v23, 0x0

    .line 280
    .line 281
    const/16 v24, 0x8

    .line 282
    .line 283
    const/16 v18, 0x1

    .line 284
    .line 285
    const-class v20, Law;

    .line 286
    .line 287
    const-string v21, "setOpenPanelOnLaunch"

    .line 288
    .line 289
    const-string v22, "setOpenPanelOnLaunch(Z)V"

    .line 290
    .line 291
    move-object/from16 v19, v4

    .line 292
    .line 293
    invoke-direct/range {v17 .. v24}, Lp2;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 294
    .line 295
    .line 296
    move-object/from16 v2, v17

    .line 297
    .line 298
    invoke-virtual {v1, v2}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 299
    .line 300
    .line 301
    :cond_7
    check-cast v2, Lli2;

    .line 302
    .line 303
    iget-object v4, v10, Lfc0;->g:Lvb0;

    .line 304
    .line 305
    move-object/from16 v17, v2

    .line 306
    .line 307
    iget-object v2, v10, Lfc0;->h:Ln2;

    .line 308
    .line 309
    move-object/from16 v24, v2

    .line 310
    .line 311
    iget-object v2, v10, Lfc0;->i:Lx;

    .line 312
    .line 313
    iget-object v5, v5, Lgc0;->b:Lz75;

    .line 314
    .line 315
    invoke-virtual {v5}, Lz75;->getValue()Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v5

    .line 319
    check-cast v5, Ljava/util/Set;

    .line 320
    .line 321
    iget-object v10, v10, Lfc0;->j:Lhc0;

    .line 322
    .line 323
    move-object/from16 v18, p2

    .line 324
    .line 325
    check-cast v18, Lwh2;

    .line 326
    .line 327
    move-object/from16 v19, v28

    .line 328
    .line 329
    check-cast v19, Lwh2;

    .line 330
    .line 331
    move-object/from16 v20, v32

    .line 332
    .line 333
    check-cast v20, Lwh2;

    .line 334
    .line 335
    check-cast v17, Lwh2;

    .line 336
    .line 337
    move-object/from16 v21, v2

    .line 338
    .line 339
    iget-object v2, v0, La90;->l:Lck4;

    .line 340
    .line 341
    invoke-virtual {v1, v2}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 342
    .line 343
    .line 344
    move-result v22

    .line 345
    move-object/from16 v23, v4

    .line 346
    .line 347
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 348
    .line 349
    .line 350
    move-result-object v4

    .line 351
    if-nez v22, :cond_8

    .line 352
    .line 353
    if-eq v4, v3, :cond_8

    .line 354
    .line 355
    move-object/from16 p2, v5

    .line 356
    .line 357
    goto :goto_2

    .line 358
    :cond_8
    new-instance v4, Lz80;

    .line 359
    .line 360
    move-object/from16 p2, v5

    .line 361
    .line 362
    const/16 v5, 0x10

    .line 363
    .line 364
    invoke-direct {v4, v2, v5}, Lz80;-><init>(Lck4;B)V

    .line 365
    .line 366
    .line 367
    invoke-virtual {v1, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 368
    .line 369
    .line 370
    :goto_2
    move-object/from16 v22, v4

    .line 371
    .line 372
    check-cast v22, Llh2;

    .line 373
    .line 374
    invoke-virtual {v1, v2}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 375
    .line 376
    .line 377
    move-result v4

    .line 378
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 379
    .line 380
    .line 381
    move-result-object v5

    .line 382
    if-nez v4, :cond_9

    .line 383
    .line 384
    if-ne v5, v3, :cond_a

    .line 385
    .line 386
    :cond_9
    new-instance v5, Lz80;

    .line 387
    .line 388
    const/16 v4, 0x11

    .line 389
    .line 390
    invoke-direct {v5, v2, v4}, Lz80;-><init>(Lck4;B)V

    .line 391
    .line 392
    .line 393
    invoke-virtual {v1, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 394
    .line 395
    .line 396
    :cond_a
    check-cast v5, Llh2;

    .line 397
    .line 398
    invoke-virtual {v1, v2}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 399
    .line 400
    .line 401
    move-result v4

    .line 402
    move/from16 v28, v4

    .line 403
    .line 404
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 405
    .line 406
    .line 407
    move-result-object v4

    .line 408
    if-nez v28, :cond_b

    .line 409
    .line 410
    if-eq v4, v3, :cond_b

    .line 411
    .line 412
    move-object/from16 v28, v5

    .line 413
    .line 414
    goto :goto_3

    .line 415
    :cond_b
    new-instance v4, Lz80;

    .line 416
    .line 417
    move-object/from16 v28, v5

    .line 418
    .line 419
    const/16 v5, 0x12

    .line 420
    .line 421
    invoke-direct {v4, v2, v5}, Lz80;-><init>(Lck4;B)V

    .line 422
    .line 423
    .line 424
    invoke-virtual {v1, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 425
    .line 426
    .line 427
    :goto_3
    check-cast v4, Llh2;

    .line 428
    .line 429
    invoke-virtual {v1, v2}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 430
    .line 431
    .line 432
    move-result v5

    .line 433
    move-object/from16 v32, v4

    .line 434
    .line 435
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 436
    .line 437
    .line 438
    move-result-object v4

    .line 439
    if-nez v5, :cond_c

    .line 440
    .line 441
    if-ne v4, v3, :cond_d

    .line 442
    .line 443
    :cond_c
    new-instance v4, Lz80;

    .line 444
    .line 445
    const/16 v5, 0x13

    .line 446
    .line 447
    invoke-direct {v4, v2, v5}, Lz80;-><init>(Lck4;B)V

    .line 448
    .line 449
    .line 450
    invoke-virtual {v1, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 451
    .line 452
    .line 453
    :cond_d
    check-cast v4, Llh2;

    .line 454
    .line 455
    invoke-virtual {v1, v2}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 456
    .line 457
    .line 458
    move-result v5

    .line 459
    move-object/from16 v33, v4

    .line 460
    .line 461
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 462
    .line 463
    .line 464
    move-result-object v4

    .line 465
    if-nez v5, :cond_e

    .line 466
    .line 467
    if-ne v4, v3, :cond_f

    .line 468
    .line 469
    :cond_e
    new-instance v4, Lz80;

    .line 470
    .line 471
    const/16 v3, 0x14

    .line 472
    .line 473
    invoke-direct {v4, v2, v3}, Lz80;-><init>(Lck4;B)V

    .line 474
    .line 475
    .line 476
    invoke-virtual {v1, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 477
    .line 478
    .line 479
    :cond_f
    check-cast v4, Llh2;

    .line 480
    .line 481
    const/16 v34, 0x0

    .line 482
    .line 483
    iget v2, v0, La90;->m:F

    .line 484
    .line 485
    iget-boolean v0, v0, La90;->n:Z

    .line 486
    .line 487
    move-object/from16 v3, v31

    .line 488
    .line 489
    move/from16 v31, v2

    .line 490
    .line 491
    move v2, v14

    .line 492
    move-object/from16 v14, v19

    .line 493
    .line 494
    move-object/from16 v19, v20

    .line 495
    .line 496
    move-object/from16 v20, v17

    .line 497
    .line 498
    move-object/from16 v17, v30

    .line 499
    .line 500
    move-object/from16 v30, v4

    .line 501
    .line 502
    move-object v4, v13

    .line 503
    move-object/from16 v13, v18

    .line 504
    .line 505
    move-object/from16 v18, v3

    .line 506
    .line 507
    move-object/from16 v3, v27

    .line 508
    .line 509
    move-object/from16 v27, v10

    .line 510
    .line 511
    move-object v10, v3

    .line 512
    move/from16 v3, p1

    .line 513
    .line 514
    move v5, v12

    .line 515
    move/from16 v12, v25

    .line 516
    .line 517
    move-object/from16 v25, v21

    .line 518
    .line 519
    move-object/from16 v21, v23

    .line 520
    .line 521
    move-object/from16 v23, v28

    .line 522
    .line 523
    move-object/from16 v28, v32

    .line 524
    .line 525
    move/from16 v32, v0

    .line 526
    .line 527
    move-object/from16 v0, v16

    .line 528
    .line 529
    move-object/from16 v16, v29

    .line 530
    .line 531
    move-object/from16 v29, v33

    .line 532
    .line 533
    move-object/from16 v33, v1

    .line 534
    .line 535
    move-object/from16 v1, v26

    .line 536
    .line 537
    move-object/from16 v26, p2

    .line 538
    .line 539
    invoke-static/range {v0 .. v34}, Ln14;->f(Los;Liy2;ZZLjava/lang/String;ZLjava/lang/String;Lic0;Lic0;ZLyt4;ZZLwh2;Lwh2;Lf7;Lic0;Lic0;Lyf;Lwh2;Lwh2;Lvb0;Llh2;Llh2;Ln2;Lx;Ljava/util/Set;Lhc0;Llh2;Llh2;Llh2;FZLzi2;I)V

    .line 540
    .line 541
    .line 542
    goto :goto_4

    .line 543
    :cond_10
    move-object/from16 v33, v1

    .line 544
    .line 545
    invoke-virtual/range {v33 .. v33}, Lzi2;->b0()V

    .line 546
    .line 547
    .line 548
    :goto_4
    sget-object v0, Lst7;->a:Lst7;

    .line 549
    .line 550
    return-object v0
.end method
