.class public final Laj4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Lz75;

.field public final b:Lz75;

.field public final c:Lz75;

.field public final d:Lz75;

.field public e:Lc41;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lbj4;->a:Lbj4;

    .line 5
    .line 6
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Laj4;->a:Lz75;

    .line 11
    .line 12
    sget-object v0, Lo22;->h:Lo22;

    .line 13
    .line 14
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iput-object v1, p0, Laj4;->b:Lz75;

    .line 19
    .line 20
    sget-object v1, Lwi4;->a:Lwi4;

    .line 21
    .line 22
    invoke-static {v1}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    iput-object v1, p0, Laj4;->c:Lz75;

    .line 27
    .line 28
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iput-object v0, p0, Laj4;->d:Lz75;

    .line 33
    .line 34
    return-void
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method
