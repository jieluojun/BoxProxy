.class public final Laj4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Lz75;

.field public final b:Lz75;

.field public final c:Lz75;

.field public final d:Lz75;

.field public e:Lc41;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lbj4;->a:Lbj4;

    .line 5
    .line 6
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Laj4;->a:Lz75;

    .line 11
    .line 12
    sget-object v0, Lo22;->h:Lo22;

    .line 13
    .line 14
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iput-object v1, p0, Laj4;->b:Lz75;

    .line 19
    .line 20
    sget-object v1, Lwi4;->a:Lwi4;

    .line 21
    .line 22
    invoke-static {v1}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    iput-object v1, p0, Laj4;->c:Lz75;

    .line 27
    .line 28
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iput-object v0, p0, Laj4;->d:Lz75;

    .line 33
    .line 34
    return-void
.end method
