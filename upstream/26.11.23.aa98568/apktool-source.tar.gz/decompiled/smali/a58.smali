.class public final La58;
.super Lab4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lqi3;


# instance fields
.field public v:F

.field public w:Ljava/lang/Object;


# virtual methods
.method public final m(Ly14;Lp14;J)Lv14;
    .locals 2

    .line 1
    invoke-interface {p2, p3, p4}, Lp14;->e(J)Lfb5;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    iget p3, p2, Lfb5;->h:I

    .line 6
    .line 7
    iget p4, p2, Lfb5;->i:I

    .line 8
    .line 9
    new-instance v0, Lid7;

    .line 10
    .line 11
    const/16 v1, 0x15

    .line 12
    .line 13
    invoke-direct {v0, p2, p0, v1}, Lid7;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 14
    .line 15
    .line 16
    sget-object p0, Lp22;->h:Lp22;

    .line 17
    .line 18
    invoke-interface {p1, p3, p4, p0, v0}, Ly14;->P0(IILjava/util/Map;Lwh2;)Lv14;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0
.end method
