.class public final Lab1;
.super Lcb1;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public final a(J)J
    .locals 0

    .line 1
    return-wide p1
.end method
