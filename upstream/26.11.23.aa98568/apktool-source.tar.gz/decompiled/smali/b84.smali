.class public final synthetic Lb84;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:Z

.field public final synthetic i:Llh2;

.field public final synthetic j:Lg00;

.field public final synthetic k:Lyh3;

.field public final synthetic l:J

.field public final synthetic m:Z

.field public final synthetic n:Z

.field public final synthetic o:Ljava/lang/String;

.field public final synthetic p:Ls21;

.field public final synthetic q:Ls21;

.field public final synthetic r:Ls21;

.field public final synthetic s:J

.field public final synthetic t:Ls21;

.field public final synthetic u:Lwh2;

.field public final synthetic v:Ls21;


# direct methods
.method public synthetic constructor <init>(ZLlh2;Lg00;Lyh3;JZZLjava/lang/String;Ls21;Ls21;Ls21;JLs21;Lwh2;Ls21;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lb84;->h:Z

    .line 5
    .line 6
    iput-object p2, p0, Lb84;->i:Llh2;

    .line 7
    .line 8
    iput-object p3, p0, Lb84;->j:Lg00;

    .line 9
    .line 10
    iput-object p4, p0, Lb84;->k:Lyh3;

    .line 11
    .line 12
    iput-wide p5, p0, Lb84;->l:J

    .line 13
    .line 14
    iput-boolean p7, p0, Lb84;->m:Z

    .line 15
    .line 16
    iput-boolean p8, p0, Lb84;->n:Z

    .line 17
    .line 18
    iput-object p9, p0, Lb84;->o:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p10, p0, Lb84;->p:Ls21;

    .line 21
    .line 22
    iput-object p11, p0, Lb84;->q:Ls21;

    .line 23
    .line 24
    iput-object p12, p0, Lb84;->r:Ls21;

    .line 25
    .line 26
    iput-wide p13, p0, Lb84;->s:J

    .line 27
    .line 28
    iput-object p15, p0, Lb84;->t:Ls21;

    .line 29
    .line 30
    move-object/from16 p1, p16

    .line 31
    .line 32
    iput-object p1, p0, Lb84;->u:Lwh2;

    .line 33
    .line 34
    move-object/from16 p1, p17

    .line 35
    .line 36
    iput-object p1, p0, Lb84;->v:Ls21;

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lzi2;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    and-int/lit8 v3, v2, 0x3

    .line 16
    .line 17
    const/4 v4, 0x2

    .line 18
    const/4 v5, 0x1

    .line 19
    if-eq v3, v4, :cond_0

    .line 20
    .line 21
    move v3, v5

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v3, 0x0

    .line 24
    :goto_0
    and-int/2addr v2, v5

    .line 25
    invoke-virtual {v1, v2, v3}, Lzi2;->Y(IZ)Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_3

    .line 30
    .line 31
    sget-object v2, Lsr1;->a:Lux1;

    .line 32
    .line 33
    iget-boolean v3, v0, Lb84;->h:Z

    .line 34
    .line 35
    invoke-virtual {v1, v3}, Lzi2;->h(Z)Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    iget-object v5, v0, Lb84;->i:Llh2;

    .line 40
    .line 41
    invoke-virtual {v1, v5}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v6

    .line 45
    or-int/2addr v4, v6

    .line 46
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v6

    .line 50
    if-nez v4, :cond_1

    .line 51
    .line 52
    sget-object v4, Lc51;->a:Lql0;

    .line 53
    .line 54
    if-ne v6, v4, :cond_2

    .line 55
    .line 56
    :cond_1
    new-instance v6, Lws;

    .line 57
    .line 58
    const/16 v4, 0xd

    .line 59
    .line 60
    invoke-direct {v6, v3, v5, v4}, Lws;-><init>(ZLlh2;B)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    :cond_2
    check-cast v6, Llh2;

    .line 67
    .line 68
    invoke-virtual {v2, v6}, Lux1;->a(Ljava/lang/Object;)Lci5;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    new-instance v3, Le84;

    .line 73
    .line 74
    iget-object v4, v0, Lb84;->j:Lg00;

    .line 75
    .line 76
    iget-object v5, v0, Lb84;->k:Lyh3;

    .line 77
    .line 78
    iget-wide v6, v0, Lb84;->l:J

    .line 79
    .line 80
    iget-boolean v8, v0, Lb84;->m:Z

    .line 81
    .line 82
    iget-boolean v9, v0, Lb84;->n:Z

    .line 83
    .line 84
    iget-object v10, v0, Lb84;->o:Ljava/lang/String;

    .line 85
    .line 86
    iget-object v11, v0, Lb84;->p:Ls21;

    .line 87
    .line 88
    iget-object v12, v0, Lb84;->q:Ls21;

    .line 89
    .line 90
    iget-object v13, v0, Lb84;->r:Ls21;

    .line 91
    .line 92
    iget-wide v14, v0, Lb84;->s:J

    .line 93
    .line 94
    move-object/from16 p1, v3

    .line 95
    .line 96
    iget-object v3, v0, Lb84;->t:Ls21;

    .line 97
    .line 98
    move-object/from16 v16, v3

    .line 99
    .line 100
    iget-object v3, v0, Lb84;->u:Lwh2;

    .line 101
    .line 102
    iget-object v0, v0, Lb84;->v:Ls21;

    .line 103
    .line 104
    move-object/from16 v18, v0

    .line 105
    .line 106
    move-object/from16 v17, v3

    .line 107
    .line 108
    move-object/from16 v3, p1

    .line 109
    .line 110
    invoke-direct/range {v3 .. v18}, Le84;-><init>(Lg00;Lyh3;JZZLjava/lang/String;Ls21;Ls21;Ls21;JLs21;Lwh2;Ls21;)V

    .line 111
    .line 112
    .line 113
    const v0, 0x5796e2b4

    .line 114
    .line 115
    .line 116
    invoke-static {v0, v3, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    const/16 v3, 0x38

    .line 121
    .line 122
    invoke-static {v2, v0, v1, v3}, Luu;->i(Lci5;Lai2;Lzi2;I)V

    .line 123
    .line 124
    .line 125
    goto :goto_1

    .line 126
    :cond_3
    invoke-virtual {v1}, Lzi2;->b0()V

    .line 127
    .line 128
    .line 129
    :goto_1
    sget-object v0, Lst7;->a:Lst7;

    .line 130
    .line 131
    return-object v0
.end method
