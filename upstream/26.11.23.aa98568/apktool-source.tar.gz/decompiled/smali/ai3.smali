.class public final Lai3;
.super Lab4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lcw1;
.implements Lnp2;


# instance fields
.field public v:Lyh3;


# virtual methods
.method public final H(Lbt4;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Lbt4;->B1()Lab4;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v0, v0, Lab4;->u:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object p0, p0, Lai3;->v:Lyh3;

    .line 10
    .line 11
    iget-object p0, p0, Lyh3;->c:Lz75;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final l0(Lbj3;)V
    .locals 6

    .line 1
    invoke-virtual {p1}, Lbj3;->c()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lai3;->v:Lyh3;

    .line 5
    .line 6
    iget-object v0, v0, Lyh3;->a:Lsq2;

    .line 7
    .line 8
    iget-object v1, p1, Lbj3;->h:Ltl0;

    .line 9
    .line 10
    invoke-interface {v1}, Ldw1;->b()J

    .line 11
    .line 12
    .line 13
    move-result-wide v1

    .line 14
    invoke-static {v1, v2}, Luu;->r0(J)J

    .line 15
    .line 16
    .line 17
    move-result-wide v1

    .line 18
    invoke-static {p0}, Lsx;->l0(Lap1;)Lzi3;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    iget-object v3, v3, Lzi3;->F:Lkp1;

    .line 23
    .line 24
    new-instance v4, Lk30;

    .line 25
    .line 26
    const/4 v5, 0x2

    .line 27
    invoke-direct {v4, v3, p0, p1, v5}, Lk30;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1, v0, v1, v2, v4}, Lbj3;->d0(Lsq2;JLwh2;)V

    .line 31
    .line 32
    .line 33
    return-void
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public final z1()V
    .locals 1

    .line 1
    iget-object p0, p0, Lai3;->v:Lyh3;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    iget-object p0, p0, Lyh3;->c:Lz75;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
