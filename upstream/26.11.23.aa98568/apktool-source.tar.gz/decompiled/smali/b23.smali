.class final Lb23;
.super Ljb4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljb4;"
    }
.end annotation


# instance fields
.field public final h:Ltd4;


# direct methods
.method public constructor <init>(Ltd4;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb23;->h:Ltd4;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lab4;
    .locals 1

    .line 1
    new-instance v0, Lf23;

    .line 2
    .line 3
    invoke-direct {v0}, Lab4;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lb23;->h:Ltd4;

    .line 7
    .line 8
    iput-object p0, v0, Lf23;->v:Ltd4;

    .line 9
    .line 10
    return-object v0
.end method

.method public final b(Lab4;)V
    .locals 1

    .line 1
    check-cast p1, Lf23;

    .line 2
    .line 3
    iget-object v0, p1, Lf23;->v:Ltd4;

    .line 4
    .line 5
    iget-object p0, p0, Lb23;->h:Ltd4;

    .line 6
    .line 7
    invoke-static {v0, p0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1}, Lf23;->I1()V

    .line 14
    .line 15
    .line 16
    iput-object p0, p1, Lf23;->v:Ltd4;

    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lb23;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lb23;

    .line 12
    .line 13
    iget-object p1, p1, Lb23;->h:Ltd4;

    .line 14
    .line 15
    iget-object p0, p0, Lb23;->h:Ltd4;

    .line 16
    .line 17
    invoke-static {p1, p0}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-nez p0, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    return v0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lb23;->h:Ltd4;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    mul-int/lit8 p0, p0, 0x1f

    .line 8
    .line 9
    return p0
.end method
