.class public final Lab2;
.super Lrj3;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final c:Luz4;

.field public final d:Luz4;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Luz4;

    .line 5
    .line 6
    invoke-direct {v0}, Luz4;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lab2;->c:Luz4;

    .line 10
    .line 11
    new-instance v0, Luz4;

    .line 12
    .line 13
    invoke-direct {v0}, Luz4;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lab2;->d:Luz4;

    .line 17
    .line 18
    return-void
.end method
