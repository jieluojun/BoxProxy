.class public abstract Lb30;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:Lux1;

.field public static final b:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static c:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Llv;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-direct {v0, v1}, Llv;-><init>(B)V

    .line 5
    .line 6
    .line 7
    new-instance v1, Lux1;

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    invoke-direct {v1, v0, v2}, Lux1;-><init>(Llh2;B)V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lb30;->a:Lux1;

    .line 14
    .line 15
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 19
    .line 20
    .line 21
    sput-object v0, Lb30;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 22
    .line 23
    return-void
.end method

.method public static final a(Lij;Lbi7;Lff2;Lfu3;Ljava/util/List;ZLzi2;)V
    .locals 12

    .line 1
    move-object/from16 v0, p6

    .line 2
    .line 3
    sget-object v1, Lb30;->a:Lux1;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Ljava/util/concurrent/Executor;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-object v3, p0, Lij;->i:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    invoke-static {v3}, Lb30;->b(I)Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-eqz v3, :cond_0

    .line 25
    .line 26
    const v3, 0x32210da0

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0, v3}, Lzi2;->h0(I)V

    .line 30
    .line 31
    .line 32
    sget-object v3, Lz51;->i:La61;

    .line 33
    .line 34
    invoke-virtual {v0, v3}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    move-object v5, v3

    .line 39
    check-cast v5, Lii3;

    .line 40
    .line 41
    sget-object v3, Lz51;->d:La61;

    .line 42
    .line 43
    invoke-virtual {v0, v3}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    move-object v8, v3

    .line 48
    check-cast v8, Lkp1;

    .line 49
    .line 50
    :try_start_0
    new-instance v3, Lz20;

    .line 51
    .line 52
    move-object v7, p0

    .line 53
    move-object v4, p1

    .line 54
    move-object v9, p2

    .line 55
    move-object v11, p3

    .line 56
    move-object/from16 v6, p4

    .line 57
    .line 58
    move/from16 v10, p5

    .line 59
    .line 60
    invoke-direct/range {v3 .. v11}, Lz20;-><init>(Lbi7;Lii3;Ljava/util/List;Lij;Lkp1;Lff2;ZLfu3;)V

    .line 61
    .line 62
    .line 63
    invoke-interface {v1, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    .line 65
    .line 66
    :catch_0
    invoke-virtual {v0, v2}, Lzi2;->r(Z)V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :cond_0
    const v1, 0x32385313

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v0, v2}, Lzi2;->r(Z)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public static final b(I)Z
    .locals 3

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-lt p0, v0, :cond_2

    .line 5
    .line 6
    const/16 v0, 0x3e8

    .line 7
    .line 8
    if-ge p0, v0, :cond_2

    .line 9
    .line 10
    sget-object p0, Lb30;->c:Ljava/lang/Boolean;

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    if-nez p0, :cond_1

    .line 14
    .line 15
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-virtual {p0}, Ljava/lang/Runtime;->availableProcessors()I

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    const/4 v2, 0x4

    .line 24
    if-lt p0, v2, :cond_0

    .line 25
    .line 26
    move p0, v0

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    move p0, v1

    .line 29
    :goto_0
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    sput-object p0, Lb30;->c:Ljava/lang/Boolean;

    .line 34
    .line 35
    :cond_1
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    if-eqz p0, :cond_2

    .line 40
    .line 41
    return v0

    .line 42
    :cond_2
    return v1
.end method
