.class public final synthetic Lal1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ldd5;

.field public final synthetic j:Lcd5;


# direct methods
.method public synthetic constructor <init>(Lcd5;Ldd5;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lal1;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lal1;->j:Lcd5;

    .line 8
    .line 9
    iput-object p2, p0, Lal1;->i:Ldd5;

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ldd5;Lcd5;)V
    .locals 1

    .line 12
    const/4 v0, 0x1

    iput-byte v0, p0, Lal1;->h:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lal1;->i:Ldd5;

    iput-object p2, p0, Lal1;->j:Lcd5;

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 36

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lal1;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    sget-object v4, Lc51;->a:Lql0;

    .line 9
    .line 10
    iget-object v5, v0, Lal1;->j:Lcd5;

    .line 11
    .line 12
    const/4 v6, 0x1

    .line 13
    const/4 v7, 0x0

    .line 14
    packed-switch v1, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    move-object/from16 v1, p1

    .line 18
    .line 19
    check-cast v1, Lzi2;

    .line 20
    .line 21
    move-object/from16 v8, p2

    .line 22
    .line 23
    check-cast v8, Ljava/lang/Integer;

    .line 24
    .line 25
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 26
    .line 27
    .line 28
    move-result v8

    .line 29
    and-int/lit8 v9, v8, 0x3

    .line 30
    .line 31
    if-eq v9, v3, :cond_0

    .line 32
    .line 33
    move v7, v6

    .line 34
    :cond_0
    and-int/2addr v8, v6

    .line 35
    invoke-virtual {v1, v8, v7}, Lzi2;->Y(IZ)Z

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    if-eqz v3, :cond_a

    .line 40
    .line 41
    sget-object v3, Lya4;->h:Lya4;

    .line 42
    .line 43
    const/high16 v7, 0x3f800000    # 1.0f

    .line 44
    .line 45
    invoke-static {v3, v7}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 46
    .line 47
    .line 48
    move-result-object v8

    .line 49
    new-instance v9, Lnw;

    .line 50
    .line 51
    new-instance v10, Ll42;

    .line 52
    .line 53
    const/4 v11, 0x3

    .line 54
    invoke-direct {v10, v11}, Ll42;-><init>(B)V

    .line 55
    .line 56
    .line 57
    const/high16 v12, 0x41800000    # 16.0f

    .line 58
    .line 59
    invoke-direct {v9, v12, v6, v10}, Lnw;-><init>(FZLl42;)V

    .line 60
    .line 61
    .line 62
    sget-object v10, Ly6;->v:Lz30;

    .line 63
    .line 64
    const/4 v12, 0x6

    .line 65
    invoke-static {v9, v10, v1, v12}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 66
    .line 67
    .line 68
    move-result-object v9

    .line 69
    iget-wide v13, v1, Lzi2;->U:J

    .line 70
    .line 71
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 72
    .line 73
    .line 74
    move-result v10

    .line 75
    invoke-virtual {v1}, Lzi2;->m()Lla5;

    .line 76
    .line 77
    .line 78
    move-result-object v13

    .line 79
    invoke-static {v1, v8}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 80
    .line 81
    .line 82
    move-result-object v8

    .line 83
    sget-object v14, Ls41;->d:Ly6;

    .line 84
    .line 85
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v1}, Lzi2;->k0()V

    .line 89
    .line 90
    .line 91
    iget-boolean v14, v1, Lzi2;->T:Z

    .line 92
    .line 93
    sget-object v15, Lzi3;->Z:Lu43;

    .line 94
    .line 95
    if-eqz v14, :cond_1

    .line 96
    .line 97
    invoke-virtual {v1, v15}, Lzi2;->l(Llh2;)V

    .line 98
    .line 99
    .line 100
    goto :goto_0

    .line 101
    :cond_1
    invoke-virtual {v1}, Lzi2;->t0()V

    .line 102
    .line 103
    .line 104
    :goto_0
    sget-object v14, Ly6;->T:Lx31;

    .line 105
    .line 106
    invoke-static {v14, v1, v9}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    sget-object v9, Ly6;->S:Lx31;

    .line 110
    .line 111
    invoke-static {v9, v1, v13}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 115
    .line 116
    .line 117
    move-result-object v10

    .line 118
    sget-object v13, Ly6;->U:Lx31;

    .line 119
    .line 120
    invoke-static {v13, v1, v10}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v1}, Lfa7;->k(Lzi2;)V

    .line 124
    .line 125
    .line 126
    sget-object v10, Ly6;->R:Lx31;

    .line 127
    .line 128
    invoke-static {v10, v1, v8}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    const v8, 0x7f0f03cc

    .line 132
    .line 133
    .line 134
    invoke-static {v8, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v8

    .line 138
    move-object/from16 v16, v9

    .line 139
    .line 140
    invoke-static {v3, v7}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 141
    .line 142
    .line 143
    move-result-object v9

    .line 144
    sget-object v12, Lvz0;->a:Lux1;

    .line 145
    .line 146
    invoke-virtual {v1, v12}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v12

    .line 150
    check-cast v12, Luz0;

    .line 151
    .line 152
    invoke-virtual {v12}, Luz0;->n()J

    .line 153
    .line 154
    .line 155
    move-result-wide v17

    .line 156
    new-instance v12, Lca7;

    .line 157
    .line 158
    invoke-direct {v12, v11}, Lca7;-><init>(I)V

    .line 159
    .line 160
    .line 161
    const/16 v29, 0x0

    .line 162
    .line 163
    const v30, 0x3fbf8

    .line 164
    .line 165
    .line 166
    move-object v11, v13

    .line 167
    move-wide/from16 v19, v17

    .line 168
    .line 169
    move-object/from16 v18, v12

    .line 170
    .line 171
    const-wide/16 v12, 0x0

    .line 172
    .line 173
    move-object/from16 v17, v14

    .line 174
    .line 175
    const/4 v14, 0x0

    .line 176
    move-object/from16 v21, v15

    .line 177
    .line 178
    const/4 v15, 0x0

    .line 179
    move-object/from16 v23, v16

    .line 180
    .line 181
    move-object/from16 v22, v17

    .line 182
    .line 183
    const-wide/16 v16, 0x0

    .line 184
    .line 185
    move-object/from16 v25, v10

    .line 186
    .line 187
    move-object/from16 v24, v11

    .line 188
    .line 189
    move-wide/from16 v10, v19

    .line 190
    .line 191
    const-wide/16 v19, 0x0

    .line 192
    .line 193
    move-object/from16 v26, v21

    .line 194
    .line 195
    const/16 v21, 0x0

    .line 196
    .line 197
    move-object/from16 v27, v22

    .line 198
    .line 199
    const/16 v22, 0x0

    .line 200
    .line 201
    move-object/from16 v28, v23

    .line 202
    .line 203
    const/16 v23, 0x0

    .line 204
    .line 205
    move-object/from16 v31, v24

    .line 206
    .line 207
    const/16 v24, 0x0

    .line 208
    .line 209
    move-object/from16 v32, v25

    .line 210
    .line 211
    const/16 v25, 0x0

    .line 212
    .line 213
    move-object/from16 v33, v26

    .line 214
    .line 215
    const/16 v26, 0x0

    .line 216
    .line 217
    move-object/from16 v34, v28

    .line 218
    .line 219
    const/16 v28, 0x30

    .line 220
    .line 221
    move-object/from16 v6, v27

    .line 222
    .line 223
    move-object/from16 v27, v1

    .line 224
    .line 225
    move-object v1, v6

    .line 226
    move-object/from16 v35, v33

    .line 227
    .line 228
    move-object/from16 v6, v34

    .line 229
    .line 230
    move-object/from16 v34, v4

    .line 231
    .line 232
    move-object/from16 v33, v5

    .line 233
    .line 234
    move-object/from16 v5, v32

    .line 235
    .line 236
    const/4 v4, 0x6

    .line 237
    move-object/from16 v32, v2

    .line 238
    .line 239
    move-object/from16 v2, v31

    .line 240
    .line 241
    invoke-static/range {v8 .. v30}, Lma7;->a(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILwh2;Lbi7;Lzi2;III)V

    .line 242
    .line 243
    .line 244
    move-object/from16 v8, v27

    .line 245
    .line 246
    invoke-static {v3, v7}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 247
    .line 248
    .line 249
    move-result-object v9

    .line 250
    sget-object v10, Lob3;->k:Ls38;

    .line 251
    .line 252
    sget-object v11, Ly6;->s:La40;

    .line 253
    .line 254
    invoke-static {v10, v11, v8, v4}, Ln26;->a(Lmw;La40;Lzi2;I)Lo26;

    .line 255
    .line 256
    .line 257
    move-result-object v4

    .line 258
    iget-wide v10, v8, Lzi2;->U:J

    .line 259
    .line 260
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 261
    .line 262
    .line 263
    move-result v10

    .line 264
    invoke-virtual {v8}, Lzi2;->m()Lla5;

    .line 265
    .line 266
    .line 267
    move-result-object v11

    .line 268
    invoke-static {v8, v9}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 269
    .line 270
    .line 271
    move-result-object v9

    .line 272
    invoke-virtual {v8}, Lzi2;->k0()V

    .line 273
    .line 274
    .line 275
    iget-boolean v12, v8, Lzi2;->T:Z

    .line 276
    .line 277
    if-eqz v12, :cond_2

    .line 278
    .line 279
    move-object/from16 v12, v35

    .line 280
    .line 281
    invoke-virtual {v8, v12}, Lzi2;->l(Llh2;)V

    .line 282
    .line 283
    .line 284
    goto :goto_1

    .line 285
    :cond_2
    invoke-virtual {v8}, Lzi2;->t0()V

    .line 286
    .line 287
    .line 288
    :goto_1
    invoke-static {v1, v8, v4}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 289
    .line 290
    .line 291
    invoke-static {v6, v8, v11}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 292
    .line 293
    .line 294
    invoke-static {v10, v8, v2, v8}, Lp92;->w(ILzi2;Lx31;Lzi2;)V

    .line 295
    .line 296
    .line 297
    invoke-static {v5, v8, v9}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    const/high16 v1, 0x1040000

    .line 301
    .line 302
    invoke-static {v1, v8}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    move-result-object v1

    .line 306
    iget-object v11, v0, Lal1;->i:Ldd5;

    .line 307
    .line 308
    invoke-virtual {v8, v11}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result v0

    .line 312
    invoke-virtual {v8}, Lzi2;->T()Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object v2

    .line 316
    move-object/from16 v4, v34

    .line 317
    .line 318
    if-nez v0, :cond_3

    .line 319
    .line 320
    if-eq v2, v4, :cond_3

    .line 321
    .line 322
    move-object v0, v11

    .line 323
    goto :goto_2

    .line 324
    :cond_3
    new-instance v9, Lhl1;

    .line 325
    .line 326
    const/4 v15, 0x0

    .line 327
    const/16 v16, 0x2

    .line 328
    .line 329
    const/4 v10, 0x0

    .line 330
    const-class v12, Ldd5;

    .line 331
    .line 332
    const-string v13, "dismissClearAll"

    .line 333
    .line 334
    const-string v14, "dismissClearAll()V"

    .line 335
    .line 336
    invoke-direct/range {v9 .. v16}, Lhl1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 337
    .line 338
    .line 339
    move-object v0, v11

    .line 340
    invoke-virtual {v8, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 341
    .line 342
    .line 343
    move-object v2, v9

    .line 344
    :goto_2
    check-cast v2, Lli2;

    .line 345
    .line 346
    move-object v9, v2

    .line 347
    check-cast v9, Llh2;

    .line 348
    .line 349
    float-to-double v5, v7

    .line 350
    const-wide/16 v21, 0x0

    .line 351
    .line 352
    cmpl-double v2, v5, v21

    .line 353
    .line 354
    const-string v5, "invalid weight; must be greater than zero"

    .line 355
    .line 356
    if-gtz v2, :cond_4

    .line 357
    .line 358
    invoke-static {v5}, Ln73;->a(Ljava/lang/String;)V

    .line 359
    .line 360
    .line 361
    :cond_4
    new-instance v10, Lsj3;

    .line 362
    .line 363
    const v2, 0x7f7fffff    # Float.MAX_VALUE

    .line 364
    .line 365
    .line 366
    cmpl-float v6, v7, v2

    .line 367
    .line 368
    if-lez v6, :cond_5

    .line 369
    .line 370
    move v6, v2

    .line 371
    :goto_3
    const/4 v11, 0x1

    .line 372
    goto :goto_4

    .line 373
    :cond_5
    move v6, v7

    .line 374
    goto :goto_3

    .line 375
    :goto_4
    invoke-direct {v10, v6, v11}, Lsj3;-><init>(FZ)V

    .line 376
    .line 377
    .line 378
    const/16 v19, 0x0

    .line 379
    .line 380
    const/16 v20, 0xff8

    .line 381
    .line 382
    const/4 v11, 0x0

    .line 383
    const/4 v12, 0x0

    .line 384
    const/4 v13, 0x0

    .line 385
    const/4 v14, 0x0

    .line 386
    const/4 v15, 0x0

    .line 387
    const/16 v16, 0x0

    .line 388
    .line 389
    const/16 v17, 0x0

    .line 390
    .line 391
    move-object/from16 v18, v8

    .line 392
    .line 393
    move-object v8, v1

    .line 394
    invoke-static/range {v8 .. v20}, Lnl3;->c(Ljava/lang/String;Llh2;Lbb4;ZFFFLd74;Lo45;Li63;Lzi2;II)V

    .line 395
    .line 396
    .line 397
    move-object/from16 v8, v18

    .line 398
    .line 399
    const/high16 v1, 0x41a00000    # 20.0f

    .line 400
    .line 401
    const v6, 0x7f0f03cb

    .line 402
    .line 403
    .line 404
    invoke-static {v3, v1, v8, v6, v8}, Lp92;->o(Lya4;FLzi2;ILzi2;)Ljava/lang/String;

    .line 405
    .line 406
    .line 407
    move-result-object v1

    .line 408
    move-object/from16 v6, v33

    .line 409
    .line 410
    invoke-virtual {v8, v6}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 411
    .line 412
    .line 413
    move-result v3

    .line 414
    invoke-virtual {v8, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 415
    .line 416
    .line 417
    move-result v9

    .line 418
    or-int/2addr v3, v9

    .line 419
    invoke-virtual {v8}, Lzi2;->T()Ljava/lang/Object;

    .line 420
    .line 421
    .line 422
    move-result-object v9

    .line 423
    if-nez v3, :cond_6

    .line 424
    .line 425
    if-ne v9, v4, :cond_7

    .line 426
    .line 427
    :cond_6
    new-instance v9, Lbl1;

    .line 428
    .line 429
    const/4 v11, 0x1

    .line 430
    invoke-direct {v9, v6, v0, v11}, Lbl1;-><init>(Lcd5;Ldd5;B)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {v8, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 434
    .line 435
    .line 436
    :cond_7
    check-cast v9, Llh2;

    .line 437
    .line 438
    float-to-double v3, v7

    .line 439
    cmpl-double v0, v3, v21

    .line 440
    .line 441
    if-gtz v0, :cond_8

    .line 442
    .line 443
    invoke-static {v5}, Ln73;->a(Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    :cond_8
    new-instance v10, Lsj3;

    .line 447
    .line 448
    cmpl-float v0, v7, v2

    .line 449
    .line 450
    if-lez v0, :cond_9

    .line 451
    .line 452
    move v7, v2

    .line 453
    :cond_9
    const/4 v0, 0x1

    .line 454
    invoke-direct {v10, v7, v0}, Lsj3;-><init>(FZ)V

    .line 455
    .line 456
    .line 457
    const/high16 v19, 0xc00000

    .line 458
    .line 459
    const/16 v20, 0xf78

    .line 460
    .line 461
    const/4 v11, 0x0

    .line 462
    const/4 v12, 0x0

    .line 463
    const/4 v13, 0x0

    .line 464
    const/4 v14, 0x0

    .line 465
    sget-object v15, Ld74;->j:Ld74;

    .line 466
    .line 467
    const/16 v16, 0x0

    .line 468
    .line 469
    const/16 v17, 0x0

    .line 470
    .line 471
    move-object/from16 v18, v8

    .line 472
    .line 473
    move-object v8, v1

    .line 474
    invoke-static/range {v8 .. v20}, Lnl3;->c(Ljava/lang/String;Llh2;Lbb4;ZFFFLd74;Lo45;Li63;Lzi2;II)V

    .line 475
    .line 476
    .line 477
    move-object/from16 v8, v18

    .line 478
    .line 479
    invoke-virtual {v8, v0}, Lzi2;->r(Z)V

    .line 480
    .line 481
    .line 482
    invoke-virtual {v8, v0}, Lzi2;->r(Z)V

    .line 483
    .line 484
    .line 485
    goto :goto_5

    .line 486
    :cond_a
    move-object v8, v1

    .line 487
    move-object/from16 v32, v2

    .line 488
    .line 489
    invoke-virtual {v8}, Lzi2;->b0()V

    .line 490
    .line 491
    .line 492
    :goto_5
    return-object v32

    .line 493
    :pswitch_0
    move-object/from16 v32, v2

    .line 494
    .line 495
    move-object v6, v5

    .line 496
    move-object/from16 v1, p1

    .line 497
    .line 498
    check-cast v1, Lzi2;

    .line 499
    .line 500
    move-object/from16 v2, p2

    .line 501
    .line 502
    check-cast v2, Ljava/lang/Integer;

    .line 503
    .line 504
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 505
    .line 506
    .line 507
    move-result v2

    .line 508
    and-int/lit8 v5, v2, 0x3

    .line 509
    .line 510
    if-eq v5, v3, :cond_b

    .line 511
    .line 512
    const/4 v11, 0x1

    .line 513
    :goto_6
    const/16 v31, 0x1

    .line 514
    .line 515
    goto :goto_7

    .line 516
    :cond_b
    move v11, v7

    .line 517
    goto :goto_6

    .line 518
    :goto_7
    and-int/lit8 v2, v2, 0x1

    .line 519
    .line 520
    invoke-virtual {v1, v2, v11}, Lzi2;->Y(IZ)Z

    .line 521
    .line 522
    .line 523
    move-result v2

    .line 524
    if-eqz v2, :cond_e

    .line 525
    .line 526
    invoke-virtual {v1, v6}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 527
    .line 528
    .line 529
    move-result v2

    .line 530
    iget-object v0, v0, Lal1;->i:Ldd5;

    .line 531
    .line 532
    invoke-virtual {v1, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 533
    .line 534
    .line 535
    move-result v3

    .line 536
    or-int/2addr v2, v3

    .line 537
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 538
    .line 539
    .line 540
    move-result-object v3

    .line 541
    if-nez v2, :cond_c

    .line 542
    .line 543
    if-ne v3, v4, :cond_d

    .line 544
    .line 545
    :cond_c
    new-instance v3, Lbl1;

    .line 546
    .line 547
    invoke-direct {v3, v6, v0, v7}, Lbl1;-><init>(Lcd5;Ldd5;B)V

    .line 548
    .line 549
    .line 550
    invoke-virtual {v1, v3}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 551
    .line 552
    .line 553
    :cond_d
    move-object v9, v3

    .line 554
    check-cast v9, Llh2;

    .line 555
    .line 556
    sget-object v0, Leh0;->a:Lo45;

    .line 557
    .line 558
    sget-object v0, Lh14;->b:Lux1;

    .line 559
    .line 560
    invoke-virtual {v1, v0}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 561
    .line 562
    .line 563
    move-result-object v2

    .line 564
    check-cast v2, Le14;

    .line 565
    .line 566
    iget-object v2, v2, Le14;->a:Lny0;

    .line 567
    .line 568
    iget-wide v2, v2, Lny0;->w:J

    .line 569
    .line 570
    invoke-virtual {v1, v0}, Lzi2;->k(Lzh5;)Ljava/lang/Object;

    .line 571
    .line 572
    .line 573
    move-result-object v0

    .line 574
    check-cast v0, Le14;

    .line 575
    .line 576
    iget-object v0, v0, Le14;->a:Lny0;

    .line 577
    .line 578
    iget-wide v4, v0, Lny0;->x:J

    .line 579
    .line 580
    invoke-static {v2, v3, v4, v5, v1}, Leh0;->a(JJLzi2;)Lch0;

    .line 581
    .line 582
    .line 583
    move-result-object v13

    .line 584
    sget-object v17, Lv97;->x:Ls21;

    .line 585
    .line 586
    const/high16 v19, 0x30000000

    .line 587
    .line 588
    const/16 v20, 0x1ee

    .line 589
    .line 590
    const/4 v10, 0x0

    .line 591
    const/4 v11, 0x0

    .line 592
    const/4 v12, 0x0

    .line 593
    const/4 v14, 0x0

    .line 594
    const/4 v15, 0x0

    .line 595
    const/16 v16, 0x0

    .line 596
    .line 597
    move-object/from16 v18, v1

    .line 598
    .line 599
    invoke-static/range {v9 .. v20}, Llx;->b(Llh2;Lbb4;ZLbo6;Lch0;Lih0;Lr50;Lo45;Lbi2;Lzi2;II)V

    .line 600
    .line 601
    .line 602
    goto :goto_8

    .line 603
    :cond_e
    move-object/from16 v18, v1

    .line 604
    .line 605
    invoke-virtual/range {v18 .. v18}, Lzi2;->b0()V

    .line 606
    .line 607
    .line 608
    :goto_8
    return-object v32

    .line 609
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
