.class public final enum Lar5;
.super Ljava/lang/Enum;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final k:Llb5;

.field public static final enum l:Lar5;

.field public static final enum m:Lar5;

.field public static final enum n:Lar5;

.field public static final enum o:Lar5;

.field public static final enum p:Lar5;

.field public static final enum q:Lar5;

.field public static final synthetic r:[Lar5;

.field public static final synthetic s:Lc42;


# instance fields
.field public final h:Ljava/lang/String;

.field public final i:Ljava/lang/String;

.field public final j:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .locals 14

    .line 1
    new-instance v0, Lar5;

    .line 2
    .line 3
    const-string v6, ".yaml"

    .line 4
    .line 5
    const-string v7, ".yml"

    .line 6
    .line 7
    filled-new-array {v6, v7}, [Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-static {v1}, Lhx;->i1([Ljava/lang/Object;)Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object v5

    .line 15
    const-string v1, "Mihomo"

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    const-string v3, "mihomo"

    .line 19
    .line 20
    const-string v4, "mihomo"

    .line 21
    .line 22
    invoke-direct/range {v0 .. v5}, Lar5;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/Set;)V

    .line 23
    .line 24
    .line 25
    sput-object v0, Lar5;->l:Lar5;

    .line 26
    .line 27
    new-instance v1, Lar5;

    .line 28
    .line 29
    filled-new-array {v6, v7}, [Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    invoke-static {v2}, Lhx;->i1([Ljava/lang/Object;)Ljava/util/Set;

    .line 34
    .line 35
    .line 36
    move-result-object v13

    .line 37
    const-string v9, "Meow"

    .line 38
    .line 39
    const/4 v10, 0x1

    .line 40
    const-string v11, "meow"

    .line 41
    .line 42
    const-string v12, "meow"

    .line 43
    .line 44
    move-object v8, v1

    .line 45
    invoke-direct/range {v8 .. v13}, Lar5;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/Set;)V

    .line 46
    .line 47
    .line 48
    sput-object v1, Lar5;->m:Lar5;

    .line 49
    .line 50
    new-instance v2, Lar5;

    .line 51
    .line 52
    const-string v3, ".jsonc"

    .line 53
    .line 54
    const-string v4, ".json"

    .line 55
    .line 56
    filled-new-array {v4, v3, v6, v7}, [Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    invoke-static {v3}, Lhx;->i1([Ljava/lang/Object;)Ljava/util/Set;

    .line 61
    .line 62
    .line 63
    move-result-object v13

    .line 64
    const-string v9, "SingBox"

    .line 65
    .line 66
    const/4 v10, 0x2

    .line 67
    const-string v11, "sing-box"

    .line 68
    .line 69
    const-string v12, "sing-box"

    .line 70
    .line 71
    move-object v8, v2

    .line 72
    invoke-direct/range {v8 .. v13}, Lar5;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/Set;)V

    .line 73
    .line 74
    .line 75
    sput-object v2, Lar5;->n:Lar5;

    .line 76
    .line 77
    new-instance v3, Lar5;

    .line 78
    .line 79
    const-string v12, "xray"

    .line 80
    .line 81
    invoke-static {v4}, Lpm6;->h0(Ljava/lang/Object;)Ljava/util/Set;

    .line 82
    .line 83
    .line 84
    move-result-object v13

    .line 85
    const-string v9, "Xray"

    .line 86
    .line 87
    const/4 v10, 0x3

    .line 88
    const-string v11, "xray"

    .line 89
    .line 90
    move-object v8, v3

    .line 91
    invoke-direct/range {v8 .. v13}, Lar5;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/Set;)V

    .line 92
    .line 93
    .line 94
    sput-object v3, Lar5;->o:Lar5;

    .line 95
    .line 96
    new-instance v8, Lar5;

    .line 97
    .line 98
    const-string v12, "v2fly"

    .line 99
    .line 100
    invoke-static {v4}, Lpm6;->h0(Ljava/lang/Object;)Ljava/util/Set;

    .line 101
    .line 102
    .line 103
    move-result-object v13

    .line 104
    const-string v9, "V2fly"

    .line 105
    .line 106
    const/4 v10, 0x4

    .line 107
    const-string v11, "v2fly"

    .line 108
    .line 109
    invoke-direct/range {v8 .. v13}, Lar5;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/Set;)V

    .line 110
    .line 111
    .line 112
    move-object v4, v8

    .line 113
    sput-object v4, Lar5;->p:Lar5;

    .line 114
    .line 115
    new-instance v5, Lar5;

    .line 116
    .line 117
    filled-new-array {v6, v7}, [Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v6

    .line 121
    invoke-static {v6}, Lhx;->i1([Ljava/lang/Object;)Ljava/util/Set;

    .line 122
    .line 123
    .line 124
    move-result-object v13

    .line 125
    const-string v9, "Hysteria"

    .line 126
    .line 127
    const/4 v10, 0x5

    .line 128
    const-string v11, "hysteria"

    .line 129
    .line 130
    const-string v12, "hysteria"

    .line 131
    .line 132
    move-object v8, v5

    .line 133
    invoke-direct/range {v8 .. v13}, Lar5;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/Set;)V

    .line 134
    .line 135
    .line 136
    sput-object v5, Lar5;->q:Lar5;

    .line 137
    .line 138
    filled-new-array/range {v0 .. v5}, [Lar5;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    sput-object v0, Lar5;->r:[Lar5;

    .line 143
    .line 144
    new-instance v1, Lc42;

    .line 145
    .line 146
    invoke-direct {v1, v0}, Lc42;-><init>([Ljava/lang/Enum;)V

    .line 147
    .line 148
    .line 149
    sput-object v1, Lar5;->s:Lc42;

    .line 150
    .line 151
    new-instance v0, Llb5;

    .line 152
    .line 153
    const/16 v1, 0x11

    .line 154
    .line 155
    invoke-direct {v0, v1}, Llb5;-><init>(B)V

    .line 156
    .line 157
    .line 158
    sput-object v0, Lar5;->k:Llb5;

    .line 159
    .line 160
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/Set;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lar5;->h:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lar5;->i:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p5, p0, Lar5;->j:Ljava/util/Set;

    .line 9
    .line 10
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lar5;
    .locals 1

    .line 1
    const-class v0, Lar5;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lar5;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lar5;
    .locals 1

    .line 1
    sget-object v0, Lar5;->r:[Lar5;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lar5;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final a()Z
    .locals 1

    .line 1
    sget-object v0, Lar5;->l:Lar5;

    .line 2
    .line 3
    if-eq p0, v0, :cond_0

    .line 4
    .line 5
    sget-object v0, Lar5;->m:Lar5;

    .line 6
    .line 7
    if-eq p0, v0, :cond_0

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_0
    const/4 p0, 0x1

    .line 12
    return p0
.end method
