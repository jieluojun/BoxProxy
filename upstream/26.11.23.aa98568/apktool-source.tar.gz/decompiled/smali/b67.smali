.class public final Lb67;
.super Ldx7;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public A:Luj0;

.field public B:Luj0;

.field public C:Luj0;

.field public z:Luj0;


# virtual methods
.method public final c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z
    .locals 3

    .line 1
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x3b

    .line 6
    .line 7
    if-eq v0, v1, :cond_3

    .line 8
    .line 9
    const/16 v1, 0xbe

    .line 10
    .line 11
    if-eq v0, v1, :cond_4

    .line 12
    .line 13
    const/16 v1, 0xc0

    .line 14
    .line 15
    if-eq v0, v1, :cond_2

    .line 16
    .line 17
    const/16 v1, 0xc3

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    if-eq v0, v1, :cond_1

    .line 21
    .line 22
    const/16 v1, 0xc4

    .line 23
    .line 24
    if-eq v0, v1, :cond_0

    .line 25
    .line 26
    invoke-super {p0, p1, p2, p3, p4}, Ldx7;->c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    return p0

    .line 31
    :cond_0
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 32
    .line 33
    .line 34
    move-result p1

    .line 35
    invoke-static {v2, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    iput-object p1, p0, Lb67;->A:Luj0;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_1
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    invoke-static {v2, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    iput-object p1, p0, Lb67;->z:Luj0;

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_2
    const-string p1, "Invalid <svg> element. width cannot be negative"

    .line 54
    .line 55
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    iput-object p1, p0, Lb67;->B:Luj0;

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_3
    const-string p1, "Invalid <svg> element. height cannot be negative"

    .line 63
    .line 64
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    iput-object p1, p0, Lb67;->C:Luj0;

    .line 69
    .line 70
    :cond_4
    :goto_0
    const/4 p0, 0x1

    .line 71
    return p0
.end method
