.class public final La72;
.super Loa2;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final d:Landroid/graphics/Paint;

.field public final e:Lm5;

.field public final f:Lm5;

.field public final g:Lm5;


# direct methods
.method public constructor <init>(Ly62;Landroid/graphics/Paint;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, Loa2;-><init>(Lna2;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, La72;->d:Landroid/graphics/Paint;

    .line 5
    .line 6
    new-instance p1, Lm5;

    .line 7
    .line 8
    const/16 p2, 0x10

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p1, p2, v0}, Lm5;-><init>(BZ)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, La72;->e:Lm5;

    .line 15
    .line 16
    new-instance p1, Lm5;

    .line 17
    .line 18
    invoke-direct {p1, p2, v0}, Lm5;-><init>(BZ)V

    .line 19
    .line 20
    .line 21
    iput-object p1, p0, La72;->f:Lm5;

    .line 22
    .line 23
    new-instance p1, Lm5;

    .line 24
    .line 25
    invoke-direct {p1, p2, v0}, Lm5;-><init>(BZ)V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, La72;->g:Lm5;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final a()I
    .locals 0

    .line 1
    const/16 p0, 0x80

    .line 2
    .line 3
    return p0
.end method
