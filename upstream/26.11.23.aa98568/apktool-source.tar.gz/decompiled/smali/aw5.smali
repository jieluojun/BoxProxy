.class public final Law5;
.super Lzn6;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public A:Luj0;

.field public B:Luj0;

.field public C:Luj0;

.field public D:F

.field public x:Luj0;

.field public y:Luj0;

.field public z:Luj0;


# virtual methods
.method public final c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z
    .locals 3

    .line 1
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x3b

    .line 6
    .line 7
    if-eq v0, v1, :cond_6

    .line 8
    .line 9
    const/16 v1, 0x5f

    .line 10
    .line 11
    if-eq v0, v1, :cond_5

    .line 12
    .line 13
    const/16 v1, 0xc0

    .line 14
    .line 15
    if-eq v0, v1, :cond_4

    .line 16
    .line 17
    const/16 v1, 0x8f

    .line 18
    .line 19
    if-eq v0, v1, :cond_3

    .line 20
    .line 21
    const/16 v1, 0x90

    .line 22
    .line 23
    if-eq v0, v1, :cond_2

    .line 24
    .line 25
    const/16 v1, 0xc3

    .line 26
    .line 27
    const/4 v2, 0x0

    .line 28
    if-eq v0, v1, :cond_1

    .line 29
    .line 30
    const/16 v1, 0xc4

    .line 31
    .line 32
    if-eq v0, v1, :cond_0

    .line 33
    .line 34
    invoke-super {p0, p1, p2, p3, p4}, Lzn6;->c(Lorg/xml/sax/Attributes;ILxc6;Ljava/lang/String;)Z

    .line 35
    .line 36
    .line 37
    move-result p0

    .line 38
    return p0

    .line 39
    :cond_0
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    invoke-static {v2, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    iput-object p1, p0, Law5;->y:Luj0;

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_1
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    invoke-static {v2, p4, p1}, Lgu;->V(ILjava/lang/String;I)Luj0;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    iput-object p1, p0, Law5;->x:Luj0;

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_2
    const-string p1, "Invalid <rect> element. ry cannot be negative"

    .line 62
    .line 63
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    iput-object p1, p0, Law5;->C:Luj0;

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_3
    const-string p1, "Invalid <rect> element. rx cannot be negative"

    .line 71
    .line 72
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    iput-object p1, p0, Law5;->B:Luj0;

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_4
    const-string p1, "Invalid <rect> element. width cannot be negative"

    .line 80
    .line 81
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    iput-object p1, p0, Law5;->z:Luj0;

    .line 86
    .line 87
    goto :goto_0

    .line 88
    :cond_5
    const-string p1, "Invalid <rect> element. pathLength cannot be negative"

    .line 89
    .line 90
    invoke-static {p4, p1}, Lix;->q0(Ljava/lang/String;Ljava/lang/String;)F

    .line 91
    .line 92
    .line 93
    move-result p1

    .line 94
    iput p1, p0, Law5;->D:F

    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_6
    const-string p1, "Invalid <rect> element. height cannot be negative"

    .line 98
    .line 99
    invoke-static {p4, p1}, Lgu;->Z(Ljava/lang/String;Ljava/lang/String;)Luj0;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    iput-object p1, p0, Law5;->A:Luj0;

    .line 104
    .line 105
    :goto_0
    const/4 p0, 0x1

    .line 106
    return p0
.end method
