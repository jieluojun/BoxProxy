.class public final Lb70;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic l:B

.field public m:B

.field public n:Z

.field public o:Ljava/lang/Object;

.field public p:Ljava/lang/Object;

.field public q:Ljava/lang/Object;

.field public synthetic r:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILxd1;)V
    .locals 1

    .line 20
    const/4 v0, 0x2

    iput-byte v0, p0, Lb70;->l:B

    invoke-direct {p0, p1, p2}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZLxd1;)V
    .locals 1

    const/4 v0, 0x3

    iput-byte v0, p0, Lb70;->l:B

    .line 19
    iput-object p1, p0, Lb70;->q:Ljava/lang/Object;

    iput-object p2, p0, Lb70;->r:Ljava/lang/Object;

    iput-boolean p3, p0, Lb70;->n:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public constructor <init>(ZLte4;Lrg;Lrg;Lte4;Lxd1;)V
    .locals 1

    const/4 v0, 0x0

    iput-byte v0, p0, Lb70;->l:B

    .line 21
    iput-boolean p1, p0, Lb70;->n:Z

    iput-object p2, p0, Lb70;->o:Ljava/lang/Object;

    iput-object p3, p0, Lb70;->q:Ljava/lang/Object;

    iput-object p4, p0, Lb70;->r:Ljava/lang/Object;

    iput-object p5, p0, Lb70;->p:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public constructor <init>(ZLyy1;Lqe2;Lsf0;Lte4;Lxd1;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lb70;->l:B

    .line 3
    .line 4
    iput-boolean p1, p0, Lb70;->n:Z

    .line 5
    .line 6
    iput-object p2, p0, Lb70;->p:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Lb70;->q:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p4, p0, Lb70;->r:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p5, p0, Lb70;->o:Ljava/lang/Object;

    .line 13
    .line 14
    const/4 p1, 0x2

    .line 15
    invoke-direct {p0, p1, p6}, Lt57;-><init>(ILxd1;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lb70;->l:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    check-cast p1, Ljj1;

    .line 6
    .line 7
    check-cast p2, Lxd1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lb70;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lb70;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lb70;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    invoke-virtual {p0, p2, p1}, Lb70;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lb70;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lb70;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :pswitch_1
    invoke-virtual {p0, p2, p1}, Lb70;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Lb70;

    .line 39
    .line 40
    invoke-virtual {p0, v1}, Lb70;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    return-object p0

    .line 45
    :pswitch_2
    invoke-virtual {p0, p2, p1}, Lb70;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    check-cast p0, Lb70;

    .line 50
    .line 51
    invoke-virtual {p0, v1}, Lb70;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    nop

    .line 57
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final s(Lxd1;Ljava/lang/Object;)Lxd1;
    .locals 9

    .line 1
    iget-byte v0, p0, Lb70;->l:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance p2, Lb70;

    .line 7
    .line 8
    iget-object v0, p0, Lb70;->q:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Ljava/lang/String;

    .line 11
    .line 12
    iget-object v1, p0, Lb70;->r:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Ljava/lang/String;

    .line 15
    .line 16
    iget-boolean p0, p0, Lb70;->n:Z

    .line 17
    .line 18
    invoke-direct {p2, v0, v1, p0, p1}, Lb70;-><init>(Ljava/lang/String;Ljava/lang/String;ZLxd1;)V

    .line 19
    .line 20
    .line 21
    return-object p2

    .line 22
    :pswitch_0
    new-instance p0, Lb70;

    .line 23
    .line 24
    const/4 v0, 0x2

    .line 25
    invoke-direct {p0, v0, p1}, Lb70;-><init>(ILxd1;)V

    .line 26
    .line 27
    .line 28
    iput-object p2, p0, Lb70;->r:Ljava/lang/Object;

    .line 29
    .line 30
    return-object p0

    .line 31
    :pswitch_1
    new-instance v1, Lb70;

    .line 32
    .line 33
    iget-boolean v2, p0, Lb70;->n:Z

    .line 34
    .line 35
    iget-object p2, p0, Lb70;->p:Ljava/lang/Object;

    .line 36
    .line 37
    move-object v3, p2

    .line 38
    check-cast v3, Lyy1;

    .line 39
    .line 40
    iget-object p2, p0, Lb70;->q:Ljava/lang/Object;

    .line 41
    .line 42
    move-object v4, p2

    .line 43
    check-cast v4, Lqe2;

    .line 44
    .line 45
    iget-object p2, p0, Lb70;->r:Ljava/lang/Object;

    .line 46
    .line 47
    move-object v5, p2

    .line 48
    check-cast v5, Lsf0;

    .line 49
    .line 50
    iget-object p0, p0, Lb70;->o:Ljava/lang/Object;

    .line 51
    .line 52
    move-object v6, p0

    .line 53
    check-cast v6, Lte4;

    .line 54
    .line 55
    move-object v7, p1

    .line 56
    invoke-direct/range {v1 .. v7}, Lb70;-><init>(ZLyy1;Lqe2;Lsf0;Lte4;Lxd1;)V

    .line 57
    .line 58
    .line 59
    return-object v1

    .line 60
    :pswitch_2
    move-object v7, p1

    .line 61
    new-instance v2, Lb70;

    .line 62
    .line 63
    iget-boolean v3, p0, Lb70;->n:Z

    .line 64
    .line 65
    iget-object p1, p0, Lb70;->o:Ljava/lang/Object;

    .line 66
    .line 67
    move-object v4, p1

    .line 68
    check-cast v4, Lte4;

    .line 69
    .line 70
    iget-object p1, p0, Lb70;->q:Ljava/lang/Object;

    .line 71
    .line 72
    move-object v5, p1

    .line 73
    check-cast v5, Lrg;

    .line 74
    .line 75
    iget-object p1, p0, Lb70;->r:Ljava/lang/Object;

    .line 76
    .line 77
    move-object v6, p1

    .line 78
    check-cast v6, Lrg;

    .line 79
    .line 80
    iget-object p0, p0, Lb70;->p:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast p0, Lte4;

    .line 83
    .line 84
    move-object v8, v7

    .line 85
    move-object v7, p0

    .line 86
    invoke-direct/range {v2 .. v8}, Lb70;-><init>(ZLte4;Lrg;Lrg;Lte4;Lxd1;)V

    .line 87
    .line 88
    .line 89
    return-object v2

    .line 90
    nop

    .line 91
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v5, p0

    .line 2
    .line 3
    iget-byte v0, v5, Lb70;->l:B

    .line 4
    .line 5
    sget-object v7, Lst7;->a:Lst7;

    .line 6
    .line 7
    const-wide/32 v1, 0xea60

    .line 8
    .line 9
    .line 10
    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    .line 11
    .line 12
    sget-object v8, Lkj1;->h:Lkj1;

    .line 13
    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v6, 0x0

    .line 16
    const/4 v9, 0x1

    .line 17
    const/4 v10, 0x0

    .line 18
    packed-switch v0, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    iget-object v0, v5, Lb70;->r:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Ljava/lang/String;

    .line 24
    .line 25
    iget-byte v7, v5, Lb70;->m:B

    .line 26
    .line 27
    if-eqz v7, :cond_2

    .line 28
    .line 29
    if-eq v7, v9, :cond_1

    .line 30
    .line 31
    if-ne v7, v4, :cond_0

    .line 32
    .line 33
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    move-object/from16 v0, p1

    .line 37
    .line 38
    goto/16 :goto_4

    .line 39
    .line 40
    :cond_0
    invoke-static {v3}, Ll42;->d(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    move-object v8, v10

    .line 44
    goto/16 :goto_5

    .line 45
    .line 46
    :cond_1
    iget-object v0, v5, Lb70;->p:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v0, Ljava/io/File;

    .line 49
    .line 50
    iget-object v3, v5, Lb70;->o:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v3, Ljava/io/File;

    .line 53
    .line 54
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    move-object/from16 v7, p1

    .line 58
    .line 59
    goto/16 :goto_2

    .line 60
    .line 61
    :cond_2
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    sget-object v3, Llc6;->a:Llc6;

    .line 65
    .line 66
    iget-object v3, v5, Lb70;->q:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v3, Ljava/lang/String;

    .line 69
    .line 70
    invoke-static {v3}, Lf17;->Z0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    new-array v7, v9, [C

    .line 79
    .line 80
    const/16 v11, 0x2f

    .line 81
    .line 82
    aput-char v11, v7, v6

    .line 83
    .line 84
    invoke-static {v3, v7}, Lf17;->a1(Ljava/lang/String;[C)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    invoke-static {v3}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 89
    .line 90
    .line 91
    move-result v7

    .line 92
    if-nez v7, :cond_4

    .line 93
    .line 94
    new-array v7, v9, [C

    .line 95
    .line 96
    aput-char v11, v7, v6

    .line 97
    .line 98
    invoke-static {v3, v7}, Lf17;->P0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 99
    .line 100
    .line 101
    move-result-object v12

    .line 102
    invoke-interface {v12}, Ljava/util/Collection;->isEmpty()Z

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    if-nez v3, :cond_5

    .line 107
    .line 108
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 109
    .line 110
    .line 111
    move-result-object v3

    .line 112
    :cond_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 113
    .line 114
    .line 115
    move-result v7

    .line 116
    if-eqz v7, :cond_5

    .line 117
    .line 118
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v7

    .line 122
    check-cast v7, Ljava/lang/String;

    .line 123
    .line 124
    invoke-static {v7}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 125
    .line 126
    .line 127
    move-result v13

    .line 128
    if-nez v13, :cond_4

    .line 129
    .line 130
    const-string v13, "."

    .line 131
    .line 132
    invoke-virtual {v7, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v13

    .line 136
    if-nez v13, :cond_4

    .line 137
    .line 138
    const-string v13, ".."

    .line 139
    .line 140
    invoke-virtual {v7, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v13

    .line 144
    if-nez v13, :cond_4

    .line 145
    .line 146
    invoke-static {v7, v6}, Lf17;->p0(Ljava/lang/CharSequence;C)Z

    .line 147
    .line 148
    .line 149
    move-result v7

    .line 150
    if-eqz v7, :cond_3

    .line 151
    .line 152
    :cond_4
    move-object v3, v10

    .line 153
    goto :goto_0

    .line 154
    :cond_5
    const/16 v16, 0x0

    .line 155
    .line 156
    const/16 v17, 0x3e

    .line 157
    .line 158
    const-string v13, "/"

    .line 159
    .line 160
    const/4 v14, 0x0

    .line 161
    const/4 v15, 0x0

    .line 162
    invoke-static/range {v12 .. v17}, Lay0;->Z0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Lwh2;I)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v3

    .line 166
    :goto_0
    if-nez v3, :cond_6

    .line 167
    .line 168
    new-instance v12, Luv;

    .line 169
    .line 170
    const v0, 0x7f0f00c8

    .line 171
    .line 172
    .line 173
    new-array v1, v6, [Ljava/lang/Object;

    .line 174
    .line 175
    invoke-static {v0, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v14

    .line 179
    const/16 v16, 0x0

    .line 180
    .line 181
    const/16 v17, 0xd

    .line 182
    .line 183
    const/4 v13, 0x0

    .line 184
    const/4 v15, 0x0

    .line 185
    invoke-direct/range {v12 .. v17}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 186
    .line 187
    .line 188
    move-object v8, v12

    .line 189
    goto/16 :goto_5

    .line 190
    .line 191
    :cond_6
    invoke-static {v0}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 192
    .line 193
    .line 194
    move-result v7

    .line 195
    if-nez v7, :cond_7

    .line 196
    .line 197
    new-array v7, v9, [C

    .line 198
    .line 199
    aput-char v11, v7, v6

    .line 200
    .line 201
    invoke-static {v0, v7}, Lf17;->c1(Ljava/lang/String;[C)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    const-string v7, "/"

    .line 206
    .line 207
    invoke-static {v0, v7, v3}, Ln32;->z(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v3

    .line 211
    :cond_7
    sget-object v0, Llc6;->a:Llc6;

    .line 212
    .line 213
    invoke-static {v3}, Llc6;->o(Ljava/lang/String;)Luv;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    iget-object v3, v0, Luv;->a:Ljava/lang/Object;

    .line 218
    .line 219
    check-cast v3, Ljava/io/File;

    .line 220
    .line 221
    const v7, 0x7f0f00c9

    .line 222
    .line 223
    .line 224
    if-nez v3, :cond_9

    .line 225
    .line 226
    new-instance v11, Luv;

    .line 227
    .line 228
    iget-object v0, v0, Luv;->b:Ljava/lang/String;

    .line 229
    .line 230
    if-nez v0, :cond_8

    .line 231
    .line 232
    new-array v0, v6, [Ljava/lang/Object;

    .line 233
    .line 234
    invoke-static {v7, v0}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    :cond_8
    move-object v13, v0

    .line 239
    const/4 v15, 0x0

    .line 240
    const/16 v16, 0xd

    .line 241
    .line 242
    const/4 v12, 0x0

    .line 243
    const/4 v14, 0x0

    .line 244
    invoke-direct/range {v11 .. v16}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 245
    .line 246
    .line 247
    :goto_1
    move-object v8, v11

    .line 248
    goto/16 :goto_5

    .line 249
    .line 250
    :cond_9
    invoke-virtual {v3}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    if-nez v0, :cond_a

    .line 255
    .line 256
    new-instance v11, Luv;

    .line 257
    .line 258
    new-array v0, v6, [Ljava/lang/Object;

    .line 259
    .line 260
    invoke-static {v7, v0}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v13

    .line 264
    const/4 v15, 0x0

    .line 265
    const/16 v16, 0xd

    .line 266
    .line 267
    const/4 v12, 0x0

    .line 268
    const/4 v14, 0x0

    .line 269
    invoke-direct/range {v11 .. v16}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 270
    .line 271
    .line 272
    goto :goto_1

    .line 273
    :cond_a
    sget-object v7, Lv16;->a:Lv16;

    .line 274
    .line 275
    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v7

    .line 279
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 280
    .line 281
    .line 282
    invoke-static {v7}, Llc6;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 283
    .line 284
    .line 285
    move-result-object v7

    .line 286
    const-string v11, "ls -d "

    .line 287
    .line 288
    const-string v12, " 2>/dev/null"

    .line 289
    .line 290
    invoke-static {v11, v7, v12}, Ln32;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v7

    .line 294
    iput-object v3, v5, Lb70;->o:Ljava/lang/Object;

    .line 295
    .line 296
    iput-object v0, v5, Lb70;->p:Ljava/lang/Object;

    .line 297
    .line 298
    iput-byte v9, v5, Lb70;->m:B

    .line 299
    .line 300
    invoke-static {v1, v2, v5, v7}, Lv16;->f(JLxd1;Ljava/lang/String;)Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v7

    .line 304
    if-eq v7, v8, :cond_10

    .line 305
    .line 306
    :goto_2
    check-cast v7, Lm16;

    .line 307
    .line 308
    invoke-virtual {v7}, Lm16;->a()Z

    .line 309
    .line 310
    .line 311
    move-result v7

    .line 312
    if-eqz v7, :cond_b

    .line 313
    .line 314
    new-instance v11, Luv;

    .line 315
    .line 316
    const v0, 0x7f0f00b8

    .line 317
    .line 318
    .line 319
    new-array v1, v6, [Ljava/lang/Object;

    .line 320
    .line 321
    invoke-static {v0, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object v13

    .line 325
    const/4 v15, 0x0

    .line 326
    const/16 v16, 0xd

    .line 327
    .line 328
    const/4 v12, 0x0

    .line 329
    const/4 v14, 0x0

    .line 330
    invoke-direct/range {v11 .. v16}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 331
    .line 332
    .line 333
    goto :goto_1

    .line 334
    :cond_b
    iget-boolean v7, v5, Lb70;->n:Z

    .line 335
    .line 336
    const-string v9, "mkdir -p "

    .line 337
    .line 338
    if-eqz v7, :cond_c

    .line 339
    .line 340
    sget-object v0, Llc6;->a:Llc6;

    .line 341
    .line 342
    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 343
    .line 344
    .line 345
    move-result-object v0

    .line 346
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 347
    .line 348
    .line 349
    invoke-static {v0}, Llc6;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object v0

    .line 353
    invoke-virtual {v9, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 354
    .line 355
    .line 356
    move-result-object v0

    .line 357
    goto :goto_3

    .line 358
    :cond_c
    sget-object v7, Llc6;->a:Llc6;

    .line 359
    .line 360
    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v0

    .line 364
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 365
    .line 366
    .line 367
    invoke-static {v0}, Llc6;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object v0

    .line 371
    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v3

    .line 375
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 376
    .line 377
    .line 378
    invoke-static {v3}, Llc6;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v3

    .line 382
    const-string v7, " && touch "

    .line 383
    .line 384
    invoke-static {v9, v0, v7, v3}, Ldw4;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object v0

    .line 388
    :goto_3
    sget-object v3, Lv16;->a:Lv16;

    .line 389
    .line 390
    iput-object v10, v5, Lb70;->o:Ljava/lang/Object;

    .line 391
    .line 392
    iput-object v10, v5, Lb70;->p:Ljava/lang/Object;

    .line 393
    .line 394
    iput-byte v4, v5, Lb70;->m:B

    .line 395
    .line 396
    invoke-static {v1, v2, v5, v0}, Lv16;->f(JLxd1;Ljava/lang/String;)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v0

    .line 400
    if-eq v0, v8, :cond_10

    .line 401
    .line 402
    :goto_4
    check-cast v0, Lm16;

    .line 403
    .line 404
    invoke-virtual {v0}, Lm16;->a()Z

    .line 405
    .line 406
    .line 407
    move-result v1

    .line 408
    if-eqz v1, :cond_d

    .line 409
    .line 410
    new-instance v7, Luv;

    .line 411
    .line 412
    const/4 v11, 0x0

    .line 413
    const/16 v12, 0xe

    .line 414
    .line 415
    sget-object v8, Lst7;->a:Lst7;

    .line 416
    .line 417
    const/4 v9, 0x0

    .line 418
    const/4 v10, 0x0

    .line 419
    invoke-direct/range {v7 .. v12}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 420
    .line 421
    .line 422
    move-object v8, v7

    .line 423
    goto :goto_5

    .line 424
    :cond_d
    iget-object v1, v0, Lm16;->b:Ljava/lang/String;

    .line 425
    .line 426
    invoke-static {v1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 427
    .line 428
    .line 429
    move-result v2

    .line 430
    if-eqz v2, :cond_e

    .line 431
    .line 432
    iget-object v1, v0, Lm16;->a:Ljava/lang/String;

    .line 433
    .line 434
    :cond_e
    invoke-static {v1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 435
    .line 436
    .line 437
    move-result v0

    .line 438
    if-eqz v0, :cond_f

    .line 439
    .line 440
    const v0, 0x7f0f00bd

    .line 441
    .line 442
    .line 443
    new-array v1, v6, [Ljava/lang/Object;

    .line 444
    .line 445
    invoke-static {v0, v1}, Lcw;->j(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 446
    .line 447
    .line 448
    move-result-object v1

    .line 449
    :cond_f
    move-object v4, v1

    .line 450
    new-instance v2, Luv;

    .line 451
    .line 452
    const/4 v3, 0x0

    .line 453
    const/4 v5, 0x0

    .line 454
    const/4 v6, 0x0

    .line 455
    const/16 v7, 0xd

    .line 456
    .line 457
    invoke-direct/range {v2 .. v7}, Luv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lsz4;Ljava/lang/Throwable;I)V

    .line 458
    .line 459
    .line 460
    move-object v8, v2

    .line 461
    :cond_10
    :goto_5
    return-object v8

    .line 462
    :pswitch_0
    iget-object v0, v5, Lb70;->r:Ljava/lang/Object;

    .line 463
    .line 464
    check-cast v0, Ljj1;

    .line 465
    .line 466
    iget-byte v7, v5, Lb70;->m:B

    .line 467
    .line 468
    if-eqz v7, :cond_13

    .line 469
    .line 470
    if-eq v7, v9, :cond_12

    .line 471
    .line 472
    if-ne v7, v4, :cond_11

    .line 473
    .line 474
    iget-boolean v0, v5, Lb70;->n:Z

    .line 475
    .line 476
    iget-object v1, v5, Lb70;->q:Ljava/lang/Object;

    .line 477
    .line 478
    check-cast v1, Lif4;

    .line 479
    .line 480
    iget-object v2, v5, Lb70;->o:Ljava/lang/Object;

    .line 481
    .line 482
    check-cast v2, Ljq6;

    .line 483
    .line 484
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 485
    .line 486
    .line 487
    goto/16 :goto_8

    .line 488
    .line 489
    :cond_11
    invoke-static {v3}, Ll42;->d(Ljava/lang/String;)V

    .line 490
    .line 491
    .line 492
    move-object v8, v10

    .line 493
    goto/16 :goto_b

    .line 494
    .line 495
    :cond_12
    iget-object v0, v5, Lb70;->p:Ljava/lang/Object;

    .line 496
    .line 497
    check-cast v0, Ljava/util/ArrayList;

    .line 498
    .line 499
    iget-object v1, v5, Lb70;->o:Ljava/lang/Object;

    .line 500
    .line 501
    check-cast v1, Ljq6;

    .line 502
    .line 503
    :try_start_0
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 504
    .line 505
    .line 506
    move-object v11, v0

    .line 507
    move-object/from16 v0, p1

    .line 508
    .line 509
    goto :goto_6

    .line 510
    :cond_13
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 511
    .line 512
    .line 513
    sget-object v3, Lv16;->a:Lv16;

    .line 514
    .line 515
    const-wide/16 v11, 0x3c

    .line 516
    .line 517
    invoke-static {v11, v12}, Lv16;->e(J)Ljq6;

    .line 518
    .line 519
    .line 520
    move-result-object v7

    .line 521
    if-nez v7, :cond_14

    .line 522
    .line 523
    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 524
    .line 525
    goto/16 :goto_b

    .line 526
    .line 527
    :cond_14
    invoke-virtual {v7}, Ljq6;->c()Z

    .line 528
    .line 529
    .line 530
    move-result v11

    .line 531
    if-eqz v11, :cond_17

    .line 532
    .line 533
    invoke-virtual {v7}, Ljq6;->e()Z

    .line 534
    .line 535
    .line 536
    move-result v11

    .line 537
    if-eqz v11, :cond_17

    .line 538
    .line 539
    new-instance v11, Ljava/util/ArrayList;

    .line 540
    .line 541
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 542
    .line 543
    .line 544
    new-instance v12, Ljava/util/ArrayList;

    .line 545
    .line 546
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 547
    .line 548
    .line 549
    new-instance v13, Lkq6;

    .line 550
    .line 551
    invoke-direct {v13, v7}, Lkq6;-><init>(Ljq6;)V

    .line 552
    .line 553
    .line 554
    const-string v14, "id -u"

    .line 555
    .line 556
    filled-new-array {v14}, [Ljava/lang/String;

    .line 557
    .line 558
    .line 559
    move-result-object v14

    .line 560
    invoke-virtual {v13, v14}, Lkq6;->a([Ljava/lang/String;)Lkq6;

    .line 561
    .line 562
    .line 563
    iput-object v11, v13, Lkq6;->b:Ljava/util/ArrayList;

    .line 564
    .line 565
    iput-object v12, v13, Lkq6;->c:Ljava/util/ArrayList;

    .line 566
    .line 567
    invoke-virtual {v13}, Lkq6;->b()Lvz5;

    .line 568
    .line 569
    .line 570
    move-result-object v12

    .line 571
    :try_start_1
    iput-object v0, v5, Lb70;->r:Ljava/lang/Object;

    .line 572
    .line 573
    iput-object v7, v5, Lb70;->o:Ljava/lang/Object;

    .line 574
    .line 575
    iput-object v11, v5, Lb70;->p:Ljava/lang/Object;

    .line 576
    .line 577
    iput-byte v9, v5, Lb70;->m:B

    .line 578
    .line 579
    invoke-virtual {v3, v12, v1, v2, v5}, Lv16;->b(Lvz5;JLyd1;)Ljava/lang/Object;

    .line 580
    .line 581
    .line 582
    move-result-object v0
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 583
    if-eq v0, v8, :cond_18

    .line 584
    .line 585
    move-object v1, v7

    .line 586
    :goto_6
    :try_start_2
    check-cast v0, Lwz5;

    .line 587
    .line 588
    iget v0, v0, Lwz5;->a:I

    .line 589
    .line 590
    if-nez v0, :cond_15

    .line 591
    .line 592
    const-string v12, "\n"

    .line 593
    .line 594
    const/4 v15, 0x0

    .line 595
    const/16 v16, 0x3e

    .line 596
    .line 597
    const/4 v13, 0x0

    .line 598
    const/4 v14, 0x0

    .line 599
    invoke-static/range {v11 .. v16}, Lay0;->Z0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/String;Lwh2;I)Ljava/lang/String;

    .line 600
    .line 601
    .line 602
    move-result-object v0

    .line 603
    invoke-static {v0}, Lf17;->Z0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 604
    .line 605
    .line 606
    move-result-object v0

    .line 607
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 608
    .line 609
    .line 610
    move-result-object v0

    .line 611
    const-string v2, "0"

    .line 612
    .line 613
    invoke-static {v0, v2}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 614
    .line 615
    .line 616
    move-result v0
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 617
    if-eqz v0, :cond_15

    .line 618
    .line 619
    move v6, v9

    .line 620
    goto :goto_7

    .line 621
    :catch_0
    move-exception v0

    .line 622
    goto :goto_a

    .line 623
    :catch_1
    move-object v1, v7

    .line 624
    :catch_2
    :cond_15
    :goto_7
    move-object v2, v1

    .line 625
    if-eqz v6, :cond_16

    .line 626
    .line 627
    sget-object v1, Lv16;->c:Lif4;

    .line 628
    .line 629
    iput-object v10, v5, Lb70;->r:Ljava/lang/Object;

    .line 630
    .line 631
    iput-object v2, v5, Lb70;->o:Ljava/lang/Object;

    .line 632
    .line 633
    iput-object v10, v5, Lb70;->p:Ljava/lang/Object;

    .line 634
    .line 635
    iput-object v1, v5, Lb70;->q:Ljava/lang/Object;

    .line 636
    .line 637
    iput-boolean v6, v5, Lb70;->n:Z

    .line 638
    .line 639
    iput-byte v4, v5, Lb70;->m:B

    .line 640
    .line 641
    invoke-virtual {v1, v5}, Lif4;->e(Lxd1;)Ljava/lang/Object;

    .line 642
    .line 643
    .line 644
    move-result-object v0

    .line 645
    if-eq v0, v8, :cond_18

    .line 646
    .line 647
    move v0, v6

    .line 648
    :goto_8
    :try_start_3
    sget-object v3, Lv16;->a:Lv16;

    .line 649
    .line 650
    invoke-static {}, Lv16;->c()V

    .line 651
    .line 652
    .line 653
    sget-object v3, Lv16;->b:Ljava/util/ArrayList;

    .line 654
    .line 655
    new-instance v4, Ln16;

    .line 656
    .line 657
    invoke-direct {v4, v2}, Ln16;-><init>(Ljq6;)V

    .line 658
    .line 659
    .line 660
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 661
    .line 662
    .line 663
    invoke-virtual {v1, v10}, Lif4;->g(Ljava/lang/Object;)V

    .line 664
    .line 665
    .line 666
    move v6, v0

    .line 667
    goto :goto_9

    .line 668
    :catchall_0
    move-exception v0

    .line 669
    invoke-virtual {v1, v10}, Lif4;->g(Ljava/lang/Object;)V

    .line 670
    .line 671
    .line 672
    throw v0

    .line 673
    :cond_16
    :try_start_4
    invoke-virtual {v2}, Ljq6;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 674
    .line 675
    .line 676
    :catchall_1
    :goto_9
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 677
    .line 678
    .line 679
    move-result-object v8

    .line 680
    goto :goto_b

    .line 681
    :catch_3
    move-exception v0

    .line 682
    move-object v1, v7

    .line 683
    :goto_a
    :try_start_5
    invoke-virtual {v1}, Ljq6;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 684
    .line 685
    .line 686
    :catchall_2
    throw v0

    .line 687
    :cond_17
    :try_start_6
    invoke-virtual {v7}, Ljq6;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 688
    .line 689
    .line 690
    :catchall_3
    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 691
    .line 692
    :cond_18
    :goto_b
    return-object v8

    .line 693
    :pswitch_1
    iget-object v0, v5, Lb70;->o:Ljava/lang/Object;

    .line 694
    .line 695
    check-cast v0, Lte4;

    .line 696
    .line 697
    iget-byte v1, v5, Lb70;->m:B

    .line 698
    .line 699
    if-eqz v1, :cond_1b

    .line 700
    .line 701
    if-eq v1, v9, :cond_1a

    .line 702
    .line 703
    if-ne v1, v4, :cond_19

    .line 704
    .line 705
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 706
    .line 707
    .line 708
    goto :goto_d

    .line 709
    :cond_19
    invoke-static {v3}, Ll42;->d(Ljava/lang/String;)V

    .line 710
    .line 711
    .line 712
    move-object v7, v10

    .line 713
    goto :goto_e

    .line 714
    :cond_1a
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 715
    .line 716
    .line 717
    goto :goto_c

    .line 718
    :cond_1b
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 719
    .line 720
    .line 721
    iget-boolean v1, v5, Lb70;->n:Z

    .line 722
    .line 723
    if-eqz v1, :cond_1e

    .line 724
    .line 725
    invoke-interface {v0}, Lmz6;->getValue()Ljava/lang/Object;

    .line 726
    .line 727
    .line 728
    move-result-object v1

    .line 729
    check-cast v1, Ljava/lang/Long;

    .line 730
    .line 731
    iget-object v2, v5, Lb70;->p:Ljava/lang/Object;

    .line 732
    .line 733
    check-cast v2, Lyy1;

    .line 734
    .line 735
    iget-wide v2, v2, Lyy1;->a:J

    .line 736
    .line 737
    if-eqz v1, :cond_1e

    .line 738
    .line 739
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 740
    .line 741
    .line 742
    move-result-wide v11

    .line 743
    cmp-long v1, v11, v2

    .line 744
    .line 745
    if-nez v1, :cond_1e

    .line 746
    .line 747
    new-instance v1, Lur0;

    .line 748
    .line 749
    const/16 v2, 0x9

    .line 750
    .line 751
    invoke-direct {v1, v2}, Lur0;-><init>(B)V

    .line 752
    .line 753
    .line 754
    iput-byte v9, v5, Lb70;->m:B

    .line 755
    .line 756
    iget-object v2, v5, Lyd1;->i:Laj1;

    .line 757
    .line 758
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 759
    .line 760
    .line 761
    invoke-static {v2}, Lyj3;->C(Laj1;)Ltf;

    .line 762
    .line 763
    .line 764
    move-result-object v2

    .line 765
    invoke-virtual {v2, v1, v5}, Ltf;->a(Lwh2;Lxd1;)Ljava/lang/Object;

    .line 766
    .line 767
    .line 768
    move-result-object v1

    .line 769
    if-eq v1, v8, :cond_1c

    .line 770
    .line 771
    :goto_c
    iget-object v1, v5, Lb70;->q:Ljava/lang/Object;

    .line 772
    .line 773
    check-cast v1, Lqe2;

    .line 774
    .line 775
    invoke-static {v1}, Lqe2;->a(Lqe2;)V

    .line 776
    .line 777
    .line 778
    iget-object v1, v5, Lb70;->r:Ljava/lang/Object;

    .line 779
    .line 780
    check-cast v1, Lsf0;

    .line 781
    .line 782
    iput-byte v4, v5, Lb70;->m:B

    .line 783
    .line 784
    invoke-virtual {v1, v10, v5}, Lsf0;->a(Lyv5;Lyd1;)Ljava/lang/Object;

    .line 785
    .line 786
    .line 787
    move-result-object v1

    .line 788
    if-ne v1, v8, :cond_1d

    .line 789
    .line 790
    :cond_1c
    move-object v7, v8

    .line 791
    goto :goto_e

    .line 792
    :cond_1d
    :goto_d
    invoke-interface {v0, v10}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 793
    .line 794
    .line 795
    :cond_1e
    :goto_e
    return-object v7

    .line 796
    :pswitch_2
    iget-object v0, v5, Lb70;->q:Ljava/lang/Object;

    .line 797
    .line 798
    check-cast v0, Lrg;

    .line 799
    .line 800
    iget-object v1, v5, Lb70;->o:Ljava/lang/Object;

    .line 801
    .line 802
    move-object v11, v1

    .line 803
    check-cast v11, Lte4;

    .line 804
    .line 805
    iget-byte v1, v5, Lb70;->m:B

    .line 806
    .line 807
    const v2, 0x3ec28f5c    # 0.38f

    .line 808
    .line 809
    .line 810
    const v6, 0x3f666666    # 0.9f

    .line 811
    .line 812
    .line 813
    const/4 v12, 0x3

    .line 814
    const/4 v13, 0x4

    .line 815
    if-eqz v1, :cond_22

    .line 816
    .line 817
    if-eq v1, v9, :cond_21

    .line 818
    .line 819
    if-eq v1, v4, :cond_20

    .line 820
    .line 821
    if-eq v1, v12, :cond_1f

    .line 822
    .line 823
    if-eq v1, v13, :cond_1f

    .line 824
    .line 825
    invoke-static {v3}, Ll42;->d(Ljava/lang/String;)V

    .line 826
    .line 827
    .line 828
    move-object v7, v10

    .line 829
    goto/16 :goto_12

    .line 830
    .line 831
    :cond_1f
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 832
    .line 833
    .line 834
    goto/16 :goto_11

    .line 835
    .line 836
    :cond_20
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 837
    .line 838
    .line 839
    goto/16 :goto_12

    .line 840
    .line 841
    :cond_21
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 842
    .line 843
    .line 844
    goto :goto_f

    .line 845
    :cond_22
    invoke-static/range {p1 .. p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 846
    .line 847
    .line 848
    iget-boolean v1, v5, Lb70;->n:Z

    .line 849
    .line 850
    const/4 v3, 0x0

    .line 851
    if-eqz v1, :cond_23

    .line 852
    .line 853
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 854
    .line 855
    invoke-interface {v11, v1}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 856
    .line 857
    .line 858
    new-instance v1, Ljava/lang/Float;

    .line 859
    .line 860
    invoke-direct {v1, v3}, Ljava/lang/Float;-><init>(F)V

    .line 861
    .line 862
    .line 863
    iput-byte v9, v5, Lb70;->m:B

    .line 864
    .line 865
    invoke-virtual {v0, v5, v1}, Lrg;->h(Lxd1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 866
    .line 867
    .line 868
    move-result-object v0

    .line 869
    if-eq v0, v8, :cond_25

    .line 870
    .line 871
    :goto_f
    iget-object v0, v5, Lb70;->r:Ljava/lang/Object;

    .line 872
    .line 873
    check-cast v0, Lrg;

    .line 874
    .line 875
    new-instance v1, Ljava/lang/Float;

    .line 876
    .line 877
    const/high16 v3, 0x3f800000    # 1.0f

    .line 878
    .line 879
    invoke-direct {v1, v3}, Ljava/lang/Float;-><init>(F)V

    .line 880
    .line 881
    .line 882
    invoke-static {v6, v2, v10}, Lrl3;->y(FFLjava/lang/Float;)Liy6;

    .line 883
    .line 884
    .line 885
    move-result-object v2

    .line 886
    iput-byte v4, v5, Lb70;->m:B

    .line 887
    .line 888
    const/4 v3, 0x0

    .line 889
    const/4 v4, 0x0

    .line 890
    const/16 v6, 0xc

    .line 891
    .line 892
    invoke-static/range {v0 .. v6}, Lrg;->b(Lrg;Ljava/lang/Object;Lvi;Ljava/lang/Float;Lwh2;Lxd1;I)Ljava/lang/Object;

    .line 893
    .line 894
    .line 895
    move-result-object v0

    .line 896
    if-ne v0, v8, :cond_27

    .line 897
    .line 898
    goto :goto_10

    .line 899
    :cond_23
    invoke-interface {v11}, Lmz6;->getValue()Ljava/lang/Object;

    .line 900
    .line 901
    .line 902
    move-result-object v1

    .line 903
    check-cast v1, Ljava/lang/Boolean;

    .line 904
    .line 905
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 906
    .line 907
    .line 908
    move-result v1

    .line 909
    if-eqz v1, :cond_27

    .line 910
    .line 911
    invoke-virtual {v0}, Lrg;->e()Ljava/lang/Object;

    .line 912
    .line 913
    .line 914
    move-result-object v0

    .line 915
    check-cast v0, Ljava/lang/Number;

    .line 916
    .line 917
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 918
    .line 919
    .line 920
    move-result v0

    .line 921
    cmpl-float v0, v0, v3

    .line 922
    .line 923
    iget-object v1, v5, Lb70;->r:Ljava/lang/Object;

    .line 924
    .line 925
    check-cast v1, Lrg;

    .line 926
    .line 927
    if-lez v0, :cond_24

    .line 928
    .line 929
    new-instance v0, Ljava/lang/Float;

    .line 930
    .line 931
    invoke-direct {v0, v3}, Ljava/lang/Float;-><init>(F)V

    .line 932
    .line 933
    .line 934
    iput-byte v12, v5, Lb70;->m:B

    .line 935
    .line 936
    invoke-virtual {v1, v5, v0}, Lrg;->h(Lxd1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 937
    .line 938
    .line 939
    move-result-object v0

    .line 940
    if-ne v0, v8, :cond_26

    .line 941
    .line 942
    goto :goto_10

    .line 943
    :cond_24
    move-object v0, v1

    .line 944
    new-instance v1, Ljava/lang/Float;

    .line 945
    .line 946
    invoke-direct {v1, v3}, Ljava/lang/Float;-><init>(F)V

    .line 947
    .line 948
    .line 949
    invoke-static {v6, v2, v10}, Lrl3;->y(FFLjava/lang/Float;)Liy6;

    .line 950
    .line 951
    .line 952
    move-result-object v2

    .line 953
    iput-byte v13, v5, Lb70;->m:B

    .line 954
    .line 955
    const/4 v3, 0x0

    .line 956
    const/4 v4, 0x0

    .line 957
    const/16 v6, 0xc

    .line 958
    .line 959
    invoke-static/range {v0 .. v6}, Lrg;->b(Lrg;Ljava/lang/Object;Lvi;Ljava/lang/Float;Lwh2;Lxd1;I)Ljava/lang/Object;

    .line 960
    .line 961
    .line 962
    move-result-object v0

    .line 963
    if-ne v0, v8, :cond_26

    .line 964
    .line 965
    :cond_25
    :goto_10
    move-object v7, v8

    .line 966
    goto :goto_12

    .line 967
    :cond_26
    :goto_11
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 968
    .line 969
    invoke-interface {v11, v0}, Lte4;->setValue(Ljava/lang/Object;)V

    .line 970
    .line 971
    .line 972
    iget-object v0, v5, Lb70;->p:Ljava/lang/Object;

    .line 973
    .line 974
    check-cast v0, Lte4;

    .line 975
    .line 976
    sget-object v1, Lu70;->a:Lux1;

    .line 977
    .line 978
    invoke-interface {v0}, Lmz6;->getValue()Ljava/lang/Object;

    .line 979
    .line 980
    .line 981
    move-result-object v0

    .line 982
    check-cast v0, Llh2;

    .line 983
    .line 984
    if-eqz v0, :cond_27

    .line 985
    .line 986
    invoke-interface {v0}, Llh2;->a()Ljava/lang/Object;

    .line 987
    .line 988
    .line 989
    :cond_27
    :goto_12
    return-object v7

    .line 990
    nop

    .line 991
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
