.class public final synthetic Lb47;
.super Lli2;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# static fields
.field public static final o:Lb47;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lb47;

    .line 2
    .line 3
    const-string v4, "SubscriptionMaterialContent$display(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Ljava/lang/String;"

    .line 4
    .line 5
    const/4 v5, 0x0

    .line 6
    const/4 v1, 0x3

    .line 7
    const-class v2, Lnb3;

    .line 8
    .line 9
    const-string v3, "display"

    .line 10
    .line 11
    invoke-direct/range {v0 .. v5}, Lli2;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lb47;->o:Lb47;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/String;

    .line 2
    .line 3
    check-cast p2, Lzi2;

    .line 4
    .line 5
    check-cast p3, Ljava/lang/Number;

    .line 6
    .line 7
    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const p0, -0xe7ee8ed

    .line 17
    .line 18
    .line 19
    invoke-virtual {p2, p0}, Lzi2;->h0(I)V

    .line 20
    .line 21
    .line 22
    const-string p0, "http"

    .line 23
    .line 24
    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    const/4 p3, 0x0

    .line 29
    if-eqz p0, :cond_0

    .line 30
    .line 31
    const p0, -0x6ed23958

    .line 32
    .line 33
    .line 34
    const p1, 0x7f0f04e5

    .line 35
    .line 36
    .line 37
    invoke-static {p2, p0, p1, p2, p3}, Lp92;->n(Lzi2;IILzi2;Z)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    const-string p0, "file"

    .line 43
    .line 44
    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result p0

    .line 48
    if-eqz p0, :cond_1

    .line 49
    .line 50
    const p0, -0x6ed231b8

    .line 51
    .line 52
    .line 53
    const p1, 0x7f0f04e1

    .line 54
    .line 55
    .line 56
    invoke-static {p2, p0, p1, p2, p3}, Lp92;->n(Lzi2;IILzi2;Z)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    goto :goto_0

    .line 61
    :cond_1
    const p0, -0x6ed22a56

    .line 62
    .line 63
    .line 64
    const p1, 0x7f0f04e6

    .line 65
    .line 66
    .line 67
    invoke-static {p2, p0, p1, p2, p3}, Lp92;->n(Lzi2;IILzi2;Z)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    :goto_0
    invoke-virtual {p2, p3}, Lzi2;->r(Z)V

    .line 72
    .line 73
    .line 74
    return-object p0
.end method
