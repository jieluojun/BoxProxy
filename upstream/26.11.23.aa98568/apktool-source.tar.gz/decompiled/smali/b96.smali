.class public final synthetic Lb96;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lte4;

.field public final synthetic j:Lk96;

.field public final synthetic k:Llh2;

.field public final synthetic l:Lqe2;

.field public final synthetic m:Lte4;

.field public final synthetic n:Lte4;

.field public final synthetic o:Lte4;


# direct methods
.method public synthetic constructor <init>(Lte4;Lk96;Llh2;Lqe2;Lte4;Lte4;Lte4;B)V
    .locals 0

    .line 1
    iput-byte p8, p0, Lb96;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lb96;->i:Lte4;

    .line 4
    .line 5
    iput-object p2, p0, Lb96;->j:Lk96;

    .line 6
    .line 7
    iput-object p3, p0, Lb96;->k:Llh2;

    .line 8
    .line 9
    iput-object p4, p0, Lb96;->l:Lqe2;

    .line 10
    .line 11
    iput-object p5, p0, Lb96;->m:Lte4;

    .line 12
    .line 13
    iput-object p6, p0, Lb96;->n:Lte4;

    .line 14
    .line 15
    iput-object p7, p0, Lb96;->o:Lte4;

    .line 16
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb96;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x0

    .line 9
    const/4 v5, 0x1

    .line 10
    packed-switch v1, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    sget-object v6, Lp01;->b:Lp01;

    .line 14
    .line 15
    move-object/from16 v13, p1

    .line 16
    .line 17
    check-cast v13, Lzi2;

    .line 18
    .line 19
    move-object/from16 v1, p2

    .line 20
    .line 21
    check-cast v1, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    and-int/lit8 v7, v1, 0x3

    .line 28
    .line 29
    if-eq v7, v3, :cond_0

    .line 30
    .line 31
    move v7, v5

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    move v7, v4

    .line 34
    :goto_0
    and-int/2addr v1, v5

    .line 35
    invoke-virtual {v13, v1, v7}, Lzi2;->Y(IZ)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_1

    .line 40
    .line 41
    iget-object v1, v0, Lb96;->i:Lte4;

    .line 42
    .line 43
    invoke-interface {v1}, Lmz6;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    check-cast v5, Ljava/lang/Boolean;

    .line 48
    .line 49
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 50
    .line 51
    .line 52
    move-result v7

    .line 53
    sget-object v5, Ldd0;->b:Lek1;

    .line 54
    .line 55
    const/16 v8, 0xfa

    .line 56
    .line 57
    invoke-static {v8, v4, v5, v3}, Lnb3;->H(IILby1;I)Lqp7;

    .line 58
    .line 59
    .line 60
    move-result-object v9

    .line 61
    const/16 v10, 0xe

    .line 62
    .line 63
    invoke-static {v9, v10}, Ls32;->c(Lqp7;I)Ly32;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    invoke-static {v8, v4, v5, v3}, Lnb3;->H(IILby1;I)Lqp7;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    const/4 v8, 0x0

    .line 72
    invoke-static {v5, v8, v3}, Ls32;->d(Lua2;FI)Ly32;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    invoke-virtual {v9, v5}, Ly32;->a(Ly32;)Ly32;

    .line 77
    .line 78
    .line 79
    move-result-object v9

    .line 80
    sget-object v5, Ldd0;->c:Lek1;

    .line 81
    .line 82
    const/16 v11, 0x78

    .line 83
    .line 84
    invoke-static {v11, v4, v5, v3}, Lnb3;->H(IILby1;I)Lqp7;

    .line 85
    .line 86
    .line 87
    move-result-object v12

    .line 88
    invoke-static {v12, v10}, Ls32;->i(Lqp7;I)Lr52;

    .line 89
    .line 90
    .line 91
    move-result-object v10

    .line 92
    invoke-static {v11, v4, v5, v3}, Lnb3;->H(IILby1;I)Lqp7;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    invoke-static {v4, v8, v3}, Ls32;->e(Lua2;FI)Lr52;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    invoke-virtual {v10, v3}, Lr52;->a(Lr52;)Lr52;

    .line 101
    .line 102
    .line 103
    move-result-object v10

    .line 104
    new-instance v14, Lhu;

    .line 105
    .line 106
    iget-object v15, v0, Lb96;->j:Lk96;

    .line 107
    .line 108
    iget-object v3, v0, Lb96;->k:Llh2;

    .line 109
    .line 110
    iget-object v4, v0, Lb96;->l:Lqe2;

    .line 111
    .line 112
    iget-object v5, v0, Lb96;->m:Lte4;

    .line 113
    .line 114
    iget-object v8, v0, Lb96;->n:Lte4;

    .line 115
    .line 116
    iget-object v0, v0, Lb96;->o:Lte4;

    .line 117
    .line 118
    move-object/from16 v21, v0

    .line 119
    .line 120
    move-object/from16 v19, v1

    .line 121
    .line 122
    move-object/from16 v16, v3

    .line 123
    .line 124
    move-object/from16 v17, v4

    .line 125
    .line 126
    move-object/from16 v18, v5

    .line 127
    .line 128
    move-object/from16 v20, v8

    .line 129
    .line 130
    invoke-direct/range {v14 .. v21}, Lhu;-><init>(Lk96;Llh2;Lqe2;Lte4;Lte4;Lte4;Lte4;)V

    .line 131
    .line 132
    .line 133
    const v0, 0x1a5abbc6

    .line 134
    .line 135
    .line 136
    invoke-static {v0, v14, v13}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 137
    .line 138
    .line 139
    move-result-object v12

    .line 140
    const/high16 v14, 0x180000

    .line 141
    .line 142
    const/16 v15, 0x12

    .line 143
    .line 144
    const/4 v8, 0x0

    .line 145
    const/4 v11, 0x0

    .line 146
    invoke-static/range {v6 .. v15}, Lj58;->b(Lp01;ZLbb4;Ly32;Lr52;Ljava/lang/String;Ls21;Lzi2;II)V

    .line 147
    .line 148
    .line 149
    goto :goto_1

    .line 150
    :cond_1
    invoke-virtual {v13}, Lzi2;->b0()V

    .line 151
    .line 152
    .line 153
    :goto_1
    return-object v2

    .line 154
    :pswitch_0
    move-object/from16 v6, p1

    .line 155
    .line 156
    check-cast v6, Lzi2;

    .line 157
    .line 158
    move-object/from16 v1, p2

    .line 159
    .line 160
    check-cast v1, Ljava/lang/Integer;

    .line 161
    .line 162
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    and-int/lit8 v7, v1, 0x3

    .line 167
    .line 168
    if-eq v7, v3, :cond_2

    .line 169
    .line 170
    move v4, v5

    .line 171
    :cond_2
    and-int/2addr v1, v5

    .line 172
    invoke-virtual {v6, v1, v4}, Lzi2;->Y(IZ)Z

    .line 173
    .line 174
    .line 175
    move-result v1

    .line 176
    if-eqz v1, :cond_3

    .line 177
    .line 178
    new-instance v7, Lb96;

    .line 179
    .line 180
    const/4 v15, 0x1

    .line 181
    iget-object v8, v0, Lb96;->i:Lte4;

    .line 182
    .line 183
    iget-object v9, v0, Lb96;->j:Lk96;

    .line 184
    .line 185
    iget-object v10, v0, Lb96;->k:Llh2;

    .line 186
    .line 187
    iget-object v11, v0, Lb96;->l:Lqe2;

    .line 188
    .line 189
    iget-object v12, v0, Lb96;->m:Lte4;

    .line 190
    .line 191
    iget-object v13, v0, Lb96;->n:Lte4;

    .line 192
    .line 193
    iget-object v14, v0, Lb96;->o:Lte4;

    .line 194
    .line 195
    invoke-direct/range {v7 .. v15}, Lb96;-><init>(Lte4;Lk96;Llh2;Lqe2;Lte4;Lte4;Lte4;B)V

    .line 196
    .line 197
    .line 198
    const v0, -0x57311112

    .line 199
    .line 200
    .line 201
    invoke-static {v0, v7, v6}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 202
    .line 203
    .line 204
    move-result-object v5

    .line 205
    const/16 v7, 0x180

    .line 206
    .line 207
    const/4 v8, 0x3

    .line 208
    const/4 v3, 0x0

    .line 209
    const/4 v4, 0x0

    .line 210
    invoke-static/range {v3 .. v8}, Lla4;->i(Lbb4;FLs21;Lzi2;II)V

    .line 211
    .line 212
    .line 213
    goto :goto_2

    .line 214
    :cond_3
    invoke-virtual {v6}, Lzi2;->b0()V

    .line 215
    .line 216
    .line 217
    :goto_2
    return-object v2

    .line 218
    nop

    .line 219
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
