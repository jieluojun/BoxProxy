.class public final Lad4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:J

.field public final b:Lqj6;

.field public final c:Lqj6;

.field public final d:Lqj6;

.field public final e:Lsf0;

.field public final f:Lad4;

.field public g:Lxf7;

.field public h:I


# direct methods
.method public constructor <init>(JLqj6;Lqj6;Lqj6;Lsf0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lad4;->a:J

    .line 5
    .line 6
    iput-object p3, p0, Lad4;->b:Lqj6;

    .line 7
    .line 8
    iput-object p4, p0, Lad4;->c:Lqj6;

    .line 9
    .line 10
    iput-object p5, p0, Lad4;->d:Lqj6;

    .line 11
    .line 12
    iput-object p6, p0, Lad4;->e:Lsf0;

    .line 13
    .line 14
    iput-object p0, p0, Lad4;->f:Lad4;

    .line 15
    .line 16
    const/4 p1, -0x1

    .line 17
    iput p1, p0, Lad4;->h:I

    .line 18
    .line 19
    return-void
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
.end method


# virtual methods
.method public final a(Lhj6;Z)J
    .locals 6

    .line 1
    iget-object v0, p1, Lhj6;->b:Lgj6;

    .line 2
    .line 3
    iget-object v1, p1, Lhj6;->a:Lgj6;

    .line 4
    .line 5
    iget-wide v2, p0, Lad4;->a:J

    .line 6
    .line 7
    if-eqz p2, :cond_0

    .line 8
    .line 9
    iget-wide v4, v1, Lgj6;->c:J

    .line 10
    .line 11
    cmp-long v2, v4, v2

    .line 12
    .line 13
    if-nez v2, :cond_1

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    iget-wide v4, v0, Lgj6;->c:J

    .line 17
    .line 18
    cmp-long v2, v4, v2

    .line 19
    .line 20
    if-nez v2, :cond_1

    .line 21
    .line 22
    :goto_0
    invoke-virtual {p0}, Lad4;->c()Lhi3;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    iget-object v2, p0, Lad4;->c:Lqj6;

    .line 29
    .line 30
    invoke-virtual {v2}, Lqj6;->a()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    check-cast v2, Lxf7;

    .line 35
    .line 36
    if-nez v2, :cond_2

    .line 37
    .line 38
    :cond_1
    const-wide p0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    return-wide p0

    .line 44
    :cond_2
    if-eqz p2, :cond_3

    .line 45
    .line 46
    iget v0, v1, Lgj6;->b:I

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_3
    iget v0, v0, Lgj6;->b:I

    .line 50
    .line 51
    :goto_1
    const/4 v1, 0x0

    .line 52
    invoke-virtual {p0, v2}, Lad4;->b(Lxf7;)I

    .line 53
    .line 54
    .line 55
    move-result p0

    .line 56
    invoke-static {v0, v1, p0}, Lej3;->v(III)I

    .line 57
    .line 58
    .line 59
    move-result p0

    .line 60
    iget-boolean p1, p1, Lhj6;->c:Z

    .line 61
    .line 62
    invoke-static {v2, p0, p2, p1}, Lj87;->j(Lxf7;IZZ)J

    .line 63
    .line 64
    .line 65
    move-result-wide p0

    .line 66
    return-wide p0
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
.end method

.method public final b(Lxf7;)I
    .locals 9

    .line 1
    iget-object v0, p0, Lad4;->f:Lad4;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Lad4;->g:Lxf7;

    .line 5
    .line 6
    if-eq v1, p1, :cond_5

    .line 7
    .line 8
    iget-object v1, p1, Lxf7;->b:Lpc4;

    .line 9
    .line 10
    iget-boolean v2, v1, Lpc4;->c:Z

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    const-wide v4, 0xffffffffL

    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    const/4 v6, 0x1

    .line 19
    if-nez v2, :cond_0

    .line 20
    .line 21
    iget-wide v7, p1, Lxf7;->c:J

    .line 22
    .line 23
    and-long/2addr v7, v4

    .line 24
    long-to-int v7, v7

    .line 25
    int-to-float v7, v7

    .line 26
    iget v8, v1, Lpc4;->e:F

    .line 27
    .line 28
    cmpg-float v7, v7, v8

    .line 29
    .line 30
    if-ltz v7, :cond_0

    .line 31
    .line 32
    move v7, v3

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    move v7, v6

    .line 35
    :goto_0
    if-eqz v7, :cond_3

    .line 36
    .line 37
    if-nez v2, :cond_3

    .line 38
    .line 39
    iget-wide v7, p1, Lxf7;->c:J

    .line 40
    .line 41
    and-long/2addr v7, v4

    .line 42
    long-to-int v2, v7

    .line 43
    int-to-float v2, v2

    .line 44
    invoke-virtual {v1, v2}, Lpc4;->d(F)I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    iget-object v2, p1, Lxf7;->b:Lpc4;

    .line 49
    .line 50
    iget v2, v2, Lpc4;->f:I

    .line 51
    .line 52
    sub-int/2addr v2, v6

    .line 53
    if-le v1, v2, :cond_1

    .line 54
    .line 55
    move v1, v2

    .line 56
    :cond_1
    :goto_1
    if-ltz v1, :cond_2

    .line 57
    .line 58
    iget-object v2, p1, Lxf7;->b:Lpc4;

    .line 59
    .line 60
    invoke-virtual {v2, v1}, Lpc4;->e(I)F

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    iget-wide v7, p1, Lxf7;->c:J

    .line 65
    .line 66
    and-long/2addr v7, v4

    .line 67
    long-to-int v7, v7

    .line 68
    int-to-float v7, v7

    .line 69
    cmpl-float v2, v2, v7

    .line 70
    .line 71
    if-ltz v2, :cond_2

    .line 72
    .line 73
    add-int/lit8 v1, v1, -0x1

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_2
    if-ltz v1, :cond_4

    .line 77
    .line 78
    move v3, v1

    .line 79
    goto :goto_2

    .line 80
    :cond_3
    iget v1, v1, Lpc4;->f:I

    .line 81
    .line 82
    add-int/lit8 v3, v1, -0x1

    .line 83
    .line 84
    :cond_4
    :goto_2
    iget-object v1, p1, Lxf7;->b:Lpc4;

    .line 85
    .line 86
    invoke-virtual {v1, v3, v6}, Lpc4;->b(IZ)I

    .line 87
    .line 88
    .line 89
    move-result v1

    .line 90
    iput v1, p0, Lad4;->h:I

    .line 91
    .line 92
    iput-object p1, p0, Lad4;->g:Lxf7;

    .line 93
    .line 94
    :cond_5
    iget p0, p0, Lad4;->h:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 95
    .line 96
    monitor-exit v0

    .line 97
    return p0

    .line 98
    :catchall_0
    move-exception p0

    .line 99
    monitor-exit v0

    .line 100
    throw p0
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public final c()Lhi3;
    .locals 1

    .line 1
    iget-object p0, p0, Lad4;->b:Lqj6;

    .line 2
    .line 3
    invoke-virtual {p0}, Lqj6;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lhi3;

    .line 8
    .line 9
    if-eqz p0, :cond_0

    .line 10
    .line 11
    invoke-interface {p0}, Lhi3;->B()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_0
    const/4 p0, 0x0

    .line 19
    return-object p0
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final d()Lhj6;
    .locals 8

    .line 1
    iget-object v0, p0, Lad4;->c:Lqj6;

    .line 2
    .line 3
    invoke-virtual {v0}, Lqj6;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lxf7;

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    return-object p0

    .line 13
    :cond_0
    iget-object v1, v0, Lxf7;->a:Lwf7;

    .line 14
    .line 15
    iget-object v1, v1, Lwf7;->a:Lij;

    .line 16
    .line 17
    iget-object v1, v1, Lij;->i:Ljava/lang/String;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    new-instance v2, Lhj6;

    .line 24
    .line 25
    new-instance v3, Lgj6;

    .line 26
    .line 27
    const/4 v4, 0x0

    .line 28
    invoke-virtual {v0, v4}, Lxf7;->a(I)Ldz5;

    .line 29
    .line 30
    .line 31
    move-result-object v5

    .line 32
    iget-wide v6, p0, Lad4;->a:J

    .line 33
    .line 34
    invoke-direct {v3, v5, v4, v6, v7}, Lgj6;-><init>(Ldz5;IJ)V

    .line 35
    .line 36
    .line 37
    new-instance p0, Lgj6;

    .line 38
    .line 39
    add-int/lit8 v5, v1, -0x1

    .line 40
    .line 41
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    invoke-virtual {v0, v5}, Lxf7;->a(I)Ldz5;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-direct {p0, v0, v1, v6, v7}, Lgj6;-><init>(Ldz5;IJ)V

    .line 50
    .line 51
    .line 52
    invoke-direct {v2, v3, p0, v4}, Lhj6;-><init>(Lgj6;Lgj6;Z)V

    .line 53
    .line 54
    .line 55
    return-object v2
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method

.method public final e()Lij;
    .locals 1

    .line 1
    iget-object p0, p0, Lad4;->c:Lqj6;

    .line 2
    .line 3
    invoke-virtual {p0}, Lqj6;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lxf7;

    .line 8
    .line 9
    if-nez p0, :cond_0

    .line 10
    .line 11
    new-instance p0, Lij;

    .line 12
    .line 13
    const-string v0, ""

    .line 14
    .line 15
    invoke-direct {p0, v0}, Lij;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_0
    iget-object p0, p0, Lxf7;->a:Lwf7;

    .line 20
    .line 21
    iget-object p0, p0, Lwf7;->a:Lij;

    .line 22
    .line 23
    return-object p0
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
