.class public final Lb73;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lmz6;


# instance fields
.field public h:Ljava/lang/Float;

.field public i:Ljava/lang/Float;

.field public final j:Lz75;

.field public k:Lj97;

.field public l:Z

.field public m:Z

.field public n:J

.field public final synthetic o:Le73;


# direct methods
.method public constructor <init>(Le73;Ljava/lang/Float;Ljava/lang/Float;La73;)V
    .locals 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb73;->o:Le73;

    .line 5
    .line 6
    iput-object p2, p0, Lb73;->h:Ljava/lang/Float;

    .line 7
    .line 8
    iput-object p3, p0, Lb73;->i:Ljava/lang/Float;

    .line 9
    .line 10
    invoke-static {p2}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iput-object p1, p0, Lb73;->j:Lz75;

    .line 15
    .line 16
    new-instance v0, Lj97;

    .line 17
    .line 18
    iget-object v3, p0, Lb73;->h:Ljava/lang/Float;

    .line 19
    .line 20
    iget-object v4, p0, Lb73;->i:Ljava/lang/Float;

    .line 21
    .line 22
    const/4 v5, 0x0

    .line 23
    sget-object v2, Lj58;->M:Ltp7;

    .line 24
    .line 25
    move-object v1, p4

    .line 26
    invoke-direct/range {v0 .. v5}, Lj97;-><init>(Lvi;Ltp7;Ljava/lang/Object;Ljava/lang/Object;Lbj;)V

    .line 27
    .line 28
    .line 29
    iput-object v0, p0, Lb73;->k:Lj97;

    .line 30
    .line 31
    return-void
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
.end method


# virtual methods
.method public final getValue()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Lb73;->j:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz75;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
