.class public final synthetic Lan;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lan;->h:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-byte p0, p0, Lan;->h:B

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    packed-switch p0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    const-string p0, ""

    .line 8
    .line 9
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0

    .line 14
    :pswitch_0
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 15
    .line 16
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0

    .line 21
    :pswitch_1
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :pswitch_2
    sget-object p0, Lu22;->h:Lu22;

    .line 31
    .line 32
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    return-object p0

    .line 37
    :pswitch_3
    sget-object p0, Liv6;->h:Liv6;

    .line 38
    .line 39
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0

    .line 44
    :pswitch_4
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 45
    .line 46
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0

    .line 51
    :pswitch_5
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 52
    .line 53
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    return-object p0

    .line 58
    :pswitch_6
    sget-object p0, Lu22;->h:Lu22;

    .line 59
    .line 60
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    return-object p0

    .line 65
    :pswitch_7
    sget-object p0, Ltv;->h:Ltv;

    .line 66
    .line 67
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    return-object p0

    .line 72
    :pswitch_8
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 73
    .line 74
    invoke-static {p0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    return-object p0

    .line 79
    :pswitch_9
    sget-object p0, Lst7;->a:Lst7;

    .line 80
    .line 81
    return-object p0

    .line 82
    :pswitch_a
    sget-object p0, Lst7;->a:Lst7;

    .line 83
    .line 84
    return-object p0

    .line 85
    :pswitch_b
    const/high16 p0, 0x3f800000    # 1.0f

    .line 86
    .line 87
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    return-object p0

    .line 92
    :pswitch_c
    new-instance p0, Lkn7;

    .line 93
    .line 94
    const v0, -0x800001

    .line 95
    .line 96
    .line 97
    const/4 v1, 0x0

    .line 98
    invoke-direct {p0, v0, v1, v1}, Lkn7;-><init>(FFF)V

    .line 99
    .line 100
    .line 101
    return-object p0

    .line 102
    :pswitch_d
    sget-object p0, Lcom/box/app/AppApplication;->h:Landroid/content/Context;

    .line 103
    .line 104
    invoke-static {}, Lob3;->B()Landroid/content/Context;

    .line 105
    .line 106
    .line 107
    move-result-object p0

    .line 108
    check-cast p0, Lcom/box/app/AppApplication;

    .line 109
    .line 110
    :try_start_0
    invoke-static {}, Lm92;->c()Lm92;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    new-instance v2, Lzx;

    .line 115
    .line 116
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 121
    .line 122
    .line 123
    iput-object v3, v2, Lzx;->b:Landroid/content/res/AssetManager;

    .line 124
    .line 125
    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 126
    :try_start_1
    sget-object v3, Lo92;->a:Ln92;

    .line 127
    .line 128
    if-eq v2, v3, :cond_0

    .line 129
    .line 130
    iget-object v3, v1, Lm92;->a:Ljava/util/ArrayList;

    .line 131
    .line 132
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 133
    .line 134
    .line 135
    :cond_0
    :try_start_2
    monitor-exit v1

    .line 136
    sget-object v1, Lst7;->a:Lst7;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 137
    .line 138
    goto :goto_1

    .line 139
    :goto_0
    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 140
    :try_start_4
    throw v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 141
    :catchall_0
    move-exception v2

    .line 142
    goto :goto_0

    .line 143
    :catchall_1
    move-exception v1

    .line 144
    new-instance v2, Ltz5;

    .line 145
    .line 146
    invoke-direct {v2, v1}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 147
    .line 148
    .line 149
    move-object v1, v2

    .line 150
    :goto_1
    invoke-static {v1}, Luz5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    if-eqz v1, :cond_1

    .line 155
    .line 156
    const-string v2, "BoxAppTextMate"

    .line 157
    .line 158
    const-string v3, "Failed to register TextMate assets"

    .line 159
    .line 160
    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 161
    .line 162
    .line 163
    :cond_1
    invoke-static {}, Lzi7;->L()Lzi7;

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    const-string v2, "darcula"

    .line 168
    .line 169
    const/4 v3, 0x1

    .line 170
    invoke-static {v1, v2, v3}, Lcom/box/app/AppApplication;->a(Lzi7;Ljava/lang/String;Z)V

    .line 171
    .line 172
    .line 173
    const-string v2, "light"

    .line 174
    .line 175
    invoke-static {v1, v2, v0}, Lcom/box/app/AppApplication;->a(Lzi7;Ljava/lang/String;Z)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 179
    .line 180
    .line 181
    move-result-object p0

    .line 182
    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 183
    .line 184
    .line 185
    move-result-object p0

    .line 186
    iget p0, p0, Landroid/content/res/Configuration;->uiMode:I

    .line 187
    .line 188
    and-int/lit8 p0, p0, 0x30

    .line 189
    .line 190
    const/16 v0, 0x20

    .line 191
    .line 192
    if-ne p0, v0, :cond_2

    .line 193
    .line 194
    :try_start_5
    const-string p0, "darcula"

    .line 195
    .line 196
    goto :goto_2

    .line 197
    :cond_2
    const-string p0, "light"

    .line 198
    .line 199
    :goto_2
    invoke-virtual {v1, p0}, Lzi7;->t0(Ljava/lang/String;)Z

    .line 200
    .line 201
    .line 202
    move-result p0

    .line 203
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 204
    .line 205
    .line 206
    move-result-object p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 207
    goto :goto_3

    .line 208
    :catchall_2
    move-exception p0

    .line 209
    new-instance v0, Ltz5;

    .line 210
    .line 211
    invoke-direct {v0, p0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 212
    .line 213
    .line 214
    move-object p0, v0

    .line 215
    :goto_3
    invoke-static {p0}, Luz5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 216
    .line 217
    .line 218
    move-result-object p0

    .line 219
    if-eqz p0, :cond_3

    .line 220
    .line 221
    const-string v0, "BoxAppTextMate"

    .line 222
    .line 223
    const-string v1, "Failed to set default TextMate theme"

    .line 224
    .line 225
    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 226
    .line 227
    .line 228
    :cond_3
    :try_start_6
    invoke-static {}, Loq2;->l()Loq2;

    .line 229
    .line 230
    .line 231
    move-result-object p0

    .line 232
    const-string v0, "textmate/languages.json"

    .line 233
    .line 234
    invoke-virtual {p0, v0}, Loq2;->s(Ljava/lang/String;)Ljava/util/List;

    .line 235
    .line 236
    .line 237
    move-result-object p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 238
    goto :goto_4

    .line 239
    :catchall_3
    move-exception p0

    .line 240
    new-instance v0, Ltz5;

    .line 241
    .line 242
    invoke-direct {v0, p0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 243
    .line 244
    .line 245
    move-object p0, v0

    .line 246
    :goto_4
    invoke-static {p0}, Luz5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 247
    .line 248
    .line 249
    move-result-object p0

    .line 250
    if-eqz p0, :cond_4

    .line 251
    .line 252
    const-string v0, "BoxAppTextMate"

    .line 253
    .line 254
    const-string v1, "Failed to load TextMate grammars"

    .line 255
    .line 256
    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 257
    .line 258
    .line 259
    :cond_4
    :try_start_7
    invoke-static {}, Loq2;->l()Loq2;

    .line 260
    .line 261
    .line 262
    move-result-object p0

    .line 263
    const-string v0, "textmate/languages-js.json"

    .line 264
    .line 265
    invoke-virtual {p0, v0}, Loq2;->s(Ljava/lang/String;)Ljava/util/List;

    .line 266
    .line 267
    .line 268
    move-result-object p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 269
    goto :goto_5

    .line 270
    :catchall_4
    move-exception p0

    .line 271
    new-instance v0, Ltz5;

    .line 272
    .line 273
    invoke-direct {v0, p0}, Ltz5;-><init>(Ljava/lang/Throwable;)V

    .line 274
    .line 275
    .line 276
    move-object p0, v0

    .line 277
    :goto_5
    invoke-static {p0}, Luz5;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 278
    .line 279
    .line 280
    move-result-object p0

    .line 281
    if-eqz p0, :cond_5

    .line 282
    .line 283
    const-string v0, "BoxAppTextMate"

    .line 284
    .line 285
    const-string v1, "Failed to load JavaScript TextMate grammar"

    .line 286
    .line 287
    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 288
    .line 289
    .line 290
    :cond_5
    sget-object p0, Lst7;->a:Lst7;

    .line 291
    .line 292
    return-object p0

    .line 293
    :pswitch_e
    sget-object p0, Lst7;->a:Lst7;

    .line 294
    .line 295
    return-object p0

    .line 296
    :pswitch_f
    sget-object p0, Lst7;->a:Lst7;

    .line 297
    .line 298
    return-object p0

    .line 299
    :pswitch_10
    sget-object p0, Lst7;->a:Lst7;

    .line 300
    .line 301
    return-object p0

    .line 302
    :pswitch_11
    sget-object p0, Lst7;->a:Lst7;

    .line 303
    .line 304
    return-object p0

    .line 305
    :pswitch_12
    sget-object p0, Lst7;->a:Lst7;

    .line 306
    .line 307
    return-object p0

    .line 308
    :pswitch_13
    sget-object p0, Lst7;->a:Lst7;

    .line 309
    .line 310
    return-object p0

    .line 311
    :pswitch_14
    sget-object p0, Lst7;->a:Lst7;

    .line 312
    .line 313
    return-object p0

    .line 314
    :pswitch_15
    sget-object p0, Lst7;->a:Lst7;

    .line 315
    .line 316
    return-object p0

    .line 317
    :pswitch_16
    sget-object p0, Lst7;->a:Lst7;

    .line 318
    .line 319
    return-object p0

    .line 320
    :pswitch_17
    sget-object p0, Lst7;->a:Lst7;

    .line 321
    .line 322
    return-object p0

    .line 323
    :pswitch_18
    sget-object p0, Lst7;->a:Lst7;

    .line 324
    .line 325
    return-object p0

    .line 326
    :pswitch_19
    sget-object p0, Lst7;->a:Lst7;

    .line 327
    .line 328
    return-object p0

    .line 329
    :pswitch_1a
    sget-object p0, Lst7;->a:Lst7;

    .line 330
    .line 331
    return-object p0

    .line 332
    :pswitch_1b
    sget-object p0, Lst7;->a:Lst7;

    .line 333
    .line 334
    return-object p0

    .line 335
    :pswitch_1c
    sget-object p0, Lst7;->a:Lst7;

    .line 336
    .line 337
    return-object p0

    .line 338
    nop

    .line 339
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
