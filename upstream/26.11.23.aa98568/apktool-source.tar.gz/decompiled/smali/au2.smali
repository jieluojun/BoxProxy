.class public final synthetic Lau2;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Z

.field public final synthetic j:Z

.field public final synthetic k:Llh2;

.field public final synthetic l:Llh2;

.field public final synthetic m:Llh2;


# direct methods
.method public synthetic constructor <init>(ZZLlh2;Llh2;Llh2;B)V
    .locals 0

    .line 1
    iput-byte p6, p0, Lau2;->h:B

    .line 2
    .line 3
    iput-boolean p1, p0, Lau2;->i:Z

    .line 4
    .line 5
    iput-boolean p2, p0, Lau2;->j:Z

    .line 6
    .line 7
    iput-object p3, p0, Lau2;->k:Llh2;

    .line 8
    .line 9
    iput-object p4, p0, Lau2;->l:Llh2;

    .line 10
    .line 11
    iput-object p5, p0, Lau2;->m:Llh2;

    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    return-void
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lau2;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/high16 v3, 0x3f800000    # 1.0f

    .line 8
    .line 9
    sget-object v4, Lya4;->h:Lya4;

    .line 10
    .line 11
    sget-object v5, Lc51;->a:Lql0;

    .line 12
    .line 13
    const/4 v6, 0x2

    .line 14
    const/4 v7, 0x1

    .line 15
    const/4 v8, 0x0

    .line 16
    iget-boolean v9, v0, Lau2;->i:Z

    .line 17
    .line 18
    packed-switch v1, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    move-object/from16 v1, p1

    .line 22
    .line 23
    check-cast v1, Lzi2;

    .line 24
    .line 25
    move-object/from16 v10, p2

    .line 26
    .line 27
    check-cast v10, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 30
    .line 31
    .line 32
    move-result v10

    .line 33
    and-int/lit8 v11, v10, 0x3

    .line 34
    .line 35
    if-eq v11, v6, :cond_0

    .line 36
    .line 37
    move v6, v7

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    move v6, v8

    .line 40
    :goto_0
    and-int/2addr v10, v7

    .line 41
    invoke-virtual {v1, v10, v6}, Lzi2;->Y(IZ)Z

    .line 42
    .line 43
    .line 44
    move-result v6

    .line 45
    if-eqz v6, :cond_3

    .line 46
    .line 47
    if-eqz v9, :cond_2

    .line 48
    .line 49
    const v6, 0x57296f8d

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1, v6}, Lzi2;->h0(I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v6

    .line 59
    if-ne v6, v5, :cond_1

    .line 60
    .line 61
    new-instance v6, Lqh1;

    .line 62
    .line 63
    const/16 v5, 0x13

    .line 64
    .line 65
    invoke-direct {v6, v5}, Lqh1;-><init>(B)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    :cond_1
    move-object v15, v6

    .line 72
    check-cast v15, Llh2;

    .line 73
    .line 74
    invoke-static {v4, v3}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 75
    .line 76
    .line 77
    move-result-object v9

    .line 78
    const/high16 v13, 0x41000000    # 8.0f

    .line 79
    .line 80
    const/4 v14, 0x7

    .line 81
    const/4 v10, 0x0

    .line 82
    const/4 v11, 0x0

    .line 83
    const/4 v12, 0x0

    .line 84
    invoke-static/range {v9 .. v14}, Lah0;->I(Lbb4;FFFFI)Lbb4;

    .line 85
    .line 86
    .line 87
    move-result-object v25

    .line 88
    const/high16 v28, 0x30000

    .line 89
    .line 90
    const/16 v29, 0x7f82

    .line 91
    .line 92
    sget-object v10, Lfk;->k:Lfk;

    .line 93
    .line 94
    const/4 v11, 0x0

    .line 95
    iget-boolean v12, v0, Lau2;->j:Z

    .line 96
    .line 97
    iget-object v13, v0, Lau2;->k:Llh2;

    .line 98
    .line 99
    iget-object v14, v0, Lau2;->l:Llh2;

    .line 100
    .line 101
    iget-object v0, v0, Lau2;->m:Llh2;

    .line 102
    .line 103
    const/16 v17, 0x0

    .line 104
    .line 105
    const/16 v18, 0x0

    .line 106
    .line 107
    const/16 v19, 0x0

    .line 108
    .line 109
    const/16 v20, 0x0

    .line 110
    .line 111
    const/16 v21, 0x0

    .line 112
    .line 113
    const/16 v22, 0x0

    .line 114
    .line 115
    const/16 v23, 0x0

    .line 116
    .line 117
    const/16 v24, 0x0

    .line 118
    .line 119
    const v27, 0x30006

    .line 120
    .line 121
    .line 122
    move-object/from16 v16, v0

    .line 123
    .line 124
    move-object/from16 v26, v1

    .line 125
    .line 126
    invoke-static/range {v10 .. v29}, Lbx;->h(Lfk;Llh2;ZLlh2;Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;ZZZZFLbb4;Lzi2;III)V

    .line 127
    .line 128
    .line 129
    move-object/from16 v0, v26

    .line 130
    .line 131
    invoke-virtual {v0, v8}, Lzi2;->r(Z)V

    .line 132
    .line 133
    .line 134
    goto :goto_1

    .line 135
    :cond_2
    move-object v0, v1

    .line 136
    const v1, 0x5730adfb

    .line 137
    .line 138
    .line 139
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v0, v8}, Lzi2;->r(Z)V

    .line 143
    .line 144
    .line 145
    goto :goto_1

    .line 146
    :cond_3
    move-object v0, v1

    .line 147
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 148
    .line 149
    .line 150
    :goto_1
    return-object v2

    .line 151
    :pswitch_0
    move-object/from16 v1, p1

    .line 152
    .line 153
    check-cast v1, Lzi2;

    .line 154
    .line 155
    move-object/from16 v10, p2

    .line 156
    .line 157
    check-cast v10, Ljava/lang/Integer;

    .line 158
    .line 159
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 160
    .line 161
    .line 162
    move-result v10

    .line 163
    and-int/lit8 v11, v10, 0x3

    .line 164
    .line 165
    if-eq v11, v6, :cond_4

    .line 166
    .line 167
    move v6, v7

    .line 168
    goto :goto_2

    .line 169
    :cond_4
    move v6, v8

    .line 170
    :goto_2
    and-int/2addr v10, v7

    .line 171
    invoke-virtual {v1, v10, v6}, Lzi2;->Y(IZ)Z

    .line 172
    .line 173
    .line 174
    move-result v6

    .line 175
    if-eqz v6, :cond_7

    .line 176
    .line 177
    if-eqz v9, :cond_6

    .line 178
    .line 179
    const v6, 0x40c072ab

    .line 180
    .line 181
    .line 182
    invoke-virtual {v1, v6}, Lzi2;->h0(I)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v6

    .line 189
    if-ne v6, v5, :cond_5

    .line 190
    .line 191
    new-instance v6, Lqh1;

    .line 192
    .line 193
    const/16 v5, 0x12

    .line 194
    .line 195
    invoke-direct {v6, v5}, Lqh1;-><init>(B)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 199
    .line 200
    .line 201
    :cond_5
    move-object v14, v6

    .line 202
    check-cast v14, Llh2;

    .line 203
    .line 204
    invoke-static {v4, v3}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 205
    .line 206
    .line 207
    move-result-object v15

    .line 208
    const/high16 v19, 0x41000000    # 8.0f

    .line 209
    .line 210
    const/16 v20, 0x7

    .line 211
    .line 212
    const/16 v16, 0x0

    .line 213
    .line 214
    const/16 v17, 0x0

    .line 215
    .line 216
    const/16 v18, 0x0

    .line 217
    .line 218
    invoke-static/range {v15 .. v20}, Lah0;->I(Lbb4;FFFFI)Lbb4;

    .line 219
    .line 220
    .line 221
    move-result-object v24

    .line 222
    const/high16 v27, 0x30000

    .line 223
    .line 224
    const/16 v28, 0x7f82

    .line 225
    .line 226
    sget-object v9, Lfk;->k:Lfk;

    .line 227
    .line 228
    const/4 v10, 0x0

    .line 229
    iget-boolean v11, v0, Lau2;->j:Z

    .line 230
    .line 231
    iget-object v12, v0, Lau2;->k:Llh2;

    .line 232
    .line 233
    iget-object v13, v0, Lau2;->l:Llh2;

    .line 234
    .line 235
    iget-object v15, v0, Lau2;->m:Llh2;

    .line 236
    .line 237
    const/16 v16, 0x0

    .line 238
    .line 239
    const/16 v17, 0x0

    .line 240
    .line 241
    const/16 v18, 0x0

    .line 242
    .line 243
    const/16 v19, 0x0

    .line 244
    .line 245
    const/16 v20, 0x0

    .line 246
    .line 247
    const/16 v21, 0x0

    .line 248
    .line 249
    const/16 v22, 0x0

    .line 250
    .line 251
    const/16 v23, 0x0

    .line 252
    .line 253
    const v26, 0x30006

    .line 254
    .line 255
    .line 256
    move-object/from16 v25, v1

    .line 257
    .line 258
    invoke-static/range {v9 .. v28}, Ldy3;->g(Lfk;Llh2;ZLlh2;Llh2;Llh2;Llh2;Llh2;Llh2;Llh2;ZZZZFLbb4;Lzi2;III)V

    .line 259
    .line 260
    .line 261
    move-object/from16 v0, v25

    .line 262
    .line 263
    invoke-virtual {v0, v8}, Lzi2;->r(Z)V

    .line 264
    .line 265
    .line 266
    goto :goto_3

    .line 267
    :cond_6
    move-object v0, v1

    .line 268
    const v1, 0x40c7bc5c

    .line 269
    .line 270
    .line 271
    invoke-virtual {v0, v1}, Lzi2;->h0(I)V

    .line 272
    .line 273
    .line 274
    invoke-virtual {v0, v8}, Lzi2;->r(Z)V

    .line 275
    .line 276
    .line 277
    goto :goto_3

    .line 278
    :cond_7
    move-object v0, v1

    .line 279
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 280
    .line 281
    .line 282
    :goto_3
    return-object v2

    .line 283
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
.end method
