.class public final La44;
.super Lky3;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public final d(Lz34;I)V
    .locals 2

    .line 1
    const/4 v0, 0x6

    .line 2
    invoke-virtual {p0, v0}, Lky3;->a(I)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    iget v1, p0, Lky3;->h:I

    .line 9
    .line 10
    add-int/2addr v0, v1

    .line 11
    iget-object v1, p0, Lky3;->k:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Ljava/nio/ByteBuffer;

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    add-int/2addr v1, v0

    .line 20
    add-int/lit8 v1, v1, 0x4

    .line 21
    .line 22
    shl-int/lit8 p2, p2, 0x2

    .line 23
    .line 24
    add-int/2addr v1, p2

    .line 25
    iget-object p2, p0, Lky3;->k:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast p2, Ljava/nio/ByteBuffer;

    .line 28
    .line 29
    invoke-virtual {p2, v1}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 30
    .line 31
    .line 32
    move-result p2

    .line 33
    add-int/2addr p2, v1

    .line 34
    iget-object p0, p0, Lky3;->k:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p0, Ljava/nio/ByteBuffer;

    .line 37
    .line 38
    iput-object p0, p1, Lky3;->k:Ljava/lang/Object;

    .line 39
    .line 40
    if-eqz p0, :cond_0

    .line 41
    .line 42
    iput p2, p1, Lky3;->h:I

    .line 43
    .line 44
    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 45
    .line 46
    .line 47
    move-result p0

    .line 48
    sub-int/2addr p2, p0

    .line 49
    iput p2, p1, Lky3;->i:I

    .line 50
    .line 51
    iget-object p0, p1, Lky3;->k:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast p0, Ljava/nio/ByteBuffer;

    .line 54
    .line 55
    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->getShort(I)S

    .line 56
    .line 57
    .line 58
    move-result p0

    .line 59
    iput p0, p1, Lky3;->j:I

    .line 60
    .line 61
    return-void

    .line 62
    :cond_0
    const/4 p0, 0x0

    .line 63
    iput p0, p1, Lky3;->h:I

    .line 64
    .line 65
    iput p0, p1, Lky3;->i:I

    .line 66
    .line 67
    iput p0, p1, Lky3;->j:I

    .line 68
    .line 69
    :cond_1
    return-void
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
.end method
