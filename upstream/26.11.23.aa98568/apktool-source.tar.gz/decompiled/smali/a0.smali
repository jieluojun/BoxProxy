.class public final synthetic La0;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Llh2;

.field public final synthetic j:Lwh2;

.field public final synthetic k:Lbb4;


# direct methods
.method public synthetic constructor <init>(Llh2;Lwh2;Lbb4;IB)V
    .locals 0

    .line 1
    iput-byte p5, p0, La0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, La0;->i:Llh2;

    .line 4
    .line 5
    iput-object p2, p0, La0;->j:Lwh2;

    .line 6
    .line 7
    iput-object p3, p0, La0;->k:Lbb4;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, La0;->h:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    const/16 v2, 0x181

    .line 6
    .line 7
    iget-object v3, p0, La0;->k:Lbb4;

    .line 8
    .line 9
    iget-object v4, p0, La0;->j:Lwh2;

    .line 10
    .line 11
    iget-object p0, p0, La0;->i:Llh2;

    .line 12
    .line 13
    check-cast p1, Lzi2;

    .line 14
    .line 15
    check-cast p2, Ljava/lang/Integer;

    .line 16
    .line 17
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    packed-switch v0, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    invoke-static {p0, v4, v3, p1, p2}, Ldy3;->P(Llh2;Lwh2;Lbb4;Lzi2;I)V

    .line 28
    .line 29
    .line 30
    return-object v1

    .line 31
    :pswitch_0
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 32
    .line 33
    .line 34
    move-result p2

    .line 35
    invoke-static {p0, v4, v3, p1, p2}, Lkb;->z(Llh2;Lwh2;Lbb4;Lzi2;I)V

    .line 36
    .line 37
    .line 38
    return-object v1

    .line 39
    :pswitch_1
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 40
    .line 41
    .line 42
    move-result p2

    .line 43
    invoke-static {p0, v4, v3, p1, p2}, Lob3;->p(Llh2;Lwh2;Lbb4;Lzi2;I)V

    .line 44
    .line 45
    .line 46
    return-object v1

    .line 47
    :pswitch_2
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    invoke-static {p0, v4, v3, p1, p2}, Lnb3;->r(Llh2;Lwh2;Lbb4;Lzi2;I)V

    .line 52
    .line 53
    .line 54
    return-object v1

    .line 55
    :pswitch_3
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 56
    .line 57
    .line 58
    move-result p2

    .line 59
    invoke-static {p0, v4, v3, p1, p2}, Lbx;->f(Llh2;Lwh2;Lbb4;Lzi2;I)V

    .line 60
    .line 61
    .line 62
    return-object v1

    .line 63
    :pswitch_4
    invoke-static {v2}, Lyj3;->j0(I)I

    .line 64
    .line 65
    .line 66
    move-result p2

    .line 67
    invoke-static {p0, v4, v3, p1, p2}, Ldy3;->f(Llh2;Lwh2;Lbb4;Lzi2;I)V

    .line 68
    .line 69
    .line 70
    return-object v1

    .line 71
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
