.class public final synthetic La37;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lc37;


# direct methods
.method public synthetic constructor <init>(Lc37;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, La37;->h:B

    .line 2
    .line 3
    iput-object p1, p0, La37;->i:Lc37;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, La37;->h:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    iget-object p0, p0, La37;->i:Lc37;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p1, Lzi3;

    .line 11
    .line 12
    check-cast p2, Lai2;

    .line 13
    .line 14
    invoke-virtual {p0}, Lc37;->a()Loj3;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    iget-object v0, p0, Loj3;->w:Ljava/lang/String;

    .line 19
    .line 20
    new-instance v2, Lkj3;

    .line 21
    .line 22
    invoke-direct {v2, p0, p2, v0}, Lkj3;-><init>(Loj3;Lai2;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1, v2}, Lzi3;->d0(Lu14;)V

    .line 26
    .line 27
    .line 28
    return-object v1

    .line 29
    :pswitch_0
    check-cast p1, Lzi3;

    .line 30
    .line 31
    check-cast p2, Ln51;

    .line 32
    .line 33
    invoke-virtual {p0}, Lc37;->a()Loj3;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    iput-object p2, p0, Loj3;->i:Ln51;

    .line 38
    .line 39
    return-object v1

    .line 40
    :pswitch_1
    iget-object v0, p0, Lc37;->a:Lf37;

    .line 41
    .line 42
    check-cast p1, Lzi3;

    .line 43
    .line 44
    check-cast p2, Lc37;

    .line 45
    .line 46
    iget-object p2, p1, Lzi3;->O:Loj3;

    .line 47
    .line 48
    if-nez p2, :cond_0

    .line 49
    .line 50
    new-instance p2, Loj3;

    .line 51
    .line 52
    invoke-direct {p2, p1, v0}, Loj3;-><init>(Lzi3;Lf37;)V

    .line 53
    .line 54
    .line 55
    iput-object p2, p1, Lzi3;->O:Loj3;

    .line 56
    .line 57
    :cond_0
    iput-object p2, p0, Lc37;->b:Loj3;

    .line 58
    .line 59
    invoke-virtual {p0}, Lc37;->a()Loj3;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {p1}, Loj3;->g()V

    .line 64
    .line 65
    .line 66
    invoke-virtual {p0}, Lc37;->a()Loj3;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    iget-object p1, p0, Loj3;->j:Lf37;

    .line 71
    .line 72
    if-eq p1, v0, :cond_1

    .line 73
    .line 74
    iput-object v0, p0, Loj3;->j:Lf37;

    .line 75
    .line 76
    const/4 p1, 0x0

    .line 77
    invoke-virtual {p0, p1}, Loj3;->i(Z)V

    .line 78
    .line 79
    .line 80
    iget-object p0, p0, Loj3;->h:Lzi3;

    .line 81
    .line 82
    const/4 p2, 0x7

    .line 83
    invoke-static {p0, p1, p2}, Lzi3;->W(Lzi3;ZI)V

    .line 84
    .line 85
    .line 86
    :cond_1
    return-object v1

    .line 87
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
