.class public abstract Lav7;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public a:Ln41;


# virtual methods
.method public abstract a(Ldw1;)V
.end method

.method public b()Lwh2;
    .locals 0

    .line 1
    iget-object p0, p0, Lav7;->a:Ln41;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lav7;->b()Lwh2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-interface {v0, p0}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    :cond_0
    return-void
.end method

.method public d(Ln41;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lav7;->a:Ln41;

    .line 2
    .line 3
    return-void
.end method
