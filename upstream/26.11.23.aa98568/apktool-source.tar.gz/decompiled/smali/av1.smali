.class public final Lav1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lka3;


# instance fields
.field public final a:Lzu1;


# direct methods
.method public constructor <init>(Lzu1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lav1;->a:Lzu1;

    .line 5
    .line 6
    return-void
.end method
