.class public final Lae7;
.super Lcp1;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lu51;
.implements Lcw1;
.implements Lcl6;
.implements Lza4;


# instance fields
.field public A:Z

.field public final B:Lz75;

.field public final C:Lrg;

.field public final D:Lzx3;

.field public E:Lzy6;

.field public x:Llo7;

.field public y:Lte7;

.field public z:Lyf7;


# direct methods
.method public constructor <init>(Llo7;Lte7;Lyf7;Z)V
    .locals 3

    .line 1
    invoke-direct {p0}, Lcp1;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae7;->x:Llo7;

    .line 5
    .line 6
    iput-object p2, p0, Lae7;->y:Lte7;

    .line 7
    .line 8
    iput-object p3, p0, Lae7;->z:Lyf7;

    .line 9
    .line 10
    iput-boolean p4, p0, Lae7;->A:Z

    .line 11
    .line 12
    new-instance p1, Lx93;

    .line 13
    .line 14
    const-wide/16 p2, 0x0

    .line 15
    .line 16
    invoke-direct {p1, p2, p3}, Lx93;-><init>(J)V

    .line 17
    .line 18
    .line 19
    invoke-static {p1}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iput-object p1, p0, Lae7;->B:Lz75;

    .line 24
    .line 25
    new-instance p2, Lrg;

    .line 26
    .line 27
    iget-object p3, p0, Lae7;->x:Llo7;

    .line 28
    .line 29
    iget-object p4, p0, Lae7;->y:Lte7;

    .line 30
    .line 31
    iget-object v0, p0, Lae7;->z:Lyf7;

    .line 32
    .line 33
    invoke-virtual {p1}, Lz75;->getValue()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    check-cast p1, Lx93;

    .line 38
    .line 39
    iget-wide v1, p1, Lx93;->a:J

    .line 40
    .line 41
    invoke-static {p3, p4, v0, v1, v2}, Lx97;->b(Llo7;Lte7;Lyf7;J)J

    .line 42
    .line 43
    .line 44
    move-result-wide p3

    .line 45
    new-instance p1, Lcw4;

    .line 46
    .line 47
    invoke-direct {p1, p3, p4}, Lcw4;-><init>(J)V

    .line 48
    .line 49
    .line 50
    sget-object p3, Lgk6;->b:Ltp7;

    .line 51
    .line 52
    new-instance p4, Lcw4;

    .line 53
    .line 54
    const-wide v0, 0x3c23d70a3c23d70aL    # 5.377642754525469E-19

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    invoke-direct {p4, v0, v1}, Lcw4;-><init>(J)V

    .line 60
    .line 61
    .line 62
    const/16 v0, 0x8

    .line 63
    .line 64
    invoke-direct {p2, p1, p3, p4, v0}, Lrg;-><init>(Ljava/lang/Object;Ltp7;Ljava/lang/Object;I)V

    .line 65
    .line 66
    .line 67
    iput-object p2, p0, Lae7;->C:Lrg;

    .line 68
    .line 69
    new-instance p1, Lzx3;

    .line 70
    .line 71
    new-instance p2, Lzd7;

    .line 72
    .line 73
    const/4 p3, 0x0

    .line 74
    invoke-direct {p2, p0, p3}, Lzd7;-><init>(Lae7;B)V

    .line 75
    .line 76
    .line 77
    new-instance p3, Lzd7;

    .line 78
    .line 79
    const/4 p4, 0x1

    .line 80
    invoke-direct {p3, p0, p4}, Lzd7;-><init>(Lae7;B)V

    .line 81
    .line 82
    .line 83
    sget-object p4, Lh22;->M:Lh22;

    .line 84
    .line 85
    sget-object v0, Lay3;->a:Lkl6;

    .line 86
    .line 87
    invoke-direct {p1, p2, p3, p4}, Lzx3;-><init>(Lwh2;Lwh2;Lh22;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {p0, p1}, Lcp1;->G1(Lap1;)V

    .line 91
    .line 92
    .line 93
    iput-object p1, p0, Lae7;->D:Lzx3;

    .line 94
    .line 95
    return-void
.end method


# virtual methods
.method public final H(Lbt4;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lae7;->D:Lzx3;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lzx3;->H(Lbt4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final J1()V
    .locals 7

    .line 1
    iget-object v0, p0, Lae7;->E:Lzy6;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    invoke-virtual {v0, v1}, Lfd3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 7
    .line 8
    .line 9
    :cond_0
    iput-object v1, p0, Lae7;->E:Lzy6;

    .line 10
    .line 11
    sget-object v0, Lay3;->a:Lkl6;

    .line 12
    .line 13
    iget-boolean v0, p0, Lae7;->A:Z

    .line 14
    .line 15
    const/4 v2, 0x3

    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    iget-object v0, p0, Lae7;->C:Lrg;

    .line 19
    .line 20
    invoke-virtual {v0}, Lrg;->e()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Lcw4;

    .line 25
    .line 26
    iget-wide v3, v0, Lcw4;->a:J

    .line 27
    .line 28
    const-wide v5, 0x7fffffff7fffffffL

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    and-long/2addr v3, v5

    .line 34
    const-wide v5, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    cmp-long v0, v3, v5

    .line 40
    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    invoke-virtual {p0}, Lab4;->u1()Ljj1;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    new-instance v3, Lnt6;

    .line 48
    .line 49
    invoke-direct {v3, p0, v1, v2}, Lnt6;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 50
    .line 51
    .line 52
    const/4 v4, 0x1

    .line 53
    sget-object v5, Lmj1;->k:Lmj1;

    .line 54
    .line 55
    invoke-static {v0, v1, v5, v3, v4}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 56
    .line 57
    .line 58
    :cond_1
    invoke-virtual {p0}, Lab4;->u1()Ljj1;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    new-instance v3, Lik6;

    .line 63
    .line 64
    const/4 v4, 0x4

    .line 65
    invoke-direct {v3, p0, v1, v4}, Lik6;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 66
    .line 67
    .line 68
    invoke-static {v0, v1, v1, v3, v2}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iput-object v0, p0, Lae7;->E:Lzy6;

    .line 73
    .line 74
    return-void
.end method

.method public final R0(Lll6;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lae7;->D:Lzx3;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lzx3;->R0(Lll6;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final l0(Lbj3;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Lbj3;->c()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lae7;->D:Lzx3;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lzx3;->l0(Lbj3;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final y1()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lae7;->J1()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
