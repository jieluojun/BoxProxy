.class public final synthetic Lab6;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lrc6;

.field public final synthetic j:Lx96;

.field public final synthetic k:Lac6;

.field public final synthetic l:Landroid/content/Context;

.field public final synthetic m:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lrc6;Lx96;Lac6;Landroid/content/Context;Ljava/lang/String;B)V
    .locals 0

    .line 1
    iput-byte p6, p0, Lab6;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lab6;->i:Lrc6;

    .line 4
    .line 5
    iput-object p2, p0, Lab6;->j:Lx96;

    .line 6
    .line 7
    iput-object p3, p0, Lab6;->k:Lac6;

    .line 8
    .line 9
    iput-object p4, p0, Lab6;->l:Landroid/content/Context;

    .line 10
    .line 11
    iput-object p5, p0, Lab6;->m:Ljava/lang/String;

    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-byte v0, p0, Lab6;->h:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v3, p0, Lab6;->m:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v4, p0, Lab6;->l:Landroid/content/Context;

    .line 9
    .line 10
    iget-object v5, p0, Lab6;->k:Lac6;

    .line 11
    .line 12
    iget-object v6, p0, Lab6;->j:Lx96;

    .line 13
    .line 14
    iget-object p0, p0, Lab6;->i:Lrc6;

    .line 15
    .line 16
    check-cast p1, Ljava/lang/String;

    .line 17
    .line 18
    packed-switch v0, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, v2}, Lrc6;->i(Lac6;)V

    .line 25
    .line 26
    .line 27
    new-instance p0, Lc81;

    .line 28
    .line 29
    const/16 v0, 0x16

    .line 30
    .line 31
    invoke-direct {p0, v3, v4, v0}, Lc81;-><init>(Ljava/lang/String;Landroid/content/Context;B)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v6, v5, p1, v4, p0}, Lx96;->p(Lac6;Ljava/lang/String;Landroid/content/Context;Lwh2;)V

    .line 35
    .line 36
    .line 37
    return-object v1

    .line 38
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0, v2}, Lrc6;->i(Lac6;)V

    .line 42
    .line 43
    .line 44
    new-instance p0, Lc81;

    .line 45
    .line 46
    const/16 v0, 0x15

    .line 47
    .line 48
    invoke-direct {p0, v3, v4, v0}, Lc81;-><init>(Ljava/lang/String;Landroid/content/Context;B)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v6, v5, p1, v4, p0}, Lx96;->p(Lac6;Ljava/lang/String;Landroid/content/Context;Lwh2;)V

    .line 52
    .line 53
    .line 54
    return-object v1

    .line 55
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
