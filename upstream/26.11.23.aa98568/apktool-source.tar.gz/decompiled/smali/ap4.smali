.class public final synthetic Lap4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:I

.field public final synthetic j:Llh2;

.field public final synthetic k:I

.field public final synthetic l:Llh2;

.field public final synthetic m:Llh2;

.field public final synthetic n:Llh2;

.field public final synthetic o:Lte4;


# direct methods
.method public synthetic constructor <init>(ILlh2;ILlh2;Llh2;Llh2;Lte4;B)V
    .locals 0

    .line 1
    iput-byte p8, p0, Lap4;->h:B

    .line 2
    .line 3
    iput p1, p0, Lap4;->i:I

    .line 4
    .line 5
    iput-object p2, p0, Lap4;->j:Llh2;

    .line 6
    .line 7
    iput p3, p0, Lap4;->k:I

    .line 8
    .line 9
    iput-object p4, p0, Lap4;->l:Llh2;

    .line 10
    .line 11
    iput-object p5, p0, Lap4;->m:Llh2;

    .line 12
    .line 13
    iput-object p6, p0, Lap4;->n:Llh2;

    .line 14
    .line 15
    iput-object p7, p0, Lap4;->o:Lte4;

    .line 16
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lap4;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v4, 0x2

    .line 8
    const/4 v5, 0x1

    .line 9
    packed-switch v1, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    move-object/from16 v13, p1

    .line 13
    .line 14
    check-cast v13, Lzi2;

    .line 15
    .line 16
    move-object/from16 v1, p2

    .line 17
    .line 18
    check-cast v1, Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    and-int/lit8 v6, v1, 0x3

    .line 25
    .line 26
    if-eq v6, v4, :cond_0

    .line 27
    .line 28
    move v6, v5

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    const/4 v6, 0x0

    .line 31
    :goto_0
    and-int/2addr v1, v5

    .line 32
    invoke-virtual {v13, v1, v6}, Lzi2;->Y(IZ)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_b

    .line 37
    .line 38
    const v1, 0x7f0f02c2

    .line 39
    .line 40
    .line 41
    invoke-static {v1, v13}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    iget v1, v0, Lap4;->i:I

    .line 46
    .line 47
    if-lez v1, :cond_1

    .line 48
    .line 49
    move v11, v5

    .line 50
    goto :goto_1

    .line 51
    :cond_1
    const/4 v11, 0x0

    .line 52
    :goto_1
    iget-object v7, v0, Lap4;->j:Llh2;

    .line 53
    .line 54
    invoke-virtual {v13, v7}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v8

    .line 58
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v9

    .line 62
    iget-object v10, v0, Lap4;->o:Lte4;

    .line 63
    .line 64
    sget-object v12, Lc51;->a:Lql0;

    .line 65
    .line 66
    if-nez v8, :cond_2

    .line 67
    .line 68
    if-ne v9, v12, :cond_3

    .line 69
    .line 70
    :cond_2
    new-instance v9, Luw0;

    .line 71
    .line 72
    invoke-direct {v9, v7, v10, v5}, Luw0;-><init>(Llh2;Lte4;B)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v13, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    :cond_3
    check-cast v9, Lwh2;

    .line 79
    .line 80
    const/16 v14, 0xdb0

    .line 81
    .line 82
    const/16 v15, 0x50

    .line 83
    .line 84
    const/4 v7, 0x4

    .line 85
    const/4 v8, 0x0

    .line 86
    move-object/from16 v16, v12

    .line 87
    .line 88
    move-object v12, v9

    .line 89
    const/4 v9, 0x0

    .line 90
    move-object/from16 v17, v10

    .line 91
    .line 92
    const/4 v10, 0x0

    .line 93
    move-object/from16 v3, v16

    .line 94
    .line 95
    move/from16 v16, v5

    .line 96
    .line 97
    move-object v5, v3

    .line 98
    move-object/from16 v3, v17

    .line 99
    .line 100
    invoke-static/range {v6 .. v15}, Lv74;->c(Ljava/lang/String;IZILyw1;ZLwh2;Lzi2;II)V

    .line 101
    .line 102
    .line 103
    const v6, 0x7f0f02c1

    .line 104
    .line 105
    .line 106
    invoke-static {v6, v13}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v6

    .line 110
    iget v8, v0, Lap4;->k:I

    .line 111
    .line 112
    add-int/lit8 v8, v8, -0x1

    .line 113
    .line 114
    if-ge v1, v8, :cond_4

    .line 115
    .line 116
    move/from16 v11, v16

    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_4
    const/4 v11, 0x0

    .line 120
    :goto_2
    iget-object v1, v0, Lap4;->l:Llh2;

    .line 121
    .line 122
    invoke-virtual {v13, v1}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v8

    .line 126
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v9

    .line 130
    if-nez v8, :cond_5

    .line 131
    .line 132
    if-ne v9, v5, :cond_6

    .line 133
    .line 134
    :cond_5
    new-instance v9, Luw0;

    .line 135
    .line 136
    invoke-direct {v9, v1, v3, v4}, Luw0;-><init>(Llh2;Lte4;B)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v13, v9}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    :cond_6
    move-object v12, v9

    .line 143
    check-cast v12, Lwh2;

    .line 144
    .line 145
    const/16 v14, 0xdb0

    .line 146
    .line 147
    const/16 v15, 0x50

    .line 148
    .line 149
    const/4 v8, 0x0

    .line 150
    const/4 v9, 0x1

    .line 151
    const/4 v10, 0x0

    .line 152
    invoke-static/range {v6 .. v15}, Lv74;->c(Ljava/lang/String;IZILyw1;ZLwh2;Lzi2;II)V

    .line 153
    .line 154
    .line 155
    const v1, 0x7f0f0182

    .line 156
    .line 157
    .line 158
    invoke-static {v1, v13}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v6

    .line 162
    iget-object v1, v0, Lap4;->m:Llh2;

    .line 163
    .line 164
    invoke-virtual {v13, v1}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result v4

    .line 168
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v8

    .line 172
    if-nez v4, :cond_7

    .line 173
    .line 174
    if-ne v8, v5, :cond_8

    .line 175
    .line 176
    :cond_7
    new-instance v8, Luw0;

    .line 177
    .line 178
    const/4 v4, 0x3

    .line 179
    invoke-direct {v8, v1, v3, v4}, Luw0;-><init>(Llh2;Lte4;B)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v13, v8}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    :cond_8
    move-object v12, v8

    .line 186
    check-cast v12, Lwh2;

    .line 187
    .line 188
    const/16 v14, 0xdb0

    .line 189
    .line 190
    const/16 v15, 0x70

    .line 191
    .line 192
    const/4 v8, 0x0

    .line 193
    const/4 v9, 0x2

    .line 194
    const/4 v10, 0x0

    .line 195
    const/4 v11, 0x0

    .line 196
    invoke-static/range {v6 .. v15}, Lv74;->c(Ljava/lang/String;IZILyw1;ZLwh2;Lzi2;II)V

    .line 197
    .line 198
    .line 199
    const v1, 0x7f0f02be

    .line 200
    .line 201
    .line 202
    invoke-static {v1, v13}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v6

    .line 206
    iget-object v0, v0, Lap4;->n:Llh2;

    .line 207
    .line 208
    invoke-virtual {v13, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 209
    .line 210
    .line 211
    move-result v1

    .line 212
    invoke-virtual {v13}, Lzi2;->T()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v4

    .line 216
    if-nez v1, :cond_9

    .line 217
    .line 218
    if-ne v4, v5, :cond_a

    .line 219
    .line 220
    :cond_9
    new-instance v4, Luw0;

    .line 221
    .line 222
    const/4 v1, 0x4

    .line 223
    invoke-direct {v4, v0, v3, v1}, Luw0;-><init>(Llh2;Lte4;B)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v13, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    :cond_a
    move-object v12, v4

    .line 230
    check-cast v12, Lwh2;

    .line 231
    .line 232
    const/16 v14, 0xdb0

    .line 233
    .line 234
    const/16 v15, 0x70

    .line 235
    .line 236
    const/4 v8, 0x0

    .line 237
    const/4 v9, 0x3

    .line 238
    const/4 v10, 0x0

    .line 239
    const/4 v11, 0x0

    .line 240
    invoke-static/range {v6 .. v15}, Lv74;->c(Ljava/lang/String;IZILyw1;ZLwh2;Lzi2;II)V

    .line 241
    .line 242
    .line 243
    goto :goto_3

    .line 244
    :cond_b
    invoke-virtual {v13}, Lzi2;->b0()V

    .line 245
    .line 246
    .line 247
    :goto_3
    return-object v2

    .line 248
    :pswitch_0
    move/from16 v16, v5

    .line 249
    .line 250
    move-object/from16 v1, p1

    .line 251
    .line 252
    check-cast v1, Lzi2;

    .line 253
    .line 254
    move-object/from16 v3, p2

    .line 255
    .line 256
    check-cast v3, Ljava/lang/Integer;

    .line 257
    .line 258
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 259
    .line 260
    .line 261
    move-result v3

    .line 262
    and-int/lit8 v5, v3, 0x3

    .line 263
    .line 264
    if-eq v5, v4, :cond_c

    .line 265
    .line 266
    move/from16 v4, v16

    .line 267
    .line 268
    goto :goto_4

    .line 269
    :cond_c
    const/4 v4, 0x0

    .line 270
    :goto_4
    and-int/lit8 v3, v3, 0x1

    .line 271
    .line 272
    invoke-virtual {v1, v3, v4}, Lzi2;->Y(IZ)Z

    .line 273
    .line 274
    .line 275
    move-result v3

    .line 276
    if-eqz v3, :cond_d

    .line 277
    .line 278
    new-instance v4, Lap4;

    .line 279
    .line 280
    const/4 v12, 0x1

    .line 281
    iget v5, v0, Lap4;->i:I

    .line 282
    .line 283
    iget-object v6, v0, Lap4;->j:Llh2;

    .line 284
    .line 285
    iget v7, v0, Lap4;->k:I

    .line 286
    .line 287
    iget-object v8, v0, Lap4;->l:Llh2;

    .line 288
    .line 289
    iget-object v9, v0, Lap4;->m:Llh2;

    .line 290
    .line 291
    iget-object v10, v0, Lap4;->n:Llh2;

    .line 292
    .line 293
    iget-object v11, v0, Lap4;->o:Lte4;

    .line 294
    .line 295
    invoke-direct/range {v4 .. v12}, Lap4;-><init>(ILlh2;ILlh2;Llh2;Llh2;Lte4;B)V

    .line 296
    .line 297
    .line 298
    const v0, -0x7575b82d

    .line 299
    .line 300
    .line 301
    invoke-static {v0, v4, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 302
    .line 303
    .line 304
    move-result-object v0

    .line 305
    const/4 v3, 0x6

    .line 306
    invoke-static {v0, v1, v3}, Lv74;->f(Ls21;Lzi2;I)V

    .line 307
    .line 308
    .line 309
    goto :goto_5

    .line 310
    :cond_d
    invoke-virtual {v1}, Lzi2;->b0()V

    .line 311
    .line 312
    .line 313
    :goto_5
    return-object v2

    .line 314
    nop

    .line 315
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
