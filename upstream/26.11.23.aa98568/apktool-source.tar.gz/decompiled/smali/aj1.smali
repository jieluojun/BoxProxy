.class public interface abstract Laj1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public abstract m(Laj1;)Laj1;
.end method

.method public abstract q(Lzi1;)Lyi1;
.end method

.method public abstract v(Lai2;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public abstract z(Lzi1;)Laj1;
.end method
