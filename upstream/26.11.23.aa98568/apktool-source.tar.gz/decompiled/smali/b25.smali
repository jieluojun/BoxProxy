.class public final Lb25;
.super Lcp1;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lu51;
.implements Lqi3;
.implements La25;
.implements Lgk4;


# instance fields
.field public A:Lzy6;

.field public final B:F

.field public C:Z

.field public D:F

.field public E:F

.field public F:F

.field public G:F

.field public H:F

.field public I:F

.field public x:Z

.field public y:Lwh2;

.field public final z:Lfy6;


# direct methods
.method public constructor <init>(ZLwh2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcp1;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lb25;->x:Z

    .line 5
    .line 6
    iput-object p2, p0, Lb25;->y:Lwh2;

    .line 7
    .line 8
    new-instance p1, Lfy6;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lb25;->z:Lfy6;

    .line 14
    .line 15
    const/high16 p1, 0x3f800000    # 1.0f

    .line 16
    .line 17
    iput p1, p0, Lb25;->B:F

    .line 18
    .line 19
    new-instance p1, Le4;

    .line 20
    .line 21
    const/4 p2, 0x5

    .line 22
    invoke-direct {p1, p0, p2}, Le4;-><init>(Ljava/lang/Object;B)V

    .line 23
    .line 24
    .line 25
    invoke-static {p1}, Lv57;->a(Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)La67;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    invoke-virtual {p0, p1}, Lcp1;->G1(Lap1;)V

    .line 30
    .line 31
    .line 32
    return-void
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final J1(F)V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    cmpg-float v1, p1, v0

    .line 3
    .line 4
    if-nez v1, :cond_0

    .line 5
    .line 6
    return-void

    .line 7
    :cond_0
    iget v1, p0, Lb25;->I:F

    .line 8
    .line 9
    cmpg-float v2, v1, v0

    .line 10
    .line 11
    if-nez v2, :cond_1

    .line 12
    .line 13
    return-void

    .line 14
    :cond_1
    iget v2, p0, Lb25;->H:F

    .line 15
    .line 16
    add-float/2addr v2, p1

    .line 17
    iput v2, p0, Lb25;->H:F

    .line 18
    .line 19
    neg-float p1, v1

    .line 20
    invoke-static {v2, p1, v1}, Lej3;->u(FFF)F

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    iput p1, p0, Lb25;->H:F

    .line 25
    .line 26
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 27
    .line 28
    .line 29
    move-result p1

    .line 30
    iget v1, p0, Lb25;->I:F

    .line 31
    .line 32
    div-float/2addr p1, v1

    .line 33
    const/high16 v1, 0x3f800000    # 1.0f

    .line 34
    .line 35
    invoke-static {p1, v1}, Ljava/lang/Math;->min(FF)F

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    iget v2, p0, Lb25;->I:F

    .line 40
    .line 41
    invoke-static {p1, v1}, Ljava/lang/Math;->min(FF)F

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    float-to-double v0, p1

    .line 50
    const-wide/high16 v3, 0x4000000000000000L    # 2.0

    .line 51
    .line 52
    invoke-static {v0, v1, v3, v4}, Ljava/lang/Math;->pow(DD)D

    .line 53
    .line 54
    .line 55
    move-result-wide v3

    .line 56
    sub-double v3, v0, v3

    .line 57
    .line 58
    const-wide/high16 v5, 0x4008000000000000L    # 3.0

    .line 59
    .line 60
    invoke-static {v0, v1, v5, v6}, Ljava/lang/Math;->pow(DD)D

    .line 61
    .line 62
    .line 63
    move-result-wide v0

    .line 64
    div-double/2addr v0, v5

    .line 65
    add-double/2addr v0, v3

    .line 66
    float-to-double v2, v2

    .line 67
    mul-double/2addr v0, v2

    .line 68
    double-to-float p1, v0

    .line 69
    iget v0, p0, Lb25;->H:F

    .line 70
    .line 71
    invoke-static {v0}, Ljava/lang/Math;->signum(F)F

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    mul-float/2addr v0, p1

    .line 76
    invoke-virtual {p0, v0}, Lb25;->M1(F)V

    .line 77
    .line 78
    .line 79
    return-void
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public final K0(JJI)J
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v6, p5

    .line 4
    .line 5
    iget-boolean v1, v0, Lab4;->u:Z

    .line 6
    .line 7
    const-wide/16 v7, 0x0

    .line 8
    .line 9
    if-eqz v1, :cond_c

    .line 10
    .line 11
    iget v1, v0, Lb25;->G:F

    .line 12
    .line 13
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    iget v2, v0, Lb25;->B:F

    .line 18
    .line 19
    cmpl-float v1, v1, v2

    .line 20
    .line 21
    const/4 v9, 0x1

    .line 22
    if-lez v1, :cond_0

    .line 23
    .line 24
    move v1, v9

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v1, 0x0

    .line 27
    :goto_0
    invoke-virtual {v0}, Lb25;->K1()Lj15;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-virtual {v2}, Lj15;->a()Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-eq v2, v1, :cond_1

    .line 36
    .line 37
    invoke-virtual {v0}, Lb25;->K1()Lj15;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    invoke-virtual {v2, v1}, Lj15;->b(Z)V

    .line 42
    .line 43
    .line 44
    :cond_1
    iget-boolean v2, v0, Lb25;->x:Z

    .line 45
    .line 46
    const/16 v10, 0x20

    .line 47
    .line 48
    const-wide v11, 0xffffffffL

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    if-eqz v2, :cond_2

    .line 54
    .line 55
    and-long v2, p3, v11

    .line 56
    .line 57
    :goto_1
    long-to-int v2, v2

    .line 58
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    move v13, v2

    .line 63
    goto :goto_2

    .line 64
    :cond_2
    shr-long v2, p3, v10

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :goto_2
    iget-boolean v2, v0, Lb25;->x:Z

    .line 68
    .line 69
    if-eqz v2, :cond_3

    .line 70
    .line 71
    and-long v2, p1, v11

    .line 72
    .line 73
    :goto_3
    long-to-int v2, v2

    .line 74
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    move v14, v2

    .line 79
    goto :goto_4

    .line 80
    :cond_3
    shr-long v2, p1, v10

    .line 81
    .line 82
    goto :goto_3

    .line 83
    :goto_4
    const/4 v15, 0x0

    .line 84
    cmpg-float v16, v13, v15

    .line 85
    .line 86
    if-nez v16, :cond_4

    .line 87
    .line 88
    if-eqz v1, :cond_c

    .line 89
    .line 90
    :cond_4
    iget-boolean v1, v0, Lb25;->x:Z

    .line 91
    .line 92
    if-eqz v1, :cond_6

    .line 93
    .line 94
    if-eqz v16, :cond_6

    .line 95
    .line 96
    sget-object v1, Lls5;->a:Lux1;

    .line 97
    .line 98
    invoke-static {v0, v1}, Lgu;->A(Lu51;Lzh5;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    check-cast v1, Lys5;

    .line 103
    .line 104
    if-eqz v1, :cond_5

    .line 105
    .line 106
    and-long v2, p3, v11

    .line 107
    .line 108
    long-to-int v2, v2

    .line 109
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    if-ne v6, v9, :cond_5

    .line 114
    .line 115
    iget-boolean v1, v1, Lys5;->m:Z

    .line 116
    .line 117
    if-eqz v1, :cond_5

    .line 118
    .line 119
    cmpl-float v1, v2, v15

    .line 120
    .line 121
    if-gtz v1, :cond_b

    .line 122
    .line 123
    :cond_5
    sget-object v1, Lu70;->a:Lux1;

    .line 124
    .line 125
    invoke-static {v0, v1}, Lgu;->A(Lu51;Lzh5;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v1

    .line 129
    check-cast v1, Ly60;

    .line 130
    .line 131
    if-eqz v1, :cond_6

    .line 132
    .line 133
    move-wide/from16 v2, p1

    .line 134
    .line 135
    move-wide/from16 v4, p3

    .line 136
    .line 137
    invoke-virtual/range {v1 .. v6}, Ly60;->a(JJI)Z

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    if-eq v1, v9, :cond_b

    .line 142
    .line 143
    :cond_6
    invoke-virtual {v0}, Lb25;->N1()Z

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    if-nez v1, :cond_b

    .line 148
    .line 149
    if-ne v6, v9, :cond_b

    .line 150
    .line 151
    iget-boolean v1, v0, Lb25;->C:Z

    .line 152
    .line 153
    if-eqz v1, :cond_b

    .line 154
    .line 155
    if-nez v16, :cond_7

    .line 156
    .line 157
    cmpg-float v1, v14, v15

    .line 158
    .line 159
    if-eqz v1, :cond_c

    .line 160
    .line 161
    :cond_7
    iget-object v1, v0, Lb25;->A:Lzy6;

    .line 162
    .line 163
    if-eqz v1, :cond_8

    .line 164
    .line 165
    invoke-virtual {v1}, Lfd3;->b()Z

    .line 166
    .line 167
    .line 168
    move-result v1

    .line 169
    if-ne v1, v9, :cond_8

    .line 170
    .line 171
    invoke-virtual {v0}, Lb25;->P1()V

    .line 172
    .line 173
    .line 174
    :cond_8
    iget-object v1, v0, Lb25;->A:Lzy6;

    .line 175
    .line 176
    if-eqz v1, :cond_9

    .line 177
    .line 178
    const/4 v2, 0x0

    .line 179
    invoke-virtual {v1, v2}, Lfd3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 180
    .line 181
    .line 182
    :cond_9
    invoke-virtual {v0, v14}, Lb25;->Q1(F)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v0, v13}, Lb25;->J1(F)V

    .line 186
    .line 187
    .line 188
    iget-boolean v0, v0, Lb25;->x:Z

    .line 189
    .line 190
    if-eqz v0, :cond_a

    .line 191
    .line 192
    and-long v0, p3, v11

    .line 193
    .line 194
    long-to-int v0, v0

    .line 195
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 200
    .line 201
    .line 202
    move-result v0

    .line 203
    int-to-long v0, v0

    .line 204
    and-long/2addr v0, v11

    .line 205
    return-wide v0

    .line 206
    :cond_a
    shr-long v0, p3, v10

    .line 207
    .line 208
    long-to-int v0, v0

    .line 209
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    int-to-long v0, v0

    .line 218
    shl-long/2addr v0, v10

    .line 219
    return-wide v0

    .line 220
    :cond_b
    iget-object v1, v0, Lb25;->A:Lzy6;

    .line 221
    .line 222
    if-eqz v1, :cond_d

    .line 223
    .line 224
    invoke-virtual {v1}, Lfd3;->b()Z

    .line 225
    .line 226
    .line 227
    move-result v1

    .line 228
    if-ne v1, v9, :cond_d

    .line 229
    .line 230
    :cond_c
    return-wide v7

    .line 231
    :cond_d
    iget-boolean v1, v0, Lb25;->x:Z

    .line 232
    .line 233
    if-eqz v1, :cond_e

    .line 234
    .line 235
    and-long v1, p1, v11

    .line 236
    .line 237
    :goto_5
    long-to-int v1, v1

    .line 238
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 239
    .line 240
    .line 241
    move-result v1

    .line 242
    goto :goto_6

    .line 243
    :cond_e
    shr-long v1, p1, v10

    .line 244
    .line 245
    goto :goto_5

    .line 246
    :goto_6
    invoke-virtual {v0, v1}, Lb25;->Q1(F)V

    .line 247
    .line 248
    .line 249
    return-wide v7
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
.end method

.method public final K1()Lj15;
    .locals 1

    .line 1
    sget-object v0, Ly15;->a:Lux1;

    .line 2
    .line 3
    invoke-static {p0, v0}, Lgu;->A(Lu51;Lzh5;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lj15;

    .line 8
    .line 9
    return-object p0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final L1()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Lb25;->M1(F)V

    .line 3
    .line 4
    .line 5
    iget v1, p0, Lb25;->E:F

    .line 6
    .line 7
    cmpg-float v1, v1, v0

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    iput v0, p0, Lb25;->F:F

    .line 12
    .line 13
    iput v0, p0, Lb25;->E:F

    .line 14
    .line 15
    iget-object v1, p0, Lb25;->y:Lwh2;

    .line 16
    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    invoke-interface {v1, v2}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    :cond_0
    iput v0, p0, Lb25;->H:F

    .line 27
    .line 28
    iget-boolean v0, p0, Lab4;->u:Z

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    const/4 v0, 0x0

    .line 37
    invoke-virtual {p0, v0}, Lj15;->b(Z)V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method

.method public final M1(F)V
    .locals 2

    .line 1
    iget v0, p0, Lb25;->G:F

    .line 2
    .line 3
    cmpg-float v0, v0, p1

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    iput p1, p0, Lb25;->G:F

    .line 8
    .line 9
    float-to-double v0, p1

    .line 10
    invoke-static {v0, v1}, Ljava/lang/Math;->rint(D)D

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    double-to-float v0, v0

    .line 15
    iget v1, p0, Lb25;->F:F

    .line 16
    .line 17
    cmpg-float v1, v0, v1

    .line 18
    .line 19
    if-eqz v1, :cond_0

    .line 20
    .line 21
    iput v0, p0, Lb25;->F:F

    .line 22
    .line 23
    iput p1, p0, Lb25;->E:F

    .line 24
    .line 25
    iget-object v1, p0, Lb25;->y:Lwh2;

    .line 26
    .line 27
    if-eqz v1, :cond_0

    .line 28
    .line 29
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-interface {v1, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    :cond_0
    iget p1, p0, Lb25;->D:F

    .line 37
    .line 38
    cmpg-float p1, v0, p1

    .line 39
    .line 40
    if-eqz p1, :cond_1

    .line 41
    .line 42
    iput v0, p0, Lb25;->D:F

    .line 43
    .line 44
    iget-boolean p1, p0, Lab4;->u:Z

    .line 45
    .line 46
    if-eqz p1, :cond_1

    .line 47
    .line 48
    invoke-static {p0}, Lti3;->D(Lqi3;)V

    .line 49
    .line 50
    .line 51
    :cond_1
    return-void
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public final N0(JLxd1;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-boolean p3, p0, Lab4;->u:Z

    .line 2
    .line 3
    const-wide/16 v0, 0x0

    .line 4
    .line 5
    if-nez p3, :cond_0

    .line 6
    .line 7
    new-instance p0, Lbw7;

    .line 8
    .line 9
    invoke-direct {p0, v0, v1}, Lbw7;-><init>(J)V

    .line 10
    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_0
    iget p3, p0, Lb25;->G:F

    .line 14
    .line 15
    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    .line 16
    .line 17
    .line 18
    move-result p3

    .line 19
    iget v2, p0, Lb25;->B:F

    .line 20
    .line 21
    cmpl-float p3, p3, v2

    .line 22
    .line 23
    if-lez p3, :cond_1

    .line 24
    .line 25
    const/4 p3, 0x1

    .line 26
    goto :goto_0

    .line 27
    :cond_1
    const/4 p3, 0x0

    .line 28
    :goto_0
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    invoke-virtual {v3}, Lj15;->a()Z

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    if-eq v3, p3, :cond_2

    .line 37
    .line 38
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-virtual {v3, p3}, Lj15;->b(Z)V

    .line 43
    .line 44
    .line 45
    :cond_2
    invoke-virtual {p0}, Lb25;->N1()Z

    .line 46
    .line 47
    .line 48
    move-result p3

    .line 49
    if-eqz p3, :cond_3

    .line 50
    .line 51
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 52
    .line 53
    .line 54
    move-result-object p3

    .line 55
    invoke-virtual {p3}, Lj15;->a()Z

    .line 56
    .line 57
    .line 58
    move-result p3

    .line 59
    if-nez p3, :cond_3

    .line 60
    .line 61
    new-instance p0, Lbw7;

    .line 62
    .line 63
    invoke-direct {p0, v0, v1}, Lbw7;-><init>(J)V

    .line 64
    .line 65
    .line 66
    return-object p0

    .line 67
    :cond_3
    iget-object p3, p0, Lb25;->A:Lzy6;

    .line 68
    .line 69
    if-eqz p3, :cond_4

    .line 70
    .line 71
    const/4 v3, 0x0

    .line 72
    invoke-virtual {p3, v3}, Lfd3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 73
    .line 74
    .line 75
    :cond_4
    iget-boolean p3, p0, Lb25;->x:Z

    .line 76
    .line 77
    if-eqz p3, :cond_5

    .line 78
    .line 79
    invoke-static {p1, p2}, Lbw7;->c(J)F

    .line 80
    .line 81
    .line 82
    move-result p3

    .line 83
    goto :goto_1

    .line 84
    :cond_5
    invoke-static {p1, p2}, Lbw7;->b(J)F

    .line 85
    .line 86
    .line 87
    move-result p3

    .line 88
    :goto_1
    iget v3, p0, Lb25;->G:F

    .line 89
    .line 90
    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    cmpl-float v2, v3, v2

    .line 95
    .line 96
    if-lez v2, :cond_9

    .line 97
    .line 98
    invoke-static {p3}, Ljava/lang/Math;->signum(F)F

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    iget v1, p0, Lb25;->G:F

    .line 103
    .line 104
    invoke-static {v1}, Ljava/lang/Math;->signum(F)F

    .line 105
    .line 106
    .line 107
    move-result v1

    .line 108
    cmpg-float v0, v0, v1

    .line 109
    .line 110
    const/4 v1, 0x0

    .line 111
    if-nez v0, :cond_7

    .line 112
    .line 113
    invoke-virtual {p0, p3}, Lb25;->O1(F)V

    .line 114
    .line 115
    .line 116
    iget-boolean p0, p0, Lb25;->x:Z

    .line 117
    .line 118
    if-eqz p0, :cond_6

    .line 119
    .line 120
    invoke-static {p1, p2}, Lbw7;->c(J)F

    .line 121
    .line 122
    .line 123
    move-result p0

    .line 124
    invoke-static {v1, p0}, Ld77;->d(FF)J

    .line 125
    .line 126
    .line 127
    move-result-wide p0

    .line 128
    goto :goto_2

    .line 129
    :cond_6
    invoke-static {p1, p2}, Lbw7;->b(J)F

    .line 130
    .line 131
    .line 132
    move-result p0

    .line 133
    invoke-static {p0, v1}, Ld77;->d(FF)J

    .line 134
    .line 135
    .line 136
    move-result-wide p0

    .line 137
    :goto_2
    new-instance p2, Lbw7;

    .line 138
    .line 139
    invoke-direct {p2, p0, p1}, Lbw7;-><init>(J)V

    .line 140
    .line 141
    .line 142
    return-object p2

    .line 143
    :cond_7
    invoke-virtual {p0, p3}, Lb25;->O1(F)V

    .line 144
    .line 145
    .line 146
    iget-boolean p0, p0, Lb25;->x:Z

    .line 147
    .line 148
    const p3, 0x4008887b

    .line 149
    .line 150
    .line 151
    if-eqz p0, :cond_8

    .line 152
    .line 153
    invoke-static {p1, p2}, Lbw7;->c(J)F

    .line 154
    .line 155
    .line 156
    move-result p0

    .line 157
    div-float/2addr p0, p3

    .line 158
    invoke-static {v1, p0}, Ld77;->d(FF)J

    .line 159
    .line 160
    .line 161
    move-result-wide p0

    .line 162
    goto :goto_3

    .line 163
    :cond_8
    invoke-static {p1, p2}, Lbw7;->b(J)F

    .line 164
    .line 165
    .line 166
    move-result p0

    .line 167
    div-float/2addr p0, p3

    .line 168
    invoke-static {p0, v1}, Ld77;->d(FF)J

    .line 169
    .line 170
    .line 171
    move-result-wide p0

    .line 172
    :goto_3
    new-instance p2, Lbw7;

    .line 173
    .line 174
    invoke-direct {p2, p0, p1}, Lbw7;-><init>(J)V

    .line 175
    .line 176
    .line 177
    return-object p2

    .line 178
    :cond_9
    new-instance p0, Lbw7;

    .line 179
    .line 180
    invoke-direct {p0, v0, v1}, Lbw7;-><init>(J)V

    .line 181
    .line 182
    .line 183
    return-object p0
    .line 184
    .line 185
    .line 186
.end method

.method public final N1()Z
    .locals 2

    .line 1
    sget-object v0, Lls5;->a:Lux1;

    .line 2
    .line 3
    invoke-static {p0, v0}, Lgu;->A(Lu51;Lzh5;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Lys5;

    .line 8
    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    invoke-static {p0, v0}, Lgu;->A(Lu51;Lzh5;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Lys5;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v0}, Lys5;->b()Lyw5;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 v0, 0x0

    .line 25
    :goto_0
    sget-object v1, Ltw5;->a:Ltw5;

    .line 26
    .line 27
    invoke-static {v0, v1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    iget-boolean p0, p0, Lb25;->x:Z

    .line 34
    .line 35
    if-eqz p0, :cond_1

    .line 36
    .line 37
    const/4 p0, 0x1

    .line 38
    return p0

    .line 39
    :cond_1
    const/4 p0, 0x0

    .line 40
    return p0
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method

.method public final O1(F)V
    .locals 4

    .line 1
    iget v0, p0, Lb25;->G:F

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lb25;->B:F

    .line 8
    .line 9
    cmpg-float v0, v0, v1

    .line 10
    .line 11
    if-gtz v0, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    cmpg-float v0, p1, v0

    .line 15
    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {p0}, Lb25;->L1()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    iget-object v0, p0, Lb25;->A:Lzy6;

    .line 23
    .line 24
    const/4 v1, 0x0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Lfd3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 28
    .line 29
    .line 30
    :cond_1
    invoke-virtual {p0}, Lab4;->u1()Ljj1;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    new-instance v2, Ll41;

    .line 35
    .line 36
    const/4 v3, 0x2

    .line 37
    invoke-direct {v2, p0, p1, v1, v3}, Ll41;-><init>(Ljava/lang/Object;FLxd1;B)V

    .line 38
    .line 39
    .line 40
    const/4 p1, 0x3

    .line 41
    invoke-static {v0, v1, v1, v2, p1}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    iput-object p1, p0, Lb25;->A:Lzy6;

    .line 46
    .line 47
    return-void
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public final P1()V
    .locals 3

    .line 1
    iget v0, p0, Lb25;->G:F

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Math;->signum(F)F

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lb25;->G:F

    .line 8
    .line 9
    iget v2, p0, Lb25;->I:F

    .line 10
    .line 11
    invoke-static {v1, v2}, Lej3;->S(FF)F

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    mul-float/2addr v1, v0

    .line 16
    iput v1, p0, Lb25;->H:F

    .line 17
    .line 18
    return-void
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final Q0(JJLxd1;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-boolean p1, p0, Lab4;->u:Z

    .line 2
    .line 3
    const-wide/16 v0, 0x0

    .line 4
    .line 5
    if-nez p1, :cond_0

    .line 6
    .line 7
    new-instance p0, Lbw7;

    .line 8
    .line 9
    invoke-direct {p0, v0, v1}, Lbw7;-><init>(J)V

    .line 10
    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_0
    iget p1, p0, Lb25;->G:F

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    iget p2, p0, Lb25;->B:F

    .line 20
    .line 21
    cmpl-float p1, p1, p2

    .line 22
    .line 23
    if-lez p1, :cond_1

    .line 24
    .line 25
    const/4 p1, 0x1

    .line 26
    goto :goto_0

    .line 27
    :cond_1
    const/4 p1, 0x0

    .line 28
    :goto_0
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 29
    .line 30
    .line 31
    move-result-object p2

    .line 32
    invoke-virtual {p2}, Lj15;->a()Z

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    if-eq p2, p1, :cond_2

    .line 37
    .line 38
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    invoke-virtual {p2, p1}, Lj15;->b(Z)V

    .line 43
    .line 44
    .line 45
    :cond_2
    invoke-virtual {p0}, Lb25;->N1()Z

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    if-eqz p1, :cond_3

    .line 50
    .line 51
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-virtual {p1}, Lj15;->a()Z

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    if-nez p1, :cond_3

    .line 60
    .line 61
    new-instance p0, Lbw7;

    .line 62
    .line 63
    invoke-direct {p0, v0, v1}, Lbw7;-><init>(J)V

    .line 64
    .line 65
    .line 66
    return-object p0

    .line 67
    :cond_3
    iget-object p1, p0, Lb25;->A:Lzy6;

    .line 68
    .line 69
    if-eqz p1, :cond_4

    .line 70
    .line 71
    const/4 p2, 0x0

    .line 72
    invoke-virtual {p1, p2}, Lfd3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 73
    .line 74
    .line 75
    :cond_4
    iget-boolean p1, p0, Lb25;->x:Z

    .line 76
    .line 77
    if-eqz p1, :cond_5

    .line 78
    .line 79
    invoke-static {p3, p4}, Lbw7;->c(J)F

    .line 80
    .line 81
    .line 82
    move-result p1

    .line 83
    goto :goto_1

    .line 84
    :cond_5
    invoke-static {p3, p4}, Lbw7;->b(J)F

    .line 85
    .line 86
    .line 87
    move-result p1

    .line 88
    :goto_1
    const p2, 0x3fc44428

    .line 89
    .line 90
    .line 91
    div-float/2addr p1, p2

    .line 92
    invoke-virtual {p0, p1}, Lb25;->O1(F)V

    .line 93
    .line 94
    .line 95
    iget-boolean p0, p0, Lb25;->x:Z

    .line 96
    .line 97
    const/4 p2, 0x0

    .line 98
    if-eqz p0, :cond_6

    .line 99
    .line 100
    invoke-static {p2, p1}, Ld77;->d(FF)J

    .line 101
    .line 102
    .line 103
    move-result-wide p0

    .line 104
    goto :goto_2

    .line 105
    :cond_6
    invoke-static {p1, p2}, Ld77;->d(FF)J

    .line 106
    .line 107
    .line 108
    move-result-wide p0

    .line 109
    :goto_2
    new-instance p2, Lbw7;

    .line 110
    .line 111
    invoke-direct {p2, p0, p1}, Lbw7;-><init>(J)V

    .line 112
    .line 113
    .line 114
    return-object p2
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
.end method

.method public final Q1(F)V
    .locals 2

    .line 1
    iget v0, p0, Lb25;->G:F

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lb25;->B:F

    .line 8
    .line 9
    cmpg-float v0, v0, v1

    .line 10
    .line 11
    if-lez v0, :cond_3

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    cmpg-float v1, p1, v0

    .line 15
    .line 16
    if-nez v1, :cond_0

    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    iget v1, p0, Lb25;->H:F

    .line 20
    .line 21
    cmpg-float v0, v1, v0

    .line 22
    .line 23
    if-nez v0, :cond_1

    .line 24
    .line 25
    invoke-virtual {p0}, Lb25;->P1()V

    .line 26
    .line 27
    .line 28
    :cond_1
    invoke-static {p1}, Ljava/lang/Math;->signum(F)F

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    iget v1, p0, Lb25;->H:F

    .line 33
    .line 34
    invoke-static {v1}, Ljava/lang/Math;->signum(F)F

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    cmpg-float v0, v0, v1

    .line 39
    .line 40
    if-nez v0, :cond_3

    .line 41
    .line 42
    iget v0, p0, Lb25;->H:F

    .line 43
    .line 44
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    cmpg-float v0, v0, v1

    .line 53
    .line 54
    if-gtz v0, :cond_2

    .line 55
    .line 56
    invoke-virtual {p0}, Lb25;->L1()V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_2
    neg-float p1, p1

    .line 61
    invoke-virtual {p0, p1}, Lb25;->J1(F)V

    .line 62
    .line 63
    .line 64
    :cond_3
    return-void
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method

.method public final R1()V
    .locals 4

    .line 1
    sget-object v0, Lz51;->p:La61;

    .line 2
    .line 3
    invoke-static {p0, v0}, Lgu;->A(Lu51;Lzh5;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lw18;

    .line 8
    .line 9
    check-cast v0, Lrn3;

    .line 10
    .line 11
    invoke-virtual {v0}, Lrn3;->b()J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    iget-boolean v2, p0, Lb25;->x:Z

    .line 16
    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    const-wide v2, 0xffffffffL

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    and-long/2addr v0, v2

    .line 25
    :goto_0
    long-to-int v0, v0

    .line 26
    goto :goto_1

    .line 27
    :cond_0
    const/16 v2, 0x20

    .line 28
    .line 29
    shr-long/2addr v0, v2

    .line 30
    goto :goto_0

    .line 31
    :goto_1
    int-to-float v0, v0

    .line 32
    iput v0, p0, Lb25;->I:F

    .line 33
    .line 34
    return-void
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method

.method public final d1(IJ)J
    .locals 5

    .line 1
    iget-boolean v0, p0, Lab4;->u:Z

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    iget v0, p0, Lb25;->G:F

    .line 6
    .line 7
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iget v1, p0, Lb25;->B:F

    .line 12
    .line 13
    cmpl-float v0, v0, v1

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    if-lez v0, :cond_0

    .line 17
    .line 18
    move v0, v2

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v0, 0x0

    .line 21
    :goto_0
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    invoke-virtual {v3}, Lj15;->a()Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-eq v3, v0, :cond_1

    .line 30
    .line 31
    invoke-virtual {p0}, Lb25;->K1()Lj15;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    invoke-virtual {v3, v0}, Lj15;->b(Z)V

    .line 36
    .line 37
    .line 38
    :cond_1
    invoke-virtual {p0}, Lb25;->N1()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_8

    .line 43
    .line 44
    if-ne p1, v2, :cond_8

    .line 45
    .line 46
    iget-boolean p1, p0, Lb25;->C:Z

    .line 47
    .line 48
    if-eqz p1, :cond_8

    .line 49
    .line 50
    iget-boolean p1, p0, Lb25;->x:Z

    .line 51
    .line 52
    const/16 v0, 0x20

    .line 53
    .line 54
    const-wide v3, 0xffffffffL

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    if-eqz p1, :cond_2

    .line 60
    .line 61
    and-long/2addr p2, v3

    .line 62
    :goto_1
    long-to-int p1, p2

    .line 63
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    goto :goto_2

    .line 68
    :cond_2
    shr-long/2addr p2, v0

    .line 69
    goto :goto_1

    .line 70
    :goto_2
    const/4 p2, 0x0

    .line 71
    cmpg-float p2, p1, p2

    .line 72
    .line 73
    if-eqz p2, :cond_8

    .line 74
    .line 75
    iget-object p2, p0, Lb25;->A:Lzy6;

    .line 76
    .line 77
    if-eqz p2, :cond_3

    .line 78
    .line 79
    invoke-virtual {p2}, Lfd3;->b()Z

    .line 80
    .line 81
    .line 82
    move-result p2

    .line 83
    if-ne p2, v2, :cond_3

    .line 84
    .line 85
    invoke-virtual {p0}, Lb25;->P1()V

    .line 86
    .line 87
    .line 88
    :cond_3
    iget-object p2, p0, Lb25;->A:Lzy6;

    .line 89
    .line 90
    if-eqz p2, :cond_4

    .line 91
    .line 92
    const/4 p3, 0x0

    .line 93
    invoke-virtual {p2, p3}, Lfd3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 94
    .line 95
    .line 96
    :cond_4
    iget p2, p0, Lb25;->G:F

    .line 97
    .line 98
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    .line 99
    .line 100
    .line 101
    move-result p2

    .line 102
    cmpg-float p2, p2, v1

    .line 103
    .line 104
    if-lez p2, :cond_8

    .line 105
    .line 106
    invoke-static {p1}, Ljava/lang/Math;->signum(F)F

    .line 107
    .line 108
    .line 109
    move-result p2

    .line 110
    iget p3, p0, Lb25;->H:F

    .line 111
    .line 112
    invoke-static {p3}, Ljava/lang/Math;->signum(F)F

    .line 113
    .line 114
    .line 115
    move-result p3

    .line 116
    cmpg-float p2, p2, p3

    .line 117
    .line 118
    if-eqz p2, :cond_8

    .line 119
    .line 120
    iget p2, p0, Lb25;->H:F

    .line 121
    .line 122
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    .line 123
    .line 124
    .line 125
    move-result p2

    .line 126
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 127
    .line 128
    .line 129
    move-result p3

    .line 130
    cmpg-float p2, p2, p3

    .line 131
    .line 132
    if-gtz p2, :cond_5

    .line 133
    .line 134
    iget p2, p0, Lb25;->H:F

    .line 135
    .line 136
    neg-float p2, p2

    .line 137
    goto :goto_3

    .line 138
    :cond_5
    move p2, p1

    .line 139
    :goto_3
    iget p3, p0, Lb25;->H:F

    .line 140
    .line 141
    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    .line 142
    .line 143
    .line 144
    move-result p3

    .line 145
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 146
    .line 147
    .line 148
    move-result p1

    .line 149
    cmpg-float p1, p3, p1

    .line 150
    .line 151
    if-gtz p1, :cond_6

    .line 152
    .line 153
    invoke-virtual {p0}, Lb25;->L1()V

    .line 154
    .line 155
    .line 156
    goto :goto_4

    .line 157
    :cond_6
    invoke-virtual {p0, p2}, Lb25;->J1(F)V

    .line 158
    .line 159
    .line 160
    :goto_4
    iget-boolean p0, p0, Lb25;->x:Z

    .line 161
    .line 162
    if-eqz p0, :cond_7

    .line 163
    .line 164
    invoke-static {p2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 165
    .line 166
    .line 167
    move-result p0

    .line 168
    int-to-long p0, p0

    .line 169
    and-long/2addr p0, v3

    .line 170
    return-wide p0

    .line 171
    :cond_7
    invoke-static {p2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 172
    .line 173
    .line 174
    move-result p0

    .line 175
    int-to-long p0, p0

    .line 176
    shl-long/2addr p0, v0

    .line 177
    return-wide p0

    .line 178
    :cond_8
    const-wide/16 p0, 0x0

    .line 179
    .line 180
    return-wide p0
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
.end method

.method public final h1()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lb25;->x:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object p0, p0, Lb25;->A:Lzy6;

    .line 6
    .line 7
    if-eqz p0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Lfd3;->b()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    const/4 v0, 0x1

    .line 14
    if-ne p0, v0, :cond_0

    .line 15
    .line 16
    return v0

    .line 17
    :cond_0
    const/4 p0, 0x0

    .line 18
    return p0
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final m(Ly14;Lp14;J)Lv14;
    .locals 2

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lb25;->R1()V

    .line 5
    .line 6
    .line 7
    invoke-interface {p2, p3, p4}, Lp14;->e(J)Lfb5;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    iget p3, p2, Lfb5;->h:I

    .line 12
    .line 13
    iget p4, p2, Lfb5;->i:I

    .line 14
    .line 15
    new-instance v0, Lvr2;

    .line 16
    .line 17
    const/16 v1, 0x1b

    .line 18
    .line 19
    invoke-direct {v0, p0, p2, v1}, Lvr2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 20
    .line 21
    .line 22
    sget-object p0, Lp22;->h:Lp22;

    .line 23
    .line 24
    invoke-interface {p1, p3, p4, p0, v0}, Ly14;->P0(IILjava/util/Map;Lwh2;)Lv14;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    return-object p0
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final o1()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lb25;->x:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object p0, p0, Lb25;->A:Lzy6;

    .line 6
    .line 7
    if-eqz p0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Lfd3;->b()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    const/4 v0, 0x1

    .line 14
    if-ne p0, v0, :cond_0

    .line 15
    .line 16
    return v0

    .line 17
    :cond_0
    const/4 p0, 0x0

    .line 18
    return p0
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final y1()V
    .locals 2

    .line 1
    invoke-virtual {p0}, Lb25;->R1()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lok4;->a:Lha4;

    .line 5
    .line 6
    new-instance v0, Lnk4;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-direct {v0, p0, v1}, Lnk4;-><init>(Lgk4;Ljk4;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, v0}, Lcp1;->G1(Lap1;)V

    .line 13
    .line 14
    .line 15
    return-void
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final z1()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lb25;->C:Z

    .line 3
    .line 4
    invoke-virtual {p0}, Lb25;->L1()V

    .line 5
    .line 6
    .line 7
    return-void
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
