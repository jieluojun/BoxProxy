.class public final synthetic Lb74;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:Lbb4;

.field public final synthetic i:F

.field public final synthetic j:Lo45;

.field public final synthetic k:Lxl0;

.field public final synthetic l:Lsf5;

.field public final synthetic m:Z

.field public final synthetic n:Llh2;

.field public final synthetic o:Llh2;

.field public final synthetic p:Z

.field public final synthetic q:J

.field public final synthetic r:Ls21;

.field public final synthetic s:I

.field public final synthetic t:S


# direct methods
.method public synthetic constructor <init>(Lbb4;FLo45;Lxl0;Lsf5;ZLlh2;Llh2;ZJLs21;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb74;->h:Lbb4;

    .line 5
    .line 6
    iput p2, p0, Lb74;->i:F

    .line 7
    .line 8
    iput-object p3, p0, Lb74;->j:Lo45;

    .line 9
    .line 10
    iput-object p4, p0, Lb74;->k:Lxl0;

    .line 11
    .line 12
    iput-object p5, p0, Lb74;->l:Lsf5;

    .line 13
    .line 14
    iput-boolean p6, p0, Lb74;->m:Z

    .line 15
    .line 16
    iput-object p7, p0, Lb74;->n:Llh2;

    .line 17
    .line 18
    iput-object p8, p0, Lb74;->o:Llh2;

    .line 19
    .line 20
    iput-boolean p9, p0, Lb74;->p:Z

    .line 21
    .line 22
    iput-wide p10, p0, Lb74;->q:J

    .line 23
    .line 24
    iput-object p12, p0, Lb74;->r:Ls21;

    .line 25
    .line 26
    iput p13, p0, Lb74;->s:I

    .line 27
    .line 28
    iput-short p14, p0, Lb74;->t:S

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v12, p1

    .line 4
    .line 5
    check-cast v12, Lzi2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget v1, v0, Lb74;->s:I

    .line 15
    .line 16
    or-int/lit8 v1, v1, 0x1

    .line 17
    .line 18
    invoke-static {v1}, Lyj3;->j0(I)I

    .line 19
    .line 20
    .line 21
    move-result v13

    .line 22
    iget-object v1, v0, Lb74;->h:Lbb4;

    .line 23
    .line 24
    move-object v2, v1

    .line 25
    iget v1, v0, Lb74;->i:F

    .line 26
    .line 27
    move-object v3, v2

    .line 28
    iget-object v2, v0, Lb74;->j:Lo45;

    .line 29
    .line 30
    move-object v4, v3

    .line 31
    iget-object v3, v0, Lb74;->k:Lxl0;

    .line 32
    .line 33
    move-object v5, v4

    .line 34
    iget-object v4, v0, Lb74;->l:Lsf5;

    .line 35
    .line 36
    move-object v6, v5

    .line 37
    iget-boolean v5, v0, Lb74;->m:Z

    .line 38
    .line 39
    move-object v7, v6

    .line 40
    iget-object v6, v0, Lb74;->n:Llh2;

    .line 41
    .line 42
    move-object v8, v7

    .line 43
    iget-object v7, v0, Lb74;->o:Llh2;

    .line 44
    .line 45
    move-object v9, v8

    .line 46
    iget-boolean v8, v0, Lb74;->p:Z

    .line 47
    .line 48
    move-object v11, v9

    .line 49
    iget-wide v9, v0, Lb74;->q:J

    .line 50
    .line 51
    move-object v14, v11

    .line 52
    iget-object v11, v0, Lb74;->r:Ls21;

    .line 53
    .line 54
    iget-short v0, v0, Lb74;->t:S

    .line 55
    .line 56
    move-object v15, v14

    .line 57
    move v14, v0

    .line 58
    move-object v0, v15

    .line 59
    invoke-static/range {v0 .. v14}, Lc74;->a(Lbb4;FLo45;Lxl0;Lsf5;ZLlh2;Llh2;ZJLs21;Lzi2;II)V

    .line 60
    .line 61
    .line 62
    sget-object v0, Lst7;->a:Lst7;

    .line 63
    .line 64
    return-object v0
.end method
