.class public final La74;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lm45;


# instance fields
.field public final synthetic a:Lm45;

.field public final synthetic b:Lm45;

.field public final synthetic c:F

.field public final synthetic d:F


# direct methods
.method public constructor <init>(Lm45;FF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La74;->b:Lm45;

    .line 5
    .line 6
    iput p2, p0, La74;->c:F

    .line 7
    .line 8
    iput p3, p0, La74;->d:F

    .line 9
    .line 10
    iput-object p1, p0, La74;->a:Lm45;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a(Lii3;)F
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, La74;->a:Lm45;

    .line 5
    .line 6
    invoke-interface {p0, p1}, Lm45;->a(Lii3;)F

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final b(Lii3;)F
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, La74;->a:Lm45;

    .line 5
    .line 6
    invoke-interface {p0, p1}, Lm45;->b(Lii3;)F

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final c()F
    .locals 1

    .line 1
    iget-object v0, p0, La74;->b:Lm45;

    .line 2
    .line 3
    invoke-interface {v0}, Lm45;->c()F

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget p0, p0, La74;->d:F

    .line 8
    .line 9
    add-float/2addr v0, p0

    .line 10
    const/4 p0, 0x0

    .line 11
    add-float/2addr v0, p0

    .line 12
    return v0
.end method

.method public final d()F
    .locals 1

    .line 1
    iget-object v0, p0, La74;->b:Lm45;

    .line 2
    .line 3
    invoke-interface {v0}, Lm45;->d()F

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget p0, p0, La74;->c:F

    .line 8
    .line 9
    add-float/2addr v0, p0

    .line 10
    const/4 p0, 0x0

    .line 11
    add-float/2addr v0, p0

    .line 12
    return v0
.end method
