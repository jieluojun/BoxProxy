.class public final synthetic Lap;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:Lai2;

.field public final synthetic i:Lbb4;

.field public final synthetic j:Ls21;

.field public final synthetic k:Ls21;

.field public final synthetic l:Lz30;

.field public final synthetic m:F

.field public final synthetic n:F

.field public final synthetic o:Lip3;

.field public final synthetic p:Lrm7;

.field public final synthetic q:Lw52;


# direct methods
.method public synthetic constructor <init>(Lai2;Lbb4;Ls21;Ls21;Lz30;FFLip3;Lrm7;Lw52;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lap;->h:Lai2;

    .line 5
    .line 6
    iput-object p2, p0, Lap;->i:Lbb4;

    .line 7
    .line 8
    iput-object p3, p0, Lap;->j:Ls21;

    .line 9
    .line 10
    iput-object p4, p0, Lap;->k:Ls21;

    .line 11
    .line 12
    iput-object p5, p0, Lap;->l:Lz30;

    .line 13
    .line 14
    iput p6, p0, Lap;->m:F

    .line 15
    .line 16
    iput p7, p0, Lap;->n:F

    .line 17
    .line 18
    iput-object p8, p0, Lap;->o:Lip3;

    .line 19
    .line 20
    iput-object p9, p0, Lap;->p:Lrm7;

    .line 21
    .line 22
    iput-object p10, p0, Lap;->q:Lw52;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    move-object v10, p1

    .line 2
    check-cast v10, Lzi2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/16 p1, 0x6c01

    .line 10
    .line 11
    invoke-static {p1}, Lyj3;->j0(I)I

    .line 12
    .line 13
    .line 14
    move-result v11

    .line 15
    iget-object v0, p0, Lap;->h:Lai2;

    .line 16
    .line 17
    iget-object v1, p0, Lap;->i:Lbb4;

    .line 18
    .line 19
    iget-object v2, p0, Lap;->j:Ls21;

    .line 20
    .line 21
    iget-object v3, p0, Lap;->k:Ls21;

    .line 22
    .line 23
    iget-object v4, p0, Lap;->l:Lz30;

    .line 24
    .line 25
    iget v5, p0, Lap;->m:F

    .line 26
    .line 27
    iget v6, p0, Lap;->n:F

    .line 28
    .line 29
    iget-object v7, p0, Lap;->o:Lip3;

    .line 30
    .line 31
    iget-object v8, p0, Lap;->p:Lrm7;

    .line 32
    .line 33
    iget-object v9, p0, Lap;->q:Lw52;

    .line 34
    .line 35
    invoke-static/range {v0 .. v11}, Lnp;->a(Lai2;Lbb4;Ls21;Ls21;Lz30;FFLip3;Lrm7;Lw52;Lzi2;I)V

    .line 36
    .line 37
    .line 38
    sget-object p0, Lst7;->a:Lst7;

    .line 39
    .line 40
    return-object p0
.end method
