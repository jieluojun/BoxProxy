.class public final synthetic Lad0;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic h:Lfb5;

.field public final synthetic i:Lp14;

.field public final synthetic j:Ly14;

.field public final synthetic k:I

.field public final synthetic l:I

.field public final synthetic m:Lbd0;


# direct methods
.method public synthetic constructor <init>(Lfb5;Lp14;Ly14;IILbd0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lad0;->h:Lfb5;

    .line 5
    .line 6
    iput-object p2, p0, Lad0;->i:Lp14;

    .line 7
    .line 8
    iput-object p3, p0, Lad0;->j:Ly14;

    .line 9
    .line 10
    iput p4, p0, Lad0;->k:I

    .line 11
    .line 12
    iput p5, p0, Lad0;->l:I

    .line 13
    .line 14
    iput-object p6, p0, Lad0;->m:Lbd0;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    move-object v0, p1

    .line 2
    check-cast v0, Leb5;

    .line 3
    .line 4
    iget-object p1, p0, Lad0;->j:Ly14;

    .line 5
    .line 6
    invoke-interface {p1}, Lgb3;->getLayoutDirection()Lii3;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    iget-object p1, p0, Lad0;->m:Lbd0;

    .line 11
    .line 12
    iget-object v6, p1, Lbd0;->a:Lb40;

    .line 13
    .line 14
    iget-object v1, p0, Lad0;->h:Lfb5;

    .line 15
    .line 16
    iget-object v2, p0, Lad0;->i:Lp14;

    .line 17
    .line 18
    iget v4, p0, Lad0;->k:I

    .line 19
    .line 20
    iget v5, p0, Lad0;->l:I

    .line 21
    .line 22
    invoke-static/range {v0 .. v6}, Lzc0;->d(Leb5;Lfb5;Lp14;Lii3;IILb40;)V

    .line 23
    .line 24
    .line 25
    sget-object p0, Lst7;->a:Lst7;

    .line 26
    .line 27
    return-object p0
.end method
