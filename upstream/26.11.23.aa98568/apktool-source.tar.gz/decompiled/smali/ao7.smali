.class public final Lao7;
.super Lyd1;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Lbo7;

.field public m:I


# direct methods
.method public constructor <init>(Lbo7;Lyd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lao7;->l:Lbo7;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lyd1;-><init>(Lxd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lao7;->k:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lao7;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lao7;->m:I

    .line 9
    .line 10
    iget-object p1, p0, Lao7;->l:Lbo7;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lbo7;->f(Lzn7;Lyd1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
