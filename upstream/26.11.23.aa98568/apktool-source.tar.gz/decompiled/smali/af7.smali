.class public final Laf7;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Lxp6;

.field public b:Ldc7;

.field public final c:Lz75;

.field public final d:Lz75;

.field public final e:Lz75;

.field public final f:Lz75;

.field public final g:Lwk5;

.field public final h:Lve4;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 102
    const-string v0, ""

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    .line 103
    invoke-static {v1, v1}, Ld77;->c(II)J

    move-result-wide v1

    .line 104
    invoke-direct {p0, v1, v2, v0}, Laf7;-><init>(JLjava/lang/String;)V

    return-void
.end method

.method public constructor <init>(JLjava/lang/String;)V
    .locals 6

    .line 105
    new-instance v4, Lxp6;

    .line 106
    new-instance v0, Ldt7;

    .line 107
    sget-object v1, Lo22;->h:Lo22;

    const/16 v2, 0x64

    invoke-direct {v0, v1, v1, v2}, Ldt7;-><init>(Ljava/util/List;Ljava/util/List;I)V

    const/4 v1, 0x0

    .line 108
    invoke-direct {v4, v1, v0}, Lxp6;-><init>(Lji7;Ldt7;)V

    const/4 v5, 0x0

    move-object v0, p0

    move-wide v2, p1

    move-object v1, p3

    .line 109
    invoke-direct/range {v0 .. v5}, Laf7;-><init>(Ljava/lang/String;JLxp6;Ldf7;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;JLxp6;Ldf7;)V
    .locals 13

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    move-object/from16 v0, p4

    .line 5
    .line 6
    iput-object v0, p0, Laf7;->a:Lxp6;

    .line 7
    .line 8
    new-instance v0, Ldc7;

    .line 9
    .line 10
    new-instance v1, Lec7;

    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    move-wide v11, p2

    .line 17
    invoke-static {v2, v11, v12}, Ld77;->g(IJ)J

    .line 18
    .line 19
    .line 20
    move-result-wide v3

    .line 21
    const/4 v8, 0x0

    .line 22
    const/16 v10, 0x3c

    .line 23
    .line 24
    const/4 v5, 0x0

    .line 25
    const/4 v6, 0x0

    .line 26
    const/4 v7, 0x0

    .line 27
    move-object v2, p1

    .line 28
    move-object/from16 v9, p5

    .line 29
    .line 30
    invoke-direct/range {v1 .. v10}, Lec7;-><init>(Ljava/lang/CharSequence;JLbh7;Ld75;Ljava/util/List;Ljava/util/List;Ldf7;I)V

    .line 31
    .line 32
    .line 33
    const/4 v2, 0x0

    .line 34
    const/16 v3, 0xe

    .line 35
    .line 36
    invoke-direct {v0, v1, v2, v2, v3}, Ldc7;-><init>(Lec7;Lar;Llo0;I)V

    .line 37
    .line 38
    .line 39
    iput-object v0, p0, Laf7;->b:Ldc7;

    .line 40
    .line 41
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 42
    .line 43
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    iput-object v1, p0, Laf7;->c:Lz75;

    .line 48
    .line 49
    new-instance v3, Lec7;

    .line 50
    .line 51
    const/4 v10, 0x0

    .line 52
    const/16 v12, 0x3c

    .line 53
    .line 54
    const/4 v9, 0x0

    .line 55
    move-object v4, p1

    .line 56
    move-wide v5, p2

    .line 57
    move-object/from16 v11, p5

    .line 58
    .line 59
    invoke-direct/range {v3 .. v12}, Lec7;-><init>(Ljava/lang/CharSequence;JLbh7;Ld75;Ljava/util/List;Ljava/util/List;Ldf7;I)V

    .line 60
    .line 61
    .line 62
    invoke-static {v3}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    iput-object p1, p0, Laf7;->d:Lz75;

    .line 67
    .line 68
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    iput-object p1, p0, Laf7;->e:Lz75;

    .line 73
    .line 74
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    iput-object p1, p0, Laf7;->f:Lz75;

    .line 79
    .line 80
    new-instance p1, Lwk5;

    .line 81
    .line 82
    const/16 v0, 0xb

    .line 83
    .line 84
    invoke-direct {p1, p0, v0}, Lwk5;-><init>(Ljava/lang/Object;B)V

    .line 85
    .line 86
    .line 87
    iput-object p1, p0, Laf7;->g:Lwk5;

    .line 88
    .line 89
    new-instance p1, Lve4;

    .line 90
    .line 91
    const/16 v0, 0x10

    .line 92
    .line 93
    new-array v0, v0, [Lye7;

    .line 94
    .line 95
    const/4 v1, 0x0

    .line 96
    invoke-direct {p1, v1, v0}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    iput-object p1, p0, Laf7;->h:Lve4;

    .line 100
    .line 101
    return-void
.end method


# virtual methods
.method public final a(Ldc7;)V
    .locals 8

    .line 1
    invoke-virtual {p1}, Ldc7;->a()Lar;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lar;->i:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Lve4;

    .line 8
    .line 9
    iget v0, v0, Lve4;->j:I

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    if-lez v0, :cond_0

    .line 13
    .line 14
    move v0, v1

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    :goto_0
    iget-wide v2, p1, Ldc7;->m:J

    .line 18
    .line 19
    iget-object v4, p0, Laf7;->b:Ldc7;

    .line 20
    .line 21
    iget-wide v4, v4, Ldc7;->m:J

    .line 22
    .line 23
    invoke-static {v2, v3, v4, v5}, Lbh7;->a(JJ)Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    xor-int/2addr v2, v1

    .line 28
    iget-object v3, p1, Ldc7;->j:Lci7;

    .line 29
    .line 30
    iget-object v4, p0, Laf7;->b:Ldc7;

    .line 31
    .line 32
    iget-object v4, v4, Ldc7;->j:Lci7;

    .line 33
    .line 34
    invoke-static {v3, v4}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    xor-int/2addr v3, v1

    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    invoke-virtual {p0}, Laf7;->c()Lec7;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    const/4 v4, 0x0

    .line 46
    const/16 v5, 0xf

    .line 47
    .line 48
    const-wide/16 v6, 0x0

    .line 49
    .line 50
    invoke-static {p1, v6, v7, v4, v5}, Ldc7;->h(Ldc7;JLbh7;I)Lec7;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    invoke-virtual {p1}, Ldc7;->a()Lar;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    sget-object v6, Lbd7;->i:Lbd7;

    .line 59
    .line 60
    invoke-virtual {p0, v1, v4, v5, v6}, Laf7;->d(Lec7;Lec7;Lar;Lbd7;)V

    .line 61
    .line 62
    .line 63
    :cond_1
    invoke-virtual {p0, p1, v0, v2, v3}, Laf7;->g(Ldc7;ZZZ)V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public final b(Ll42;ZLbd7;)V
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    invoke-virtual {v0}, Laf7;->c()Lec7;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    iget-object v4, v0, Laf7;->b:Ldc7;

    .line 12
    .line 13
    invoke-virtual {v4}, Ldc7;->a()Lar;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    iget-object v4, v4, Lar;->i:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v4, Lve4;

    .line 20
    .line 21
    iget v4, v4, Lve4;->j:I

    .line 22
    .line 23
    if-nez v4, :cond_1

    .line 24
    .line 25
    iget-wide v4, v3, Lec7;->k:J

    .line 26
    .line 27
    iget-object v6, v0, Laf7;->b:Ldc7;

    .line 28
    .line 29
    iget-wide v6, v6, Ldc7;->m:J

    .line 30
    .line 31
    invoke-static {v4, v5, v6, v7}, Lbh7;->a(JJ)Z

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    if-eqz v4, :cond_1

    .line 36
    .line 37
    iget-object v2, v3, Lec7;->l:Lbh7;

    .line 38
    .line 39
    iget-object v4, v0, Laf7;->b:Ldc7;

    .line 40
    .line 41
    iget-object v4, v4, Ldc7;->n:Lbh7;

    .line 42
    .line 43
    invoke-static {v2, v4}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_0

    .line 48
    .line 49
    iget-object v2, v3, Lec7;->m:Ld75;

    .line 50
    .line 51
    iget-object v4, v0, Laf7;->b:Ldc7;

    .line 52
    .line 53
    iget-object v4, v4, Ldc7;->p:Ld75;

    .line 54
    .line 55
    invoke-static {v2, v4}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    if-eqz v2, :cond_0

    .line 60
    .line 61
    iget-object v2, v3, Lec7;->h:Ljava/util/List;

    .line 62
    .line 63
    iget-object v4, v0, Laf7;->b:Ldc7;

    .line 64
    .line 65
    iget-object v4, v4, Ldc7;->o:Lve4;

    .line 66
    .line 67
    invoke-static {v2, v4}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    if-eqz v2, :cond_0

    .line 72
    .line 73
    return-void

    .line 74
    :cond_0
    invoke-virtual {v0}, Laf7;->c()Lec7;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    new-instance v4, Lec7;

    .line 79
    .line 80
    iget-object v5, v0, Laf7;->b:Ldc7;

    .line 81
    .line 82
    iget-object v5, v5, Ldc7;->i:Lq85;

    .line 83
    .line 84
    invoke-virtual {v5}, Lq85;->toString()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    iget-object v6, v0, Laf7;->b:Ldc7;

    .line 89
    .line 90
    iget-wide v7, v6, Ldc7;->m:J

    .line 91
    .line 92
    move-wide v9, v7

    .line 93
    iget-object v8, v6, Ldc7;->n:Lbh7;

    .line 94
    .line 95
    move-wide v10, v9

    .line 96
    iget-object v9, v6, Ldc7;->p:Ld75;

    .line 97
    .line 98
    iget-object v6, v6, Ldc7;->o:Lve4;

    .line 99
    .line 100
    invoke-static {v8, v6}, Lfa7;->d(Lbh7;Lve4;)Ljava/util/List;

    .line 101
    .line 102
    .line 103
    move-result-object v6

    .line 104
    iget-object v12, v3, Lec7;->i:Ldf7;

    .line 105
    .line 106
    const/16 v13, 0x20

    .line 107
    .line 108
    move-wide/from16 v17, v10

    .line 109
    .line 110
    move-object v10, v6

    .line 111
    move-wide/from16 v6, v17

    .line 112
    .line 113
    const/4 v11, 0x0

    .line 114
    invoke-direct/range {v4 .. v13}, Lec7;-><init>(Ljava/lang/CharSequence;JLbh7;Ld75;Ljava/util/List;Ljava/util/List;Ldf7;I)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v0, v2, v4, v1}, Laf7;->h(Lec7;Lec7;Z)V

    .line 118
    .line 119
    .line 120
    return-void

    .line 121
    :cond_1
    iget-object v4, v0, Laf7;->b:Ldc7;

    .line 122
    .line 123
    invoke-virtual {v4}, Ldc7;->a()Lar;

    .line 124
    .line 125
    .line 126
    move-result-object v4

    .line 127
    iget-object v4, v4, Lar;->i:Ljava/lang/Object;

    .line 128
    .line 129
    check-cast v4, Lve4;

    .line 130
    .line 131
    iget v4, v4, Lve4;->j:I

    .line 132
    .line 133
    const/4 v5, 0x0

    .line 134
    const/4 v6, 0x1

    .line 135
    if-eqz v4, :cond_2

    .line 136
    .line 137
    move v4, v6

    .line 138
    goto :goto_0

    .line 139
    :cond_2
    move v4, v5

    .line 140
    :goto_0
    new-instance v7, Lec7;

    .line 141
    .line 142
    iget-object v8, v0, Laf7;->b:Ldc7;

    .line 143
    .line 144
    iget-object v8, v8, Ldc7;->i:Lq85;

    .line 145
    .line 146
    invoke-virtual {v8}, Lq85;->toString()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v8

    .line 150
    iget-object v9, v0, Laf7;->b:Ldc7;

    .line 151
    .line 152
    iget-wide v10, v9, Ldc7;->m:J

    .line 153
    .line 154
    move-wide v12, v10

    .line 155
    iget-object v11, v9, Ldc7;->n:Lbh7;

    .line 156
    .line 157
    move-wide v13, v12

    .line 158
    iget-object v12, v9, Ldc7;->p:Ld75;

    .line 159
    .line 160
    iget-object v9, v9, Ldc7;->o:Lve4;

    .line 161
    .line 162
    invoke-static {v11, v9}, Lfa7;->d(Lbh7;Lve4;)Ljava/util/List;

    .line 163
    .line 164
    .line 165
    move-result-object v9

    .line 166
    iget-object v10, v0, Laf7;->b:Ldc7;

    .line 167
    .line 168
    invoke-static {v10}, Lfa7;->g(Ldc7;)Ldf7;

    .line 169
    .line 170
    .line 171
    move-result-object v15

    .line 172
    const/16 v16, 0x20

    .line 173
    .line 174
    move-wide/from16 v17, v13

    .line 175
    .line 176
    move-object v13, v9

    .line 177
    move-wide/from16 v9, v17

    .line 178
    .line 179
    const/4 v14, 0x0

    .line 180
    invoke-direct/range {v7 .. v16}, Lec7;-><init>(Ljava/lang/CharSequence;JLbh7;Ld75;Ljava/util/List;Ljava/util/List;Ldf7;I)V

    .line 181
    .line 182
    .line 183
    if-nez p1, :cond_4

    .line 184
    .line 185
    if-eqz v4, :cond_3

    .line 186
    .line 187
    if-eqz v1, :cond_3

    .line 188
    .line 189
    move v5, v6

    .line 190
    :cond_3
    invoke-virtual {v0, v3, v7, v5}, Laf7;->h(Lec7;Lec7;Z)V

    .line 191
    .line 192
    .line 193
    iget-object v1, v0, Laf7;->b:Ldc7;

    .line 194
    .line 195
    invoke-virtual {v1}, Ldc7;->a()Lar;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    invoke-virtual {v0, v3, v7, v1, v2}, Laf7;->d(Lec7;Lec7;Lar;Lbd7;)V

    .line 200
    .line 201
    .line 202
    return-void

    .line 203
    :cond_4
    iget-object v4, v0, Laf7;->b:Ldc7;

    .line 204
    .line 205
    invoke-virtual {v4}, Ldc7;->a()Lar;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    new-instance v5, Ldc7;

    .line 210
    .line 211
    const/16 v8, 0x8

    .line 212
    .line 213
    const/4 v9, 0x0

    .line 214
    invoke-direct {v5, v7, v4, v9, v8}, Ldc7;-><init>(Lec7;Lar;Llo0;I)V

    .line 215
    .line 216
    .line 217
    iget-object v4, v5, Ldc7;->i:Lq85;

    .line 218
    .line 219
    invoke-virtual {v4}, Lq85;->length()I

    .line 220
    .line 221
    .line 222
    move-result v8

    .line 223
    sub-int/2addr v8, v6

    .line 224
    :goto_1
    const/4 v6, -0x1

    .line 225
    if-ge v6, v8, :cond_6

    .line 226
    .line 227
    invoke-virtual {v4, v8}, Lq85;->charAt(I)C

    .line 228
    .line 229
    .line 230
    move-result v6

    .line 231
    invoke-static {v6}, Ljava/lang/Character;->isDigit(C)Z

    .line 232
    .line 233
    .line 234
    move-result v6

    .line 235
    if-nez v6, :cond_5

    .line 236
    .line 237
    add-int/lit8 v6, v8, 0x1

    .line 238
    .line 239
    const-string v10, ""

    .line 240
    .line 241
    invoke-virtual {v5, v8, v10, v6}, Ldc7;->c(ILjava/lang/String;I)V

    .line 242
    .line 243
    .line 244
    :cond_5
    add-int/lit8 v8, v8, -0x1

    .line 245
    .line 246
    goto :goto_1

    .line 247
    :cond_6
    invoke-static {v4, v7}, Lm17;->b0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 248
    .line 249
    .line 250
    move-result v4

    .line 251
    xor-int/lit8 v6, v4, 0x1

    .line 252
    .line 253
    iget-wide v10, v5, Ldc7;->m:J

    .line 254
    .line 255
    iget-wide v12, v7, Lec7;->k:J

    .line 256
    .line 257
    invoke-static {v10, v11, v12, v13}, Lbh7;->a(JJ)Z

    .line 258
    .line 259
    .line 260
    move-result v8

    .line 261
    xor-int/lit8 v10, v8, 0x1

    .line 262
    .line 263
    iget-object v11, v7, Lec7;->i:Ldf7;

    .line 264
    .line 265
    if-eqz v11, :cond_7

    .line 266
    .line 267
    iget-object v9, v11, Ldf7;->a:Lci7;

    .line 268
    .line 269
    :cond_7
    iget-object v11, v5, Ldc7;->j:Lci7;

    .line 270
    .line 271
    invoke-static {v11, v9}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v9

    .line 275
    xor-int/lit8 v11, v9, 0x1

    .line 276
    .line 277
    if-eqz v4, :cond_8

    .line 278
    .line 279
    if-eqz v8, :cond_8

    .line 280
    .line 281
    if-eqz v9, :cond_8

    .line 282
    .line 283
    iget-object v4, v7, Lec7;->l:Lbh7;

    .line 284
    .line 285
    const/16 v6, 0xd

    .line 286
    .line 287
    const-wide/16 v7, 0x0

    .line 288
    .line 289
    invoke-static {v5, v7, v8, v4, v6}, Ldc7;->h(Ldc7;JLbh7;I)Lec7;

    .line 290
    .line 291
    .line 292
    move-result-object v4

    .line 293
    invoke-virtual {v0, v3, v4, v1}, Laf7;->h(Lec7;Lec7;Z)V

    .line 294
    .line 295
    .line 296
    goto :goto_2

    .line 297
    :cond_8
    invoke-virtual {v0, v5, v6, v10, v11}, Laf7;->g(Ldc7;ZZZ)V

    .line 298
    .line 299
    .line 300
    :goto_2
    invoke-virtual {v0}, Laf7;->c()Lec7;

    .line 301
    .line 302
    .line 303
    move-result-object v1

    .line 304
    invoke-virtual {v5}, Ldc7;->a()Lar;

    .line 305
    .line 306
    .line 307
    move-result-object v4

    .line 308
    invoke-virtual {v0, v3, v1, v4, v2}, Laf7;->d(Lec7;Lec7;Lar;Lbd7;)V

    .line 309
    .line 310
    .line 311
    return-void
.end method

.method public final c()Lec7;
    .locals 0

    .line 1
    iget-object p0, p0, Laf7;->d:Lz75;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz75;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lec7;

    .line 8
    .line 9
    return-object p0
.end method

.method public final d(Lec7;Lec7;Lar;Lbd7;)V
    .locals 1

    .line 1
    invoke-virtual {p4}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p4

    .line 5
    const/4 v0, 0x1

    .line 6
    iget-object p0, p0, Laf7;->a:Lxp6;

    .line 7
    .line 8
    if-eqz p4, :cond_2

    .line 9
    .line 10
    if-eq p4, v0, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x2

    .line 13
    if-ne p4, v0, :cond_0

    .line 14
    .line 15
    const/4 p4, 0x0

    .line 16
    invoke-static {p0, p1, p2, p3, p4}, Lx97;->l(Lxp6;Lec7;Lec7;Lar;Z)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :cond_0
    invoke-static {}, Lxb1;->a()V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_1
    iget-object p1, p0, Lxp6;->j:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, Lz75;

    .line 27
    .line 28
    const/4 p2, 0x0

    .line 29
    invoke-virtual {p1, p2}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iget-object p0, p0, Lxp6;->i:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p0, Ldt7;

    .line 35
    .line 36
    iget-object p1, p0, Ldt7;->b:Llw6;

    .line 37
    .line 38
    invoke-virtual {p1}, Llw6;->clear()V

    .line 39
    .line 40
    .line 41
    iget-object p0, p0, Ldt7;->c:Llw6;

    .line 42
    .line 43
    invoke-virtual {p0}, Llw6;->clear()V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_2
    invoke-static {p0, p1, p2, p3, v0}, Lx97;->l(Lxp6;Lec7;Lec7;Lar;Z)V

    .line 48
    .line 49
    .line 50
    return-void
.end method

.method public final e(Z)V
    .locals 0

    .line 1
    iget-object p0, p0, Laf7;->f:Lz75;

    .line 2
    .line 3
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final f(Z)V
    .locals 0

    .line 1
    iget-object p0, p0, Laf7;->e:Lz75;

    .line 2
    .line 3
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final g(Ldc7;ZZZ)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Laf7;->b:Ldc7;

    .line 6
    .line 7
    const-wide/16 v3, 0x0

    .line 8
    .line 9
    const/4 v5, 0x0

    .line 10
    const/16 v6, 0xf

    .line 11
    .line 12
    invoke-static {v2, v3, v4, v5, v6}, Ldc7;->h(Ldc7;JLbh7;I)Lec7;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    if-nez p2, :cond_0

    .line 17
    .line 18
    if-nez p4, :cond_0

    .line 19
    .line 20
    if-eqz p3, :cond_1

    .line 21
    .line 22
    iget-object v7, v0, Laf7;->b:Ldc7;

    .line 23
    .line 24
    iget-wide v8, v1, Ldc7;->m:J

    .line 25
    .line 26
    sget v10, Lbh7;->c:I

    .line 27
    .line 28
    const/16 v10, 0x20

    .line 29
    .line 30
    shr-long v10, v8, v10

    .line 31
    .line 32
    long-to-int v10, v10

    .line 33
    const-wide v11, 0xffffffffL

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    and-long/2addr v8, v11

    .line 39
    long-to-int v8, v8

    .line 40
    invoke-static {v10, v8}, Ld77;->c(II)J

    .line 41
    .line 42
    .line 43
    move-result-wide v8

    .line 44
    invoke-virtual {v7, v8, v9}, Ldc7;->g(J)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_0
    new-instance v7, Ldc7;

    .line 49
    .line 50
    new-instance v8, Lec7;

    .line 51
    .line 52
    iget-object v9, v1, Ldc7;->i:Lq85;

    .line 53
    .line 54
    invoke-virtual {v9}, Lq85;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v9

    .line 58
    iget-wide v10, v1, Ldc7;->m:J

    .line 59
    .line 60
    invoke-static {v1}, Lfa7;->g(Ldc7;)Ldf7;

    .line 61
    .line 62
    .line 63
    move-result-object v16

    .line 64
    const/16 v17, 0x3c

    .line 65
    .line 66
    const/4 v12, 0x0

    .line 67
    const/4 v13, 0x0

    .line 68
    const/4 v14, 0x0

    .line 69
    const/4 v15, 0x0

    .line 70
    invoke-direct/range {v8 .. v17}, Lec7;-><init>(Ljava/lang/CharSequence;JLbh7;Ld75;Ljava/util/List;Ljava/util/List;Ldf7;I)V

    .line 71
    .line 72
    .line 73
    const/16 v9, 0xe

    .line 74
    .line 75
    invoke-direct {v7, v8, v5, v5, v9}, Ldc7;-><init>(Lec7;Lar;Llo0;I)V

    .line 76
    .line 77
    .line 78
    iput-object v7, v0, Laf7;->b:Ldc7;

    .line 79
    .line 80
    :cond_1
    :goto_0
    if-nez p2, :cond_2

    .line 81
    .line 82
    if-nez p3, :cond_2

    .line 83
    .line 84
    iget-object v7, v2, Lec7;->l:Lbh7;

    .line 85
    .line 86
    iget-object v1, v1, Ldc7;->n:Lbh7;

    .line 87
    .line 88
    invoke-static {v7, v1}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    if-nez v1, :cond_3

    .line 93
    .line 94
    :cond_2
    iget-object v1, v0, Laf7;->b:Ldc7;

    .line 95
    .line 96
    invoke-virtual {v1, v5}, Ldc7;->f(Lbh7;)V

    .line 97
    .line 98
    .line 99
    :cond_3
    iget-object v1, v0, Laf7;->b:Ldc7;

    .line 100
    .line 101
    invoke-static {v1, v3, v4, v5, v6}, Ldc7;->h(Ldc7;JLbh7;I)Lec7;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    const/4 v3, 0x1

    .line 106
    invoke-virtual {v0, v2, v1, v3}, Laf7;->h(Lec7;Lec7;Z)V

    .line 107
    .line 108
    .line 109
    return-void
.end method

.method public final h(Lec7;Lec7;Z)V
    .locals 6

    .line 1
    iget-object v0, p0, Laf7;->d:Lz75;

    .line 2
    .line 3
    invoke-virtual {v0, p2}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Laf7;->h:Lve4;

    .line 7
    .line 8
    iget-object v1, v0, Lve4;->h:[Ljava/lang/Object;

    .line 9
    .line 10
    iget v0, v0, Lve4;->j:I

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    move v3, v2

    .line 14
    :goto_0
    if-ge v3, v0, :cond_1

    .line 15
    .line 16
    aget-object v4, v1, v3

    .line 17
    .line 18
    check-cast v4, Lye7;

    .line 19
    .line 20
    if-eqz p3, :cond_0

    .line 21
    .line 22
    iget-object v5, p1, Lec7;->j:Ljava/lang/CharSequence;

    .line 23
    .line 24
    invoke-static {v5, p2}, Lm17;->b0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 25
    .line 26
    .line 27
    move-result v5

    .line 28
    if-nez v5, :cond_0

    .line 29
    .line 30
    iget-object v5, p1, Lec7;->l:Lbh7;

    .line 31
    .line 32
    if-eqz v5, :cond_0

    .line 33
    .line 34
    const/4 v5, 0x1

    .line 35
    goto :goto_1

    .line 36
    :cond_0
    move v5, v2

    .line 37
    :goto_1
    invoke-interface {v4, p1, p2, v5}, Lye7;->a(Lec7;Lec7;Z)V

    .line 38
    .line 39
    .line 40
    add-int/lit8 v3, v3, 0x1

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    invoke-virtual {p0, v2}, Laf7;->f(Z)V

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 6

    .line 1
    const-string v0, "TextFieldState(selection="

    .line 2
    .line 3
    invoke-static {}, Lwd6;->g()Ltv6;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v1}, Ltv6;->e()Lwh2;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v2, 0x0

    .line 15
    :goto_0
    invoke-static {v1}, Lwd6;->h(Ltv6;)Ltv6;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    :try_start_0
    invoke-virtual {p0}, Laf7;->c()Lec7;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    iget-wide v4, v4, Lec7;->k:J

    .line 24
    .line 25
    invoke-static {v4, v5}, Lbh7;->f(J)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    invoke-virtual {p0}, Laf7;->c()Lec7;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    iget-object p0, p0, Lec7;->j:Ljava/lang/CharSequence;

    .line 34
    .line 35
    new-instance v5, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v0, ", text=\""

    .line 44
    .line 45
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    const-string p0, "\")"

    .line 52
    .line 53
    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 60
    invoke-static {v1, v3, v2}, Lwd6;->l(Ltv6;Ltv6;Lwh2;)V

    .line 61
    .line 62
    .line 63
    return-object p0

    .line 64
    :catchall_0
    move-exception p0

    .line 65
    invoke-static {v1, v3, v2}, Lwd6;->l(Ltv6;Ltv6;Lwh2;)V

    .line 66
    .line 67
    .line 68
    throw p0
.end method
