.class public final synthetic Lav4;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lvv;

.field public final synthetic j:Lwh2;

.field public final synthetic k:Lwh2;

.field public final synthetic l:Lwh2;


# direct methods
.method public synthetic constructor <init>(Lvv;Lwh2;Lwh2;Lwh2;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lav4;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lav4;->i:Lvv;

    .line 4
    .line 5
    iput-object p2, p0, Lav4;->j:Lwh2;

    .line 6
    .line 7
    iput-object p3, p0, Lav4;->k:Lwh2;

    .line 8
    .line 9
    iput-object p4, p0, Lav4;->l:Lwh2;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lav4;->h:B

    .line 4
    .line 5
    iget-object v2, v0, Lav4;->i:Lvv;

    .line 6
    .line 7
    sget-object v3, Lst7;->a:Lst7;

    .line 8
    .line 9
    const/16 v4, 0x10

    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v6, 0x1

    .line 13
    packed-switch v1, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    move-object/from16 v1, p1

    .line 17
    .line 18
    check-cast v1, Lp01;

    .line 19
    .line 20
    move-object/from16 v12, p2

    .line 21
    .line 22
    check-cast v12, Lzi2;

    .line 23
    .line 24
    move-object/from16 v7, p3

    .line 25
    .line 26
    check-cast v7, Ljava/lang/Integer;

    .line 27
    .line 28
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 29
    .line 30
    .line 31
    move-result v7

    .line 32
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    and-int/lit8 v1, v7, 0x11

    .line 36
    .line 37
    if-eq v1, v4, :cond_0

    .line 38
    .line 39
    move v1, v6

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    move v1, v5

    .line 42
    :goto_0
    and-int/2addr v7, v6

    .line 43
    invoke-virtual {v12, v7, v1}, Lzi2;->Y(IZ)Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_6

    .line 48
    .line 49
    sget-object v11, Lya4;->h:Lya4;

    .line 50
    .line 51
    const/4 v1, 0x3

    .line 52
    invoke-static {v11, v1}, Lyl3;->B(Lbb4;I)Lbb4;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    new-instance v7, Lnw;

    .line 57
    .line 58
    new-instance v8, Ll42;

    .line 59
    .line 60
    invoke-direct {v8, v1}, Ll42;-><init>(B)V

    .line 61
    .line 62
    .line 63
    const/high16 v1, 0x41400000    # 12.0f

    .line 64
    .line 65
    invoke-direct {v7, v1, v6, v8}, Lnw;-><init>(FZLl42;)V

    .line 66
    .line 67
    .line 68
    sget-object v1, Ly6;->v:Lz30;

    .line 69
    .line 70
    invoke-static {v7, v1, v12, v5}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    iget-wide v7, v12, Lzi2;->U:J

    .line 75
    .line 76
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 77
    .line 78
    .line 79
    move-result v7

    .line 80
    invoke-virtual {v12}, Lzi2;->m()Lla5;

    .line 81
    .line 82
    .line 83
    move-result-object v8

    .line 84
    invoke-static {v12, v4}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    sget-object v9, Ls41;->d:Ly6;

    .line 89
    .line 90
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    .line 92
    .line 93
    invoke-virtual {v12}, Lzi2;->k0()V

    .line 94
    .line 95
    .line 96
    iget-boolean v9, v12, Lzi2;->T:Z

    .line 97
    .line 98
    if-eqz v9, :cond_1

    .line 99
    .line 100
    sget-object v9, Lzi3;->Z:Lu43;

    .line 101
    .line 102
    invoke-virtual {v12, v9}, Lzi2;->l(Llh2;)V

    .line 103
    .line 104
    .line 105
    goto :goto_1

    .line 106
    :cond_1
    invoke-virtual {v12}, Lzi2;->t0()V

    .line 107
    .line 108
    .line 109
    :goto_1
    sget-object v9, Ly6;->T:Lx31;

    .line 110
    .line 111
    invoke-static {v9, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    sget-object v1, Ly6;->S:Lx31;

    .line 115
    .line 116
    invoke-static {v1, v12, v8}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    sget-object v7, Ly6;->U:Lx31;

    .line 124
    .line 125
    invoke-static {v7, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    invoke-static {v12}, Lfa7;->k(Lzi2;)V

    .line 129
    .line 130
    .line 131
    sget-object v1, Ly6;->R:Lx31;

    .line 132
    .line 133
    invoke-static {v1, v12, v4}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    iget-object v7, v2, Lvv;->l:Ljava/lang/String;

    .line 137
    .line 138
    const v1, 0x7f0f0343

    .line 139
    .line 140
    .line 141
    invoke-static {v1, v12}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v8

    .line 145
    const/16 v13, 0x6180

    .line 146
    .line 147
    const/4 v14, 0x0

    .line 148
    const/4 v9, 0x1

    .line 149
    iget-object v10, v0, Lav4;->k:Lwh2;

    .line 150
    .line 151
    invoke-static/range {v7 .. v14}, Lza1;->q(Ljava/lang/String;Ljava/lang/String;ZLwh2;Lbb4;Lzi2;II)V

    .line 152
    .line 153
    .line 154
    iget-object v7, v2, Lvv;->m:Ljava/lang/String;

    .line 155
    .line 156
    const v1, 0x7f0f033a

    .line 157
    .line 158
    .line 159
    invoke-static {v1, v12}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v8

    .line 163
    const/4 v9, 0x0

    .line 164
    iget-object v10, v0, Lav4;->l:Lwh2;

    .line 165
    .line 166
    invoke-static/range {v7 .. v14}, Lza1;->q(Ljava/lang/String;Ljava/lang/String;ZLwh2;Lbb4;Lzi2;II)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v12, v6}, Lzi2;->r(Z)V

    .line 170
    .line 171
    .line 172
    const v1, 0x7f0f0339

    .line 173
    .line 174
    .line 175
    invoke-static {v1, v12}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v9

    .line 179
    const v1, 0x6a588371

    .line 180
    .line 181
    .line 182
    invoke-virtual {v12, v1}, Lzi2;->h0(I)V

    .line 183
    .line 184
    .line 185
    new-instance v7, Ljava/util/ArrayList;

    .line 186
    .line 187
    const/16 v1, 0xa

    .line 188
    .line 189
    sget-object v4, Lyt4;->n:Lc42;

    .line 190
    .line 191
    invoke-static {v4, v1}, Lby0;->D0(Ljava/lang/Iterable;I)I

    .line 192
    .line 193
    .line 194
    move-result v1

    .line 195
    invoke-direct {v7, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v4}, Lq3;->iterator()Ljava/util/Iterator;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 203
    .line 204
    .line 205
    move-result v6

    .line 206
    if-eqz v6, :cond_2

    .line 207
    .line 208
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v6

    .line 212
    check-cast v6, Lyt4;

    .line 213
    .line 214
    invoke-static {v6, v12}, Lyj3;->z(Lyt4;Lzi2;)Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v6

    .line 218
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 219
    .line 220
    .line 221
    goto :goto_2

    .line 222
    :cond_2
    invoke-virtual {v12, v5}, Lzi2;->r(Z)V

    .line 223
    .line 224
    .line 225
    iget-object v1, v2, Lvv;->n:Lyt4;

    .line 226
    .line 227
    invoke-virtual {v4, v1}, Lc42;->indexOf(Ljava/lang/Object;)I

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    if-gez v1, :cond_3

    .line 232
    .line 233
    move v8, v5

    .line 234
    goto :goto_3

    .line 235
    :cond_3
    move v8, v1

    .line 236
    :goto_3
    iget-object v0, v0, Lav4;->j:Lwh2;

    .line 237
    .line 238
    invoke-virtual {v12, v0}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 239
    .line 240
    .line 241
    move-result v1

    .line 242
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v2

    .line 246
    if-nez v1, :cond_4

    .line 247
    .line 248
    sget-object v1, Lc51;->a:Lql0;

    .line 249
    .line 250
    if-ne v2, v1, :cond_5

    .line 251
    .line 252
    :cond_4
    new-instance v2, Lz60;

    .line 253
    .line 254
    const/16 v1, 0x14

    .line 255
    .line 256
    invoke-direct {v2, v0, v1}, Lz60;-><init>(Lwh2;B)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v12, v2}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 260
    .line 261
    .line 262
    :cond_5
    move-object/from16 v19, v2

    .line 263
    .line 264
    check-cast v19, Lwh2;

    .line 265
    .line 266
    const/16 v22, 0x0

    .line 267
    .line 268
    const v23, 0xfff8

    .line 269
    .line 270
    .line 271
    const/4 v10, 0x0

    .line 272
    const/4 v11, 0x0

    .line 273
    move-object/from16 v20, v12

    .line 274
    .line 275
    const/4 v12, 0x0

    .line 276
    const/4 v13, 0x0

    .line 277
    const/4 v14, 0x0

    .line 278
    const/4 v15, 0x0

    .line 279
    const/16 v16, 0x0

    .line 280
    .line 281
    const/16 v17, 0x0

    .line 282
    .line 283
    const/16 v18, 0x0

    .line 284
    .line 285
    const/16 v21, 0x0

    .line 286
    .line 287
    invoke-static/range {v7 .. v23}, Lv74;->d(Ljava/util/List;ILjava/lang/String;Lbb4;Lp10;Lp10;Lyw1;Ls21;Lo45;ZZZLwh2;Lzi2;III)V

    .line 288
    .line 289
    .line 290
    goto :goto_4

    .line 291
    :cond_6
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 292
    .line 293
    .line 294
    :goto_4
    return-object v3

    .line 295
    :pswitch_0
    move-object/from16 v1, p1

    .line 296
    .line 297
    check-cast v1, Lfl3;

    .line 298
    .line 299
    move-object/from16 v14, p2

    .line 300
    .line 301
    check-cast v14, Lzi2;

    .line 302
    .line 303
    move-object/from16 v7, p3

    .line 304
    .line 305
    check-cast v7, Ljava/lang/Integer;

    .line 306
    .line 307
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 308
    .line 309
    .line 310
    move-result v7

    .line 311
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 312
    .line 313
    .line 314
    and-int/lit8 v1, v7, 0x11

    .line 315
    .line 316
    if-eq v1, v4, :cond_7

    .line 317
    .line 318
    move v5, v6

    .line 319
    :cond_7
    and-int/2addr v7, v6

    .line 320
    invoke-virtual {v14, v7, v5}, Lzi2;->Y(IZ)Z

    .line 321
    .line 322
    .line 323
    move-result v1

    .line 324
    if-eqz v1, :cond_8

    .line 325
    .line 326
    const v1, 0x7f0f0334

    .line 327
    .line 328
    .line 329
    invoke-static {v1, v14}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 330
    .line 331
    .line 332
    move-result-object v7

    .line 333
    iget-boolean v8, v2, Lvv;->u:Z

    .line 334
    .line 335
    iget-object v9, v2, Lvv;->v:Ljava/lang/String;

    .line 336
    .line 337
    iget-object v10, v2, Lvv;->w:Lxt4;

    .line 338
    .line 339
    const/4 v15, 0x0

    .line 340
    iget-object v11, v0, Lav4;->j:Lwh2;

    .line 341
    .line 342
    iget-object v12, v0, Lav4;->k:Lwh2;

    .line 343
    .line 344
    iget-object v13, v0, Lav4;->l:Lwh2;

    .line 345
    .line 346
    invoke-static/range {v7 .. v15}, Lza1;->p(Ljava/lang/String;ZLjava/lang/String;Lxt4;Lwh2;Lwh2;Lwh2;Lzi2;I)V

    .line 347
    .line 348
    .line 349
    goto :goto_5

    .line 350
    :cond_8
    invoke-virtual {v14}, Lzi2;->b0()V

    .line 351
    .line 352
    .line 353
    :goto_5
    return-object v3

    .line 354
    :pswitch_1
    move-object/from16 v1, p1

    .line 355
    .line 356
    check-cast v1, Lfl3;

    .line 357
    .line 358
    move-object/from16 v14, p2

    .line 359
    .line 360
    check-cast v14, Lzi2;

    .line 361
    .line 362
    move-object/from16 v7, p3

    .line 363
    .line 364
    check-cast v7, Ljava/lang/Integer;

    .line 365
    .line 366
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 367
    .line 368
    .line 369
    move-result v7

    .line 370
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 371
    .line 372
    .line 373
    and-int/lit8 v1, v7, 0x11

    .line 374
    .line 375
    if-eq v1, v4, :cond_9

    .line 376
    .line 377
    move v5, v6

    .line 378
    :cond_9
    and-int/2addr v7, v6

    .line 379
    invoke-virtual {v14, v7, v5}, Lzi2;->Y(IZ)Z

    .line 380
    .line 381
    .line 382
    move-result v1

    .line 383
    if-eqz v1, :cond_a

    .line 384
    .line 385
    const v1, 0x7f0f0335

    .line 386
    .line 387
    .line 388
    invoke-static {v1, v14}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 389
    .line 390
    .line 391
    move-result-object v7

    .line 392
    iget-boolean v8, v2, Lvv;->r:Z

    .line 393
    .line 394
    iget-object v9, v2, Lvv;->s:Ljava/lang/String;

    .line 395
    .line 396
    iget-object v10, v2, Lvv;->t:Lxt4;

    .line 397
    .line 398
    const/4 v15, 0x0

    .line 399
    iget-object v11, v0, Lav4;->j:Lwh2;

    .line 400
    .line 401
    iget-object v12, v0, Lav4;->k:Lwh2;

    .line 402
    .line 403
    iget-object v13, v0, Lav4;->l:Lwh2;

    .line 404
    .line 405
    invoke-static/range {v7 .. v15}, Lza1;->p(Ljava/lang/String;ZLjava/lang/String;Lxt4;Lwh2;Lwh2;Lwh2;Lzi2;I)V

    .line 406
    .line 407
    .line 408
    goto :goto_6

    .line 409
    :cond_a
    invoke-virtual {v14}, Lzi2;->b0()V

    .line 410
    .line 411
    .line 412
    :goto_6
    return-object v3

    .line 413
    :pswitch_2
    move-object/from16 v1, p1

    .line 414
    .line 415
    check-cast v1, Lfl3;

    .line 416
    .line 417
    move-object/from16 v14, p2

    .line 418
    .line 419
    check-cast v14, Lzi2;

    .line 420
    .line 421
    move-object/from16 v7, p3

    .line 422
    .line 423
    check-cast v7, Ljava/lang/Integer;

    .line 424
    .line 425
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 426
    .line 427
    .line 428
    move-result v7

    .line 429
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 430
    .line 431
    .line 432
    and-int/lit8 v1, v7, 0x11

    .line 433
    .line 434
    if-eq v1, v4, :cond_b

    .line 435
    .line 436
    move v5, v6

    .line 437
    :cond_b
    and-int/2addr v7, v6

    .line 438
    invoke-virtual {v14, v7, v5}, Lzi2;->Y(IZ)Z

    .line 439
    .line 440
    .line 441
    move-result v1

    .line 442
    if-eqz v1, :cond_c

    .line 443
    .line 444
    const v1, 0x7f0f0333

    .line 445
    .line 446
    .line 447
    invoke-static {v1, v14}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v7

    .line 451
    iget-boolean v8, v2, Lvv;->o:Z

    .line 452
    .line 453
    iget-object v9, v2, Lvv;->p:Ljava/lang/String;

    .line 454
    .line 455
    iget-object v10, v2, Lvv;->q:Lxt4;

    .line 456
    .line 457
    const/4 v15, 0x0

    .line 458
    iget-object v11, v0, Lav4;->j:Lwh2;

    .line 459
    .line 460
    iget-object v12, v0, Lav4;->k:Lwh2;

    .line 461
    .line 462
    iget-object v13, v0, Lav4;->l:Lwh2;

    .line 463
    .line 464
    invoke-static/range {v7 .. v15}, Lza1;->p(Ljava/lang/String;ZLjava/lang/String;Lxt4;Lwh2;Lwh2;Lwh2;Lzi2;I)V

    .line 465
    .line 466
    .line 467
    goto :goto_7

    .line 468
    :cond_c
    invoke-virtual {v14}, Lzi2;->b0()V

    .line 469
    .line 470
    .line 471
    :goto_7
    return-object v3

    .line 472
    :pswitch_3
    move-object/from16 v1, p1

    .line 473
    .line 474
    check-cast v1, Lfl3;

    .line 475
    .line 476
    move-object/from16 v2, p2

    .line 477
    .line 478
    check-cast v2, Lzi2;

    .line 479
    .line 480
    move-object/from16 v7, p3

    .line 481
    .line 482
    check-cast v7, Ljava/lang/Integer;

    .line 483
    .line 484
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 485
    .line 486
    .line 487
    move-result v7

    .line 488
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 489
    .line 490
    .line 491
    and-int/lit8 v1, v7, 0x11

    .line 492
    .line 493
    if-eq v1, v4, :cond_d

    .line 494
    .line 495
    move v5, v6

    .line 496
    :cond_d
    and-int/2addr v7, v6

    .line 497
    invoke-virtual {v2, v7, v5}, Lzi2;->Y(IZ)Z

    .line 498
    .line 499
    .line 500
    move-result v1

    .line 501
    if-eqz v1, :cond_e

    .line 502
    .line 503
    sget-object v1, Lya4;->h:Lya4;

    .line 504
    .line 505
    const/high16 v4, 0x3f800000    # 1.0f

    .line 506
    .line 507
    invoke-static {v1, v4}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 508
    .line 509
    .line 510
    move-result-object v7

    .line 511
    new-instance v8, Lav4;

    .line 512
    .line 513
    const/4 v13, 0x4

    .line 514
    iget-object v9, v0, Lav4;->i:Lvv;

    .line 515
    .line 516
    iget-object v10, v0, Lav4;->j:Lwh2;

    .line 517
    .line 518
    iget-object v11, v0, Lav4;->k:Lwh2;

    .line 519
    .line 520
    iget-object v12, v0, Lav4;->l:Lwh2;

    .line 521
    .line 522
    invoke-direct/range {v8 .. v13}, Lav4;-><init>(Lvv;Lwh2;Lwh2;Lwh2;B)V

    .line 523
    .line 524
    .line 525
    const v0, 0x340e79f8

    .line 526
    .line 527
    .line 528
    invoke-static {v0, v8, v2}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 529
    .line 530
    .line 531
    move-result-object v18

    .line 532
    const/16 v20, 0x6

    .line 533
    .line 534
    const/16 v21, 0x7fe

    .line 535
    .line 536
    const/4 v8, 0x0

    .line 537
    const/4 v9, 0x0

    .line 538
    const/4 v10, 0x0

    .line 539
    const/4 v11, 0x0

    .line 540
    const/4 v12, 0x0

    .line 541
    const/4 v13, 0x0

    .line 542
    const/4 v14, 0x0

    .line 543
    const/4 v15, 0x0

    .line 544
    const-wide/16 v16, 0x0

    .line 545
    .line 546
    move-object/from16 v19, v2

    .line 547
    .line 548
    invoke-static/range {v7 .. v21}, Lc74;->a(Lbb4;FLo45;Lxl0;Lsf5;ZLlh2;Llh2;ZJLs21;Lzi2;II)V

    .line 549
    .line 550
    .line 551
    goto :goto_8

    .line 552
    :cond_e
    move-object/from16 v19, v2

    .line 553
    .line 554
    invoke-virtual/range {v19 .. v19}, Lzi2;->b0()V

    .line 555
    .line 556
    .line 557
    :goto_8
    return-object v3

    .line 558
    nop

    .line 559
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
