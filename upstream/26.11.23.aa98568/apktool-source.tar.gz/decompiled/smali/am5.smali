.class public final synthetic Lam5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lvq0;

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:Z

.field public final synthetic l:Laq5;

.field public final synthetic m:Z

.field public final synthetic n:Lwh2;


# direct methods
.method public synthetic constructor <init>(Lvq0;Ljava/lang/String;ZLaq5;ZLwh2;IB)V
    .locals 0

    .line 1
    iput-byte p8, p0, Lam5;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lam5;->i:Lvq0;

    .line 4
    .line 5
    iput-object p2, p0, Lam5;->j:Ljava/lang/String;

    .line 6
    .line 7
    iput-boolean p3, p0, Lam5;->k:Z

    .line 8
    .line 9
    iput-object p4, p0, Lam5;->l:Laq5;

    .line 10
    .line 11
    iput-boolean p5, p0, Lam5;->m:Z

    .line 12
    .line 13
    iput-object p6, p0, Lam5;->n:Lwh2;

    .line 14
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lam5;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    packed-switch v1, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    move-object/from16 v10, p1

    .line 12
    .line 13
    check-cast v10, Lzi2;

    .line 14
    .line 15
    move-object/from16 v1, p2

    .line 16
    .line 17
    check-cast v1, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {v3}, Lyj3;->j0(I)I

    .line 23
    .line 24
    .line 25
    move-result v11

    .line 26
    iget-object v4, v0, Lam5;->i:Lvq0;

    .line 27
    .line 28
    iget-object v5, v0, Lam5;->j:Ljava/lang/String;

    .line 29
    .line 30
    iget-boolean v6, v0, Lam5;->k:Z

    .line 31
    .line 32
    iget-object v7, v0, Lam5;->l:Laq5;

    .line 33
    .line 34
    iget-boolean v8, v0, Lam5;->m:Z

    .line 35
    .line 36
    iget-object v9, v0, Lam5;->n:Lwh2;

    .line 37
    .line 38
    invoke-static/range {v4 .. v11}, Lv97;->g(Lvq0;Ljava/lang/String;ZLaq5;ZLwh2;Lzi2;I)V

    .line 39
    .line 40
    .line 41
    return-object v2

    .line 42
    :pswitch_0
    move-object/from16 v18, p1

    .line 43
    .line 44
    check-cast v18, Lzi2;

    .line 45
    .line 46
    move-object/from16 v1, p2

    .line 47
    .line 48
    check-cast v1, Ljava/lang/Integer;

    .line 49
    .line 50
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    invoke-static {v3}, Lyj3;->j0(I)I

    .line 54
    .line 55
    .line 56
    move-result v19

    .line 57
    iget-object v12, v0, Lam5;->i:Lvq0;

    .line 58
    .line 59
    iget-object v13, v0, Lam5;->j:Ljava/lang/String;

    .line 60
    .line 61
    iget-boolean v14, v0, Lam5;->k:Z

    .line 62
    .line 63
    iget-object v15, v0, Lam5;->l:Laq5;

    .line 64
    .line 65
    iget-boolean v1, v0, Lam5;->m:Z

    .line 66
    .line 67
    iget-object v0, v0, Lam5;->n:Lwh2;

    .line 68
    .line 69
    move-object/from16 v17, v0

    .line 70
    .line 71
    move/from16 v16, v1

    .line 72
    .line 73
    invoke-static/range {v12 .. v19}, Lnb3;->p(Lvq0;Ljava/lang/String;ZLaq5;ZLwh2;Lzi2;I)V

    .line 74
    .line 75
    .line 76
    return-object v2

    .line 77
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
