.class public final Lb82;
.super Loa2;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final d:Landroid/graphics/Bitmap;

.field public final e:Lwx5;


# direct methods
.method public constructor <init>(La82;Landroid/graphics/Bitmap;Lwx5;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Loa2;-><init>(Lna2;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lb82;->d:Landroid/graphics/Bitmap;

    .line 5
    .line 6
    iput-object p3, p0, Lb82;->e:Lwx5;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()I
    .locals 0

    .line 1
    const/16 p0, 0x1000

    .line 2
    .line 3
    return p0
.end method
