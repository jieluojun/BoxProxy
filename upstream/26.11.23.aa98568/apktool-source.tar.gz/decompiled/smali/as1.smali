.class public interface abstract Las1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# virtual methods
.method public abstract a()F
.end method

.method public abstract c()F
.end method

.method public abstract f()Lw80;
.end method

.method public abstract g()F
.end method
