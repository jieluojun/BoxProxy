.class public final Lb07;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Landroid/view/inputmethod/InputConnection;


# instance fields
.field public final a:Ljf;

.field public final b:Lve4;

.field public final c:Lb83;


# direct methods
.method public constructor <init>(Ljf;Landroid/view/inputmethod/EditorInfo;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb07;->a:Ljf;

    .line 5
    .line 6
    new-instance p1, Lve4;

    .line 7
    .line 8
    const/16 v0, 0x10

    .line 9
    .line 10
    new-array v0, v0, [Lwh2;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-direct {p1, v1, v0}, Lve4;-><init>(I[Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lb07;->b:Lve4;

    .line 17
    .line 18
    new-instance p1, La07;

    .line 19
    .line 20
    invoke-direct {p1, p0, v1}, Landroid/view/inputmethod/InputConnectionWrapper;-><init>(Landroid/view/inputmethod/InputConnection;Z)V

    .line 21
    .line 22
    .line 23
    new-instance v0, Lwd6;

    .line 24
    .line 25
    const/16 v1, 0x9

    .line 26
    .line 27
    invoke-direct {v0, p0, v1}, Lwd6;-><init>(Ljava/lang/Object;B)V

    .line 28
    .line 29
    .line 30
    if-eqz p2, :cond_0

    .line 31
    .line 32
    new-instance p2, Lb83;

    .line 33
    .line 34
    invoke-direct {p2, p1, v0}, Lb83;-><init>(Landroid/view/inputmethod/InputConnection;Lc83;)V

    .line 35
    .line 36
    .line 37
    iput-object p2, p0, Lb07;->c:Lb83;

    .line 38
    .line 39
    return-void

    .line 40
    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    .line 41
    .line 42
    const-string p1, "editorInfo must be non-null"

    .line 43
    .line 44
    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    throw p0
.end method


# virtual methods
.method public final a()Lec7;
    .locals 0

    .line 1
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 2
    .line 3
    iget-object p0, p0, Ljf;->c:Llo7;

    .line 4
    .line 5
    invoke-virtual {p0}, Llo7;->f()Lec7;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final b(I)V
    .locals 2

    .line 1
    new-instance v0, Landroid/view/KeyEvent;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1, p1}, Landroid/view/KeyEvent;-><init>(II)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Lb07;->sendKeyEvent(Landroid/view/KeyEvent;)Z

    .line 8
    .line 9
    .line 10
    new-instance v0, Landroid/view/KeyEvent;

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    invoke-direct {v0, v1, p1}, Landroid/view/KeyEvent;-><init>(II)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, v0}, Lb07;->sendKeyEvent(Landroid/view/KeyEvent;)Z

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final beginBatchEdit()Z
    .locals 2

    .line 1
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 2
    .line 3
    iget-object p0, p0, Ljf;->a:Lwz4;

    .line 4
    .line 5
    iget v0, p0, Lwz4;->b:I

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    add-int/2addr v0, v1

    .line 9
    iput v0, p0, Lwz4;->b:I

    .line 10
    .line 11
    return v1
.end method

.method public final clearMetaKeyStates(I)Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final closeConnection()V
    .locals 0

    .line 1
    iget-object p0, p0, Lb07;->b:Lve4;

    .line 2
    .line 3
    invoke-virtual {p0}, Lve4;->g()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final commitCompletion(Landroid/view/inputmethod/CompletionInfo;)Z
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/view/inputmethod/CompletionInfo;->getText()Ljava/lang/CharSequence;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 p0, 0x0

    .line 9
    :goto_0
    invoke-static {p0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    const/4 p0, 0x0

    .line 13
    return p0
.end method

.method public final commitContent(Landroid/view/inputmethod/InputContentInfo;ILandroid/os/Bundle;)Z
    .locals 0

    .line 1
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    invoke-static {p3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, Lb07;->c:Lb83;

    .line 8
    .line 9
    invoke-virtual {p0, p1, p2, p3}, Lb83;->commitContent(Landroid/view/inputmethod/InputContentInfo;ILandroid/os/Bundle;)Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final commitCorrection(Landroid/view/inputmethod/CorrectionInfo;)Z
    .locals 0

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final commitText(Ljava/lang/CharSequence;I)Z
    .locals 3

    .line 41
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    const/4 v0, 0x1

    if-nez p1, :cond_0

    return v0

    .line 42
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 43
    new-instance v1, Llo2;

    const/4 v2, 0x0

    invoke-direct {v1, p2, p1, v2}, Llo2;-><init>(ILjava/lang/String;Z)V

    iget-object p0, p0, Lb07;->a:Ljf;

    invoke-virtual {p0, v1}, Ljf;->d(Lwh2;)V

    return v0
.end method

.method public final commitText(Ljava/lang/CharSequence;ILandroid/view/inputmethod/TextAttribute;)Z
    .locals 2

    .line 1
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    invoke-static {p3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-static {p3}, Lwk5;->p(Ljava/lang/Object;)Lwk5;

    .line 12
    .line 13
    .line 14
    move-result-object p3

    .line 15
    const/4 v0, 0x0

    .line 16
    const/4 v1, 0x1

    .line 17
    if-eqz p3, :cond_0

    .line 18
    .line 19
    iget-object p3, p3, Lwk5;->i:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p3, Lqa7;

    .line 22
    .line 23
    invoke-interface {p3}, Lqa7;->a()Z

    .line 24
    .line 25
    .line 26
    move-result p3

    .line 27
    if-ne p3, v1, :cond_0

    .line 28
    .line 29
    move v0, v1

    .line 30
    :cond_0
    new-instance p3, Llo2;

    .line 31
    .line 32
    invoke-direct {p3, p2, p1, v0}, Llo2;-><init>(ILjava/lang/String;Z)V

    .line 33
    .line 34
    .line 35
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 36
    .line 37
    invoke-virtual {p0, p3}, Ljf;->d(Lwh2;)V

    .line 38
    .line 39
    .line 40
    return v1
.end method

.method public final deleteSurroundingText(II)Z
    .locals 2

    .line 1
    new-instance v0, Lq53;

    .line 2
    .line 3
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-direct {v0, p1, p2, p0, v1}, Lq53;-><init>(IILo53;B)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, v0}, Ljf;->d(Lwh2;)V

    .line 10
    .line 11
    .line 12
    return v1
.end method

.method public final deleteSurroundingTextInCodePoints(II)Z
    .locals 2

    .line 1
    new-instance v0, Lp53;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p1, p2, v1}, Lp53;-><init>(IIB)V

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Ljf;->d(Lwh2;)V

    .line 10
    .line 11
    .line 12
    const/4 p0, 0x1

    .line 13
    return p0
.end method

.method public final endBatchEdit()Z
    .locals 0

    .line 1
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 2
    .line 3
    iget-object p0, p0, Ljf;->a:Lwz4;

    .line 4
    .line 5
    invoke-virtual {p0}, Lwz4;->g()Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public final finishComposingText()Z
    .locals 2

    .line 1
    new-instance v0, Ljw2;

    .line 2
    .line 3
    const/16 v1, 0x16

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljw2;-><init>(B)V

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 9
    .line 10
    invoke-virtual {p0, v0}, Ljf;->d(Lwh2;)V

    .line 11
    .line 12
    .line 13
    const/4 p0, 0x1

    .line 14
    return p0
.end method

.method public final getCursorCapsMode(I)I
    .locals 3

    .line 1
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    iget-wide v1, p0, Lec7;->k:J

    .line 10
    .line 11
    invoke-static {v1, v2}, Lbh7;->d(J)I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    invoke-static {v0, p0, p1}, Landroid/text/TextUtils;->getCapsMode(Ljava/lang/CharSequence;II)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method

.method public final getExtractedText(Landroid/view/inputmethod/ExtractedTextRequest;I)Landroid/view/inputmethod/ExtractedText;
    .locals 2

    .line 1
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    and-int/2addr p2, v0

    .line 6
    if-eqz p2, :cond_1

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    iget p1, p1, Landroid/view/inputmethod/ExtractedTextRequest;->token:I

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 p1, 0x0

    .line 14
    :goto_0
    iget-object p2, p0, Lb07;->a:Ljf;

    .line 15
    .line 16
    iget-object v1, p2, Ljf;->g:Lcw5;

    .line 17
    .line 18
    iput-boolean v0, v1, Lcw5;->h:Z

    .line 19
    .line 20
    iget-object p2, p2, Ljf;->h:Lew5;

    .line 21
    .line 22
    iput p1, p2, Lew5;->h:I

    .line 23
    .line 24
    :cond_1
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    invoke-static {p0}, Lpm6;->i0(Lec7;)Landroid/view/inputmethod/ExtractedText;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0
.end method

.method public final getHandler()Landroid/os/Handler;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final getSelectedText(I)Ljava/lang/CharSequence;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-wide v0, p1, Lec7;->k:J

    .line 6
    .line 7
    invoke-static {v0, v1}, Lbh7;->b(J)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    const/4 p0, 0x0

    .line 14
    return-object p0

    .line 15
    :cond_0
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    iget-wide v0, p0, Lec7;->k:J

    .line 20
    .line 21
    invoke-static {v0, v1}, Lbh7;->d(J)I

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    iget-wide v0, p0, Lec7;->k:J

    .line 26
    .line 27
    invoke-static {v0, v1}, Lbh7;->c(J)I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    iget-object p0, p0, Lec7;->j:Ljava/lang/CharSequence;

    .line 32
    .line 33
    invoke-interface {p0, p1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    return-object p0
.end method

.method public final getTextAfterCursor(II)Ljava/lang/CharSequence;
    .locals 3

    .line 1
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-wide v0, p0, Lec7;->k:J

    .line 6
    .line 7
    iget-object p2, p0, Lec7;->j:Ljava/lang/CharSequence;

    .line 8
    .line 9
    invoke-static {v0, v1}, Lbh7;->c(J)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    iget-wide v1, p0, Lec7;->k:J

    .line 14
    .line 15
    invoke-static {v1, v2}, Lbh7;->c(J)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    add-int v1, p0, p1

    .line 20
    .line 21
    xor-int/2addr p0, v1

    .line 22
    xor-int/2addr p1, v1

    .line 23
    and-int/2addr p0, p1

    .line 24
    if-gez p0, :cond_0

    .line 25
    .line 26
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    :cond_0
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    invoke-static {v1, p0}, Ljava/lang/Math;->min(II)I

    .line 35
    .line 36
    .line 37
    move-result p0

    .line 38
    invoke-interface {p2, v0, p0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0
.end method

.method public final getTextBeforeCursor(II)Ljava/lang/CharSequence;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-wide v0, p0, Lec7;->k:J

    .line 6
    .line 7
    invoke-static {v0, v1}, Lbh7;->d(J)I

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    sub-int v0, p2, p1

    .line 12
    .line 13
    xor-int/2addr p1, p2

    .line 14
    xor-int/2addr p2, v0

    .line 15
    and-int/2addr p1, p2

    .line 16
    const/4 p2, 0x0

    .line 17
    if-gez p1, :cond_0

    .line 18
    .line 19
    move v0, p2

    .line 20
    :cond_0
    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    iget-wide v0, p0, Lec7;->k:J

    .line 25
    .line 26
    invoke-static {v0, v1}, Lbh7;->d(J)I

    .line 27
    .line 28
    .line 29
    move-result p2

    .line 30
    iget-object p0, p0, Lec7;->j:Ljava/lang/CharSequence;

    .line 31
    .line 32
    invoke-interface {p0, p1, p2}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    return-object p0
.end method

.method public final performContextMenuAction(I)Z
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    packed-switch p1, :pswitch_data_0

    .line 3
    .line 4
    .line 5
    return v0

    .line 6
    :pswitch_0
    const/16 p1, 0x117

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Lb07;->b(I)V

    .line 9
    .line 10
    .line 11
    return v0

    .line 12
    :pswitch_1
    const/16 p1, 0x116

    .line 13
    .line 14
    invoke-virtual {p0, p1}, Lb07;->b(I)V

    .line 15
    .line 16
    .line 17
    return v0

    .line 18
    :pswitch_2
    const/16 p1, 0x115

    .line 19
    .line 20
    invoke-virtual {p0, p1}, Lb07;->b(I)V

    .line 21
    .line 22
    .line 23
    return v0

    .line 24
    :pswitch_3
    invoke-virtual {p0}, Lb07;->a()Lec7;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    iget-object p1, p1, Lec7;->j:Ljava/lang/CharSequence;

    .line 29
    .line 30
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    new-instance v1, Lq53;

    .line 35
    .line 36
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 37
    .line 38
    invoke-direct {v1, p0, v0, p1}, Lq53;-><init>(Lo53;II)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0, v1}, Ljf;->d(Lwh2;)V

    .line 42
    .line 43
    .line 44
    return v0

    .line 45
    :pswitch_data_0
    .packed-switch 0x102001f
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final performEditorAction(I)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    packed-switch p1, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    goto :goto_0

    .line 8
    :pswitch_0
    const/4 p1, 0x5

    .line 9
    goto :goto_1

    .line 10
    :pswitch_1
    const/4 p1, 0x7

    .line 11
    goto :goto_1

    .line 12
    :pswitch_2
    const/4 p1, 0x6

    .line 13
    goto :goto_1

    .line 14
    :pswitch_3
    const/4 p1, 0x4

    .line 15
    goto :goto_1

    .line 16
    :pswitch_4
    const/4 p1, 0x3

    .line 17
    goto :goto_1

    .line 18
    :pswitch_5
    const/4 p1, 0x2

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    :goto_0
    move p1, v0

    .line 21
    :goto_1
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 22
    .line 23
    iget-object p0, p0, Ljf;->e:Lyo4;

    .line 24
    .line 25
    if-eqz p0, :cond_1

    .line 26
    .line 27
    iget-object p0, p0, Lk7;->h:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast p0, Lwc7;

    .line 30
    .line 31
    invoke-virtual {p0, p1}, Lwc7;->N1(I)Z

    .line 32
    .line 33
    .line 34
    :cond_1
    return v0

    .line 35
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final performHandwritingGesture(Landroid/view/inputmethod/HandwritingGesture;Ljava/util/concurrent/Executor;Ljava/util/function/IntConsumer;)V
    .locals 12

    .line 1
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    invoke-static {p2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    invoke-static {p3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 11
    .line 12
    const/16 v1, 0x22

    .line 13
    .line 14
    if-lt v0, v1, :cond_24

    .line 15
    .line 16
    const/4 v2, 0x2

    .line 17
    if-lt v0, v1, :cond_23

    .line 18
    .line 19
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 20
    .line 21
    iget-object v3, p0, Ljf;->c:Llo7;

    .line 22
    .line 23
    iget-object v0, p0, Ljf;->i:Lyf7;

    .line 24
    .line 25
    iget-object v1, p0, Ljf;->j:Lpc7;

    .line 26
    .line 27
    iget-object p0, p0, Ljf;->k:Lqx7;

    .line 28
    .line 29
    invoke-static {p1}, Lvc;->q(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    const/4 v5, 0x0

    .line 34
    const/4 v10, 0x1

    .line 35
    if-eqz v4, :cond_3

    .line 36
    .line 37
    invoke-static {p1}, Lvc;->l(Ljava/lang/Object;)Landroid/view/inputmethod/SelectGesture;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    invoke-static {p0}, Lvc;->g(Landroid/view/inputmethod/SelectGesture;)Landroid/graphics/RectF;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-static {p1}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-static {p0}, Lvc;->d(Landroid/view/inputmethod/SelectGesture;)I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-ne v2, v10, :cond_0

    .line 54
    .line 55
    move v5, v10

    .line 56
    :cond_0
    invoke-static {v0, p1, v5}, Lnx;->O(Lyf7;Lyv5;I)J

    .line 57
    .line 58
    .line 59
    move-result-wide v4

    .line 60
    invoke-static {v4, v5}, Lbh7;->b(J)Z

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    if-eqz p1, :cond_1

    .line 65
    .line 66
    invoke-static {p0}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    goto/16 :goto_a

    .line 75
    .line 76
    :cond_1
    invoke-virtual {v3, v4, v5}, Llo7;->m(J)V

    .line 77
    .line 78
    .line 79
    if-eqz v1, :cond_2

    .line 80
    .line 81
    invoke-virtual {v1}, Lpc7;->a()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    :cond_2
    :goto_0
    move v2, v10

    .line 85
    goto/16 :goto_a

    .line 86
    .line 87
    :cond_3
    invoke-static {p1}, Las2;->u(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v4

    .line 91
    if-eqz v4, :cond_7

    .line 92
    .line 93
    invoke-static {p1}, Las2;->m(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteGesture;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    invoke-static {p0}, Las2;->c(Landroid/view/inputmethod/DeleteGesture;)I

    .line 98
    .line 99
    .line 100
    move-result p1

    .line 101
    if-eq p1, v10, :cond_4

    .line 102
    .line 103
    move p1, v5

    .line 104
    goto :goto_1

    .line 105
    :cond_4
    move p1, v10

    .line 106
    :goto_1
    invoke-static {p0}, Las2;->j(Landroid/view/inputmethod/DeleteGesture;)Landroid/graphics/RectF;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    invoke-static {v1}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    invoke-static {v0, v1, p1}, Lnx;->O(Lyf7;Lyv5;I)J

    .line 115
    .line 116
    .line 117
    move-result-wide v0

    .line 118
    invoke-static {v0, v1}, Lbh7;->b(J)Z

    .line 119
    .line 120
    .line 121
    move-result v2

    .line 122
    if-eqz v2, :cond_5

    .line 123
    .line 124
    invoke-static {p0}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 125
    .line 126
    .line 127
    move-result-object p0

    .line 128
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 129
    .line 130
    .line 131
    move-result v2

    .line 132
    goto/16 :goto_a

    .line 133
    .line 134
    :cond_5
    if-ne p1, v10, :cond_6

    .line 135
    .line 136
    move v5, v10

    .line 137
    :cond_6
    invoke-static {v3, v0, v1, v5}, Lmx;->V(Llo7;JZ)V

    .line 138
    .line 139
    .line 140
    goto :goto_0

    .line 141
    :cond_7
    invoke-static {p1}, Las2;->z(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    move-result v4

    .line 145
    if-eqz v4, :cond_a

    .line 146
    .line 147
    invoke-static {p1}, Las2;->p(Ljava/lang/Object;)Landroid/view/inputmethod/SelectRangeGesture;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    invoke-static {p0}, Lvc;->h(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    invoke-static {p1}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    invoke-static {p0}, Las2;->l(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    invoke-static {v2}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 164
    .line 165
    .line 166
    move-result-object v2

    .line 167
    invoke-static {p0}, Las2;->e(Landroid/view/inputmethod/SelectRangeGesture;)I

    .line 168
    .line 169
    .line 170
    move-result v4

    .line 171
    if-ne v4, v10, :cond_8

    .line 172
    .line 173
    move v5, v10

    .line 174
    :cond_8
    invoke-static {v0, p1, v2, v5}, Lnx;->P(Lyf7;Lyv5;Lyv5;I)J

    .line 175
    .line 176
    .line 177
    move-result-wide v4

    .line 178
    invoke-static {v4, v5}, Lbh7;->b(J)Z

    .line 179
    .line 180
    .line 181
    move-result p1

    .line 182
    if-eqz p1, :cond_9

    .line 183
    .line 184
    invoke-static {p0}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 185
    .line 186
    .line 187
    move-result-object p0

    .line 188
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    goto/16 :goto_a

    .line 193
    .line 194
    :cond_9
    invoke-virtual {v3, v4, v5}, Llo7;->m(J)V

    .line 195
    .line 196
    .line 197
    if-eqz v1, :cond_2

    .line 198
    .line 199
    invoke-virtual {v1}, Lpc7;->a()Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    goto :goto_0

    .line 203
    :cond_a
    invoke-static {p1}, Las2;->C(Ljava/lang/Object;)Z

    .line 204
    .line 205
    .line 206
    move-result v1

    .line 207
    if-eqz v1, :cond_e

    .line 208
    .line 209
    invoke-static {p1}, Las2;->n(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteRangeGesture;

    .line 210
    .line 211
    .line 212
    move-result-object p0

    .line 213
    invoke-static {p0}, Las2;->d(Landroid/view/inputmethod/DeleteRangeGesture;)I

    .line 214
    .line 215
    .line 216
    move-result p1

    .line 217
    if-eq p1, v10, :cond_b

    .line 218
    .line 219
    move p1, v5

    .line 220
    goto :goto_2

    .line 221
    :cond_b
    move p1, v10

    .line 222
    :goto_2
    invoke-static {p0}, Las2;->k(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    invoke-static {v1}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    invoke-static {p0}, Las2;->B(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 231
    .line 232
    .line 233
    move-result-object v2

    .line 234
    invoke-static {v2}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 235
    .line 236
    .line 237
    move-result-object v2

    .line 238
    invoke-static {v0, v1, v2, p1}, Lnx;->P(Lyf7;Lyv5;Lyv5;I)J

    .line 239
    .line 240
    .line 241
    move-result-wide v0

    .line 242
    invoke-static {v0, v1}, Lbh7;->b(J)Z

    .line 243
    .line 244
    .line 245
    move-result v2

    .line 246
    if-eqz v2, :cond_c

    .line 247
    .line 248
    invoke-static {p0}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 249
    .line 250
    .line 251
    move-result-object p0

    .line 252
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 253
    .line 254
    .line 255
    move-result v2

    .line 256
    goto/16 :goto_a

    .line 257
    .line 258
    :cond_c
    if-ne p1, v10, :cond_d

    .line 259
    .line 260
    move v5, v10

    .line 261
    :cond_d
    invoke-static {v3, v0, v1, v5}, Lmx;->V(Llo7;JZ)V

    .line 262
    .line 263
    .line 264
    goto/16 :goto_0

    .line 265
    .line 266
    :cond_e
    invoke-static {p1}, Lvc;->y(Ljava/lang/Object;)Z

    .line 267
    .line 268
    .line 269
    move-result v1

    .line 270
    const/4 v4, -0x1

    .line 271
    if-eqz v1, :cond_16

    .line 272
    .line 273
    invoke-static {p1}, Lvc;->j(Ljava/lang/Object;)Landroid/view/inputmethod/JoinOrSplitGesture;

    .line 274
    .line 275
    .line 276
    move-result-object p1

    .line 277
    invoke-virtual {v3}, Llo7;->d()Lec7;

    .line 278
    .line 279
    .line 280
    move-result-object v1

    .line 281
    iget-object v2, v3, Llo7;->a:Laf7;

    .line 282
    .line 283
    invoke-virtual {v2}, Laf7;->c()Lec7;

    .line 284
    .line 285
    .line 286
    move-result-object v2

    .line 287
    if-eq v1, v2, :cond_f

    .line 288
    .line 289
    const/4 v2, 0x3

    .line 290
    goto/16 :goto_a

    .line 291
    .line 292
    :cond_f
    invoke-static {p1}, Las2;->h(Landroid/view/inputmethod/JoinOrSplitGesture;)Landroid/graphics/PointF;

    .line 293
    .line 294
    .line 295
    move-result-object v1

    .line 296
    invoke-static {v1}, Lnx;->g0(Landroid/graphics/PointF;)J

    .line 297
    .line 298
    .line 299
    move-result-wide v1

    .line 300
    invoke-static {v0, v1, v2, p0}, Lnx;->N(Lyf7;JLqx7;)I

    .line 301
    .line 302
    .line 303
    move-result p0

    .line 304
    if-eq p0, v4, :cond_15

    .line 305
    .line 306
    invoke-virtual {v0}, Lyf7;->c()Lxf7;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    if-eqz v0, :cond_11

    .line 311
    .line 312
    iget-object v1, v0, Lxf7;->b:Lpc4;

    .line 313
    .line 314
    invoke-virtual {v1, p0}, Lpc4;->c(I)I

    .line 315
    .line 316
    .line 317
    move-result v2

    .line 318
    invoke-virtual {v0, v2}, Lxf7;->h(I)I

    .line 319
    .line 320
    .line 321
    move-result v4

    .line 322
    if-eq p0, v4, :cond_10

    .line 323
    .line 324
    invoke-virtual {v1, v2, v5}, Lpc4;->b(IZ)I

    .line 325
    .line 326
    .line 327
    move-result v1

    .line 328
    if-eq p0, v1, :cond_10

    .line 329
    .line 330
    invoke-virtual {v0, p0}, Lxf7;->a(I)Ldz5;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    add-int/lit8 v2, p0, -0x1

    .line 335
    .line 336
    invoke-virtual {v0, v2}, Lxf7;->a(I)Ldz5;

    .line 337
    .line 338
    .line 339
    move-result-object v0

    .line 340
    if-eq v1, v0, :cond_11

    .line 341
    .line 342
    goto :goto_5

    .line 343
    :cond_10
    invoke-virtual {v0, p0}, Lxf7;->i(I)Ldz5;

    .line 344
    .line 345
    .line 346
    move-result-object v1

    .line 347
    invoke-virtual {v0, p0}, Lxf7;->a(I)Ldz5;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    if-ne v1, v0, :cond_15

    .line 352
    .line 353
    :cond_11
    invoke-virtual {v3}, Llo7;->f()Lec7;

    .line 354
    .line 355
    .line 356
    move-result-object p1

    .line 357
    move v0, p0

    .line 358
    :goto_3
    if-lez v0, :cond_12

    .line 359
    .line 360
    invoke-static {p1, v0}, Ljava/lang/Character;->codePointBefore(Ljava/lang/CharSequence;I)I

    .line 361
    .line 362
    .line 363
    move-result v1

    .line 364
    invoke-static {v1}, Lnx;->T(I)Z

    .line 365
    .line 366
    .line 367
    move-result v2

    .line 368
    if-eqz v2, :cond_12

    .line 369
    .line 370
    invoke-static {v1}, Ljava/lang/Character;->charCount(I)I

    .line 371
    .line 372
    .line 373
    move-result v1

    .line 374
    sub-int/2addr v0, v1

    .line 375
    goto :goto_3

    .line 376
    :cond_12
    :goto_4
    iget-object v1, p1, Lec7;->j:Ljava/lang/CharSequence;

    .line 377
    .line 378
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    .line 379
    .line 380
    .line 381
    move-result v1

    .line 382
    if-ge p0, v1, :cond_13

    .line 383
    .line 384
    invoke-static {p1, p0}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 385
    .line 386
    .line 387
    move-result v1

    .line 388
    invoke-static {v1}, Lnx;->T(I)Z

    .line 389
    .line 390
    .line 391
    move-result v2

    .line 392
    if-eqz v2, :cond_13

    .line 393
    .line 394
    invoke-static {v1}, Ljava/lang/Character;->charCount(I)I

    .line 395
    .line 396
    .line 397
    move-result v1

    .line 398
    add-int/2addr p0, v1

    .line 399
    goto :goto_4

    .line 400
    :cond_13
    invoke-static {v0, p0}, Ld77;->c(II)J

    .line 401
    .line 402
    .line 403
    move-result-wide v5

    .line 404
    invoke-static {v5, v6}, Lbh7;->b(J)Z

    .line 405
    .line 406
    .line 407
    move-result p0

    .line 408
    const/4 v8, 0x0

    .line 409
    const/16 v9, 0x1c

    .line 410
    .line 411
    if-eqz p0, :cond_14

    .line 412
    .line 413
    const-string v4, " "

    .line 414
    .line 415
    const/4 v7, 0x0

    .line 416
    invoke-static/range {v3 .. v9}, Llo7;->l(Llo7;Ljava/lang/String;JZZI)V

    .line 417
    .line 418
    .line 419
    goto/16 :goto_0

    .line 420
    .line 421
    :cond_14
    const-string v4, ""

    .line 422
    .line 423
    const/4 v7, 0x0

    .line 424
    invoke-static/range {v3 .. v9}, Llo7;->l(Llo7;Ljava/lang/String;JZZI)V

    .line 425
    .line 426
    .line 427
    goto/16 :goto_0

    .line 428
    .line 429
    :cond_15
    :goto_5
    invoke-static {p1}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 430
    .line 431
    .line 432
    move-result-object p0

    .line 433
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 434
    .line 435
    .line 436
    move-result v2

    .line 437
    goto/16 :goto_a

    .line 438
    .line 439
    :cond_16
    invoke-static {p1}, Lvc;->u(Ljava/lang/Object;)Z

    .line 440
    .line 441
    .line 442
    move-result v1

    .line 443
    if-eqz v1, :cond_18

    .line 444
    .line 445
    invoke-static {p1}, Lvc;->i(Ljava/lang/Object;)Landroid/view/inputmethod/InsertGesture;

    .line 446
    .line 447
    .line 448
    move-result-object p1

    .line 449
    invoke-static {p1}, Las2;->g(Landroid/view/inputmethod/InsertGesture;)Landroid/graphics/PointF;

    .line 450
    .line 451
    .line 452
    move-result-object v1

    .line 453
    invoke-static {v1}, Lnx;->g0(Landroid/graphics/PointF;)J

    .line 454
    .line 455
    .line 456
    move-result-wide v1

    .line 457
    invoke-static {v0, v1, v2, p0}, Lnx;->N(Lyf7;JLqx7;)I

    .line 458
    .line 459
    .line 460
    move-result p0

    .line 461
    if-ne p0, v4, :cond_17

    .line 462
    .line 463
    invoke-static {p1}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 464
    .line 465
    .line 466
    move-result-object p0

    .line 467
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 468
    .line 469
    .line 470
    move-result v2

    .line 471
    goto/16 :goto_a

    .line 472
    .line 473
    :cond_17
    invoke-static {p1}, Las2;->r(Landroid/view/inputmethod/InsertGesture;)Ljava/lang/String;

    .line 474
    .line 475
    .line 476
    move-result-object v4

    .line 477
    invoke-static {p0, p0}, Ld77;->c(II)J

    .line 478
    .line 479
    .line 480
    move-result-wide v5

    .line 481
    const/4 v8, 0x0

    .line 482
    const/16 v9, 0x1c

    .line 483
    .line 484
    const/4 v7, 0x0

    .line 485
    invoke-static/range {v3 .. v9}, Llo7;->l(Llo7;Ljava/lang/String;JZZI)V

    .line 486
    .line 487
    .line 488
    goto/16 :goto_0

    .line 489
    .line 490
    :cond_18
    invoke-static {p1}, Lvc;->w(Ljava/lang/Object;)Z

    .line 491
    .line 492
    .line 493
    move-result v1

    .line 494
    if-eqz v1, :cond_23

    .line 495
    .line 496
    invoke-static {p1}, Lvc;->k(Ljava/lang/Object;)Landroid/view/inputmethod/RemoveSpaceGesture;

    .line 497
    .line 498
    .line 499
    move-result-object p1

    .line 500
    invoke-virtual {v0}, Lyf7;->c()Lxf7;

    .line 501
    .line 502
    .line 503
    move-result-object v1

    .line 504
    invoke-static {p1}, Las2;->i(Landroid/view/inputmethod/RemoveSpaceGesture;)Landroid/graphics/PointF;

    .line 505
    .line 506
    .line 507
    move-result-object v2

    .line 508
    invoke-static {v2}, Lnx;->g0(Landroid/graphics/PointF;)J

    .line 509
    .line 510
    .line 511
    move-result-wide v6

    .line 512
    invoke-static {p1}, Las2;->w(Landroid/view/inputmethod/RemoveSpaceGesture;)Landroid/graphics/PointF;

    .line 513
    .line 514
    .line 515
    move-result-object v2

    .line 516
    invoke-static {v2}, Lnx;->g0(Landroid/graphics/PointF;)J

    .line 517
    .line 518
    .line 519
    move-result-wide v8

    .line 520
    invoke-virtual {v0}, Lyf7;->e()Lhi3;

    .line 521
    .line 522
    .line 523
    move-result-object v0

    .line 524
    const/16 v2, 0x20

    .line 525
    .line 526
    if-eqz v1, :cond_1c

    .line 527
    .line 528
    iget-object v1, v1, Lxf7;->b:Lpc4;

    .line 529
    .line 530
    if-eqz v0, :cond_1c

    .line 531
    .line 532
    invoke-interface {v0, v6, v7}, Lhi3;->x(J)J

    .line 533
    .line 534
    .line 535
    move-result-wide v6

    .line 536
    invoke-interface {v0, v8, v9}, Lhi3;->x(J)J

    .line 537
    .line 538
    .line 539
    move-result-wide v8

    .line 540
    invoke-static {v1, v6, v7, p0}, Lnx;->M(Lpc4;JLqx7;)I

    .line 541
    .line 542
    .line 543
    move-result v0

    .line 544
    invoke-static {v1, v8, v9, p0}, Lnx;->M(Lpc4;JLqx7;)I

    .line 545
    .line 546
    .line 547
    move-result p0

    .line 548
    if-ne v0, v4, :cond_19

    .line 549
    .line 550
    if-ne p0, v4, :cond_1b

    .line 551
    .line 552
    sget-wide v0, Lbh7;->b:J

    .line 553
    .line 554
    goto :goto_6

    .line 555
    :cond_19
    if-eq p0, v4, :cond_1a

    .line 556
    .line 557
    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    .line 558
    .line 559
    .line 560
    move-result v0

    .line 561
    :cond_1a
    move p0, v0

    .line 562
    :cond_1b
    invoke-virtual {v1, p0}, Lpc4;->e(I)F

    .line 563
    .line 564
    .line 565
    move-result v0

    .line 566
    invoke-virtual {v1, p0}, Lpc4;->a(I)F

    .line 567
    .line 568
    .line 569
    move-result p0

    .line 570
    add-float/2addr p0, v0

    .line 571
    const/high16 v0, 0x40000000    # 2.0f

    .line 572
    .line 573
    div-float/2addr p0, v0

    .line 574
    new-instance v0, Lyv5;

    .line 575
    .line 576
    shr-long/2addr v6, v2

    .line 577
    long-to-int v6, v6

    .line 578
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 579
    .line 580
    .line 581
    move-result v7

    .line 582
    shr-long/2addr v8, v2

    .line 583
    long-to-int v8, v8

    .line 584
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 585
    .line 586
    .line 587
    move-result v9

    .line 588
    invoke-static {v7, v9}, Ljava/lang/Math;->min(FF)F

    .line 589
    .line 590
    .line 591
    move-result v7

    .line 592
    const v9, 0x3dcccccd    # 0.1f

    .line 593
    .line 594
    .line 595
    sub-float v11, p0, v9

    .line 596
    .line 597
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 598
    .line 599
    .line 600
    move-result v6

    .line 601
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 602
    .line 603
    .line 604
    move-result v8

    .line 605
    invoke-static {v6, v8}, Ljava/lang/Math;->max(FF)F

    .line 606
    .line 607
    .line 608
    move-result v6

    .line 609
    add-float/2addr p0, v9

    .line 610
    invoke-direct {v0, v7, v11, v6, p0}, Lyv5;-><init>(FFFF)V

    .line 611
    .line 612
    .line 613
    sget-object p0, Lpc5;->M:Lwt5;

    .line 614
    .line 615
    invoke-virtual {v1, v0, v5, p0}, Lpc4;->g(Lyv5;ILwt5;)J

    .line 616
    .line 617
    .line 618
    move-result-wide v0

    .line 619
    goto :goto_6

    .line 620
    :cond_1c
    sget-wide v0, Lbh7;->b:J

    .line 621
    .line 622
    :goto_6
    invoke-static {v0, v1}, Lbh7;->b(J)Z

    .line 623
    .line 624
    .line 625
    move-result p0

    .line 626
    if-eqz p0, :cond_1d

    .line 627
    .line 628
    invoke-static {p1}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 629
    .line 630
    .line 631
    move-result-object p0

    .line 632
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 633
    .line 634
    .line 635
    move-result v2

    .line 636
    goto/16 :goto_a

    .line 637
    .line 638
    :cond_1d
    invoke-virtual {v3}, Llo7;->f()Lec7;

    .line 639
    .line 640
    .line 641
    move-result-object p0

    .line 642
    invoke-static {v0, v1}, Lbh7;->d(J)I

    .line 643
    .line 644
    .line 645
    move-result v6

    .line 646
    invoke-static {v0, v1}, Lbh7;->c(J)I

    .line 647
    .line 648
    .line 649
    move-result v7

    .line 650
    iget-object p0, p0, Lec7;->j:Ljava/lang/CharSequence;

    .line 651
    .line 652
    invoke-interface {p0, v6, v7}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 653
    .line 654
    .line 655
    move-result-object p0

    .line 656
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 657
    .line 658
    .line 659
    move-result-object p0

    .line 660
    const-string v6, "\\s+"

    .line 661
    .line 662
    invoke-static {v6}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 663
    .line 664
    .line 665
    move-result-object v6

    .line 666
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 667
    .line 668
    .line 669
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 670
    .line 671
    .line 672
    invoke-virtual {v6, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 673
    .line 674
    .line 675
    move-result-object v6

    .line 676
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 677
    .line 678
    .line 679
    invoke-static {v6, v5, p0}, Lti3;->y(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lb04;

    .line 680
    .line 681
    .line 682
    move-result-object v6

    .line 683
    if-nez v6, :cond_1e

    .line 684
    .line 685
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 686
    .line 687
    .line 688
    move-result-object p0

    .line 689
    move v5, v4

    .line 690
    move v9, v5

    .line 691
    goto :goto_9

    .line 692
    :cond_1e
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 693
    .line 694
    .line 695
    move-result v7

    .line 696
    new-instance v8, Ljava/lang/StringBuilder;

    .line 697
    .line 698
    invoke-direct {v8, v7}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 699
    .line 700
    .line 701
    move v9, v4

    .line 702
    :goto_7
    invoke-virtual {v6}, Lb04;->b()Ls93;

    .line 703
    .line 704
    .line 705
    move-result-object v11

    .line 706
    iget v11, v11, Lq93;->h:I

    .line 707
    .line 708
    invoke-virtual {v8, p0, v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 709
    .line 710
    .line 711
    if-ne v9, v4, :cond_1f

    .line 712
    .line 713
    invoke-virtual {v6}, Lb04;->b()Ls93;

    .line 714
    .line 715
    .line 716
    move-result-object v5

    .line 717
    iget v9, v5, Lq93;->h:I

    .line 718
    .line 719
    :cond_1f
    invoke-virtual {v6}, Lb04;->b()Ls93;

    .line 720
    .line 721
    .line 722
    move-result-object v5

    .line 723
    iget v5, v5, Lq93;->i:I

    .line 724
    .line 725
    add-int/2addr v5, v10

    .line 726
    const-string v11, ""

    .line 727
    .line 728
    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 729
    .line 730
    .line 731
    invoke-virtual {v6}, Lb04;->b()Ls93;

    .line 732
    .line 733
    .line 734
    move-result-object v11

    .line 735
    iget v11, v11, Lq93;->i:I

    .line 736
    .line 737
    add-int/2addr v11, v10

    .line 738
    invoke-virtual {v6}, Lb04;->c()Lb04;

    .line 739
    .line 740
    .line 741
    move-result-object v6

    .line 742
    if-ge v11, v7, :cond_21

    .line 743
    .line 744
    if-nez v6, :cond_20

    .line 745
    .line 746
    invoke-virtual {v8, p0, v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 747
    .line 748
    .line 749
    goto :goto_8

    .line 750
    :cond_20
    move v5, v11

    .line 751
    goto :goto_7

    .line 752
    :cond_21
    :goto_8
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 753
    .line 754
    .line 755
    move-result-object p0

    .line 756
    :goto_9
    if-eq v9, v4, :cond_22

    .line 757
    .line 758
    if-eq v5, v4, :cond_22

    .line 759
    .line 760
    shr-long v6, v0, v2

    .line 761
    .line 762
    long-to-int p1, v6

    .line 763
    add-int v2, p1, v9

    .line 764
    .line 765
    add-int/2addr p1, v5

    .line 766
    invoke-static {v2, p1}, Ld77;->c(II)J

    .line 767
    .line 768
    .line 769
    move-result-wide v6

    .line 770
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 771
    .line 772
    .line 773
    move-result p1

    .line 774
    invoke-static {v0, v1}, Lbh7;->c(J)I

    .line 775
    .line 776
    .line 777
    move-result v2

    .line 778
    invoke-static {v0, v1}, Lbh7;->d(J)I

    .line 779
    .line 780
    .line 781
    move-result v0

    .line 782
    sub-int/2addr v2, v0

    .line 783
    sub-int/2addr v2, v5

    .line 784
    sub-int/2addr p1, v2

    .line 785
    invoke-virtual {p0, v9, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 786
    .line 787
    .line 788
    move-result-object v4

    .line 789
    const/4 v8, 0x0

    .line 790
    const/16 v9, 0x1c

    .line 791
    .line 792
    move-wide v5, v6

    .line 793
    const/4 v7, 0x0

    .line 794
    invoke-static/range {v3 .. v9}, Llo7;->l(Llo7;Ljava/lang/String;JZZI)V

    .line 795
    .line 796
    .line 797
    goto/16 :goto_0

    .line 798
    .line 799
    :cond_22
    invoke-static {p1}, Las2;->o(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 800
    .line 801
    .line 802
    move-result-object p0

    .line 803
    invoke-static {v3, p0}, Lmx;->z(Llo7;Landroid/view/inputmethod/HandwritingGesture;)I

    .line 804
    .line 805
    .line 806
    move-result v2

    .line 807
    :cond_23
    :goto_a
    if-nez p3, :cond_25

    .line 808
    .line 809
    :cond_24
    return-void

    .line 810
    :cond_25
    if-eqz p2, :cond_26

    .line 811
    .line 812
    new-instance p0, Lxj;

    .line 813
    .line 814
    invoke-direct {p0, p3, v2}, Lxj;-><init>(Ljava/util/function/IntConsumer;I)V

    .line 815
    .line 816
    .line 817
    invoke-interface {p2, p0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 818
    .line 819
    .line 820
    return-void

    .line 821
    :cond_26
    invoke-interface {p3, v2}, Ljava/util/function/IntConsumer;->accept(I)V

    .line 822
    .line 823
    .line 824
    return-void
.end method

.method public final performPrivateCommand(Ljava/lang/String;Landroid/os/Bundle;)Z
    .locals 0

    .line 1
    invoke-static {p2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb07;->c:Lb83;

    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, Landroid/view/inputmethod/InputConnectionWrapper;->performPrivateCommand(Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final previewHandwritingGesture(Landroid/view/inputmethod/PreviewableHandwritingGesture;Landroid/os/CancellationSignal;)Z
    .locals 5

    .line 1
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    invoke-static {p2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x22

    .line 11
    .line 12
    if-lt v0, v2, :cond_8

    .line 13
    .line 14
    if-lt v0, v2, :cond_8

    .line 15
    .line 16
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 17
    .line 18
    iget-object v0, p0, Ljf;->c:Llo7;

    .line 19
    .line 20
    iget-object p0, p0, Ljf;->i:Lyf7;

    .line 21
    .line 22
    invoke-static {p1}, Lvc;->q(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/4 v3, 0x1

    .line 27
    if-eqz v2, :cond_1

    .line 28
    .line 29
    invoke-static {p1}, Lvc;->l(Ljava/lang/Object;)Landroid/view/inputmethod/SelectGesture;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-static {p1}, Lvc;->g(Landroid/view/inputmethod/SelectGesture;)Landroid/graphics/RectF;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    invoke-static {v2}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    invoke-static {p1}, Lvc;->d(Landroid/view/inputmethod/SelectGesture;)I

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    if-eq p1, v3, :cond_0

    .line 46
    .line 47
    move p1, v1

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    move p1, v3

    .line 50
    :goto_0
    invoke-static {p0, v2, p1}, Lnx;->O(Lyf7;Lyv5;I)J

    .line 51
    .line 52
    .line 53
    move-result-wide p0

    .line 54
    invoke-static {v0, p0, p1, v1}, Lmx;->M(Llo7;JI)V

    .line 55
    .line 56
    .line 57
    goto/16 :goto_2

    .line 58
    .line 59
    :cond_1
    invoke-static {p1}, Las2;->u(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    if-eqz v2, :cond_3

    .line 64
    .line 65
    invoke-static {p1}, Las2;->m(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteGesture;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-static {p1}, Lvc;->f(Landroid/view/inputmethod/DeleteGesture;)Landroid/graphics/RectF;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    invoke-static {v2}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    invoke-static {p1}, Lvc;->b(Landroid/view/inputmethod/DeleteGesture;)I

    .line 78
    .line 79
    .line 80
    move-result p1

    .line 81
    if-ne p1, v3, :cond_2

    .line 82
    .line 83
    move v1, v3

    .line 84
    :cond_2
    invoke-static {p0, v2, v1}, Lnx;->O(Lyf7;Lyv5;I)J

    .line 85
    .line 86
    .line 87
    move-result-wide p0

    .line 88
    invoke-static {v0, p0, p1, v3}, Lmx;->M(Llo7;JI)V

    .line 89
    .line 90
    .line 91
    goto :goto_2

    .line 92
    :cond_3
    invoke-static {p1}, Las2;->z(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    if-eqz v2, :cond_5

    .line 97
    .line 98
    invoke-static {p1}, Las2;->p(Ljava/lang/Object;)Landroid/view/inputmethod/SelectRangeGesture;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    invoke-static {p1}, Lvc;->h(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    invoke-static {v2}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 107
    .line 108
    .line 109
    move-result-object v2

    .line 110
    invoke-static {p1}, Las2;->l(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    invoke-static {v4}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    invoke-static {p1}, Las2;->e(Landroid/view/inputmethod/SelectRangeGesture;)I

    .line 119
    .line 120
    .line 121
    move-result p1

    .line 122
    if-eq p1, v3, :cond_4

    .line 123
    .line 124
    move p1, v1

    .line 125
    goto :goto_1

    .line 126
    :cond_4
    move p1, v3

    .line 127
    :goto_1
    invoke-static {p0, v2, v4, p1}, Lnx;->P(Lyf7;Lyv5;Lyv5;I)J

    .line 128
    .line 129
    .line 130
    move-result-wide p0

    .line 131
    invoke-static {v0, p0, p1, v1}, Lmx;->M(Llo7;JI)V

    .line 132
    .line 133
    .line 134
    goto :goto_2

    .line 135
    :cond_5
    invoke-static {p1}, Las2;->C(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v2

    .line 139
    if-eqz v2, :cond_8

    .line 140
    .line 141
    invoke-static {p1}, Las2;->n(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteRangeGesture;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    invoke-static {p1}, Las2;->x(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    invoke-static {v2}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 150
    .line 151
    .line 152
    move-result-object v2

    .line 153
    invoke-static {p1}, Las2;->B(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    invoke-static {v4}, Lck3;->A0(Landroid/graphics/RectF;)Lyv5;

    .line 158
    .line 159
    .line 160
    move-result-object v4

    .line 161
    invoke-static {p1}, Lvc;->c(Landroid/view/inputmethod/DeleteRangeGesture;)I

    .line 162
    .line 163
    .line 164
    move-result p1

    .line 165
    if-ne p1, v3, :cond_6

    .line 166
    .line 167
    move v1, v3

    .line 168
    :cond_6
    invoke-static {p0, v2, v4, v1}, Lnx;->P(Lyf7;Lyv5;Lyv5;I)J

    .line 169
    .line 170
    .line 171
    move-result-wide p0

    .line 172
    invoke-static {v0, p0, p1, v3}, Lmx;->M(Llo7;JI)V

    .line 173
    .line 174
    .line 175
    :goto_2
    if-eqz p2, :cond_7

    .line 176
    .line 177
    new-instance p0, Lo41;

    .line 178
    .line 179
    invoke-direct {p0, v0, v3}, Lo41;-><init>(Ljava/lang/Object;B)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {p2, p0}, Landroid/os/CancellationSignal;->setOnCancelListener(Landroid/os/CancellationSignal$OnCancelListener;)V

    .line 183
    .line 184
    .line 185
    :cond_7
    return v3

    .line 186
    :cond_8
    return v1
.end method

.method public final reportFullscreenMode(Z)Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final requestCursorUpdates(I)Z
    .locals 9

    .line 1
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 2
    .line 3
    iget-object p0, p0, Ljf;->f:Lik1;

    .line 4
    .line 5
    and-int/lit8 v0, p1, 0x1

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x1

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    move v0, v2

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move v0, v1

    .line 14
    :goto_0
    and-int/lit8 v3, p1, 0x2

    .line 15
    .line 16
    if-eqz v3, :cond_1

    .line 17
    .line 18
    move v3, v2

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    move v3, v1

    .line 21
    :goto_1
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 22
    .line 23
    const/16 v5, 0x21

    .line 24
    .line 25
    if-lt v4, v5, :cond_8

    .line 26
    .line 27
    and-int/lit8 v5, p1, 0x10

    .line 28
    .line 29
    if-eqz v5, :cond_2

    .line 30
    .line 31
    move v5, v2

    .line 32
    goto :goto_2

    .line 33
    :cond_2
    move v5, v1

    .line 34
    :goto_2
    and-int/lit8 v6, p1, 0x8

    .line 35
    .line 36
    if-eqz v6, :cond_3

    .line 37
    .line 38
    move v6, v2

    .line 39
    goto :goto_3

    .line 40
    :cond_3
    move v6, v1

    .line 41
    :goto_3
    and-int/lit8 v7, p1, 0x4

    .line 42
    .line 43
    if-eqz v7, :cond_4

    .line 44
    .line 45
    move v7, v2

    .line 46
    goto :goto_4

    .line 47
    :cond_4
    move v7, v1

    .line 48
    :goto_4
    const/16 v8, 0x22

    .line 49
    .line 50
    if-lt v4, v8, :cond_5

    .line 51
    .line 52
    and-int/lit8 p1, p1, 0x20

    .line 53
    .line 54
    if-eqz p1, :cond_5

    .line 55
    .line 56
    move v1, v2

    .line 57
    :cond_5
    if-nez v5, :cond_7

    .line 58
    .line 59
    if-nez v6, :cond_7

    .line 60
    .line 61
    if-nez v7, :cond_7

    .line 62
    .line 63
    if-nez v1, :cond_7

    .line 64
    .line 65
    if-lt v4, v8, :cond_6

    .line 66
    .line 67
    move p1, v2

    .line 68
    move v1, p1

    .line 69
    :goto_5
    move v5, v1

    .line 70
    :goto_6
    move v6, v5

    .line 71
    goto :goto_7

    .line 72
    :cond_6
    move p1, v1

    .line 73
    move v1, v2

    .line 74
    goto :goto_5

    .line 75
    :cond_7
    move p1, v1

    .line 76
    move v1, v7

    .line 77
    goto :goto_7

    .line 78
    :cond_8
    move p1, v1

    .line 79
    move v5, v2

    .line 80
    goto :goto_6

    .line 81
    :goto_7
    iput-boolean v5, p0, Lik1;->f:Z

    .line 82
    .line 83
    iput-boolean v6, p0, Lik1;->g:Z

    .line 84
    .line 85
    iput-boolean v1, p0, Lik1;->h:Z

    .line 86
    .line 87
    iput-boolean p1, p0, Lik1;->i:Z

    .line 88
    .line 89
    if-eqz v0, :cond_9

    .line 90
    .line 91
    invoke-virtual {p0}, Lik1;->a()Landroid/view/inputmethod/CursorAnchorInfo;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    if-eqz p1, :cond_9

    .line 96
    .line 97
    iget-object v0, p0, Lik1;->c:Lar;

    .line 98
    .line 99
    invoke-virtual {v0}, Lar;->F()Landroid/view/inputmethod/InputMethodManager;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    iget-object v0, v0, Lar;->i:Ljava/lang/Object;

    .line 104
    .line 105
    check-cast v0, Landroid/view/View;

    .line 106
    .line 107
    invoke-virtual {v1, v0, p1}, Landroid/view/inputmethod/InputMethodManager;->updateCursorAnchorInfo(Landroid/view/View;Landroid/view/inputmethod/CursorAnchorInfo;)V

    .line 108
    .line 109
    .line 110
    :cond_9
    iget-object p1, p0, Lik1;->e:Lzy6;

    .line 111
    .line 112
    const/4 v0, 0x0

    .line 113
    if-eqz v3, :cond_b

    .line 114
    .line 115
    if-eqz p1, :cond_a

    .line 116
    .line 117
    invoke-virtual {p1}, Lfd3;->b()Z

    .line 118
    .line 119
    .line 120
    move-result p1

    .line 121
    if-ne p1, v2, :cond_a

    .line 122
    .line 123
    return v2

    .line 124
    :cond_a
    iget-object p1, p0, Lik1;->d:Ljj1;

    .line 125
    .line 126
    new-instance v1, Ly3;

    .line 127
    .line 128
    const/16 v3, 0x9

    .line 129
    .line 130
    invoke-direct {v1, p0, v0, v3}, Ly3;-><init>(Ljava/lang/Object;Lxd1;B)V

    .line 131
    .line 132
    .line 133
    sget-object v3, Lmj1;->k:Lmj1;

    .line 134
    .line 135
    invoke-static {p1, v0, v3, v1, v2}, Lbw;->R(Ljj1;Le3;Lmj1;Lai2;I)Lzy6;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    iput-object p1, p0, Lik1;->e:Lzy6;

    .line 140
    .line 141
    return v2

    .line 142
    :cond_b
    if-eqz p1, :cond_c

    .line 143
    .line 144
    invoke-virtual {p1, v0}, Lfd3;->c(Ljava/util/concurrent/CancellationException;)V

    .line 145
    .line 146
    .line 147
    :cond_c
    iput-object v0, p0, Lik1;->e:Lzy6;

    .line 148
    .line 149
    return v2
.end method

.method public final sendKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 1

    .line 1
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 5
    .line 6
    iget-object p0, p0, Ljf;->d:Lar;

    .line 7
    .line 8
    invoke-virtual {p0}, Lar;->F()Landroid/view/inputmethod/InputMethodManager;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object p0, p0, Lar;->i:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p0, Landroid/view/View;

    .line 15
    .line 16
    invoke-virtual {v0, p0, p1}, Landroid/view/inputmethod/InputMethodManager;->dispatchKeyEventFromInputMethod(Landroid/view/View;Landroid/view/KeyEvent;)V

    .line 17
    .line 18
    .line 19
    const/4 p0, 0x1

    .line 20
    return p0
.end method

.method public final setComposingRegion(II)Z
    .locals 2

    .line 1
    new-instance v0, Lq53;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 5
    .line 6
    invoke-direct {v0, p1, p2, p0, v1}, Lq53;-><init>(IILo53;B)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, v0}, Ljf;->d(Lwh2;)V

    .line 10
    .line 11
    .line 12
    const/4 p0, 0x1

    .line 13
    return p0
.end method

.method public final setComposingText(Ljava/lang/CharSequence;I)Z
    .locals 34

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    return v1

    .line 10
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    instance-of v3, v0, Landroid/text/Spanned;

    .line 15
    .line 16
    const/4 v4, 0x0

    .line 17
    if-eqz v3, :cond_1

    .line 18
    .line 19
    check-cast v0, Landroid/text/Spanned;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_1
    move-object v0, v4

    .line 23
    :goto_0
    const/4 v3, 0x0

    .line 24
    if-eqz v0, :cond_14

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    const-class v6, Ljava/lang/Object;

    .line 31
    .line 32
    invoke-interface {v0, v3, v5, v6}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    array-length v6, v5

    .line 37
    move v7, v3

    .line 38
    move-object v8, v4

    .line 39
    :goto_1
    if-ge v7, v6, :cond_13

    .line 40
    .line 41
    aget-object v9, v5, v7

    .line 42
    .line 43
    instance-of v10, v9, Landroid/text/style/BackgroundColorSpan;

    .line 44
    .line 45
    const/16 v11, 0x20

    .line 46
    .line 47
    if-eqz v10, :cond_2

    .line 48
    .line 49
    new-instance v12, Lox6;

    .line 50
    .line 51
    move-object v10, v9

    .line 52
    check-cast v10, Landroid/text/style/BackgroundColorSpan;

    .line 53
    .line 54
    invoke-virtual {v10}, Landroid/text/style/BackgroundColorSpan;->getBackgroundColor()I

    .line 55
    .line 56
    .line 57
    move-result v10

    .line 58
    int-to-long v13, v10

    .line 59
    shl-long v27, v13, v11

    .line 60
    .line 61
    const/16 v30, 0x0

    .line 62
    .line 63
    const v31, 0xf7ff

    .line 64
    .line 65
    .line 66
    const-wide/16 v13, 0x0

    .line 67
    .line 68
    const-wide/16 v15, 0x0

    .line 69
    .line 70
    const/16 v17, 0x0

    .line 71
    .line 72
    const/16 v18, 0x0

    .line 73
    .line 74
    const/16 v19, 0x0

    .line 75
    .line 76
    const/16 v20, 0x0

    .line 77
    .line 78
    const/16 v21, 0x0

    .line 79
    .line 80
    const-wide/16 v22, 0x0

    .line 81
    .line 82
    const/16 v24, 0x0

    .line 83
    .line 84
    const/16 v25, 0x0

    .line 85
    .line 86
    const/16 v26, 0x0

    .line 87
    .line 88
    const/16 v29, 0x0

    .line 89
    .line 90
    invoke-direct/range {v12 .. v31}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 91
    .line 92
    .line 93
    goto/16 :goto_5

    .line 94
    .line 95
    :cond_2
    instance-of v10, v9, Landroid/text/style/ForegroundColorSpan;

    .line 96
    .line 97
    if-eqz v10, :cond_3

    .line 98
    .line 99
    new-instance v12, Lox6;

    .line 100
    .line 101
    move-object v10, v9

    .line 102
    check-cast v10, Landroid/text/style/ForegroundColorSpan;

    .line 103
    .line 104
    invoke-virtual {v10}, Landroid/text/style/ForegroundColorSpan;->getForegroundColor()I

    .line 105
    .line 106
    .line 107
    move-result v10

    .line 108
    int-to-long v13, v10

    .line 109
    shl-long/2addr v13, v11

    .line 110
    const/16 v30, 0x0

    .line 111
    .line 112
    const v31, 0xfffe

    .line 113
    .line 114
    .line 115
    const-wide/16 v15, 0x0

    .line 116
    .line 117
    const/16 v17, 0x0

    .line 118
    .line 119
    const/16 v18, 0x0

    .line 120
    .line 121
    const/16 v19, 0x0

    .line 122
    .line 123
    const/16 v20, 0x0

    .line 124
    .line 125
    const/16 v21, 0x0

    .line 126
    .line 127
    const-wide/16 v22, 0x0

    .line 128
    .line 129
    const/16 v24, 0x0

    .line 130
    .line 131
    const/16 v25, 0x0

    .line 132
    .line 133
    const/16 v26, 0x0

    .line 134
    .line 135
    const-wide/16 v27, 0x0

    .line 136
    .line 137
    const/16 v29, 0x0

    .line 138
    .line 139
    invoke-direct/range {v12 .. v31}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 140
    .line 141
    .line 142
    goto/16 :goto_5

    .line 143
    .line 144
    :cond_3
    instance-of v10, v9, Landroid/text/style/StrikethroughSpan;

    .line 145
    .line 146
    if-eqz v10, :cond_4

    .line 147
    .line 148
    new-instance v11, Lox6;

    .line 149
    .line 150
    const/16 v29, 0x0

    .line 151
    .line 152
    const v30, 0xefff

    .line 153
    .line 154
    .line 155
    const-wide/16 v12, 0x0

    .line 156
    .line 157
    const-wide/16 v14, 0x0

    .line 158
    .line 159
    const/16 v16, 0x0

    .line 160
    .line 161
    const/16 v17, 0x0

    .line 162
    .line 163
    const/16 v18, 0x0

    .line 164
    .line 165
    const/16 v19, 0x0

    .line 166
    .line 167
    const/16 v20, 0x0

    .line 168
    .line 169
    const-wide/16 v21, 0x0

    .line 170
    .line 171
    const/16 v23, 0x0

    .line 172
    .line 173
    const/16 v24, 0x0

    .line 174
    .line 175
    const/16 v25, 0x0

    .line 176
    .line 177
    const-wide/16 v26, 0x0

    .line 178
    .line 179
    sget-object v28, Lvb7;->d:Lvb7;

    .line 180
    .line 181
    invoke-direct/range {v11 .. v30}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 182
    .line 183
    .line 184
    :goto_2
    move-object v12, v11

    .line 185
    goto/16 :goto_5

    .line 186
    .line 187
    :cond_4
    instance-of v10, v9, Landroid/text/style/StyleSpan;

    .line 188
    .line 189
    if-eqz v10, :cond_7

    .line 190
    .line 191
    move-object v10, v9

    .line 192
    check-cast v10, Landroid/text/style/StyleSpan;

    .line 193
    .line 194
    invoke-virtual {v10}, Landroid/text/style/StyleSpan;->getStyle()I

    .line 195
    .line 196
    .line 197
    move-result v10

    .line 198
    if-eq v10, v1, :cond_6

    .line 199
    .line 200
    const/4 v11, 0x2

    .line 201
    if-eq v10, v11, :cond_5

    .line 202
    .line 203
    const/4 v11, 0x3

    .line 204
    if-ne v10, v11, :cond_10

    .line 205
    .line 206
    new-instance v12, Lox6;

    .line 207
    .line 208
    sget-object v17, Lhg2;->m:Lhg2;

    .line 209
    .line 210
    new-instance v10, Lfg2;

    .line 211
    .line 212
    invoke-direct {v10, v1}, Lfg2;-><init>(I)V

    .line 213
    .line 214
    .line 215
    const/16 v30, 0x0

    .line 216
    .line 217
    const v31, 0xfff3

    .line 218
    .line 219
    .line 220
    const-wide/16 v13, 0x0

    .line 221
    .line 222
    const-wide/16 v15, 0x0

    .line 223
    .line 224
    const/16 v19, 0x0

    .line 225
    .line 226
    const/16 v20, 0x0

    .line 227
    .line 228
    const/16 v21, 0x0

    .line 229
    .line 230
    const-wide/16 v22, 0x0

    .line 231
    .line 232
    const/16 v24, 0x0

    .line 233
    .line 234
    const/16 v25, 0x0

    .line 235
    .line 236
    const/16 v26, 0x0

    .line 237
    .line 238
    const-wide/16 v27, 0x0

    .line 239
    .line 240
    const/16 v29, 0x0

    .line 241
    .line 242
    move-object/from16 v18, v10

    .line 243
    .line 244
    invoke-direct/range {v12 .. v31}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 245
    .line 246
    .line 247
    goto/16 :goto_5

    .line 248
    .line 249
    :cond_5
    new-instance v13, Lox6;

    .line 250
    .line 251
    new-instance v10, Lfg2;

    .line 252
    .line 253
    invoke-direct {v10, v1}, Lfg2;-><init>(I)V

    .line 254
    .line 255
    .line 256
    const/16 v31, 0x0

    .line 257
    .line 258
    const v32, 0xfff7

    .line 259
    .line 260
    .line 261
    const-wide/16 v14, 0x0

    .line 262
    .line 263
    const-wide/16 v16, 0x0

    .line 264
    .line 265
    const/16 v18, 0x0

    .line 266
    .line 267
    const/16 v20, 0x0

    .line 268
    .line 269
    const/16 v21, 0x0

    .line 270
    .line 271
    const/16 v22, 0x0

    .line 272
    .line 273
    const-wide/16 v23, 0x0

    .line 274
    .line 275
    const/16 v25, 0x0

    .line 276
    .line 277
    const/16 v26, 0x0

    .line 278
    .line 279
    const/16 v27, 0x0

    .line 280
    .line 281
    const-wide/16 v28, 0x0

    .line 282
    .line 283
    const/16 v30, 0x0

    .line 284
    .line 285
    move-object/from16 v19, v10

    .line 286
    .line 287
    invoke-direct/range {v13 .. v32}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 288
    .line 289
    .line 290
    move-object v12, v13

    .line 291
    goto/16 :goto_5

    .line 292
    .line 293
    :cond_6
    new-instance v14, Lox6;

    .line 294
    .line 295
    sget-object v19, Lhg2;->m:Lhg2;

    .line 296
    .line 297
    const/16 v32, 0x0

    .line 298
    .line 299
    const v33, 0xfffb

    .line 300
    .line 301
    .line 302
    const-wide/16 v15, 0x0

    .line 303
    .line 304
    const-wide/16 v17, 0x0

    .line 305
    .line 306
    const/16 v20, 0x0

    .line 307
    .line 308
    const/16 v21, 0x0

    .line 309
    .line 310
    const/16 v22, 0x0

    .line 311
    .line 312
    const/16 v23, 0x0

    .line 313
    .line 314
    const-wide/16 v24, 0x0

    .line 315
    .line 316
    const/16 v26, 0x0

    .line 317
    .line 318
    const/16 v27, 0x0

    .line 319
    .line 320
    const/16 v28, 0x0

    .line 321
    .line 322
    const-wide/16 v29, 0x0

    .line 323
    .line 324
    const/16 v31, 0x0

    .line 325
    .line 326
    invoke-direct/range {v14 .. v33}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 327
    .line 328
    .line 329
    move-object v12, v14

    .line 330
    goto/16 :goto_5

    .line 331
    .line 332
    :cond_7
    instance-of v10, v9, Landroid/text/style/TypefaceSpan;

    .line 333
    .line 334
    if-eqz v10, :cond_f

    .line 335
    .line 336
    move-object v10, v9

    .line 337
    check-cast v10, Landroid/text/style/TypefaceSpan;

    .line 338
    .line 339
    invoke-virtual {v10}, Landroid/text/style/TypefaceSpan;->getFamily()Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v11

    .line 343
    const-string v12, "cursive"

    .line 344
    .line 345
    invoke-static {v11, v12}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 346
    .line 347
    .line 348
    move-result v12

    .line 349
    if-eqz v12, :cond_8

    .line 350
    .line 351
    sget-object v10, Lgf2;->e:Lij2;

    .line 352
    .line 353
    :goto_3
    move-object/from16 v19, v10

    .line 354
    .line 355
    goto :goto_4

    .line 356
    :cond_8
    const-string v12, "monospace"

    .line 357
    .line 358
    invoke-static {v11, v12}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 359
    .line 360
    .line 361
    move-result v12

    .line 362
    if-eqz v12, :cond_9

    .line 363
    .line 364
    sget-object v10, Lgf2;->d:Lij2;

    .line 365
    .line 366
    goto :goto_3

    .line 367
    :cond_9
    const-string v12, "sans-serif"

    .line 368
    .line 369
    invoke-static {v11, v12}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 370
    .line 371
    .line 372
    move-result v12

    .line 373
    if-eqz v12, :cond_a

    .line 374
    .line 375
    sget-object v10, Lgf2;->b:Lij2;

    .line 376
    .line 377
    goto :goto_3

    .line 378
    :cond_a
    const-string v12, "serif"

    .line 379
    .line 380
    invoke-static {v11, v12}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 381
    .line 382
    .line 383
    move-result v11

    .line 384
    if-eqz v11, :cond_b

    .line 385
    .line 386
    sget-object v10, Lgf2;->c:Lij2;

    .line 387
    .line 388
    goto :goto_3

    .line 389
    :cond_b
    invoke-virtual {v10}, Landroid/text/style/TypefaceSpan;->getFamily()Ljava/lang/String;

    .line 390
    .line 391
    .line 392
    move-result-object v10

    .line 393
    if-eqz v10, :cond_e

    .line 394
    .line 395
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 396
    .line 397
    .line 398
    move-result v11

    .line 399
    if-eqz v11, :cond_e

    .line 400
    .line 401
    invoke-static {v10, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 402
    .line 403
    .line 404
    move-result-object v10

    .line 405
    sget-object v11, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 406
    .line 407
    invoke-static {v10, v11}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 408
    .line 409
    .line 410
    move-result v12

    .line 411
    if-nez v12, :cond_c

    .line 412
    .line 413
    invoke-static {v11, v3}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 414
    .line 415
    .line 416
    move-result-object v11

    .line 417
    invoke-static {v10, v11}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    move-result v11

    .line 421
    if-eqz v11, :cond_d

    .line 422
    .line 423
    :cond_c
    move-object v10, v4

    .line 424
    :cond_d
    if-eqz v10, :cond_e

    .line 425
    .line 426
    new-instance v11, Lzy7;

    .line 427
    .line 428
    const/4 v12, 0x6

    .line 429
    invoke-direct {v11, v10, v12}, Lzy7;-><init>(Ljava/lang/Object;B)V

    .line 430
    .line 431
    .line 432
    new-instance v10, Lkt3;

    .line 433
    .line 434
    invoke-direct {v10, v11}, Lkt3;-><init>(Lzy7;)V

    .line 435
    .line 436
    .line 437
    goto :goto_3

    .line 438
    :cond_e
    move-object v10, v4

    .line 439
    goto :goto_3

    .line 440
    :goto_4
    new-instance v11, Lox6;

    .line 441
    .line 442
    const/16 v29, 0x0

    .line 443
    .line 444
    const v30, 0xffdf

    .line 445
    .line 446
    .line 447
    const-wide/16 v12, 0x0

    .line 448
    .line 449
    const-wide/16 v14, 0x0

    .line 450
    .line 451
    const/16 v16, 0x0

    .line 452
    .line 453
    const/16 v17, 0x0

    .line 454
    .line 455
    const/16 v18, 0x0

    .line 456
    .line 457
    const/16 v20, 0x0

    .line 458
    .line 459
    const-wide/16 v21, 0x0

    .line 460
    .line 461
    const/16 v23, 0x0

    .line 462
    .line 463
    const/16 v24, 0x0

    .line 464
    .line 465
    const/16 v25, 0x0

    .line 466
    .line 467
    const-wide/16 v26, 0x0

    .line 468
    .line 469
    const/16 v28, 0x0

    .line 470
    .line 471
    invoke-direct/range {v11 .. v30}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 472
    .line 473
    .line 474
    goto/16 :goto_2

    .line 475
    .line 476
    :cond_f
    instance-of v10, v9, Landroid/text/style/UnderlineSpan;

    .line 477
    .line 478
    if-eqz v10, :cond_10

    .line 479
    .line 480
    new-instance v11, Lox6;

    .line 481
    .line 482
    const/16 v29, 0x0

    .line 483
    .line 484
    const v30, 0xefff

    .line 485
    .line 486
    .line 487
    const-wide/16 v12, 0x0

    .line 488
    .line 489
    const-wide/16 v14, 0x0

    .line 490
    .line 491
    const/16 v16, 0x0

    .line 492
    .line 493
    const/16 v17, 0x0

    .line 494
    .line 495
    const/16 v18, 0x0

    .line 496
    .line 497
    const/16 v19, 0x0

    .line 498
    .line 499
    const/16 v20, 0x0

    .line 500
    .line 501
    const-wide/16 v21, 0x0

    .line 502
    .line 503
    const/16 v23, 0x0

    .line 504
    .line 505
    const/16 v24, 0x0

    .line 506
    .line 507
    const/16 v25, 0x0

    .line 508
    .line 509
    const-wide/16 v26, 0x0

    .line 510
    .line 511
    sget-object v28, Lvb7;->c:Lvb7;

    .line 512
    .line 513
    invoke-direct/range {v11 .. v30}, Lox6;-><init>(JJLhg2;Lfg2;Lgg2;Lgf2;Ljava/lang/String;JLm10;Lgf7;Lfu3;JLvb7;Lwn6;I)V

    .line 514
    .line 515
    .line 516
    goto/16 :goto_2

    .line 517
    .line 518
    :cond_10
    move-object v12, v4

    .line 519
    :goto_5
    if-eqz v12, :cond_12

    .line 520
    .line 521
    if-nez v8, :cond_11

    .line 522
    .line 523
    new-instance v8, Ljava/util/ArrayList;

    .line 524
    .line 525
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 526
    .line 527
    .line 528
    :cond_11
    new-instance v10, Lhj;

    .line 529
    .line 530
    invoke-interface {v0, v9}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 531
    .line 532
    .line 533
    move-result v11

    .line 534
    invoke-interface {v0, v9}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 535
    .line 536
    .line 537
    move-result v9

    .line 538
    invoke-direct {v10, v11, v9, v12}, Lhj;-><init>(IILjava/lang/Object;)V

    .line 539
    .line 540
    .line 541
    invoke-interface {v8, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 542
    .line 543
    .line 544
    :cond_12
    add-int/lit8 v7, v7, 0x1

    .line 545
    .line 546
    goto/16 :goto_1

    .line 547
    .line 548
    :cond_13
    move-object v4, v8

    .line 549
    :cond_14
    new-instance v0, Lol2;

    .line 550
    .line 551
    move/from16 v5, p2

    .line 552
    .line 553
    invoke-direct {v0, v2, v4, v5, v3}, Lol2;-><init>(Ljava/lang/String;Ljava/util/List;IZ)V

    .line 554
    .line 555
    .line 556
    move-object/from16 v2, p0

    .line 557
    .line 558
    iget-object v2, v2, Lb07;->a:Ljf;

    .line 559
    .line 560
    invoke-virtual {v2, v0}, Ljf;->d(Lwh2;)V

    .line 561
    .line 562
    .line 563
    return v1
.end method

.method public final setComposingText(Ljava/lang/CharSequence;ILandroid/view/inputmethod/TextAttribute;)Z
    .locals 3

    .line 564
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    invoke-static {p3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 565
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 566
    invoke-static {p3}, Lwk5;->p(Ljava/lang/Object;)Lwk5;

    move-result-object p3

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p3, :cond_0

    .line 567
    iget-object p3, p3, Lwk5;->i:Ljava/lang/Object;

    check-cast p3, Lqa7;

    invoke-interface {p3}, Lqa7;->a()Z

    move-result p3

    if-ne p3, v1, :cond_0

    move v0, v1

    .line 568
    :cond_0
    new-instance p3, Lol2;

    const/4 v2, 0x0

    invoke-direct {p3, p1, v2, p2, v0}, Lol2;-><init>(Ljava/lang/String;Ljava/util/List;IZ)V

    iget-object p0, p0, Lb07;->a:Ljf;

    invoke-virtual {p0, p3}, Ljf;->d(Lwh2;)V

    return v1
.end method

.method public final setSelection(II)Z
    .locals 1

    .line 1
    new-instance v0, Lq53;

    .line 2
    .line 3
    iget-object p0, p0, Lb07;->a:Ljf;

    .line 4
    .line 5
    invoke-direct {v0, p0, p1, p2}, Lq53;-><init>(Lo53;II)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, v0}, Ljf;->d(Lwh2;)V

    .line 9
    .line 10
    .line 11
    iget-object p0, p0, Ljf;->l:Lqc7;

    .line 12
    .line 13
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 14
    .line 15
    invoke-virtual {p0, p1}, Lqc7;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    const/4 p0, 0x1

    .line 19
    return p0
.end method
