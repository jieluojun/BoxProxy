.class public final synthetic Lam;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lwk;

.field public final synthetic j:Lwh2;


# direct methods
.method public synthetic constructor <init>(BLwk;Lwh2;)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lam;->h:B

    .line 2
    .line 3
    iput-object p2, p0, Lam;->i:Lwk;

    .line 4
    .line 5
    iput-object p3, p0, Lam;->j:Lwh2;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lam;->h:B

    .line 4
    .line 5
    const/high16 v2, 0x3f800000    # 1.0f

    .line 6
    .line 7
    const v3, 0x7f0f01c7

    .line 8
    .line 9
    .line 10
    const v4, 0x7f0f01b8

    .line 11
    .line 12
    .line 13
    const v5, 0x7f0f01be

    .line 14
    .line 15
    .line 16
    const v6, 0x7f0f01ba

    .line 17
    .line 18
    .line 19
    sget-object v7, Lya4;->h:Lya4;

    .line 20
    .line 21
    sget-object v8, Lc51;->a:Lql0;

    .line 22
    .line 23
    sget-object v9, Lst7;->a:Lst7;

    .line 24
    .line 25
    const/16 v10, 0x10

    .line 26
    .line 27
    const/4 v11, 0x0

    .line 28
    const/4 v12, 0x1

    .line 29
    iget-object v13, v0, Lam;->j:Lwh2;

    .line 30
    .line 31
    iget-object v0, v0, Lam;->i:Lwk;

    .line 32
    .line 33
    packed-switch v1, :pswitch_data_0

    .line 34
    .line 35
    .line 36
    move-object/from16 v1, p1

    .line 37
    .line 38
    check-cast v1, Lli;

    .line 39
    .line 40
    move-object/from16 v2, p2

    .line 41
    .line 42
    check-cast v2, Lzi2;

    .line 43
    .line 44
    move-object/from16 v14, p3

    .line 45
    .line 46
    check-cast v14, Ljava/lang/Integer;

    .line 47
    .line 48
    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    .line 49
    .line 50
    .line 51
    move-result v14

    .line 52
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    and-int/lit8 v1, v14, 0x11

    .line 56
    .line 57
    if-eq v1, v10, :cond_0

    .line 58
    .line 59
    move v1, v12

    .line 60
    goto :goto_0

    .line 61
    :cond_0
    move v1, v11

    .line 62
    :goto_0
    and-int/2addr v14, v12

    .line 63
    invoke-virtual {v2, v14, v1}, Lzi2;->Y(IZ)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_6

    .line 68
    .line 69
    sget-object v1, Lob3;->g:Llw;

    .line 70
    .line 71
    sget-object v10, Ly6;->v:Lz30;

    .line 72
    .line 73
    invoke-static {v1, v10, v2, v11}, Lm01;->a(Low;Lz30;Lzi2;I)Lo01;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    iget-wide v10, v2, Lzi2;->U:J

    .line 78
    .line 79
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 80
    .line 81
    .line 82
    move-result v10

    .line 83
    invoke-virtual {v2}, Lzi2;->m()Lla5;

    .line 84
    .line 85
    .line 86
    move-result-object v11

    .line 87
    invoke-static {v2, v7}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 88
    .line 89
    .line 90
    move-result-object v7

    .line 91
    sget-object v14, Ls41;->d:Ly6;

    .line 92
    .line 93
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v2}, Lzi2;->k0()V

    .line 97
    .line 98
    .line 99
    iget-boolean v14, v2, Lzi2;->T:Z

    .line 100
    .line 101
    if-eqz v14, :cond_1

    .line 102
    .line 103
    sget-object v14, Lzi3;->Z:Lu43;

    .line 104
    .line 105
    invoke-virtual {v2, v14}, Lzi2;->l(Llh2;)V

    .line 106
    .line 107
    .line 108
    goto :goto_1

    .line 109
    :cond_1
    invoke-virtual {v2}, Lzi2;->t0()V

    .line 110
    .line 111
    .line 112
    :goto_1
    sget-object v14, Ly6;->T:Lx31;

    .line 113
    .line 114
    invoke-static {v14, v2, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    sget-object v1, Ly6;->S:Lx31;

    .line 118
    .line 119
    invoke-static {v1, v2, v11}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    sget-object v10, Ly6;->U:Lx31;

    .line 127
    .line 128
    invoke-static {v10, v2, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    invoke-static {v2}, Lfa7;->k(Lzi2;)V

    .line 132
    .line 133
    .line 134
    sget-object v1, Ly6;->R:Lx31;

    .line 135
    .line 136
    invoke-static {v1, v2, v7}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    invoke-static {v6, v2}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v14

    .line 143
    iget v15, v0, Lwk;->j:I

    .line 144
    .line 145
    sget-object v1, Lns0;->a:Ljava/util/List;

    .line 146
    .line 147
    invoke-static {v5, v2, v1}, Lp80;->t(ILzi2;Ljava/util/List;)Lwr3;

    .line 148
    .line 149
    .line 150
    move-result-object v17

    .line 151
    invoke-virtual {v2, v13}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result v5

    .line 155
    invoke-virtual {v2, v0}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    move-result v6

    .line 159
    or-int/2addr v5, v6

    .line 160
    invoke-virtual {v2}, Lzi2;->T()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v6

    .line 164
    if-nez v5, :cond_2

    .line 165
    .line 166
    if-ne v6, v8, :cond_3

    .line 167
    .line 168
    :cond_2
    new-instance v6, Lpl;

    .line 169
    .line 170
    const/16 v5, 0xe

    .line 171
    .line 172
    invoke-direct {v6, v5, v0, v13}, Lpl;-><init>(BLwk;Lwh2;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v2, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    :cond_3
    move-object/from16 v18, v6

    .line 179
    .line 180
    check-cast v18, Lwh2;

    .line 181
    .line 182
    const/16 v20, 0x0

    .line 183
    .line 184
    move-object/from16 v16, v1

    .line 185
    .line 186
    move-object/from16 v19, v2

    .line 187
    .line 188
    invoke-static/range {v14 .. v20}, Lbx;->n(Ljava/lang/String;ILjava/util/List;Lwr3;Lwh2;Lzi2;I)V

    .line 189
    .line 190
    .line 191
    move-object/from16 v1, v19

    .line 192
    .line 193
    invoke-static {v4, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v14

    .line 197
    iget v15, v0, Lwk;->k:I

    .line 198
    .line 199
    sget-object v2, Lns0;->b:Ljava/util/List;

    .line 200
    .line 201
    invoke-static {v3, v1, v2}, Lp80;->t(ILzi2;Ljava/util/List;)Lwr3;

    .line 202
    .line 203
    .line 204
    move-result-object v17

    .line 205
    invoke-virtual {v1, v13}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result v3

    .line 209
    invoke-virtual {v1, v0}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 210
    .line 211
    .line 212
    move-result v4

    .line 213
    or-int/2addr v3, v4

    .line 214
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v4

    .line 218
    if-nez v3, :cond_4

    .line 219
    .line 220
    if-ne v4, v8, :cond_5

    .line 221
    .line 222
    :cond_4
    new-instance v4, Lpl;

    .line 223
    .line 224
    const/16 v3, 0xf

    .line 225
    .line 226
    invoke-direct {v4, v3, v0, v13}, Lpl;-><init>(BLwk;Lwh2;)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v1, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    :cond_5
    move-object/from16 v18, v4

    .line 233
    .line 234
    check-cast v18, Lwh2;

    .line 235
    .line 236
    const/16 v20, 0x0

    .line 237
    .line 238
    move-object/from16 v19, v1

    .line 239
    .line 240
    move-object/from16 v16, v2

    .line 241
    .line 242
    invoke-static/range {v14 .. v20}, Lbx;->n(Ljava/lang/String;ILjava/util/List;Lwr3;Lwh2;Lzi2;I)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v1, v12}, Lzi2;->r(Z)V

    .line 246
    .line 247
    .line 248
    goto :goto_2

    .line 249
    :cond_6
    move-object v1, v2

    .line 250
    invoke-virtual {v1}, Lzi2;->b0()V

    .line 251
    .line 252
    .line 253
    :goto_2
    return-object v9

    .line 254
    :pswitch_0
    move-object/from16 v1, p1

    .line 255
    .line 256
    check-cast v1, Lli;

    .line 257
    .line 258
    move-object/from16 v3, p2

    .line 259
    .line 260
    check-cast v3, Lzi2;

    .line 261
    .line 262
    move-object/from16 v4, p3

    .line 263
    .line 264
    check-cast v4, Ljava/lang/Integer;

    .line 265
    .line 266
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 267
    .line 268
    .line 269
    move-result v4

    .line 270
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 271
    .line 272
    .line 273
    and-int/lit8 v1, v4, 0x11

    .line 274
    .line 275
    if-eq v1, v10, :cond_7

    .line 276
    .line 277
    move v11, v12

    .line 278
    :cond_7
    and-int/2addr v4, v12

    .line 279
    invoke-virtual {v3, v4, v11}, Lzi2;->Y(IZ)Z

    .line 280
    .line 281
    .line 282
    move-result v1

    .line 283
    if-eqz v1, :cond_8

    .line 284
    .line 285
    invoke-static {v7, v2}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 286
    .line 287
    .line 288
    move-result-object v14

    .line 289
    new-instance v1, Lyl;

    .line 290
    .line 291
    const/4 v2, 0x5

    .line 292
    invoke-direct {v1, v2, v0, v13}, Lyl;-><init>(BLwk;Lwh2;)V

    .line 293
    .line 294
    .line 295
    const v0, 0x6dd80356

    .line 296
    .line 297
    .line 298
    invoke-static {v0, v1, v3}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 299
    .line 300
    .line 301
    move-result-object v17

    .line 302
    const/16 v19, 0x186

    .line 303
    .line 304
    const/16 v20, 0x2

    .line 305
    .line 306
    const-wide/16 v15, 0x0

    .line 307
    .line 308
    move-object/from16 v18, v3

    .line 309
    .line 310
    invoke-static/range {v14 .. v20}, Lb14;->g(Lbb4;JLs21;Lzi2;II)V

    .line 311
    .line 312
    .line 313
    goto :goto_3

    .line 314
    :cond_8
    move-object/from16 v18, v3

    .line 315
    .line 316
    invoke-virtual/range {v18 .. v18}, Lzi2;->b0()V

    .line 317
    .line 318
    .line 319
    :goto_3
    return-object v9

    .line 320
    :pswitch_1
    move-object/from16 v1, p1

    .line 321
    .line 322
    check-cast v1, Lli;

    .line 323
    .line 324
    move-object/from16 v2, p2

    .line 325
    .line 326
    check-cast v2, Lzi2;

    .line 327
    .line 328
    move-object/from16 v3, p3

    .line 329
    .line 330
    check-cast v3, Ljava/lang/Integer;

    .line 331
    .line 332
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 333
    .line 334
    .line 335
    move-result v3

    .line 336
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 337
    .line 338
    .line 339
    and-int/lit8 v1, v3, 0x11

    .line 340
    .line 341
    if-eq v1, v10, :cond_9

    .line 342
    .line 343
    move v11, v12

    .line 344
    :cond_9
    and-int/2addr v3, v12

    .line 345
    invoke-virtual {v2, v3, v11}, Lzi2;->Y(IZ)Z

    .line 346
    .line 347
    .line 348
    move-result v1

    .line 349
    if-eqz v1, :cond_c

    .line 350
    .line 351
    invoke-static {v6, v2}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 352
    .line 353
    .line 354
    move-result-object v14

    .line 355
    iget v15, v0, Lwk;->j:I

    .line 356
    .line 357
    sget-object v1, Lns0;->a:Ljava/util/List;

    .line 358
    .line 359
    invoke-static {v5, v2, v1}, Lp80;->t(ILzi2;Ljava/util/List;)Lwr3;

    .line 360
    .line 361
    .line 362
    move-result-object v17

    .line 363
    invoke-virtual {v2, v13}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 364
    .line 365
    .line 366
    move-result v3

    .line 367
    invoke-virtual {v2, v0}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 368
    .line 369
    .line 370
    move-result v4

    .line 371
    or-int/2addr v3, v4

    .line 372
    invoke-virtual {v2}, Lzi2;->T()Ljava/lang/Object;

    .line 373
    .line 374
    .line 375
    move-result-object v4

    .line 376
    if-nez v3, :cond_a

    .line 377
    .line 378
    if-ne v4, v8, :cond_b

    .line 379
    .line 380
    :cond_a
    new-instance v4, Lpl;

    .line 381
    .line 382
    const/16 v3, 0x9

    .line 383
    .line 384
    invoke-direct {v4, v3, v0, v13}, Lpl;-><init>(BLwk;Lwh2;)V

    .line 385
    .line 386
    .line 387
    invoke-virtual {v2, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 388
    .line 389
    .line 390
    :cond_b
    move-object/from16 v18, v4

    .line 391
    .line 392
    check-cast v18, Lwh2;

    .line 393
    .line 394
    const/16 v20, 0x0

    .line 395
    .line 396
    move-object/from16 v16, v1

    .line 397
    .line 398
    move-object/from16 v19, v2

    .line 399
    .line 400
    invoke-static/range {v14 .. v20}, Ldy3;->l(Ljava/lang/String;ILjava/util/List;Lwr3;Lwh2;Lzi2;I)V

    .line 401
    .line 402
    .line 403
    goto :goto_4

    .line 404
    :cond_c
    move-object/from16 v19, v2

    .line 405
    .line 406
    invoke-virtual/range {v19 .. v19}, Lzi2;->b0()V

    .line 407
    .line 408
    .line 409
    :goto_4
    return-object v9

    .line 410
    :pswitch_2
    move-object/from16 v1, p1

    .line 411
    .line 412
    check-cast v1, Lli;

    .line 413
    .line 414
    move-object/from16 v3, p2

    .line 415
    .line 416
    check-cast v3, Lzi2;

    .line 417
    .line 418
    move-object/from16 v4, p3

    .line 419
    .line 420
    check-cast v4, Ljava/lang/Integer;

    .line 421
    .line 422
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 423
    .line 424
    .line 425
    move-result v4

    .line 426
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 427
    .line 428
    .line 429
    and-int/lit8 v1, v4, 0x11

    .line 430
    .line 431
    if-eq v1, v10, :cond_d

    .line 432
    .line 433
    move v11, v12

    .line 434
    :cond_d
    and-int/2addr v4, v12

    .line 435
    invoke-virtual {v3, v4, v11}, Lzi2;->Y(IZ)Z

    .line 436
    .line 437
    .line 438
    move-result v1

    .line 439
    if-eqz v1, :cond_e

    .line 440
    .line 441
    invoke-static {v7, v2}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 442
    .line 443
    .line 444
    move-result-object v14

    .line 445
    new-instance v1, Lyl;

    .line 446
    .line 447
    const/4 v2, 0x4

    .line 448
    invoke-direct {v1, v2, v0, v13}, Lyl;-><init>(BLwk;Lwh2;)V

    .line 449
    .line 450
    .line 451
    const v0, -0x48c3f42b

    .line 452
    .line 453
    .line 454
    invoke-static {v0, v1, v3}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 455
    .line 456
    .line 457
    move-result-object v17

    .line 458
    const/16 v19, 0x186

    .line 459
    .line 460
    const/16 v20, 0x2

    .line 461
    .line 462
    const-wide/16 v15, 0x0

    .line 463
    .line 464
    move-object/from16 v18, v3

    .line 465
    .line 466
    invoke-static/range {v14 .. v20}, Lb14;->g(Lbb4;JLs21;Lzi2;II)V

    .line 467
    .line 468
    .line 469
    goto :goto_5

    .line 470
    :cond_e
    move-object/from16 v18, v3

    .line 471
    .line 472
    invoke-virtual/range {v18 .. v18}, Lzi2;->b0()V

    .line 473
    .line 474
    .line 475
    :goto_5
    return-object v9

    .line 476
    :pswitch_3
    move-object/from16 v1, p1

    .line 477
    .line 478
    check-cast v1, Lli;

    .line 479
    .line 480
    move-object/from16 v2, p2

    .line 481
    .line 482
    check-cast v2, Lzi2;

    .line 483
    .line 484
    move-object/from16 v5, p3

    .line 485
    .line 486
    check-cast v5, Ljava/lang/Integer;

    .line 487
    .line 488
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 489
    .line 490
    .line 491
    move-result v5

    .line 492
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 493
    .line 494
    .line 495
    and-int/lit8 v1, v5, 0x11

    .line 496
    .line 497
    if-eq v1, v10, :cond_f

    .line 498
    .line 499
    move v11, v12

    .line 500
    :cond_f
    and-int/2addr v5, v12

    .line 501
    invoke-virtual {v2, v5, v11}, Lzi2;->Y(IZ)Z

    .line 502
    .line 503
    .line 504
    move-result v1

    .line 505
    if-eqz v1, :cond_12

    .line 506
    .line 507
    invoke-static {v4, v2}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 508
    .line 509
    .line 510
    move-result-object v14

    .line 511
    iget v15, v0, Lwk;->k:I

    .line 512
    .line 513
    sget-object v1, Lns0;->b:Ljava/util/List;

    .line 514
    .line 515
    invoke-static {v3, v2, v1}, Lp80;->t(ILzi2;Ljava/util/List;)Lwr3;

    .line 516
    .line 517
    .line 518
    move-result-object v17

    .line 519
    invoke-virtual {v2, v13}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 520
    .line 521
    .line 522
    move-result v3

    .line 523
    invoke-virtual {v2, v0}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 524
    .line 525
    .line 526
    move-result v4

    .line 527
    or-int/2addr v3, v4

    .line 528
    invoke-virtual {v2}, Lzi2;->T()Ljava/lang/Object;

    .line 529
    .line 530
    .line 531
    move-result-object v4

    .line 532
    if-nez v3, :cond_10

    .line 533
    .line 534
    if-ne v4, v8, :cond_11

    .line 535
    .line 536
    :cond_10
    new-instance v4, Lpl;

    .line 537
    .line 538
    const/16 v3, 0x8

    .line 539
    .line 540
    invoke-direct {v4, v3, v0, v13}, Lpl;-><init>(BLwk;Lwh2;)V

    .line 541
    .line 542
    .line 543
    invoke-virtual {v2, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 544
    .line 545
    .line 546
    :cond_11
    move-object/from16 v18, v4

    .line 547
    .line 548
    check-cast v18, Lwh2;

    .line 549
    .line 550
    const/16 v20, 0x0

    .line 551
    .line 552
    move-object/from16 v16, v1

    .line 553
    .line 554
    move-object/from16 v19, v2

    .line 555
    .line 556
    invoke-static/range {v14 .. v20}, Ldy3;->l(Ljava/lang/String;ILjava/util/List;Lwr3;Lwh2;Lzi2;I)V

    .line 557
    .line 558
    .line 559
    goto :goto_6

    .line 560
    :cond_12
    move-object/from16 v19, v2

    .line 561
    .line 562
    invoke-virtual/range {v19 .. v19}, Lzi2;->b0()V

    .line 563
    .line 564
    .line 565
    :goto_6
    return-object v9

    .line 566
    nop

    .line 567
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
