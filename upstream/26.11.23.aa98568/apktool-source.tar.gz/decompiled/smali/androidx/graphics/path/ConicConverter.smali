.class public final Landroidx/graphics/path/ConicConverter;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# direct methods
.method private final native internalConicToQuadratics([FI[FFF)I
.end method
