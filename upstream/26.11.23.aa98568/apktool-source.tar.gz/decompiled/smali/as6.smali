.class public final synthetic Las6;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Las6;->h:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v0, v0, Las6;->h:B

    .line 4
    .line 5
    const-wide/16 v1, 0x0

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x0

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget-object v0, Lq92;->h:Ltf3;

    .line 13
    .line 14
    sget-object v1, Lq92;->i:Lr85;

    .line 15
    .line 16
    const-string v2, "coil3_disk_cache"

    .line 17
    .line 18
    invoke-virtual {v1, v2}, Lr85;->e(Ljava/lang/String;)Lr85;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-wide/32 v4, 0xa00000

    .line 23
    .line 24
    .line 25
    :try_start_0
    invoke-virtual {v1}, Lr85;->toFile()Ljava/io/File;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    invoke-virtual {v2}, Ljava/io/File;->mkdir()Z

    .line 30
    .line 31
    .line 32
    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    new-instance v3, Landroid/os/StatFs;

    .line 37
    .line 38
    invoke-direct {v3, v2}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v3}, Landroid/os/StatFs;->getBlockCountLong()J

    .line 42
    .line 43
    .line 44
    move-result-wide v6

    .line 45
    invoke-virtual {v3}, Landroid/os/StatFs;->getBlockSizeLong()J

    .line 46
    .line 47
    .line 48
    move-result-wide v2

    .line 49
    mul-long/2addr v2, v6

    .line 50
    long-to-double v2, v2

    .line 51
    const-wide v6, 0x3f947ae147ae147bL    # 0.02

    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    mul-double/2addr v6, v2

    .line 57
    double-to-long v2, v6

    .line 58
    const-wide/32 v6, 0xfa00000

    .line 59
    .line 60
    .line 61
    invoke-static/range {v2 .. v7}, Lej3;->x(JJJ)J

    .line 62
    .line 63
    .line 64
    move-result-wide v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 65
    :catch_0
    new-instance v2, Luu5;

    .line 66
    .line 67
    invoke-direct {v2, v4, v5, v0, v1}, Luu5;-><init>(JLtf3;Lr85;)V

    .line 68
    .line 69
    .line 70
    return-object v2

    .line 71
    :pswitch_0
    sget-object v0, Lh60;->i:Lh60;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_1
    sget-object v0, Lmn7;->i:Lmn7;

    .line 75
    .line 76
    return-object v0

    .line 77
    :pswitch_2
    sget-object v0, Lss7;->i:Luk7;

    .line 78
    .line 79
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    sget-object v0, Lss7;->j:Lss7;

    .line 83
    .line 84
    return-object v0

    .line 85
    :pswitch_3
    new-instance v0, Lkr7;

    .line 86
    .line 87
    invoke-direct {v0}, Lkr7;-><init>()V

    .line 88
    .line 89
    .line 90
    return-object v0

    .line 91
    :pswitch_4
    new-instance v0, Ljn7;

    .line 92
    .line 93
    const v1, -0x800001

    .line 94
    .line 95
    .line 96
    invoke-direct {v0, v1, v3, v3}, Ljn7;-><init>(FFF)V

    .line 97
    .line 98
    .line 99
    return-object v0

    .line 100
    :pswitch_5
    return-object v4

    .line 101
    :pswitch_6
    sget-object v0, Lo22;->h:Lo22;

    .line 102
    .line 103
    return-object v0

    .line 104
    :pswitch_7
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 105
    .line 106
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    return-object v0

    .line 111
    :pswitch_8
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 112
    .line 113
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    return-object v0

    .line 118
    :pswitch_9
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 119
    .line 120
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    return-object v0

    .line 125
    :pswitch_a
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 126
    .line 127
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    return-object v0

    .line 132
    :pswitch_b
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 133
    .line 134
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    return-object v0

    .line 139
    :pswitch_c
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 140
    .line 141
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    return-object v0

    .line 146
    :pswitch_d
    return-object v4

    .line 147
    :pswitch_e
    new-instance v1, Lbi7;

    .line 148
    .line 149
    const/16 v0, 0x11

    .line 150
    .line 151
    invoke-static {v0}, Lfa7;->f(I)J

    .line 152
    .line 153
    .line 154
    move-result-wide v4

    .line 155
    const-wide/16 v11, 0x0

    .line 156
    .line 157
    const v13, 0xfffffd

    .line 158
    .line 159
    .line 160
    const-wide/16 v2, 0x0

    .line 161
    .line 162
    const/4 v6, 0x0

    .line 163
    const-wide/16 v7, 0x0

    .line 164
    .line 165
    const/4 v9, 0x0

    .line 166
    const/4 v10, 0x0

    .line 167
    invoke-direct/range {v1 .. v13}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 168
    .line 169
    .line 170
    new-instance v2, Lbi7;

    .line 171
    .line 172
    invoke-static {v0}, Lfa7;->f(I)J

    .line 173
    .line 174
    .line 175
    move-result-wide v5

    .line 176
    const v0, 0x3f99999a    # 1.2f

    .line 177
    .line 178
    .line 179
    const-wide v3, 0x200000000L

    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    invoke-static {v0, v3, v4}, Lfa7;->i(FJ)J

    .line 185
    .line 186
    .line 187
    move-result-wide v12

    .line 188
    const v14, 0xfdfffd

    .line 189
    .line 190
    .line 191
    const-wide/16 v3, 0x0

    .line 192
    .line 193
    const/4 v7, 0x0

    .line 194
    const-wide/16 v8, 0x0

    .line 195
    .line 196
    const/4 v11, 0x0

    .line 197
    invoke-direct/range {v2 .. v14}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 198
    .line 199
    .line 200
    new-instance v3, Lbi7;

    .line 201
    .line 202
    const/16 v0, 0x10

    .line 203
    .line 204
    invoke-static {v0}, Lfa7;->f(I)J

    .line 205
    .line 206
    .line 207
    move-result-wide v6

    .line 208
    const-wide/16 v13, 0x0

    .line 209
    .line 210
    const v15, 0xfffffd

    .line 211
    .line 212
    .line 213
    const-wide/16 v4, 0x0

    .line 214
    .line 215
    const/4 v8, 0x0

    .line 216
    const-wide/16 v9, 0x0

    .line 217
    .line 218
    const/4 v12, 0x0

    .line 219
    invoke-direct/range {v3 .. v15}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 220
    .line 221
    .line 222
    new-instance v4, Lbi7;

    .line 223
    .line 224
    const/16 v0, 0xe

    .line 225
    .line 226
    invoke-static {v0}, Lfa7;->f(I)J

    .line 227
    .line 228
    .line 229
    move-result-wide v7

    .line 230
    const-wide/16 v14, 0x0

    .line 231
    .line 232
    const v16, 0xfffffd

    .line 233
    .line 234
    .line 235
    const-wide/16 v5, 0x0

    .line 236
    .line 237
    const/4 v9, 0x0

    .line 238
    const-wide/16 v10, 0x0

    .line 239
    .line 240
    const/4 v13, 0x0

    .line 241
    invoke-direct/range {v4 .. v16}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 242
    .line 243
    .line 244
    new-instance v5, Lbi7;

    .line 245
    .line 246
    const/16 v0, 0x11

    .line 247
    .line 248
    invoke-static {v0}, Lfa7;->f(I)J

    .line 249
    .line 250
    .line 251
    move-result-wide v8

    .line 252
    const-wide/16 v15, 0x0

    .line 253
    .line 254
    const v17, 0xfffffd

    .line 255
    .line 256
    .line 257
    const-wide/16 v6, 0x0

    .line 258
    .line 259
    const/4 v10, 0x0

    .line 260
    const-wide/16 v11, 0x0

    .line 261
    .line 262
    const/4 v14, 0x0

    .line 263
    invoke-direct/range {v5 .. v17}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 264
    .line 265
    .line 266
    new-instance v6, Lbi7;

    .line 267
    .line 268
    const/16 v0, 0xd

    .line 269
    .line 270
    invoke-static {v0}, Lfa7;->f(I)J

    .line 271
    .line 272
    .line 273
    move-result-wide v9

    .line 274
    const-wide/16 v16, 0x0

    .line 275
    .line 276
    const v18, 0xfffffd

    .line 277
    .line 278
    .line 279
    const-wide/16 v7, 0x0

    .line 280
    .line 281
    const/4 v11, 0x0

    .line 282
    const-wide/16 v12, 0x0

    .line 283
    .line 284
    const/4 v15, 0x0

    .line 285
    invoke-direct/range {v6 .. v18}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 286
    .line 287
    .line 288
    new-instance v7, Lbi7;

    .line 289
    .line 290
    const/16 v0, 0xb

    .line 291
    .line 292
    invoke-static {v0}, Lfa7;->f(I)J

    .line 293
    .line 294
    .line 295
    move-result-wide v10

    .line 296
    const-wide/16 v17, 0x0

    .line 297
    .line 298
    const v19, 0xfffffd

    .line 299
    .line 300
    .line 301
    const-wide/16 v8, 0x0

    .line 302
    .line 303
    const/4 v12, 0x0

    .line 304
    const-wide/16 v13, 0x0

    .line 305
    .line 306
    const/16 v16, 0x0

    .line 307
    .line 308
    invoke-direct/range {v7 .. v19}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 309
    .line 310
    .line 311
    new-instance v8, Lbi7;

    .line 312
    .line 313
    const/16 v0, 0x11

    .line 314
    .line 315
    invoke-static {v0}, Lfa7;->f(I)J

    .line 316
    .line 317
    .line 318
    move-result-wide v11

    .line 319
    const-wide/16 v18, 0x0

    .line 320
    .line 321
    const v20, 0xfffffd

    .line 322
    .line 323
    .line 324
    const-wide/16 v9, 0x0

    .line 325
    .line 326
    const/4 v13, 0x0

    .line 327
    const-wide/16 v14, 0x0

    .line 328
    .line 329
    const/16 v17, 0x0

    .line 330
    .line 331
    invoke-direct/range {v8 .. v20}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 332
    .line 333
    .line 334
    new-instance v9, Lbi7;

    .line 335
    .line 336
    const/16 v0, 0x10

    .line 337
    .line 338
    invoke-static {v0}, Lfa7;->f(I)J

    .line 339
    .line 340
    .line 341
    move-result-wide v12

    .line 342
    const-wide/16 v19, 0x0

    .line 343
    .line 344
    const v21, 0xfffffd

    .line 345
    .line 346
    .line 347
    const-wide/16 v10, 0x0

    .line 348
    .line 349
    const/4 v14, 0x0

    .line 350
    const-wide/16 v15, 0x0

    .line 351
    .line 352
    const/16 v18, 0x0

    .line 353
    .line 354
    invoke-direct/range {v9 .. v21}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 355
    .line 356
    .line 357
    new-instance v10, Lbi7;

    .line 358
    .line 359
    const/16 v0, 0xe

    .line 360
    .line 361
    invoke-static {v0}, Lfa7;->f(I)J

    .line 362
    .line 363
    .line 364
    move-result-wide v13

    .line 365
    sget-object v15, Lhg2;->m:Lhg2;

    .line 366
    .line 367
    const-wide/16 v20, 0x0

    .line 368
    .line 369
    const v22, 0xfffff9

    .line 370
    .line 371
    .line 372
    const-wide/16 v11, 0x0

    .line 373
    .line 374
    const-wide/16 v16, 0x0

    .line 375
    .line 376
    const/16 v19, 0x0

    .line 377
    .line 378
    invoke-direct/range {v10 .. v22}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 379
    .line 380
    .line 381
    new-instance v11, Lbi7;

    .line 382
    .line 383
    const/16 v0, 0x20

    .line 384
    .line 385
    invoke-static {v0}, Lfa7;->f(I)J

    .line 386
    .line 387
    .line 388
    move-result-wide v14

    .line 389
    const-wide/16 v21, 0x0

    .line 390
    .line 391
    const v23, 0xfffffd

    .line 392
    .line 393
    .line 394
    const-wide/16 v12, 0x0

    .line 395
    .line 396
    const/16 v16, 0x0

    .line 397
    .line 398
    const-wide/16 v17, 0x0

    .line 399
    .line 400
    const/16 v20, 0x0

    .line 401
    .line 402
    invoke-direct/range {v11 .. v23}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 403
    .line 404
    .line 405
    new-instance v12, Lbi7;

    .line 406
    .line 407
    const/16 v0, 0x18

    .line 408
    .line 409
    invoke-static {v0}, Lfa7;->f(I)J

    .line 410
    .line 411
    .line 412
    move-result-wide v15

    .line 413
    const-wide/16 v22, 0x0

    .line 414
    .line 415
    const v24, 0xfffffd

    .line 416
    .line 417
    .line 418
    const-wide/16 v13, 0x0

    .line 419
    .line 420
    const/16 v17, 0x0

    .line 421
    .line 422
    const-wide/16 v18, 0x0

    .line 423
    .line 424
    const/16 v21, 0x0

    .line 425
    .line 426
    invoke-direct/range {v12 .. v24}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 427
    .line 428
    .line 429
    new-instance v13, Lbi7;

    .line 430
    .line 431
    const/16 v0, 0x14

    .line 432
    .line 433
    invoke-static {v0}, Lfa7;->f(I)J

    .line 434
    .line 435
    .line 436
    move-result-wide v16

    .line 437
    const-wide/16 v23, 0x0

    .line 438
    .line 439
    const v25, 0xfffffd

    .line 440
    .line 441
    .line 442
    const-wide/16 v14, 0x0

    .line 443
    .line 444
    const/16 v18, 0x0

    .line 445
    .line 446
    const-wide/16 v19, 0x0

    .line 447
    .line 448
    const/16 v22, 0x0

    .line 449
    .line 450
    invoke-direct/range {v13 .. v25}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 451
    .line 452
    .line 453
    new-instance v15, Lbi7;

    .line 454
    .line 455
    const/16 v0, 0x12

    .line 456
    .line 457
    invoke-static {v0}, Lfa7;->f(I)J

    .line 458
    .line 459
    .line 460
    move-result-wide v17

    .line 461
    const-wide/16 v24, 0x0

    .line 462
    .line 463
    const v26, 0xfffffd

    .line 464
    .line 465
    .line 466
    move-object v14, v15

    .line 467
    const-wide/16 v15, 0x0

    .line 468
    .line 469
    const/16 v19, 0x0

    .line 470
    .line 471
    const-wide/16 v20, 0x0

    .line 472
    .line 473
    const/16 v23, 0x0

    .line 474
    .line 475
    invoke-direct/range {v14 .. v26}, Lbi7;-><init>(JJLhg2;JIIJI)V

    .line 476
    .line 477
    .line 478
    move-object v0, v13

    .line 479
    move-object v13, v12

    .line 480
    move-object v12, v11

    .line 481
    move-object v11, v10

    .line 482
    move-object v10, v9

    .line 483
    move-object v9, v8

    .line 484
    move-object v8, v7

    .line 485
    move-object v7, v6

    .line 486
    move-object v6, v5

    .line 487
    move-object v5, v4

    .line 488
    move-object v4, v3

    .line 489
    move-object v3, v2

    .line 490
    move-object v2, v1

    .line 491
    new-instance v1, Ldi7;

    .line 492
    .line 493
    move-object v15, v14

    .line 494
    move-object v14, v0

    .line 495
    invoke-direct/range {v1 .. v15}, Ldi7;-><init>(Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;Lbi7;)V

    .line 496
    .line 497
    .line 498
    return-object v1

    .line 499
    :pswitch_f
    sget-object v0, Llo1;->a:Lsh7;

    .line 500
    .line 501
    return-object v0

    .line 502
    :pswitch_10
    new-instance v0, Lp93;

    .line 503
    .line 504
    invoke-direct {v0, v1, v2}, Lp93;-><init>(J)V

    .line 505
    .line 506
    .line 507
    return-object v0

    .line 508
    :pswitch_11
    new-instance v0, Lp93;

    .line 509
    .line 510
    invoke-direct {v0, v1, v2}, Lp93;-><init>(J)V

    .line 511
    .line 512
    .line 513
    return-object v0

    .line 514
    :pswitch_12
    sget-object v0, Lmr7;->a:Lbi7;

    .line 515
    .line 516
    return-object v0

    .line 517
    :pswitch_13
    return-object v4

    .line 518
    :pswitch_14
    new-instance v0, Lot1;

    .line 519
    .line 520
    invoke-direct {v0, v3}, Lot1;-><init>(F)V

    .line 521
    .line 522
    .line 523
    return-object v0

    .line 524
    :pswitch_15
    sget-object v0, Lst7;->a:Lst7;

    .line 525
    .line 526
    return-object v0

    .line 527
    :pswitch_16
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 528
    .line 529
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 530
    .line 531
    .line 532
    move-result-object v0

    .line 533
    return-object v0

    .line 534
    :pswitch_17
    const-string v0, "Unexpected call to default provider"

    .line 535
    .line 536
    invoke-static {v0}, Lp92;->C(Ljava/lang/String;)Lo11;

    .line 537
    .line 538
    .line 539
    move-result-object v0

    .line 540
    throw v0

    .line 541
    :pswitch_18
    sget-object v0, Lt00;->b:Lvj3;

    .line 542
    .line 543
    invoke-interface {v0}, Lvj3;->getValue()Ljava/lang/Object;

    .line 544
    .line 545
    .line 546
    move-result-object v0

    .line 547
    check-cast v0, [B

    .line 548
    .line 549
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 550
    .line 551
    .line 552
    sget-object v1, Landroid/graphics/Bitmap$Config;->ALPHA_8:Landroid/graphics/Bitmap$Config;

    .line 553
    .line 554
    const/16 v2, 0x200

    .line 555
    .line 556
    invoke-static {v2, v2, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 557
    .line 558
    .line 559
    move-result-object v1

    .line 560
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 561
    .line 562
    .line 563
    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    invoke-virtual {v1, v0}, Landroid/graphics/Bitmap;->copyPixelsFromBuffer(Ljava/nio/Buffer;)V

    .line 568
    .line 569
    .line 570
    new-instance v0, Luc;

    .line 571
    .line 572
    invoke-direct {v0, v1}, Luc;-><init>(Landroid/graphics/Bitmap;)V

    .line 573
    .line 574
    .line 575
    new-instance v1, Landroid/graphics/BitmapShader;

    .line 576
    .line 577
    invoke-static {v0}, Ln14;->m(Luc;)Landroid/graphics/Bitmap;

    .line 578
    .line 579
    .line 580
    move-result-object v0

    .line 581
    sget-object v2, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    .line 582
    .line 583
    invoke-direct {v1, v0, v2, v2}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    .line 584
    .line 585
    .line 586
    invoke-static {}, Lj5;->s()Z

    .line 587
    .line 588
    .line 589
    move-result v0

    .line 590
    if-eqz v0, :cond_0

    .line 591
    .line 592
    invoke-static {v1}, Lg5;->n(Landroid/graphics/BitmapShader;)V

    .line 593
    .line 594
    .line 595
    :cond_0
    return-object v1

    .line 596
    :pswitch_19
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 597
    .line 598
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 599
    .line 600
    .line 601
    move-result-object v0

    .line 602
    return-object v0

    .line 603
    :pswitch_1a
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 604
    .line 605
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 606
    .line 607
    .line 608
    move-result-object v0

    .line 609
    return-object v0

    .line 610
    :pswitch_1b
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 611
    .line 612
    invoke-static {v0}, Lml3;->B(Ljava/lang/Object;)Lz75;

    .line 613
    .line 614
    .line 615
    move-result-object v0

    .line 616
    return-object v0

    .line 617
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
