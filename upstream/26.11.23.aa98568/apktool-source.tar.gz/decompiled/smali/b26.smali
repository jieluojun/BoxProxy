.class public abstract Lb26;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:Lz16;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const/16 v0, 0x32

    .line 2
    .line 3
    invoke-static {v0}, Lmx;->e(I)Lia5;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Lz16;

    .line 8
    .line 9
    invoke-direct {v1, v0, v0, v0, v0}, Lvi1;-><init>(Lxi1;Lxi1;Lxi1;Lxi1;)V

    .line 10
    .line 11
    .line 12
    sput-object v1, Lb26;->a:Lz16;

    .line 13
    .line 14
    return-void
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public static final a(F)Lz16;
    .locals 1

    .line 1
    new-instance v0, Lpt1;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lpt1;-><init>(F)V

    .line 4
    .line 5
    .line 6
    new-instance p0, Lz16;

    .line 7
    .line 8
    invoke-direct {p0, v0, v0, v0, v0}, Lvi1;-><init>(Lxi1;Lxi1;Lxi1;Lxi1;)V

    .line 9
    .line 10
    .line 11
    return-object p0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
.end method

.method public static final b(FFFF)Lz16;
    .locals 2

    .line 1
    new-instance v0, Lz16;

    .line 2
    .line 3
    new-instance v1, Lpt1;

    .line 4
    .line 5
    invoke-direct {v1, p0}, Lpt1;-><init>(F)V

    .line 6
    .line 7
    .line 8
    new-instance p0, Lpt1;

    .line 9
    .line 10
    invoke-direct {p0, p1}, Lpt1;-><init>(F)V

    .line 11
    .line 12
    .line 13
    new-instance p1, Lpt1;

    .line 14
    .line 15
    invoke-direct {p1, p2}, Lpt1;-><init>(F)V

    .line 16
    .line 17
    .line 18
    new-instance p2, Lpt1;

    .line 19
    .line 20
    invoke-direct {p2, p3}, Lpt1;-><init>(F)V

    .line 21
    .line 22
    .line 23
    invoke-direct {v0, v1, p0, p1, p2}, Lvi1;-><init>(Lxi1;Lxi1;Lxi1;Lxi1;)V

    .line 24
    .line 25
    .line 26
    return-object v0
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
.end method
