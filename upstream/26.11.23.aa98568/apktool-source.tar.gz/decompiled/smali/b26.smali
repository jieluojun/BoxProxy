.class public abstract Lb26;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# static fields
.field public static final a:Lz16;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const/16 v0, 0x32

    .line 2
    .line 3
    invoke-static {v0}, Lmx;->e(I)Lia5;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Lz16;

    .line 8
    .line 9
    invoke-direct {v1, v0, v0, v0, v0}, Lvi1;-><init>(Lxi1;Lxi1;Lxi1;Lxi1;)V

    .line 10
    .line 11
    .line 12
    sput-object v1, Lb26;->a:Lz16;

    .line 13
    .line 14
    return-void
.end method

.method public static final a(F)Lz16;
    .locals 1

    .line 1
    new-instance v0, Lpt1;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lpt1;-><init>(F)V

    .line 4
    .line 5
    .line 6
    new-instance p0, Lz16;

    .line 7
    .line 8
    invoke-direct {p0, v0, v0, v0, v0}, Lvi1;-><init>(Lxi1;Lxi1;Lxi1;Lxi1;)V

    .line 9
    .line 10
    .line 11
    return-object p0
.end method

.method public static final b(FFFF)Lz16;
    .locals 2

    .line 1
    new-instance v0, Lz16;

    .line 2
    .line 3
    new-instance v1, Lpt1;

    .line 4
    .line 5
    invoke-direct {v1, p0}, Lpt1;-><init>(F)V

    .line 6
    .line 7
    .line 8
    new-instance p0, Lpt1;

    .line 9
    .line 10
    invoke-direct {p0, p1}, Lpt1;-><init>(F)V

    .line 11
    .line 12
    .line 13
    new-instance p1, Lpt1;

    .line 14
    .line 15
    invoke-direct {p1, p2}, Lpt1;-><init>(F)V

    .line 16
    .line 17
    .line 18
    new-instance p2, Lpt1;

    .line 19
    .line 20
    invoke-direct {p2, p3}, Lpt1;-><init>(F)V

    .line 21
    .line 22
    .line 23
    invoke-direct {v0, v1, p0, p1, p2}, Lvi1;-><init>(Lxi1;Lxi1;Lxi1;Lxi1;)V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method
