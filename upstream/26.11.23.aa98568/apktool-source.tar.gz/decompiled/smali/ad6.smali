.class public final Lad6;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lorg/xml/sax/Attributes;


# instance fields
.field public final a:Lhg3;


# direct methods
.method public constructor <init>(Lhg3;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lad6;->a:Lhg3;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final getIndex(Ljava/lang/String;)I
    .locals 0

    .line 3
    const/4 p0, -0x1

    return p0
.end method

.method public final getIndex(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    .line 1
    const/4 p0, -0x1

    .line 2
    return p0
.end method

.method public final getLength()I
    .locals 0

    .line 1
    iget-object p0, p0, Lad6;->a:Lhg3;

    .line 2
    .line 3
    iget p0, p0, Lhg3;->H:I

    .line 4
    .line 5
    return p0
.end method

.method public final getLocalName(I)Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lad6;->a:Lhg3;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lhg3;->getAttributeName(I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final getQName(I)Ljava/lang/String;
    .locals 1

    .line 1
    iget-object p0, p0, Lad6;->a:Lhg3;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lhg3;->getAttributeName(I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {p0, p1}, Lhg3;->getAttributePrefix(I)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    new-instance p1, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const/16 p0, 0x3a

    .line 17
    .line 18
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    return-object p0
.end method

.method public final getType(I)Ljava/lang/String;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final getType(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 4
    const/4 p0, 0x0

    return-object p0
.end method

.method public final getType(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 3
    const/4 p0, 0x0

    return-object p0
.end method

.method public final getURI(I)Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lad6;->a:Lhg3;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lhg3;->getAttributeNamespace(I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final getValue(I)Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lad6;->a:Lhg3;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lhg3;->getAttributeValue(I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final getValue(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 9
    const/4 p0, 0x0

    return-object p0
.end method

.method public final getValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 8
    const/4 p0, 0x0

    return-object p0
.end method
