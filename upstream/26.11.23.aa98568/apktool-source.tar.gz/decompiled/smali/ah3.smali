.class public final Lah3;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lim1;


# virtual methods
.method public final a(Lix6;Lyz4;Lyu5;)Lkm1;
    .locals 16

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v1, v0, Lix6;->a:Lg53;

    .line 7
    .line 8
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    iget-object v0, v0, Lix6;->b:Ljava/lang/String;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const/16 v3, 0x3b

    .line 17
    .line 18
    invoke-static {v0, v3}, Lf17;->V0(Ljava/lang/String;C)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {v0}, Lf17;->Z0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move-object v0, v2

    .line 32
    :goto_0
    const-string v3, "image/svg+xml"

    .line 33
    .line 34
    invoke-static {v0, v3}, Lm17;->d0(Ljava/lang/String;Ljava/lang/String;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_5

    .line 39
    .line 40
    invoke-interface {v1}, Lg53;->B()Lvg0;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    sget-object v3, Lch3;->a:Ldj0;

    .line 45
    .line 46
    const-wide/16 v4, 0x0

    .line 47
    .line 48
    invoke-interface {v0, v4, v5, v3}, Lvg0;->p(JLdj0;)Z

    .line 49
    .line 50
    .line 51
    move-result v6

    .line 52
    if-eqz v6, :cond_1

    .line 53
    .line 54
    iget-object v3, v3, Ldj0;->h:[B

    .line 55
    .line 56
    array-length v3, v3

    .line 57
    int-to-long v4, v3

    .line 58
    :cond_1
    :goto_1
    const-wide/16 v6, 0x400

    .line 59
    .line 60
    cmp-long v3, v4, v6

    .line 61
    .line 62
    const/16 v8, 0x20

    .line 63
    .line 64
    const/16 v9, 0xd

    .line 65
    .line 66
    const/16 v10, 0xa

    .line 67
    .line 68
    const/16 v11, 0x9

    .line 69
    .line 70
    const-wide/16 v12, 0x1

    .line 71
    .line 72
    if-gez v3, :cond_3

    .line 73
    .line 74
    add-long v14, v4, v12

    .line 75
    .line 76
    invoke-interface {v0, v14, v15}, Lvg0;->h(J)Z

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    if-eqz v3, :cond_3

    .line 81
    .line 82
    invoke-interface {v0}, Lvg0;->j()Ljg0;

    .line 83
    .line 84
    .line 85
    move-result-object v3

    .line 86
    invoke-virtual {v3, v4, v5}, Ljg0;->i(J)B

    .line 87
    .line 88
    .line 89
    move-result v3

    .line 90
    if-eq v3, v11, :cond_2

    .line 91
    .line 92
    if-eq v3, v10, :cond_2

    .line 93
    .line 94
    if-eq v3, v9, :cond_2

    .line 95
    .line 96
    if-eq v3, v8, :cond_2

    .line 97
    .line 98
    const/16 v14, 0x3c

    .line 99
    .line 100
    if-eq v3, v14, :cond_3

    .line 101
    .line 102
    goto :goto_3

    .line 103
    :cond_2
    move-wide v4, v14

    .line 104
    goto :goto_1

    .line 105
    :cond_3
    :goto_2
    sget-object v3, Lch3;->b:Ldj0;

    .line 106
    .line 107
    iget-object v14, v3, Ldj0;->h:[B

    .line 108
    .line 109
    array-length v15, v14

    .line 110
    move-wide/from16 p0, v6

    .line 111
    .line 112
    int-to-long v6, v15

    .line 113
    sub-long v6, p0, v6

    .line 114
    .line 115
    cmp-long v6, v4, v6

    .line 116
    .line 117
    if-gez v6, :cond_4

    .line 118
    .line 119
    invoke-interface {v0, v4, v5, v3}, Lvg0;->g(JLdj0;)J

    .line 120
    .line 121
    .line 122
    move-result-wide v3

    .line 123
    const-wide/16 v5, -0x1

    .line 124
    .line 125
    cmp-long v5, v3, v5

    .line 126
    .line 127
    if-eqz v5, :cond_4

    .line 128
    .line 129
    array-length v5, v14

    .line 130
    int-to-long v5, v5

    .line 131
    add-long/2addr v5, v3

    .line 132
    add-long/2addr v5, v12

    .line 133
    invoke-interface {v0, v5, v6}, Lvg0;->h(J)Z

    .line 134
    .line 135
    .line 136
    move-result v5

    .line 137
    if-eqz v5, :cond_4

    .line 138
    .line 139
    invoke-interface {v0}, Lvg0;->j()Ljg0;

    .line 140
    .line 141
    .line 142
    move-result-object v5

    .line 143
    array-length v6, v14

    .line 144
    int-to-long v6, v6

    .line 145
    add-long/2addr v6, v3

    .line 146
    invoke-virtual {v5, v6, v7}, Ljg0;->i(J)B

    .line 147
    .line 148
    .line 149
    move-result v5

    .line 150
    if-eq v5, v11, :cond_5

    .line 151
    .line 152
    if-eq v5, v10, :cond_5

    .line 153
    .line 154
    if-eq v5, v9, :cond_5

    .line 155
    .line 156
    if-eq v5, v8, :cond_5

    .line 157
    .line 158
    const/16 v6, 0x2f

    .line 159
    .line 160
    if-eq v5, v6, :cond_5

    .line 161
    .line 162
    const/16 v6, 0x3e

    .line 163
    .line 164
    if-eq v5, v6, :cond_5

    .line 165
    .line 166
    array-length v5, v14

    .line 167
    int-to-long v5, v5

    .line 168
    add-long v4, v3, v5

    .line 169
    .line 170
    move-wide/from16 v6, p0

    .line 171
    .line 172
    goto :goto_2

    .line 173
    :cond_4
    :goto_3
    return-object v2

    .line 174
    :cond_5
    new-instance v0, Lbh3;

    .line 175
    .line 176
    move-object/from16 v2, p2

    .line 177
    .line 178
    invoke-direct {v0, v1, v2}, Lbh3;-><init>(Lg53;Lyz4;)V

    .line 179
    .line 180
    .line 181
    return-object v0
.end method
