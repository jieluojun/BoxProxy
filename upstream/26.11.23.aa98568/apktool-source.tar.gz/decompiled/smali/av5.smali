.class public final Lav5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public final a:Lpu5;

.field public final b:Ljava/util/ArrayList;

.field public final c:I

.field public final d:Lnr1;

.field public final e:Lny5;

.field public final f:I

.field public final g:I

.field public final h:I

.field public final i:Ly6;

.field public final j:Loo0;

.field public final k:Lzy7;

.field public final l:Ly6;

.field public final m:Lzs1;

.field public final n:Ljavax/net/ssl/HostnameVerifier;

.field public final o:Ly6;

.field public final p:Ljava/net/ProxySelector;

.field public final q:Z

.field public final r:Ljavax/net/SocketFactory;

.field public final s:Ljavax/net/ssl/SSLSocketFactory;

.field public final t:Ljavax/net/ssl/X509TrustManager;

.field public final u:Ldv;

.field public v:I


# direct methods
.method public constructor <init>(Lpu5;Ljava/util/ArrayList;ILnr1;Lny5;IIILy6;Loo0;Lzy7;Ly6;Lzs1;Ljavax/net/ssl/HostnameVerifier;Ly6;Ljava/net/ProxySelector;ZLjavax/net/SocketFactory;Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/X509TrustManager;Ldv;)V
    .locals 0

    .line 1
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual {p12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    invoke-virtual {p13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {p15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    invoke-virtual/range {p16 .. p16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-virtual/range {p18 .. p18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    .line 33
    .line 34
    iput-object p1, p0, Lav5;->a:Lpu5;

    .line 35
    .line 36
    iput-object p2, p0, Lav5;->b:Ljava/util/ArrayList;

    .line 37
    .line 38
    iput p3, p0, Lav5;->c:I

    .line 39
    .line 40
    iput-object p4, p0, Lav5;->d:Lnr1;

    .line 41
    .line 42
    iput-object p5, p0, Lav5;->e:Lny5;

    .line 43
    .line 44
    iput p6, p0, Lav5;->f:I

    .line 45
    .line 46
    iput p7, p0, Lav5;->g:I

    .line 47
    .line 48
    iput p8, p0, Lav5;->h:I

    .line 49
    .line 50
    iput-object p9, p0, Lav5;->i:Ly6;

    .line 51
    .line 52
    iput-object p10, p0, Lav5;->j:Loo0;

    .line 53
    .line 54
    iput-object p11, p0, Lav5;->k:Lzy7;

    .line 55
    .line 56
    iput-object p12, p0, Lav5;->l:Ly6;

    .line 57
    .line 58
    iput-object p13, p0, Lav5;->m:Lzs1;

    .line 59
    .line 60
    iput-object p14, p0, Lav5;->n:Ljavax/net/ssl/HostnameVerifier;

    .line 61
    .line 62
    iput-object p15, p0, Lav5;->o:Ly6;

    .line 63
    .line 64
    move-object/from16 p1, p16

    .line 65
    .line 66
    iput-object p1, p0, Lav5;->p:Ljava/net/ProxySelector;

    .line 67
    .line 68
    move/from16 p1, p17

    .line 69
    .line 70
    iput-boolean p1, p0, Lav5;->q:Z

    .line 71
    .line 72
    move-object/from16 p1, p18

    .line 73
    .line 74
    iput-object p1, p0, Lav5;->r:Ljavax/net/SocketFactory;

    .line 75
    .line 76
    move-object/from16 p1, p19

    .line 77
    .line 78
    iput-object p1, p0, Lav5;->s:Ljavax/net/ssl/SSLSocketFactory;

    .line 79
    .line 80
    move-object/from16 p1, p20

    .line 81
    .line 82
    iput-object p1, p0, Lav5;->t:Ljavax/net/ssl/X509TrustManager;

    .line 83
    .line 84
    move-object/from16 p1, p21

    .line 85
    .line 86
    iput-object p1, p0, Lav5;->u:Ldv;

    .line 87
    .line 88
    return-void
.end method

.method public static a(Lav5;ILnr1;Lny5;I)Lav5;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    and-int/lit8 v1, p4, 0x1

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    iget v1, v0, Lav5;->c:I

    .line 8
    .line 9
    move v5, v1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    move/from16 v5, p1

    .line 12
    .line 13
    :goto_0
    and-int/lit8 v1, p4, 0x2

    .line 14
    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    iget-object v1, v0, Lav5;->d:Lnr1;

    .line 18
    .line 19
    move-object v6, v1

    .line 20
    goto :goto_1

    .line 21
    :cond_1
    move-object/from16 v6, p2

    .line 22
    .line 23
    :goto_1
    and-int/lit8 v1, p4, 0x4

    .line 24
    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    iget-object v1, v0, Lav5;->e:Lny5;

    .line 28
    .line 29
    move-object v7, v1

    .line 30
    goto :goto_2

    .line 31
    :cond_2
    move-object/from16 v7, p3

    .line 32
    .line 33
    :goto_2
    iget v8, v0, Lav5;->f:I

    .line 34
    .line 35
    iget v9, v0, Lav5;->g:I

    .line 36
    .line 37
    iget v10, v0, Lav5;->h:I

    .line 38
    .line 39
    iget-object v11, v0, Lav5;->i:Ly6;

    .line 40
    .line 41
    iget-object v12, v0, Lav5;->j:Loo0;

    .line 42
    .line 43
    iget-object v13, v0, Lav5;->k:Lzy7;

    .line 44
    .line 45
    iget-object v14, v0, Lav5;->l:Ly6;

    .line 46
    .line 47
    iget-object v15, v0, Lav5;->m:Lzs1;

    .line 48
    .line 49
    iget-object v1, v0, Lav5;->n:Ljavax/net/ssl/HostnameVerifier;

    .line 50
    .line 51
    iget-object v2, v0, Lav5;->o:Ly6;

    .line 52
    .line 53
    iget-object v3, v0, Lav5;->p:Ljava/net/ProxySelector;

    .line 54
    .line 55
    iget-boolean v4, v0, Lav5;->q:Z

    .line 56
    .line 57
    move-object/from16 v16, v1

    .line 58
    .line 59
    iget-object v1, v0, Lav5;->r:Ljavax/net/SocketFactory;

    .line 60
    .line 61
    move-object/from16 v20, v1

    .line 62
    .line 63
    iget-object v1, v0, Lav5;->s:Ljavax/net/ssl/SSLSocketFactory;

    .line 64
    .line 65
    move-object/from16 v21, v1

    .line 66
    .line 67
    iget-object v1, v0, Lav5;->t:Ljavax/net/ssl/X509TrustManager;

    .line 68
    .line 69
    move-object/from16 v22, v1

    .line 70
    .line 71
    iget-object v1, v0, Lav5;->u:Ldv;

    .line 72
    .line 73
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 74
    .line 75
    .line 76
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    .line 93
    .line 94
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    .line 102
    .line 103
    move-object/from16 v17, v2

    .line 104
    .line 105
    new-instance v2, Lav5;

    .line 106
    .line 107
    move-object/from16 v18, v3

    .line 108
    .line 109
    iget-object v3, v0, Lav5;->a:Lpu5;

    .line 110
    .line 111
    iget-object v0, v0, Lav5;->b:Ljava/util/ArrayList;

    .line 112
    .line 113
    move-object/from16 v23, v1

    .line 114
    .line 115
    move/from16 v19, v4

    .line 116
    .line 117
    move-object v4, v0

    .line 118
    invoke-direct/range {v2 .. v23}, Lav5;-><init>(Lpu5;Ljava/util/ArrayList;ILnr1;Lny5;IIILy6;Loo0;Lzy7;Ly6;Lzs1;Ljavax/net/ssl/HostnameVerifier;Ly6;Ljava/net/ProxySelector;ZLjavax/net/SocketFactory;Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/X509TrustManager;Ldv;)V

    .line 119
    .line 120
    .line 121
    return-object v2
.end method


# virtual methods
.method public final b(Lny5;)Loz5;
    .locals 11

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lav5;->b:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x0

    .line 11
    iget v3, p0, Lav5;->c:I

    .line 12
    .line 13
    if-ge v3, v1, :cond_4

    .line 14
    .line 15
    iget v1, p0, Lav5;->v:I

    .line 16
    .line 17
    const/4 v4, 0x1

    .line 18
    add-int/2addr v1, v4

    .line 19
    iput v1, p0, Lav5;->v:I

    .line 20
    .line 21
    const-string v1, " must call proceed() exactly once"

    .line 22
    .line 23
    iget-object v5, p0, Lav5;->d:Lnr1;

    .line 24
    .line 25
    const-string v6, "network interceptor "

    .line 26
    .line 27
    if-eqz v5, :cond_1

    .line 28
    .line 29
    iget-object v7, v5, Lnr1;->c:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v7, Lb52;

    .line 32
    .line 33
    invoke-interface {v7}, Lb52;->c()Lev5;

    .line 34
    .line 35
    .line 36
    move-result-object v7

    .line 37
    iget-object v8, p1, Lny5;->a:Lh33;

    .line 38
    .line 39
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    iget-object v7, v7, Lev5;->j:Lq7;

    .line 46
    .line 47
    iget-object v7, v7, Lq7;->h:Lh33;

    .line 48
    .line 49
    iget v9, v8, Lh33;->e:I

    .line 50
    .line 51
    iget v10, v7, Lh33;->e:I

    .line 52
    .line 53
    if-ne v9, v10, :cond_0

    .line 54
    .line 55
    iget-object v8, v8, Lh33;->d:Ljava/lang/String;

    .line 56
    .line 57
    iget-object v7, v7, Lh33;->d:Ljava/lang/String;

    .line 58
    .line 59
    invoke-static {v8, v7}, Lob3;->s(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    if-eqz v7, :cond_0

    .line 64
    .line 65
    iget v7, p0, Lav5;->v:I

    .line 66
    .line 67
    if-eq v7, v4, :cond_1

    .line 68
    .line 69
    sub-int/2addr v3, v4

    .line 70
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    invoke-static {v6, p0, v1}, Lxb1;->k(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    return-object v2

    .line 78
    :cond_0
    sub-int/2addr v3, v4

    .line 79
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    const-string p1, " must retain the same host and port"

    .line 84
    .line 85
    invoke-static {v6, p0, p1}, Lxb1;->k(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    return-object v2

    .line 89
    :cond_1
    add-int/lit8 v7, v3, 0x1

    .line 90
    .line 91
    const v8, 0x1ffffa

    .line 92
    .line 93
    .line 94
    invoke-static {p0, v7, v2, p1, v8}, Lav5;->a(Lav5;ILnr1;Lny5;I)Lav5;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    check-cast p1, Lwk0;

    .line 103
    .line 104
    invoke-virtual {p1, p0}, Lwk0;->b(Lav5;)Loz5;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    if-eqz v3, :cond_3

    .line 109
    .line 110
    if-eqz v5, :cond_2

    .line 111
    .line 112
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    if-ge v7, v0, :cond_2

    .line 117
    .line 118
    iget p0, p0, Lav5;->v:I

    .line 119
    .line 120
    if-eq p0, v4, :cond_2

    .line 121
    .line 122
    invoke-static {v6, p1, v1}, Lxb1;->k(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    return-object v2

    .line 126
    :cond_2
    return-object v3

    .line 127
    :cond_3
    new-instance p0, Ljava/lang/NullPointerException;

    .line 128
    .line 129
    new-instance v0, Ljava/lang/StringBuilder;

    .line 130
    .line 131
    const-string v1, "interceptor "

    .line 132
    .line 133
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    const-string p1, " returned null"

    .line 140
    .line 141
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    throw p0

    .line 152
    :cond_4
    const-string p0, "Check failed."

    .line 153
    .line 154
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    return-object v2
.end method
