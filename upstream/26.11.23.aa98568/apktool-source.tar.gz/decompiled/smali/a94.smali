.class public final La94;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lx15;


# static fields
.field public static final a:La94;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La94;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La94;->a:La94;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Lv15;
    .locals 0

    .line 1
    new-instance p0, Lw84;

    .line 2
    .line 3
    invoke-direct {p0}, Lw84;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    const/4 p0, 0x1

    .line 4
    return p0

    .line 5
    :cond_0
    const/4 p0, 0x0

    .line 6
    return p0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method
