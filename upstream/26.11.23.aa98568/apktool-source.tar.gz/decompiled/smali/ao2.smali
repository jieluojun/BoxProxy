.class public final synthetic Lao2;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Z

.field public final synthetic j:Llh2;

.field public final synthetic k:Lyv5;

.field public final synthetic l:Lr01;

.field public final synthetic m:Lbb4;

.field public final synthetic n:Lln2;

.field public final synthetic o:Lsn2;

.field public final synthetic p:Lxn2;

.field public final synthetic q:F

.field public final synthetic r:Lm45;

.field public final synthetic s:Llh2;

.field public final synthetic t:Ls21;


# direct methods
.method public synthetic constructor <init>(ZLlh2;Lyv5;Lr01;Lbb4;Lln2;Lsn2;Lxn2;FLm45;Llh2;Ls21;IB)V
    .locals 0

    .line 1
    iput-byte p14, p0, Lao2;->h:B

    .line 2
    .line 3
    iput-boolean p1, p0, Lao2;->i:Z

    .line 4
    .line 5
    iput-object p2, p0, Lao2;->j:Llh2;

    .line 6
    .line 7
    iput-object p3, p0, Lao2;->k:Lyv5;

    .line 8
    .line 9
    iput-object p4, p0, Lao2;->l:Lr01;

    .line 10
    .line 11
    iput-object p5, p0, Lao2;->m:Lbb4;

    .line 12
    .line 13
    iput-object p6, p0, Lao2;->n:Lln2;

    .line 14
    .line 15
    iput-object p7, p0, Lao2;->o:Lsn2;

    .line 16
    .line 17
    iput-object p8, p0, Lao2;->p:Lxn2;

    .line 18
    .line 19
    iput p9, p0, Lao2;->q:F

    .line 20
    .line 21
    iput-object p10, p0, Lao2;->r:Lm45;

    .line 22
    .line 23
    iput-object p11, p0, Lao2;->s:Llh2;

    .line 24
    .line 25
    iput-object p12, p0, Lao2;->t:Ls21;

    .line 26
    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lao2;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/16 v3, 0x187

    .line 8
    .line 9
    packed-switch v1, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    move-object/from16 v16, p1

    .line 13
    .line 14
    check-cast v16, Lzi2;

    .line 15
    .line 16
    move-object/from16 v1, p2

    .line 17
    .line 18
    check-cast v1, Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    invoke-static {v3}, Lyj3;->j0(I)I

    .line 24
    .line 25
    .line 26
    move-result v17

    .line 27
    iget-boolean v4, v0, Lao2;->i:Z

    .line 28
    .line 29
    iget-object v5, v0, Lao2;->j:Llh2;

    .line 30
    .line 31
    iget-object v6, v0, Lao2;->k:Lyv5;

    .line 32
    .line 33
    iget-object v7, v0, Lao2;->l:Lr01;

    .line 34
    .line 35
    iget-object v8, v0, Lao2;->m:Lbb4;

    .line 36
    .line 37
    iget-object v9, v0, Lao2;->n:Lln2;

    .line 38
    .line 39
    iget-object v10, v0, Lao2;->o:Lsn2;

    .line 40
    .line 41
    iget-object v11, v0, Lao2;->p:Lxn2;

    .line 42
    .line 43
    iget v12, v0, Lao2;->q:F

    .line 44
    .line 45
    iget-object v13, v0, Lao2;->r:Lm45;

    .line 46
    .line 47
    iget-object v14, v0, Lao2;->s:Llh2;

    .line 48
    .line 49
    iget-object v15, v0, Lao2;->t:Ls21;

    .line 50
    .line 51
    invoke-static/range {v4 .. v17}, Llx;->h(ZLlh2;Lyv5;Lr01;Lbb4;Lln2;Lsn2;Lxn2;FLm45;Llh2;Ls21;Lzi2;I)V

    .line 52
    .line 53
    .line 54
    return-object v2

    .line 55
    :pswitch_0
    move-object/from16 v30, p1

    .line 56
    .line 57
    check-cast v30, Lzi2;

    .line 58
    .line 59
    move-object/from16 v1, p2

    .line 60
    .line 61
    check-cast v1, Ljava/lang/Integer;

    .line 62
    .line 63
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    invoke-static {v3}, Lyj3;->j0(I)I

    .line 67
    .line 68
    .line 69
    move-result v31

    .line 70
    iget-boolean v1, v0, Lao2;->i:Z

    .line 71
    .line 72
    iget-object v3, v0, Lao2;->j:Llh2;

    .line 73
    .line 74
    iget-object v4, v0, Lao2;->k:Lyv5;

    .line 75
    .line 76
    iget-object v5, v0, Lao2;->l:Lr01;

    .line 77
    .line 78
    iget-object v6, v0, Lao2;->m:Lbb4;

    .line 79
    .line 80
    iget-object v7, v0, Lao2;->n:Lln2;

    .line 81
    .line 82
    iget-object v8, v0, Lao2;->o:Lsn2;

    .line 83
    .line 84
    iget-object v9, v0, Lao2;->p:Lxn2;

    .line 85
    .line 86
    iget v10, v0, Lao2;->q:F

    .line 87
    .line 88
    iget-object v11, v0, Lao2;->r:Lm45;

    .line 89
    .line 90
    iget-object v12, v0, Lao2;->s:Llh2;

    .line 91
    .line 92
    iget-object v0, v0, Lao2;->t:Ls21;

    .line 93
    .line 94
    move-object/from16 v29, v0

    .line 95
    .line 96
    move/from16 v18, v1

    .line 97
    .line 98
    move-object/from16 v19, v3

    .line 99
    .line 100
    move-object/from16 v20, v4

    .line 101
    .line 102
    move-object/from16 v21, v5

    .line 103
    .line 104
    move-object/from16 v22, v6

    .line 105
    .line 106
    move-object/from16 v23, v7

    .line 107
    .line 108
    move-object/from16 v24, v8

    .line 109
    .line 110
    move-object/from16 v25, v9

    .line 111
    .line 112
    move/from16 v26, v10

    .line 113
    .line 114
    move-object/from16 v27, v11

    .line 115
    .line 116
    move-object/from16 v28, v12

    .line 117
    .line 118
    invoke-static/range {v18 .. v31}, Llx;->h(ZLlh2;Lyv5;Lr01;Lbb4;Lln2;Lsn2;Lxn2;FLm45;Llh2;Ls21;Lzi2;I)V

    .line 119
    .line 120
    .line 121
    return-object v2

    .line 122
    nop

    .line 123
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
