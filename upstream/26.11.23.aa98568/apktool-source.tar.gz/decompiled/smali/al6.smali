.class public interface abstract Lal6;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lza4;


# virtual methods
.method public abstract b1()Lzk6;
.end method
