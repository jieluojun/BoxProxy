.class public final synthetic Laa6;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lac6;

.field public final synthetic j:Llh2;

.field public final synthetic k:Lwh2;


# direct methods
.method public synthetic constructor <init>(Lac6;Llh2;Lwh2;IB)V
    .locals 0

    .line 14
    iput-byte p5, p0, Laa6;->h:B

    iput-object p1, p0, Laa6;->i:Lac6;

    iput-object p2, p0, Laa6;->j:Llh2;

    iput-object p3, p0, Laa6;->k:Lwh2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Llh2;Lwh2;Lac6;)V
    .locals 1

    .line 1
    const/4 v0, 0x3

    .line 2
    iput-byte v0, p0, Laa6;->h:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Laa6;->j:Llh2;

    .line 8
    .line 9
    iput-object p2, p0, Laa6;->k:Lwh2;

    .line 10
    .line 11
    iput-object p3, p0, Laa6;->i:Lac6;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Laa6;->h:B

    .line 4
    .line 5
    iget-object v2, v0, Laa6;->j:Llh2;

    .line 6
    .line 7
    sget-object v3, Lst7;->a:Lst7;

    .line 8
    .line 9
    iget-object v4, v0, Laa6;->k:Lwh2;

    .line 10
    .line 11
    iget-object v5, v0, Laa6;->i:Lac6;

    .line 12
    .line 13
    const/4 v6, 0x1

    .line 14
    packed-switch v1, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    move-object/from16 v0, p1

    .line 18
    .line 19
    check-cast v0, Lzi2;

    .line 20
    .line 21
    move-object/from16 v1, p2

    .line 22
    .line 23
    check-cast v1, Ljava/lang/Integer;

    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-static {v6}, Lyj3;->j0(I)I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-static {v5, v2, v4, v0, v1}, Lyj3;->m(Lac6;Llh2;Lwh2;Lzi2;I)V

    .line 33
    .line 34
    .line 35
    return-object v3

    .line 36
    :pswitch_0
    move-object/from16 v1, p1

    .line 37
    .line 38
    check-cast v1, Lzi2;

    .line 39
    .line 40
    move-object/from16 v2, p2

    .line 41
    .line 42
    check-cast v2, Ljava/lang/Integer;

    .line 43
    .line 44
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    and-int/lit8 v7, v2, 0x3

    .line 49
    .line 50
    const/4 v8, 0x2

    .line 51
    if-eq v7, v8, :cond_0

    .line 52
    .line 53
    move v7, v6

    .line 54
    goto :goto_0

    .line 55
    :cond_0
    const/4 v7, 0x0

    .line 56
    :goto_0
    and-int/2addr v2, v6

    .line 57
    invoke-virtual {v1, v2, v7}, Lzi2;->Y(IZ)Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-eqz v2, :cond_8

    .line 62
    .line 63
    sget-object v2, Lya4;->h:Lya4;

    .line 64
    .line 65
    const/high16 v7, 0x3f800000    # 1.0f

    .line 66
    .line 67
    invoke-static {v2, v7}, Lxt6;->e(Lbb4;F)Lbb4;

    .line 68
    .line 69
    .line 70
    move-result-object v8

    .line 71
    sget-object v9, Lob3;->k:Ls38;

    .line 72
    .line 73
    sget-object v10, Ly6;->s:La40;

    .line 74
    .line 75
    const/4 v11, 0x6

    .line 76
    invoke-static {v9, v10, v1, v11}, Ln26;->a(Lmw;La40;Lzi2;I)Lo26;

    .line 77
    .line 78
    .line 79
    move-result-object v9

    .line 80
    iget-wide v10, v1, Lzi2;->U:J

    .line 81
    .line 82
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 83
    .line 84
    .line 85
    move-result v10

    .line 86
    invoke-virtual {v1}, Lzi2;->m()Lla5;

    .line 87
    .line 88
    .line 89
    move-result-object v11

    .line 90
    invoke-static {v1, v8}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 91
    .line 92
    .line 93
    move-result-object v8

    .line 94
    sget-object v12, Ls41;->d:Ly6;

    .line 95
    .line 96
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v1}, Lzi2;->k0()V

    .line 100
    .line 101
    .line 102
    iget-boolean v12, v1, Lzi2;->T:Z

    .line 103
    .line 104
    if-eqz v12, :cond_1

    .line 105
    .line 106
    sget-object v12, Lzi3;->Z:Lu43;

    .line 107
    .line 108
    invoke-virtual {v1, v12}, Lzi2;->l(Llh2;)V

    .line 109
    .line 110
    .line 111
    goto :goto_1

    .line 112
    :cond_1
    invoke-virtual {v1}, Lzi2;->t0()V

    .line 113
    .line 114
    .line 115
    :goto_1
    sget-object v12, Ly6;->T:Lx31;

    .line 116
    .line 117
    invoke-static {v12, v1, v9}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    sget-object v9, Ly6;->S:Lx31;

    .line 121
    .line 122
    invoke-static {v9, v1, v11}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 126
    .line 127
    .line 128
    move-result-object v9

    .line 129
    sget-object v10, Ly6;->U:Lx31;

    .line 130
    .line 131
    invoke-static {v10, v1, v9}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    invoke-static {v1}, Lfa7;->k(Lzi2;)V

    .line 135
    .line 136
    .line 137
    sget-object v9, Ly6;->R:Lx31;

    .line 138
    .line 139
    invoke-static {v9, v1, v8}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    const/high16 v8, 0x1040000

    .line 143
    .line 144
    invoke-static {v8, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v8

    .line 148
    float-to-double v9, v7

    .line 149
    const-wide/16 v20, 0x0

    .line 150
    .line 151
    cmpl-double v9, v9, v20

    .line 152
    .line 153
    const-string v22, "invalid weight; must be greater than zero"

    .line 154
    .line 155
    if-gtz v9, :cond_2

    .line 156
    .line 157
    invoke-static/range {v22 .. v22}, Ln73;->a(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    :cond_2
    new-instance v9, Lsj3;

    .line 161
    .line 162
    const v23, 0x7f7fffff    # Float.MAX_VALUE

    .line 163
    .line 164
    .line 165
    cmpl-float v10, v7, v23

    .line 166
    .line 167
    if-lez v10, :cond_3

    .line 168
    .line 169
    move/from16 v10, v23

    .line 170
    .line 171
    goto :goto_2

    .line 172
    :cond_3
    move v10, v7

    .line 173
    :goto_2
    invoke-direct {v9, v10, v6}, Lsj3;-><init>(FZ)V

    .line 174
    .line 175
    .line 176
    const/16 v18, 0x0

    .line 177
    .line 178
    const/16 v19, 0xff8

    .line 179
    .line 180
    iget-object v0, v0, Laa6;->j:Llh2;

    .line 181
    .line 182
    const/4 v10, 0x0

    .line 183
    const/4 v11, 0x0

    .line 184
    const/4 v12, 0x0

    .line 185
    const/4 v13, 0x0

    .line 186
    const/4 v14, 0x0

    .line 187
    const/4 v15, 0x0

    .line 188
    const/16 v16, 0x0

    .line 189
    .line 190
    move-object/from16 v17, v8

    .line 191
    .line 192
    move-object v8, v0

    .line 193
    move v0, v7

    .line 194
    move-object/from16 v7, v17

    .line 195
    .line 196
    move-object/from16 v17, v1

    .line 197
    .line 198
    invoke-static/range {v7 .. v19}, Lnl3;->c(Ljava/lang/String;Llh2;Lbb4;ZFFFLd74;Lo45;Li63;Lzi2;II)V

    .line 199
    .line 200
    .line 201
    const/high16 v7, 0x41a00000    # 20.0f

    .line 202
    .line 203
    const v8, 0x7f0f00be

    .line 204
    .line 205
    .line 206
    invoke-static {v2, v7, v1, v8, v1}, Lp92;->o(Lya4;FLzi2;ILzi2;)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v7

    .line 210
    invoke-virtual {v1, v4}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 211
    .line 212
    .line 213
    move-result v2

    .line 214
    invoke-virtual {v1, v5}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    move-result v8

    .line 218
    or-int/2addr v2, v8

    .line 219
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v8

    .line 223
    if-nez v2, :cond_4

    .line 224
    .line 225
    sget-object v2, Lc51;->a:Lql0;

    .line 226
    .line 227
    if-ne v8, v2, :cond_5

    .line 228
    .line 229
    :cond_4
    new-instance v8, Lea6;

    .line 230
    .line 231
    invoke-direct {v8, v4, v5, v6}, Lea6;-><init>(Lwh2;Lac6;B)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v1, v8}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 235
    .line 236
    .line 237
    :cond_5
    check-cast v8, Llh2;

    .line 238
    .line 239
    float-to-double v4, v0

    .line 240
    cmpl-double v2, v4, v20

    .line 241
    .line 242
    if-gtz v2, :cond_6

    .line 243
    .line 244
    invoke-static/range {v22 .. v22}, Ln73;->a(Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    :cond_6
    new-instance v9, Lsj3;

    .line 248
    .line 249
    cmpl-float v2, v0, v23

    .line 250
    .line 251
    if-lez v2, :cond_7

    .line 252
    .line 253
    move/from16 v0, v23

    .line 254
    .line 255
    :cond_7
    invoke-direct {v9, v0, v6}, Lsj3;-><init>(FZ)V

    .line 256
    .line 257
    .line 258
    const/high16 v18, 0xc00000

    .line 259
    .line 260
    const/16 v19, 0xf78

    .line 261
    .line 262
    const/4 v10, 0x0

    .line 263
    const/4 v11, 0x0

    .line 264
    const/4 v12, 0x0

    .line 265
    const/4 v13, 0x0

    .line 266
    sget-object v14, Ld74;->j:Ld74;

    .line 267
    .line 268
    const/4 v15, 0x0

    .line 269
    const/16 v16, 0x0

    .line 270
    .line 271
    move-object/from16 v17, v1

    .line 272
    .line 273
    invoke-static/range {v7 .. v19}, Lnl3;->c(Ljava/lang/String;Llh2;Lbb4;ZFFFLd74;Lo45;Li63;Lzi2;II)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v1, v6}, Lzi2;->r(Z)V

    .line 277
    .line 278
    .line 279
    goto :goto_3

    .line 280
    :cond_8
    invoke-virtual {v1}, Lzi2;->b0()V

    .line 281
    .line 282
    .line 283
    :goto_3
    return-object v3

    .line 284
    :pswitch_1
    move-object/from16 v0, p1

    .line 285
    .line 286
    check-cast v0, Lzi2;

    .line 287
    .line 288
    move-object/from16 v1, p2

    .line 289
    .line 290
    check-cast v1, Ljava/lang/Integer;

    .line 291
    .line 292
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 293
    .line 294
    .line 295
    invoke-static {v6}, Lyj3;->j0(I)I

    .line 296
    .line 297
    .line 298
    move-result v1

    .line 299
    invoke-static {v5, v2, v4, v0, v1}, Lyj3;->m(Lac6;Llh2;Lwh2;Lzi2;I)V

    .line 300
    .line 301
    .line 302
    return-object v3

    .line 303
    :pswitch_2
    move-object/from16 v0, p1

    .line 304
    .line 305
    check-cast v0, Lzi2;

    .line 306
    .line 307
    move-object/from16 v1, p2

    .line 308
    .line 309
    check-cast v1, Ljava/lang/Integer;

    .line 310
    .line 311
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 312
    .line 313
    .line 314
    invoke-static {v6}, Lyj3;->j0(I)I

    .line 315
    .line 316
    .line 317
    move-result v1

    .line 318
    invoke-static {v5, v2, v4, v0, v1}, Lrj3;->u(Lac6;Llh2;Lwh2;Lzi2;I)V

    .line 319
    .line 320
    .line 321
    return-object v3

    .line 322
    :pswitch_3
    move-object/from16 v0, p1

    .line 323
    .line 324
    check-cast v0, Lzi2;

    .line 325
    .line 326
    move-object/from16 v1, p2

    .line 327
    .line 328
    check-cast v1, Ljava/lang/Integer;

    .line 329
    .line 330
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 331
    .line 332
    .line 333
    invoke-static {v6}, Lyj3;->j0(I)I

    .line 334
    .line 335
    .line 336
    move-result v1

    .line 337
    invoke-static {v5, v2, v4, v0, v1}, Lrj3;->u(Lac6;Llh2;Lwh2;Lzi2;I)V

    .line 338
    .line 339
    .line 340
    return-object v3

    .line 341
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
