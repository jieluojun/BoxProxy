.class public final synthetic La84;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic A:I

.field public final synthetic h:Z

.field public final synthetic i:Lbb4;

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:J

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:J

.field public final synthetic n:J

.field public final synthetic o:Z

.field public final synthetic p:Llh2;

.field public final synthetic q:Llh2;

.field public final synthetic r:J

.field public final synthetic s:J

.field public final synthetic t:Z

.field public final synthetic u:Z

.field public final synthetic v:F

.field public final synthetic w:Z

.field public final synthetic x:Ls21;

.field public final synthetic y:I

.field public final synthetic z:I


# direct methods
.method public synthetic constructor <init>(ZLbb4;Ljava/lang/String;JLjava/lang/String;JJZLlh2;Llh2;JJZZFZLs21;III)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, La84;->h:Z

    .line 5
    .line 6
    iput-object p2, p0, La84;->i:Lbb4;

    .line 7
    .line 8
    iput-object p3, p0, La84;->j:Ljava/lang/String;

    .line 9
    .line 10
    iput-wide p4, p0, La84;->k:J

    .line 11
    .line 12
    iput-object p6, p0, La84;->l:Ljava/lang/String;

    .line 13
    .line 14
    iput-wide p7, p0, La84;->m:J

    .line 15
    .line 16
    iput-wide p9, p0, La84;->n:J

    .line 17
    .line 18
    iput-boolean p11, p0, La84;->o:Z

    .line 19
    .line 20
    iput-object p12, p0, La84;->p:Llh2;

    .line 21
    .line 22
    iput-object p13, p0, La84;->q:Llh2;

    .line 23
    .line 24
    iput-wide p14, p0, La84;->r:J

    .line 25
    .line 26
    move-wide/from16 p1, p16

    .line 27
    .line 28
    iput-wide p1, p0, La84;->s:J

    .line 29
    .line 30
    move/from16 p1, p18

    .line 31
    .line 32
    iput-boolean p1, p0, La84;->t:Z

    .line 33
    .line 34
    move/from16 p1, p19

    .line 35
    .line 36
    iput-boolean p1, p0, La84;->u:Z

    .line 37
    .line 38
    move/from16 p1, p20

    .line 39
    .line 40
    iput p1, p0, La84;->v:F

    .line 41
    .line 42
    move/from16 p1, p21

    .line 43
    .line 44
    iput-boolean p1, p0, La84;->w:Z

    .line 45
    .line 46
    move-object/from16 p1, p22

    .line 47
    .line 48
    iput-object p1, p0, La84;->x:Ls21;

    .line 49
    .line 50
    move/from16 p1, p23

    .line 51
    .line 52
    iput p1, p0, La84;->y:I

    .line 53
    .line 54
    move/from16 p1, p24

    .line 55
    .line 56
    iput p1, p0, La84;->z:I

    .line 57
    .line 58
    move/from16 p1, p25

    .line 59
    .line 60
    iput p1, p0, La84;->A:I

    .line 61
    .line 62
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v22, p1

    .line 4
    .line 5
    check-cast v22, Lzi2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget v1, v0, La84;->y:I

    .line 15
    .line 16
    or-int/lit8 v1, v1, 0x1

    .line 17
    .line 18
    invoke-static {v1}, Lyj3;->j0(I)I

    .line 19
    .line 20
    .line 21
    move-result v23

    .line 22
    iget v1, v0, La84;->z:I

    .line 23
    .line 24
    invoke-static {v1}, Lyj3;->j0(I)I

    .line 25
    .line 26
    .line 27
    move-result v24

    .line 28
    iget-boolean v1, v0, La84;->h:Z

    .line 29
    .line 30
    move v2, v1

    .line 31
    iget-object v1, v0, La84;->i:Lbb4;

    .line 32
    .line 33
    move v3, v2

    .line 34
    iget-object v2, v0, La84;->j:Ljava/lang/String;

    .line 35
    .line 36
    move v5, v3

    .line 37
    iget-wide v3, v0, La84;->k:J

    .line 38
    .line 39
    move v6, v5

    .line 40
    iget-object v5, v0, La84;->l:Ljava/lang/String;

    .line 41
    .line 42
    move v8, v6

    .line 43
    iget-wide v6, v0, La84;->m:J

    .line 44
    .line 45
    move v10, v8

    .line 46
    iget-wide v8, v0, La84;->n:J

    .line 47
    .line 48
    move v11, v10

    .line 49
    iget-boolean v10, v0, La84;->o:Z

    .line 50
    .line 51
    move v12, v11

    .line 52
    iget-object v11, v0, La84;->p:Llh2;

    .line 53
    .line 54
    move v13, v12

    .line 55
    iget-object v12, v0, La84;->q:Llh2;

    .line 56
    .line 57
    move v15, v13

    .line 58
    iget-wide v13, v0, La84;->r:J

    .line 59
    .line 60
    move-object/from16 v16, v1

    .line 61
    .line 62
    move-object/from16 v17, v2

    .line 63
    .line 64
    iget-wide v1, v0, La84;->s:J

    .line 65
    .line 66
    move-wide/from16 v18, v1

    .line 67
    .line 68
    iget-boolean v1, v0, La84;->t:Z

    .line 69
    .line 70
    iget-boolean v2, v0, La84;->u:Z

    .line 71
    .line 72
    move/from16 v20, v1

    .line 73
    .line 74
    iget v1, v0, La84;->v:F

    .line 75
    .line 76
    move/from16 v21, v1

    .line 77
    .line 78
    iget-boolean v1, v0, La84;->w:Z

    .line 79
    .line 80
    move/from16 v25, v1

    .line 81
    .line 82
    iget-object v1, v0, La84;->x:Ls21;

    .line 83
    .line 84
    iget v0, v0, La84;->A:I

    .line 85
    .line 86
    move/from16 v26, v25

    .line 87
    .line 88
    move/from16 v25, v0

    .line 89
    .line 90
    move v0, v15

    .line 91
    move/from16 v27, v21

    .line 92
    .line 93
    move-object/from16 v21, v1

    .line 94
    .line 95
    move-object/from16 v1, v16

    .line 96
    .line 97
    move-wide/from16 v15, v18

    .line 98
    .line 99
    move/from16 v19, v27

    .line 100
    .line 101
    move/from16 v18, v2

    .line 102
    .line 103
    move-object/from16 v2, v17

    .line 104
    .line 105
    move/from16 v17, v20

    .line 106
    .line 107
    move/from16 v20, v26

    .line 108
    .line 109
    invoke-static/range {v0 .. v25}, Lti3;->c(ZLbb4;Ljava/lang/String;JLjava/lang/String;JJZLlh2;Llh2;JJZZFZLs21;Lzi2;III)V

    .line 110
    .line 111
    .line 112
    sget-object v0, Lst7;->a:Lst7;

    .line 113
    .line 114
    return-object v0
.end method
