.class public final synthetic Lao5;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lzk5;

.field public final synthetic j:Lyp5;

.field public final synthetic k:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lzk5;Lyp5;Ljava/util/List;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lao5;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lao5;->i:Lzk5;

    .line 4
    .line 5
    iput-object p2, p0, Lao5;->j:Lyp5;

    .line 6
    .line 7
    iput-object p3, p0, Lao5;->k:Ljava/util/List;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget-byte v0, p0, Lao5;->h:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    const/high16 v2, 0x41000000    # 8.0f

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    const/4 v5, 0x0

    .line 11
    iget-object v6, p0, Lao5;->k:Ljava/util/List;

    .line 12
    .line 13
    iget-object v7, p0, Lao5;->j:Lyp5;

    .line 14
    .line 15
    iget-object p0, p0, Lao5;->i:Lzk5;

    .line 16
    .line 17
    check-cast p1, Lfl3;

    .line 18
    .line 19
    check-cast p2, Lzi2;

    .line 20
    .line 21
    check-cast p3, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result p3

    .line 27
    packed-switch v0, :pswitch_data_0

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    and-int/lit8 p1, p3, 0x11

    .line 34
    .line 35
    if-eq p1, v3, :cond_0

    .line 36
    .line 37
    move p1, v4

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    move p1, v5

    .line 40
    :goto_0
    and-int/2addr p3, v4

    .line 41
    invoke-virtual {p2, p3, p1}, Lzi2;->Y(IZ)Z

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    if-eqz p1, :cond_1

    .line 46
    .line 47
    iget-object p1, v7, Lyp5;->a:Ljava/lang/String;

    .line 48
    .line 49
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 50
    .line 51
    .line 52
    move-result p3

    .line 53
    add-int/2addr p3, v4

    .line 54
    invoke-virtual {p0, v5, p1, p3}, Lzk5;->b(ILjava/lang/String;I)Lbb4;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    invoke-static {p0, v2}, Lxt6;->f(Lbb4;F)Lbb4;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    invoke-static {p2, p0}, Lvl3;->A(Lzi2;Lbb4;)V

    .line 63
    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_1
    invoke-virtual {p2}, Lzi2;->b0()V

    .line 67
    .line 68
    .line 69
    :goto_1
    return-object v1

    .line 70
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    and-int/lit8 p1, p3, 0x11

    .line 74
    .line 75
    if-eq p1, v3, :cond_2

    .line 76
    .line 77
    move p1, v4

    .line 78
    goto :goto_2

    .line 79
    :cond_2
    move p1, v5

    .line 80
    :goto_2
    and-int/2addr p3, v4

    .line 81
    invoke-virtual {p2, p3, p1}, Lzi2;->Y(IZ)Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-eqz p1, :cond_3

    .line 86
    .line 87
    iget-object p1, v7, Lyp5;->a:Ljava/lang/String;

    .line 88
    .line 89
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 90
    .line 91
    .line 92
    move-result p3

    .line 93
    add-int/2addr p3, v4

    .line 94
    invoke-virtual {p0, v5, p1, p3}, Lzk5;->b(ILjava/lang/String;I)Lbb4;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    invoke-static {p0, v2}, Lxt6;->f(Lbb4;F)Lbb4;

    .line 99
    .line 100
    .line 101
    move-result-object p0

    .line 102
    invoke-static {p2, p0}, Lvl3;->A(Lzi2;Lbb4;)V

    .line 103
    .line 104
    .line 105
    goto :goto_3

    .line 106
    :cond_3
    invoke-virtual {p2}, Lzi2;->b0()V

    .line 107
    .line 108
    .line 109
    :goto_3
    return-object v1

    .line 110
    nop

    .line 111
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
