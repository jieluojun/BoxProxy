.class public final Lal3;
.super Lyd1;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public k:Lze4;

.field public l:Lt57;

.field public synthetic m:Ljava/lang/Object;

.field public final synthetic n:Lbl3;

.field public o:I


# direct methods
.method public constructor <init>(Lbl3;Lxd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lal3;->n:Lbl3;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lyd1;-><init>(Lxd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lal3;->m:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lal3;->o:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lal3;->o:I

    .line 9
    .line 10
    iget-object p1, p0, Lal3;->n:Lbl3;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, p0}, Lbl3;->f(Lze4;Lai2;Lxd1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
