.class public final synthetic Lag1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lii1;


# direct methods
.method public synthetic constructor <init>(Lii1;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lag1;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lag1;->i:Lii1;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 47

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lag1;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    const/4 v5, 0x0

    .line 10
    iget-object v0, v0, Lag1;->i:Lii1;

    .line 11
    .line 12
    packed-switch v1, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    move-object/from16 v1, p1

    .line 16
    .line 17
    check-cast v1, Lzi2;

    .line 18
    .line 19
    move-object/from16 v6, p2

    .line 20
    .line 21
    check-cast v6, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v6

    .line 27
    and-int/lit8 v7, v6, 0x3

    .line 28
    .line 29
    if-eq v7, v3, :cond_0

    .line 30
    .line 31
    move v5, v4

    .line 32
    :cond_0
    and-int/2addr v6, v4

    .line 33
    invoke-virtual {v1, v6, v5}, Lzi2;->Y(IZ)Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-eqz v3, :cond_1

    .line 38
    .line 39
    iget-object v0, v0, Lii1;->l:Lti1;

    .line 40
    .line 41
    iget-object v0, v0, Lti1;->a:Ljava/lang/String;

    .line 42
    .line 43
    invoke-static {v0}, Lsx;->v(Ljava/lang/String;)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-static {v0, v1}, Lxl3;->U(ILzi2;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    const/16 v26, 0x0

    .line 52
    .line 53
    const v27, 0x3fffe

    .line 54
    .line 55
    .line 56
    const/4 v7, 0x0

    .line 57
    const-wide/16 v8, 0x0

    .line 58
    .line 59
    const-wide/16 v10, 0x0

    .line 60
    .line 61
    const/4 v12, 0x0

    .line 62
    const/4 v13, 0x0

    .line 63
    const-wide/16 v14, 0x0

    .line 64
    .line 65
    const/16 v16, 0x0

    .line 66
    .line 67
    const-wide/16 v17, 0x0

    .line 68
    .line 69
    const/16 v19, 0x0

    .line 70
    .line 71
    const/16 v20, 0x0

    .line 72
    .line 73
    const/16 v21, 0x0

    .line 74
    .line 75
    const/16 v22, 0x0

    .line 76
    .line 77
    const/16 v23, 0x0

    .line 78
    .line 79
    const/16 v25, 0x0

    .line 80
    .line 81
    move-object/from16 v24, v1

    .line 82
    .line 83
    invoke-static/range {v6 .. v27}, Ltf7;->b(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILbi7;Lzi2;III)V

    .line 84
    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_1
    move-object/from16 v24, v1

    .line 88
    .line 89
    invoke-virtual/range {v24 .. v24}, Lzi2;->b0()V

    .line 90
    .line 91
    .line 92
    :goto_0
    return-object v2

    .line 93
    :pswitch_0
    move-object/from16 v1, p1

    .line 94
    .line 95
    check-cast v1, Lzi2;

    .line 96
    .line 97
    move-object/from16 v6, p2

    .line 98
    .line 99
    check-cast v6, Ljava/lang/Integer;

    .line 100
    .line 101
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 102
    .line 103
    .line 104
    move-result v6

    .line 105
    and-int/lit8 v7, v6, 0x3

    .line 106
    .line 107
    if-eq v7, v3, :cond_2

    .line 108
    .line 109
    move v5, v4

    .line 110
    :cond_2
    and-int/2addr v6, v4

    .line 111
    invoke-virtual {v1, v6, v5}, Lzi2;->Y(IZ)Z

    .line 112
    .line 113
    .line 114
    move-result v3

    .line 115
    if-eqz v3, :cond_3

    .line 116
    .line 117
    iget-object v0, v0, Lii1;->b:Ljava/lang/String;

    .line 118
    .line 119
    const/16 v45, 0x0

    .line 120
    .line 121
    const v46, 0x3fffe

    .line 122
    .line 123
    .line 124
    const/16 v26, 0x0

    .line 125
    .line 126
    const-wide/16 v27, 0x0

    .line 127
    .line 128
    const-wide/16 v29, 0x0

    .line 129
    .line 130
    const/16 v31, 0x0

    .line 131
    .line 132
    const/16 v32, 0x0

    .line 133
    .line 134
    const-wide/16 v33, 0x0

    .line 135
    .line 136
    const/16 v35, 0x0

    .line 137
    .line 138
    const-wide/16 v36, 0x0

    .line 139
    .line 140
    const/16 v38, 0x0

    .line 141
    .line 142
    const/16 v39, 0x0

    .line 143
    .line 144
    const/16 v40, 0x0

    .line 145
    .line 146
    const/16 v41, 0x0

    .line 147
    .line 148
    const/16 v42, 0x0

    .line 149
    .line 150
    const/16 v44, 0x0

    .line 151
    .line 152
    move-object/from16 v25, v0

    .line 153
    .line 154
    move-object/from16 v43, v1

    .line 155
    .line 156
    invoke-static/range {v25 .. v46}, Ltf7;->b(Ljava/lang/String;Lbb4;JJLhg2;Lgf2;JLca7;JIZIILbi7;Lzi2;III)V

    .line 157
    .line 158
    .line 159
    goto :goto_1

    .line 160
    :cond_3
    move-object/from16 v43, v1

    .line 161
    .line 162
    invoke-virtual/range {v43 .. v43}, Lzi2;->b0()V

    .line 163
    .line 164
    .line 165
    :goto_1
    return-object v2

    .line 166
    nop

    .line 167
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
.end method
