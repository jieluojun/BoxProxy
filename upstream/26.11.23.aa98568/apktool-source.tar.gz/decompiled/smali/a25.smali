.class public interface abstract La25;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbp7;


# virtual methods
.method public f()Ljava/lang/Object;
    .locals 0

    .line 1
    sget-object p0, Lh22;->J:Ljava/lang/Object;

    .line 2
    .line 3
    return-object p0
.end method

.method public abstract h1()Z
.end method

.method public abstract o1()Z
.end method
