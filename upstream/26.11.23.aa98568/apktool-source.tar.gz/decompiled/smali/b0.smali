.class public final synthetic Lb0;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lwh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Ljava/util/List;

.field public final synthetic j:Lwh2;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lwh2;B)V
    .locals 0

    .line 11
    iput-byte p3, p0, Lb0;->h:B

    iput-object p1, p0, Lb0;->i:Ljava/util/List;

    iput-object p2, p0, Lb0;->j:Lwh2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lwh2;Ljava/util/List;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lb0;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lb0;->j:Lwh2;

    .line 4
    .line 5
    iput-object p2, p0, Lb0;->i:Ljava/util/List;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget-byte v0, p0, Lb0;->h:B

    .line 2
    .line 3
    const v1, 0x2fd4df92

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    sget-object v3, Lst7;->a:Lst7;

    .line 8
    .line 9
    iget-object v4, p0, Lb0;->i:Ljava/util/List;

    .line 10
    .line 11
    iget-object p0, p0, Lb0;->j:Lwh2;

    .line 12
    .line 13
    packed-switch v0, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast p1, Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    if-nez p1, :cond_0

    .line 23
    .line 24
    new-instance p1, Lnl4;

    .line 25
    .line 26
    const/4 v0, 0x6

    .line 27
    invoke-direct {p1, v0}, Lnl4;-><init>(B)V

    .line 28
    .line 29
    .line 30
    invoke-interface {p0, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    sub-int/2addr p1, v2

    .line 35
    invoke-static {p1, v4}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    check-cast p1, Ljava/lang/String;

    .line 40
    .line 41
    if-eqz p1, :cond_1

    .line 42
    .line 43
    new-instance v0, Lp;

    .line 44
    .line 45
    const/16 v1, 0x1a

    .line 46
    .line 47
    invoke-direct {v0, p1, v1}, Lp;-><init>(Ljava/lang/String;B)V

    .line 48
    .line 49
    .line 50
    invoke-interface {p0, v0}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    :cond_1
    :goto_0
    return-object v3

    .line 54
    :pswitch_0
    check-cast p1, Ljava/lang/Integer;

    .line 55
    .line 56
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    invoke-interface {v4, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    invoke-interface {p0, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    return-object v3

    .line 68
    :pswitch_1
    check-cast p1, Ljava/lang/Integer;

    .line 69
    .line 70
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    invoke-interface {v4, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    check-cast p1, Ld75;

    .line 79
    .line 80
    iget-object p1, p1, Ld75;->h:Ljava/lang/Object;

    .line 81
    .line 82
    invoke-interface {p0, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    return-object v3

    .line 86
    :pswitch_2
    check-cast p1, Ljava/lang/Integer;

    .line 87
    .line 88
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 89
    .line 90
    .line 91
    move-result p1

    .line 92
    invoke-interface {v4, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    invoke-interface {p0, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    return-object v3

    .line 100
    :pswitch_3
    check-cast p1, Ljava/lang/Integer;

    .line 101
    .line 102
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 103
    .line 104
    .line 105
    move-result p1

    .line 106
    invoke-static {p1, v4}, Lay0;->W0(ILjava/util/List;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    check-cast p1, Ljava/lang/Integer;

    .line 111
    .line 112
    if-eqz p1, :cond_2

    .line 113
    .line 114
    invoke-interface {p0, p1}, Lwh2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    :cond_2
    return-object v3

    .line 118
    :pswitch_4
    check-cast p1, Lxm3;

    .line 119
    .line 120
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 121
    .line 122
    .line 123
    new-instance v0, Ll;

    .line 124
    .line 125
    const/4 v5, 0x5

    .line 126
    invoke-direct {v0, v5}, Ll;-><init>(B)V

    .line 127
    .line 128
    .line 129
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 130
    .line 131
    .line 132
    move-result v5

    .line 133
    new-instance v6, Lf0;

    .line 134
    .line 135
    const/4 v7, 0x3

    .line 136
    invoke-direct {v6, v0, v4, v7}, Lf0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 137
    .line 138
    .line 139
    new-instance v0, Lg0;

    .line 140
    .line 141
    invoke-direct {v0, v4, v7}, Lg0;-><init>(Ljava/util/List;B)V

    .line 142
    .line 143
    .line 144
    new-instance v7, Lk0;

    .line 145
    .line 146
    invoke-direct {v7, v4, p0, v2}, Lk0;-><init>(Ljava/util/List;Lwh2;B)V

    .line 147
    .line 148
    .line 149
    new-instance p0, Ls21;

    .line 150
    .line 151
    invoke-direct {p0, v1, v2, v7}, Ls21;-><init>(IZLjava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {p1, v5, v6, v0, p0}, Lxm3;->w0(ILwh2;Lwh2;Ls21;)V

    .line 155
    .line 156
    .line 157
    return-object v3

    .line 158
    :pswitch_5
    check-cast p1, Lxm3;

    .line 159
    .line 160
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 161
    .line 162
    .line 163
    new-instance v0, Ll;

    .line 164
    .line 165
    const/4 v5, 0x0

    .line 166
    invoke-direct {v0, v5}, Ll;-><init>(B)V

    .line 167
    .line 168
    .line 169
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 170
    .line 171
    .line 172
    move-result v6

    .line 173
    new-instance v7, Lf0;

    .line 174
    .line 175
    invoke-direct {v7, v0, v4, v2}, Lf0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 176
    .line 177
    .line 178
    new-instance v0, Lg0;

    .line 179
    .line 180
    invoke-direct {v0, v4, v2}, Lg0;-><init>(Ljava/util/List;B)V

    .line 181
    .line 182
    .line 183
    new-instance v8, Lk0;

    .line 184
    .line 185
    invoke-direct {v8, v4, p0, v5}, Lk0;-><init>(Ljava/util/List;Lwh2;B)V

    .line 186
    .line 187
    .line 188
    new-instance p0, Ls21;

    .line 189
    .line 190
    invoke-direct {p0, v1, v2, v8}, Ls21;-><init>(IZLjava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {p1, v6, v7, v0, p0}, Lxm3;->w0(ILwh2;Lwh2;Ls21;)V

    .line 194
    .line 195
    .line 196
    return-object v3

    .line 197
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method
