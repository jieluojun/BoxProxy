.class public final Laz2;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic l:B

.field public m:Z

.field public final synthetic n:Lcz2;


# direct methods
.method public constructor <init>(Lcz2;Lxd1;)V
    .locals 1

    const/4 v0, 0x1

    iput-byte v0, p0, Laz2;->l:B

    .line 13
    iput-object p1, p0, Laz2;->n:Lcz2;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lt57;-><init>(ILxd1;)V

    return-void
.end method

.method public constructor <init>(Lcz2;ZLxd1;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Laz2;->l:B

    .line 3
    .line 4
    iput-object p1, p0, Laz2;->n:Lcz2;

    .line 5
    .line 6
    iput-boolean p2, p0, Laz2;->m:Z

    .line 7
    .line 8
    const/4 p1, 0x2

    .line 9
    invoke-direct {p0, p1, p3}, Lt57;-><init>(ILxd1;)V

    .line 10
    .line 11
    .line 12
    return-void
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Laz2;->l:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    check-cast p1, Ljj1;

    .line 6
    .line 7
    check-cast p2, Lxd1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Laz2;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Laz2;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Laz2;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    invoke-virtual {p0, p2, p1}, Laz2;->s(Lxd1;Ljava/lang/Object;)Lxd1;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Laz2;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Laz2;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    return-object v1

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final s(Lxd1;Ljava/lang/Object;)Lxd1;
    .locals 1

    .line 1
    iget-byte p2, p0, Laz2;->l:B

    .line 2
    .line 3
    iget-object v0, p0, Laz2;->n:Lcz2;

    .line 4
    .line 5
    packed-switch p2, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance p0, Laz2;

    .line 9
    .line 10
    invoke-direct {p0, v0, p1}, Laz2;-><init>(Lcz2;Lxd1;)V

    .line 11
    .line 12
    .line 13
    return-object p0

    .line 14
    :pswitch_0
    new-instance p2, Laz2;

    .line 15
    .line 16
    iget-boolean p0, p0, Laz2;->m:Z

    .line 17
    .line 18
    invoke-direct {p2, v0, p0, p1}, Laz2;-><init>(Lcz2;ZLxd1;)V

    .line 19
    .line 20
    .line 21
    return-object p2

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, Laz2;->l:B

    .line 2
    .line 3
    sget-object v1, Lst7;->a:Lst7;

    .line 4
    .line 5
    iget-object v2, p0, Laz2;->n:Lcz2;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    iget-boolean v0, p0, Laz2;->m:Z

    .line 12
    .line 13
    const/4 v4, 0x1

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    if-ne v0, v4, :cond_0

    .line 17
    .line 18
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 23
    .line 24
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    move-object v1, v3

    .line 28
    goto :goto_2

    .line 29
    :cond_1
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    sget-object p1, Lhz2;->a:Lhz2;

    .line 33
    .line 34
    iput-boolean v4, p0, Laz2;->m:Z

    .line 35
    .line 36
    sget-object p1, Lzr1;->a:Lao1;

    .line 37
    .line 38
    sget-object p1, Lqn1;->j:Lqn1;

    .line 39
    .line 40
    new-instance v0, Ljy;

    .line 41
    .line 42
    const/4 v4, 0x2

    .line 43
    const/16 v5, 0x8

    .line 44
    .line 45
    invoke-direct {v0, v4, v3, v5}, Ljy;-><init>(ILxd1;B)V

    .line 46
    .line 47
    .line 48
    invoke-static {p1, v0, p0}, Lbw;->f0(Laj1;Lai2;Lxd1;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    sget-object p0, Lkj1;->h:Lkj1;

    .line 53
    .line 54
    if-ne p1, p0, :cond_2

    .line 55
    .line 56
    move-object v1, p0

    .line 57
    goto :goto_2

    .line 58
    :cond_2
    :goto_0
    check-cast p1, Ldz2;

    .line 59
    .line 60
    iget-object p0, v2, Lcz2;->d:Lyy2;

    .line 61
    .line 62
    iget-boolean v0, p1, Ldz2;->a:Z

    .line 63
    .line 64
    if-eqz v0, :cond_3

    .line 65
    .line 66
    iget-object p1, v2, Lcz2;->c:Ljava/lang/String;

    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_3
    iget-object p1, p1, Ldz2;->b:Ljava/lang/String;

    .line 70
    .line 71
    invoke-static {p1}, Lf17;->A0(Ljava/lang/CharSequence;)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_4

    .line 76
    .line 77
    iget-object p1, v2, Lcz2;->b:Ljava/lang/String;

    .line 78
    .line 79
    :cond_4
    :goto_1
    invoke-virtual {p0, p1}, Lyy2;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    iget-object p0, v2, Lcz2;->f:Lz75;

    .line 83
    .line 84
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 85
    .line 86
    invoke-virtual {p0, p1}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    :goto_2
    return-object v1

    .line 90
    :pswitch_0
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    iget-boolean p0, p0, Laz2;->m:Z

    .line 94
    .line 95
    invoke-virtual {v2}, Lcz2;->a()Loz2;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    if-eqz p1, :cond_5

    .line 100
    .line 101
    iget-object v0, v2, Lcz2;->f:Lz75;

    .line 102
    .line 103
    invoke-virtual {v0}, Lz75;->getValue()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    check-cast v0, Ljava/lang/Boolean;

    .line 108
    .line 109
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-nez v0, :cond_5

    .line 114
    .line 115
    iget-boolean p1, p1, Loz2;->h:Z

    .line 116
    .line 117
    if-ne p0, p1, :cond_5

    .line 118
    .line 119
    iget-object p0, v2, Lcz2;->e:Lz75;

    .line 120
    .line 121
    invoke-virtual {p0, v3}, Lz75;->setValue(Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    :cond_5
    return-object v1

    .line 125
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method
