.class public final Laf;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lnb7;


# instance fields
.field public final a:Landroid/view/View;

.field public final b:Lwh2;

.field public final c:Llh2;

.field public final d:Lff4;

.field public final e:Lpw6;

.field public final f:Lte;

.field public final g:Lte;

.field public h:Landroid/view/ActionMode;

.field public i:Lze;

.field public j:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Landroid/view/View;Lwh2;Llh2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Laf;->a:Landroid/view/View;

    .line 5
    .line 6
    iput-object p2, p0, Laf;->b:Lwh2;

    .line 7
    .line 8
    iput-object p3, p0, Laf;->c:Llh2;

    .line 9
    .line 10
    new-instance p1, Lff4;

    .line 11
    .line 12
    invoke-direct {p1}, Lff4;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Laf;->d:Lff4;

    .line 16
    .line 17
    new-instance p1, Lpw6;

    .line 18
    .line 19
    new-instance p2, Lte;

    .line 20
    .line 21
    const/4 p3, 0x0

    .line 22
    invoke-direct {p2, p0, p3}, Lte;-><init>(Laf;B)V

    .line 23
    .line 24
    .line 25
    invoke-direct {p1, p2}, Lpw6;-><init>(Lwh2;)V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, Laf;->e:Lpw6;

    .line 29
    .line 30
    new-instance p1, Lte;

    .line 31
    .line 32
    const/4 p2, 0x1

    .line 33
    invoke-direct {p1, p0, p2}, Lte;-><init>(Laf;B)V

    .line 34
    .line 35
    .line 36
    iput-object p1, p0, Laf;->f:Lte;

    .line 37
    .line 38
    new-instance p1, Lte;

    .line 39
    .line 40
    const/4 p2, 0x2

    .line 41
    invoke-direct {p1, p0, p2}, Lte;-><init>(Laf;B)V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, Laf;->g:Lte;

    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final a(Leb7;Lyd1;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, Lye;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lye;

    .line 7
    .line 8
    iget v1, v0, Lye;->m:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lye;->m:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lye;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lye;-><init>(Laf;Lyd1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lye;->k:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lye;->m:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x1

    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    if-ne v1, v3, :cond_1

    .line 34
    .line 35
    invoke-static {p2}, Lyl3;->M(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 40
    .line 41
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v2

    .line 45
    :cond_2
    invoke-static {p2}, Lyl3;->M(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    new-instance p2, Lq9;

    .line 49
    .line 50
    invoke-direct {p2, p0, p1, v2, v3}, Lq9;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lxd1;B)V

    .line 51
    .line 52
    .line 53
    iput v3, v0, Lye;->m:I

    .line 54
    .line 55
    iget-object p0, p0, Laf;->d:Lff4;

    .line 56
    .line 57
    invoke-static {p0, p2, v0}, Lff4;->a(Lff4;Lwh2;Lyd1;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    sget-object p1, Lkj1;->h:Lkj1;

    .line 62
    .line 63
    if-ne p0, p1, :cond_3

    .line 64
    .line 65
    return-object p1

    .line 66
    :cond_3
    :goto_1
    sget-object p0, Lst7;->a:Lst7;

    .line 67
    .line 68
    return-object p0
.end method
