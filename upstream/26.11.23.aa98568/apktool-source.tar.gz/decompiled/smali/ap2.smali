.class public final synthetic Lap2;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Llh2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lv52;


# direct methods
.method public synthetic constructor <init>(Lv52;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lap2;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lap2;->i:Lv52;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lap2;->h:B

    .line 2
    .line 3
    const/high16 v1, 0x3f800000    # 1.0f

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object p0, p0, Lap2;->i:Lv52;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    if-eqz p0, :cond_0

    .line 12
    .line 13
    iget-object p0, p0, Lv52;->a:Ljn7;

    .line 14
    .line 15
    if-eqz p0, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0}, Ljn7;->a()F

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    move p0, v2

    .line 23
    :goto_0
    const/high16 v0, 0x40400000    # 3.0f

    .line 24
    .line 25
    mul-float/2addr p0, v0

    .line 26
    invoke-static {p0, v2, v1}, Lej3;->u(FFF)F

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    :goto_1
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    return-object p0

    .line 35
    :pswitch_0
    if-eqz p0, :cond_1

    .line 36
    .line 37
    iget-object p0, p0, Lv52;->a:Ljn7;

    .line 38
    .line 39
    if-eqz p0, :cond_1

    .line 40
    .line 41
    iget-object p0, p0, Ljn7;->e:Lv75;

    .line 42
    .line 43
    invoke-virtual {p0}, Lv75;->h()F

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    :cond_1
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    return-object p0

    .line 52
    :pswitch_1
    iget-object p0, p0, Lv52;->a:Ljn7;

    .line 53
    .line 54
    invoke-virtual {p0}, Ljn7;->a()F

    .line 55
    .line 56
    .line 57
    move-result p0

    .line 58
    invoke-static {p0, v2, v1}, Lej3;->u(FFF)F

    .line 59
    .line 60
    .line 61
    move-result p0

    .line 62
    goto :goto_1

    .line 63
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
