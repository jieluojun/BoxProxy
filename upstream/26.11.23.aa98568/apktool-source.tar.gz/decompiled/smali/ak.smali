.class public abstract Lak;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# direct methods
.method public static final a(Landroid/view/ViewTreeObserver;)V
    .locals 0

    .line 1
    invoke-static {p0}, Ll5;->b(Landroid/view/ViewTreeObserver;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
