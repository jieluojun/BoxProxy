.class public final synthetic La54;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lgy3;

.field public final synthetic j:Lte4;

.field public final synthetic k:Lte4;

.field public final synthetic l:Lte4;


# direct methods
.method public synthetic constructor <init>(Lgy3;Lte4;Lte4;Lte4;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, La54;->h:B

    .line 2
    .line 3
    iput-object p1, p0, La54;->i:Lgy3;

    .line 4
    .line 5
    iput-object p2, p0, La54;->j:Lte4;

    .line 6
    .line 7
    iput-object p3, p0, La54;->k:Lte4;

    .line 8
    .line 9
    iput-object p4, p0, La54;->l:Lte4;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La54;->h:B

    .line 4
    .line 5
    sget-object v2, Lst7;->a:Lst7;

    .line 6
    .line 7
    sget-object v3, Lc51;->a:Lql0;

    .line 8
    .line 9
    sget-object v4, Lzi3;->Z:Lu43;

    .line 10
    .line 11
    sget-object v5, Lya4;->h:Lya4;

    .line 12
    .line 13
    const/16 v6, 0x10

    .line 14
    .line 15
    iget-object v7, v0, La54;->l:Lte4;

    .line 16
    .line 17
    iget-object v8, v0, La54;->k:Lte4;

    .line 18
    .line 19
    iget-object v9, v0, La54;->j:Lte4;

    .line 20
    .line 21
    iget-object v0, v0, La54;->i:Lgy3;

    .line 22
    .line 23
    const/4 v10, 0x0

    .line 24
    const/4 v11, 0x1

    .line 25
    packed-switch v1, :pswitch_data_0

    .line 26
    .line 27
    .line 28
    move-object/from16 v1, p1

    .line 29
    .line 30
    check-cast v1, Lp26;

    .line 31
    .line 32
    move-object/from16 v12, p2

    .line 33
    .line 34
    check-cast v12, Lzi2;

    .line 35
    .line 36
    move-object/from16 v13, p3

    .line 37
    .line 38
    check-cast v13, Ljava/lang/Integer;

    .line 39
    .line 40
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 41
    .line 42
    .line 43
    move-result v13

    .line 44
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    and-int/lit8 v1, v13, 0x11

    .line 48
    .line 49
    if-eq v1, v6, :cond_0

    .line 50
    .line 51
    move v1, v11

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    move v1, v10

    .line 54
    :goto_0
    and-int/2addr v13, v11

    .line 55
    invoke-virtual {v12, v13, v1}, Lzi2;->Y(IZ)Z

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    if-eqz v1, :cond_8

    .line 60
    .line 61
    sget-object v1, Ly6;->j:Lb40;

    .line 62
    .line 63
    invoke-static {v1, v10}, Lzc0;->c(Lb40;Z)Lu14;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    iget-wide v13, v12, Lzi2;->U:J

    .line 68
    .line 69
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 70
    .line 71
    .line 72
    move-result v6

    .line 73
    invoke-virtual {v12}, Lzi2;->m()Lla5;

    .line 74
    .line 75
    .line 76
    move-result-object v10

    .line 77
    invoke-static {v12, v5}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 78
    .line 79
    .line 80
    move-result-object v5

    .line 81
    sget-object v13, Ls41;->d:Ly6;

    .line 82
    .line 83
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v12}, Lzi2;->k0()V

    .line 87
    .line 88
    .line 89
    iget-boolean v13, v12, Lzi2;->T:Z

    .line 90
    .line 91
    if-eqz v13, :cond_1

    .line 92
    .line 93
    invoke-virtual {v12, v4}, Lzi2;->l(Llh2;)V

    .line 94
    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_1
    invoke-virtual {v12}, Lzi2;->t0()V

    .line 98
    .line 99
    .line 100
    :goto_1
    sget-object v4, Ly6;->T:Lx31;

    .line 101
    .line 102
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    sget-object v1, Ly6;->S:Lx31;

    .line 106
    .line 107
    invoke-static {v1, v12, v10}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    sget-object v4, Ly6;->U:Lx31;

    .line 115
    .line 116
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    invoke-static {v12}, Lfa7;->k(Lzi2;)V

    .line 120
    .line 121
    .line 122
    sget-object v1, Ly6;->R:Lx31;

    .line 123
    .line 124
    invoke-static {v1, v12, v5}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    invoke-interface {v9}, Lmz6;->getValue()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    check-cast v1, Ljava/lang/Boolean;

    .line 132
    .line 133
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v4

    .line 141
    if-ne v4, v3, :cond_2

    .line 142
    .line 143
    new-instance v4, Ln54;

    .line 144
    .line 145
    invoke-direct {v4, v9, v11}, Ln54;-><init>(Lte4;B)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v12, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    :cond_2
    move-object v13, v4

    .line 152
    check-cast v13, Llh2;

    .line 153
    .line 154
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object v4

    .line 158
    if-ne v4, v3, :cond_3

    .line 159
    .line 160
    new-instance v4, Les0;

    .line 161
    .line 162
    const/16 v5, 0xe

    .line 163
    .line 164
    invoke-direct {v4, v9, v8, v5}, Les0;-><init>(Lte4;Lte4;B)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v12, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    :cond_3
    move-object v14, v4

    .line 171
    check-cast v14, Llh2;

    .line 172
    .line 173
    invoke-virtual {v12, v0}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v4

    .line 177
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v5

    .line 181
    if-nez v4, :cond_4

    .line 182
    .line 183
    if-ne v5, v3, :cond_5

    .line 184
    .line 185
    :cond_4
    new-instance v5, Ld54;

    .line 186
    .line 187
    invoke-direct {v5, v0, v9, v11}, Ld54;-><init>(Lgy3;Lte4;B)V

    .line 188
    .line 189
    .line 190
    invoke-virtual {v12, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    :cond_5
    move-object v15, v5

    .line 194
    check-cast v15, Llh2;

    .line 195
    .line 196
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    if-ne v0, v3, :cond_6

    .line 201
    .line 202
    new-instance v0, Les0;

    .line 203
    .line 204
    const/16 v4, 0xf

    .line 205
    .line 206
    invoke-direct {v0, v9, v7, v4}, Les0;-><init>(Lte4;Lte4;B)V

    .line 207
    .line 208
    .line 209
    invoke-virtual {v12, v0}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    :cond_6
    move-object/from16 v16, v0

    .line 213
    .line 214
    check-cast v16, Llh2;

    .line 215
    .line 216
    const/16 v18, 0x61b0

    .line 217
    .line 218
    move-object/from16 v17, v12

    .line 219
    .line 220
    move v12, v1

    .line 221
    invoke-static/range {v12 .. v18}, Luk3;->k(ZLlh2;Llh2;Llh2;Llh2;Lzi2;I)V

    .line 222
    .line 223
    .line 224
    move-object/from16 v0, v17

    .line 225
    .line 226
    invoke-virtual {v0}, Lzi2;->T()Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    if-ne v1, v3, :cond_7

    .line 231
    .line 232
    new-instance v1, Ln54;

    .line 233
    .line 234
    const/4 v3, 0x2

    .line 235
    invoke-direct {v1, v9, v3}, Ln54;-><init>(Lte4;B)V

    .line 236
    .line 237
    .line 238
    invoke-virtual {v0, v1}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 239
    .line 240
    .line 241
    :cond_7
    move-object v12, v1

    .line 242
    check-cast v12, Llh2;

    .line 243
    .line 244
    invoke-interface {v9}, Lmz6;->getValue()Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object v1

    .line 248
    check-cast v1, Ljava/lang/Boolean;

    .line 249
    .line 250
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 251
    .line 252
    .line 253
    move-result v15

    .line 254
    sget-object v21, Lkb;->o:Ls21;

    .line 255
    .line 256
    const v23, 0x6000006

    .line 257
    .line 258
    .line 259
    const/16 v24, 0xf6

    .line 260
    .line 261
    const/4 v13, 0x0

    .line 262
    const/4 v14, 0x0

    .line 263
    const-wide/16 v16, 0x0

    .line 264
    .line 265
    const/16 v18, 0x0

    .line 266
    .line 267
    const/16 v19, 0x0

    .line 268
    .line 269
    const/16 v20, 0x0

    .line 270
    .line 271
    move-object/from16 v22, v0

    .line 272
    .line 273
    invoke-static/range {v12 .. v24}, Lla4;->b(Llh2;Lbb4;ZZJFFFLai2;Lzi2;II)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v0, v11}, Lzi2;->r(Z)V

    .line 277
    .line 278
    .line 279
    goto :goto_2

    .line 280
    :cond_8
    move-object v0, v12

    .line 281
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 282
    .line 283
    .line 284
    :goto_2
    return-object v2

    .line 285
    :pswitch_0
    move-object/from16 v1, p1

    .line 286
    .line 287
    check-cast v1, Lp26;

    .line 288
    .line 289
    move-object/from16 v12, p2

    .line 290
    .line 291
    check-cast v12, Lzi2;

    .line 292
    .line 293
    move-object/from16 v13, p3

    .line 294
    .line 295
    check-cast v13, Ljava/lang/Integer;

    .line 296
    .line 297
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 298
    .line 299
    .line 300
    move-result v13

    .line 301
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 302
    .line 303
    .line 304
    and-int/lit8 v1, v13, 0x11

    .line 305
    .line 306
    if-eq v1, v6, :cond_9

    .line 307
    .line 308
    move v1, v11

    .line 309
    goto :goto_3

    .line 310
    :cond_9
    move v1, v10

    .line 311
    :goto_3
    and-int/2addr v13, v11

    .line 312
    invoke-virtual {v12, v13, v1}, Lzi2;->Y(IZ)Z

    .line 313
    .line 314
    .line 315
    move-result v1

    .line 316
    if-eqz v1, :cond_11

    .line 317
    .line 318
    sget-object v1, Ly6;->j:Lb40;

    .line 319
    .line 320
    invoke-static {v1, v10}, Lzc0;->c(Lb40;Z)Lu14;

    .line 321
    .line 322
    .line 323
    move-result-object v1

    .line 324
    iget-wide v13, v12, Lzi2;->U:J

    .line 325
    .line 326
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 327
    .line 328
    .line 329
    move-result v6

    .line 330
    invoke-virtual {v12}, Lzi2;->m()Lla5;

    .line 331
    .line 332
    .line 333
    move-result-object v13

    .line 334
    invoke-static {v12, v5}, Lsx;->M(Lzi2;Lbb4;)Lbb4;

    .line 335
    .line 336
    .line 337
    move-result-object v5

    .line 338
    sget-object v14, Ls41;->d:Ly6;

    .line 339
    .line 340
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 341
    .line 342
    .line 343
    invoke-virtual {v12}, Lzi2;->k0()V

    .line 344
    .line 345
    .line 346
    iget-boolean v14, v12, Lzi2;->T:Z

    .line 347
    .line 348
    if-eqz v14, :cond_a

    .line 349
    .line 350
    invoke-virtual {v12, v4}, Lzi2;->l(Llh2;)V

    .line 351
    .line 352
    .line 353
    goto :goto_4

    .line 354
    :cond_a
    invoke-virtual {v12}, Lzi2;->t0()V

    .line 355
    .line 356
    .line 357
    :goto_4
    sget-object v4, Ly6;->T:Lx31;

    .line 358
    .line 359
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 360
    .line 361
    .line 362
    sget-object v1, Ly6;->S:Lx31;

    .line 363
    .line 364
    invoke-static {v1, v12, v13}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 365
    .line 366
    .line 367
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 368
    .line 369
    .line 370
    move-result-object v1

    .line 371
    sget-object v4, Ly6;->U:Lx31;

    .line 372
    .line 373
    invoke-static {v4, v12, v1}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 374
    .line 375
    .line 376
    invoke-static {v12}, Lfa7;->k(Lzi2;)V

    .line 377
    .line 378
    .line 379
    sget-object v1, Ly6;->R:Lx31;

    .line 380
    .line 381
    invoke-static {v1, v12, v5}, Lfa7;->o(Lai2;Lzi2;Ljava/lang/Object;)V

    .line 382
    .line 383
    .line 384
    invoke-interface {v9}, Lmz6;->getValue()Ljava/lang/Object;

    .line 385
    .line 386
    .line 387
    move-result-object v1

    .line 388
    check-cast v1, Ljava/lang/Boolean;

    .line 389
    .line 390
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 391
    .line 392
    .line 393
    move-result v1

    .line 394
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v4

    .line 398
    if-ne v4, v3, :cond_b

    .line 399
    .line 400
    new-instance v4, Lgw2;

    .line 401
    .line 402
    const/16 v5, 0x1a

    .line 403
    .line 404
    invoke-direct {v4, v9, v5}, Lgw2;-><init>(Lte4;B)V

    .line 405
    .line 406
    .line 407
    invoke-virtual {v12, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 408
    .line 409
    .line 410
    :cond_b
    move-object v13, v4

    .line 411
    check-cast v13, Llh2;

    .line 412
    .line 413
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 414
    .line 415
    .line 416
    move-result-object v4

    .line 417
    if-ne v4, v3, :cond_c

    .line 418
    .line 419
    new-instance v4, Les0;

    .line 420
    .line 421
    const/16 v5, 0xc

    .line 422
    .line 423
    invoke-direct {v4, v9, v8, v5}, Les0;-><init>(Lte4;Lte4;B)V

    .line 424
    .line 425
    .line 426
    invoke-virtual {v12, v4}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 427
    .line 428
    .line 429
    :cond_c
    move-object v14, v4

    .line 430
    check-cast v14, Llh2;

    .line 431
    .line 432
    invoke-virtual {v12, v0}, Lzi2;->i(Ljava/lang/Object;)Z

    .line 433
    .line 434
    .line 435
    move-result v4

    .line 436
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 437
    .line 438
    .line 439
    move-result-object v5

    .line 440
    if-nez v4, :cond_d

    .line 441
    .line 442
    if-ne v5, v3, :cond_e

    .line 443
    .line 444
    :cond_d
    new-instance v5, Ld54;

    .line 445
    .line 446
    invoke-direct {v5, v0, v9, v10}, Ld54;-><init>(Lgy3;Lte4;B)V

    .line 447
    .line 448
    .line 449
    invoke-virtual {v12, v5}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 450
    .line 451
    .line 452
    :cond_e
    move-object v15, v5

    .line 453
    check-cast v15, Llh2;

    .line 454
    .line 455
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v0

    .line 459
    if-ne v0, v3, :cond_f

    .line 460
    .line 461
    new-instance v0, Les0;

    .line 462
    .line 463
    const/16 v4, 0xd

    .line 464
    .line 465
    invoke-direct {v0, v9, v7, v4}, Les0;-><init>(Lte4;Lte4;B)V

    .line 466
    .line 467
    .line 468
    invoke-virtual {v12, v0}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 469
    .line 470
    .line 471
    :cond_f
    move-object/from16 v16, v0

    .line 472
    .line 473
    check-cast v16, Llh2;

    .line 474
    .line 475
    const/16 v18, 0x61b0

    .line 476
    .line 477
    move-object/from16 v17, v12

    .line 478
    .line 479
    move v12, v1

    .line 480
    invoke-static/range {v12 .. v18}, Lpm6;->i(ZLlh2;Llh2;Llh2;Llh2;Lzi2;I)V

    .line 481
    .line 482
    .line 483
    move-object/from16 v0, v17

    .line 484
    .line 485
    invoke-virtual {v0}, Lzi2;->T()Ljava/lang/Object;

    .line 486
    .line 487
    .line 488
    move-result-object v1

    .line 489
    if-ne v1, v3, :cond_10

    .line 490
    .line 491
    new-instance v1, Lgw2;

    .line 492
    .line 493
    const/16 v3, 0x1b

    .line 494
    .line 495
    invoke-direct {v1, v9, v3}, Lgw2;-><init>(Lte4;B)V

    .line 496
    .line 497
    .line 498
    invoke-virtual {v0, v1}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 499
    .line 500
    .line 501
    :cond_10
    move-object v12, v1

    .line 502
    check-cast v12, Llh2;

    .line 503
    .line 504
    sget-object v17, Lj58;->h:Ls21;

    .line 505
    .line 506
    const v19, 0x180006

    .line 507
    .line 508
    .line 509
    const/16 v20, 0x3e

    .line 510
    .line 511
    const/4 v13, 0x0

    .line 512
    const/4 v14, 0x0

    .line 513
    const/4 v15, 0x0

    .line 514
    const/16 v16, 0x0

    .line 515
    .line 516
    move-object/from16 v18, v0

    .line 517
    .line 518
    invoke-static/range {v12 .. v20}, Lhw;->u(Llh2;Lbb4;ZLi43;Lbo6;Lai2;Lzi2;II)V

    .line 519
    .line 520
    .line 521
    invoke-virtual {v0, v11}, Lzi2;->r(Z)V

    .line 522
    .line 523
    .line 524
    goto :goto_5

    .line 525
    :cond_11
    move-object v0, v12

    .line 526
    invoke-virtual {v0}, Lzi2;->b0()V

    .line 527
    .line 528
    .line 529
    :goto_5
    return-object v2

    .line 530
    nop

    .line 531
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
