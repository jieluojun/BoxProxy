.class public final Lb4;
.super Lt57;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lbi2;


# instance fields
.field public l:Z

.field public synthetic m:Lxf5;

.field public synthetic n:J

.field public final synthetic o:Leg5;


# direct methods
.method public constructor <init>(Leg5;Lxd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lb4;->o:Leg5;

    .line 2
    .line 3
    const/4 p1, 0x3

    .line 4
    invoke-direct {p0, p1, p2}, Lt57;-><init>(ILxd1;)V

    .line 5
    .line 6
    .line 7
    return-void
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    check-cast p1, Lxf5;

    .line 2
    .line 3
    check-cast p2, Lcw4;

    .line 4
    .line 5
    iget-wide v0, p2, Lcw4;->a:J

    .line 6
    .line 7
    check-cast p3, Lxd1;

    .line 8
    .line 9
    new-instance p2, Lb4;

    .line 10
    .line 11
    iget-object p0, p0, Lb4;->o:Leg5;

    .line 12
    .line 13
    invoke-direct {p2, p0, p3}, Lb4;-><init>(Leg5;Lxd1;)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p2, Lb4;->m:Lxf5;

    .line 17
    .line 18
    iput-wide v0, p2, Lb4;->n:J

    .line 19
    .line 20
    sget-object p0, Lst7;->a:Lst7;

    .line 21
    .line 22
    invoke-virtual {p2, p0}, Lb4;->v(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method

.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget-object v1, p0, Lb4;->m:Lxf5;

    .line 2
    .line 3
    iget-wide v2, p0, Lb4;->n:J

    .line 4
    .line 5
    iget-boolean v0, p0, Lb4;->l:Z

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    sget-object v7, Lst7;->a:Lst7;

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    if-ne v0, v5, :cond_0

    .line 14
    .line 15
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-object v7

    .line 19
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 20
    .line 21
    invoke-static {p0}, Ll42;->d(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-object v4

    .line 25
    :cond_1
    invoke-static {p1}, Lyl3;->M(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    move p1, v5

    .line 29
    iget-object v5, p0, Lb4;->o:Leg5;

    .line 30
    .line 31
    iget-boolean v0, v5, Leg5;->z:Z

    .line 32
    .line 33
    if-eqz v0, :cond_4

    .line 34
    .line 35
    iput-object v4, p0, Lb4;->m:Lxf5;

    .line 36
    .line 37
    iput-wide v2, p0, Lb4;->n:J

    .line 38
    .line 39
    iput-boolean p1, p0, Lb4;->l:Z

    .line 40
    .line 41
    iget-object v4, v5, Leg5;->x:Ltd4;

    .line 42
    .line 43
    sget-object p1, Lkj1;->h:Lkj1;

    .line 44
    .line 45
    if-eqz v4, :cond_2

    .line 46
    .line 47
    new-instance v0, Lc4;

    .line 48
    .line 49
    const/4 v6, 0x0

    .line 50
    invoke-direct/range {v0 .. v6}, Lc4;-><init>(Lxf5;JLtd4;Leg5;Lxd1;)V

    .line 51
    .line 52
    .line 53
    invoke-static {v0, p0}, Luu;->Q(Lai2;Lxd1;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    if-eq p0, p1, :cond_3

    .line 58
    .line 59
    :cond_2
    move-object p0, v7

    .line 60
    :cond_3
    if-ne p0, p1, :cond_4

    .line 61
    .line 62
    return-object p1

    .line 63
    :cond_4
    return-object v7
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
.end method
