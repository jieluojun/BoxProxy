.class public final Lab;
.super Lyd1;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# instance fields
.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Lbb;

.field public m:I


# direct methods
.method public constructor <init>(Lbb;Lyd1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lab;->l:Lbb;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lyd1;-><init>(Lxd1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lab;->k:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lab;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lab;->m:I

    .line 9
    .line 10
    iget-object p1, p0, Lab;->l:Lbb;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lbb;->H(Lik6;Lyd1;)V

    .line 14
    .line 15
    .line 16
    sget-object p0, Lkj1;->h:Lkj1;

    .line 17
    .line 18
    return-object p0
.end method
