.class public final La83;
.super Lab4;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lcw1;


# instance fields
.field public A:F

.field public v:Lbo6;

.field public w:Llh2;

.field public x:Lsq2;

.field public final y:Lwz4;

.field public final z:Lgd;


# direct methods
.method public constructor <init>(Lbo6;Llh2;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, Lab4;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, La83;->v:Lbo6;

    .line 11
    .line 12
    iput-object p2, p0, La83;->w:Llh2;

    .line 13
    .line 14
    invoke-static {}, Lj58;->x()Lwz4;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, La83;->y:Lwz4;

    .line 19
    .line 20
    invoke-static {}, Lid;->a()Lgd;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, La83;->z:Lgd;

    .line 25
    .line 26
    const/high16 p1, 0x7fc00000    # Float.NaN

    .line 27
    .line 28
    iput p1, p0, La83;->A:F

    .line 29
    .line 30
    return-void
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final l0(Lbj3;)V
    .locals 13

    .line 1
    iget-object v0, p1, Lbj3;->h:Ltl0;

    .line 2
    .line 3
    invoke-virtual {p1}, Lbj3;->c()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, La83;->w:Llh2;

    .line 7
    .line 8
    invoke-interface {v1}, Llh2;->a()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Lx73;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    iget-wide v2, v1, Lx73;->b:J

    .line 17
    .line 18
    iget-object v4, p0, La83;->x:Lsq2;

    .line 19
    .line 20
    if-nez v4, :cond_1

    .line 21
    .line 22
    :cond_0
    return-void

    .line 23
    :cond_1
    iget v5, v1, Lx73;->a:F

    .line 24
    .line 25
    invoke-virtual {p1, v5}, Lbj3;->L(F)F

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    invoke-static {v2, v3}, Lqt1;->a(J)F

    .line 30
    .line 31
    .line 32
    move-result v6

    .line 33
    invoke-virtual {p1, v6}, Lbj3;->L(F)F

    .line 34
    .line 35
    .line 36
    move-result v10

    .line 37
    invoke-static {v2, v3}, Lqt1;->b(J)F

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    invoke-virtual {p1, v2}, Lbj3;->L(F)F

    .line 42
    .line 43
    .line 44
    move-result v11

    .line 45
    iget-object v2, p0, La83;->v:Lbo6;

    .line 46
    .line 47
    invoke-interface {v0}, Ldw1;->b()J

    .line 48
    .line 49
    .line 50
    move-result-wide v6

    .line 51
    invoke-virtual {p1}, Lbj3;->getLayoutDirection()Lii3;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    invoke-interface {v2, v6, v7, v3, p1}, Lbo6;->b(JLii3;Lkp1;)Luk3;

    .line 56
    .line 57
    .line 58
    move-result-object v9

    .line 59
    iget-object v2, p0, La83;->z:Lgd;

    .line 60
    .line 61
    invoke-virtual {v2}, Lgd;->i()V

    .line 62
    .line 63
    .line 64
    if-eqz v9, :cond_8

    .line 65
    .line 66
    instance-of v3, v9, La15;

    .line 67
    .line 68
    if-eqz v3, :cond_2

    .line 69
    .line 70
    move-object v3, v9

    .line 71
    check-cast v3, La15;

    .line 72
    .line 73
    iget-object v3, v3, La15;->c:Lyv5;

    .line 74
    .line 75
    invoke-static {v2, v3}, Lgd;->b(Lgd;Lyv5;)V

    .line 76
    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_2
    instance-of v3, v9, Lb15;

    .line 80
    .line 81
    if-eqz v3, :cond_3

    .line 82
    .line 83
    move-object v3, v9

    .line 84
    check-cast v3, Lb15;

    .line 85
    .line 86
    iget-object v3, v3, Lb15;->c:Lw16;

    .line 87
    .line 88
    invoke-static {v2, v3}, Lgd;->c(Lgd;Lw16;)V

    .line 89
    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_3
    instance-of v3, v9, Lz05;

    .line 93
    .line 94
    if-eqz v3, :cond_8

    .line 95
    .line 96
    move-object v3, v9

    .line 97
    check-cast v3, Lz05;

    .line 98
    .line 99
    iget-object v3, v3, Lz05;->c:Lgd;

    .line 100
    .line 101
    const-wide/16 v6, 0x0

    .line 102
    .line 103
    invoke-virtual {v2, v3, v6, v7}, Lgd;->a(Lgd;J)V

    .line 104
    .line 105
    .line 106
    :goto_0
    iget-object v3, p0, La83;->y:Lwz4;

    .line 107
    .line 108
    iget-wide v6, v1, Lx73;->c:J

    .line 109
    .line 110
    invoke-virtual {v3, v6, v7}, Lwz4;->p(J)V

    .line 111
    .line 112
    .line 113
    iget v1, v1, Lx73;->d:F

    .line 114
    .line 115
    invoke-virtual {v4, v1}, Lsq2;->g(F)V

    .line 116
    .line 117
    .line 118
    iget-object v1, v4, Lsq2;->a:Lwq2;

    .line 119
    .line 120
    iget-byte v3, v1, Lwq2;->i:B

    .line 121
    .line 122
    const/4 v6, 0x3

    .line 123
    if-eq v3, v6, :cond_5

    .line 124
    .line 125
    iput-byte v6, v1, Lwq2;->i:B

    .line 126
    .line 127
    iget-object v3, v1, Lwq2;->e:Landroid/graphics/Paint;

    .line 128
    .line 129
    if-nez v3, :cond_4

    .line 130
    .line 131
    new-instance v3, Landroid/graphics/Paint;

    .line 132
    .line 133
    invoke-direct {v3}, Landroid/graphics/Paint;-><init>()V

    .line 134
    .line 135
    .line 136
    iput-object v3, v1, Lwq2;->e:Landroid/graphics/Paint;

    .line 137
    .line 138
    :cond_4
    invoke-static {v6}, Lbx;->e0(I)Landroid/graphics/BlendMode;

    .line 139
    .line 140
    .line 141
    move-result-object v6

    .line 142
    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setBlendMode(Landroid/graphics/BlendMode;)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {v1}, Lwq2;->c()V

    .line 146
    .line 147
    .line 148
    :cond_5
    iget v1, p0, La83;->A:F

    .line 149
    .line 150
    cmpg-float v1, v1, v5

    .line 151
    .line 152
    if-eqz v1, :cond_7

    .line 153
    .line 154
    const/4 v1, 0x0

    .line 155
    cmpl-float v1, v5, v1

    .line 156
    .line 157
    if-lez v1, :cond_6

    .line 158
    .line 159
    new-instance v1, Lg50;

    .line 160
    .line 161
    invoke-direct {v1, v5, v5}, Lg50;-><init>(FF)V

    .line 162
    .line 163
    .line 164
    goto :goto_1

    .line 165
    :cond_6
    const/4 v1, 0x0

    .line 166
    :goto_1
    invoke-virtual {v4, v1}, Lsq2;->l(Lvx5;)V

    .line 167
    .line 168
    .line 169
    iput v5, p0, La83;->A:F

    .line 170
    .line 171
    :cond_7
    new-instance v7, Lvn2;

    .line 172
    .line 173
    const/4 v12, 0x2

    .line 174
    move-object v8, p0

    .line 175
    invoke-direct/range {v7 .. v12}, Lvn2;-><init>(Ljava/lang/Object;Ljava/lang/Object;FFB)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {p1}, Lbj3;->b()J

    .line 179
    .line 180
    .line 181
    move-result-wide v5

    .line 182
    invoke-static {v5, v6}, Luu;->r0(J)J

    .line 183
    .line 184
    .line 185
    move-result-wide v5

    .line 186
    invoke-virtual {p1, v4, v5, v6, v7}, Lbj3;->d0(Lsq2;JLwh2;)V

    .line 187
    .line 188
    .line 189
    iget-object p0, v0, Ltl0;->i:Lzi7;

    .line 190
    .line 191
    invoke-virtual {p0}, Lzi7;->K()Lpl0;

    .line 192
    .line 193
    .line 194
    move-result-object p0

    .line 195
    invoke-interface {p0}, Lpl0;->n()V

    .line 196
    .line 197
    .line 198
    invoke-interface {p0, v2}, Lpl0;->s(Lgd;)V

    .line 199
    .line 200
    .line 201
    invoke-static {p1, v4}, Ldw;->z(Ldw1;Lsq2;)V

    .line 202
    .line 203
    .line 204
    invoke-interface {p0}, Lpl0;->j()V

    .line 205
    .line 206
    .line 207
    return-void

    .line 208
    :cond_8
    invoke-static {}, Lxb1;->a()V

    .line 209
    .line 210
    .line 211
    return-void
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
.end method

.method public final v1()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final y1()V
    .locals 2

    .line 1
    invoke-static {p0}, Lsx;->j0(Lap1;)Lpq2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Lpq2;->c()Lsq2;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const/4 v1, 0x1

    .line 10
    invoke-virtual {v0, v1}, Lsq2;->i(I)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, La83;->x:Lsq2;

    .line 14
    .line 15
    return-void
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final z1()V
    .locals 2

    .line 1
    iget-object v0, p0, La83;->x:Lsq2;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p0}, Lsx;->j0(Lap1;)Lpq2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1, v0}, Lpq2;->a(Lsq2;)V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    iput-object v0, p0, La83;->x:Lsq2;

    .line 14
    .line 15
    :cond_0
    return-void
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method
