.class public final Lb33;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lgx6;


# instance fields
.field public final h:J

.field public i:Z

.field public final j:Ljg0;

.field public final k:Ljg0;

.field public l:Z

.field public final synthetic m:Ld33;


# direct methods
.method public constructor <init>(Ld33;JZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb33;->m:Ld33;

    .line 5
    .line 6
    iput-wide p2, p0, Lb33;->h:J

    .line 7
    .line 8
    iput-boolean p4, p0, Lb33;->i:Z

    .line 9
    .line 10
    new-instance p1, Ljg0;

    .line 11
    .line 12
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Lb33;->j:Ljg0;

    .line 16
    .line 17
    new-instance p1, Ljg0;

    .line 18
    .line 19
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, Lb33;->k:Ljg0;

    .line 23
    .line 24
    return-void
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
.end method


# virtual methods
.method public final a()Lnk7;
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->m:Ld33;

    .line 2
    .line 3
    iget-object p0, p0, Ld33;->q:Lc33;

    .line 4
    .line 5
    return-object p0
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
.end method

.method public final close()V
    .locals 4

    .line 1
    iget-object v0, p0, Lb33;->m:Ld33;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    const/4 v1, 0x1

    .line 5
    :try_start_0
    iput-boolean v1, p0, Lb33;->l:Z

    .line 6
    .line 7
    iget-object v1, p0, Lb33;->k:Ljg0;

    .line 8
    .line 9
    iget-wide v2, v1, Ljg0;->i:J

    .line 10
    .line 11
    invoke-virtual {v1}, Ljg0;->b()V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    .line 17
    monitor-exit v0

    .line 18
    const-wide/16 v0, 0x0

    .line 19
    .line 20
    cmp-long v0, v2, v0

    .line 21
    .line 22
    if-lez v0, :cond_0

    .line 23
    .line 24
    iget-object v0, p0, Lb33;->m:Ld33;

    .line 25
    .line 26
    sget-object v1, Lo58;->a:Ljava/util/TimeZone;

    .line 27
    .line 28
    iget-object v0, v0, Ld33;->i:Lw23;

    .line 29
    .line 30
    invoke-virtual {v0, v2, v3}, Lw23;->i(J)V

    .line 31
    .line 32
    .line 33
    :cond_0
    iget-object p0, p0, Lb33;->m:Ld33;

    .line 34
    .line 35
    invoke-virtual {p0}, Ld33;->a()V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :catchall_0
    move-exception p0

    .line 40
    monitor-exit v0

    .line 41
    throw p0
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
.end method

.method public final t(Ljg0;J)J
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-wide/from16 v1, p2

    .line 4
    .line 5
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-wide/16 v3, 0x0

    .line 9
    .line 10
    cmp-long v5, v1, v3

    .line 11
    .line 12
    if-ltz v5, :cond_e

    .line 13
    .line 14
    :goto_0
    iget-object v5, v0, Lb33;->m:Ld33;

    .line 15
    .line 16
    monitor-enter v5

    .line 17
    :try_start_0
    iget-object v6, v5, Ld33;->i:Lw23;

    .line 18
    .line 19
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    iget-object v6, v5, Ld33;->p:La33;

    .line 23
    .line 24
    iget-boolean v7, v6, La33;->j:Z

    .line 25
    .line 26
    const/4 v8, 0x1

    .line 27
    const/4 v9, 0x0

    .line 28
    if-nez v7, :cond_0

    .line 29
    .line 30
    iget-boolean v6, v6, La33;->h:Z

    .line 31
    .line 32
    if-nez v6, :cond_0

    .line 33
    .line 34
    move v6, v9

    .line 35
    goto :goto_1

    .line 36
    :cond_0
    move v6, v8

    .line 37
    :goto_1
    if-eqz v6, :cond_1

    .line 38
    .line 39
    iget-object v7, v5, Ld33;->q:Lc33;

    .line 40
    .line 41
    invoke-virtual {v7}, Lsy;->i()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 42
    .line 43
    .line 44
    :cond_1
    :try_start_1
    invoke-virtual {v5}, Ld33;->g()Lf42;

    .line 45
    .line 46
    .line 47
    move-result-object v7

    .line 48
    if-eqz v7, :cond_2

    .line 49
    .line 50
    iget-boolean v7, v0, Lb33;->i:Z

    .line 51
    .line 52
    if-nez v7, :cond_2

    .line 53
    .line 54
    iget-object v7, v5, Ld33;->t:Ljava/io/IOException;

    .line 55
    .line 56
    if-nez v7, :cond_3

    .line 57
    .line 58
    new-instance v7, Lr07;

    .line 59
    .line 60
    invoke-virtual {v5}, Ld33;->g()Lf42;

    .line 61
    .line 62
    .line 63
    move-result-object v10

    .line 64
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    invoke-direct {v7, v10}, Lr07;-><init>(Lf42;)V

    .line 68
    .line 69
    .line 70
    goto :goto_2

    .line 71
    :cond_2
    const/4 v7, 0x0

    .line 72
    :cond_3
    :goto_2
    iget-boolean v10, v0, Lb33;->l:Z

    .line 73
    .line 74
    if-nez v10, :cond_c

    .line 75
    .line 76
    iget-object v10, v0, Lb33;->k:Ljg0;

    .line 77
    .line 78
    iget-wide v11, v10, Ljg0;->i:J

    .line 79
    .line 80
    cmp-long v13, v11, v3

    .line 81
    .line 82
    const-wide/16 v14, -0x1

    .line 83
    .line 84
    if-lez v13, :cond_6

    .line 85
    .line 86
    invoke-static {v1, v2, v11, v12}, Ljava/lang/Math;->min(JJ)J

    .line 87
    .line 88
    .line 89
    move-result-wide v11

    .line 90
    move-object/from16 v13, p1

    .line 91
    .line 92
    invoke-virtual {v10, v13, v11, v12}, Ljg0;->t(Ljg0;J)J

    .line 93
    .line 94
    .line 95
    move-result-wide v17

    .line 96
    iget-object v8, v5, Ld33;->j:Ls18;

    .line 97
    .line 98
    const-wide/16 v19, 0x0

    .line 99
    .line 100
    const/16 v21, 0x2

    .line 101
    .line 102
    move-object/from16 v16, v8

    .line 103
    .line 104
    invoke-static/range {v16 .. v21}, Ls18;->b(Ls18;JJI)V

    .line 105
    .line 106
    .line 107
    iget-object v8, v5, Ld33;->j:Ls18;

    .line 108
    .line 109
    invoke-virtual {v8}, Ls18;->a()J

    .line 110
    .line 111
    .line 112
    move-result-wide v10

    .line 113
    if-nez v7, :cond_4

    .line 114
    .line 115
    iget-object v8, v5, Ld33;->i:Lw23;

    .line 116
    .line 117
    iget-object v8, v8, Lw23;->y:Lqm6;

    .line 118
    .line 119
    invoke-virtual {v8}, Lqm6;->a()I

    .line 120
    .line 121
    .line 122
    move-result v8

    .line 123
    div-int/lit8 v8, v8, 0x2

    .line 124
    .line 125
    move-wide/from16 v25, v3

    .line 126
    .line 127
    int-to-long v3, v8

    .line 128
    cmp-long v3, v10, v3

    .line 129
    .line 130
    if-ltz v3, :cond_5

    .line 131
    .line 132
    iget-object v3, v5, Ld33;->i:Lw23;

    .line 133
    .line 134
    iget v4, v5, Ld33;->h:I

    .line 135
    .line 136
    invoke-virtual {v3, v4, v10, v11}, Lw23;->o(IJ)V

    .line 137
    .line 138
    .line 139
    iget-object v3, v5, Ld33;->j:Ls18;

    .line 140
    .line 141
    const-wide/16 v20, 0x0

    .line 142
    .line 143
    const/16 v24, 0x1

    .line 144
    .line 145
    move-object/from16 v19, v3

    .line 146
    .line 147
    move-wide/from16 v22, v10

    .line 148
    .line 149
    invoke-static/range {v19 .. v24}, Ls18;->b(Ls18;JJI)V

    .line 150
    .line 151
    .line 152
    goto :goto_3

    .line 153
    :cond_4
    move-wide/from16 v25, v3

    .line 154
    .line 155
    :cond_5
    :goto_3
    move v8, v9

    .line 156
    goto :goto_5

    .line 157
    :cond_6
    move-wide/from16 v25, v3

    .line 158
    .line 159
    iget-boolean v3, v0, Lb33;->i:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 160
    .line 161
    if-nez v3, :cond_7

    .line 162
    .line 163
    if-nez v7, :cond_7

    .line 164
    .line 165
    :try_start_2
    invoke-virtual {v5}, Ljava/lang/Object;->wait()V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 166
    .line 167
    .line 168
    :goto_4
    move-wide/from16 v17, v14

    .line 169
    .line 170
    goto :goto_5

    .line 171
    :catch_0
    :try_start_3
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    .line 176
    .line 177
    .line 178
    new-instance v0, Ljava/io/InterruptedIOException;

    .line 179
    .line 180
    invoke-direct {v0}, Ljava/io/InterruptedIOException;-><init>()V

    .line 181
    .line 182
    .line 183
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 184
    :cond_7
    move v8, v9

    .line 185
    goto :goto_4

    .line 186
    :goto_5
    if-eqz v6, :cond_8

    .line 187
    .line 188
    :try_start_4
    iget-object v3, v5, Ld33;->q:Lc33;

    .line 189
    .line 190
    invoke-virtual {v3}, Lc33;->l()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 191
    .line 192
    .line 193
    :cond_8
    monitor-exit v5

    .line 194
    iget-object v3, v0, Lb33;->m:Ld33;

    .line 195
    .line 196
    iget-object v3, v3, Ld33;->i:Lw23;

    .line 197
    .line 198
    iget-object v3, v3, Lw23;->x:Llc2;

    .line 199
    .line 200
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 201
    .line 202
    .line 203
    if-eqz v8, :cond_9

    .line 204
    .line 205
    move-wide/from16 v3, v25

    .line 206
    .line 207
    goto/16 :goto_0

    .line 208
    .line 209
    :cond_9
    cmp-long v0, v17, v14

    .line 210
    .line 211
    if-eqz v0, :cond_a

    .line 212
    .line 213
    return-wide v17

    .line 214
    :cond_a
    if-nez v7, :cond_b

    .line 215
    .line 216
    return-wide v14

    .line 217
    :cond_b
    throw v7

    .line 218
    :cond_c
    :try_start_5
    new-instance v0, Ljava/io/IOException;

    .line 219
    .line 220
    const-string v1, "stream closed"

    .line 221
    .line 222
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 223
    .line 224
    .line 225
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 226
    :catchall_0
    move-exception v0

    .line 227
    if-eqz v6, :cond_d

    .line 228
    .line 229
    :try_start_6
    iget-object v1, v5, Ld33;->q:Lc33;

    .line 230
    .line 231
    invoke-virtual {v1}, Lc33;->l()V

    .line 232
    .line 233
    .line 234
    :cond_d
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 235
    :catchall_1
    move-exception v0

    .line 236
    monitor-exit v5

    .line 237
    throw v0

    .line 238
    :cond_e
    move-wide/from16 v25, v3

    .line 239
    .line 240
    const-string v0, "byteCount < 0: "

    .line 241
    .line 242
    invoke-static {v1, v2, v0}, Ln32;->m(JLjava/lang/String;)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    invoke-static {v0}, Ll42;->c(Ljava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    return-wide v25
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
.end method
