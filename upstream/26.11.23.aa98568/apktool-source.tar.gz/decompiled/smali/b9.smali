.class public final Lb9;
.super Lqb5;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    const-string v0, "Anchored drag finished"

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {p0, v0, v1}, Lqb5;-><init>(Ljava/lang/String;B)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
