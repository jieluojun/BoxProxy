.class public final synthetic Lb1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lw52;

.field public final synthetic j:Leh6;

.field public final synthetic k:Llh2;


# direct methods
.method public synthetic constructor <init>(Lw52;Leh6;Llh2;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lb1;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lb1;->i:Lw52;

    .line 4
    .line 5
    iput-object p2, p0, Lb1;->j:Leh6;

    .line 6
    .line 7
    iput-object p3, p0, Lb1;->k:Llh2;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb1;->h:B

    .line 4
    .line 5
    const/4 v2, 0x6

    .line 6
    sget-object v3, Lst7;->a:Lst7;

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    sget-object v5, Lc51;->a:Lql0;

    .line 10
    .line 11
    const/16 v6, 0x1f

    .line 12
    .line 13
    const/4 v7, 0x2

    .line 14
    iget-object v8, v0, Lb1;->k:Llh2;

    .line 15
    .line 16
    iget-object v9, v0, Lb1;->j:Leh6;

    .line 17
    .line 18
    const/4 v10, 0x1

    .line 19
    const/4 v11, 0x0

    .line 20
    packed-switch v1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    move-object/from16 v1, p1

    .line 24
    .line 25
    check-cast v1, Lzi2;

    .line 26
    .line 27
    move-object/from16 v2, p2

    .line 28
    .line 29
    check-cast v2, Ljava/lang/Integer;

    .line 30
    .line 31
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    and-int/lit8 v12, v2, 0x3

    .line 36
    .line 37
    if-eq v12, v7, :cond_0

    .line 38
    .line 39
    move v11, v10

    .line 40
    :cond_0
    and-int/2addr v2, v10

    .line 41
    invoke-virtual {v1, v2, v11}, Lzi2;->Y(IZ)Z

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    if-eqz v2, :cond_3

    .line 46
    .line 47
    invoke-static {v1}, Lck3;->e0(Lzi2;)Lbb4;

    .line 48
    .line 49
    .line 50
    move-result-object v13

    .line 51
    invoke-static {v1}, Lck3;->f0(Lzi2;)Lrm7;

    .line 52
    .line 53
    .line 54
    move-result-object v16

    .line 55
    sget-object v2, Lf38;->w:Ljava/util/WeakHashMap;

    .line 56
    .line 57
    invoke-static {v1}, Lva7;->h(Lzi2;)Lf38;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    iget-object v2, v2, Lf38;->l:Lpt7;

    .line 62
    .line 63
    new-instance v7, Lip3;

    .line 64
    .line 65
    invoke-direct {v7, v2, v6}, Lip3;-><init>(Ly18;I)V

    .line 66
    .line 67
    .line 68
    sget-object v12, Lem1;->N:Ls21;

    .line 69
    .line 70
    new-instance v2, Lx56;

    .line 71
    .line 72
    const/16 v6, 0x16

    .line 73
    .line 74
    invoke-direct {v2, v8, v6}, Lx56;-><init>(Llh2;B)V

    .line 75
    .line 76
    .line 77
    const v6, -0x6e02155d

    .line 78
    .line 79
    .line 80
    invoke-static {v6, v2, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 81
    .line 82
    .line 83
    move-result-object v14

    .line 84
    invoke-virtual {v1, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v2

    .line 88
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v6

    .line 92
    if-nez v2, :cond_1

    .line 93
    .line 94
    if-ne v6, v5, :cond_2

    .line 95
    .line 96
    :cond_1
    new-instance v6, Lg1;

    .line 97
    .line 98
    const/16 v2, 0xb

    .line 99
    .line 100
    invoke-direct {v6, v9, v4, v2}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    :cond_2
    move-object/from16 v19, v6

    .line 107
    .line 108
    check-cast v19, Lwh2;

    .line 109
    .line 110
    const/16 v21, 0x186

    .line 111
    .line 112
    const/16 v22, 0x8

    .line 113
    .line 114
    const/4 v15, 0x0

    .line 115
    iget-object v0, v0, Lb1;->i:Lw52;

    .line 116
    .line 117
    move-object/from16 v18, v0

    .line 118
    .line 119
    move-object/from16 v20, v1

    .line 120
    .line 121
    move-object/from16 v17, v7

    .line 122
    .line 123
    invoke-static/range {v12 .. v22}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 124
    .line 125
    .line 126
    goto :goto_0

    .line 127
    :cond_3
    move-object/from16 v20, v1

    .line 128
    .line 129
    invoke-virtual/range {v20 .. v20}, Lzi2;->b0()V

    .line 130
    .line 131
    .line 132
    :goto_0
    return-object v3

    .line 133
    :pswitch_0
    move-object/from16 v12, p1

    .line 134
    .line 135
    check-cast v12, Lzi2;

    .line 136
    .line 137
    move-object/from16 v1, p2

    .line 138
    .line 139
    check-cast v1, Ljava/lang/Integer;

    .line 140
    .line 141
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    and-int/lit8 v2, v1, 0x3

    .line 146
    .line 147
    if-eq v2, v7, :cond_4

    .line 148
    .line 149
    move v11, v10

    .line 150
    :cond_4
    and-int/2addr v1, v10

    .line 151
    invoke-virtual {v12, v1, v11}, Lzi2;->Y(IZ)Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    if-eqz v1, :cond_7

    .line 156
    .line 157
    invoke-static {v12}, Lck3;->e0(Lzi2;)Lbb4;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-static {v12}, Lck3;->f0(Lzi2;)Lrm7;

    .line 162
    .line 163
    .line 164
    move-result-object v2

    .line 165
    sget-object v7, Lf38;->w:Ljava/util/WeakHashMap;

    .line 166
    .line 167
    invoke-static {v12}, Lva7;->h(Lzi2;)Lf38;

    .line 168
    .line 169
    .line 170
    move-result-object v7

    .line 171
    iget-object v7, v7, Lf38;->l:Lpt7;

    .line 172
    .line 173
    new-instance v10, Lip3;

    .line 174
    .line 175
    invoke-direct {v10, v7, v6}, Lip3;-><init>(Ly18;I)V

    .line 176
    .line 177
    .line 178
    sget-object v6, Ldy3;->j:Ls21;

    .line 179
    .line 180
    new-instance v7, Lvh3;

    .line 181
    .line 182
    const/16 v11, 0x1a

    .line 183
    .line 184
    invoke-direct {v7, v8, v11}, Lvh3;-><init>(Llh2;B)V

    .line 185
    .line 186
    .line 187
    const v8, 0x1cbb0ee4

    .line 188
    .line 189
    .line 190
    invoke-static {v8, v7, v12}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 191
    .line 192
    .line 193
    move-result-object v7

    .line 194
    invoke-virtual {v12, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v8

    .line 198
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v11

    .line 202
    if-nez v8, :cond_5

    .line 203
    .line 204
    if-ne v11, v5, :cond_6

    .line 205
    .line 206
    :cond_5
    new-instance v11, Lg1;

    .line 207
    .line 208
    const/16 v5, 0x8

    .line 209
    .line 210
    invoke-direct {v11, v9, v4, v5}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v12, v11}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_6
    check-cast v11, Lwh2;

    .line 217
    .line 218
    const/16 v13, 0x186

    .line 219
    .line 220
    const/16 v14, 0x8

    .line 221
    .line 222
    move-object v4, v6

    .line 223
    move-object v6, v7

    .line 224
    const/4 v7, 0x0

    .line 225
    move-object v9, v10

    .line 226
    iget-object v10, v0, Lb1;->i:Lw52;

    .line 227
    .line 228
    move-object v5, v1

    .line 229
    move-object v8, v2

    .line 230
    invoke-static/range {v4 .. v14}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 231
    .line 232
    .line 233
    goto :goto_1

    .line 234
    :cond_7
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 235
    .line 236
    .line 237
    :goto_1
    return-object v3

    .line 238
    :pswitch_1
    move-object/from16 v1, p1

    .line 239
    .line 240
    check-cast v1, Lzi2;

    .line 241
    .line 242
    move-object/from16 v2, p2

    .line 243
    .line 244
    check-cast v2, Ljava/lang/Integer;

    .line 245
    .line 246
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 247
    .line 248
    .line 249
    move-result v2

    .line 250
    and-int/lit8 v12, v2, 0x3

    .line 251
    .line 252
    if-eq v12, v7, :cond_8

    .line 253
    .line 254
    move v11, v10

    .line 255
    :cond_8
    and-int/2addr v2, v10

    .line 256
    invoke-virtual {v1, v2, v11}, Lzi2;->Y(IZ)Z

    .line 257
    .line 258
    .line 259
    move-result v2

    .line 260
    if-eqz v2, :cond_b

    .line 261
    .line 262
    invoke-static {v1}, Lck3;->e0(Lzi2;)Lbb4;

    .line 263
    .line 264
    .line 265
    move-result-object v14

    .line 266
    invoke-static {v1}, Lck3;->f0(Lzi2;)Lrm7;

    .line 267
    .line 268
    .line 269
    move-result-object v17

    .line 270
    sget-object v2, Lf38;->w:Ljava/util/WeakHashMap;

    .line 271
    .line 272
    invoke-static {v1}, Lva7;->h(Lzi2;)Lf38;

    .line 273
    .line 274
    .line 275
    move-result-object v2

    .line 276
    iget-object v2, v2, Lf38;->l:Lpt7;

    .line 277
    .line 278
    new-instance v7, Lip3;

    .line 279
    .line 280
    invoke-direct {v7, v2, v6}, Lip3;-><init>(Ly18;I)V

    .line 281
    .line 282
    .line 283
    sget-object v13, Lem1;->F:Ls21;

    .line 284
    .line 285
    new-instance v2, Lvh3;

    .line 286
    .line 287
    const/16 v6, 0x14

    .line 288
    .line 289
    invoke-direct {v2, v8, v6}, Lvh3;-><init>(Llh2;B)V

    .line 290
    .line 291
    .line 292
    const v6, -0x47ea689a

    .line 293
    .line 294
    .line 295
    invoke-static {v6, v2, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 296
    .line 297
    .line 298
    move-result-object v15

    .line 299
    invoke-virtual {v1, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 300
    .line 301
    .line 302
    move-result v2

    .line 303
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v6

    .line 307
    if-nez v2, :cond_9

    .line 308
    .line 309
    if-ne v6, v5, :cond_a

    .line 310
    .line 311
    :cond_9
    new-instance v6, Lg1;

    .line 312
    .line 313
    const/4 v2, 0x7

    .line 314
    invoke-direct {v6, v9, v4, v2}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    :cond_a
    move-object/from16 v20, v6

    .line 321
    .line 322
    check-cast v20, Lwh2;

    .line 323
    .line 324
    const/16 v22, 0x186

    .line 325
    .line 326
    const/16 v23, 0x8

    .line 327
    .line 328
    const/16 v16, 0x0

    .line 329
    .line 330
    iget-object v0, v0, Lb1;->i:Lw52;

    .line 331
    .line 332
    move-object/from16 v19, v0

    .line 333
    .line 334
    move-object/from16 v21, v1

    .line 335
    .line 336
    move-object/from16 v18, v7

    .line 337
    .line 338
    invoke-static/range {v13 .. v23}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 339
    .line 340
    .line 341
    goto :goto_2

    .line 342
    :cond_b
    move-object/from16 v21, v1

    .line 343
    .line 344
    invoke-virtual/range {v21 .. v21}, Lzi2;->b0()V

    .line 345
    .line 346
    .line 347
    :goto_2
    return-object v3

    .line 348
    :pswitch_2
    move-object/from16 v12, p1

    .line 349
    .line 350
    check-cast v12, Lzi2;

    .line 351
    .line 352
    move-object/from16 v1, p2

    .line 353
    .line 354
    check-cast v1, Ljava/lang/Integer;

    .line 355
    .line 356
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 357
    .line 358
    .line 359
    move-result v1

    .line 360
    and-int/lit8 v13, v1, 0x3

    .line 361
    .line 362
    if-eq v13, v7, :cond_c

    .line 363
    .line 364
    move v11, v10

    .line 365
    :cond_c
    and-int/2addr v1, v10

    .line 366
    invoke-virtual {v12, v1, v11}, Lzi2;->Y(IZ)Z

    .line 367
    .line 368
    .line 369
    move-result v1

    .line 370
    if-eqz v1, :cond_f

    .line 371
    .line 372
    invoke-static {v12}, Lck3;->e0(Lzi2;)Lbb4;

    .line 373
    .line 374
    .line 375
    move-result-object v1

    .line 376
    invoke-static {v12}, Lck3;->f0(Lzi2;)Lrm7;

    .line 377
    .line 378
    .line 379
    move-result-object v7

    .line 380
    sget-object v10, Lf38;->w:Ljava/util/WeakHashMap;

    .line 381
    .line 382
    invoke-static {v12}, Lva7;->h(Lzi2;)Lf38;

    .line 383
    .line 384
    .line 385
    move-result-object v10

    .line 386
    iget-object v10, v10, Lf38;->l:Lpt7;

    .line 387
    .line 388
    new-instance v11, Lip3;

    .line 389
    .line 390
    invoke-direct {v11, v10, v6}, Lip3;-><init>(Ly18;I)V

    .line 391
    .line 392
    .line 393
    sget-object v6, Lp80;->t:Ls21;

    .line 394
    .line 395
    new-instance v10, Lvh3;

    .line 396
    .line 397
    const/16 v13, 0x12

    .line 398
    .line 399
    invoke-direct {v10, v8, v13}, Lvh3;-><init>(Llh2;B)V

    .line 400
    .line 401
    .line 402
    const v8, -0xe3d5557

    .line 403
    .line 404
    .line 405
    invoke-static {v8, v10, v12}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 406
    .line 407
    .line 408
    move-result-object v8

    .line 409
    invoke-virtual {v12, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 410
    .line 411
    .line 412
    move-result v10

    .line 413
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 414
    .line 415
    .line 416
    move-result-object v13

    .line 417
    if-nez v10, :cond_d

    .line 418
    .line 419
    if-ne v13, v5, :cond_e

    .line 420
    .line 421
    :cond_d
    new-instance v13, Lg1;

    .line 422
    .line 423
    invoke-direct {v13, v9, v4, v2}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 424
    .line 425
    .line 426
    invoke-virtual {v12, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 427
    .line 428
    .line 429
    :cond_e
    check-cast v13, Lwh2;

    .line 430
    .line 431
    move-object v9, v11

    .line 432
    move-object v11, v13

    .line 433
    const/16 v13, 0x186

    .line 434
    .line 435
    const/16 v14, 0x8

    .line 436
    .line 437
    move-object v4, v6

    .line 438
    move-object v6, v8

    .line 439
    move-object v8, v7

    .line 440
    const/4 v7, 0x0

    .line 441
    iget-object v10, v0, Lb1;->i:Lw52;

    .line 442
    .line 443
    move-object v5, v1

    .line 444
    invoke-static/range {v4 .. v14}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 445
    .line 446
    .line 447
    goto :goto_3

    .line 448
    :cond_f
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 449
    .line 450
    .line 451
    :goto_3
    return-object v3

    .line 452
    :pswitch_3
    move-object/from16 v1, p1

    .line 453
    .line 454
    check-cast v1, Lzi2;

    .line 455
    .line 456
    move-object/from16 v2, p2

    .line 457
    .line 458
    check-cast v2, Ljava/lang/Integer;

    .line 459
    .line 460
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 461
    .line 462
    .line 463
    move-result v2

    .line 464
    and-int/lit8 v12, v2, 0x3

    .line 465
    .line 466
    if-eq v12, v7, :cond_10

    .line 467
    .line 468
    move v11, v10

    .line 469
    :cond_10
    and-int/2addr v2, v10

    .line 470
    invoke-virtual {v1, v2, v11}, Lzi2;->Y(IZ)Z

    .line 471
    .line 472
    .line 473
    move-result v2

    .line 474
    if-eqz v2, :cond_13

    .line 475
    .line 476
    invoke-static {v1}, Lck3;->e0(Lzi2;)Lbb4;

    .line 477
    .line 478
    .line 479
    move-result-object v14

    .line 480
    invoke-static {v1}, Lck3;->f0(Lzi2;)Lrm7;

    .line 481
    .line 482
    .line 483
    move-result-object v17

    .line 484
    sget-object v2, Lf38;->w:Ljava/util/WeakHashMap;

    .line 485
    .line 486
    invoke-static {v1}, Lva7;->h(Lzi2;)Lf38;

    .line 487
    .line 488
    .line 489
    move-result-object v2

    .line 490
    iget-object v2, v2, Lf38;->l:Lpt7;

    .line 491
    .line 492
    new-instance v7, Lip3;

    .line 493
    .line 494
    invoke-direct {v7, v2, v6}, Lip3;-><init>(Ly18;I)V

    .line 495
    .line 496
    .line 497
    sget-object v13, Ln14;->h:Ls21;

    .line 498
    .line 499
    new-instance v2, Lj;

    .line 500
    .line 501
    const/16 v6, 0x9

    .line 502
    .line 503
    invoke-direct {v2, v8, v6}, Lj;-><init>(Llh2;B)V

    .line 504
    .line 505
    .line 506
    const v6, -0x765768fc

    .line 507
    .line 508
    .line 509
    invoke-static {v6, v2, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 510
    .line 511
    .line 512
    move-result-object v15

    .line 513
    invoke-virtual {v1, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 514
    .line 515
    .line 516
    move-result v2

    .line 517
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 518
    .line 519
    .line 520
    move-result-object v6

    .line 521
    if-nez v2, :cond_11

    .line 522
    .line 523
    if-ne v6, v5, :cond_12

    .line 524
    .line 525
    :cond_11
    new-instance v6, Lg1;

    .line 526
    .line 527
    invoke-direct {v6, v9, v4, v10}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 528
    .line 529
    .line 530
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 531
    .line 532
    .line 533
    :cond_12
    move-object/from16 v20, v6

    .line 534
    .line 535
    check-cast v20, Lwh2;

    .line 536
    .line 537
    const/16 v22, 0x186

    .line 538
    .line 539
    const/16 v23, 0x8

    .line 540
    .line 541
    const/16 v16, 0x0

    .line 542
    .line 543
    iget-object v0, v0, Lb1;->i:Lw52;

    .line 544
    .line 545
    move-object/from16 v19, v0

    .line 546
    .line 547
    move-object/from16 v21, v1

    .line 548
    .line 549
    move-object/from16 v18, v7

    .line 550
    .line 551
    invoke-static/range {v13 .. v23}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 552
    .line 553
    .line 554
    goto :goto_4

    .line 555
    :cond_13
    move-object/from16 v21, v1

    .line 556
    .line 557
    invoke-virtual/range {v21 .. v21}, Lzi2;->b0()V

    .line 558
    .line 559
    .line 560
    :goto_4
    return-object v3

    .line 561
    :pswitch_4
    move-object/from16 v12, p1

    .line 562
    .line 563
    check-cast v12, Lzi2;

    .line 564
    .line 565
    move-object/from16 v1, p2

    .line 566
    .line 567
    check-cast v1, Ljava/lang/Integer;

    .line 568
    .line 569
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 570
    .line 571
    .line 572
    move-result v1

    .line 573
    and-int/lit8 v13, v1, 0x3

    .line 574
    .line 575
    if-eq v13, v7, :cond_14

    .line 576
    .line 577
    move v7, v10

    .line 578
    goto :goto_5

    .line 579
    :cond_14
    move v7, v11

    .line 580
    :goto_5
    and-int/2addr v1, v10

    .line 581
    invoke-virtual {v12, v1, v7}, Lzi2;->Y(IZ)Z

    .line 582
    .line 583
    .line 584
    move-result v1

    .line 585
    if-eqz v1, :cond_17

    .line 586
    .line 587
    invoke-static {v12}, Lck3;->e0(Lzi2;)Lbb4;

    .line 588
    .line 589
    .line 590
    move-result-object v1

    .line 591
    invoke-static {v12}, Lck3;->f0(Lzi2;)Lrm7;

    .line 592
    .line 593
    .line 594
    move-result-object v7

    .line 595
    sget-object v10, Lf38;->w:Ljava/util/WeakHashMap;

    .line 596
    .line 597
    invoke-static {v12}, Lva7;->h(Lzi2;)Lf38;

    .line 598
    .line 599
    .line 600
    move-result-object v10

    .line 601
    iget-object v10, v10, Lf38;->l:Lpt7;

    .line 602
    .line 603
    new-instance v13, Lip3;

    .line 604
    .line 605
    invoke-direct {v13, v10, v6}, Lip3;-><init>(Ly18;I)V

    .line 606
    .line 607
    .line 608
    sget-object v6, Lnb3;->e:Ls21;

    .line 609
    .line 610
    new-instance v10, Lj;

    .line 611
    .line 612
    invoke-direct {v10, v8, v2}, Lj;-><init>(Llh2;B)V

    .line 613
    .line 614
    .line 615
    const v2, -0x3d76d02a

    .line 616
    .line 617
    .line 618
    invoke-static {v2, v10, v12}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 619
    .line 620
    .line 621
    move-result-object v2

    .line 622
    invoke-virtual {v12, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 623
    .line 624
    .line 625
    move-result v8

    .line 626
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 627
    .line 628
    .line 629
    move-result-object v10

    .line 630
    if-nez v8, :cond_15

    .line 631
    .line 632
    if-ne v10, v5, :cond_16

    .line 633
    .line 634
    :cond_15
    new-instance v10, Lg1;

    .line 635
    .line 636
    invoke-direct {v10, v9, v4, v11}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 637
    .line 638
    .line 639
    invoke-virtual {v12, v10}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 640
    .line 641
    .line 642
    :cond_16
    move-object v11, v10

    .line 643
    check-cast v11, Lwh2;

    .line 644
    .line 645
    move-object v9, v13

    .line 646
    const/16 v13, 0x186

    .line 647
    .line 648
    const/16 v14, 0x8

    .line 649
    .line 650
    move-object v8, v7

    .line 651
    const/4 v7, 0x0

    .line 652
    iget-object v10, v0, Lb1;->i:Lw52;

    .line 653
    .line 654
    move-object v5, v1

    .line 655
    move-object v4, v6

    .line 656
    move-object v6, v2

    .line 657
    invoke-static/range {v4 .. v14}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 658
    .line 659
    .line 660
    goto :goto_6

    .line 661
    :cond_17
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 662
    .line 663
    .line 664
    :goto_6
    return-object v3

    .line 665
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
.end method
