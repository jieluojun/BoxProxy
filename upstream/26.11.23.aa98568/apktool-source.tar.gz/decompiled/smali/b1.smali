.class public final synthetic Lb1;
.super Ljava/lang/Object;
.source "r8-map-id-8a350405171d2c33bdd94e3ad2d739b062381a652ea433c4b9b339af03d4fbf6"

# interfaces
.implements Lai2;


# instance fields
.field public final synthetic h:B

.field public final synthetic i:Lw52;

.field public final synthetic j:Leh6;

.field public final synthetic k:Llh2;


# direct methods
.method public synthetic constructor <init>(Lw52;Leh6;Llh2;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lb1;->h:B

    .line 2
    .line 3
    iput-object p1, p0, Lb1;->i:Lw52;

    .line 4
    .line 5
    iput-object p2, p0, Lb1;->j:Leh6;

    .line 6
    .line 7
    iput-object p3, p0, Lb1;->k:Llh2;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb1;->h:B

    .line 4
    .line 5
    const/4 v2, 0x6

    .line 6
    sget-object v3, Lst7;->a:Lst7;

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    sget-object v5, Lc51;->a:Lql0;

    .line 10
    .line 11
    const/16 v6, 0x1f

    .line 12
    .line 13
    const/4 v7, 0x2

    .line 14
    iget-object v8, v0, Lb1;->k:Llh2;

    .line 15
    .line 16
    iget-object v9, v0, Lb1;->j:Leh6;

    .line 17
    .line 18
    const/4 v10, 0x1

    .line 19
    const/4 v11, 0x0

    .line 20
    packed-switch v1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    move-object/from16 v1, p1

    .line 24
    .line 25
    check-cast v1, Lzi2;

    .line 26
    .line 27
    move-object/from16 v2, p2

    .line 28
    .line 29
    check-cast v2, Ljava/lang/Integer;

    .line 30
    .line 31
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    and-int/lit8 v12, v2, 0x3

    .line 36
    .line 37
    if-eq v12, v7, :cond_0

    .line 38
    .line 39
    move v11, v10

    .line 40
    :cond_0
    and-int/2addr v2, v10

    .line 41
    invoke-virtual {v1, v2, v11}, Lzi2;->Y(IZ)Z

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    if-eqz v2, :cond_3

    .line 46
    .line 47
    invoke-static {v1}, Lck3;->e0(Lzi2;)Lbb4;

    .line 48
    .line 49
    .line 50
    move-result-object v13

    .line 51
    invoke-static {v1}, Lck3;->f0(Lzi2;)Lrm7;

    .line 52
    .line 53
    .line 54
    move-result-object v16

    .line 55
    sget-object v2, Lf38;->w:Ljava/util/WeakHashMap;

    .line 56
    .line 57
    invoke-static {v1}, Lva7;->h(Lzi2;)Lf38;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    iget-object v2, v2, Lf38;->l:Lpt7;

    .line 62
    .line 63
    new-instance v7, Lip3;

    .line 64
    .line 65
    invoke-direct {v7, v2, v6}, Lip3;-><init>(Ly18;I)V

    .line 66
    .line 67
    .line 68
    sget-object v12, Lem1;->N:Ls21;

    .line 69
    .line 70
    new-instance v2, Lx56;

    .line 71
    .line 72
    const/16 v6, 0x16

    .line 73
    .line 74
    invoke-direct {v2, v8, v6}, Lx56;-><init>(Llh2;B)V

    .line 75
    .line 76
    .line 77
    const v6, -0x6e02155d

    .line 78
    .line 79
    .line 80
    invoke-static {v6, v2, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 81
    .line 82
    .line 83
    move-result-object v14

    .line 84
    invoke-virtual {v1, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v2

    .line 88
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v6

    .line 92
    if-nez v2, :cond_1

    .line 93
    .line 94
    if-ne v6, v5, :cond_2

    .line 95
    .line 96
    :cond_1
    new-instance v6, Lg1;

    .line 97
    .line 98
    const/16 v2, 0xb

    .line 99
    .line 100
    invoke-direct {v6, v9, v4, v2}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    :cond_2
    move-object/from16 v19, v6

    .line 107
    .line 108
    check-cast v19, Lwh2;

    .line 109
    .line 110
    const/16 v21, 0x186

    .line 111
    .line 112
    const/16 v22, 0x8

    .line 113
    .line 114
    const/4 v15, 0x0

    .line 115
    iget-object v0, v0, Lb1;->i:Lw52;

    .line 116
    .line 117
    move-object/from16 v18, v0

    .line 118
    .line 119
    move-object/from16 v20, v1

    .line 120
    .line 121
    move-object/from16 v17, v7

    .line 122
    .line 123
    invoke-static/range {v12 .. v22}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 124
    .line 125
    .line 126
    goto :goto_0

    .line 127
    :cond_3
    move-object/from16 v20, v1

    .line 128
    .line 129
    invoke-virtual/range {v20 .. v20}, Lzi2;->b0()V

    .line 130
    .line 131
    .line 132
    :goto_0
    return-object v3

    .line 133
    :pswitch_0
    move-object/from16 v12, p1

    .line 134
    .line 135
    check-cast v12, Lzi2;

    .line 136
    .line 137
    move-object/from16 v1, p2

    .line 138
    .line 139
    check-cast v1, Ljava/lang/Integer;

    .line 140
    .line 141
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    and-int/lit8 v2, v1, 0x3

    .line 146
    .line 147
    if-eq v2, v7, :cond_4

    .line 148
    .line 149
    move v11, v10

    .line 150
    :cond_4
    and-int/2addr v1, v10

    .line 151
    invoke-virtual {v12, v1, v11}, Lzi2;->Y(IZ)Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    if-eqz v1, :cond_7

    .line 156
    .line 157
    invoke-static {v12}, Lck3;->e0(Lzi2;)Lbb4;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-static {v12}, Lck3;->f0(Lzi2;)Lrm7;

    .line 162
    .line 163
    .line 164
    move-result-object v2

    .line 165
    sget-object v7, Lf38;->w:Ljava/util/WeakHashMap;

    .line 166
    .line 167
    invoke-static {v12}, Lva7;->h(Lzi2;)Lf38;

    .line 168
    .line 169
    .line 170
    move-result-object v7

    .line 171
    iget-object v7, v7, Lf38;->l:Lpt7;

    .line 172
    .line 173
    new-instance v10, Lip3;

    .line 174
    .line 175
    invoke-direct {v10, v7, v6}, Lip3;-><init>(Ly18;I)V

    .line 176
    .line 177
    .line 178
    sget-object v6, Ldy3;->j:Ls21;

    .line 179
    .line 180
    new-instance v7, Lvh3;

    .line 181
    .line 182
    const/16 v11, 0x1a

    .line 183
    .line 184
    invoke-direct {v7, v8, v11}, Lvh3;-><init>(Llh2;B)V

    .line 185
    .line 186
    .line 187
    const v8, 0x1cbb0ee4

    .line 188
    .line 189
    .line 190
    invoke-static {v8, v7, v12}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 191
    .line 192
    .line 193
    move-result-object v7

    .line 194
    invoke-virtual {v12, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v8

    .line 198
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v11

    .line 202
    if-nez v8, :cond_5

    .line 203
    .line 204
    if-ne v11, v5, :cond_6

    .line 205
    .line 206
    :cond_5
    new-instance v11, Lg1;

    .line 207
    .line 208
    const/16 v5, 0x8

    .line 209
    .line 210
    invoke-direct {v11, v9, v4, v5}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v12, v11}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_6
    check-cast v11, Lwh2;

    .line 217
    .line 218
    const/16 v13, 0x186

    .line 219
    .line 220
    const/16 v14, 0x8

    .line 221
    .line 222
    move-object v4, v6

    .line 223
    move-object v6, v7

    .line 224
    const/4 v7, 0x0

    .line 225
    move-object v9, v10

    .line 226
    iget-object v10, v0, Lb1;->i:Lw52;

    .line 227
    .line 228
    move-object v5, v1

    .line 229
    move-object v8, v2

    .line 230
    invoke-static/range {v4 .. v14}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 231
    .line 232
    .line 233
    goto :goto_1

    .line 234
    :cond_7
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 235
    .line 236
    .line 237
    :goto_1
    return-object v3

    .line 238
    :pswitch_1
    move-object/from16 v1, p1

    .line 239
    .line 240
    check-cast v1, Lzi2;

    .line 241
    .line 242
    move-object/from16 v2, p2

    .line 243
    .line 244
    check-cast v2, Ljava/lang/Integer;

    .line 245
    .line 246
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 247
    .line 248
    .line 249
    move-result v2

    .line 250
    and-int/lit8 v12, v2, 0x3

    .line 251
    .line 252
    if-eq v12, v7, :cond_8

    .line 253
    .line 254
    move v11, v10

    .line 255
    :cond_8
    and-int/2addr v2, v10

    .line 256
    invoke-virtual {v1, v2, v11}, Lzi2;->Y(IZ)Z

    .line 257
    .line 258
    .line 259
    move-result v2

    .line 260
    if-eqz v2, :cond_b

    .line 261
    .line 262
    invoke-static {v1}, Lck3;->e0(Lzi2;)Lbb4;

    .line 263
    .line 264
    .line 265
    move-result-object v14

    .line 266
    invoke-static {v1}, Lck3;->f0(Lzi2;)Lrm7;

    .line 267
    .line 268
    .line 269
    move-result-object v17

    .line 270
    sget-object v2, Lf38;->w:Ljava/util/WeakHashMap;

    .line 271
    .line 272
    invoke-static {v1}, Lva7;->h(Lzi2;)Lf38;

    .line 273
    .line 274
    .line 275
    move-result-object v2

    .line 276
    iget-object v2, v2, Lf38;->l:Lpt7;

    .line 277
    .line 278
    new-instance v7, Lip3;

    .line 279
    .line 280
    invoke-direct {v7, v2, v6}, Lip3;-><init>(Ly18;I)V

    .line 281
    .line 282
    .line 283
    sget-object v13, Lem1;->F:Ls21;

    .line 284
    .line 285
    new-instance v2, Lvh3;

    .line 286
    .line 287
    const/16 v6, 0x14

    .line 288
    .line 289
    invoke-direct {v2, v8, v6}, Lvh3;-><init>(Llh2;B)V

    .line 290
    .line 291
    .line 292
    const v6, -0x47ea689a

    .line 293
    .line 294
    .line 295
    invoke-static {v6, v2, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 296
    .line 297
    .line 298
    move-result-object v15

    .line 299
    invoke-virtual {v1, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 300
    .line 301
    .line 302
    move-result v2

    .line 303
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v6

    .line 307
    if-nez v2, :cond_9

    .line 308
    .line 309
    if-ne v6, v5, :cond_a

    .line 310
    .line 311
    :cond_9
    new-instance v6, Lg1;

    .line 312
    .line 313
    const/4 v2, 0x7

    .line 314
    invoke-direct {v6, v9, v4, v2}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    :cond_a
    move-object/from16 v20, v6

    .line 321
    .line 322
    check-cast v20, Lwh2;

    .line 323
    .line 324
    const/16 v22, 0x186

    .line 325
    .line 326
    const/16 v23, 0x8

    .line 327
    .line 328
    const/16 v16, 0x0

    .line 329
    .line 330
    iget-object v0, v0, Lb1;->i:Lw52;

    .line 331
    .line 332
    move-object/from16 v19, v0

    .line 333
    .line 334
    move-object/from16 v21, v1

    .line 335
    .line 336
    move-object/from16 v18, v7

    .line 337
    .line 338
    invoke-static/range {v13 .. v23}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 339
    .line 340
    .line 341
    goto :goto_2

    .line 342
    :cond_b
    move-object/from16 v21, v1

    .line 343
    .line 344
    invoke-virtual/range {v21 .. v21}, Lzi2;->b0()V

    .line 345
    .line 346
    .line 347
    :goto_2
    return-object v3

    .line 348
    :pswitch_2
    move-object/from16 v12, p1

    .line 349
    .line 350
    check-cast v12, Lzi2;

    .line 351
    .line 352
    move-object/from16 v1, p2

    .line 353
    .line 354
    check-cast v1, Ljava/lang/Integer;

    .line 355
    .line 356
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 357
    .line 358
    .line 359
    move-result v1

    .line 360
    and-int/lit8 v13, v1, 0x3

    .line 361
    .line 362
    if-eq v13, v7, :cond_c

    .line 363
    .line 364
    move v11, v10

    .line 365
    :cond_c
    and-int/2addr v1, v10

    .line 366
    invoke-virtual {v12, v1, v11}, Lzi2;->Y(IZ)Z

    .line 367
    .line 368
    .line 369
    move-result v1

    .line 370
    if-eqz v1, :cond_f

    .line 371
    .line 372
    invoke-static {v12}, Lck3;->e0(Lzi2;)Lbb4;

    .line 373
    .line 374
    .line 375
    move-result-object v1

    .line 376
    invoke-static {v12}, Lck3;->f0(Lzi2;)Lrm7;

    .line 377
    .line 378
    .line 379
    move-result-object v7

    .line 380
    sget-object v10, Lf38;->w:Ljava/util/WeakHashMap;

    .line 381
    .line 382
    invoke-static {v12}, Lva7;->h(Lzi2;)Lf38;

    .line 383
    .line 384
    .line 385
    move-result-object v10

    .line 386
    iget-object v10, v10, Lf38;->l:Lpt7;

    .line 387
    .line 388
    new-instance v11, Lip3;

    .line 389
    .line 390
    invoke-direct {v11, v10, v6}, Lip3;-><init>(Ly18;I)V

    .line 391
    .line 392
    .line 393
    sget-object v6, Lp80;->t:Ls21;

    .line 394
    .line 395
    new-instance v10, Lvh3;

    .line 396
    .line 397
    const/16 v13, 0x12

    .line 398
    .line 399
    invoke-direct {v10, v8, v13}, Lvh3;-><init>(Llh2;B)V

    .line 400
    .line 401
    .line 402
    const v8, -0xe3d5557

    .line 403
    .line 404
    .line 405
    invoke-static {v8, v10, v12}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 406
    .line 407
    .line 408
    move-result-object v8

    .line 409
    invoke-virtual {v12, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 410
    .line 411
    .line 412
    move-result v10

    .line 413
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 414
    .line 415
    .line 416
    move-result-object v13

    .line 417
    if-nez v10, :cond_d

    .line 418
    .line 419
    if-ne v13, v5, :cond_e

    .line 420
    .line 421
    :cond_d
    new-instance v13, Lg1;

    .line 422
    .line 423
    invoke-direct {v13, v9, v4, v2}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 424
    .line 425
    .line 426
    invoke-virtual {v12, v13}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 427
    .line 428
    .line 429
    :cond_e
    check-cast v13, Lwh2;

    .line 430
    .line 431
    move-object v9, v11

    .line 432
    move-object v11, v13

    .line 433
    const/16 v13, 0x186

    .line 434
    .line 435
    const/16 v14, 0x8

    .line 436
    .line 437
    move-object v4, v6

    .line 438
    move-object v6, v8

    .line 439
    move-object v8, v7

    .line 440
    const/4 v7, 0x0

    .line 441
    iget-object v10, v0, Lb1;->i:Lw52;

    .line 442
    .line 443
    move-object v5, v1

    .line 444
    invoke-static/range {v4 .. v14}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 445
    .line 446
    .line 447
    goto :goto_3

    .line 448
    :cond_f
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 449
    .line 450
    .line 451
    :goto_3
    return-object v3

    .line 452
    :pswitch_3
    move-object/from16 v1, p1

    .line 453
    .line 454
    check-cast v1, Lzi2;

    .line 455
    .line 456
    move-object/from16 v2, p2

    .line 457
    .line 458
    check-cast v2, Ljava/lang/Integer;

    .line 459
    .line 460
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 461
    .line 462
    .line 463
    move-result v2

    .line 464
    and-int/lit8 v12, v2, 0x3

    .line 465
    .line 466
    if-eq v12, v7, :cond_10

    .line 467
    .line 468
    move v11, v10

    .line 469
    :cond_10
    and-int/2addr v2, v10

    .line 470
    invoke-virtual {v1, v2, v11}, Lzi2;->Y(IZ)Z

    .line 471
    .line 472
    .line 473
    move-result v2

    .line 474
    if-eqz v2, :cond_13

    .line 475
    .line 476
    invoke-static {v1}, Lck3;->e0(Lzi2;)Lbb4;

    .line 477
    .line 478
    .line 479
    move-result-object v14

    .line 480
    invoke-static {v1}, Lck3;->f0(Lzi2;)Lrm7;

    .line 481
    .line 482
    .line 483
    move-result-object v17

    .line 484
    sget-object v2, Lf38;->w:Ljava/util/WeakHashMap;

    .line 485
    .line 486
    invoke-static {v1}, Lva7;->h(Lzi2;)Lf38;

    .line 487
    .line 488
    .line 489
    move-result-object v2

    .line 490
    iget-object v2, v2, Lf38;->l:Lpt7;

    .line 491
    .line 492
    new-instance v7, Lip3;

    .line 493
    .line 494
    invoke-direct {v7, v2, v6}, Lip3;-><init>(Ly18;I)V

    .line 495
    .line 496
    .line 497
    sget-object v13, Ln14;->h:Ls21;

    .line 498
    .line 499
    new-instance v2, Lj;

    .line 500
    .line 501
    const/16 v6, 0x9

    .line 502
    .line 503
    invoke-direct {v2, v8, v6}, Lj;-><init>(Llh2;B)V

    .line 504
    .line 505
    .line 506
    const v6, -0x765768fc

    .line 507
    .line 508
    .line 509
    invoke-static {v6, v2, v1}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 510
    .line 511
    .line 512
    move-result-object v15

    .line 513
    invoke-virtual {v1, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 514
    .line 515
    .line 516
    move-result v2

    .line 517
    invoke-virtual {v1}, Lzi2;->T()Ljava/lang/Object;

    .line 518
    .line 519
    .line 520
    move-result-object v6

    .line 521
    if-nez v2, :cond_11

    .line 522
    .line 523
    if-ne v6, v5, :cond_12

    .line 524
    .line 525
    :cond_11
    new-instance v6, Lg1;

    .line 526
    .line 527
    invoke-direct {v6, v9, v4, v10}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 528
    .line 529
    .line 530
    invoke-virtual {v1, v6}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 531
    .line 532
    .line 533
    :cond_12
    move-object/from16 v20, v6

    .line 534
    .line 535
    check-cast v20, Lwh2;

    .line 536
    .line 537
    const/16 v22, 0x186

    .line 538
    .line 539
    const/16 v23, 0x8

    .line 540
    .line 541
    const/16 v16, 0x0

    .line 542
    .line 543
    iget-object v0, v0, Lb1;->i:Lw52;

    .line 544
    .line 545
    move-object/from16 v19, v0

    .line 546
    .line 547
    move-object/from16 v21, v1

    .line 548
    .line 549
    move-object/from16 v18, v7

    .line 550
    .line 551
    invoke-static/range {v13 .. v23}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 552
    .line 553
    .line 554
    goto :goto_4

    .line 555
    :cond_13
    move-object/from16 v21, v1

    .line 556
    .line 557
    invoke-virtual/range {v21 .. v21}, Lzi2;->b0()V

    .line 558
    .line 559
    .line 560
    :goto_4
    return-object v3

    .line 561
    :pswitch_4
    move-object/from16 v12, p1

    .line 562
    .line 563
    check-cast v12, Lzi2;

    .line 564
    .line 565
    move-object/from16 v1, p2

    .line 566
    .line 567
    check-cast v1, Ljava/lang/Integer;

    .line 568
    .line 569
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 570
    .line 571
    .line 572
    move-result v1

    .line 573
    and-int/lit8 v13, v1, 0x3

    .line 574
    .line 575
    if-eq v13, v7, :cond_14

    .line 576
    .line 577
    move v7, v10

    .line 578
    goto :goto_5

    .line 579
    :cond_14
    move v7, v11

    .line 580
    :goto_5
    and-int/2addr v1, v10

    .line 581
    invoke-virtual {v12, v1, v7}, Lzi2;->Y(IZ)Z

    .line 582
    .line 583
    .line 584
    move-result v1

    .line 585
    if-eqz v1, :cond_17

    .line 586
    .line 587
    invoke-static {v12}, Lck3;->e0(Lzi2;)Lbb4;

    .line 588
    .line 589
    .line 590
    move-result-object v1

    .line 591
    invoke-static {v12}, Lck3;->f0(Lzi2;)Lrm7;

    .line 592
    .line 593
    .line 594
    move-result-object v7

    .line 595
    sget-object v10, Lf38;->w:Ljava/util/WeakHashMap;

    .line 596
    .line 597
    invoke-static {v12}, Lva7;->h(Lzi2;)Lf38;

    .line 598
    .line 599
    .line 600
    move-result-object v10

    .line 601
    iget-object v10, v10, Lf38;->l:Lpt7;

    .line 602
    .line 603
    new-instance v13, Lip3;

    .line 604
    .line 605
    invoke-direct {v13, v10, v6}, Lip3;-><init>(Ly18;I)V

    .line 606
    .line 607
    .line 608
    sget-object v6, Lnb3;->e:Ls21;

    .line 609
    .line 610
    new-instance v10, Lj;

    .line 611
    .line 612
    invoke-direct {v10, v8, v2}, Lj;-><init>(Llh2;B)V

    .line 613
    .line 614
    .line 615
    const v2, -0x3d76d02a

    .line 616
    .line 617
    .line 618
    invoke-static {v2, v10, v12}, Lix;->u0(ILii2;Lzi2;)Ls21;

    .line 619
    .line 620
    .line 621
    move-result-object v2

    .line 622
    invoke-virtual {v12, v9}, Lzi2;->g(Ljava/lang/Object;)Z

    .line 623
    .line 624
    .line 625
    move-result v8

    .line 626
    invoke-virtual {v12}, Lzi2;->T()Ljava/lang/Object;

    .line 627
    .line 628
    .line 629
    move-result-object v10

    .line 630
    if-nez v8, :cond_15

    .line 631
    .line 632
    if-ne v10, v5, :cond_16

    .line 633
    .line 634
    :cond_15
    new-instance v10, Lg1;

    .line 635
    .line 636
    invoke-direct {v10, v9, v4, v11}, Lg1;-><init>(Leh6;Lxd1;B)V

    .line 637
    .line 638
    .line 639
    invoke-virtual {v12, v10}, Lzi2;->q0(Ljava/lang/Object;)V

    .line 640
    .line 641
    .line 642
    :cond_16
    move-object v11, v10

    .line 643
    check-cast v11, Lwh2;

    .line 644
    .line 645
    move-object v9, v13

    .line 646
    const/16 v13, 0x186

    .line 647
    .line 648
    const/16 v14, 0x8

    .line 649
    .line 650
    move-object v8, v7

    .line 651
    const/4 v7, 0x0

    .line 652
    iget-object v10, v0, Lb1;->i:Lw52;

    .line 653
    .line 654
    move-object v5, v1

    .line 655
    move-object v4, v6

    .line 656
    move-object v6, v2

    .line 657
    invoke-static/range {v4 .. v14}, Lml3;->c(Lai2;Lbb4;Ls21;Ls21;Lrm7;Lip3;Lw52;Lwh2;Lzi2;II)V

    .line 658
    .line 659
    .line 660
    goto :goto_6

    .line 661
    :cond_17
    invoke-virtual {v12}, Lzi2;->b0()V

    .line 662
    .line 663
    .line 664
    :goto_6
    return-object v3

    .line 665
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
